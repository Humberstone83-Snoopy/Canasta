/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.javafx.event.BasicEventDispatcher;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.DragEvent;
/*     */ import javafx.scene.input.MouseDragEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnteredExitedHandler
/*     */   extends BasicEventDispatcher
/*     */ {
/*     */   private final Object eventSource;
/*     */   private boolean eventTypeModified;
/*     */   
/*     */   public EnteredExitedHandler(Object paramObject) {
/*  45 */     this.eventSource = paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Event dispatchCapturingEvent(Event paramEvent) {
/*  50 */     if (this.eventSource == paramEvent.getTarget()) {
/*  51 */       if (paramEvent.getEventType() == MouseEvent.MOUSE_ENTERED_TARGET) {
/*  52 */         this.eventTypeModified = true;
/*  53 */         return ((MouseEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), MouseEvent.MOUSE_ENTERED);
/*     */       } 
/*     */ 
/*     */       
/*  57 */       if (paramEvent.getEventType() == MouseEvent.MOUSE_EXITED_TARGET) {
/*  58 */         this.eventTypeModified = true;
/*  59 */         return ((MouseEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), MouseEvent.MOUSE_EXITED);
/*     */       } 
/*     */ 
/*     */       
/*  63 */       if (paramEvent.getEventType() == MouseDragEvent.MOUSE_DRAG_ENTERED_TARGET) {
/*  64 */         this.eventTypeModified = true;
/*  65 */         return ((MouseDragEvent)paramEvent).copyFor(this.eventSource, paramEvent
/*  66 */             .getTarget(), (EventType)MouseDragEvent.MOUSE_DRAG_ENTERED);
/*     */       } 
/*     */       
/*  69 */       if (paramEvent.getEventType() == MouseDragEvent.MOUSE_DRAG_EXITED_TARGET) {
/*  70 */         this.eventTypeModified = true;
/*  71 */         return ((MouseDragEvent)paramEvent).copyFor(this.eventSource, paramEvent
/*  72 */             .getTarget(), (EventType)MouseDragEvent.MOUSE_DRAG_EXITED);
/*     */       } 
/*     */       
/*  75 */       if (paramEvent.getEventType() == DragEvent.DRAG_ENTERED_TARGET) {
/*  76 */         this.eventTypeModified = true;
/*  77 */         return ((DragEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), DragEvent.DRAG_ENTERED);
/*     */       } 
/*     */ 
/*     */       
/*  81 */       if (paramEvent.getEventType() == DragEvent.DRAG_EXITED_TARGET) {
/*  82 */         this.eventTypeModified = true;
/*  83 */         return ((DragEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), DragEvent.DRAG_EXITED);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  88 */     this.eventTypeModified = false;
/*  89 */     return paramEvent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Event dispatchBubblingEvent(Event paramEvent) {
/*  94 */     if (this.eventTypeModified && this.eventSource == paramEvent.getTarget()) {
/*  95 */       if (paramEvent.getEventType() == MouseEvent.MOUSE_ENTERED) {
/*  96 */         return ((MouseEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), MouseEvent.MOUSE_ENTERED_TARGET);
/*     */       }
/*     */ 
/*     */       
/* 100 */       if (paramEvent.getEventType() == MouseEvent.MOUSE_EXITED) {
/* 101 */         return ((MouseEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), MouseEvent.MOUSE_EXITED_TARGET);
/*     */       }
/*     */ 
/*     */       
/* 105 */       if (paramEvent.getEventType() == MouseDragEvent.MOUSE_DRAG_ENTERED) {
/* 106 */         this.eventTypeModified = true;
/* 107 */         return ((MouseDragEvent)paramEvent).copyFor(this.eventSource, paramEvent
/* 108 */             .getTarget(), (EventType)MouseDragEvent.MOUSE_DRAG_ENTERED_TARGET);
/*     */       } 
/*     */       
/* 111 */       if (paramEvent.getEventType() == MouseDragEvent.MOUSE_DRAG_EXITED) {
/* 112 */         this.eventTypeModified = true;
/* 113 */         return ((MouseDragEvent)paramEvent).copyFor(this.eventSource, paramEvent
/* 114 */             .getTarget(), (EventType)MouseDragEvent.MOUSE_DRAG_EXITED_TARGET);
/*     */       } 
/*     */       
/* 117 */       if (paramEvent.getEventType() == DragEvent.DRAG_ENTERED) {
/* 118 */         return ((DragEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), DragEvent.DRAG_ENTERED_TARGET);
/*     */       }
/*     */ 
/*     */       
/* 122 */       if (paramEvent.getEventType() == DragEvent.DRAG_EXITED) {
/* 123 */         return ((DragEvent)paramEvent).copyFor(this.eventSource, paramEvent.getTarget(), DragEvent.DRAG_EXITED_TARGET);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return paramEvent;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\EnteredExitedHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */