/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBgraPre
/*     */ {
/*  39 */   public static final BytePixelGetter getter = Accessor.instance;
/*  40 */   public static final BytePixelSetter setter = Accessor.instance;
/*  41 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  44 */     return ToByteBgraConv.instance;
/*     */   }
/*     */   private static ByteToBytePixelConverter ToByteBgraPreObj;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/*  49 */     if (ToByteBgraPreObj == null) {
/*  50 */       ToByteBgraPreObj = BaseByteToByteConverter.create(accessor);
/*     */     }
/*  52 */     return ToByteBgraPreObj;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbConverter() {
/*  56 */     return ToIntArgbConv.instance;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbPreConverter() {
/*  60 */     return ByteBgra.ToIntArgbSameConv.premul;
/*     */   }
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  64 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  69 */       return AlphaType.PREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  74 */       return 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  79 */       return PixelUtils.PretoNonPre(getArgbPre(param1ArrayOfbyte, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  84 */       return param1ArrayOfbyte[param1Int] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int + 2] & 0xFF) << 16 | param1ArrayOfbyte[param1Int + 3] << 24;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  92 */       return PixelUtils.PretoNonPre(getArgbPre(param1ByteBuffer, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/*  97 */       return param1ByteBuffer.get(param1Int) & 0xFF | (param1ByteBuffer
/*  98 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/*  99 */         .get(param1Int + 2) & 0xFF) << 16 | param1ByteBuffer
/* 100 */         .get(param1Int + 3) << 24;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 105 */       setArgbPre(param1ArrayOfbyte, param1Int1, PixelUtils.NonPretoPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 110 */       param1ArrayOfbyte[param1Int1] = (byte)param1Int2;
/* 111 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)(param1Int2 >> 8);
/* 112 */       param1ArrayOfbyte[param1Int1 + 2] = (byte)(param1Int2 >> 16);
/* 113 */       param1ArrayOfbyte[param1Int1 + 3] = (byte)(param1Int2 >> 24);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 118 */       setArgbPre(param1ByteBuffer, param1Int1, PixelUtils.NonPretoPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 123 */       param1ByteBuffer.put(param1Int1, (byte)param1Int2);
/* 124 */       param1ByteBuffer.put(param1Int1 + 1, (byte)(param1Int2 >> 8));
/* 125 */       param1ByteBuffer.put(param1Int1 + 2, (byte)(param1Int2 >> 16));
/* 126 */       param1ByteBuffer.put(param1Int1 + 3, (byte)(param1Int2 >> 24));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ToByteBgraConv extends BaseByteToByteConverter {
/* 131 */     public static final ByteToBytePixelConverter instance = new ToByteBgraConv();
/*     */ 
/*     */     
/*     */     private ToByteBgraConv() {
/* 135 */       super(ByteBgraPre.getter, ByteBgra.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 143 */       param1Int2 -= param1Int5 * 4;
/* 144 */       param1Int4 -= param1Int5 * 4;
/* 145 */       while (--param1Int6 >= 0) {
/* 146 */         for (byte b = 0; b < param1Int5; b++) {
/* 147 */           byte b1 = param1ArrayOfbyte1[param1Int1++];
/* 148 */           byte b2 = param1ArrayOfbyte1[param1Int1++];
/* 149 */           byte b3 = param1ArrayOfbyte1[param1Int1++];
/* 150 */           int i = param1ArrayOfbyte1[param1Int1++] & 0xFF;
/* 151 */           if (i > 0 && i < 255) {
/* 152 */             int j = i >> 1;
/* 153 */             b1 = (byte)(((b1 & 0xFF) * 255 + j) / i);
/* 154 */             b2 = (byte)(((b2 & 0xFF) * 255 + j) / i);
/* 155 */             b3 = (byte)(((b3 & 0xFF) * 255 + j) / i);
/*     */           } 
/* 157 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 158 */           param1ArrayOfbyte2[param1Int3++] = b2;
/* 159 */           param1ArrayOfbyte2[param1Int3++] = b3;
/* 160 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/*     */         } 
/* 162 */         param1Int1 += param1Int2;
/* 163 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 172 */       param1Int2 -= param1Int5 * 4;
/* 173 */       param1Int4 -= param1Int5 * 4;
/* 174 */       while (--param1Int6 >= 0) {
/* 175 */         for (byte b = 0; b < param1Int5; b++) {
/* 176 */           byte b1 = param1ByteBuffer1.get(param1Int1);
/* 177 */           byte b2 = param1ByteBuffer1.get(param1Int1 + 1);
/* 178 */           byte b3 = param1ByteBuffer1.get(param1Int1 + 2);
/* 179 */           int i = param1ByteBuffer1.get(param1Int1 + 3) & 0xFF;
/* 180 */           param1Int1 += 4;
/* 181 */           if (i > 0 && i < 255) {
/* 182 */             int j = i >> 1;
/* 183 */             b1 = (byte)(((b1 & 0xFF) * 255 + j) / i);
/* 184 */             b2 = (byte)(((b2 & 0xFF) * 255 + j) / i);
/* 185 */             b3 = (byte)(((b3 & 0xFF) * 255 + j) / i);
/*     */           } 
/* 187 */           param1ByteBuffer2.put(param1Int3, b1);
/* 188 */           param1ByteBuffer2.put(param1Int3 + 1, b2);
/* 189 */           param1ByteBuffer2.put(param1Int3 + 2, b3);
/* 190 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)i);
/* 191 */           param1Int3 += 4;
/*     */         } 
/* 193 */         param1Int1 += param1Int2;
/* 194 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ToIntArgbConv extends BaseByteToIntConverter {
/* 200 */     public static final ByteToIntPixelConverter instance = new ToIntArgbConv();
/*     */ 
/*     */     
/*     */     private ToIntArgbConv() {
/* 204 */       super(ByteBgraPre.getter, IntArgb.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 212 */       param1Int2 -= param1Int5 * 4;
/* 213 */       param1Int4 -= param1Int5;
/* 214 */       while (--param1Int6 >= 0) {
/* 215 */         for (byte b = 0; b < param1Int5; b++) {
/* 216 */           int i = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 217 */           int j = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 218 */           int k = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 219 */           int m = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 220 */           if (m > 0 && m < 255) {
/* 221 */             int n = m >> 1;
/* 222 */             k = (k * 255 + n) / m;
/* 223 */             j = (j * 255 + n) / m;
/* 224 */             i = (i * 255 + n) / m;
/*     */           } 
/* 226 */           param1ArrayOfint[param1Int3++] = m << 24 | k << 16 | j << 8 | i;
/*     */         } 
/*     */         
/* 229 */         param1Int3 += param1Int4;
/* 230 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 239 */       param1Int2 -= param1Int5 * 4;
/* 240 */       while (--param1Int6 >= 0) {
/* 241 */         for (byte b = 0; b < param1Int5; b++) {
/* 242 */           int i = param1ByteBuffer.get(param1Int1) & 0xFF;
/* 243 */           int j = param1ByteBuffer.get(param1Int1 + 1) & 0xFF;
/* 244 */           int k = param1ByteBuffer.get(param1Int1 + 2) & 0xFF;
/* 245 */           int m = param1ByteBuffer.get(param1Int1 + 3) & 0xFF;
/* 246 */           param1Int1 += 4;
/* 247 */           if (m > 0 && m < 255) {
/* 248 */             int n = m >> 1;
/* 249 */             k = (k * 255 + n) / m;
/* 250 */             j = (j * 255 + n) / m;
/* 251 */             i = (i * 255 + n) / m;
/*     */           } 
/* 253 */           param1IntBuffer.put(param1Int3 + b, m << 24 | k << 16 | j << 8 | i);
/*     */         } 
/* 255 */         param1Int3 += param1Int4;
/* 256 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteBgraPre.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */