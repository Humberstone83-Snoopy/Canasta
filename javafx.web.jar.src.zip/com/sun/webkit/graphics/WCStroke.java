/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WCStroke<P, S>
/*     */ {
/*     */   public static final int NO_STROKE = 0;
/*     */   public static final int SOLID_STROKE = 1;
/*     */   public static final int DOTTED_STROKE = 2;
/*     */   public static final int DASHED_STROKE = 3;
/*     */   public static final int BUTT_CAP = 0;
/*     */   public static final int ROUND_CAP = 1;
/*     */   public static final int SQUARE_CAP = 2;
/*     */   public static final int MITER_JOIN = 0;
/*     */   public static final int ROUND_JOIN = 1;
/*     */   public static final int BEVEL_JOIN = 2;
/*  54 */   private int style = 1;
/*  55 */   private int lineCap = 0;
/*  56 */   private int lineJoin = 0;
/*  57 */   private float miterLimit = 10.0F;
/*  58 */   private float thickness = 1.0F;
/*     */   private float offset;
/*     */   private float[] sizes;
/*     */   private P paint;
/*     */   
/*     */   protected abstract void invalidate();
/*     */   
/*     */   public abstract S getPlatformStroke();
/*     */   
/*     */   public void copyFrom(WCStroke<P, S> paramWCStroke) {
/*  68 */     this.style = paramWCStroke.style;
/*  69 */     this.lineCap = paramWCStroke.lineCap;
/*  70 */     this.lineJoin = paramWCStroke.lineJoin;
/*  71 */     this.miterLimit = paramWCStroke.miterLimit;
/*  72 */     this.thickness = paramWCStroke.thickness;
/*  73 */     this.offset = paramWCStroke.offset;
/*  74 */     this.sizes = paramWCStroke.sizes;
/*  75 */     this.paint = paramWCStroke.paint;
/*     */   }
/*     */   
/*     */   public void setStyle(int paramInt) {
/*  79 */     if (paramInt != 1 && paramInt != 2 && paramInt != 3) {
/*  80 */       paramInt = 0;
/*     */     }
/*  82 */     if (this.style != paramInt) {
/*  83 */       this.style = paramInt;
/*  84 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLineCap(int paramInt) {
/*  89 */     if (paramInt != 1 && paramInt != 2) {
/*  90 */       paramInt = 0;
/*     */     }
/*  92 */     if (this.lineCap != paramInt) {
/*  93 */       this.lineCap = paramInt;
/*  94 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLineJoin(int paramInt) {
/*  99 */     if (paramInt != 1 && paramInt != 2) {
/* 100 */       paramInt = 0;
/*     */     }
/* 102 */     if (this.lineJoin != paramInt) {
/* 103 */       this.lineJoin = paramInt;
/* 104 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMiterLimit(float paramFloat) {
/* 109 */     if (paramFloat < 1.0F) {
/* 110 */       paramFloat = 1.0F;
/*     */     }
/* 112 */     if (this.miterLimit != paramFloat) {
/* 113 */       this.miterLimit = paramFloat;
/* 114 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setThickness(float paramFloat) {
/* 119 */     if (paramFloat < 0.0F) {
/* 120 */       paramFloat = 1.0F;
/*     */     }
/* 122 */     if (this.thickness != paramFloat) {
/* 123 */       this.thickness = paramFloat;
/* 124 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setDashOffset(float paramFloat) {
/* 129 */     if (this.offset != paramFloat) {
/* 130 */       this.offset = paramFloat;
/* 131 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setDashSizes(float... paramVarArgs) {
/* 136 */     if (paramVarArgs == null || paramVarArgs.length == 0) {
/* 137 */       if (this.sizes != null) {
/* 138 */         this.sizes = null;
/* 139 */         invalidate();
/*     */       }
/*     */     
/* 142 */     } else if (!Arrays.equals(this.sizes, paramVarArgs)) {
/* 143 */       this.sizes = (float[])paramVarArgs.clone();
/* 144 */       invalidate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setPaint(P paramP) {
/* 149 */     this.paint = paramP;
/*     */   }
/*     */   
/*     */   public int getStyle() {
/* 153 */     return this.style;
/*     */   }
/*     */   
/*     */   public int getLineCap() {
/* 157 */     return this.lineCap;
/*     */   }
/*     */   
/*     */   public int getLineJoin() {
/* 161 */     return this.lineJoin;
/*     */   }
/*     */   
/*     */   public float getMiterLimit() {
/* 165 */     return this.miterLimit;
/*     */   }
/*     */   
/*     */   public float getThickness() {
/* 169 */     return this.thickness;
/*     */   }
/*     */   
/*     */   public float getDashOffset() {
/* 173 */     return this.offset;
/*     */   }
/*     */   
/*     */   public float[] getDashSizes() {
/* 177 */     return (this.sizes != null) ? 
/* 178 */       (float[])this.sizes.clone() : 
/* 179 */       null;
/*     */   }
/*     */   
/*     */   public P getPaint() {
/* 183 */     return this.paint;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 188 */     StringBuilder stringBuilder = new StringBuilder(getClass().getSimpleName());
/* 189 */     stringBuilder.append("[style=").append(this.style);
/* 190 */     stringBuilder.append(", lineCap=").append(this.lineCap);
/* 191 */     stringBuilder.append(", lineJoin=").append(this.lineJoin);
/* 192 */     stringBuilder.append(", miterLimit=").append(this.miterLimit);
/* 193 */     stringBuilder.append(", thickness=").append(this.thickness);
/* 194 */     stringBuilder.append(", offset=").append(this.offset);
/* 195 */     stringBuilder.append(", sizes=").append(Arrays.toString(this.sizes));
/* 196 */     stringBuilder.append(", paint=").append(this.paint);
/* 197 */     return stringBuilder.append("]").toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCStroke.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */