/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.xpath.XPathNSResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathNSResolverImpl
/*    */   implements XPathNSResolver
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 36 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 39 */       XPathNSResolverImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   XPathNSResolverImpl(long paramLong) {
/* 44 */     this.peer = paramLong;
/* 45 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static XPathNSResolver create(long paramLong) {
/* 49 */     if (paramLong == 0L) return null; 
/* 50 */     return new XPathNSResolverImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 56 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 60 */     return (paramObject instanceof XPathNSResolverImpl && this.peer == ((XPathNSResolverImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 64 */     long l = this.peer;
/* 65 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(XPathNSResolver paramXPathNSResolver) {
/* 69 */     return (paramXPathNSResolver == null) ? 0L : ((XPathNSResolverImpl)paramXPathNSResolver).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static XPathNSResolver getImpl(long paramLong) {
/* 75 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String lookupNamespaceURI(String paramString) {
/* 82 */     return lookupNamespaceURIImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native String lookupNamespaceURIImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\XPathNSResolverImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */