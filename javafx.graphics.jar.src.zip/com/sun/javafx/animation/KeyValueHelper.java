/*    */ package com.sun.javafx.animation;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.animation.KeyValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KeyValueHelper
/*    */ {
/*    */   private static KeyValueAccessor keyValueAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(KeyValue.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static KeyValueType getType(KeyValue paramKeyValue) {
/* 46 */     return keyValueAccessor.getType(paramKeyValue);
/*    */   }
/*    */   
/*    */   public static void setKeyValueAccessor(KeyValueAccessor paramKeyValueAccessor) {
/* 50 */     if (keyValueAccessor != null) {
/* 51 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 54 */     keyValueAccessor = paramKeyValueAccessor;
/*    */   }
/*    */   
/*    */   public static interface KeyValueAccessor {
/*    */     KeyValueType getType(KeyValue param1KeyValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\animation\KeyValueHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */