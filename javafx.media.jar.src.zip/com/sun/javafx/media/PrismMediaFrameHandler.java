/*     */ package com.sun.javafx.media;
/*     */ 
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.javafx.tk.RenderJob;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*     */ import com.sun.media.jfxmedia.control.VideoFormat;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.GraphicsPipeline;
/*     */ import com.sun.prism.MediaFrame;
/*     */ import com.sun.prism.PixelFormat;
/*     */ import com.sun.prism.ResourceFactoryListener;
/*     */ import com.sun.prism.Texture;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrismMediaFrameHandler
/*     */   implements ResourceFactoryListener
/*     */ {
/*  48 */   private final Map<Screen, TextureMapEntry> textures = new WeakHashMap<>(1);
/*     */   private static Map<Object, PrismMediaFrameHandler> handlers;
/*     */   
/*     */   public static synchronized PrismMediaFrameHandler getHandler(Object paramObject) {
/*  52 */     if (paramObject == null) {
/*  53 */       throw new IllegalArgumentException("provider must be non-null");
/*     */     }
/*  55 */     if (handlers == null) {
/*  56 */       handlers = new WeakHashMap<>(1);
/*     */     }
/*  58 */     PrismMediaFrameHandler prismMediaFrameHandler = handlers.get(paramObject);
/*  59 */     if (prismMediaFrameHandler == null) {
/*  60 */       prismMediaFrameHandler = new PrismMediaFrameHandler(paramObject);
/*  61 */       handlers.put(paramObject, prismMediaFrameHandler);
/*     */     } 
/*  63 */     return prismMediaFrameHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean registeredWithFactory = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final RenderJob releaseRenderJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Texture getTexture(Graphics paramGraphics, VideoDataBuffer paramVideoDataBuffer) {
/*  85 */     Screen screen = paramGraphics.getAssociatedScreen();
/*  86 */     TextureMapEntry textureMapEntry = this.textures.get(screen);
/*     */     
/*  88 */     if (null == paramVideoDataBuffer) {
/*     */       
/*  90 */       if (this.textures.containsKey(screen)) {
/*  91 */         this.textures.remove(screen);
/*     */       }
/*  93 */       return null;
/*     */     } 
/*     */     
/*  96 */     if (null == textureMapEntry) {
/*     */       
/*  98 */       textureMapEntry = new TextureMapEntry();
/*  99 */       this.textures.put(screen, textureMapEntry);
/*     */     } 
/*     */     
/* 102 */     if (textureMapEntry.texture != null) {
/* 103 */       textureMapEntry.texture.lock();
/* 104 */       if (textureMapEntry.texture.isSurfaceLost()) {
/* 105 */         textureMapEntry.texture = null;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 110 */     if (null == textureMapEntry.texture || textureMapEntry.lastFrameTime != paramVideoDataBuffer.getTimestamp()) {
/* 111 */       updateTexture(paramGraphics, paramVideoDataBuffer, textureMapEntry);
/*     */     }
/*     */     
/* 114 */     return textureMapEntry.texture;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateTexture(Graphics paramGraphics, VideoDataBuffer paramVideoDataBuffer, TextureMapEntry paramTextureMapEntry) {
/* 119 */     Screen screen = paramGraphics.getAssociatedScreen();
/*     */ 
/*     */     
/* 122 */     if (paramTextureMapEntry.texture != null && (paramTextureMapEntry.encodedWidth != paramVideoDataBuffer
/* 123 */       .getEncodedWidth() || paramTextureMapEntry.encodedHeight != paramVideoDataBuffer
/* 124 */       .getEncodedHeight())) {
/*     */       
/* 126 */       paramTextureMapEntry.texture.dispose();
/* 127 */       paramTextureMapEntry.texture = null;
/*     */     } 
/*     */     
/* 130 */     PrismFrameBuffer prismFrameBuffer = new PrismFrameBuffer(paramVideoDataBuffer);
/* 131 */     if (paramTextureMapEntry.texture == null) {
/* 132 */       if (!this.registeredWithFactory) {
/*     */ 
/*     */         
/* 135 */         GraphicsPipeline.getDefaultResourceFactory().addFactoryListener(this);
/* 136 */         this.registeredWithFactory = true;
/*     */       } 
/*     */       
/* 139 */       paramTextureMapEntry
/*     */         
/* 141 */         .texture = GraphicsPipeline.getPipeline().getResourceFactory(screen).createTexture(prismFrameBuffer);
/* 142 */       paramTextureMapEntry.encodedWidth = paramVideoDataBuffer.getEncodedWidth();
/* 143 */       paramTextureMapEntry.encodedHeight = paramVideoDataBuffer.getEncodedHeight();
/*     */     } 
/*     */ 
/*     */     
/* 147 */     if (paramTextureMapEntry.texture != null) {
/* 148 */       paramTextureMapEntry.texture.update(prismFrameBuffer, false);
/*     */     }
/* 150 */     paramTextureMapEntry.lastFrameTime = paramVideoDataBuffer.getTimestamp();
/*     */   }
/*     */   
/*     */   private void releaseData() {
/* 154 */     for (TextureMapEntry textureMapEntry : this.textures.values()) {
/* 155 */       if (textureMapEntry != null && textureMapEntry.texture != null) {
/* 156 */         textureMapEntry.texture.dispose();
/*     */       }
/*     */     } 
/* 159 */     this.textures.clear();
/*     */   }
/*     */   private PrismMediaFrameHandler(Object paramObject) {
/* 162 */     this.releaseRenderJob = new RenderJob(() -> releaseData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseTextures() {
/* 171 */     Toolkit toolkit = Toolkit.getToolkit();
/* 172 */     toolkit.addRenderJob(this.releaseRenderJob);
/*     */   }
/*     */   
/*     */   public void factoryReset() {
/* 176 */     releaseData();
/*     */   }
/*     */   
/*     */   public void factoryReleased() {
/* 180 */     releaseData();
/*     */   }
/*     */ 
/*     */   
/*     */   private class PrismFrameBuffer
/*     */     implements MediaFrame
/*     */   {
/*     */     private final PixelFormat videoFormat;
/*     */     
/*     */     private final VideoDataBuffer master;
/*     */     
/*     */     public PrismFrameBuffer(VideoDataBuffer param1VideoDataBuffer) {
/* 192 */       if (null == param1VideoDataBuffer) {
/* 193 */         throw new NullPointerException();
/*     */       }
/*     */       
/* 196 */       this.master = param1VideoDataBuffer;
/* 197 */       switch (this.master.getFormat()) {
/*     */         case BGRA_PRE:
/* 199 */           this.videoFormat = PixelFormat.INT_ARGB_PRE;
/*     */           return;
/*     */         case YCbCr_420p:
/* 202 */           this.videoFormat = PixelFormat.MULTI_YCbCr_420;
/*     */           return;
/*     */         case YCbCr_422:
/* 205 */           this.videoFormat = PixelFormat.BYTE_APPLE_422;
/*     */           return;
/*     */       } 
/*     */ 
/*     */       
/* 210 */       throw new IllegalArgumentException("Unsupported video format " + this.master.getFormat());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteBuffer getBufferForPlane(int param1Int) {
/* 216 */       return this.master.getBufferForPlane(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public void holdFrame() {
/* 221 */       this.master.holdFrame();
/*     */     }
/*     */ 
/*     */     
/*     */     public void releaseFrame() {
/* 226 */       this.master.releaseFrame();
/*     */     }
/*     */ 
/*     */     
/*     */     public PixelFormat getPixelFormat() {
/* 231 */       return this.videoFormat;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getWidth() {
/* 236 */       return this.master.getWidth();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getHeight() {
/* 241 */       return this.master.getHeight();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getEncodedWidth() {
/* 246 */       return this.master.getEncodedWidth();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getEncodedHeight() {
/* 251 */       return this.master.getEncodedHeight();
/*     */     }
/*     */ 
/*     */     
/*     */     public int planeCount() {
/* 256 */       return this.master.getPlaneCount();
/*     */     }
/*     */ 
/*     */     
/*     */     public int[] planeStrides() {
/* 261 */       return this.master.getPlaneStrides();
/*     */     }
/*     */ 
/*     */     
/*     */     public int strideForPlane(int param1Int) {
/* 266 */       return this.master.getStrideForPlane(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public MediaFrame convertToFormat(PixelFormat param1PixelFormat) {
/* 271 */       if (param1PixelFormat == getPixelFormat()) {
/* 272 */         return this;
/*     */       }
/*     */ 
/*     */       
/* 276 */       if (param1PixelFormat != PixelFormat.INT_ARGB_PRE) {
/* 277 */         return null;
/*     */       }
/*     */       
/* 280 */       VideoDataBuffer videoDataBuffer = this.master.convertToFormat(VideoFormat.BGRA_PRE);
/* 281 */       if (null == videoDataBuffer) {
/* 282 */         return null;
/*     */       }
/* 284 */       return new PrismFrameBuffer(videoDataBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TextureMapEntry {
/* 289 */     public double lastFrameTime = -1.0D;
/*     */     
/*     */     private TextureMapEntry() {}
/*     */     
/*     */     public Texture texture;
/*     */     public int encodedWidth;
/*     */     public int encodedHeight;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\javafx\media\PrismMediaFrameHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */