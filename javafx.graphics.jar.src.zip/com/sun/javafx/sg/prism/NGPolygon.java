/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGPolygon
/*    */   extends NGShape
/*    */ {
/* 36 */   private Path2D path = new Path2D();
/*    */   
/*    */   public void updatePolygon(float[] paramArrayOffloat) {
/* 39 */     this.path.reset();
/* 40 */     if (paramArrayOffloat == null || paramArrayOffloat.length == 0 || paramArrayOffloat.length % 2 != 0) {
/*    */       return;
/*    */     }
/* 43 */     this.path.moveTo(paramArrayOffloat[0], paramArrayOffloat[1]);
/* 44 */     for (byte b = 1; b < paramArrayOffloat.length / 2; b++) {
/* 45 */       float f1 = paramArrayOffloat[b * 2 + 0];
/* 46 */       float f2 = paramArrayOffloat[b * 2 + 1];
/* 47 */       this.path.lineTo(f1, f2);
/*    */     } 
/* 49 */     this.path.closePath();
/* 50 */     geometryChanged();
/*    */   }
/*    */ 
/*    */   
/*    */   public Shape getShape() {
/* 55 */     return this.path;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGPolygon.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */