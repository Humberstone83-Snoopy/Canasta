/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.events.mac.NpapiEvent;
/*     */ import com.sun.glass.ui.Cursor;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacWindow
/*     */   extends Window
/*     */ {
/*     */   private ByteBuffer iconBuffer;
/*     */   
/*     */   static {
/*  46 */     _initIDs();
/*     */   }
/*     */   
/*     */   protected MacWindow(Window paramWindow, Screen paramScreen, int paramInt) {
/*  50 */     super(paramWindow, paramScreen, paramInt);
/*     */   }
/*     */   protected MacWindow(long paramLong) {
/*  53 */     super(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _setBounds(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
/*  68 */     float f1 = getPlatformScaleX();
/*  69 */     float f2 = getPlatformScaleY();
/*  70 */     if (paramBoolean1) paramInt1 = Math.round(paramInt1 / f1); 
/*  71 */     if (paramBoolean2) paramInt2 = Math.round(paramInt2 / f2); 
/*  72 */     if (paramInt3 > 0) paramInt3 = Math.round(paramInt3 / f1); 
/*  73 */     if (paramInt4 > 0) paramInt4 = Math.round(paramInt4 / f2); 
/*  74 */     if (paramInt5 > 0) paramInt5 = Math.round(paramInt5 / f1); 
/*  75 */     if (paramInt6 > 0) paramInt6 = Math.round(paramInt6 / f2); 
/*  76 */     _setBounds2(paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _requestFocus(long paramLong, int paramInt) {
/*  85 */     if (paramInt != 541) {
/*  86 */       return _requestFocus(paramLong);
/*     */     }
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _setIcon(long paramLong, Pixels paramPixels) {
/* 104 */     if (paramPixels != null) {
/* 105 */       this.iconBuffer = paramPixels.asByteBuffer();
/* 106 */       _setIcon(paramLong, this.iconBuffer, paramPixels.getWidth(), paramPixels.getHeight());
/*     */     } else {
/* 108 */       this.iconBuffer = null;
/* 109 */       _setIcon(paramLong, (Object)null, 0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyResize(int paramInt1, int paramInt2, int paramInt3) {
/* 129 */     paramInt2 = Math.round(paramInt2 * getPlatformScaleX());
/* 130 */     paramInt3 = Math.round(paramInt3 * getPlatformScaleY());
/* 131 */     super.notifyResize(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   protected void notifyMove(int paramInt1, int paramInt2, boolean paramBoolean) {
/* 135 */     if (isMaximized() != paramBoolean && !isMinimized()) {
/* 136 */       setState(paramBoolean ? 3 : 1);
/* 137 */       handleWindowEvent(System.nanoTime(), 
/* 138 */           paramBoolean ? 
/* 139 */           532 : 
/* 140 */           533);
/*     */     } 
/* 142 */     notifyMove(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _setCursor(long paramLong, Cursor paramCursor) {
/* 147 */     ((MacCursor)paramCursor).set();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispatchNpapiEvent(Map paramMap) {
/* 152 */     NpapiEvent.dispatchCocoaNpapiEvent(this, paramMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _requestInput(long paramLong, String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14) {
/* 160 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _releaseInput(long paramLong) {
/* 165 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   protected native long _createWindow(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   protected native long _createChildWindow(long paramLong);
/*     */   
/*     */   protected native boolean _close(long paramLong);
/*     */   
/*     */   protected native boolean _setView(long paramLong, View paramView);
/*     */   
/*     */   protected native boolean _setMenubar(long paramLong1, long paramLong2);
/*     */   
/*     */   protected native boolean _minimize(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   protected native void _setBounds2(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2);
/*     */   
/*     */   protected native boolean _setVisible(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setResizable(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private native boolean _requestFocus(long paramLong);
/*     */   
/*     */   protected native void _setFocusable(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setTitle(long paramLong, String paramString);
/*     */   
/*     */   protected native void _setLevel(long paramLong, int paramInt);
/*     */   
/*     */   protected native void _setAlpha(long paramLong, float paramFloat);
/*     */   
/*     */   protected native boolean _setBackground(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
/*     */   
/*     */   protected native void _setEnabled(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   protected native boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   private native void _setIcon(long paramLong, Object paramObject, int paramInt1, int paramInt2);
/*     */   
/*     */   protected native void _toFront(long paramLong);
/*     */   
/*     */   protected native void _toBack(long paramLong);
/*     */   
/*     */   protected native void _enterModal(long paramLong);
/*     */   
/*     */   protected native void _enterModalWithWindow(long paramLong1, long paramLong2);
/*     */   
/*     */   protected native void _exitModal(long paramLong);
/*     */   
/*     */   protected native boolean _grabFocus(long paramLong);
/*     */   
/*     */   protected native void _ungrabFocus(long paramLong);
/*     */   
/*     */   protected native int _getEmbeddedX(long paramLong);
/*     */   
/*     */   protected native int _getEmbeddedY(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacWindow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */