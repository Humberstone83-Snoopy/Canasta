/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ import com.sun.glass.utils.NativeLibLoader;
/*    */ import java.io.IOException;
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DFontDecoder
/*    */   extends FontFileWriter
/*    */ {
/*    */   static {
/* 36 */     AccessController.doPrivileged(() -> {
/*    */           NativeLibLoader.loadLibrary("javafx_font");
/*    */           return null;
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void decode(String paramString) throws IOException {
/* 52 */     if (paramString == null) {
/* 53 */       throw new IOException("Invalid font name");
/*    */     }
/* 55 */     long l = 0L;
/*    */     try {
/* 57 */       l = createCTFont(paramString);
/* 58 */       if (l == 0L) {
/* 59 */         throw new IOException("Failure creating CTFont");
/*    */       }
/* 61 */       int i = getCTFontFormat(l);
/* 62 */       if (i != 1953658213 && i != 65536 && i != 1330926671) {
/* 63 */         throw new IOException("Unsupported Dfont");
/*    */       }
/* 65 */       int[] arrayOfInt = getCTFontTags(l);
/* 66 */       short s = (short)arrayOfInt.length;
/* 67 */       int j = 12 + 16 * s;
/* 68 */       byte[][] arrayOfByte = new byte[s][]; int k;
/* 69 */       for (k = 0; k < arrayOfInt.length; k++) {
/* 70 */         int m = arrayOfInt[k];
/* 71 */         arrayOfByte[k] = getCTFontTable(l, m);
/* 72 */         int n = (arrayOfByte[k]).length;
/* 73 */         j += n + 3 & 0xFFFFFFFC;
/*    */       } 
/* 75 */       releaseCTFont(l);
/* 76 */       l = 0L;
/*    */ 
/*    */       
/* 79 */       setLength(j);
/* 80 */       writeHeader(i, s);
/*    */       
/* 82 */       k = 12 + 16 * s;
/* 83 */       for (byte b = 0; b < s; b++) {
/* 84 */         int m = arrayOfInt[b];
/* 85 */         byte[] arrayOfByte1 = arrayOfByte[b];
/*    */ 
/*    */         
/* 88 */         writeDirectoryEntry(b, m, 0, k, arrayOfByte1.length);
/*    */ 
/*    */         
/* 91 */         seek(k);
/* 92 */         writeBytes(arrayOfByte1);
/*    */         
/* 94 */         k += arrayOfByte1.length + 3 & 0xFFFFFFFC;
/*    */       } 
/*    */     } finally {
/*    */       
/* 98 */       if (l != 0L)
/* 99 */         releaseCTFont(l); 
/*    */     } 
/*    */   }
/*    */   
/*    */   private static native byte[] getCTFontTable(long paramLong, int paramInt);
/*    */   
/*    */   private static native int[] getCTFontTags(long paramLong);
/*    */   
/*    */   private static native int getCTFontFormat(long paramLong);
/*    */   
/*    */   private static native void releaseCTFont(long paramLong);
/*    */   
/*    */   private static native long createCTFont(String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\DFontDecoder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */