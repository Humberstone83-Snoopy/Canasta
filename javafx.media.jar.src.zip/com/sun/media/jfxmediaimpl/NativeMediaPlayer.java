/*      */ package com.sun.media.jfxmediaimpl;
/*      */ 
/*      */ import com.sun.media.jfxmedia.Media;
/*      */ import com.sun.media.jfxmedia.MediaError;
/*      */ import com.sun.media.jfxmedia.MediaException;
/*      */ import com.sun.media.jfxmedia.MediaPlayer;
/*      */ import com.sun.media.jfxmedia.control.VideoRenderControl;
/*      */ import com.sun.media.jfxmedia.effects.AudioEqualizer;
/*      */ import com.sun.media.jfxmedia.effects.AudioSpectrum;
/*      */ import com.sun.media.jfxmedia.events.AudioSpectrumEvent;
/*      */ import com.sun.media.jfxmedia.events.AudioSpectrumListener;
/*      */ import com.sun.media.jfxmedia.events.BufferListener;
/*      */ import com.sun.media.jfxmedia.events.BufferProgressEvent;
/*      */ import com.sun.media.jfxmedia.events.MarkerEvent;
/*      */ import com.sun.media.jfxmedia.events.MarkerListener;
/*      */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*      */ import com.sun.media.jfxmedia.events.NewFrameEvent;
/*      */ import com.sun.media.jfxmedia.events.PlayerEvent;
/*      */ import com.sun.media.jfxmedia.events.PlayerStateEvent;
/*      */ import com.sun.media.jfxmedia.events.PlayerStateListener;
/*      */ import com.sun.media.jfxmedia.events.PlayerTimeListener;
/*      */ import com.sun.media.jfxmedia.events.VideoFrameRateListener;
/*      */ import com.sun.media.jfxmedia.events.VideoRendererListener;
/*      */ import com.sun.media.jfxmedia.events.VideoTrackSizeListener;
/*      */ import com.sun.media.jfxmedia.logging.Logger;
/*      */ import com.sun.media.jfxmedia.track.AudioTrack;
/*      */ import com.sun.media.jfxmedia.track.SubtitleTrack;
/*      */ import com.sun.media.jfxmedia.track.Track;
/*      */ import com.sun.media.jfxmedia.track.VideoResolution;
/*      */ import com.sun.media.jfxmedia.track.VideoTrack;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Timer;
/*      */ import java.util.concurrent.BlockingQueue;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class NativeMediaPlayer
/*      */   implements MediaPlayer, MarkerStateListener
/*      */ {
/*      */   public static final int eventPlayerUnknown = 100;
/*      */   public static final int eventPlayerReady = 101;
/*      */   public static final int eventPlayerPlaying = 102;
/*      */   public static final int eventPlayerPaused = 103;
/*      */   public static final int eventPlayerStopped = 104;
/*      */   public static final int eventPlayerStalled = 105;
/*      */   public static final int eventPlayerFinished = 106;
/*      */   public static final int eventPlayerError = 107;
/*      */   private static final int NOMINAL_VIDEO_FPS = 30;
/*      */   public static final long ONE_SECOND = 1000000000L;
/*      */   private NativeMedia media;
/*      */   private VideoRenderControl videoRenderControl;
/*   93 */   private final List<WeakReference<MediaErrorListener>> errorListeners = new ArrayList<>();
/*   94 */   private final List<WeakReference<PlayerStateListener>> playerStateListeners = new ArrayList<>();
/*   95 */   private final List<WeakReference<PlayerTimeListener>> playerTimeListeners = new ArrayList<>();
/*   96 */   private final List<WeakReference<VideoTrackSizeListener>> videoTrackSizeListeners = new ArrayList<>();
/*   97 */   private final List<WeakReference<VideoRendererListener>> videoUpdateListeners = new ArrayList<>();
/*   98 */   private final List<WeakReference<VideoFrameRateListener>> videoFrameRateListeners = new ArrayList<>();
/*   99 */   private final List<WeakReference<MarkerListener>> markerListeners = new ArrayList<>();
/*  100 */   private final List<WeakReference<BufferListener>> bufferListeners = new ArrayList<>();
/*  101 */   private final List<WeakReference<AudioSpectrumListener>> audioSpectrumListeners = new ArrayList<>();
/*  102 */   private final List<PlayerStateEvent> cachedStateEvents = new ArrayList<>();
/*  103 */   private final List<PlayerTimeEvent> cachedTimeEvents = new ArrayList<>();
/*  104 */   private final List<BufferProgressEvent> cachedBufferEvents = new ArrayList<>();
/*  105 */   private final List<MediaErrorEvent> cachedErrorEvents = new ArrayList<>();
/*      */   private boolean isFirstFrame = true;
/*  107 */   private NewFrameEvent firstFrameEvent = null;
/*      */   private double firstFrameTime;
/*  109 */   private final Object firstFrameLock = new Object();
/*  110 */   private EventQueueThread eventLoop = new EventQueueThread();
/*  111 */   private int frameWidth = -1;
/*  112 */   private int frameHeight = -1;
/*  113 */   private final AtomicBoolean isMediaPulseEnabled = new AtomicBoolean(false);
/*  114 */   private final Lock mediaPulseLock = new ReentrantLock();
/*      */   private Timer mediaPulseTimer;
/*  116 */   private final Lock markerLock = new ReentrantLock();
/*      */   private boolean checkSeek = false;
/*  118 */   private double timeBeforeSeek = 0.0D;
/*  119 */   private double timeAfterSeek = 0.0D;
/*  120 */   private double previousTime = 0.0D;
/*  121 */   private double firedMarkerTime = -1.0D;
/*  122 */   private double startTime = 0.0D;
/*  123 */   private double stopTime = Double.POSITIVE_INFINITY;
/*      */   
/*      */   private boolean isStartTimeUpdated = false;
/*      */   
/*      */   private boolean isStopTimeSet = false;
/*  128 */   private double encodedFrameRate = 0.0D;
/*      */   
/*      */   private boolean recomputeFrameRate = true;
/*      */   private double previousFrameTime;
/*      */   private long numFramesSincePlaying;
/*      */   private double meanFrameDuration;
/*      */   private double decodedFrameRate;
/*  135 */   private PlayerStateEvent.PlayerState playerState = PlayerStateEvent.PlayerState.UNKNOWN;
/*  136 */   private final Lock disposeLock = new ReentrantLock();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isDisposed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Runnable onDispose;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NativeMediaPlayer(NativeMedia paramNativeMedia) {
/*  152 */     if (paramNativeMedia == null) {
/*  153 */       throw new IllegalArgumentException("clip == null!");
/*      */     }
/*  155 */     this.media = paramNativeMedia;
/*  156 */     this.videoRenderControl = new VideoRenderer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*  165 */     this.media.addMarkerStateListener(this);
/*  166 */     this.eventLoop.start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setOnDispose(Runnable paramRunnable) {
/*  176 */     this.disposeLock.lock();
/*      */     try {
/*  178 */       if (!this.isDisposed) {
/*  179 */         this.onDispose = paramRunnable;
/*      */       }
/*      */     } finally {
/*  182 */       this.disposeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static class WarningEvent
/*      */     extends PlayerEvent
/*      */   {
/*      */     private final Object source;
/*      */     
/*      */     private final String message;
/*      */     
/*      */     WarningEvent(Object param1Object, String param1String) {
/*  195 */       this.source = param1Object;
/*  196 */       this.message = param1String;
/*      */     }
/*      */     
/*      */     public Object getSource() {
/*  200 */       return this.source;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/*  204 */       return this.message;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class MediaErrorEvent
/*      */     extends PlayerEvent
/*      */   {
/*      */     private final Object source;
/*      */     
/*      */     private final MediaError error;
/*      */     
/*      */     public MediaErrorEvent(Object param1Object, MediaError param1MediaError) {
/*  217 */       this.source = param1Object;
/*  218 */       this.error = param1MediaError;
/*      */     }
/*      */     
/*      */     public Object getSource() {
/*  222 */       return this.source;
/*      */     }
/*      */     
/*      */     public String getMessage() {
/*  226 */       return this.error.description();
/*      */     }
/*      */     
/*      */     public int getErrorCode() {
/*  230 */       return this.error.code();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class PlayerTimeEvent
/*      */     extends PlayerEvent {
/*      */     private final double time;
/*      */     
/*      */     public PlayerTimeEvent(double param1Double) {
/*  239 */       this.time = param1Double;
/*      */     }
/*      */     
/*      */     public double getTime() {
/*  243 */       return this.time;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class TrackEvent
/*      */     extends PlayerEvent
/*      */   {
/*      */     private final Track track;
/*      */ 
/*      */     
/*      */     TrackEvent(Track param1Track) {
/*  255 */       this.track = param1Track;
/*      */     }
/*      */     
/*      */     public Track getTrack() {
/*  259 */       return this.track;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class FrameSizeChangedEvent
/*      */     extends PlayerEvent
/*      */   {
/*      */     private final int width;
/*      */     
/*      */     private final int height;
/*      */     
/*      */     public FrameSizeChangedEvent(int param1Int1, int param1Int2) {
/*  272 */       if (param1Int1 > 0) {
/*  273 */         this.width = param1Int1;
/*      */       } else {
/*  275 */         this.width = 0;
/*      */       } 
/*      */       
/*  278 */       if (param1Int2 > 0) {
/*  279 */         this.height = param1Int2;
/*      */       } else {
/*  281 */         this.height = 0;
/*      */       } 
/*      */     }
/*      */     
/*      */     public int getWidth() {
/*  286 */       return this.width;
/*      */     }
/*      */     
/*      */     public int getHeight() {
/*  290 */       return this.height;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class VideoRenderer
/*      */     implements VideoRenderControl
/*      */   {
/*      */     private VideoRenderer() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addVideoRendererListener(VideoRendererListener param1VideoRendererListener) {
/*  311 */       if (param1VideoRendererListener != null) {
/*  312 */         synchronized (NativeMediaPlayer.this.firstFrameLock) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  317 */           if (NativeMediaPlayer.this.firstFrameEvent != null) {
/*  318 */             param1VideoRendererListener.videoFrameUpdated(NativeMediaPlayer.this.firstFrameEvent);
/*      */           }
/*      */         } 
/*  321 */         NativeMediaPlayer.this.videoUpdateListeners.add(new WeakReference<>(param1VideoRendererListener));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeVideoRendererListener(VideoRendererListener param1VideoRendererListener) {
/*  332 */       if (param1VideoRendererListener != null) {
/*  333 */         for (ListIterator<WeakReference<VideoRendererListener>> listIterator = NativeMediaPlayer.this.videoUpdateListeners.listIterator(); listIterator.hasNext(); ) {
/*  334 */           VideoRendererListener videoRendererListener = ((WeakReference<VideoRendererListener>)listIterator.next()).get();
/*  335 */           if (videoRendererListener == null || videoRendererListener == param1VideoRendererListener) {
/*  336 */             listIterator.remove();
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void addVideoFrameRateListener(VideoFrameRateListener param1VideoFrameRateListener) {
/*  344 */       if (param1VideoFrameRateListener != null) {
/*  345 */         NativeMediaPlayer.this.videoFrameRateListeners.add(new WeakReference<>(param1VideoFrameRateListener));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeVideoFrameRateListener(VideoFrameRateListener param1VideoFrameRateListener) {
/*  351 */       if (param1VideoFrameRateListener != null) {
/*  352 */         for (ListIterator<WeakReference<VideoFrameRateListener>> listIterator = NativeMediaPlayer.this.videoFrameRateListeners.listIterator(); listIterator.hasNext(); ) {
/*  353 */           VideoFrameRateListener videoFrameRateListener = ((WeakReference<VideoFrameRateListener>)listIterator.next()).get();
/*  354 */           if (videoFrameRateListener == null || videoFrameRateListener == param1VideoFrameRateListener) {
/*  355 */             listIterator.remove();
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public int getFrameWidth() {
/*  363 */       return NativeMediaPlayer.this.frameWidth;
/*      */     }
/*      */ 
/*      */     
/*      */     public int getFrameHeight() {
/*  368 */       return NativeMediaPlayer.this.frameHeight;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class EventQueueThread
/*      */     extends Thread
/*      */   {
/*  383 */     private final BlockingQueue<PlayerEvent> eventQueue = new LinkedBlockingQueue<>();
/*      */     
/*      */     private volatile boolean stopped = false;
/*      */     
/*      */     EventQueueThread() {
/*  388 */       setName("JFXMedia Player EventQueueThread");
/*  389 */       setDaemon(true);
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*  394 */       while (!this.stopped) {
/*      */ 
/*      */         
/*      */         try {
/*  398 */           PlayerEvent playerEvent = this.eventQueue.take();
/*      */           
/*  400 */           if (!this.stopped) {
/*  401 */             if (playerEvent instanceof NewFrameEvent) {
/*      */               try {
/*  403 */                 HandleRendererEvents((NewFrameEvent)playerEvent);
/*  404 */               } catch (Throwable throwable) {
/*  405 */                 if (Logger.canLog(4))
/*  406 */                   Logger.logMsg(4, "Caught exception in HandleRendererEvents: " + throwable.toString()); 
/*      */               }  continue;
/*      */             } 
/*  409 */             if (playerEvent instanceof PlayerStateEvent) {
/*  410 */               HandleStateEvents((PlayerStateEvent)playerEvent); continue;
/*  411 */             }  if (playerEvent instanceof NativeMediaPlayer.FrameSizeChangedEvent) {
/*  412 */               HandleFrameSizeChangedEvents((NativeMediaPlayer.FrameSizeChangedEvent)playerEvent); continue;
/*  413 */             }  if (playerEvent instanceof NativeMediaPlayer.TrackEvent) {
/*  414 */               HandleTrackEvents((NativeMediaPlayer.TrackEvent)playerEvent); continue;
/*  415 */             }  if (playerEvent instanceof MarkerEvent) {
/*  416 */               HandleMarkerEvents((MarkerEvent)playerEvent); continue;
/*  417 */             }  if (playerEvent instanceof NativeMediaPlayer.WarningEvent) {
/*  418 */               HandleWarningEvents((NativeMediaPlayer.WarningEvent)playerEvent); continue;
/*  419 */             }  if (playerEvent instanceof NativeMediaPlayer.PlayerTimeEvent) {
/*  420 */               HandlePlayerTimeEvents((NativeMediaPlayer.PlayerTimeEvent)playerEvent); continue;
/*  421 */             }  if (playerEvent instanceof BufferProgressEvent) {
/*  422 */               HandleBufferEvents((BufferProgressEvent)playerEvent); continue;
/*  423 */             }  if (playerEvent instanceof AudioSpectrumEvent) {
/*  424 */               HandleAudioSpectrumEvents((AudioSpectrumEvent)playerEvent); continue;
/*  425 */             }  if (playerEvent instanceof NativeMediaPlayer.MediaErrorEvent) {
/*  426 */               HandleErrorEvents((NativeMediaPlayer.MediaErrorEvent)playerEvent);
/*      */             }
/*      */           } 
/*  429 */         } catch (Exception exception) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  438 */       this.eventQueue.clear();
/*      */     }
/*      */     
/*      */     private void HandleRendererEvents(NewFrameEvent param1NewFrameEvent) {
/*  442 */       if (NativeMediaPlayer.this.isFirstFrame) {
/*      */ 
/*      */         
/*  445 */         NativeMediaPlayer.this.isFirstFrame = false;
/*  446 */         synchronized (NativeMediaPlayer.this.firstFrameLock) {
/*  447 */           NativeMediaPlayer.this.firstFrameEvent = param1NewFrameEvent;
/*  448 */           NativeMediaPlayer.this.firstFrameTime = NativeMediaPlayer.this.firstFrameEvent.getFrameData().getTimestamp();
/*  449 */           NativeMediaPlayer.this.firstFrameEvent.getFrameData().holdFrame();
/*      */         } 
/*  451 */       } else if (NativeMediaPlayer.this.firstFrameEvent != null && NativeMediaPlayer.this
/*  452 */         .firstFrameTime != param1NewFrameEvent.getFrameData().getTimestamp()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  461 */         synchronized (NativeMediaPlayer.this.firstFrameLock) {
/*  462 */           NativeMediaPlayer.this.firstFrameEvent.getFrameData().releaseFrame();
/*  463 */           NativeMediaPlayer.this.firstFrameEvent = null;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  468 */       for (ListIterator<WeakReference<VideoRendererListener>> listIterator = NativeMediaPlayer.this.videoUpdateListeners.listIterator(); listIterator.hasNext(); ) {
/*  469 */         VideoRendererListener videoRendererListener = ((WeakReference<VideoRendererListener>)listIterator.next()).get();
/*  470 */         if (videoRendererListener != null) {
/*  471 */           videoRendererListener.videoFrameUpdated(param1NewFrameEvent); continue;
/*      */         } 
/*  473 */         listIterator.remove();
/*      */       } 
/*      */ 
/*      */       
/*  477 */       param1NewFrameEvent.getFrameData().releaseFrame();
/*      */       
/*  479 */       if (!NativeMediaPlayer.this.videoFrameRateListeners.isEmpty()) {
/*      */         
/*  481 */         double d = System.nanoTime() / 1.0E9D;
/*      */         
/*  483 */         if (NativeMediaPlayer.this.recomputeFrameRate) {
/*      */           
/*  485 */           NativeMediaPlayer.this.recomputeFrameRate = false;
/*  486 */           NativeMediaPlayer.this.previousFrameTime = d;
/*  487 */           NativeMediaPlayer.this.numFramesSincePlaying = 1L;
/*      */         } else {
/*  489 */           boolean bool = false;
/*      */           
/*  491 */           if (NativeMediaPlayer.this.numFramesSincePlaying == 1L) {
/*      */ 
/*      */             
/*  494 */             NativeMediaPlayer.this.meanFrameDuration = d - NativeMediaPlayer.this.previousFrameTime;
/*  495 */             if (NativeMediaPlayer.this.meanFrameDuration > 0.0D) {
/*  496 */               NativeMediaPlayer.this.decodedFrameRate = 1.0D / NativeMediaPlayer.this.meanFrameDuration;
/*  497 */               bool = true;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  502 */             double d1 = NativeMediaPlayer.this.meanFrameDuration;
/*      */ 
/*      */ 
/*      */             
/*  506 */             boolean bool1 = (NativeMediaPlayer.this.encodedFrameRate != 0.0D) ? (int)(NativeMediaPlayer.this.encodedFrameRate + 0.5D) : true;
/*      */ 
/*      */ 
/*      */             
/*  510 */             long l = (NativeMediaPlayer.this.numFramesSincePlaying < bool1) ? NativeMediaPlayer.this.numFramesSincePlaying : bool1;
/*      */ 
/*      */             
/*  513 */             NativeMediaPlayer.this.meanFrameDuration = ((l - 1L) * d1 + d - NativeMediaPlayer.this
/*  514 */               .previousFrameTime) / l;
/*      */ 
/*      */ 
/*      */             
/*  518 */             if (NativeMediaPlayer.this.meanFrameDuration > 0.0D && 
/*  519 */               Math.abs(NativeMediaPlayer.this.decodedFrameRate - 1.0D / NativeMediaPlayer.this.meanFrameDuration) > 0.5D) {
/*  520 */               NativeMediaPlayer.this.decodedFrameRate = 1.0D / NativeMediaPlayer.this.meanFrameDuration;
/*  521 */               bool = true;
/*      */             } 
/*      */           } 
/*      */           
/*  525 */           if (bool)
/*      */           {
/*  527 */             for (ListIterator<WeakReference<VideoFrameRateListener>> listIterator1 = NativeMediaPlayer.this.videoFrameRateListeners.listIterator(); listIterator1.hasNext(); ) {
/*  528 */               VideoFrameRateListener videoFrameRateListener = ((WeakReference<VideoFrameRateListener>)listIterator1.next()).get();
/*  529 */               if (videoFrameRateListener != null) {
/*  530 */                 videoFrameRateListener.onFrameRateChanged(NativeMediaPlayer.this.decodedFrameRate); continue;
/*      */               } 
/*  532 */               listIterator1.remove();
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  538 */           NativeMediaPlayer.this.previousFrameTime = d;
/*  539 */           NativeMediaPlayer.this.numFramesSincePlaying++;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void HandleStateEvents(PlayerStateEvent param1PlayerStateEvent) {
/*  545 */       NativeMediaPlayer.this.playerState = param1PlayerStateEvent.getState();
/*      */       
/*  547 */       NativeMediaPlayer.this.recomputeFrameRate = (PlayerStateEvent.PlayerState.PLAYING == param1PlayerStateEvent.getState());
/*      */       
/*  549 */       switch (NativeMediaPlayer.this.playerState) {
/*      */         case READY:
/*  551 */           NativeMediaPlayer.this.onNativeInit();
/*  552 */           sendFakeBufferProgressEvent();
/*      */           break;
/*      */         case PLAYING:
/*  555 */           NativeMediaPlayer.this.isMediaPulseEnabled.set(true);
/*      */           break;
/*      */ 
/*      */         
/*      */         case STOPPED:
/*      */         case FINISHED:
/*  561 */           NativeMediaPlayer.this.doMediaPulseTask();
/*      */         case PAUSED:
/*      */         case STALLED:
/*      */         case HALTED:
/*  565 */           NativeMediaPlayer.this.isMediaPulseEnabled.set(false);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  571 */       synchronized (NativeMediaPlayer.this.cachedStateEvents) {
/*  572 */         if (NativeMediaPlayer.this.playerStateListeners.isEmpty()) {
/*      */           
/*  574 */           NativeMediaPlayer.this.cachedStateEvents.add(param1PlayerStateEvent);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  579 */       for (ListIterator<WeakReference<PlayerStateListener>> listIterator = NativeMediaPlayer.this.playerStateListeners.listIterator(); listIterator.hasNext(); ) {
/*  580 */         PlayerStateListener playerStateListener = ((WeakReference<PlayerStateListener>)listIterator.next()).get();
/*  581 */         if (playerStateListener != null) {
/*  582 */           switch (NativeMediaPlayer.this.playerState) {
/*      */             case READY:
/*  584 */               NativeMediaPlayer.this.onNativeInit();
/*  585 */               sendFakeBufferProgressEvent();
/*  586 */               playerStateListener.onReady(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case PLAYING:
/*  590 */               playerStateListener.onPlaying(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case PAUSED:
/*  594 */               playerStateListener.onPause(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case STOPPED:
/*  598 */               playerStateListener.onStop(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case STALLED:
/*  602 */               playerStateListener.onStall(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case FINISHED:
/*  606 */               playerStateListener.onFinish(param1PlayerStateEvent);
/*      */               continue;
/*      */             
/*      */             case HALTED:
/*  610 */               playerStateListener.onHalt(param1PlayerStateEvent);
/*      */               continue;
/*      */           } 
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*  617 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandlePlayerTimeEvents(NativeMediaPlayer.PlayerTimeEvent param1PlayerTimeEvent) {
/*  623 */       synchronized (NativeMediaPlayer.this.cachedTimeEvents) {
/*  624 */         if (NativeMediaPlayer.this.playerTimeListeners.isEmpty()) {
/*      */           
/*  626 */           NativeMediaPlayer.this.cachedTimeEvents.add(param1PlayerTimeEvent);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  631 */       for (ListIterator<WeakReference<PlayerTimeListener>> listIterator = NativeMediaPlayer.this.playerTimeListeners.listIterator(); listIterator.hasNext(); ) {
/*  632 */         PlayerTimeListener playerTimeListener = ((WeakReference<PlayerTimeListener>)listIterator.next()).get();
/*  633 */         if (playerTimeListener != null) {
/*  634 */           playerTimeListener.onDurationChanged(param1PlayerTimeEvent.getTime()); continue;
/*      */         } 
/*  636 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandleFrameSizeChangedEvents(NativeMediaPlayer.FrameSizeChangedEvent param1FrameSizeChangedEvent) {
/*  642 */       NativeMediaPlayer.this.frameWidth = param1FrameSizeChangedEvent.getWidth();
/*  643 */       NativeMediaPlayer.this.frameHeight = param1FrameSizeChangedEvent.getHeight();
/*  644 */       Logger.logMsg(1, "** Frame size changed (" + NativeMediaPlayer.this.frameWidth + ", " + NativeMediaPlayer.this.frameHeight + ")");
/*  645 */       for (ListIterator<WeakReference<VideoTrackSizeListener>> listIterator = NativeMediaPlayer.this.videoTrackSizeListeners.listIterator(); listIterator.hasNext(); ) {
/*  646 */         VideoTrackSizeListener videoTrackSizeListener = ((WeakReference<VideoTrackSizeListener>)listIterator.next()).get();
/*  647 */         if (videoTrackSizeListener != null) {
/*  648 */           videoTrackSizeListener.onSizeChanged(NativeMediaPlayer.this.frameWidth, NativeMediaPlayer.this.frameHeight); continue;
/*      */         } 
/*  650 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandleTrackEvents(NativeMediaPlayer.TrackEvent param1TrackEvent) {
/*  656 */       NativeMediaPlayer.this.media.addTrack(param1TrackEvent.getTrack());
/*      */       
/*  658 */       if (param1TrackEvent.getTrack() instanceof VideoTrack) {
/*  659 */         NativeMediaPlayer.this.encodedFrameRate = ((VideoTrack)param1TrackEvent.getTrack()).getEncodedFrameRate();
/*      */       }
/*      */     }
/*      */     
/*      */     private void HandleMarkerEvents(MarkerEvent param1MarkerEvent) {
/*  664 */       for (ListIterator<WeakReference<MarkerListener>> listIterator = NativeMediaPlayer.this.markerListeners.listIterator(); listIterator.hasNext(); ) {
/*  665 */         MarkerListener markerListener = ((WeakReference<MarkerListener>)listIterator.next()).get();
/*  666 */         if (markerListener != null) {
/*  667 */           markerListener.onMarker(param1MarkerEvent); continue;
/*      */         } 
/*  669 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandleWarningEvents(NativeMediaPlayer.WarningEvent param1WarningEvent) {
/*  675 */       Logger.logMsg(3, "" + param1WarningEvent.getSource() + param1WarningEvent.getSource());
/*      */     }
/*      */     
/*      */     private void HandleErrorEvents(NativeMediaPlayer.MediaErrorEvent param1MediaErrorEvent) {
/*  679 */       Logger.logMsg(4, param1MediaErrorEvent.getMessage());
/*      */       
/*  681 */       synchronized (NativeMediaPlayer.this.cachedErrorEvents) {
/*  682 */         if (NativeMediaPlayer.this.errorListeners.isEmpty()) {
/*      */           
/*  684 */           NativeMediaPlayer.this.cachedErrorEvents.add(param1MediaErrorEvent);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  689 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = NativeMediaPlayer.this.errorListeners.listIterator(); listIterator.hasNext(); ) {
/*  690 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/*  691 */         if (mediaErrorListener != null) {
/*  692 */           mediaErrorListener.onError(param1MediaErrorEvent.getSource(), param1MediaErrorEvent.getErrorCode(), param1MediaErrorEvent.getMessage()); continue;
/*      */         } 
/*  694 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandleBufferEvents(BufferProgressEvent param1BufferProgressEvent) {
/*  700 */       synchronized (NativeMediaPlayer.this.cachedBufferEvents) {
/*  701 */         if (NativeMediaPlayer.this.bufferListeners.isEmpty()) {
/*      */           
/*  703 */           NativeMediaPlayer.this.cachedBufferEvents.add(param1BufferProgressEvent);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  708 */       for (ListIterator<WeakReference<BufferListener>> listIterator = NativeMediaPlayer.this.bufferListeners.listIterator(); listIterator.hasNext(); ) {
/*  709 */         BufferListener bufferListener = ((WeakReference<BufferListener>)listIterator.next()).get();
/*  710 */         if (bufferListener != null) {
/*  711 */           bufferListener.onBufferProgress(param1BufferProgressEvent); continue;
/*      */         } 
/*  713 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void HandleAudioSpectrumEvents(AudioSpectrumEvent param1AudioSpectrumEvent) {
/*  719 */       for (ListIterator<WeakReference<AudioSpectrumListener>> listIterator = NativeMediaPlayer.this.audioSpectrumListeners.listIterator(); listIterator.hasNext(); ) {
/*  720 */         AudioSpectrumListener audioSpectrumListener = ((WeakReference<AudioSpectrumListener>)listIterator.next()).get();
/*  721 */         if (audioSpectrumListener != null) {
/*  722 */           audioSpectrumListener.onAudioSpectrumEvent(param1AudioSpectrumEvent); continue;
/*      */         } 
/*  724 */         listIterator.remove();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void postEvent(PlayerEvent param1PlayerEvent) {
/*  733 */       if (this.eventQueue != null) {
/*  734 */         this.eventQueue.offer(param1PlayerEvent);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void terminateLoop() {
/*  742 */       this.stopped = true;
/*      */       
/*      */       try {
/*  745 */         this.eventQueue.put(new PlayerEvent());
/*  746 */       } catch (InterruptedException interruptedException) {}
/*      */     }
/*      */ 
/*      */     
/*      */     private void sendFakeBufferProgressEvent() {
/*  751 */       String str1 = NativeMediaPlayer.this.media.getLocator().getContentType();
/*  752 */       String str2 = NativeMediaPlayer.this.media.getLocator().getProtocol();
/*  753 */       if ((str1 != null && (str1.equals("audio/mpegurl") || str1.equals("application/vnd.apple.mpegurl"))) || (str2 != null && 
/*  754 */         !str2.equals("http") && !str2.equals("https"))) {
/*  755 */         HandleBufferEvents(new BufferProgressEvent(NativeMediaPlayer.this.getDuration(), 0L, 1L, 1L));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void onNativeInit() {
/*      */     try {
/*  765 */       playerInit();
/*  766 */     } catch (MediaException mediaException) {
/*  767 */       sendPlayerMediaErrorEvent(mediaException.getMediaError().code());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/*  777 */     if (paramMediaErrorListener != null) {
/*  778 */       this.errorListeners.add(new WeakReference<>(paramMediaErrorListener));
/*      */       
/*  780 */       synchronized (this.cachedErrorEvents) {
/*  781 */         if (!this.cachedErrorEvents.isEmpty() && !this.errorListeners.isEmpty()) {
/*  782 */           this.cachedErrorEvents.stream().forEach(paramMediaErrorEvent -> sendPlayerEvent(paramMediaErrorEvent));
/*      */ 
/*      */           
/*  785 */           this.cachedErrorEvents.clear();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeMediaErrorListener(MediaErrorListener paramMediaErrorListener) {
/*  793 */     if (paramMediaErrorListener != null) {
/*  794 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = this.errorListeners.listIterator(); listIterator.hasNext(); ) {
/*  795 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/*  796 */         if (mediaErrorListener == null || mediaErrorListener == paramMediaErrorListener) {
/*  797 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addMediaPlayerListener(PlayerStateListener paramPlayerStateListener) {
/*  805 */     if (paramPlayerStateListener != null) {
/*  806 */       synchronized (this.cachedStateEvents) {
/*  807 */         if (!this.cachedStateEvents.isEmpty() && this.playerStateListeners.isEmpty()) {
/*      */           
/*  809 */           Iterator<PlayerStateEvent> iterator = this.cachedStateEvents.iterator();
/*  810 */           while (iterator.hasNext()) {
/*  811 */             PlayerStateEvent playerStateEvent = iterator.next();
/*  812 */             switch (playerStateEvent.getState()) {
/*      */               case READY:
/*  814 */                 paramPlayerStateListener.onReady(playerStateEvent);
/*      */               
/*      */               case PLAYING:
/*  817 */                 paramPlayerStateListener.onPlaying(playerStateEvent);
/*      */               
/*      */               case PAUSED:
/*  820 */                 paramPlayerStateListener.onPause(playerStateEvent);
/*      */               
/*      */               case STOPPED:
/*  823 */                 paramPlayerStateListener.onStop(playerStateEvent);
/*      */               
/*      */               case STALLED:
/*  826 */                 paramPlayerStateListener.onStall(playerStateEvent);
/*      */               
/*      */               case FINISHED:
/*  829 */                 paramPlayerStateListener.onFinish(playerStateEvent);
/*      */               
/*      */               case HALTED:
/*  832 */                 paramPlayerStateListener.onHalt(playerStateEvent);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           } 
/*  840 */           this.cachedStateEvents.clear();
/*      */         } 
/*      */         
/*  843 */         this.playerStateListeners.add(new WeakReference<>(paramPlayerStateListener));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeMediaPlayerListener(PlayerStateListener paramPlayerStateListener) {
/*  850 */     if (paramPlayerStateListener != null) {
/*  851 */       for (ListIterator<WeakReference<PlayerStateListener>> listIterator = this.playerStateListeners.listIterator(); listIterator.hasNext(); ) {
/*  852 */         PlayerStateListener playerStateListener = ((WeakReference<PlayerStateListener>)listIterator.next()).get();
/*  853 */         if (playerStateListener == null || playerStateListener == paramPlayerStateListener) {
/*  854 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addMediaTimeListener(PlayerTimeListener paramPlayerTimeListener) {
/*  862 */     if (paramPlayerTimeListener != null) {
/*  863 */       synchronized (this.cachedTimeEvents) {
/*  864 */         if (!this.cachedTimeEvents.isEmpty() && this.playerTimeListeners.isEmpty()) {
/*      */           
/*  866 */           Iterator<PlayerTimeEvent> iterator = this.cachedTimeEvents.iterator();
/*  867 */           while (iterator.hasNext()) {
/*  868 */             PlayerTimeEvent playerTimeEvent = iterator.next();
/*  869 */             paramPlayerTimeListener.onDurationChanged(playerTimeEvent.getTime());
/*      */           } 
/*      */ 
/*      */           
/*  873 */           this.cachedTimeEvents.clear();
/*      */         } else {
/*      */           
/*  876 */           double d = getDuration();
/*  877 */           if (d != Double.POSITIVE_INFINITY) {
/*  878 */             paramPlayerTimeListener.onDurationChanged(d);
/*      */           }
/*      */         } 
/*      */         
/*  882 */         this.playerTimeListeners.add(new WeakReference<>(paramPlayerTimeListener));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeMediaTimeListener(PlayerTimeListener paramPlayerTimeListener) {
/*  889 */     if (paramPlayerTimeListener != null) {
/*  890 */       for (ListIterator<WeakReference<PlayerTimeListener>> listIterator = this.playerTimeListeners.listIterator(); listIterator.hasNext(); ) {
/*  891 */         PlayerTimeListener playerTimeListener = ((WeakReference<PlayerTimeListener>)listIterator.next()).get();
/*  892 */         if (playerTimeListener == null || playerTimeListener == paramPlayerTimeListener) {
/*  893 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addVideoTrackSizeListener(VideoTrackSizeListener paramVideoTrackSizeListener) {
/*  901 */     if (paramVideoTrackSizeListener != null) {
/*  902 */       if (this.frameWidth != -1 && this.frameHeight != -1) {
/*  903 */         paramVideoTrackSizeListener.onSizeChanged(this.frameWidth, this.frameHeight);
/*      */       }
/*  905 */       this.videoTrackSizeListeners.add(new WeakReference<>(paramVideoTrackSizeListener));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeVideoTrackSizeListener(VideoTrackSizeListener paramVideoTrackSizeListener) {
/*  911 */     if (paramVideoTrackSizeListener != null) {
/*  912 */       for (ListIterator<WeakReference<VideoTrackSizeListener>> listIterator = this.videoTrackSizeListeners.listIterator(); listIterator.hasNext(); ) {
/*  913 */         VideoTrackSizeListener videoTrackSizeListener = ((WeakReference<VideoTrackSizeListener>)listIterator.next()).get();
/*  914 */         if (videoTrackSizeListener == null || videoTrackSizeListener == paramVideoTrackSizeListener) {
/*  915 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addMarkerListener(MarkerListener paramMarkerListener) {
/*  923 */     if (paramMarkerListener != null) {
/*  924 */       this.markerListeners.add(new WeakReference<>(paramMarkerListener));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeMarkerListener(MarkerListener paramMarkerListener) {
/*  930 */     if (paramMarkerListener != null) {
/*  931 */       for (ListIterator<WeakReference<MarkerListener>> listIterator = this.markerListeners.listIterator(); listIterator.hasNext(); ) {
/*  932 */         MarkerListener markerListener = ((WeakReference<MarkerListener>)listIterator.next()).get();
/*  933 */         if (markerListener == null || markerListener == paramMarkerListener) {
/*  934 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBufferListener(BufferListener paramBufferListener) {
/*  942 */     if (paramBufferListener != null) {
/*  943 */       synchronized (this.cachedBufferEvents) {
/*  944 */         if (!this.cachedBufferEvents.isEmpty() && this.bufferListeners.isEmpty()) {
/*  945 */           this.cachedBufferEvents.stream().forEach(paramBufferProgressEvent -> paramBufferListener.onBufferProgress(paramBufferProgressEvent));
/*      */ 
/*      */ 
/*      */           
/*  949 */           this.cachedBufferEvents.clear();
/*      */         } 
/*      */         
/*  952 */         this.bufferListeners.add(new WeakReference<>(paramBufferListener));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeBufferListener(BufferListener paramBufferListener) {
/*  959 */     if (paramBufferListener != null) {
/*  960 */       for (ListIterator<WeakReference<BufferListener>> listIterator = this.bufferListeners.listIterator(); listIterator.hasNext(); ) {
/*  961 */         BufferListener bufferListener = ((WeakReference<BufferListener>)listIterator.next()).get();
/*  962 */         if (bufferListener == null || bufferListener == paramBufferListener) {
/*  963 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAudioSpectrumListener(AudioSpectrumListener paramAudioSpectrumListener) {
/*  971 */     if (paramAudioSpectrumListener != null) {
/*  972 */       this.audioSpectrumListeners.add(new WeakReference<>(paramAudioSpectrumListener));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeAudioSpectrumListener(AudioSpectrumListener paramAudioSpectrumListener) {
/*  978 */     if (paramAudioSpectrumListener != null) {
/*  979 */       for (ListIterator<WeakReference<AudioSpectrumListener>> listIterator = this.audioSpectrumListeners.listIterator(); listIterator.hasNext(); ) {
/*  980 */         AudioSpectrumListener audioSpectrumListener = ((WeakReference<AudioSpectrumListener>)listIterator.next()).get();
/*  981 */         if (audioSpectrumListener == null || audioSpectrumListener == paramAudioSpectrumListener) {
/*  982 */           listIterator.remove();
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public VideoRenderControl getVideoRenderControl() {
/*  991 */     return this.videoRenderControl;
/*      */   }
/*      */ 
/*      */   
/*      */   public Media getMedia() {
/*  996 */     return this.media;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAudioSyncDelay(long paramLong) {
/*      */     try {
/* 1002 */       playerSetAudioSyncDelay(paramLong);
/* 1003 */     } catch (MediaException mediaException) {
/* 1004 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long getAudioSyncDelay() {
/*      */     try {
/* 1011 */       return playerGetAudioSyncDelay();
/* 1012 */     } catch (MediaException mediaException) {
/* 1013 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */       
/* 1015 */       return 0L;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void play() {
/*      */     try {
/* 1021 */       if (this.isStartTimeUpdated) {
/* 1022 */         playerSeek(this.startTime);
/*      */       }
/* 1024 */       this.isMediaPulseEnabled.set(true);
/* 1025 */       playerPlay();
/* 1026 */     } catch (MediaException mediaException) {
/* 1027 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void stop() {
/*      */     try {
/* 1034 */       playerStop();
/* 1035 */       playerSeek(this.startTime);
/* 1036 */     } catch (MediaException mediaException) {
/*      */       
/* 1038 */       MediaUtils.warning(this, "stop() failed!");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void pause() {
/*      */     try {
/* 1045 */       playerPause();
/* 1046 */     } catch (MediaException mediaException) {
/* 1047 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public float getRate() {
/*      */     try {
/* 1054 */       return playerGetRate();
/* 1055 */     } catch (MediaException mediaException) {
/* 1056 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */       
/* 1058 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRate(float paramFloat) {
/*      */     try {
/* 1065 */       playerSetRate(paramFloat);
/* 1066 */     } catch (MediaException mediaException) {
/*      */       
/* 1068 */       MediaUtils.warning(this, "setRate(" + paramFloat + ") failed!");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public double getPresentationTime() {
/*      */     try {
/* 1075 */       return playerGetPresentationTime();
/* 1076 */     } catch (MediaException mediaException) {
/*      */ 
/*      */       
/* 1079 */       return -1.0D;
/*      */     } 
/*      */   }
/*      */   
/*      */   public float getVolume() {
/*      */     try {
/* 1085 */       return playerGetVolume();
/* 1086 */     } catch (MediaException mediaException) {
/* 1087 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */       
/* 1089 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setVolume(float paramFloat) {
/* 1094 */     if (paramFloat < 0.0F) {
/* 1095 */       paramFloat = 0.0F;
/* 1096 */     } else if (paramFloat > 1.0F) {
/* 1097 */       paramFloat = 1.0F;
/*      */     } 
/*      */     
/*      */     try {
/* 1101 */       playerSetVolume(paramFloat);
/* 1102 */     } catch (MediaException mediaException) {
/* 1103 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getMute() {
/*      */     try {
/* 1110 */       return playerGetMute();
/* 1111 */     } catch (MediaException mediaException) {
/* 1112 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */       
/* 1114 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMute(boolean paramBoolean) {
/*      */     try {
/* 1124 */       playerSetMute(paramBoolean);
/* 1125 */     } catch (MediaException mediaException) {
/* 1126 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public float getBalance() {
/*      */     try {
/* 1133 */       return playerGetBalance();
/* 1134 */     } catch (MediaException mediaException) {
/* 1135 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */       
/* 1137 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setBalance(float paramFloat) {
/* 1142 */     if (paramFloat < -1.0F) {
/* 1143 */       paramFloat = -1.0F;
/* 1144 */     } else if (paramFloat > 1.0F) {
/* 1145 */       paramFloat = 1.0F;
/*      */     } 
/*      */     
/*      */     try {
/* 1149 */       playerSetBalance(paramFloat);
/* 1150 */     } catch (MediaException mediaException) {
/* 1151 */       sendPlayerEvent(new MediaErrorEvent(this, mediaException.getMediaError()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDuration() {
/*      */     try {
/* 1164 */       return playerGetDuration();
/* 1165 */     } catch (MediaException mediaException) {
/*      */ 
/*      */       
/* 1168 */       return Double.POSITIVE_INFINITY;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getStartTime() {
/* 1176 */     return this.startTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStartTime(double paramDouble) {
/*      */     try {
/* 1185 */       this.markerLock.lock();
/* 1186 */       this.startTime = paramDouble;
/* 1187 */       if (this.playerState != PlayerStateEvent.PlayerState.PLAYING && this.playerState != PlayerStateEvent.PlayerState.FINISHED && this.playerState != PlayerStateEvent.PlayerState.STOPPED) {
/* 1188 */         playerSeek(paramDouble);
/* 1189 */       } else if (this.playerState == PlayerStateEvent.PlayerState.STOPPED) {
/* 1190 */         this.isStartTimeUpdated = true;
/*      */       } 
/*      */     } finally {
/* 1193 */       this.markerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getStopTime() {
/* 1202 */     return this.stopTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStopTime(double paramDouble) {
/*      */     try {
/* 1211 */       this.markerLock.lock();
/* 1212 */       this.stopTime = paramDouble;
/* 1213 */       this.isStopTimeSet = true;
/* 1214 */       createMediaPulse();
/*      */     } finally {
/* 1216 */       this.markerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void seek(double paramDouble) {
/* 1222 */     if (this.playerState == PlayerStateEvent.PlayerState.STOPPED) {
/*      */       return;
/*      */     }
/*      */     
/* 1226 */     if (paramDouble < 0.0D) {
/* 1227 */       paramDouble = 0.0D;
/*      */     } else {
/* 1229 */       double d = getDuration();
/* 1230 */       if (d >= 0.0D && paramDouble > d) {
/* 1231 */         paramDouble = d;
/*      */       }
/*      */     } 
/*      */     
/* 1235 */     if (!this.isMediaPulseEnabled.get() && (
/* 1236 */       this.playerState == PlayerStateEvent.PlayerState.PLAYING || this.playerState == PlayerStateEvent.PlayerState.PAUSED || this.playerState == PlayerStateEvent.PlayerState.FINISHED) && 
/*      */ 
/*      */       
/* 1239 */       getStartTime() <= paramDouble && paramDouble <= getStopTime()) {
/* 1240 */       this.isMediaPulseEnabled.set(true);
/*      */     }
/*      */ 
/*      */     
/* 1244 */     this.markerLock.lock();
/*      */     try {
/* 1246 */       this.timeBeforeSeek = getPresentationTime();
/* 1247 */       this.timeAfterSeek = paramDouble;
/* 1248 */       this.checkSeek = (this.timeBeforeSeek != this.timeAfterSeek);
/* 1249 */       this.previousTime = paramDouble;
/* 1250 */       this.firedMarkerTime = -1.0D;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1255 */         playerSeek(paramDouble);
/* 1256 */       } catch (MediaException mediaException) {
/*      */         
/* 1258 */         MediaUtils.warning(this, "seek(" + paramDouble + ") failed!");
/*      */       } 
/*      */     } finally {
/* 1261 */       this.markerLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PlayerStateEvent.PlayerState getState() {
/* 1310 */     return this.playerState;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void dispose() {
/* 1315 */     this.disposeLock.lock();
/*      */     try {
/* 1317 */       if (!this.isDisposed) {
/*      */         
/* 1319 */         destroyMediaPulse();
/*      */         
/* 1321 */         if (this.eventLoop != null) {
/* 1322 */           this.eventLoop.terminateLoop();
/* 1323 */           this.eventLoop = null;
/*      */         } 
/*      */         
/* 1326 */         synchronized (this.firstFrameLock) {
/* 1327 */           if (this.firstFrameEvent != null) {
/* 1328 */             this.firstFrameEvent.getFrameData().releaseFrame();
/* 1329 */             this.firstFrameEvent = null;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1334 */         playerDispose();
/*      */ 
/*      */         
/* 1337 */         if (this.media != null) {
/* 1338 */           this.media.dispose();
/* 1339 */           this.media = null;
/*      */         } 
/*      */         
/* 1342 */         if (this.videoUpdateListeners != null) {
/* 1343 */           for (ListIterator<WeakReference<VideoRendererListener>> listIterator = this.videoUpdateListeners.listIterator(); listIterator.hasNext(); ) {
/* 1344 */             VideoRendererListener videoRendererListener = ((WeakReference<VideoRendererListener>)listIterator.next()).get();
/* 1345 */             if (videoRendererListener != null) {
/* 1346 */               videoRendererListener.releaseVideoFrames(); continue;
/*      */             } 
/* 1348 */             listIterator.remove();
/*      */           } 
/*      */ 
/*      */           
/* 1352 */           this.videoUpdateListeners.clear();
/*      */         } 
/*      */         
/* 1355 */         if (this.playerStateListeners != null) {
/* 1356 */           this.playerStateListeners.clear();
/*      */         }
/*      */         
/* 1359 */         if (this.videoTrackSizeListeners != null) {
/* 1360 */           this.videoTrackSizeListeners.clear();
/*      */         }
/*      */         
/* 1363 */         if (this.videoFrameRateListeners != null) {
/* 1364 */           this.videoFrameRateListeners.clear();
/*      */         }
/*      */         
/* 1367 */         if (this.cachedStateEvents != null) {
/* 1368 */           this.cachedStateEvents.clear();
/*      */         }
/*      */         
/* 1371 */         if (this.cachedTimeEvents != null) {
/* 1372 */           this.cachedTimeEvents.clear();
/*      */         }
/*      */         
/* 1375 */         if (this.cachedBufferEvents != null) {
/* 1376 */           this.cachedBufferEvents.clear();
/*      */         }
/*      */         
/* 1379 */         if (this.errorListeners != null) {
/* 1380 */           this.errorListeners.clear();
/*      */         }
/*      */         
/* 1383 */         if (this.playerTimeListeners != null) {
/* 1384 */           this.playerTimeListeners.clear();
/*      */         }
/*      */         
/* 1387 */         if (this.markerListeners != null) {
/* 1388 */           this.markerListeners.clear();
/*      */         }
/*      */         
/* 1391 */         if (this.bufferListeners != null) {
/* 1392 */           this.bufferListeners.clear();
/*      */         }
/*      */         
/* 1395 */         if (this.audioSpectrumListeners != null) {
/* 1396 */           this.audioSpectrumListeners.clear();
/*      */         }
/*      */         
/* 1399 */         if (this.videoRenderControl != null) {
/* 1400 */           this.videoRenderControl = null;
/*      */         }
/*      */         
/* 1403 */         if (this.onDispose != null) {
/* 1404 */           this.onDispose.run();
/*      */         }
/*      */         
/* 1407 */         this.isDisposed = true;
/*      */       } 
/*      */     } finally {
/* 1410 */       this.disposeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendWarning(int paramInt, String paramString) {
/* 1422 */     if (this.eventLoop != null) {
/* 1423 */       String str = String.format("Internal media warning: %d", new Object[] {
/* 1424 */             Integer.valueOf(paramInt) });
/* 1425 */       if (paramString != null) {
/* 1426 */         str = str + ": " + str;
/*      */       }
/* 1428 */       this.eventLoop.postEvent(new WarningEvent(this, str));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void sendPlayerEvent(PlayerEvent paramPlayerEvent) {
/* 1433 */     if (this.eventLoop != null) {
/* 1434 */       this.eventLoop.postEvent(paramPlayerEvent);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendPlayerHaltEvent(String paramString, double paramDouble) {
/* 1441 */     Logger.logMsg(4, paramString);
/*      */     
/* 1443 */     if (this.eventLoop != null) {
/* 1444 */       this.eventLoop.postEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.HALTED, paramDouble, paramString));
/*      */     }
/*      */   }
/*      */   
/*      */   protected void sendPlayerMediaErrorEvent(int paramInt) {
/* 1449 */     sendPlayerEvent(new MediaErrorEvent(this, MediaError.getFromCode(paramInt)));
/*      */   }
/*      */   
/*      */   protected void sendPlayerStateEvent(int paramInt, double paramDouble) {
/* 1453 */     switch (paramInt) {
/*      */       case 101:
/* 1455 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.READY, paramDouble));
/*      */         break;
/*      */       case 102:
/* 1458 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.PLAYING, paramDouble));
/*      */         break;
/*      */       case 103:
/* 1461 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.PAUSED, paramDouble));
/*      */         break;
/*      */       case 104:
/* 1464 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.STOPPED, paramDouble));
/*      */         break;
/*      */       case 105:
/* 1467 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.STALLED, paramDouble));
/*      */         break;
/*      */       case 106:
/* 1470 */         sendPlayerEvent(new PlayerStateEvent(PlayerStateEvent.PlayerState.FINISHED, paramDouble));
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendNewFrameEvent(long paramLong) {
/* 1478 */     NativeVideoBuffer nativeVideoBuffer = NativeVideoBuffer.createVideoBuffer(paramLong);
/*      */ 
/*      */     
/* 1481 */     sendPlayerEvent(new NewFrameEvent(nativeVideoBuffer));
/*      */   }
/*      */   
/*      */   protected void sendFrameSizeChangedEvent(int paramInt1, int paramInt2) {
/* 1485 */     sendPlayerEvent(new FrameSizeChangedEvent(paramInt1, paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendAudioTrack(boolean paramBoolean, long paramLong, String paramString1, int paramInt1, String paramString2, int paramInt2, int paramInt3, float paramFloat) {
/* 1491 */     Locale locale = null;
/* 1492 */     if (!paramString2.equals("und")) {
/* 1493 */       locale = new Locale(paramString2);
/*      */     }
/*      */ 
/*      */     
/* 1497 */     AudioTrack audioTrack = new AudioTrack(paramBoolean, paramLong, paramString1, locale, Track.Encoding.toEncoding(paramInt1), paramInt2, paramInt3, paramFloat);
/*      */ 
/*      */     
/* 1500 */     TrackEvent trackEvent = new TrackEvent(audioTrack);
/*      */     
/* 1502 */     sendPlayerEvent(trackEvent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendVideoTrack(boolean paramBoolean1, long paramLong, String paramString, int paramInt1, int paramInt2, int paramInt3, float paramFloat, boolean paramBoolean2) {
/* 1510 */     VideoTrack videoTrack = new VideoTrack(paramBoolean1, paramLong, paramString, null, Track.Encoding.toEncoding(paramInt1), new VideoResolution(paramInt2, paramInt3), paramFloat, paramBoolean2);
/*      */ 
/*      */     
/* 1513 */     TrackEvent trackEvent = new TrackEvent(videoTrack);
/*      */     
/* 1515 */     sendPlayerEvent(trackEvent);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendSubtitleTrack(boolean paramBoolean, long paramLong, String paramString1, int paramInt, String paramString2) {
/* 1521 */     Locale locale = null;
/* 1522 */     if (null != paramString2) {
/* 1523 */       locale = new Locale(paramString2);
/*      */     }
/*      */     
/* 1526 */     SubtitleTrack subtitleTrack = new SubtitleTrack(paramBoolean, paramLong, paramString1, locale, Track.Encoding.toEncoding(paramInt));
/*      */     
/* 1528 */     sendPlayerEvent(new TrackEvent(subtitleTrack));
/*      */   }
/*      */   
/*      */   protected void sendMarkerEvent(String paramString, double paramDouble) {
/* 1532 */     sendPlayerEvent(new MarkerEvent(paramString, paramDouble));
/*      */   }
/*      */   
/*      */   protected void sendDurationUpdateEvent(double paramDouble) {
/* 1536 */     sendPlayerEvent(new PlayerTimeEvent(paramDouble));
/*      */   }
/*      */   
/*      */   protected void sendBufferProgressEvent(double paramDouble, long paramLong1, long paramLong2, long paramLong3) {
/* 1540 */     sendPlayerEvent(new BufferProgressEvent(paramDouble, paramLong1, paramLong2, paramLong3));
/*      */   }
/*      */   
/*      */   protected void sendAudioSpectrumEvent(double paramDouble1, double paramDouble2) {
/* 1544 */     sendPlayerEvent(new AudioSpectrumEvent(getAudioSpectrum(), paramDouble1, paramDouble2));
/*      */   }
/*      */ 
/*      */   
/*      */   public void markerStateChanged(boolean paramBoolean) {
/* 1549 */     if (paramBoolean) {
/* 1550 */       this.markerLock.lock();
/*      */       try {
/* 1552 */         this.previousTime = getPresentationTime();
/*      */       } finally {
/* 1554 */         this.markerLock.unlock();
/*      */       } 
/* 1556 */       createMediaPulse();
/*      */     }
/* 1558 */     else if (!this.isStopTimeSet) {
/* 1559 */       destroyMediaPulse();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void createMediaPulse() {
/* 1565 */     this.mediaPulseLock.lock();
/*      */     try {
/* 1567 */       if (this.mediaPulseTimer == null) {
/* 1568 */         this.mediaPulseTimer = new Timer(true);
/* 1569 */         this.mediaPulseTimer.scheduleAtFixedRate(new MediaPulseTask(this), 0L, 40L);
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 1574 */       this.mediaPulseLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void destroyMediaPulse() {
/* 1579 */     this.mediaPulseLock.lock();
/*      */     try {
/* 1581 */       if (this.mediaPulseTimer != null) {
/* 1582 */         this.mediaPulseTimer.cancel();
/* 1583 */         this.mediaPulseTimer = null;
/*      */       } 
/*      */     } finally {
/* 1586 */       this.mediaPulseLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   boolean doMediaPulseTask() {
/* 1591 */     if (this.isMediaPulseEnabled.get()) {
/* 1592 */       this.disposeLock.lock();
/*      */       
/* 1594 */       if (this.isDisposed) {
/* 1595 */         this.disposeLock.unlock();
/* 1596 */         return false;
/*      */       } 
/*      */       
/* 1599 */       double d = getPresentationTime();
/*      */       
/* 1601 */       this.markerLock.lock();
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1606 */         if (this.checkSeek) {
/* 1607 */           if (this.timeAfterSeek > this.timeBeforeSeek) {
/*      */             
/* 1609 */             if (d >= this.timeAfterSeek) {
/*      */               
/* 1611 */               this.checkSeek = false;
/*      */             } else {
/* 1613 */               return true;
/*      */             } 
/* 1615 */           } else if (this.timeAfterSeek < this.timeBeforeSeek) {
/*      */             
/* 1617 */             if (d >= this.timeBeforeSeek)
/*      */             {
/* 1619 */               return true;
/*      */             }
/* 1621 */             this.checkSeek = false;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 1626 */         Map.Entry<Double, String> entry = this.media.getNextMarker(this.previousTime, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1632 */         while (entry != null) {
/* 1633 */           double d1 = ((Double)entry.getKey()).doubleValue();
/* 1634 */           if (d1 > d)
/*      */             break; 
/* 1636 */           if (d1 != this.firedMarkerTime && d1 >= this.previousTime && d1 >= 
/*      */             
/* 1638 */             getStartTime() && d1 <= 
/* 1639 */             getStopTime()) {
/*      */ 
/*      */ 
/*      */             
/* 1643 */             MarkerEvent markerEvent = new MarkerEvent(entry.getValue(), d1);
/* 1644 */             for (ListIterator<WeakReference<MarkerListener>> listIterator = this.markerListeners.listIterator(); listIterator.hasNext(); ) {
/* 1645 */               MarkerListener markerListener = ((WeakReference<MarkerListener>)listIterator.next()).get();
/* 1646 */               if (markerListener != null) {
/* 1647 */                 markerListener.onMarker(markerEvent); continue;
/*      */               } 
/* 1649 */               listIterator.remove();
/*      */             } 
/*      */             
/* 1652 */             this.firedMarkerTime = d1;
/*      */           } 
/* 1654 */           entry = this.media.getNextMarker(d1, false);
/*      */         } 
/*      */         
/* 1657 */         this.previousTime = d;
/*      */ 
/*      */         
/* 1660 */         if (this.isStopTimeSet && d >= this.stopTime) {
/* 1661 */           playerFinish();
/*      */         }
/*      */       } finally {
/* 1664 */         this.disposeLock.unlock();
/* 1665 */         this.markerLock.unlock();
/*      */       } 
/*      */     } 
/*      */     
/* 1669 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected AudioEqualizer createNativeAudioEqualizer(long paramLong) {
/* 1674 */     return new NativeAudioEqualizer(paramLong);
/*      */   }
/*      */   
/*      */   protected AudioSpectrum createNativeAudioSpectrum(long paramLong) {
/* 1678 */     return new NativeAudioSpectrum(paramLong);
/*      */   }
/*      */   
/*      */   public abstract AudioEqualizer getEqualizer();
/*      */   
/*      */   public abstract AudioSpectrum getAudioSpectrum();
/*      */   
/*      */   protected abstract long playerGetAudioSyncDelay() throws MediaException;
/*      */   
/*      */   protected abstract void playerSetAudioSyncDelay(long paramLong) throws MediaException;
/*      */   
/*      */   protected abstract void playerPlay() throws MediaException;
/*      */   
/*      */   protected abstract void playerStop() throws MediaException;
/*      */   
/*      */   protected abstract void playerPause() throws MediaException;
/*      */   
/*      */   protected abstract void playerFinish() throws MediaException;
/*      */   
/*      */   protected abstract float playerGetRate() throws MediaException;
/*      */   
/*      */   protected abstract void playerSetRate(float paramFloat) throws MediaException;
/*      */   
/*      */   protected abstract double playerGetPresentationTime() throws MediaException;
/*      */   
/*      */   protected abstract boolean playerGetMute() throws MediaException;
/*      */   
/*      */   protected abstract void playerSetMute(boolean paramBoolean) throws MediaException;
/*      */   
/*      */   protected abstract float playerGetVolume() throws MediaException;
/*      */   
/*      */   protected abstract void playerSetVolume(float paramFloat) throws MediaException;
/*      */   
/*      */   protected abstract float playerGetBalance() throws MediaException;
/*      */   
/*      */   protected abstract void playerSetBalance(float paramFloat) throws MediaException;
/*      */   
/*      */   protected abstract double playerGetDuration() throws MediaException;
/*      */   
/*      */   protected abstract void playerSeek(double paramDouble) throws MediaException;
/*      */   
/*      */   protected abstract void playerInit() throws MediaException;
/*      */   
/*      */   protected abstract void playerDispose();
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeMediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */