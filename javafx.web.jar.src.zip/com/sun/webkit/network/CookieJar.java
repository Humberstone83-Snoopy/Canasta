/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.CookieHandler;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CookieJar
/*     */ {
/*     */   private static void fwkPut(String paramString1, String paramString2) {
/*  43 */     CookieHandler cookieHandler = CookieHandler.getDefault();
/*  44 */     if (cookieHandler != null) {
/*  45 */       URI uRI = null;
/*     */       try {
/*  47 */         uRI = new URI(paramString1);
/*  48 */         uRI = rewriteToFilterOutHttpOnlyCookies(uRI);
/*  49 */       } catch (URISyntaxException uRISyntaxException) {
/*     */         return;
/*     */       } 
/*     */       
/*  53 */       HashMap<Object, Object> hashMap = new HashMap<>();
/*  54 */       ArrayList<String> arrayList = new ArrayList();
/*  55 */       arrayList.add(paramString2);
/*  56 */       hashMap.put("Set-Cookie", arrayList);
/*     */       try {
/*  58 */         cookieHandler.put(uRI, (Map)hashMap);
/*  59 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String fwkGet(String paramString, boolean paramBoolean) {
/*  65 */     CookieHandler cookieHandler = CookieHandler.getDefault();
/*  66 */     if (cookieHandler != null) {
/*  67 */       URI uRI = null;
/*     */       try {
/*  69 */         uRI = new URI(paramString);
/*  70 */         if (!paramBoolean) {
/*  71 */           uRI = rewriteToFilterOutHttpOnlyCookies(uRI);
/*     */         }
/*  73 */       } catch (URISyntaxException uRISyntaxException) {
/*  74 */         return null;
/*     */       } 
/*     */       
/*  77 */       HashMap<Object, Object> hashMap = new HashMap<>();
/*  78 */       Map<String, List<String>> map = null;
/*     */       try {
/*  80 */         map = cookieHandler.get(uRI, (Map)hashMap);
/*  81 */       } catch (IOException iOException) {
/*  82 */         return null;
/*     */       } 
/*  84 */       if (map != null) {
/*  85 */         StringBuilder stringBuilder = new StringBuilder();
/*  86 */         for (Map.Entry<String, List<String>> entry : map.entrySet()) {
/*  87 */           String str = (String)entry.getKey();
/*  88 */           if ("Cookie".equalsIgnoreCase(str)) {
/*  89 */             for (String str1 : entry.getValue()) {
/*  90 */               if (stringBuilder.length() > 0) {
/*  91 */                 stringBuilder.append("; ");
/*     */               }
/*  93 */               stringBuilder.append(str1);
/*     */             } 
/*     */           }
/*     */         } 
/*  97 */         return stringBuilder.toString();
/*     */       } 
/*     */     } 
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URI rewriteToFilterOutHttpOnlyCookies(URI paramURI) throws URISyntaxException {
/* 111 */     return new URI(
/* 112 */         paramURI.getScheme().equalsIgnoreCase("https") ? 
/* 113 */         "javascripts" : "javascript", paramURI
/* 114 */         .getRawSchemeSpecificPart(), paramURI
/* 115 */         .getRawFragment());
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\CookieJar.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */