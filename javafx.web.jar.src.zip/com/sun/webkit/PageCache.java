/*    */ package com.sun.webkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PageCache
/*    */ {
/*    */   private PageCache() {
/* 37 */     throw new AssertionError();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getCapacity() {
/* 46 */     return twkGetCapacity();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setCapacity(int paramInt) {
/* 55 */     if (paramInt < 0) {
/* 56 */       throw new IllegalArgumentException("capacity is negative:" + paramInt);
/*    */     }
/*    */     
/* 59 */     twkSetCapacity(paramInt);
/*    */   }
/*    */   
/*    */   private static native int twkGetCapacity();
/*    */   
/*    */   private static native void twkSetCapacity(int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\PageCache.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */