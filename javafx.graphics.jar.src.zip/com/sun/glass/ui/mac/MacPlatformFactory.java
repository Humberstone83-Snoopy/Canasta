/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.Application;
/*    */ import com.sun.glass.ui.Menu;
/*    */ import com.sun.glass.ui.MenuBar;
/*    */ import com.sun.glass.ui.MenuItem;
/*    */ import com.sun.glass.ui.PlatformFactory;
/*    */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MacPlatformFactory
/*    */   extends PlatformFactory
/*    */ {
/*    */   public Application createApplication() {
/* 36 */     return new MacApplication();
/*    */   }
/*    */   
/*    */   public MenuBarDelegate createMenuBarDelegate(MenuBar paramMenuBar) {
/* 40 */     return new MacMenuBarDelegate();
/*    */   }
/*    */   
/*    */   public MenuDelegate createMenuDelegate(Menu paramMenu) {
/* 44 */     return new MacMenuDelegate(paramMenu);
/*    */   }
/*    */   
/*    */   public MenuItemDelegate createMenuItemDelegate(MenuItem paramMenuItem) {
/* 48 */     return new MacMenuDelegate();
/*    */   }
/*    */   
/*    */   public ClipboardDelegate createClipboardDelegate() {
/* 52 */     return new MacClipboardDelegate();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacPlatformFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */