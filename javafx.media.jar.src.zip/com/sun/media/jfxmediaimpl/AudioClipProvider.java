/*    */ package com.sun.media.jfxmediaimpl;
/*    */ 
/*    */ import com.sun.media.jfxmedia.AudioClip;
/*    */ import com.sun.media.jfxmedia.logging.Logger;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioClipProvider
/*    */ {
/*    */   private static AudioClipProvider primaDonna;
/*    */   private boolean useNative;
/*    */   
/*    */   public static synchronized AudioClipProvider getProvider() {
/* 43 */     if (null == primaDonna) {
/* 44 */       primaDonna = new AudioClipProvider();
/*    */     }
/* 46 */     return primaDonna;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private AudioClipProvider() {
/* 52 */     this.useNative = false;
/*    */     try {
/* 54 */       this.useNative = NativeAudioClip.init();
/* 55 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 56 */       Logger.logMsg(1, "JavaFX AudioClip native methods not linked, using NativeMedia implementation");
/* 57 */     } catch (Exception exception) {
/* 58 */       Logger.logMsg(4, "Exception while loading native AudioClip library: " + exception);
/*    */     } 
/*    */   }
/*    */   
/*    */   public AudioClip load(URI paramURI) throws URISyntaxException, FileNotFoundException, IOException {
/* 63 */     if (this.useNative) {
/* 64 */       return NativeAudioClip.load(paramURI);
/*    */     }
/* 66 */     return NativeMediaAudioClip.load(paramURI);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public AudioClip create(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws IllegalArgumentException {
/* 72 */     if (this.useNative) {
/* 73 */       return NativeAudioClip.create(paramArrayOfbyte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */     }
/* 75 */     return NativeMediaAudioClip.create(paramArrayOfbyte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */   }
/*    */   
/*    */   public void stopAllClips() {
/* 79 */     if (this.useNative) {
/* 80 */       NativeAudioClip.stopAllClips();
/*    */     }
/* 82 */     NativeMediaAudioClip.stopAllClips();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\AudioClipProvider.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */