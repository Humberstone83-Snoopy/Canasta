/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.webkit.graphics.WCFont;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PopupMenu
/*    */ {
/*    */   private long pdata;
/*    */   
/*    */   protected abstract void show(WebPage paramWebPage, int paramInt1, int paramInt2, int paramInt3);
/*    */   
/*    */   protected abstract void hide();
/*    */   
/*    */   protected abstract void setSelectedItem(int paramInt);
/*    */   
/*    */   protected abstract void appendItem(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt1, int paramInt2, WCFont paramWCFont);
/*    */   
/*    */   protected void notifySelectionCommited(int paramInt) {
/* 43 */     twkSelectionCommited(this.pdata, paramInt);
/*    */   }
/*    */   
/*    */   protected void notifyPopupClosed() {
/* 47 */     twkPopupClosed(this.pdata);
/*    */   }
/*    */   
/*    */   private static PopupMenu fwkCreatePopupMenu(long paramLong) {
/* 51 */     PopupMenu popupMenu = Utilities.getUtilities().createPopupMenu();
/* 52 */     popupMenu.pdata = paramLong;
/* 53 */     return popupMenu;
/*    */   }
/*    */   
/*    */   private void fwkShow(WebPage paramWebPage, int paramInt1, int paramInt2, int paramInt3) {
/* 57 */     assert paramWebPage != null;
/* 58 */     show(paramWebPage, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   
/*    */   private void fwkHide() {
/* 62 */     hide();
/*    */   }
/*    */   
/*    */   private void fwkSetSelectedItem(int paramInt) {
/* 66 */     setSelectedItem(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void fwkAppendItem(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt1, int paramInt2, WCFont paramWCFont) {
/* 72 */     appendItem(paramString, paramBoolean1, paramBoolean2, paramBoolean3, paramInt1, paramInt2, paramWCFont);
/*    */   }
/*    */   
/*    */   private void fwkDestroy() {
/* 76 */     this.pdata = 0L;
/*    */   }
/*    */   
/*    */   private native void twkSelectionCommited(long paramLong, int paramInt);
/*    */   
/*    */   private native void twkPopupClosed(long paramLong);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\PopupMenu.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */