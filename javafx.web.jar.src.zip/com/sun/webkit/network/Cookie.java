/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.net.URI;
/*     */ import java.text.ParseException;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Cookie
/*     */ {
/*  41 */   private static final PlatformLogger logger = PlatformLogger.getLogger(Cookie.class.getName());
/*  42 */   private static final Pattern IP_ADDRESS_PATTERN = Pattern.compile("(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})");
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final String value;
/*     */   
/*     */   private final long expiryTime;
/*     */   
/*     */   private String domain;
/*     */   
/*     */   private String path;
/*     */   
/*     */   private ExtendedTime creationTime;
/*     */   
/*     */   private long lastAccessTime;
/*     */   
/*     */   private final boolean persistent;
/*     */   
/*     */   private boolean hostOnly;
/*     */   
/*     */   private final boolean secureOnly;
/*     */   
/*     */   private final boolean httpOnly;
/*     */   
/*     */   private Cookie(String paramString1, String paramString2, long paramLong1, String paramString3, String paramString4, ExtendedTime paramExtendedTime, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/*  67 */     this.name = paramString1;
/*  68 */     this.value = paramString2;
/*  69 */     this.expiryTime = paramLong1;
/*  70 */     this.domain = paramString3;
/*  71 */     this.path = paramString4;
/*  72 */     this.creationTime = paramExtendedTime;
/*  73 */     this.lastAccessTime = paramLong2;
/*  74 */     this.persistent = paramBoolean1;
/*  75 */     this.hostOnly = paramBoolean2;
/*  76 */     this.secureOnly = paramBoolean3;
/*  77 */     this.httpOnly = paramBoolean4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Cookie parse(String paramString, ExtendedTime paramExtendedTime) {
/*     */     long l;
/*     */     boolean bool3;
/*  86 */     logger.finest("setCookieString: [{0}]", new Object[] { paramString });
/*     */     
/*  88 */     String[] arrayOfString1 = paramString.split(";", -1);
/*     */     
/*  90 */     String[] arrayOfString2 = arrayOfString1[0].split("=", 2);
/*  91 */     if (arrayOfString2.length != 2) {
/*  92 */       logger.finest("Name-value pair string lacks '=', ignoring cookie");
/*     */       
/*  94 */       return null;
/*     */     } 
/*  96 */     String str1 = arrayOfString2[0].trim();
/*  97 */     String str2 = arrayOfString2[1].trim();
/*  98 */     if (str1.length() == 0) {
/*  99 */       logger.finest("Name string is empty, ignoring cookie");
/* 100 */       return null;
/*     */     } 
/*     */     
/* 103 */     Long long_1 = null;
/* 104 */     Long long_2 = null;
/* 105 */     String str3 = null;
/* 106 */     String str4 = null;
/* 107 */     boolean bool1 = false;
/* 108 */     boolean bool2 = false;
/*     */     
/* 110 */     for (byte b = 1; b < arrayOfString1.length; b++) {
/* 111 */       String[] arrayOfString = arrayOfString1[b].split("=", 2);
/* 112 */       String str5 = arrayOfString[0].trim();
/* 113 */       String str6 = ((arrayOfString.length > 1) ? arrayOfString[1] : "").trim();
/*     */       
/*     */       try {
/* 116 */         if ("Expires".equalsIgnoreCase(str5)) {
/* 117 */           long_1 = Long.valueOf(parseExpires(str6));
/* 118 */         } else if ("Max-Age".equalsIgnoreCase(str5)) {
/* 119 */           long_2 = Long.valueOf(parseMaxAge(str6, paramExtendedTime.baseTime()));
/* 120 */         } else if ("Domain".equalsIgnoreCase(str5)) {
/* 121 */           str3 = parseDomain(str6);
/* 122 */         } else if ("Path".equalsIgnoreCase(str5)) {
/* 123 */           str4 = parsePath(str6);
/* 124 */         } else if ("Secure".equalsIgnoreCase(str5)) {
/* 125 */           bool1 = true;
/* 126 */         } else if ("HttpOnly".equalsIgnoreCase(str5)) {
/* 127 */           bool2 = true;
/*     */         } else {
/* 129 */           logger.finest("Unknown attribute: [{0}], ignoring", new Object[] { str5 });
/*     */         }
/*     */       
/* 132 */       } catch (ParseException parseException) {
/* 133 */         logger.finest("{0}, ignoring", new Object[] { parseException.getMessage() });
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 139 */     if (long_2 != null) {
/* 140 */       bool3 = true;
/* 141 */       l = long_2.longValue();
/* 142 */     } else if (long_1 != null) {
/* 143 */       bool3 = true;
/* 144 */       l = long_1.longValue();
/*     */     } else {
/* 146 */       bool3 = false;
/* 147 */       l = Long.MAX_VALUE;
/*     */     } 
/*     */     
/* 150 */     if (str3 == null) {
/* 151 */       str3 = "";
/*     */     }
/*     */ 
/*     */     
/* 155 */     Cookie cookie = new Cookie(str1, str2, l, str3, str4, paramExtendedTime, paramExtendedTime.baseTime(), bool3, false, bool1, bool2);
/*     */     
/* 157 */     logger.finest("result: {0}", new Object[] { cookie });
/* 158 */     return cookie;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long parseExpires(String paramString) throws ParseException {
/*     */     try {
/* 168 */       return Math.max(DateParser.parse(paramString), 0L);
/* 169 */     } catch (ParseException parseException) {
/* 170 */       throw new ParseException("Error parsing Expires attribute", 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long parseMaxAge(String paramString, long paramLong) throws ParseException {
/*     */     try {
/* 181 */       long l = Long.parseLong(paramString);
/* 182 */       if (l <= 0L) {
/* 183 */         return 0L;
/*     */       }
/* 185 */       return (l > (Long.MAX_VALUE - paramLong) / 1000L) ? 
/* 186 */         Long.MAX_VALUE : (paramLong + l * 1000L);
/*     */     }
/* 188 */     catch (NumberFormatException numberFormatException) {
/* 189 */       throw new ParseException("Error parsing Max-Age attribute", 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parseDomain(String paramString) throws ParseException {
/* 199 */     if (paramString.length() == 0) {
/* 200 */       throw new ParseException("Domain attribute is empty", 0);
/*     */     }
/* 202 */     if (paramString.startsWith(".")) {
/* 203 */       paramString = paramString.substring(1);
/*     */     }
/* 205 */     return paramString.toLowerCase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String parsePath(String paramString) {
/* 212 */     return paramString.startsWith("/") ? paramString : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getName() {
/* 220 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getValue() {
/* 227 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getExpiryTime() {
/* 234 */     return this.expiryTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getDomain() {
/* 241 */     return this.domain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDomain(String paramString) {
/* 248 */     this.domain = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getPath() {
/* 255 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPath(String paramString) {
/* 262 */     this.path = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExtendedTime getCreationTime() {
/* 269 */     return this.creationTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCreationTime(ExtendedTime paramExtendedTime) {
/* 276 */     this.creationTime = paramExtendedTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getLastAccessTime() {
/* 283 */     return this.lastAccessTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLastAccessTime(long paramLong) {
/* 290 */     this.lastAccessTime = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getPersistent() {
/* 297 */     return this.persistent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getHostOnly() {
/* 304 */     return this.hostOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setHostOnly(boolean paramBoolean) {
/* 311 */     this.hostOnly = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getSecureOnly() {
/* 318 */     return this.secureOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getHttpOnly() {
/* 325 */     return this.httpOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasExpired() {
/* 332 */     return (System.currentTimeMillis() > this.expiryTime);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 341 */     if (paramObject instanceof Cookie) {
/* 342 */       Cookie cookie = (Cookie)paramObject;
/* 343 */       return (equal(this.name, cookie.name) && 
/* 344 */         equal(this.domain, cookie.domain) && 
/* 345 */         equal(this.path, cookie.path));
/*     */     } 
/* 347 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equal(Object paramObject1, Object paramObject2) {
/* 355 */     return ((paramObject1 == null && paramObject2 == null) || (paramObject1 != null && paramObject1
/* 356 */       .equals(paramObject2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 364 */     int i = 7;
/* 365 */     i = 53 * i + hashCode(this.name);
/* 366 */     i = 53 * i + hashCode(this.domain);
/* 367 */     i = 53 * i + hashCode(this.path);
/* 368 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int hashCode(Object paramObject) {
/* 375 */     return (paramObject != null) ? paramObject.hashCode() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 383 */     return "[name=" + this.name + ", value=" + this.value + ", expiryTime=" + this.expiryTime + ", domain=" + this.domain + ", path=" + this.path + ", creationTime=" + this.creationTime + ", lastAccessTime=" + this.lastAccessTime + ", persistent=" + this.persistent + ", hostOnly=" + this.hostOnly + ", secureOnly=" + this.secureOnly + ", httpOnly=" + this.httpOnly + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean domainMatches(String paramString1, String paramString2) {
/* 395 */     return (paramString1.endsWith(paramString2) && (paramString1
/* 396 */       .length() == paramString2.length() || (paramString1
/* 397 */       .charAt(paramString1.length() - paramString2
/* 398 */         .length() - 1) == '.' && 
/* 399 */       !isIpAddress(paramString1))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isIpAddress(String paramString) {
/* 406 */     Matcher matcher = IP_ADDRESS_PATTERN.matcher(paramString);
/* 407 */     if (!matcher.matches()) {
/* 408 */       return false;
/*     */     }
/* 410 */     for (byte b = 1; b <= matcher.groupCount(); b++) {
/* 411 */       if (Integer.parseInt(matcher.group(b)) > 255) {
/* 412 */         return false;
/*     */       }
/*     */     } 
/* 415 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String defaultPath(URI paramURI) {
/* 422 */     String str = paramURI.getPath();
/* 423 */     if (str == null || !str.startsWith("/")) {
/* 424 */       return "/";
/*     */     }
/* 426 */     str = str.substring(0, str.lastIndexOf("/"));
/* 427 */     if (str.length() == 0) {
/* 428 */       return "/";
/*     */     }
/* 430 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean pathMatches(String paramString1, String paramString2) {
/* 437 */     return (paramString1 != null && paramString1.startsWith(paramString2) && (paramString1
/* 438 */       .length() == paramString2.length() || paramString2
/* 439 */       .endsWith("/") || paramString1
/* 440 */       .charAt(paramString2.length()) == '/'));
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\Cookie.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */