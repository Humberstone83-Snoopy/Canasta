/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacPasteboard
/*     */ {
/*     */   public static final int General = 1;
/*     */   public static final int DragAndDrop = 2;
/*     */   public static final int UtfIndex = 0;
/*     */   public static final int ObjectIndex = 1;
/*     */   public static final String UtfString = "public.utf8-plain-text";
/*     */   public static final String UtfPdf = "com.adobe.pdf";
/*     */   public static final String UtfTiff = "public.tiff";
/*     */   public static final String UtfPng = "public.png";
/*     */   public static final String UtfRtf = "public.rtf";
/*     */   public static final String UtfRtfd = "com.apple.flat-rtfd";
/*     */   public static final String UtfHtml = "public.html";
/*     */   public static final String UtfTabularText = "public.utf8-tab-separated-values-text";
/*     */   public static final String UtfFont = "com.apple.cocoa.pasteboard.character-formatting";
/*     */   public static final String UtfColor = "com.apple.cocoa.pasteboard.color";
/*     */   public static final String UtfSound = "com.apple.cocoa.pasteboard.sound";
/*     */   public static final String UtfMultipleTextSelection = "com.apple.cocoa.pasteboard.multiple-text-selection";
/*     */   public static final String UtfFindPanelSearchOptions = "com.apple.cocoa.pasteboard.find-panel-search-options";
/*     */   public static final String UtfUrl = "public.url";
/*     */   public static final String UtfFileUrl = "public.file-url";
/*     */   public static final String UtfRawImageType = "application.x-java-rawimage";
/*     */   public static final String UtfDragImageType = "application.x-java-drag-image";
/*     */   public static final String UtfDragImageOffset = "application.x-java-drag-image-offset";
/*     */   
/*     */   static {
/*  33 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private long ptr = 0L;
/*     */ 
/*     */   
/*     */   private boolean user;
/*     */ 
/*     */ 
/*     */   
/*     */   public MacPasteboard(int paramInt) {
/*  70 */     this.user = false;
/*  71 */     this.ptr = _createSystemPasteboard(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MacPasteboard(String paramString) {
/*  77 */     this.user = true;
/*  78 */     this.ptr = _createUserPasteboard(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNativePasteboard() {
/*  84 */     assertValid();
/*  85 */     return this.ptr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  91 */     assertValid();
/*  92 */     return _getName(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getUTFs() {
/* 100 */     assertValid();
/* 101 */     return _getUTFs(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getItemAsRawImage(int paramInt) {
/* 108 */     assertValid();
/* 109 */     return _getItemAsRawImage(this.ptr, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getItemStringForUTF(int paramInt, String paramString) {
/* 115 */     assertValid();
/* 116 */     return _getItemStringForUTF(this.ptr, paramInt, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getItemBytesForUTF(int paramInt, String paramString) {
/* 122 */     assertValid();
/* 123 */     return _getItemBytesForUTF(this.ptr, paramInt, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long putItemsFromArray(Object[] paramArrayOfObject, int paramInt) {
/* 143 */     return _putItemsFromArray(this.ptr, paramArrayOfObject, paramInt);
/*     */   }
/*     */   private Object[] hashMapToArray(HashMap<String, Object> paramHashMap) {
/* 146 */     Object[] arrayOfObject = null;
/* 147 */     if (paramHashMap != null && paramHashMap.size() > 0) {
/* 148 */       arrayOfObject = new Object[paramHashMap.size()];
/* 149 */       byte b = 0;
/* 150 */       for (String str : paramHashMap.keySet()) {
/* 151 */         Object[] arrayOfObject1 = new Object[2];
/* 152 */         arrayOfObject1[0] = str;
/* 153 */         arrayOfObject1[1] = paramHashMap.get(str);
/* 154 */         arrayOfObject[b++] = arrayOfObject1;
/*     */       } 
/*     */     } 
/* 157 */     return arrayOfObject;
/*     */   }
/*     */   public long putItems(HashMap<String, Object>[] paramArrayOfHashMap, int paramInt) {
/* 160 */     assertValid();
/* 161 */     Object[] arrayOfObject = new Object[paramArrayOfHashMap.length];
/* 162 */     for (byte b = 0; b < paramArrayOfHashMap.length; b++) {
/* 163 */       arrayOfObject[b] = hashMapToArray(paramArrayOfHashMap[b]);
/*     */     }
/* 165 */     return putItemsFromArray(arrayOfObject, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long clear() {
/* 172 */     assertValid();
/* 173 */     return _clear(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSeed() {
/* 179 */     assertValid();
/* 180 */     return _getSeed(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAllowedOperation() {
/* 186 */     assertValid();
/* 187 */     return _getAllowedOperation(this.ptr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 192 */     assertValid();
/* 193 */     if (this.ptr != 0L && this.user) {
/* 194 */       _release(this.ptr);
/*     */     }
/* 196 */     this.ptr = 0L;
/*     */   }
/*     */   
/*     */   private void assertValid() {
/* 200 */     if (this.ptr == 0L)
/* 201 */       throw new IllegalStateException("The MacPasteboard is not valid"); 
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native long _createSystemPasteboard(int paramInt);
/*     */   
/*     */   private native long _createUserPasteboard(String paramString);
/*     */   
/*     */   private native String _getName(long paramLong);
/*     */   
/*     */   private native String[][] _getUTFs(long paramLong);
/*     */   
/*     */   private native byte[] _getItemAsRawImage(long paramLong, int paramInt);
/*     */   
/*     */   private native String _getItemStringForUTF(long paramLong, int paramInt, String paramString);
/*     */   
/*     */   private native byte[] _getItemBytesForUTF(long paramLong, int paramInt, String paramString);
/*     */   
/*     */   private native long _putItemsFromArray(long paramLong, Object[] paramArrayOfObject, int paramInt);
/*     */   
/*     */   private native long _clear(long paramLong);
/*     */   
/*     */   private native long _getSeed(long paramLong);
/*     */   
/*     */   private native int _getAllowedOperation(long paramLong);
/*     */   
/*     */   private native void _release(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacPasteboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */