/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vec2f
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   
/*     */   public Vec2f() {}
/*     */   
/*     */   public Vec2f(float paramFloat1, float paramFloat2) {
/*  46 */     this.x = paramFloat1;
/*  47 */     this.y = paramFloat2;
/*     */   }
/*     */   
/*     */   public Vec2f(Vec2f paramVec2f) {
/*  51 */     this.x = paramVec2f.x;
/*  52 */     this.y = paramVec2f.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Vec2f paramVec2f) {
/*  63 */     this.x = paramVec2f.x;
/*  64 */     this.y = paramVec2f.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(float paramFloat1, float paramFloat2) {
/*  75 */     this.x = paramFloat1;
/*  76 */     this.y = paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float distanceSq(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  90 */     paramFloat1 -= paramFloat3;
/*  91 */     paramFloat2 -= paramFloat4;
/*  92 */     return paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float distance(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 106 */     paramFloat1 -= paramFloat3;
/* 107 */     paramFloat2 -= paramFloat4;
/* 108 */     return (float)Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distanceSq(float paramFloat1, float paramFloat2) {
/* 123 */     paramFloat1 -= this.x;
/* 124 */     paramFloat2 -= this.y;
/* 125 */     return paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distanceSq(Vec2f paramVec2f) {
/* 138 */     float f1 = paramVec2f.x - this.x;
/* 139 */     float f2 = paramVec2f.y - this.y;
/* 140 */     return f1 * f1 + f2 * f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distance(float paramFloat1, float paramFloat2) {
/* 155 */     paramFloat1 -= this.x;
/* 156 */     paramFloat2 -= this.y;
/* 157 */     return (float)Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float distance(Vec2f paramVec2f) {
/* 170 */     float f1 = paramVec2f.x - this.x;
/* 171 */     float f2 = paramVec2f.y - this.y;
/* 172 */     return (float)Math.sqrt((f1 * f1 + f2 * f2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 181 */     int i = 7;
/* 182 */     i = 31 * i + Float.floatToIntBits(this.x);
/* 183 */     i = 31 * i + Float.floatToIntBits(this.y);
/* 184 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 199 */     if (paramObject == this) return true; 
/* 200 */     if (paramObject instanceof Vec2f) {
/* 201 */       Vec2f vec2f = (Vec2f)paramObject;
/* 202 */       return (this.x == vec2f.x && this.y == vec2f.y);
/*     */     } 
/* 204 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 214 */     return "Vec2f[" + this.x + ", " + this.y + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec2f.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */