/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WoffDecoder
/*     */   extends FontFileWriter
/*     */ {
/*     */   WoffHeader woffHeader;
/*     */   WoffDirectoryEntry[] woffTableDirectory;
/*     */   
/*     */   public void decode(FontFileReader paramFontFileReader) throws Exception {
/*  42 */     paramFontFileReader.reset();
/*  43 */     initWoffTables(paramFontFileReader);
/*  44 */     if (this.woffHeader == null || this.woffTableDirectory == null) {
/*  45 */       throw new Exception("WoffDecoder: failure reading header");
/*     */     }
/*  47 */     int i = this.woffHeader.flavor;
/*  48 */     if (i != 65536 && i != 1953658213 && i != 1330926671) {
/*  49 */       throw new Exception("WoffDecoder: invalid flavor");
/*     */     }
/*     */ 
/*     */     
/*  53 */     short s = this.woffHeader.numTables;
/*  54 */     setLength(this.woffHeader.totalSfntSize);
/*  55 */     writeHeader(i, s);
/*     */ 
/*     */     
/*  58 */     Arrays.sort(this.woffTableDirectory, (paramWoffDirectoryEntry1, paramWoffDirectoryEntry2) -> paramWoffDirectoryEntry1.offset - paramWoffDirectoryEntry2.offset);
/*     */     
/*  60 */     Inflater inflater = new Inflater();
/*  61 */     int j = 12 + s * 16;
/*  62 */     for (byte b = 0; b < this.woffTableDirectory.length; b++) {
/*  63 */       WoffDirectoryEntry woffDirectoryEntry = this.woffTableDirectory[b];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       writeDirectoryEntry(woffDirectoryEntry.index, woffDirectoryEntry.tag, woffDirectoryEntry.origChecksum, j, woffDirectoryEntry.origLength);
/*     */ 
/*     */ 
/*     */       
/*  72 */       FontFileReader.Buffer buffer = paramFontFileReader.readBlock(woffDirectoryEntry.offset, woffDirectoryEntry.comLength);
/*  73 */       byte[] arrayOfByte = new byte[woffDirectoryEntry.comLength];
/*  74 */       buffer.get(0, arrayOfByte, 0, woffDirectoryEntry.comLength);
/*  75 */       if (woffDirectoryEntry.comLength != woffDirectoryEntry.origLength) {
/*  76 */         inflater.setInput(arrayOfByte);
/*  77 */         byte[] arrayOfByte1 = new byte[woffDirectoryEntry.origLength];
/*  78 */         int k = inflater.inflate(arrayOfByte1);
/*  79 */         if (k != woffDirectoryEntry.origLength) {
/*  80 */           throw new Exception("WoffDecoder: failure expanding table");
/*     */         }
/*  82 */         inflater.reset();
/*  83 */         arrayOfByte = arrayOfByte1;
/*     */       } 
/*  85 */       seek(j);
/*  86 */       writeBytes(arrayOfByte);
/*     */       
/*  88 */       j += woffDirectoryEntry.origLength + 3 & 0xFFFFFFFC;
/*     */     } 
/*  90 */     inflater.end();
/*     */   }
/*     */   
/*     */   void initWoffTables(FontFileReader paramFontFileReader) throws Exception {
/*  94 */     long l = paramFontFileReader.getLength();
/*  95 */     if (l < 44L) {
/*  96 */       throw new Exception("WoffDecoder: invalid filesize");
/*     */     }
/*  98 */     FontFileReader.Buffer buffer = paramFontFileReader.readBlock(0, 44);
/*  99 */     WoffHeader woffHeader = new WoffHeader(buffer);
/* 100 */     short s = woffHeader.numTables;
/* 101 */     if (woffHeader.signature != 2001684038) {
/* 102 */       throw new Exception("WoffDecoder: invalid signature");
/*     */     }
/* 104 */     if (woffHeader.reserved != 0) {
/* 105 */       throw new Exception("WoffDecoder: invalid reserved != 0");
/*     */     }
/* 107 */     if (l < (44 + s * 20)) {
/* 108 */       throw new Exception("WoffDecoder: invalid filesize");
/*     */     }
/*     */     
/* 111 */     WoffDirectoryEntry[] arrayOfWoffDirectoryEntry = new WoffDirectoryEntry[s];
/* 112 */     int i = 44 + s * 20;
/* 113 */     int j = 12 + s * 16;
/* 114 */     buffer = paramFontFileReader.readBlock(44, s * 20);
/* 115 */     byte b1 = 0;
/* 116 */     for (byte b2 = 0; b2 < s; b2++) {
/* 117 */       WoffDirectoryEntry woffDirectoryEntry = new WoffDirectoryEntry(buffer, b2);
/* 118 */       if (woffDirectoryEntry.tag <= b1) {
/* 119 */         throw new Exception("WoffDecoder: table directory not ordered by tag");
/*     */       }
/*     */       
/* 122 */       int k = woffDirectoryEntry.offset;
/* 123 */       int m = woffDirectoryEntry.offset + woffDirectoryEntry.comLength;
/* 124 */       if (i > k || k > l) {
/* 125 */         throw new Exception("WoffDecoder: invalid table offset");
/*     */       }
/* 127 */       if (k > m || m > l) {
/* 128 */         throw new Exception("WoffDecoder: invalid table offset");
/*     */       }
/* 130 */       if (woffDirectoryEntry.comLength > woffDirectoryEntry.origLength) {
/* 131 */         throw new Exception("WoffDecoder: invalid compressed length");
/*     */       }
/* 133 */       j += woffDirectoryEntry.origLength + 3 & 0xFFFFFFFC;
/* 134 */       if (j > woffHeader.totalSfntSize) {
/* 135 */         throw new Exception("WoffDecoder: invalid totalSfntSize");
/*     */       }
/*     */     } 
/* 138 */     if (j != woffHeader.totalSfntSize) {
/* 139 */       throw new Exception("WoffDecoder: invalid totalSfntSize");
/*     */     }
/* 141 */     this.woffHeader = woffHeader;
/* 142 */     this.woffTableDirectory = arrayOfWoffDirectoryEntry;
/*     */   }
/*     */ 
/*     */   
/*     */   static class WoffHeader
/*     */   {
/*     */     int signature;
/*     */     
/*     */     int flavor;
/*     */     
/*     */     int length;
/*     */     
/*     */     short numTables;
/*     */     
/*     */     short reserved;
/*     */     int totalSfntSize;
/*     */     
/*     */     WoffHeader(FontFileReader.Buffer param1Buffer) {
/* 160 */       this.signature = param1Buffer.getInt();
/* 161 */       this.flavor = param1Buffer.getInt();
/* 162 */       this.length = param1Buffer.getInt();
/* 163 */       this.numTables = param1Buffer.getShort();
/* 164 */       this.reserved = param1Buffer.getShort();
/* 165 */       this.totalSfntSize = param1Buffer.getInt();
/* 166 */       this.majorVersion = param1Buffer.getShort();
/* 167 */       this.minorVersion = param1Buffer.getShort();
/* 168 */       this.metaOffset = param1Buffer.getInt();
/* 169 */       this.metaLength = param1Buffer.getInt();
/* 170 */       this.metaOrigLength = param1Buffer.getInt();
/* 171 */       this.privateOffset = param1Buffer.getInt();
/* 172 */       this.privateLength = param1Buffer.getInt();
/*     */     }
/*     */     short majorVersion; short minorVersion; int metaOffset; int metaLength; int metaOrigLength; int privateOffset; int privateLength; }
/*     */   
/*     */   static class WoffDirectoryEntry { int tag;
/*     */     int offset;
/*     */     int comLength;
/*     */     int origLength;
/*     */     int origChecksum;
/*     */     int index;
/*     */     
/*     */     WoffDirectoryEntry(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 184 */       this.tag = param1Buffer.getInt();
/* 185 */       this.offset = param1Buffer.getInt();
/* 186 */       this.comLength = param1Buffer.getInt();
/* 187 */       this.origLength = param1Buffer.getInt();
/* 188 */       this.origChecksum = param1Buffer.getInt();
/* 189 */       this.index = param1Int;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\WoffDecoder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */