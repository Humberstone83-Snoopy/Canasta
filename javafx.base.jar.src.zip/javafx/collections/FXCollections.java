/*      */ package javafx.collections;
/*      */ 
/*      */ import com.sun.javafx.collections.ListListenerHelper;
/*      */ import com.sun.javafx.collections.MapAdapterChange;
/*      */ import com.sun.javafx.collections.MapListenerHelper;
/*      */ import com.sun.javafx.collections.ObservableFloatArrayImpl;
/*      */ import com.sun.javafx.collections.ObservableIntegerArrayImpl;
/*      */ import com.sun.javafx.collections.ObservableListWrapper;
/*      */ import com.sun.javafx.collections.ObservableMapWrapper;
/*      */ import com.sun.javafx.collections.ObservableSequentialListWrapper;
/*      */ import com.sun.javafx.collections.ObservableSetWrapper;
/*      */ import com.sun.javafx.collections.SetAdapterChange;
/*      */ import com.sun.javafx.collections.SetListenerHelper;
/*      */ import com.sun.javafx.collections.SortableList;
/*      */ import com.sun.javafx.collections.SourceAdapterChange;
/*      */ import com.sun.javafx.collections.UnmodifiableObservableMap;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.AbstractList;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.util.Callback;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FXCollections
/*      */ {
/*      */   public static <E> ObservableList<E> observableList(List<E> paramList) {
/*   97 */     if (paramList == null) {
/*   98 */       throw new NullPointerException();
/*      */     }
/*  100 */     return (paramList instanceof java.util.RandomAccess) ? new ObservableListWrapper<>(paramList) : 
/*  101 */       new ObservableSequentialListWrapper<>(paramList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> observableList(List<E> paramList, Callback<E, Observable[]> paramCallback) {
/*  123 */     if (paramList == null || paramCallback == null) {
/*  124 */       throw new NullPointerException();
/*      */     }
/*  126 */     return (paramList instanceof java.util.RandomAccess) ? new ObservableListWrapper<>(paramList, paramCallback) : 
/*  127 */       new ObservableSequentialListWrapper<>(paramList, paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> observableMap(Map<K, V> paramMap) {
/*  142 */     if (paramMap == null) {
/*  143 */       throw new NullPointerException();
/*      */     }
/*  145 */     return new ObservableMapWrapper<>(paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> observableSet(Set<E> paramSet) {
/*  160 */     if (paramSet == null) {
/*  161 */       throw new NullPointerException();
/*      */     }
/*  163 */     return new ObservableSetWrapper<>(paramSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> observableSet(E... paramVarArgs) {
/*  175 */     if (paramVarArgs == null) {
/*  176 */       throw new NullPointerException();
/*      */     }
/*  178 */     HashSet<? super E> hashSet = new HashSet(paramVarArgs.length);
/*  179 */     Collections.addAll(hashSet, paramVarArgs);
/*  180 */     return new ObservableSetWrapper<>((Set)hashSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> unmodifiableObservableMap(ObservableMap<K, V> paramObservableMap) {
/*  194 */     if (paramObservableMap == null) {
/*  195 */       throw new NullPointerException();
/*      */     }
/*  197 */     return new UnmodifiableObservableMap<>(paramObservableMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> checkedObservableMap(ObservableMap<K, V> paramObservableMap, Class<K> paramClass, Class<V> paramClass1) {
/*  212 */     if (paramObservableMap == null || paramClass == null || paramClass1 == null) {
/*  213 */       throw new NullPointerException();
/*      */     }
/*  215 */     return new CheckedObservableMap<>(paramObservableMap, paramClass, paramClass1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> synchronizedObservableMap(ObservableMap<K, V> paramObservableMap) {
/*  228 */     if (paramObservableMap == null) {
/*  229 */       throw new NullPointerException();
/*      */     }
/*  231 */     return new SynchronizedObservableMap<>(paramObservableMap);
/*      */   }
/*      */   
/*  234 */   private static ObservableMap EMPTY_OBSERVABLE_MAP = new EmptyObservableMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> emptyObservableMap() {
/*  246 */     return EMPTY_OBSERVABLE_MAP;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableIntegerArray observableIntegerArray() {
/*  255 */     return new ObservableIntegerArrayImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableIntegerArray observableIntegerArray(int... paramVarArgs) {
/*  265 */     return new ObservableIntegerArrayImpl(paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableIntegerArray observableIntegerArray(ObservableIntegerArray paramObservableIntegerArray) {
/*  276 */     return new ObservableIntegerArrayImpl(paramObservableIntegerArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableFloatArray observableFloatArray() {
/*  285 */     return new ObservableFloatArrayImpl();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableFloatArray observableFloatArray(float... paramVarArgs) {
/*  295 */     return new ObservableFloatArrayImpl(paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableFloatArray observableFloatArray(ObservableFloatArray paramObservableFloatArray) {
/*  306 */     return new ObservableFloatArrayImpl(paramObservableFloatArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> observableArrayList() {
/*  317 */     return observableList(new ArrayList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> observableArrayList(Callback<E, Observable[]> paramCallback) {
/*  331 */     return observableList(new ArrayList<>(), paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> observableArrayList(E... paramVarArgs) {
/*  342 */     ObservableList<?> observableList = observableArrayList();
/*  343 */     observableList.addAll((Object[])paramVarArgs);
/*  344 */     return (ObservableList)observableList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> observableArrayList(Collection<? extends E> paramCollection) {
/*  355 */     ObservableList<?> observableList = observableArrayList();
/*  356 */     observableList.addAll(paramCollection);
/*  357 */     return (ObservableList)observableList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObservableMap<K, V> observableHashMap() {
/*  367 */     return observableMap(new HashMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> concat(ObservableList<E>... paramVarArgs) {
/*  378 */     if (paramVarArgs.length == 0) {
/*  379 */       return observableArrayList();
/*      */     }
/*  381 */     if (paramVarArgs.length == 1) {
/*  382 */       return observableArrayList(paramVarArgs[0]);
/*      */     }
/*  384 */     ArrayList<E> arrayList = new ArrayList();
/*  385 */     for (ObservableList<E> observableList : paramVarArgs) {
/*  386 */       arrayList.addAll(observableList);
/*      */     }
/*      */     
/*  389 */     return observableList(arrayList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> unmodifiableObservableList(ObservableList<E> paramObservableList) {
/*  400 */     if (paramObservableList == null) {
/*  401 */       throw new NullPointerException();
/*      */     }
/*  403 */     return new UnmodifiableObservableListImpl<>(paramObservableList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> checkedObservableList(ObservableList<E> paramObservableList, Class<E> paramClass) {
/*  415 */     if (paramObservableList == null) {
/*  416 */       throw new NullPointerException();
/*      */     }
/*  418 */     return new CheckedObservableList<>(paramObservableList, paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> synchronizedObservableList(ObservableList<E> paramObservableList) {
/*  429 */     if (paramObservableList == null) {
/*  430 */       throw new NullPointerException();
/*      */     }
/*  432 */     return new SynchronizedObservableList<>(paramObservableList);
/*      */   }
/*      */   
/*  435 */   private static ObservableList EMPTY_OBSERVABLE_LIST = new EmptyObservableList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> emptyObservableList() {
/*  446 */     return EMPTY_OBSERVABLE_LIST;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableList<E> singletonObservableList(E paramE) {
/*  457 */     return new SingletonObservableList<>(paramE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> unmodifiableObservableSet(ObservableSet<E> paramObservableSet) {
/*  469 */     if (paramObservableSet == null) {
/*  470 */       throw new NullPointerException();
/*      */     }
/*  472 */     return new UnmodifiableObservableSet<>(paramObservableSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> checkedObservableSet(ObservableSet<E> paramObservableSet, Class<E> paramClass) {
/*  485 */     if (paramObservableSet == null) {
/*  486 */       throw new NullPointerException();
/*      */     }
/*  488 */     return new CheckedObservableSet<>(paramObservableSet, paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> synchronizedObservableSet(ObservableSet<E> paramObservableSet) {
/*  500 */     if (paramObservableSet == null) {
/*  501 */       throw new NullPointerException();
/*      */     }
/*  503 */     return new SynchronizedObservableSet<>(paramObservableSet);
/*      */   }
/*      */   
/*  506 */   private static ObservableSet EMPTY_OBSERVABLE_SET = new EmptyObservableSet();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Random r;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObservableSet<E> emptyObservableSet() {
/*  517 */     return EMPTY_OBSERVABLE_SET;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void copy(ObservableList<? super T> paramObservableList, List<? extends T> paramList) {
/*  529 */     int i = paramList.size();
/*  530 */     if (i > paramObservableList.size()) {
/*  531 */       throw new IndexOutOfBoundsException("Source does not fit in dest");
/*      */     }
/*  533 */     Object[] arrayOfObject = paramObservableList.toArray();
/*  534 */     System.arraycopy(paramList.toArray(), 0, arrayOfObject, 0, i);
/*  535 */     paramObservableList.setAll((T[])arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void fill(ObservableList<? super T> paramObservableList, T paramT) {
/*  547 */     Object[] arrayOfObject = new Object[paramObservableList.size()];
/*  548 */     Arrays.fill(arrayOfObject, paramT);
/*  549 */     paramObservableList.setAll((T[])arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> boolean replaceAll(ObservableList<T> paramObservableList, T paramT1, T paramT2) {
/*  564 */     Object[] arrayOfObject = paramObservableList.toArray();
/*  565 */     boolean bool = false;
/*  566 */     for (byte b = 0; b < arrayOfObject.length; b++) {
/*  567 */       if (arrayOfObject[b].equals(paramT1)) {
/*  568 */         arrayOfObject[b] = paramT2;
/*  569 */         bool = true;
/*      */       } 
/*      */     } 
/*  572 */     if (bool) {
/*  573 */       paramObservableList.setAll((T[])arrayOfObject);
/*      */     }
/*  575 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(ObservableList<Object> paramObservableList) {
/*  586 */     Object[] arrayOfObject = paramObservableList.toArray();
/*  587 */     for (byte b = 0; b < arrayOfObject.length / 2; b++) {
/*  588 */       Object object = arrayOfObject[b];
/*  589 */       arrayOfObject[b] = arrayOfObject[arrayOfObject.length - b - 1];
/*  590 */       arrayOfObject[arrayOfObject.length - b - 1] = object;
/*      */     } 
/*  592 */     paramObservableList.setAll(arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rotate(ObservableList<Object> paramObservableList, int paramInt) {
/*  604 */     Object[] arrayOfObject = paramObservableList.toArray();
/*      */     
/*  606 */     int i = paramObservableList.size();
/*  607 */     paramInt %= i;
/*  608 */     if (paramInt < 0)
/*  609 */       paramInt += i; 
/*  610 */     if (paramInt == 0)
/*      */       return;  byte b;
/*      */     int j;
/*  613 */     for (b = 0, j = 0; j != i; ) {
/*  614 */       Object object = arrayOfObject[b];
/*      */       
/*  616 */       int k = b;
/*      */       while (true)
/*  618 */       { k += paramInt;
/*  619 */         if (k >= i)
/*  620 */           k -= i; 
/*  621 */         Object object1 = arrayOfObject[k];
/*  622 */         arrayOfObject[k] = object;
/*  623 */         object = object1;
/*  624 */         j++;
/*  625 */         if (k == b)
/*      */           b++;  } 
/*  627 */     }  paramObservableList.setAll(arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shuffle(ObservableList<?> paramObservableList) {
/*  637 */     if (r == null) {
/*  638 */       r = new Random();
/*      */     }
/*  640 */     shuffle(paramObservableList, r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shuffle(ObservableList<Object> paramObservableList, Random paramRandom) {
/*  653 */     Object[] arrayOfObject = paramObservableList.toArray();
/*      */     
/*  655 */     for (int i = paramObservableList.size(); i > 1; i--) {
/*  656 */       swap(arrayOfObject, i - 1, paramRandom.nextInt(i));
/*      */     }
/*      */     
/*  659 */     paramObservableList.setAll(arrayOfObject);
/*      */   }
/*      */   
/*      */   private static void swap(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
/*  663 */     Object object = paramArrayOfObject[paramInt1];
/*  664 */     paramArrayOfObject[paramInt1] = paramArrayOfObject[paramInt2];
/*  665 */     paramArrayOfObject[paramInt2] = object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Comparable<? super T>> void sort(ObservableList<T> paramObservableList) {
/*  677 */     if (paramObservableList instanceof SortableList) {
/*  678 */       ((SortableList)paramObservableList).sort();
/*      */     } else {
/*  680 */       ArrayList<T> arrayList = new ArrayList<>(paramObservableList);
/*  681 */       Collections.sort(arrayList);
/*  682 */       paramObservableList.setAll(arrayList);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void sort(ObservableList<T> paramObservableList, Comparator<? super T> paramComparator) {
/*  696 */     if (paramObservableList instanceof SortableList) {
/*  697 */       ((SortableList<T>)paramObservableList).sort(paramComparator);
/*      */     } else {
/*  699 */       ArrayList<T> arrayList = new ArrayList<>(paramObservableList);
/*  700 */       Collections.sort(arrayList, paramComparator);
/*  701 */       paramObservableList.setAll(arrayList);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class EmptyObservableList<E>
/*      */     extends AbstractList<E> implements ObservableList<E> {
/*  707 */     private static final ListIterator iterator = new ListIterator()
/*      */       {
/*      */         public boolean hasNext()
/*      */         {
/*  711 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public Object next() {
/*  716 */           throw new NoSuchElementException();
/*      */         }
/*      */ 
/*      */         
/*      */         public void remove() {
/*  721 */           throw new UnsupportedOperationException();
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean hasPrevious() {
/*  726 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public Object previous() {
/*  731 */           throw new NoSuchElementException();
/*      */         }
/*      */ 
/*      */         
/*      */         public int nextIndex() {
/*  736 */           return 0;
/*      */         }
/*      */ 
/*      */         
/*      */         public int previousIndex() {
/*  741 */           return -1;
/*      */         }
/*      */ 
/*      */         
/*      */         public void set(Object param2Object) {
/*  746 */           throw new UnsupportedOperationException();
/*      */         }
/*      */ 
/*      */         
/*      */         public void add(Object param2Object) {
/*  751 */           throw new UnsupportedOperationException();
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void addListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void removeListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(ListChangeListener<? super E> param1ListChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(ListChangeListener<? super E> param1ListChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  777 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/*  782 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/*  788 */       return iterator;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/*  793 */       return param1Collection.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public E get(int param1Int) {
/*  798 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */ 
/*      */     
/*      */     public int indexOf(Object param1Object) {
/*  803 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*      */     public int lastIndexOf(Object param1Object) {
/*  808 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ListIterator<E> listIterator() {
/*  814 */       return iterator;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ListIterator<E> listIterator(int param1Int) {
/*  820 */       if (param1Int != 0) {
/*  821 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  823 */       return iterator;
/*      */     }
/*      */ 
/*      */     
/*      */     public List<E> subList(int param1Int1, int param1Int2) {
/*  828 */       if (param1Int1 != 0 || param1Int2 != 0) {
/*  829 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  831 */       return this;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(E... param1VarArgs) {
/*  836 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(E... param1VarArgs) {
/*  841 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(Collection<? extends E> param1Collection) {
/*  846 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(E... param1VarArgs) {
/*  851 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(E... param1VarArgs) {
/*  856 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(int param1Int1, int param1Int2) {
/*  861 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SingletonObservableList<E>
/*      */     extends AbstractList<E> implements ObservableList<E> {
/*      */     private final E element;
/*      */     
/*      */     public SingletonObservableList(E param1E) {
/*  870 */       if (param1E == null) {
/*  871 */         throw new NullPointerException();
/*      */       }
/*  873 */       this.element = param1E;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(E... param1VarArgs) {
/*  878 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(E... param1VarArgs) {
/*  883 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(Collection<? extends E> param1Collection) {
/*  888 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(E... param1VarArgs) {
/*  893 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(E... param1VarArgs) {
/*  898 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(int param1Int1, int param1Int2) {
/*  903 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(ListChangeListener<? super E> param1ListChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(ListChangeListener<? super E> param1ListChangeListener) {}
/*      */ 
/*      */     
/*      */     public int size() {
/*  924 */       return 1;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  929 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/*  934 */       return this.element.equals(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public E get(int param1Int) {
/*  939 */       if (param1Int != 0) {
/*  940 */         throw new IndexOutOfBoundsException();
/*      */       }
/*  942 */       return this.element;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class UnmodifiableObservableListImpl<T>
/*      */     extends ObservableListBase<T>
/*      */     implements ObservableList<T> {
/*      */     private final ObservableList<T> backingList;
/*      */     private final ListChangeListener<T> listener;
/*      */     
/*      */     public UnmodifiableObservableListImpl(ObservableList<T> param1ObservableList) {
/*  953 */       this.backingList = param1ObservableList;
/*  954 */       this.listener = (param1Change -> fireChange(new SourceAdapterChange<>(this, param1Change)));
/*      */ 
/*      */       
/*  957 */       this.backingList.addListener(new WeakListChangeListener<>(this.listener));
/*      */     }
/*      */ 
/*      */     
/*      */     public T get(int param1Int) {
/*  962 */       return this.backingList.get(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  967 */       return this.backingList.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(T... param1VarArgs) {
/*  972 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(T... param1VarArgs) {
/*  977 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(Collection<? extends T> param1Collection) {
/*  982 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(T... param1VarArgs) {
/*  987 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(T... param1VarArgs) {
/*  992 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(int param1Int1, int param1Int2) {
/*  997 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedList<T>
/*      */     implements List<T> {
/*      */     final Object mutex;
/*      */     private final List<T> backingList;
/*      */     
/*      */     SynchronizedList(List<T> param1List, Object param1Object) {
/* 1007 */       this.backingList = param1List;
/* 1008 */       this.mutex = param1Object;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1013 */       synchronized (this.mutex) {
/* 1014 */         return this.backingList.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1020 */       synchronized (this.mutex) {
/* 1021 */         return this.backingList.isEmpty();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1027 */       synchronized (this.mutex) {
/* 1028 */         return this.backingList.contains(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<T> iterator() {
/* 1034 */       return this.backingList.iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1039 */       synchronized (this.mutex) {
/* 1040 */         return this.backingList.toArray();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 1046 */       synchronized (this.mutex) {
/* 1047 */         return this.backingList.toArray(param1ArrayOfT);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(T param1T) {
/* 1053 */       synchronized (this.mutex) {
/* 1054 */         return this.backingList.add(param1T);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 1060 */       synchronized (this.mutex) {
/* 1061 */         return this.backingList.remove(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 1067 */       synchronized (this.mutex) {
/* 1068 */         return this.backingList.containsAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends T> param1Collection) {
/* 1074 */       synchronized (this.mutex) {
/* 1075 */         return this.backingList.addAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(int param1Int, Collection<? extends T> param1Collection) {
/* 1081 */       synchronized (this.mutex) {
/* 1082 */         return this.backingList.addAll(param1Int, param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 1089 */       synchronized (this.mutex) {
/* 1090 */         return this.backingList.removeAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 1096 */       synchronized (this.mutex) {
/* 1097 */         return this.backingList.retainAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1103 */       synchronized (this.mutex) {
/* 1104 */         this.backingList.clear();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public T get(int param1Int) {
/* 1110 */       synchronized (this.mutex) {
/* 1111 */         return this.backingList.get(param1Int);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public T set(int param1Int, T param1T) {
/* 1117 */       synchronized (this.mutex) {
/* 1118 */         return this.backingList.set(param1Int, param1T);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(int param1Int, T param1T) {
/* 1124 */       synchronized (this.mutex) {
/* 1125 */         this.backingList.add(param1Int, param1T);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public T remove(int param1Int) {
/* 1131 */       synchronized (this.mutex) {
/* 1132 */         return this.backingList.remove(param1Int);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int indexOf(Object param1Object) {
/* 1138 */       synchronized (this.mutex) {
/* 1139 */         return this.backingList.indexOf(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int lastIndexOf(Object param1Object) {
/* 1145 */       synchronized (this.mutex) {
/* 1146 */         return this.backingList.lastIndexOf(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public ListIterator<T> listIterator() {
/* 1152 */       return this.backingList.listIterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public ListIterator<T> listIterator(int param1Int) {
/* 1157 */       synchronized (this.mutex) {
/* 1158 */         return this.backingList.listIterator(param1Int);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public List<T> subList(int param1Int1, int param1Int2) {
/* 1164 */       synchronized (this.mutex) {
/* 1165 */         return new SynchronizedList(this.backingList.subList(param1Int1, param1Int2), this.mutex);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1172 */       synchronized (this.mutex) {
/* 1173 */         return this.backingList.toString();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1179 */       synchronized (this.mutex) {
/* 1180 */         return this.backingList.hashCode();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 1186 */       synchronized (this.mutex) {
/* 1187 */         return this.backingList.equals(param1Object);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedObservableList<T>
/*      */     extends SynchronizedList<T>
/*      */     implements ObservableList<T>
/*      */   {
/*      */     private ListListenerHelper helper;
/*      */     private final ObservableList<T> backingList;
/*      */     private final ListChangeListener<T> listener;
/*      */     
/*      */     SynchronizedObservableList(ObservableList<T> param1ObservableList, Object param1Object) {
/* 1201 */       super(param1ObservableList, param1Object);
/* 1202 */       this.backingList = param1ObservableList;
/* 1203 */       this.listener = (param1Change -> ListListenerHelper.fireValueChangedEvent(this.helper, new SourceAdapterChange(this, param1Change)));
/*      */ 
/*      */       
/* 1206 */       this.backingList.addListener(new WeakListChangeListener<>(this.listener));
/*      */     }
/*      */     
/*      */     SynchronizedObservableList(ObservableList<T> param1ObservableList) {
/* 1210 */       this(param1ObservableList, new Object());
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(T... param1VarArgs) {
/* 1215 */       synchronized (this.mutex) {
/* 1216 */         return this.backingList.addAll(param1VarArgs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(T... param1VarArgs) {
/* 1222 */       synchronized (this.mutex) {
/* 1223 */         return this.backingList.setAll(param1VarArgs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(T... param1VarArgs) {
/* 1229 */       synchronized (this.mutex) {
/* 1230 */         return this.backingList.removeAll(param1VarArgs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(T... param1VarArgs) {
/* 1236 */       synchronized (this.mutex) {
/* 1237 */         return this.backingList.retainAll(param1VarArgs);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(int param1Int1, int param1Int2) {
/* 1243 */       synchronized (this.mutex) {
/* 1244 */         this.backingList.remove(param1Int1, param1Int2);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean setAll(Collection<? extends T> param1Collection) {
/* 1250 */       synchronized (this.mutex) {
/* 1251 */         return this.backingList.setAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void addListener(InvalidationListener param1InvalidationListener) {
/* 1257 */       synchronized (this.mutex) {
/* 1258 */         this.helper = ListListenerHelper.addListener(this.helper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public final void removeListener(InvalidationListener param1InvalidationListener) {
/* 1264 */       synchronized (this.mutex) {
/* 1265 */         this.helper = ListListenerHelper.removeListener(this.helper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(ListChangeListener<? super T> param1ListChangeListener) {
/* 1271 */       synchronized (this.mutex) {
/* 1272 */         this.helper = ListListenerHelper.addListener(this.helper, param1ListChangeListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(ListChangeListener<? super T> param1ListChangeListener) {
/* 1278 */       synchronized (this.mutex) {
/* 1279 */         this.helper = ListListenerHelper.removeListener(this.helper, param1ListChangeListener);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class CheckedObservableList<T>
/*      */     extends ObservableListBase<T>
/*      */     implements ObservableList<T>
/*      */   {
/*      */     private final ObservableList<T> list;
/*      */     private final Class<T> type;
/*      */     private final ListChangeListener<T> listener;
/*      */     
/*      */     CheckedObservableList(ObservableList<T> param1ObservableList, Class<T> param1Class) {
/* 1293 */       if (param1ObservableList == null || param1Class == null) {
/* 1294 */         throw new NullPointerException();
/*      */       }
/* 1296 */       this.list = param1ObservableList;
/* 1297 */       this.type = param1Class;
/* 1298 */       this.listener = (param1Change -> fireChange(new SourceAdapterChange<>(this, param1Change)));
/*      */ 
/*      */       
/* 1301 */       param1ObservableList.addListener(new WeakListChangeListener<>(this.listener));
/*      */     }
/*      */     
/*      */     void typeCheck(Object param1Object) {
/* 1305 */       if (param1Object != null && !this.type.isInstance(param1Object)) {
/* 1306 */         throw new ClassCastException("Attempt to insert " + param1Object
/* 1307 */             .getClass() + " element into collection with element type " + this.type);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 1314 */       return this.list.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1319 */       return this.list.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1324 */       return this.list.contains(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1329 */       return this.list.toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 1334 */       return (T[])this.list.toArray((Object[])param1ArrayOfT);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1339 */       return this.list.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 1344 */       return this.list.remove(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 1349 */       return this.list.containsAll(param1Collection);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 1354 */       return this.list.removeAll(param1Collection);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 1359 */       return this.list.retainAll(param1Collection);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(T... param1VarArgs) {
/* 1364 */       return this.list.removeAll(param1VarArgs);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(T... param1VarArgs) {
/* 1369 */       return this.list.retainAll(param1VarArgs);
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove(int param1Int1, int param1Int2) {
/* 1374 */       this.list.remove(param1Int1, param1Int2);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1379 */       this.list.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 1384 */       return (param1Object == this || this.list.equals(param1Object));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1389 */       return this.list.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public T get(int param1Int) {
/* 1394 */       return this.list.get(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     public T remove(int param1Int) {
/* 1399 */       return this.list.remove(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     public int indexOf(Object param1Object) {
/* 1404 */       return this.list.indexOf(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public int lastIndexOf(Object param1Object) {
/* 1409 */       return this.list.lastIndexOf(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public T set(int param1Int, T param1T) {
/* 1414 */       typeCheck(param1T);
/* 1415 */       return this.list.set(param1Int, param1T);
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(int param1Int, T param1T) {
/* 1420 */       typeCheck(param1T);
/* 1421 */       this.list.add(param1Int, param1T);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean addAll(int param1Int, Collection<? extends T> param1Collection) {
/* 1427 */       Object[] arrayOfObject = null;
/*      */       try {
/* 1429 */         arrayOfObject = param1Collection.toArray((Object[])Array.newInstance(this.type, 0));
/* 1430 */       } catch (ArrayStoreException arrayStoreException) {
/* 1431 */         throw new ClassCastException();
/*      */       } 
/*      */       
/* 1434 */       return this.list.addAll(param1Int, Arrays.asList((T[])arrayOfObject));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends T> param1Collection) {
/* 1440 */       Object[] arrayOfObject = null;
/*      */       try {
/* 1442 */         arrayOfObject = param1Collection.toArray((Object[])Array.newInstance(this.type, 0));
/* 1443 */       } catch (ArrayStoreException arrayStoreException) {
/* 1444 */         throw new ClassCastException();
/*      */       } 
/*      */       
/* 1447 */       return this.list.addAll(Arrays.asList((T[])arrayOfObject));
/*      */     }
/*      */ 
/*      */     
/*      */     public ListIterator<T> listIterator() {
/* 1452 */       return listIterator(0);
/*      */     }
/*      */ 
/*      */     
/*      */     public ListIterator<T> listIterator(final int index) {
/* 1457 */       return new ListIterator<T>()
/*      */         {
/* 1459 */           ListIterator<T> i = FXCollections.CheckedObservableList.this.list.listIterator(index);
/*      */ 
/*      */           
/*      */           public boolean hasNext() {
/* 1463 */             return this.i.hasNext();
/*      */           }
/*      */ 
/*      */           
/*      */           public T next() {
/* 1468 */             return this.i.next();
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean hasPrevious() {
/* 1473 */             return this.i.hasPrevious();
/*      */           }
/*      */ 
/*      */           
/*      */           public T previous() {
/* 1478 */             return this.i.previous();
/*      */           }
/*      */ 
/*      */           
/*      */           public int nextIndex() {
/* 1483 */             return this.i.nextIndex();
/*      */           }
/*      */ 
/*      */           
/*      */           public int previousIndex() {
/* 1488 */             return this.i.previousIndex();
/*      */           }
/*      */ 
/*      */           
/*      */           public void remove() {
/* 1493 */             this.i.remove();
/*      */           }
/*      */ 
/*      */           
/*      */           public void set(T param2T) {
/* 1498 */             FXCollections.CheckedObservableList.this.typeCheck(param2T);
/* 1499 */             this.i.set(param2T);
/*      */           }
/*      */ 
/*      */           
/*      */           public void add(T param2T) {
/* 1504 */             FXCollections.CheckedObservableList.this.typeCheck(param2T);
/* 1505 */             this.i.add(param2T);
/*      */           }
/*      */         };
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<T> iterator() {
/* 1512 */       return new Iterator<T>()
/*      */         {
/* 1514 */           private final Iterator<T> it = FXCollections.CheckedObservableList.this.list.iterator();
/*      */ 
/*      */           
/*      */           public boolean hasNext() {
/* 1518 */             return this.it.hasNext();
/*      */           }
/*      */ 
/*      */           
/*      */           public T next() {
/* 1523 */             return this.it.next();
/*      */           }
/*      */ 
/*      */           
/*      */           public void remove() {
/* 1528 */             this.it.remove();
/*      */           }
/*      */         };
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(T param1T) {
/* 1535 */       typeCheck(param1T);
/* 1536 */       return this.list.add(param1T);
/*      */     }
/*      */ 
/*      */     
/*      */     public List<T> subList(int param1Int1, int param1Int2) {
/* 1541 */       return Collections.checkedList(this.list.subList(param1Int1, param1Int2), this.type);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean addAll(T... param1VarArgs) {
/*      */       try {
/* 1548 */         Object[] arrayOfObject = (Object[])Array.newInstance(this.type, param1VarArgs.length);
/* 1549 */         System.arraycopy(param1VarArgs, 0, arrayOfObject, 0, param1VarArgs.length);
/* 1550 */         return this.list.addAll((T[])arrayOfObject);
/* 1551 */       } catch (ArrayStoreException arrayStoreException) {
/* 1552 */         throw new ClassCastException();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean setAll(T... param1VarArgs) {
/*      */       try {
/* 1560 */         Object[] arrayOfObject = (Object[])Array.newInstance(this.type, param1VarArgs.length);
/* 1561 */         System.arraycopy(param1VarArgs, 0, arrayOfObject, 0, param1VarArgs.length);
/* 1562 */         return this.list.setAll((T[])arrayOfObject);
/* 1563 */       } catch (ArrayStoreException arrayStoreException) {
/* 1564 */         throw new ClassCastException();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean setAll(Collection<? extends T> param1Collection) {
/* 1571 */       Object[] arrayOfObject = null;
/*      */       try {
/* 1573 */         arrayOfObject = param1Collection.toArray((Object[])Array.newInstance(this.type, 0));
/* 1574 */       } catch (ArrayStoreException arrayStoreException) {
/* 1575 */         throw new ClassCastException();
/*      */       } 
/*      */       
/* 1578 */       return this.list.setAll(Arrays.asList((T[])arrayOfObject));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class EmptyObservableSet<E>
/*      */     extends AbstractSet<E>
/*      */     implements ObservableSet<E>
/*      */   {
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(SetChangeListener<? super E> param1SetChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(SetChangeListener<? super E> param1SetChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 1605 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1610 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1615 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 1620 */       return param1Collection.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1625 */       return new Object[0];
/*      */     }
/*      */ 
/*      */     
/*      */     public <E> E[] toArray(E[] param1ArrayOfE) {
/* 1630 */       if (param1ArrayOfE.length > 0)
/* 1631 */         param1ArrayOfE[0] = null; 
/* 1632 */       return param1ArrayOfE;
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 1637 */       return new Iterator<E>()
/*      */         {
/*      */           public boolean hasNext()
/*      */           {
/* 1641 */             return false;
/*      */           }
/*      */ 
/*      */           
/*      */           public Object next() {
/* 1646 */             throw new NoSuchElementException();
/*      */           }
/*      */ 
/*      */           
/*      */           public void remove() {
/* 1651 */             throw new UnsupportedOperationException();
/*      */           }
/*      */         };
/*      */     }
/*      */   }
/*      */   
/*      */   private static class UnmodifiableObservableSet<E>
/*      */     extends AbstractSet<E>
/*      */     implements ObservableSet<E> {
/*      */     private final ObservableSet<E> backingSet;
/*      */     private SetListenerHelper<E> listenerHelper;
/*      */     private SetChangeListener<E> listener;
/*      */     
/*      */     public UnmodifiableObservableSet(ObservableSet<E> param1ObservableSet) {
/* 1665 */       this.backingSet = param1ObservableSet;
/* 1666 */       this.listener = null;
/*      */     }
/*      */     
/*      */     private void initListener() {
/* 1670 */       if (this.listener == null) {
/* 1671 */         this.listener = (param1Change -> callObservers(new SetAdapterChange<>(this, param1Change)));
/*      */ 
/*      */         
/* 1674 */         this.backingSet.addListener(new WeakSetChangeListener<>(this.listener));
/*      */       } 
/*      */     }
/*      */     
/*      */     private void callObservers(SetChangeListener.Change<? extends E> param1Change) {
/* 1679 */       SetListenerHelper.fireValueChangedEvent(this.listenerHelper, param1Change);
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 1684 */       return new Iterator<E>() {
/* 1685 */           private final Iterator<? extends E> i = FXCollections.UnmodifiableObservableSet.this.backingSet.iterator();
/*      */ 
/*      */           
/*      */           public boolean hasNext() {
/* 1689 */             return this.i.hasNext();
/*      */           }
/*      */ 
/*      */           
/*      */           public E next() {
/* 1694 */             return this.i.next();
/*      */           }
/*      */         };
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1701 */       return this.backingSet.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1706 */       return this.backingSet.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1711 */       return this.backingSet.contains(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 1716 */       initListener();
/* 1717 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 1722 */       this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1727 */       initListener();
/* 1728 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1SetChangeListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1733 */       this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1SetChangeListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(E param1E) {
/* 1738 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 1743 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 1748 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 1753 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 1758 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1763 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedSet<E> implements Set<E> {
/*      */     final Object mutex;
/*      */     private final Set<E> backingSet;
/*      */     
/*      */     SynchronizedSet(Set<E> param1Set, Object param1Object) {
/* 1772 */       this.backingSet = param1Set;
/* 1773 */       this.mutex = param1Object;
/*      */     }
/*      */     
/*      */     SynchronizedSet(Set<E> param1Set) {
/* 1777 */       this(param1Set, new Object());
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1782 */       synchronized (this.mutex) {
/* 1783 */         return this.backingSet.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1789 */       synchronized (this.mutex) {
/* 1790 */         return this.backingSet.isEmpty();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1796 */       synchronized (this.mutex) {
/* 1797 */         return this.backingSet.contains(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 1803 */       return this.backingSet.iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 1808 */       synchronized (this.mutex) {
/* 1809 */         return this.backingSet.toArray();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public <E> E[] toArray(E[] param1ArrayOfE) {
/* 1815 */       synchronized (this.mutex) {
/* 1816 */         return this.backingSet.toArray(param1ArrayOfE);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(E param1E) {
/* 1822 */       synchronized (this.mutex) {
/* 1823 */         return this.backingSet.add(param1E);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 1829 */       synchronized (this.mutex) {
/* 1830 */         return this.backingSet.remove(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 1836 */       synchronized (this.mutex) {
/* 1837 */         return this.backingSet.containsAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 1843 */       synchronized (this.mutex) {
/* 1844 */         return this.backingSet.addAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 1850 */       synchronized (this.mutex) {
/* 1851 */         return this.backingSet.retainAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 1857 */       synchronized (this.mutex) {
/* 1858 */         return this.backingSet.removeAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 1864 */       synchronized (this.mutex) {
/* 1865 */         this.backingSet.clear();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 1871 */       if (param1Object == this) {
/* 1872 */         return true;
/*      */       }
/* 1874 */       synchronized (this.mutex) {
/* 1875 */         return this.backingSet.equals(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 1881 */       synchronized (this.mutex) {
/* 1882 */         return this.backingSet.hashCode();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedObservableSet<E>
/*      */     extends SynchronizedSet<E> implements ObservableSet<E> {
/*      */     private final ObservableSet<E> backingSet;
/*      */     private SetListenerHelper listenerHelper;
/*      */     private final SetChangeListener<E> listener;
/*      */     
/*      */     SynchronizedObservableSet(ObservableSet<E> param1ObservableSet, Object param1Object) {
/* 1894 */       super(param1ObservableSet, param1Object);
/* 1895 */       this.backingSet = param1ObservableSet;
/* 1896 */       this.listener = (param1Change -> SetListenerHelper.fireValueChangedEvent(this.listenerHelper, new SetAdapterChange(this, param1Change)));
/*      */ 
/*      */       
/* 1899 */       this.backingSet.addListener(new WeakSetChangeListener<>(this.listener));
/*      */     }
/*      */     
/*      */     SynchronizedObservableSet(ObservableSet<E> param1ObservableSet) {
/* 1903 */       this(param1ObservableSet, new Object());
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 1908 */       synchronized (this.mutex) {
/* 1909 */         this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 1915 */       synchronized (this.mutex) {
/* 1916 */         this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void addListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1921 */       synchronized (this.mutex) {
/* 1922 */         this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1SetChangeListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1928 */       synchronized (this.mutex) {
/* 1929 */         this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1SetChangeListener);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class CheckedObservableSet<E>
/*      */     extends AbstractSet<E> implements ObservableSet<E> {
/*      */     private final ObservableSet<E> backingSet;
/*      */     private final Class<E> type;
/*      */     private SetListenerHelper listenerHelper;
/*      */     private final SetChangeListener<E> listener;
/*      */     
/*      */     CheckedObservableSet(ObservableSet<E> param1ObservableSet, Class<E> param1Class) {
/* 1942 */       if (param1ObservableSet == null || param1Class == null) {
/* 1943 */         throw new NullPointerException();
/*      */       }
/* 1945 */       this.backingSet = param1ObservableSet;
/* 1946 */       this.type = param1Class;
/* 1947 */       this.listener = (param1Change -> callObservers(new SetAdapterChange<>(this, param1Change)));
/*      */ 
/*      */       
/* 1950 */       this.backingSet.addListener(new WeakSetChangeListener<>(this.listener));
/*      */     }
/*      */     
/*      */     private void callObservers(SetChangeListener.Change<? extends E> param1Change) {
/* 1954 */       SetListenerHelper.fireValueChangedEvent(this.listenerHelper, param1Change);
/*      */     }
/*      */     
/*      */     void typeCheck(Object param1Object) {
/* 1958 */       if (param1Object != null && !this.type.isInstance(param1Object)) {
/* 1959 */         throw new ClassCastException("Attempt to insert " + param1Object
/* 1960 */             .getClass() + " element into collection with element type " + this.type);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 1967 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 1972 */       this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1977 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, param1SetChangeListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(SetChangeListener<? super E> param1SetChangeListener) {
/* 1982 */       this.listenerHelper = SetListenerHelper.removeListener(this.listenerHelper, param1SetChangeListener);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1987 */       return this.backingSet.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1992 */       return this.backingSet.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 1997 */       return this.backingSet.contains(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 2002 */       return this.backingSet.toArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 2007 */       return (T[])this.backingSet.toArray((Object[])param1ArrayOfT);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(E param1E) {
/* 2012 */       typeCheck(param1E);
/* 2013 */       return this.backingSet.add(param1E);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 2018 */       return this.backingSet.remove(param1Object);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 2023 */       return this.backingSet.containsAll(param1Collection);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 2029 */       Object[] arrayOfObject = null;
/*      */       try {
/* 2031 */         arrayOfObject = param1Collection.toArray((Object[])Array.newInstance(this.type, 0));
/* 2032 */       } catch (ArrayStoreException arrayStoreException) {
/* 2033 */         throw new ClassCastException();
/*      */       } 
/*      */       
/* 2036 */       return this.backingSet.addAll(Arrays.asList((E[])arrayOfObject));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 2041 */       return this.backingSet.retainAll(param1Collection);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 2046 */       return this.backingSet.removeAll(param1Collection);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2051 */       this.backingSet.clear();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 2056 */       return (param1Object == this || this.backingSet.equals(param1Object));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2061 */       return this.backingSet.hashCode();
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 2066 */       final Iterator<E> it = this.backingSet.iterator();
/*      */       
/* 2068 */       return new Iterator<E>()
/*      */         {
/*      */           public boolean hasNext() {
/* 2071 */             return it.hasNext();
/*      */           }
/*      */ 
/*      */           
/*      */           public E next() {
/* 2076 */             return it.next();
/*      */           }
/*      */ 
/*      */           
/*      */           public void remove() {
/* 2081 */             it.remove();
/*      */           }
/*      */         };
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class EmptyObservableMap<K, V>
/*      */     extends AbstractMap<K, V>
/*      */     implements ObservableMap<K, V>
/*      */   {
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {}
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 2111 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 2116 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object param1Object) {
/* 2121 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsValue(Object param1Object) {
/* 2126 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public V get(Object param1Object) {
/* 2131 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<K> keySet() {
/* 2136 */       return FXCollections.emptyObservableSet();
/*      */     }
/*      */ 
/*      */     
/*      */     public Collection<V> values() {
/* 2141 */       return FXCollections.emptyObservableSet();
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<K, V>> entrySet() {
/* 2146 */       return FXCollections.emptyObservableSet();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 2151 */       return (param1Object instanceof Map && ((Map)param1Object).isEmpty());
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2156 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class CheckedObservableMap<K, V>
/*      */     extends AbstractMap<K, V>
/*      */     implements ObservableMap<K, V>
/*      */   {
/*      */     private final ObservableMap<K, V> backingMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<K> keyType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<V> valueType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MapListenerHelper listenerHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MapChangeListener<K, V> listener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Set<Map.Entry<K, V>> entrySet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void callObservers(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/*      */       MapListenerHelper.fireValueChangedEvent(this.listenerHelper, param1Change);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void typeCheck(Object param1Object1, Object param1Object2) {
/*      */       if (param1Object1 != null && !this.keyType.isInstance(param1Object1)) {
/*      */         throw new ClassCastException("Attempt to insert " + param1Object1.getClass() + " key into map with key type " + this.keyType);
/*      */       }
/*      */       if (param1Object2 != null && !this.valueType.isInstance(param1Object2)) {
/*      */         throw new ClassCastException("Attempt to insert " + param1Object2.getClass() + " value into map with value type " + this.valueType);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/*      */       this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/*      */       this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, param1InvalidationListener);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CheckedObservableMap(ObservableMap<K, V> param1ObservableMap, Class<K> param1Class, Class<V> param1Class1) {
/* 2290 */       this.entrySet = null; this.backingMap = param1ObservableMap; this.keyType = param1Class; this.valueType = param1Class1; this.listener = (param1Change -> callObservers(new MapAdapterChange<>(this, param1Change))); this.backingMap.addListener(new WeakMapChangeListener<>(this.listener));
/*      */     } public void addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) { this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, param1MapChangeListener); } public void removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) { this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, param1MapChangeListener); }
/*      */     public int size() { return this.backingMap.size(); }
/*      */     public boolean isEmpty() { return this.backingMap.isEmpty(); }
/* 2294 */     public Set entrySet() { if (this.entrySet == null)
/* 2295 */         this.entrySet = new CheckedEntrySet<>(this.backingMap.entrySet(), this.valueType); 
/* 2296 */       return this.entrySet; } public boolean containsKey(Object param1Object) { return this.backingMap.containsKey(param1Object); }
/*      */     public boolean containsValue(Object param1Object) { return this.backingMap.containsValue(param1Object); }
/*      */     public V get(Object param1Object) { return this.backingMap.get(param1Object); }
/*      */     public V put(K param1K, V param1V) { typeCheck(param1K, param1V);
/*      */       return this.backingMap.put(param1K, param1V); }
/* 2301 */     public boolean equals(Object param1Object) { return (param1Object == this || this.backingMap.equals(param1Object)); }
/*      */     public V remove(Object param1Object) { return this.backingMap.remove(param1Object); }
/*      */     public void putAll(Map param1Map) { Object[] arrayOfObject = param1Map.entrySet().toArray(); ArrayList arrayList = new ArrayList(arrayOfObject.length); for (Object object1 : arrayOfObject) {
/*      */         Map.Entry entry = (Map.Entry)object1; Object object2 = entry.getKey(); Object object3 = entry.getValue(); typeCheck(object2, object3); arrayList.add(new AbstractMap.SimpleImmutableEntry<>(object2, object3));
/*      */       }  for (Map.Entry entry : arrayList)
/* 2306 */         this.backingMap.put((K)entry.getKey(), (V)entry.getValue());  } public int hashCode() { return this.backingMap.hashCode(); }
/*      */      public void clear() {
/*      */       this.backingMap.clear();
/*      */     } public Set<K> keySet() {
/*      */       return this.backingMap.keySet();
/*      */     } public Collection<V> values() {
/*      */       return this.backingMap.values();
/*      */     } static class CheckedEntrySet<K, V> implements Set<Map.Entry<K, V>> { private final Set<Map.Entry<K, V>> s; private final Class<V> valueType; CheckedEntrySet(Set<Map.Entry<K, V>> param2Set, Class<V> param2Class) {
/* 2314 */         this.s = param2Set;
/* 2315 */         this.valueType = param2Class;
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/* 2320 */         return this.s.size();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isEmpty() {
/* 2325 */         return this.s.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public String toString() {
/* 2330 */         return this.s.toString();
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 2335 */         return this.s.hashCode();
/*      */       }
/*      */ 
/*      */       
/*      */       public void clear() {
/* 2340 */         this.s.clear();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean add(Map.Entry<K, V> param2Entry) {
/* 2345 */         throw new UnsupportedOperationException();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean addAll(Collection<? extends Map.Entry<K, V>> param2Collection) {
/* 2350 */         throw new UnsupportedOperationException();
/*      */       }
/*      */ 
/*      */       
/*      */       public Iterator<Map.Entry<K, V>> iterator() {
/* 2355 */         final Iterator<Map.Entry<K, V>> i = this.s.iterator();
/* 2356 */         final Class<V> valueType = this.valueType;
/*      */         
/* 2358 */         return new Iterator<Map.Entry<K, V>>()
/*      */           {
/*      */             public boolean hasNext() {
/* 2361 */               return i.hasNext();
/*      */             }
/*      */ 
/*      */             
/*      */             public void remove() {
/* 2366 */               i.remove();
/*      */             }
/*      */ 
/*      */             
/*      */             public Map.Entry<K, V> next() {
/* 2371 */               return FXCollections.CheckedObservableMap.CheckedEntrySet.checkedEntry(i.next(), valueType);
/*      */             }
/*      */           };
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public Object[] toArray() {
/* 2379 */         Object[] arrayOfObject1 = this.s.toArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2387 */         Object[] arrayOfObject2 = CheckedEntry.class.isInstance(arrayOfObject1.getClass().getComponentType()) ? arrayOfObject1 : new Object[arrayOfObject1.length];
/*      */         
/* 2389 */         for (byte b = 0; b < arrayOfObject1.length; b++) {
/* 2390 */           arrayOfObject2[b] = checkedEntry((Map.Entry<?, ?>)arrayOfObject1[b], this.valueType);
/*      */         }
/* 2392 */         return arrayOfObject2;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public <T> T[] toArray(T[] param2ArrayOfT) {
/* 2401 */         Object[] arrayOfObject = this.s.toArray((param2ArrayOfT.length == 0) ? (Object[])param2ArrayOfT : Arrays.<Object>copyOf((Object[])param2ArrayOfT, 0));
/*      */         
/* 2403 */         for (byte b = 0; b < arrayOfObject.length; b++) {
/* 2404 */           arrayOfObject[b] = checkedEntry((Map.Entry<?, ?>)arrayOfObject[b], this.valueType);
/*      */         }
/* 2406 */         if (arrayOfObject.length > param2ArrayOfT.length) {
/* 2407 */           return (T[])arrayOfObject;
/*      */         }
/* 2409 */         System.arraycopy(arrayOfObject, 0, param2ArrayOfT, 0, arrayOfObject.length);
/* 2410 */         if (param2ArrayOfT.length > arrayOfObject.length)
/* 2411 */           param2ArrayOfT[arrayOfObject.length] = null; 
/* 2412 */         return param2ArrayOfT;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean contains(Object param2Object) {
/* 2423 */         if (!(param2Object instanceof Map.Entry))
/* 2424 */           return false; 
/* 2425 */         Map.Entry<?, ?> entry = (Map.Entry)param2Object;
/* 2426 */         return this.s.contains(
/* 2427 */             (entry instanceof CheckedEntry) ? entry : checkedEntry(entry, this.valueType));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean containsAll(Collection<?> param2Collection) {
/* 2437 */         for (Object object : param2Collection) {
/* 2438 */           if (!contains(object))
/* 2439 */             return false; 
/* 2440 */         }  return true;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean remove(Object param2Object) {
/* 2445 */         if (!(param2Object instanceof Map.Entry))
/* 2446 */           return false; 
/* 2447 */         return this.s.remove(new AbstractMap.SimpleImmutableEntry<>((Map.Entry<?, ?>)param2Object));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean removeAll(Collection<?> param2Collection) {
/* 2453 */         return batchRemove(param2Collection, false);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean retainAll(Collection<?> param2Collection) {
/* 2458 */         return batchRemove(param2Collection, true);
/*      */       }
/*      */       
/*      */       private boolean batchRemove(Collection<?> param2Collection, boolean param2Boolean) {
/* 2462 */         boolean bool = false;
/* 2463 */         Iterator<Map.Entry<K, V>> iterator = iterator();
/* 2464 */         while (iterator.hasNext()) {
/* 2465 */           if (param2Collection.contains(iterator.next()) != param2Boolean) {
/* 2466 */             iterator.remove();
/* 2467 */             bool = true;
/*      */           } 
/*      */         } 
/* 2470 */         return bool;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(Object param2Object) {
/* 2475 */         if (param2Object == this)
/* 2476 */           return true; 
/* 2477 */         if (!(param2Object instanceof Set))
/* 2478 */           return false; 
/* 2479 */         Set<?> set = (Set)param2Object;
/* 2480 */         return (set.size() == this.s.size() && 
/* 2481 */           containsAll(set));
/*      */       }
/*      */ 
/*      */       
/*      */       static <K, V, T> CheckedEntry<K, V, T> checkedEntry(Map.Entry<K, V> param2Entry, Class<T> param2Class) {
/* 2486 */         return new CheckedEntry<>(param2Entry, param2Class);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       private static class CheckedEntry<K, V, T>
/*      */         implements Map.Entry<K, V>
/*      */       {
/*      */         private final Map.Entry<K, V> e;
/*      */ 
/*      */         
/*      */         private final Class<T> valueType;
/*      */ 
/*      */         
/*      */         CheckedEntry(Map.Entry<K, V> param3Entry, Class<T> param3Class) {
/* 2501 */           this.e = param3Entry;
/* 2502 */           this.valueType = param3Class;
/*      */         }
/*      */ 
/*      */         
/*      */         public K getKey() {
/* 2507 */           return this.e.getKey();
/*      */         }
/*      */ 
/*      */         
/*      */         public V getValue() {
/* 2512 */           return this.e.getValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/* 2517 */           return this.e.hashCode();
/*      */         }
/*      */ 
/*      */         
/*      */         public String toString() {
/* 2522 */           return this.e.toString();
/*      */         }
/*      */ 
/*      */         
/*      */         public V setValue(V param3V) {
/* 2527 */           if (param3V != null && !this.valueType.isInstance(param3V))
/* 2528 */             throw new ClassCastException(badValueMsg(param3V)); 
/* 2529 */           return this.e.setValue(param3V);
/*      */         }
/*      */         
/*      */         private String badValueMsg(Object param3Object) {
/* 2533 */           return "Attempt to insert " + param3Object.getClass() + " value into map with value type " + this.valueType;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(Object param3Object) {
/* 2539 */           if (param3Object == this)
/* 2540 */             return true; 
/* 2541 */           if (!(param3Object instanceof Map.Entry))
/* 2542 */             return false; 
/* 2543 */           return this.e.equals(new AbstractMap.SimpleImmutableEntry<>((Map.Entry<?, ?>)param3Object));
/*      */         }
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class SynchronizedMap<K, V>
/*      */     implements Map<K, V>
/*      */   {
/*      */     final Object mutex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Map<K, V> backingMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Set<K> keySet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Set<Map.Entry<K, V>> entrySet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Collection<V> values;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SynchronizedMap(Map<K, V> param1Map) {
/*      */       this(param1Map, new Object());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*      */       synchronized (this.mutex) {
/*      */         return this.backingMap.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*      */       synchronized (this.mutex) {
/*      */         return this.backingMap.isEmpty();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SynchronizedMap(Map<K, V> param1Map, Object param1Object) {
/* 2627 */       this.keySet = null;
/* 2628 */       this.entrySet = null;
/* 2629 */       this.values = null; this.backingMap = param1Map; this.mutex = param1Object;
/*      */     } public boolean containsKey(Object param1Object) { synchronized (this.mutex) { return this.backingMap.containsKey(param1Object); }
/*      */        } public boolean containsValue(Object param1Object) { synchronized (this.mutex) { return this.backingMap.containsValue(param1Object); }
/*      */        }
/* 2633 */     public Set<K> keySet() { synchronized (this.mutex)
/* 2634 */       { if (this.keySet == null)
/* 2635 */           this.keySet = new FXCollections.SynchronizedSet<>(this.backingMap.keySet(), this.mutex); 
/* 2636 */         return this.keySet; }  } public V get(Object param1Object) { synchronized (this.mutex) { return this.backingMap.get(param1Object); }  }
/*      */     public V put(K param1K, V param1V) { synchronized (this.mutex) { return this.backingMap.put(param1K, param1V); }  }
/*      */     public V remove(Object param1Object) { synchronized (this.mutex) { return this.backingMap.remove(param1Object); }  }
/*      */     public void putAll(Map<? extends K, ? extends V> param1Map) { synchronized (this.mutex) { this.backingMap.putAll(param1Map); }  }
/*      */     public void clear() { synchronized (this.mutex) { this.backingMap.clear(); }
/*      */        }
/* 2642 */     public Collection<V> values() { synchronized (this.mutex) {
/* 2643 */         if (this.values == null)
/* 2644 */           this.values = new FXCollections.SynchronizedCollection<>(this.backingMap.values(), this.mutex); 
/* 2645 */         return this.values;
/*      */       }  }
/*      */ 
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<K, V>> entrySet() {
/* 2651 */       synchronized (this.mutex) {
/* 2652 */         if (this.entrySet == null)
/* 2653 */           this.entrySet = new FXCollections.SynchronizedSet<>(this.backingMap.entrySet(), this.mutex); 
/* 2654 */         return this.entrySet;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 2660 */       if (param1Object == this) {
/* 2661 */         return true;
/*      */       }
/* 2663 */       synchronized (this.mutex) {
/* 2664 */         return this.backingMap.equals(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2670 */       synchronized (this.mutex) {
/* 2671 */         return this.backingMap.hashCode();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedCollection<E>
/*      */     implements Collection<E>
/*      */   {
/*      */     private final Collection<E> backingCollection;
/*      */     final Object mutex;
/*      */     
/*      */     SynchronizedCollection(Collection<E> param1Collection, Object param1Object) {
/* 2683 */       this.backingCollection = param1Collection;
/* 2684 */       this.mutex = param1Object;
/*      */     }
/*      */     
/*      */     SynchronizedCollection(Collection<E> param1Collection) {
/* 2688 */       this(param1Collection, new Object());
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 2693 */       synchronized (this.mutex) {
/* 2694 */         return this.backingCollection.size();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 2700 */       synchronized (this.mutex) {
/* 2701 */         return this.backingCollection.isEmpty();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean contains(Object param1Object) {
/* 2707 */       synchronized (this.mutex) {
/* 2708 */         return this.backingCollection.contains(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public Iterator<E> iterator() {
/* 2714 */       return this.backingCollection.iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object[] toArray() {
/* 2719 */       synchronized (this.mutex) {
/* 2720 */         return this.backingCollection.toArray();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 2726 */       synchronized (this.mutex) {
/* 2727 */         return this.backingCollection.toArray(param1ArrayOfT);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean add(E param1E) {
/* 2733 */       synchronized (this.mutex) {
/* 2734 */         return this.backingCollection.add(param1E);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean remove(Object param1Object) {
/* 2740 */       synchronized (this.mutex) {
/* 2741 */         return this.backingCollection.remove(param1Object);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsAll(Collection<?> param1Collection) {
/* 2747 */       synchronized (this.mutex) {
/* 2748 */         return this.backingCollection.containsAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 2754 */       synchronized (this.mutex) {
/* 2755 */         return this.backingCollection.addAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean removeAll(Collection<?> param1Collection) {
/* 2761 */       synchronized (this.mutex) {
/* 2762 */         return this.backingCollection.removeAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean retainAll(Collection<?> param1Collection) {
/* 2768 */       synchronized (this.mutex) {
/* 2769 */         return this.backingCollection.retainAll(param1Collection);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/* 2775 */       synchronized (this.mutex) {
/* 2776 */         this.backingCollection.clear();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SynchronizedObservableMap<K, V>
/*      */     extends SynchronizedMap<K, V> implements ObservableMap<K, V> {
/*      */     private final ObservableMap<K, V> backingMap;
/*      */     private MapListenerHelper listenerHelper;
/*      */     private final MapChangeListener<K, V> listener;
/*      */     
/*      */     SynchronizedObservableMap(ObservableMap<K, V> param1ObservableMap, Object param1Object) {
/* 2788 */       super(param1ObservableMap, param1Object);
/* 2789 */       this.backingMap = param1ObservableMap;
/* 2790 */       this.listener = (param1Change -> MapListenerHelper.fireValueChangedEvent(this.listenerHelper, new MapAdapterChange<>(this, param1Change)));
/*      */ 
/*      */       
/* 2793 */       this.backingMap.addListener(new WeakMapChangeListener<>(this.listener));
/*      */     }
/*      */     
/*      */     SynchronizedObservableMap(ObservableMap<K, V> param1ObservableMap) {
/* 2797 */       this(param1ObservableMap, new Object());
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(InvalidationListener param1InvalidationListener) {
/* 2802 */       synchronized (this.mutex) {
/* 2803 */         this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(InvalidationListener param1InvalidationListener) {
/* 2809 */       synchronized (this.mutex) {
/* 2810 */         this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, param1InvalidationListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 2816 */       synchronized (this.mutex) {
/* 2817 */         this.listenerHelper = MapListenerHelper.addListener(this.listenerHelper, param1MapChangeListener);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 2823 */       synchronized (this.mutex) {
/* 2824 */         this.listenerHelper = MapListenerHelper.removeListener(this.listenerHelper, param1MapChangeListener);
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\FXCollections.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */