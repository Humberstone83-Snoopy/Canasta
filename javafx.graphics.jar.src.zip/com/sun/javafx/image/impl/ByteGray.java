/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteGray
/*     */ {
/*  40 */   public static final BytePixelGetter getter = Accessor.instance;
/*  41 */   public static final BytePixelSetter setter = Accessor.instance;
/*  42 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   private static ByteToBytePixelConverter ToByteGrayObj;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteGrayConverter() {
/*  46 */     if (ToByteGrayObj == null) {
/*  47 */       ToByteGrayObj = BaseByteToByteConverter.create(accessor);
/*     */     }
/*  49 */     return ToByteGrayObj;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  53 */     return ToByteBgrfConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/*  57 */     return ToByteBgrfConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbConverter() {
/*  61 */     return ToIntFrgbConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbPreConverter() {
/*  65 */     return ToIntFrgbConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgrConverter() {
/*  69 */     return ToByteRgbAnyConv.bgr;
/*     */   }
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  73 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  78 */       return AlphaType.OPAQUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  83 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  88 */       int i = param1ArrayOfbyte[param1Int] & 0xFF;
/*  89 */       return 0xFF000000 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  94 */       int i = param1ArrayOfbyte[param1Int] & 0xFF;
/*  95 */       return 0xFF000000 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/* 100 */       int i = param1ByteBuffer.get(param1Int) & 0xFF;
/* 101 */       return 0xFF000000 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 106 */       int i = param1ByteBuffer.get(param1Int) & 0xFF;
/* 107 */       return 0xFF000000 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 112 */       param1ArrayOfbyte[param1Int1] = (byte)PixelUtils.RgbToGray(param1Int2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 117 */       setArgb(param1ArrayOfbyte, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 122 */       param1ByteBuffer.put(param1Int1, (byte)PixelUtils.RgbToGray(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 127 */       setArgb(param1ByteBuffer, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgrfConv extends BaseByteToByteConverter {
/* 132 */     public static final ByteToBytePixelConverter nonpremult = new ToByteBgrfConv(ByteBgra.setter);
/*     */     
/* 134 */     public static final ByteToBytePixelConverter premult = new ToByteBgrfConv(ByteBgraPre.setter);
/*     */ 
/*     */     
/*     */     ToByteBgrfConv(BytePixelSetter param1BytePixelSetter) {
/* 138 */       super(ByteGray.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 146 */       param1Int4 -= param1Int5 * 4;
/* 147 */       while (--param1Int6 >= 0) {
/* 148 */         for (byte b = 0; b < param1Int5; b++) {
/* 149 */           byte b1 = param1ArrayOfbyte1[param1Int1 + b];
/* 150 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 151 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 152 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 153 */           param1ArrayOfbyte2[param1Int3++] = -1;
/*     */         } 
/* 155 */         param1Int1 += param1Int2;
/* 156 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 165 */       param1Int4 -= param1Int5 * 4;
/* 166 */       while (--param1Int6 >= 0) {
/* 167 */         for (byte b = 0; b < param1Int5; b++) {
/* 168 */           byte b1 = param1ByteBuffer1.get(param1Int1 + b);
/* 169 */           param1ByteBuffer2.put(param1Int3, b1);
/* 170 */           param1ByteBuffer2.put(param1Int3 + 1, b1);
/* 171 */           param1ByteBuffer2.put(param1Int3 + 2, b1);
/* 172 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)-1);
/* 173 */           param1Int3 += 4;
/*     */         } 
/* 175 */         param1Int1 += param1Int2;
/* 176 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntFrgbConv extends BaseByteToIntConverter {
/* 182 */     public static final ByteToIntPixelConverter nonpremult = new ToIntFrgbConv(IntArgb.setter);
/*     */     
/* 184 */     public static final ByteToIntPixelConverter premult = new ToIntFrgbConv(IntArgbPre.setter);
/*     */ 
/*     */     
/*     */     private ToIntFrgbConv(IntPixelSetter param1IntPixelSetter) {
/* 188 */       super(ByteGray.getter, param1IntPixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 196 */       while (--param1Int6 >= 0) {
/* 197 */         for (byte b = 0; b < param1Int5; b++) {
/* 198 */           int i = param1ArrayOfbyte[param1Int1 + b] & 0xFF;
/* 199 */           param1ArrayOfint[param1Int3 + b] = 0xFF000000 | i << 16 | i << 8 | i;
/*     */         } 
/* 201 */         param1Int1 += param1Int2;
/* 202 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 211 */       while (--param1Int6 >= 0) {
/* 212 */         for (byte b = 0; b < param1Int5; b++) {
/* 213 */           int i = param1ByteBuffer.get(param1Int1 + b) & 0xFF;
/* 214 */           param1IntBuffer.put(param1Int3 + b, 0xFF000000 | i << 16 | i << 8 | i);
/*     */         } 
/* 216 */         param1Int1 += param1Int2;
/* 217 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteRgbAnyConv extends BaseByteToByteConverter {
/* 223 */     static ToByteRgbAnyConv bgr = new ToByteRgbAnyConv(ByteBgr.setter);
/*     */     
/*     */     private ToByteRgbAnyConv(BytePixelSetter param1BytePixelSetter) {
/* 226 */       super(ByteGray.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 234 */       param1Int4 -= param1Int5 * 3;
/* 235 */       while (--param1Int6 >= 0) {
/* 236 */         for (byte b = 0; b < param1Int5; b++) {
/* 237 */           int i = param1ArrayOfbyte1[param1Int1 + b] & 0xFF;
/* 238 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/* 239 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/* 240 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/*     */         } 
/* 242 */         param1Int1 += param1Int2;
/* 243 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 252 */       param1Int4 -= param1Int5 * 3;
/* 253 */       while (--param1Int6 >= 0) {
/* 254 */         for (byte b = 0; b < param1Int5; b++) {
/* 255 */           int i = param1ByteBuffer1.get(param1Int1 + b) & 0xFF;
/* 256 */           param1ByteBuffer2.put(param1Int3++, (byte)i);
/* 257 */           param1ByteBuffer2.put(param1Int3++, (byte)i);
/* 258 */           param1ByteBuffer2.put(param1Int3++, (byte)i);
/*     */         } 
/* 260 */         param1Int1 += param1Int2;
/* 261 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteGray.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */