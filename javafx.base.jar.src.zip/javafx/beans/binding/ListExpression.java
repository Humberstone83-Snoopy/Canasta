/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.StringFormatter;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.value.ObservableIntegerValue;
/*     */ import javafx.beans.value.ObservableListValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListExpression<E>
/*     */   implements ObservableListValue<E>
/*     */ {
/*  58 */   private static final ObservableList EMPTY_LIST = FXCollections.emptyObservableList();
/*     */ 
/*     */   
/*     */   public ObservableList<E> getValue() {
/*  62 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> ListExpression<E> listExpression(final ObservableListValue<E> value) {
/*  82 */     if (value == null) {
/*  83 */       throw new NullPointerException("List must be specified.");
/*     */     }
/*  85 */     return (value instanceof ListExpression) ? (ListExpression<E>)value : 
/*  86 */       new ListBinding<E>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/*  93 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected ObservableList<E> computeValue() {
/*  98 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableListValue<E>> getDependencies() {
/* 103 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 113 */     return size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectBinding<E> valueAt(int paramInt) {
/* 138 */     return Bindings.valueAt(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectBinding<E> valueAt(ObservableIntegerValue paramObservableIntegerValue) {
/* 150 */     return Bindings.valueAt(this, paramObservableIntegerValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(ObservableList<?> paramObservableList) {
/* 164 */     return Bindings.equal(this, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(ObservableList<?> paramObservableList) {
/* 178 */     return Bindings.notEqual(this, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNull() {
/* 187 */     return Bindings.isNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotNull() {
/* 196 */     return Bindings.isNotNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBinding asString() {
/* 208 */     return (StringBinding)StringFormatter.convert(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 213 */     ObservableList<E> observableList = get();
/* 214 */     return (observableList == null) ? EMPTY_LIST.size() : observableList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 219 */     ObservableList<E> observableList = get();
/* 220 */     return (observableList == null) ? EMPTY_LIST.isEmpty() : observableList.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 225 */     ObservableList<E> observableList = get();
/* 226 */     return (observableList == null) ? EMPTY_LIST.contains(paramObject) : observableList.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 231 */     ObservableList<E> observableList = get();
/* 232 */     return (observableList == null) ? EMPTY_LIST.iterator() : observableList.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 237 */     ObservableList<E> observableList = get();
/* 238 */     return (observableList == null) ? EMPTY_LIST.toArray() : observableList.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 243 */     ObservableList<E> observableList = get();
/* 244 */     return (observableList == null) ? (T[])EMPTY_LIST.toArray((Object[])paramArrayOfT) : (T[])observableList.toArray((Object[])paramArrayOfT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E paramE) {
/* 249 */     ObservableList<E> observableList = get();
/* 250 */     return (observableList == null) ? EMPTY_LIST.add(paramE) : observableList.add(paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 255 */     ObservableList<E> observableList = get();
/* 256 */     return (observableList == null) ? EMPTY_LIST.remove(paramObject) : observableList.remove(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 261 */     ObservableList<E> observableList = get();
/* 262 */     return (observableList == null) ? EMPTY_LIST.contains(paramCollection) : observableList.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 267 */     ObservableList<E> observableList = get();
/* 268 */     return (observableList == null) ? EMPTY_LIST.addAll(paramCollection) : observableList.addAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 273 */     ObservableList<E> observableList = get();
/* 274 */     return (observableList == null) ? EMPTY_LIST.addAll(paramInt, paramCollection) : observableList.addAll(paramInt, paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 279 */     ObservableList<E> observableList = get();
/* 280 */     return (observableList == null) ? EMPTY_LIST.removeAll(paramCollection) : observableList.removeAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 285 */     ObservableList<E> observableList = get();
/* 286 */     return (observableList == null) ? EMPTY_LIST.retainAll(paramCollection) : observableList.retainAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 291 */     ObservableList<E> observableList = get();
/* 292 */     if (observableList == null) {
/* 293 */       EMPTY_LIST.clear();
/*     */     } else {
/* 295 */       observableList.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 301 */     ObservableList<E> observableList = get();
/* 302 */     return (observableList == null) ? EMPTY_LIST.get(paramInt) : observableList.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 307 */     ObservableList<E> observableList = get();
/* 308 */     return (observableList == null) ? EMPTY_LIST.set(paramInt, paramE) : observableList.set(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 313 */     ObservableList<E> observableList = get();
/* 314 */     if (observableList == null) {
/* 315 */       EMPTY_LIST.add(paramInt, paramE);
/*     */     } else {
/* 317 */       observableList.add(paramInt, paramE);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int paramInt) {
/* 323 */     ObservableList<E> observableList = get();
/* 324 */     return (observableList == null) ? EMPTY_LIST.remove(paramInt) : observableList.remove(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 329 */     ObservableList<E> observableList = get();
/* 330 */     return (observableList == null) ? EMPTY_LIST.indexOf(paramObject) : observableList.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 335 */     ObservableList<E> observableList = get();
/* 336 */     return (observableList == null) ? EMPTY_LIST.lastIndexOf(paramObject) : observableList.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 341 */     ObservableList<E> observableList = get();
/* 342 */     return (observableList == null) ? EMPTY_LIST.listIterator() : observableList.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int paramInt) {
/* 347 */     ObservableList<E> observableList = get();
/* 348 */     return (observableList == null) ? EMPTY_LIST.listIterator(paramInt) : observableList.listIterator(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int paramInt1, int paramInt2) {
/* 353 */     ObservableList<E> observableList = get();
/* 354 */     return (observableList == null) ? EMPTY_LIST.subList(paramInt1, paramInt2) : observableList.subList(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 359 */     ObservableList<E> observableList = get();
/* 360 */     return (observableList == null) ? EMPTY_LIST.addAll(paramVarArgs) : observableList.addAll(paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 365 */     ObservableList<E> observableList = get();
/* 366 */     return (observableList == null) ? EMPTY_LIST.setAll(paramVarArgs) : observableList.setAll(paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 371 */     ObservableList<E> observableList = get();
/* 372 */     return (observableList == null) ? EMPTY_LIST.setAll(paramCollection) : observableList.setAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 377 */     ObservableList<E> observableList = get();
/* 378 */     return (observableList == null) ? EMPTY_LIST.removeAll(paramVarArgs) : observableList.removeAll(paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 383 */     ObservableList<E> observableList = get();
/* 384 */     return (observableList == null) ? EMPTY_LIST.retainAll(paramVarArgs) : observableList.retainAll(paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 389 */     ObservableList<E> observableList = get();
/* 390 */     if (observableList == null) {
/* 391 */       EMPTY_LIST.remove(paramInt1, paramInt2);
/*     */     } else {
/* 393 */       observableList.remove(paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract ReadOnlyIntegerProperty sizeProperty();
/*     */   
/*     */   public abstract ReadOnlyBooleanProperty emptyProperty();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\ListExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */