/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogicalFont
/*     */   implements CompositeFontResource
/*     */ {
/*     */   public static final String SYSTEM = "System";
/*     */   public static final String SERIF = "Serif";
/*     */   public static final String SANS_SERIF = "SansSerif";
/*     */   public static final String MONOSPACED = "Monospaced";
/*     */   public static final String STYLE_REGULAR = "Regular";
/*     */   public static final String STYLE_BOLD = "Bold";
/*     */   public static final String STYLE_ITALIC = "Italic";
/*     */   public static final String STYLE_BOLD_ITALIC = "Bold Italic";
/*  54 */   static final HashMap<String, String> canonicalFamilyMap = new HashMap<>();
/*     */   static {
/*  56 */     canonicalFamilyMap.put("system", "System");
/*     */     
/*  58 */     canonicalFamilyMap.put("serif", "Serif");
/*     */     
/*  60 */     canonicalFamilyMap.put("sansserif", "SansSerif");
/*  61 */     canonicalFamilyMap.put("sans-serif", "SansSerif");
/*  62 */     canonicalFamilyMap.put("dialog", "SansSerif");
/*  63 */     canonicalFamilyMap.put("default", "SansSerif");
/*     */     
/*  65 */     canonicalFamilyMap.put("monospaced", "Monospaced");
/*  66 */     canonicalFamilyMap.put("monospace", "Monospaced");
/*  67 */     canonicalFamilyMap.put("dialoginput", "Monospaced");
/*     */   }
/*     */   
/*     */   static boolean isLogicalFont(String paramString) {
/*  71 */     int i = paramString.indexOf(' ');
/*  72 */     if (i != -1) paramString = paramString.substring(0, i); 
/*  73 */     return (canonicalFamilyMap.get(paramString) != null);
/*     */   }
/*     */   
/*     */   private static String getCanonicalFamilyName(String paramString) {
/*  77 */     if (paramString == null) {
/*  78 */       return "SansSerif";
/*     */     }
/*  80 */     String str = paramString.toLowerCase();
/*  81 */     return canonicalFamilyMap.get(str);
/*     */   }
/*     */   
/*  84 */   static LogicalFont[] logicalFonts = new LogicalFont[16]; boolean isBold; boolean isItalic; private String fullName; private String familyName; private String styleName; private String physicalFamily; private String physicalFullName; private String physicalFileName; private FontResource slot0FontResource; private ArrayList<String> linkedFontFiles; private ArrayList<String> linkedFontNames; private FontResource[] fallbacks; private FontResource[] nativeFallbacks; CompositeGlyphMapper mapper; Map<FontStrikeDesc, WeakReference<FontStrike>> strikeMap; private static final int SANS_SERIF_INDEX = 0; private static final int SERIF_INDEX = 1;
/*     */   private static final int MONOSPACED_INDEX = 2;
/*     */   private static final int SYSTEM_INDEX = 3;
/*     */   
/*     */   static PGFont getLogicalFont(String paramString, boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
/*  89 */     String str = getCanonicalFamilyName(paramString);
/*  90 */     if (str == null) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     byte b = 0;
/*  95 */     if (str.equals("SansSerif")) {
/*  96 */       b = 0;
/*  97 */     } else if (str.equals("Serif")) {
/*  98 */       b = 4;
/*  99 */     } else if (str.equals("Monospaced")) {
/* 100 */       b = 8;
/*     */     } else {
/* 102 */       b = 12;
/*     */     } 
/* 104 */     if (paramBoolean1) {
/* 105 */       b++;
/*     */     }
/* 107 */     if (paramBoolean2) {
/* 108 */       b += 2;
/*     */     }
/*     */     
/* 111 */     LogicalFont logicalFont = logicalFonts[b];
/* 112 */     if (logicalFont == null) {
/* 113 */       logicalFont = new LogicalFont(str, paramBoolean1, paramBoolean2);
/* 114 */       logicalFonts[b] = logicalFont;
/*     */     } 
/* 116 */     return new PrismFont(logicalFont, logicalFont.getFullName(), paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static PGFont getLogicalFont(String paramString, float paramFloat) {
/* 130 */     int i = paramString.indexOf(' ');
/* 131 */     if (i == -1 || i == paramString.length() - 1) {
/* 132 */       return null;
/*     */     }
/* 134 */     String str1 = paramString.substring(0, i);
/* 135 */     String str2 = getCanonicalFamilyName(str1);
/* 136 */     if (str2 == null) {
/* 137 */       return null;
/*     */     }
/* 139 */     String str3 = paramString.substring(i + 1).toLowerCase();
/* 140 */     boolean bool1 = false, bool2 = false;
/* 141 */     if (!str3.equals("regular"))
/*     */     {
/* 143 */       if (str3.equals("bold")) {
/* 144 */         bool1 = true;
/* 145 */       } else if (str3.equals("italic")) {
/* 146 */         bool2 = true;
/* 147 */       } else if (str3.equals("bold italic")) {
/* 148 */         bool1 = true;
/* 149 */         bool2 = true;
/*     */       } else {
/* 151 */         return null;
/*     */       }  } 
/* 153 */     return getLogicalFont(str2, bool1, bool2, paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LogicalFont(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 401 */     this.strikeMap = new ConcurrentHashMap<>(); this.familyName = paramString; this.isBold = paramBoolean1; this.isItalic = paramBoolean2; if (!paramBoolean1 && !paramBoolean2) { this.styleName = "Regular"; } else if (paramBoolean1 && !paramBoolean2) { this.styleName = "Bold"; } else if (!paramBoolean1 && paramBoolean2) { this.styleName = "Italic"; } else { this.styleName = "Bold Italic"; }  this.fullName = this.familyName + " " + this.familyName; if (PrismFontFactory.isLinux) { FontConfigManager.FcCompFont fcCompFont = FontConfigManager.getFontConfigFont(paramString, paramBoolean1, paramBoolean2); this.physicalFullName = fcCompFont.firstFont.fullName; this.physicalFileName = fcCompFont.firstFont.fontFile; } else { this.physicalFamily = PrismFontFactory.getSystemFont(this.familyName); } 
/*     */   }
/*     */   private FontResource getSlot0Resource() { if (this.slot0FontResource == null) { PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory(); if (this.physicalFamily != null) { this.slot0FontResource = prismFontFactory.getFontResource(this.physicalFamily, this.isBold, this.isItalic, false); } else { this.slot0FontResource = prismFontFactory.getFontResource(this.physicalFullName, this.physicalFileName, false); }  if (this.slot0FontResource == null) this.slot0FontResource = prismFontFactory.getDefaultFontResource(false);  }  return this.slot0FontResource; }
/*     */   private void getLinkedFonts() { if (this.fallbacks == null) { if (PrismFontFactory.isLinux) { FontConfigManager.FcCompFont fcCompFont = FontConfigManager.getFontConfigFont(this.familyName, this.isBold, this.isItalic); this.linkedFontFiles = FontConfigManager.getFileNames(fcCompFont, true); this.linkedFontNames = FontConfigManager.getFontNames(fcCompFont, true); } else { ArrayList[] arrayOfArrayList = (ArrayList[])PrismFontFactory.getLinkedFonts("Tahoma", true); this.linkedFontFiles = arrayOfArrayList[0]; this.linkedFontNames = arrayOfArrayList[1]; }  this.fallbacks = new FontResource[this.linkedFontFiles.size()]; }  }
/* 405 */   public int getNumSlots() { getLinkedFonts(); int i = this.linkedFontFiles.size(); if (this.nativeFallbacks != null) i += this.nativeFallbacks.length;  return i + 1; } public int getSlotForFont(String paramString) { FontResource[] arrayOfFontResource; getLinkedFonts(); byte b = 1; for (String str : this.linkedFontNames) { if (paramString.equalsIgnoreCase(str)) return b;  b++; }  if (this.nativeFallbacks != null) for (FontResource fontResource1 : this.nativeFallbacks) { if (paramString.equalsIgnoreCase(fontResource1.getFullName())) return b;  b++; }   if (b >= 126) { if (PrismFontFactory.debugFonts) System.err.println("\tToo many font fallbacks!");  return -1; }  PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory(); FontResource fontResource = prismFontFactory.getFontResource(paramString, null, false); if (fontResource == null) { if (PrismFontFactory.debugFonts) System.err.println("\t Font name not supported \"" + paramString + "\".");  return -1; }  if (this.nativeFallbacks == null) { arrayOfFontResource = new FontResource[1]; } else { arrayOfFontResource = new FontResource[this.nativeFallbacks.length + 1]; System.arraycopy(this.nativeFallbacks, 0, arrayOfFontResource, 0, this.nativeFallbacks.length); }  arrayOfFontResource[arrayOfFontResource.length - 1] = fontResource; this.nativeFallbacks = arrayOfFontResource; return b; } public FontResource getSlotResource(int paramInt) { if (paramInt == 0) return getSlot0Resource();  getLinkedFonts(); paramInt--; if (paramInt >= this.fallbacks.length) { paramInt -= this.fallbacks.length; if (this.nativeFallbacks == null || paramInt >= this.nativeFallbacks.length) return null;  return this.nativeFallbacks[paramInt]; }  if (this.fallbacks[paramInt] == null) { String str1 = this.linkedFontFiles.get(paramInt); String str2 = this.linkedFontNames.get(paramInt); this.fallbacks[paramInt] = PrismFontFactory.getFontFactory().getFontResource(str2, str1, false); if (this.fallbacks[paramInt] == null) this.fallbacks[paramInt] = getSlot0Resource();  }  return this.fallbacks[paramInt]; } public String getFullName() { return this.fullName; } public String getPSName() { return this.fullName; } public String getFamilyName() { return this.familyName; } public String getStyleName() { return this.styleName; } public String getLocaleFullName() { return this.fullName; } public String getLocaleFamilyName() { return this.familyName; } public Map<FontStrikeDesc, WeakReference<FontStrike>> getStrikeMap() { return this.strikeMap; }
/*     */   public String getLocaleStyleName() { return this.styleName; }
/*     */   public boolean isBold() { return getSlotResource(0).isBold(); }
/*     */   public boolean isItalic() { return getSlotResource(0).isItalic(); }
/* 409 */   public String getFileName() { return getSlotResource(0).getFileName(); } public int getFeatures() { return getSlotResource(0).getFeatures(); } public Object getPeer() { return null; } public boolean isEmbeddedFont() { return getSlotResource(0).isEmbeddedFont(); } public void setPeer(Object paramObject) { throw new UnsupportedOperationException("Not supported"); } public float[] getGlyphBoundingBox(int paramInt, float paramFloat, float[] paramArrayOffloat) { int i = paramInt >>> 24; int j = paramInt & 0xFFFFFF; FontResource fontResource = getSlotResource(i); return fontResource.getGlyphBoundingBox(j, paramFloat, paramArrayOffloat); } public float getAdvance(int paramInt, float paramFloat) { int i = paramInt >>> 24; int j = paramInt & 0xFFFFFF; FontResource fontResource = getSlotResource(i); return fontResource.getAdvance(j, paramFloat); } public CharToGlyphMapper getGlyphMapper() { if (this.mapper == null) this.mapper = new CompositeGlyphMapper(this);  return this.mapper; } public int getDefaultAAMode() { return getSlot0Resource().getDefaultAAMode(); }
/*     */ 
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform) {
/* 413 */     return getStrike(paramFloat, paramBaseTransform, getDefaultAAMode());
/*     */   }
/*     */ 
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt) {
/* 418 */     FontStrikeDesc fontStrikeDesc = new FontStrikeDesc(paramFloat, paramBaseTransform, paramInt);
/* 419 */     WeakReference<CompositeStrike> weakReference = (WeakReference)this.strikeMap.get(fontStrikeDesc);
/* 420 */     CompositeStrike compositeStrike = null;
/*     */     
/* 422 */     if (weakReference != null) {
/* 423 */       compositeStrike = weakReference.get();
/*     */     }
/* 425 */     if (compositeStrike == null) {
/* 426 */       compositeStrike = new CompositeStrike(this, paramFloat, paramBaseTransform, paramInt, fontStrikeDesc);
/* 427 */       if (compositeStrike.disposer != null) {
/* 428 */         weakReference = Disposer.addRecord(compositeStrike, compositeStrike.disposer);
/*     */       } else {
/* 430 */         weakReference = new WeakReference<>(compositeStrike);
/*     */       } 
/* 432 */       this.strikeMap.put(fontStrikeDesc, weakReference);
/*     */     } 
/* 434 */     return compositeStrike;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 443 */   static String[][] logFamilies = null; private int hash;
/*     */   
/*     */   private static void buildFamily(String[] paramArrayOfString, String paramString) {
/* 446 */     paramArrayOfString[0] = paramString + " Regular";
/* 447 */     paramArrayOfString[1] = paramString + " Bold";
/* 448 */     paramArrayOfString[2] = paramString + " Italic";
/* 449 */     paramArrayOfString[3] = paramString + " Bold Italic";
/*     */   }
/*     */   
/*     */   private static void buildFamilies() {
/* 453 */     if (logFamilies == null) {
/* 454 */       String[][] arrayOfString = new String[4][4];
/* 455 */       buildFamily(arrayOfString[0], "SansSerif");
/* 456 */       buildFamily(arrayOfString[1], "Serif");
/* 457 */       buildFamily(arrayOfString[2], "Monospaced");
/* 458 */       buildFamily(arrayOfString[3], "System");
/* 459 */       logFamilies = arrayOfString;
/*     */     } 
/*     */   }
/*     */   
/*     */   static void addFamilies(ArrayList<String> paramArrayList) {
/* 464 */     paramArrayList.add("SansSerif");
/* 465 */     paramArrayList.add("Serif");
/* 466 */     paramArrayList.add("Monospaced");
/* 467 */     paramArrayList.add("System");
/*     */   }
/*     */   
/*     */   static void addFullNames(ArrayList<String> paramArrayList) {
/* 471 */     buildFamilies();
/* 472 */     for (byte b = 0; b < logFamilies.length; b++) {
/* 473 */       for (byte b1 = 0; b1 < (logFamilies[b]).length; b1++) {
/* 474 */         paramArrayList.add(logFamilies[b][b1]);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static String[] getFontsInFamily(String paramString) {
/* 480 */     String str = getCanonicalFamilyName(paramString);
/* 481 */     if (str == null) {
/* 482 */       return null;
/*     */     }
/* 484 */     buildFamilies();
/* 485 */     if (str.equals("SansSerif"))
/* 486 */       return logFamilies[0]; 
/* 487 */     if (str.equals("Serif"))
/* 488 */       return logFamilies[1]; 
/* 489 */     if (str.equals("Monospaced")) {
/* 490 */       return logFamilies[2];
/*     */     }
/* 492 */     return logFamilies[3];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 498 */     if (paramObject == null) {
/* 499 */       return false;
/*     */     }
/* 501 */     if (!(paramObject instanceof LogicalFont)) {
/* 502 */       return false;
/*     */     }
/* 504 */     LogicalFont logicalFont = (LogicalFont)paramObject;
/*     */     
/* 506 */     return this.fullName.equals(logicalFont.fullName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 512 */     if (this.hash != 0) {
/* 513 */       return this.hash;
/*     */     }
/*     */     
/* 516 */     this.hash = this.fullName.hashCode();
/* 517 */     return this.hash;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\LogicalFont.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */