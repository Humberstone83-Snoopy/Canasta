/*     */ package com.sun.javafx.font.coretext;
/*     */ 
/*     */ import com.sun.javafx.font.CompositeFontResource;
/*     */ import com.sun.javafx.font.CompositeStrike;
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CTGlyphLayout
/*     */   extends GlyphLayout
/*     */ {
/*     */   private long createCTLine(long paramLong, char[] paramArrayOfchar, boolean paramBoolean, int paramInt1, int paramInt2) {
/*  41 */     long l1 = OS.kCFAllocatorDefault();
/*  42 */     long l2 = OS.CFStringCreateWithCharacters(l1, paramArrayOfchar, paramInt1, paramInt2);
/*  43 */     long l3 = 0L;
/*  44 */     if (l2 != 0L) {
/*  45 */       long l = OS.CFDictionaryCreateMutable(l1, 4L, 
/*  46 */           OS.kCFTypeDictionaryKeyCallBacks(), 
/*  47 */           OS.kCFTypeDictionaryValueCallBacks());
/*  48 */       if (l != 0L) {
/*  49 */         OS.CFDictionaryAddValue(l, OS.kCTFontAttributeName(), paramLong);
/*  50 */         if (paramBoolean) {
/*  51 */           long l5 = OS.CTParagraphStyleCreate(1);
/*  52 */           if (l5 != 0L) {
/*  53 */             OS.CFDictionaryAddValue(l, OS.kCTParagraphStyleAttributeName(), l5);
/*  54 */             OS.CFRelease(l5);
/*     */           } 
/*     */         } 
/*     */         
/*  58 */         long l4 = OS.CFAttributedStringCreate(l1, l2, l);
/*  59 */         if (l4 != 0L) {
/*  60 */           l3 = OS.CTLineCreateWithAttributedString(l4);
/*  61 */           OS.CFRelease(l4);
/*     */         } 
/*  63 */         OS.CFRelease(l);
/*     */       } 
/*  65 */       OS.CFRelease(l2);
/*     */     } 
/*  67 */     return l3;
/*     */   }
/*     */   
/*     */   private int getFontSlot(long paramLong, CompositeFontResource paramCompositeFontResource, String paramString, int paramInt) {
/*  71 */     long l1 = OS.CTRunGetAttributes(paramLong);
/*  72 */     if (l1 == 0L) return -1; 
/*  73 */     long l2 = OS.CFDictionaryGetValue(l1, OS.kCTFontAttributeName());
/*  74 */     if (l2 == 0L) return -1;
/*     */ 
/*     */ 
/*     */     
/*  78 */     String str = OS.CTFontCopyAttributeDisplayName(l2);
/*  79 */     if (str == null) return -1; 
/*  80 */     if (!str.equalsIgnoreCase(paramString)) {
/*  81 */       if (paramCompositeFontResource == null) return -1; 
/*  82 */       paramInt = paramCompositeFontResource.getSlotForFont(str);
/*  83 */       if (PrismFontFactory.debugFonts) {
/*  84 */         System.err.println("\tFallback font= " + str + " slot=" + paramInt);
/*     */       }
/*     */     } 
/*  87 */     return paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void layout(TextRun paramTextRun, PGFont paramPGFont, FontStrike paramFontStrike, char[] paramArrayOfchar) {
/*  92 */     int i = 0;
/*  93 */     CompositeFontResource compositeFontResource = null;
/*  94 */     if (paramFontStrike instanceof CompositeStrike) {
/*  95 */       compositeFontResource = (CompositeFontResource)paramFontStrike.getFontResource();
/*  96 */       i = getInitialSlot(compositeFontResource);
/*  97 */       paramFontStrike = ((CompositeStrike)paramFontStrike).getStrikeSlot(i);
/*     */     } 
/*  99 */     float f = paramFontStrike.getSize();
/* 100 */     String str = paramFontStrike.getFontResource().getFullName();
/* 101 */     long l1 = ((CTFontStrike)paramFontStrike).getFontRef();
/* 102 */     if (l1 == 0L)
/* 103 */       return;  boolean bool = ((paramTextRun.getLevel() & 0x1) != 0) ? true : false;
/* 104 */     long l2 = createCTLine(l1, paramArrayOfchar, bool, paramTextRun.getStart(), paramTextRun.getLength());
/* 105 */     if (l2 == 0L)
/* 106 */       return;  long l3 = OS.CTLineGetGlyphRuns(l2);
/* 107 */     if (l3 != 0L) {
/* 108 */       int j = (int)OS.CTLineGetGlyphCount(l2);
/* 109 */       int[] arrayOfInt1 = new int[j];
/* 110 */       float[] arrayOfFloat = new float[j * 2 + 2];
/* 111 */       int[] arrayOfInt2 = new int[j];
/* 112 */       long l = OS.CFArrayGetCount(l3);
/* 113 */       int k = 0, m = 0, n = 0;
/* 114 */       for (byte b = 0; b < l; b++) {
/* 115 */         long l4 = OS.CFArrayGetValueAtIndex(l3, b);
/* 116 */         if (l4 != 0L) {
/* 117 */           int i1 = getFontSlot(l4, compositeFontResource, str, i);
/* 118 */           if (i1 != -1) {
/* 119 */             k += OS.CTRunGetGlyphs(l4, i1 << 24, k, arrayOfInt1);
/*     */           } else {
/* 121 */             k += OS.CTRunGetGlyphs(l4, 0, k, arrayOfInt1);
/*     */           } 
/* 123 */           if (f > 0.0F) {
/* 124 */             m += OS.CTRunGetPositions(l4, m, arrayOfFloat);
/*     */           }
/* 126 */           n += OS.CTRunGetStringIndices(l4, n, arrayOfInt2);
/*     */         } 
/*     */       } 
/* 129 */       if (f > 0.0F) {
/* 130 */         arrayOfFloat[m] = (float)OS.CTLineGetTypographicBounds(l2);
/*     */       }
/* 132 */       paramTextRun.shape(j, arrayOfInt1, arrayOfFloat, arrayOfInt2);
/*     */     } 
/* 134 */     OS.CFRelease(l2);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CTGlyphLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */