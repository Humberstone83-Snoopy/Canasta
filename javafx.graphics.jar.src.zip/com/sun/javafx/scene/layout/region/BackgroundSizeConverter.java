/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.Size;
/*    */ import javafx.css.SizeUnits;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.css.converter.BooleanConverter;
/*    */ import javafx.scene.layout.BackgroundSize;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BackgroundSizeConverter
/*    */   extends StyleConverter<ParsedValue[], BackgroundSize>
/*    */ {
/* 39 */   private static final BackgroundSizeConverter BACKGROUND_SIZE_CONVERTER = new BackgroundSizeConverter();
/*    */ 
/*    */   
/*    */   public static BackgroundSizeConverter getInstance() {
/* 43 */     return BACKGROUND_SIZE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BackgroundSize convert(ParsedValue<ParsedValue[], BackgroundSize> paramParsedValue, Font paramFont) {
/* 51 */     ParsedValue[] arrayOfParsedValue = paramParsedValue.getValue();
/*    */ 
/*    */ 
/*    */     
/* 55 */     Size size1 = (arrayOfParsedValue[0] != null) ? arrayOfParsedValue[0].convert(paramFont) : null;
/*    */     
/* 57 */     Size size2 = (arrayOfParsedValue[1] != null) ? arrayOfParsedValue[1].convert(paramFont) : null;
/*    */     
/* 59 */     boolean bool1 = true;
/* 60 */     boolean bool2 = true;
/*    */     
/* 62 */     if (size1 != null) {
/* 63 */       bool1 = (size1.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     }
/* 65 */     if (size2 != null)
/*    */     {
/* 67 */       bool2 = (size2.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     }
/*    */     
/* 70 */     double d1 = (size1 != null) ? size1.pixels(paramFont) : -1.0D;
/* 71 */     double d2 = (size2 != null) ? size2.pixels(paramFont) : -1.0D;
/*    */ 
/*    */     
/* 74 */     boolean bool3 = (arrayOfParsedValue[2] != null) ? ((Boolean)BooleanConverter.getInstance().convert(arrayOfParsedValue[2], paramFont)).booleanValue() : false;
/*    */ 
/*    */     
/* 77 */     boolean bool4 = (arrayOfParsedValue[3] != null) ? ((Boolean)BooleanConverter.getInstance().convert(arrayOfParsedValue[3], paramFont)).booleanValue() : false;
/*    */     
/* 79 */     return new BackgroundSize(d1, d2, bool1, bool2, bool4, bool3);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "BackgroundSizeConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BackgroundSizeConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */