/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.events.EventListener;
/*     */ import org.w3c.dom.html.HTMLFrameSetElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLFrameSetElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLFrameSetElement
/*     */ {
/*     */   HTMLFrameSetElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLFrameSetElement getImpl(long paramLong) {
/*  37 */     return (HTMLFrameSetElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getColsImpl(long paramLong);
/*     */   
/*     */   public String getCols() {
/*  43 */     return getColsImpl(getPeer());
/*     */   }
/*     */   static native void setColsImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setCols(String paramString) {
/*  48 */     setColsImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRows() {
/*  53 */     return getRowsImpl(getPeer());
/*     */   }
/*     */   static native String getRowsImpl(long paramLong);
/*     */   
/*     */   public void setRows(String paramString) {
/*  58 */     setRowsImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRowsImpl(long paramLong, String paramString);
/*     */   
/*     */   public EventListener getOnblur() {
/*  63 */     return EventListenerImpl.getImpl(getOnblurImpl(getPeer()));
/*     */   }
/*     */   static native long getOnblurImpl(long paramLong);
/*     */   
/*     */   public void setOnblur(EventListener paramEventListener) {
/*  68 */     setOnblurImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnblurImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnerror() {
/*  73 */     return EventListenerImpl.getImpl(getOnerrorImpl(getPeer()));
/*     */   }
/*     */   static native long getOnerrorImpl(long paramLong);
/*     */   
/*     */   public void setOnerror(EventListener paramEventListener) {
/*  78 */     setOnerrorImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnerrorImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocus() {
/*  83 */     return EventListenerImpl.getImpl(getOnfocusImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusImpl(long paramLong);
/*     */   
/*     */   public void setOnfocus(EventListener paramEventListener) {
/*  88 */     setOnfocusImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocusin() {
/*  93 */     return EventListenerImpl.getImpl(getOnfocusinImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusinImpl(long paramLong);
/*     */   
/*     */   public void setOnfocusin(EventListener paramEventListener) {
/*  98 */     setOnfocusinImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusinImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnfocusout() {
/* 103 */     return EventListenerImpl.getImpl(getOnfocusoutImpl(getPeer()));
/*     */   }
/*     */   static native long getOnfocusoutImpl(long paramLong);
/*     */   
/*     */   public void setOnfocusout(EventListener paramEventListener) {
/* 108 */     setOnfocusoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnfocusoutImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnload() {
/* 113 */     return EventListenerImpl.getImpl(getOnloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnloadImpl(long paramLong);
/*     */   
/*     */   public void setOnload(EventListener paramEventListener) {
/* 118 */     setOnloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnloadImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnresize() {
/* 123 */     return EventListenerImpl.getImpl(getOnresizeImpl(getPeer()));
/*     */   }
/*     */   static native long getOnresizeImpl(long paramLong);
/*     */   
/*     */   public void setOnresize(EventListener paramEventListener) {
/* 128 */     setOnresizeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnresizeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnscroll() {
/* 133 */     return EventListenerImpl.getImpl(getOnscrollImpl(getPeer()));
/*     */   }
/*     */   static native long getOnscrollImpl(long paramLong);
/*     */   
/*     */   public void setOnscroll(EventListener paramEventListener) {
/* 138 */     setOnscrollImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnscrollImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnbeforeunload() {
/* 143 */     return EventListenerImpl.getImpl(getOnbeforeunloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnbeforeunloadImpl(long paramLong);
/*     */   
/*     */   public void setOnbeforeunload(EventListener paramEventListener) {
/* 148 */     setOnbeforeunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnbeforeunloadImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnhashchange() {
/* 153 */     return EventListenerImpl.getImpl(getOnhashchangeImpl(getPeer()));
/*     */   }
/*     */   static native long getOnhashchangeImpl(long paramLong);
/*     */   
/*     */   public void setOnhashchange(EventListener paramEventListener) {
/* 158 */     setOnhashchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnhashchangeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnmessage() {
/* 163 */     return EventListenerImpl.getImpl(getOnmessageImpl(getPeer()));
/*     */   }
/*     */   static native long getOnmessageImpl(long paramLong);
/*     */   
/*     */   public void setOnmessage(EventListener paramEventListener) {
/* 168 */     setOnmessageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnmessageImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnoffline() {
/* 173 */     return EventListenerImpl.getImpl(getOnofflineImpl(getPeer()));
/*     */   }
/*     */   static native long getOnofflineImpl(long paramLong);
/*     */   
/*     */   public void setOnoffline(EventListener paramEventListener) {
/* 178 */     setOnofflineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnofflineImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnonline() {
/* 183 */     return EventListenerImpl.getImpl(getOnonlineImpl(getPeer()));
/*     */   }
/*     */   static native long getOnonlineImpl(long paramLong);
/*     */   
/*     */   public void setOnonline(EventListener paramEventListener) {
/* 188 */     setOnonlineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnonlineImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpagehide() {
/* 193 */     return EventListenerImpl.getImpl(getOnpagehideImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpagehideImpl(long paramLong);
/*     */   
/*     */   public void setOnpagehide(EventListener paramEventListener) {
/* 198 */     setOnpagehideImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpagehideImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpageshow() {
/* 203 */     return EventListenerImpl.getImpl(getOnpageshowImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpageshowImpl(long paramLong);
/*     */   
/*     */   public void setOnpageshow(EventListener paramEventListener) {
/* 208 */     setOnpageshowImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpageshowImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnpopstate() {
/* 213 */     return EventListenerImpl.getImpl(getOnpopstateImpl(getPeer()));
/*     */   }
/*     */   static native long getOnpopstateImpl(long paramLong);
/*     */   
/*     */   public void setOnpopstate(EventListener paramEventListener) {
/* 218 */     setOnpopstateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnpopstateImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnstorage() {
/* 223 */     return EventListenerImpl.getImpl(getOnstorageImpl(getPeer()));
/*     */   }
/*     */   static native long getOnstorageImpl(long paramLong);
/*     */   
/*     */   public void setOnstorage(EventListener paramEventListener) {
/* 228 */     setOnstorageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   static native void setOnstorageImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public EventListener getOnunload() {
/* 233 */     return EventListenerImpl.getImpl(getOnunloadImpl(getPeer()));
/*     */   }
/*     */   static native long getOnunloadImpl(long paramLong);
/*     */   
/*     */   public void setOnunload(EventListener paramEventListener) {
/* 238 */     setOnunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*     */   }
/*     */   
/*     */   static native void setOnunloadImpl(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLFrameSetElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */