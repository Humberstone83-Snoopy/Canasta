/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ import javafx.css.CssMetaData;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.css.Styleable;
/*    */ import javafx.css.StyleableProperty;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubCssMetaData<T>
/*    */   extends CssMetaData<Node, T>
/*    */ {
/*    */   public SubCssMetaData(String paramString, StyleConverter<?, T> paramStyleConverter, T paramT) {
/* 38 */     super(paramString, paramStyleConverter, paramT);
/*    */   }
/*    */   
/*    */   public SubCssMetaData(String paramString, StyleConverter<?, T> paramStyleConverter) {
/* 42 */     super(paramString, paramStyleConverter);
/*    */   }
/*    */   
/* 45 */   public boolean isSettable(Node paramNode) { return false; } public StyleableProperty<T> getStyleableProperty(Node paramNode) {
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\SubCssMetaData.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */