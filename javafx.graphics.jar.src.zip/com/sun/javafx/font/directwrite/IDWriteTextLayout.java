/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteTextLayout
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteTextLayout(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int Draw(long paramLong, JFXTextRenderer paramJFXTextRenderer, float paramFloat1, float paramFloat2) {
/* 34 */     return OS.Draw(this.ptr, paramLong, paramJFXTextRenderer.ptr, paramFloat1, paramFloat2);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteTextLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */