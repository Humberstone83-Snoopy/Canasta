/*     */ package javafx.collections;
/*     */ 
/*     */ import com.sun.javafx.collections.ListListenerHelper;
/*     */ import java.util.AbstractList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ObservableListBase<E>
/*     */   extends AbstractList<E>
/*     */   implements ObservableList<E>
/*     */ {
/*     */   private ListListenerHelper<E> listenerHelper;
/*  94 */   private final ListChangeBuilder<E> changeBuilder = new ListChangeBuilder<>(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextUpdate(int paramInt) {
/* 103 */     this.changeBuilder.nextUpdate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextSet(int paramInt, E paramE) {
/* 115 */     this.changeBuilder.nextSet(paramInt, paramE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextReplace(int paramInt1, int paramInt2, List<? extends E> paramList) {
/* 128 */     this.changeBuilder.nextReplace(paramInt1, paramInt2, paramList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextRemove(int paramInt, List<? extends E> paramList) {
/* 139 */     this.changeBuilder.nextRemove(paramInt, paramList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextRemove(int paramInt, E paramE) {
/* 150 */     this.changeBuilder.nextRemove(paramInt, paramE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextPermutation(int paramInt1, int paramInt2, int[] paramArrayOfint) {
/* 166 */     this.changeBuilder.nextPermutation(paramInt1, paramInt2, paramArrayOfint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void nextAdd(int paramInt1, int paramInt2) {
/* 179 */     this.changeBuilder.nextAdd(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void beginChange() {
/* 192 */     this.changeBuilder.beginChange();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void endChange() {
/* 205 */     this.changeBuilder.endChange();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void addListener(InvalidationListener paramInvalidationListener) {
/* 210 */     this.listenerHelper = ListListenerHelper.addListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void removeListener(InvalidationListener paramInvalidationListener) {
/* 215 */     this.listenerHelper = ListListenerHelper.removeListener(this.listenerHelper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void addListener(ListChangeListener<? super E> paramListChangeListener) {
/* 220 */     this.listenerHelper = ListListenerHelper.addListener(this.listenerHelper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void removeListener(ListChangeListener<? super E> paramListChangeListener) {
/* 225 */     this.listenerHelper = ListListenerHelper.removeListener(this.listenerHelper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void fireChange(ListChangeListener.Change<? extends E> paramChange) {
/* 233 */     ListListenerHelper.fireValueChangedEvent(this.listenerHelper, paramChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean hasListeners() {
/* 241 */     return ListListenerHelper.hasListeners(this.listenerHelper);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 246 */     return addAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 251 */     return setAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 256 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 261 */     return removeAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 266 */     return retainAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 271 */     removeRange(paramInt1, paramInt2);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\ObservableListBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */