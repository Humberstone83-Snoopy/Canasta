/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLCollectionImpl
/*     */   implements HTMLCollection
/*     */ {
/*     */   private final long peer;
/*     */   private static final int TYPE_HTMLOptionsCollection = 1;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  37 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  40 */       HTMLCollectionImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   HTMLCollectionImpl(long paramLong) {
/*  45 */     this.peer = paramLong;
/*  46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static HTMLCollection create(long paramLong) {
/*  50 */     if (paramLong == 0L) return null; 
/*  51 */     switch (getCPPTypeImpl(paramLong)) { case 1:
/*  52 */         return new HTMLOptionsCollectionImpl(paramLong); }
/*     */     
/*  54 */     return new HTMLCollectionImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  60 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  64 */     return (paramObject instanceof HTMLCollectionImpl && this.peer == ((HTMLCollectionImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  68 */     long l = this.peer;
/*  69 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(HTMLCollection paramHTMLCollection) {
/*  73 */     return (paramHTMLCollection == null) ? 0L : ((HTMLCollectionImpl)paramHTMLCollection).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static HTMLCollection getImpl(long paramLong) {
/*  82 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  88 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node item(int paramInt) {
/*  96 */     return NodeImpl.getImpl(itemImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node namedItem(String paramString) {
/* 105 */     return NodeImpl.getImpl(namedItemImpl(getPeer(), paramString));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   private static native int getCPPTypeImpl(long paramLong);
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   static native long itemImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native long namedItemImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLCollectionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */