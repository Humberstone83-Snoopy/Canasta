/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConcentricShapePair
/*     */   extends ShapePair
/*     */ {
/*     */   private final Shape outer;
/*     */   private final Shape inner;
/*     */   
/*     */   public ConcentricShapePair(Shape paramShape1, Shape paramShape2) {
/*  46 */     this.outer = paramShape1;
/*  47 */     this.inner = paramShape2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCombinationType() {
/*  52 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getOuterShape() {
/*  57 */     return this.outer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getInnerShape() {
/*  62 */     return this.inner;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape copy() {
/*  67 */     return new ConcentricShapePair(this.outer.copy(), this.inner.copy());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/*  72 */     return (this.outer.contains(paramFloat1, paramFloat2) && !this.inner.contains(paramFloat1, paramFloat2));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  77 */     return (this.outer.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && !this.inner.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  82 */     return (this.outer.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && !this.inner.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/*  87 */     return this.outer.getBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/*  92 */     return new PairIterator(this.outer.getPathIterator(paramBaseTransform), this.inner
/*  93 */         .getPathIterator(paramBaseTransform));
/*     */   }
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/*  98 */     return new PairIterator(this.outer.getPathIterator(paramBaseTransform, paramFloat), this.inner
/*  99 */         .getPathIterator(paramBaseTransform, paramFloat));
/*     */   }
/*     */   
/*     */   static class PairIterator implements PathIterator {
/*     */     PathIterator outer;
/*     */     PathIterator inner;
/*     */     
/*     */     PairIterator(PathIterator param1PathIterator1, PathIterator param1PathIterator2) {
/* 107 */       this.outer = param1PathIterator1;
/* 108 */       this.inner = param1PathIterator2;
/*     */     }
/*     */     
/*     */     public int getWindingRule() {
/* 112 */       return 0;
/*     */     }
/*     */     
/*     */     public int currentSegment(float[] param1ArrayOffloat) {
/* 116 */       if (this.outer.isDone()) {
/* 117 */         return this.inner.currentSegment(param1ArrayOffloat);
/*     */       }
/* 119 */       return this.outer.currentSegment(param1ArrayOffloat);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDone() {
/* 124 */       return (this.outer.isDone() && this.inner.isDone());
/*     */     }
/*     */     
/*     */     public void next() {
/* 128 */       if (this.outer.isDone()) {
/* 129 */         this.inner.next();
/*     */       } else {
/* 131 */         this.outer.next();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\ConcentricShapePair.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */