/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.views.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyboardEventImpl
/*     */   extends UIEventImpl
/*     */ {
/*     */   public static final int KEY_LOCATION_STANDARD = 0;
/*     */   public static final int KEY_LOCATION_LEFT = 1;
/*     */   public static final int KEY_LOCATION_RIGHT = 2;
/*     */   public static final int KEY_LOCATION_NUMPAD = 3;
/*     */   
/*     */   KeyboardEventImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static KeyboardEventImpl getImpl(long paramLong) {
/*  36 */     return (KeyboardEventImpl)create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native String getKeyIdentifierImpl(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKeyIdentifier() {
/*  48 */     return getKeyIdentifierImpl(getPeer());
/*     */   }
/*     */   static native int getLocationImpl(long paramLong);
/*     */   
/*     */   public int getLocation() {
/*  53 */     return getLocationImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKeyLocation() {
/*  58 */     return getKeyLocationImpl(getPeer());
/*     */   }
/*     */   static native int getKeyLocationImpl(long paramLong);
/*     */   
/*     */   public boolean getCtrlKey() {
/*  63 */     return getCtrlKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getCtrlKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getShiftKey() {
/*  68 */     return getShiftKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getShiftKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getAltKey() {
/*  73 */     return getAltKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getAltKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getMetaKey() {
/*  78 */     return getMetaKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getMetaKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getAltGraphKey() {
/*  83 */     return getAltGraphKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getAltGraphKeyImpl(long paramLong);
/*     */   
/*     */   public int getKeyCode() {
/*  88 */     return getKeyCodeImpl(getPeer());
/*     */   }
/*     */   static native int getKeyCodeImpl(long paramLong);
/*     */   
/*     */   public int getCharCode() {
/*  93 */     return getCharCodeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native int getCharCodeImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public boolean getModifierState(String paramString) {
/* 101 */     return getModifierStateImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native boolean getModifierStateImpl(long paramLong, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initKeyboardEvent(String paramString1, boolean paramBoolean1, boolean paramBoolean2, AbstractView paramAbstractView, String paramString2, int paramInt, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7) {
/* 120 */     initKeyboardEventImpl(getPeer(), paramString1, paramBoolean1, paramBoolean2, 
/*     */ 
/*     */ 
/*     */         
/* 124 */         DOMWindowImpl.getPeer(paramAbstractView), paramString2, paramInt, paramBoolean3, paramBoolean4, paramBoolean5, paramBoolean6, paramBoolean7);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void initKeyboardEventImpl(long paramLong1, String paramString1, boolean paramBoolean1, boolean paramBoolean2, long paramLong2, String paramString2, int paramInt, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initKeyboardEventEx(String paramString1, boolean paramBoolean1, boolean paramBoolean2, AbstractView paramAbstractView, String paramString2, int paramInt, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
/* 158 */     initKeyboardEventExImpl(getPeer(), paramString1, paramBoolean1, paramBoolean2, 
/*     */ 
/*     */ 
/*     */         
/* 162 */         DOMWindowImpl.getPeer(paramAbstractView), paramString2, paramInt, paramBoolean3, paramBoolean4, paramBoolean5, paramBoolean6);
/*     */   }
/*     */   
/*     */   static native void initKeyboardEventExImpl(long paramLong1, String paramString1, boolean paramBoolean1, boolean paramBoolean2, long paramLong2, String paramString2, int paramInt, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\KeyboardEventImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */