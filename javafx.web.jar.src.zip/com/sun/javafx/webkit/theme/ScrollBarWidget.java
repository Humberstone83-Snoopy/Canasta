/*    */ package com.sun.javafx.webkit.theme;
/*    */ 
/*    */ import com.sun.webkit.graphics.ScrollBarTheme;
/*    */ import javafx.geometry.Orientation;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.ScrollBar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ScrollBarWidget
/*    */   extends ScrollBar
/*    */   implements RenderThemeImpl.Widget
/*    */ {
/*    */   private ScrollBarThemeImpl sbtImpl;
/*    */   private boolean thicknessInitialized;
/*    */   
/*    */   static {
/* 35 */     ScrollBarWidgetHelper.setScrollBarWidgetAccessor(new ScrollBarWidgetHelper.ScrollBarWidgetAccessor()
/*    */         {
/*    */           public void doUpdatePeer(Node param1Node) {
/* 38 */             ((ScrollBarWidget)param1Node).doUpdatePeer();
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScrollBarWidget(ScrollBarThemeImpl paramScrollBarThemeImpl) {
/* 47 */     ScrollBarWidgetHelper.initHelper(this);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     this.thicknessInitialized = false; this.sbtImpl = paramScrollBarThemeImpl; setOrientation(Orientation.VERTICAL);
/*    */     setMin(0.0D);
/* 77 */     setManaged(false); } private void initializeThickness() { if (!this.thicknessInitialized) {
/* 78 */       ScrollBar scrollBar = this.sbtImpl.getTestSBRef();
/* 79 */       if (scrollBar == null) {
/*    */         return;
/*    */       }
/* 82 */       int i = (int)scrollBar.prefWidth(-1.0D);
/* 83 */       if (i != 0 && ScrollBarTheme.getThickness() != i) {
/* 84 */         ScrollBarTheme.setThickness(i);
/*    */       }
/* 86 */       this.thicknessInitialized = true;
/*    */     }  }
/*    */ 
/*    */   
/*    */   private void doUpdatePeer() {
/*    */     initializeThickness();
/*    */   }
/*    */   
/*    */   public RenderThemeImpl.WidgetType getType() {
/*    */     return RenderThemeImpl.WidgetType.SCROLLBAR;
/*    */   }
/*    */   
/*    */   protected void layoutChildren() {
/*    */     super.layoutChildren();
/*    */     initializeThickness();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\ScrollBarWidget.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */