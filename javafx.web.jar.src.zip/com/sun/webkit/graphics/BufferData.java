/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BufferData
/*     */ {
/* 185 */   private final AtomicInteger idCount = new AtomicInteger(0);
/* 186 */   private final HashMap<Integer, String> strMap = new HashMap<>();
/*     */   
/* 188 */   private final HashMap<Integer, int[]> intArrMap = (HashMap)new HashMap<>();
/*     */   
/* 190 */   private final HashMap<Integer, float[]> floatArrMap = (HashMap)new HashMap<>();
/*     */   
/*     */   private ByteBuffer buffer;
/*     */ 
/*     */   
/*     */   private int createID() {
/* 196 */     return this.idCount.incrementAndGet();
/*     */   }
/*     */   
/*     */   int addIntArray(int[] paramArrayOfint) {
/* 200 */     int i = createID();
/* 201 */     this.intArrMap.put(Integer.valueOf(i), paramArrayOfint);
/* 202 */     return i;
/*     */   }
/*     */   
/*     */   int[] getIntArray(int paramInt) {
/* 206 */     return this.intArrMap.get(Integer.valueOf(paramInt));
/*     */   }
/*     */   
/*     */   int addFloatArray(float[] paramArrayOffloat) {
/* 210 */     int i = createID();
/* 211 */     this.floatArrMap.put(Integer.valueOf(i), paramArrayOffloat);
/* 212 */     return i;
/*     */   }
/*     */   
/*     */   float[] getFloatArray(int paramInt) {
/* 216 */     return this.floatArrMap.get(Integer.valueOf(paramInt));
/*     */   }
/*     */   
/*     */   int addString(String paramString) {
/* 220 */     int i = createID();
/* 221 */     this.strMap.put(Integer.valueOf(i), paramString);
/* 222 */     return i;
/*     */   }
/*     */   
/*     */   String getString(int paramInt) {
/* 226 */     return this.strMap.get(Integer.valueOf(paramInt));
/*     */   }
/*     */   
/*     */   ByteBuffer getBuffer() {
/* 230 */     return this.buffer;
/*     */   }
/*     */   
/*     */   void setBuffer(ByteBuffer paramByteBuffer) {
/* 234 */     this.buffer = paramByteBuffer;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\BufferData.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */