/*    */ package com.sun.javafx.scene.text;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface TextLayout
/*    */ {
/*    */   public static final int FLAGS_LINES_VALID = 1;
/*    */   public static final int FLAGS_ANALYSIS_VALID = 2;
/*    */   public static final int FLAGS_HAS_TABS = 4;
/*    */   public static final int FLAGS_HAS_BIDI = 8;
/*    */   public static final int FLAGS_HAS_COMPLEX = 16;
/*    */   public static final int FLAGS_HAS_EMBEDDED = 32;
/*    */   public static final int FLAGS_HAS_CJK = 64;
/*    */   public static final int FLAGS_WRAPPED = 128;
/*    */   public static final int FLAGS_RTL_BASE = 256;
/*    */   public static final int FLAGS_CACHED_UNDERLINE = 512;
/*    */   public static final int FLAGS_CACHED_STRIKETHROUGH = 1024;
/*    */   public static final int FLAGS_LAST = 2048;
/*    */   public static final int ANALYSIS_MASK = 2047;
/*    */   public static final int ALIGN_LEFT = 262144;
/*    */   public static final int ALIGN_CENTER = 524288;
/*    */   public static final int ALIGN_RIGHT = 1048576;
/*    */   public static final int ALIGN_JUSTIFY = 2097152;
/*    */   public static final int ALIGN_MASK = 3932160;
/*    */   public static final int DIRECTION_LTR = 1024;
/*    */   public static final int DIRECTION_RTL = 2048;
/*    */   public static final int DIRECTION_DEFAULT_LTR = 4096;
/*    */   public static final int DIRECTION_DEFAULT_RTL = 8192;
/*    */   public static final int DIRECTION_MASK = 15360;
/*    */   public static final int BOUNDS_CENTER = 16384;
/*    */   public static final int BOUNDS_MASK = 16384;
/*    */   public static final int TYPE_TEXT = 1;
/*    */   public static final int TYPE_UNDERLINE = 2;
/*    */   public static final int TYPE_STRIKETHROUGH = 4;
/*    */   public static final int TYPE_BASELINE = 8;
/*    */   public static final int TYPE_TOP = 16;
/*    */   public static final int TYPE_BEARINGS = 32;
/*    */   
/*    */   boolean setContent(TextSpan[] paramArrayOfTextSpan);
/*    */   
/*    */   boolean setContent(String paramString, Object paramObject);
/*    */   
/*    */   boolean setAlignment(int paramInt);
/*    */   
/*    */   boolean setWrapWidth(float paramFloat);
/*    */   
/*    */   boolean setLineSpacing(float paramFloat);
/*    */   
/*    */   boolean setDirection(int paramInt);
/*    */   
/*    */   boolean setBoundsType(int paramInt);
/*    */   
/*    */   BaseBounds getBounds();
/*    */   
/*    */   BaseBounds getBounds(TextSpan paramTextSpan, BaseBounds paramBaseBounds);
/*    */   
/*    */   BaseBounds getVisualBounds(int paramInt);
/*    */   
/*    */   TextLine[] getLines();
/*    */   
/*    */   GlyphList[] getRuns();
/*    */   
/*    */   Shape getShape(int paramInt, TextSpan paramTextSpan);
/*    */   
/*    */   Hit getHitInfo(float paramFloat1, float paramFloat2);
/*    */   
/*    */   PathElement[] getCaretShape(int paramInt, boolean paramBoolean, float paramFloat1, float paramFloat2);
/*    */   
/*    */   PathElement[] getRange(int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2);
/*    */   
/*    */   public static class Hit
/*    */   {
/*    */     int charIndex;
/*    */     int insertionIndex;
/*    */     boolean leading;
/*    */     
/*    */     public Hit(int param1Int1, int param1Int2, boolean param1Boolean) {
/* 84 */       this.charIndex = param1Int1;
/* 85 */       this.insertionIndex = param1Int2;
/* 86 */       this.leading = param1Boolean;
/*    */     }
/*    */     
/* 89 */     public int getCharIndex() { return this.charIndex; }
/* 90 */     public int getInsertionIndex() { return this.insertionIndex; } public boolean isLeading() {
/* 91 */       return this.leading;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\TextLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */