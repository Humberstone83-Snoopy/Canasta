/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.text.ParseException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DateParser
/*     */ {
/*  48 */   private static final PlatformLogger logger = PlatformLogger.getLogger(DateParser.class.getName());
/*     */   
/*  50 */   private static final Pattern DELIMITER_PATTERN = Pattern.compile("[\\x09\\x20-\\x2F\\x3B-\\x40\\x5B-\\x60\\x7B-\\x7E]+");
/*     */   
/*  52 */   private static final Pattern TIME_PATTERN = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})(?:[^\\d].*)*");
/*     */   
/*  54 */   private static final Pattern DAY_OF_MONTH_PATTERN = Pattern.compile("(\\d{1,2})(?:[^\\d].*)*");
/*     */   
/*  56 */   private static final Pattern YEAR_PATTERN = Pattern.compile("(\\d{2,4})(?:[^\\d].*)*");
/*     */   private static final Map<String, Integer> MONTH_MAP;
/*     */   
/*     */   static {
/*  60 */     HashMap<Object, Object> hashMap = new HashMap<>(12);
/*  61 */     hashMap.put("jan", Integer.valueOf(0));
/*  62 */     hashMap.put("feb", Integer.valueOf(1));
/*  63 */     hashMap.put("mar", Integer.valueOf(2));
/*  64 */     hashMap.put("apr", Integer.valueOf(3));
/*  65 */     hashMap.put("may", Integer.valueOf(4));
/*  66 */     hashMap.put("jun", Integer.valueOf(5));
/*  67 */     hashMap.put("jul", Integer.valueOf(6));
/*  68 */     hashMap.put("aug", Integer.valueOf(7));
/*  69 */     hashMap.put("sep", Integer.valueOf(8));
/*  70 */     hashMap.put("oct", Integer.valueOf(9));
/*  71 */     hashMap.put("nov", Integer.valueOf(10));
/*  72 */     hashMap.put("dec", Integer.valueOf(11));
/*  73 */     MONTH_MAP = Collections.unmodifiableMap(hashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateParser() {
/*  81 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long parse(String paramString) throws ParseException {
/*  93 */     logger.finest("date: [{0}]", new Object[] { paramString });
/*     */     
/*  95 */     Time time = null;
/*  96 */     Integer integer1 = null;
/*  97 */     Integer integer2 = null;
/*  98 */     Integer integer3 = null;
/*  99 */     String[] arrayOfString = DELIMITER_PATTERN.split(paramString, 0);
/* 100 */     for (String str : arrayOfString) {
/* 101 */       if (str.length() != 0) {
/*     */         Time time1;
/*     */ 
/*     */ 
/*     */         
/* 106 */         if (time == null && (time1 = parseTime(str)) != null) {
/* 107 */           time = time1;
/*     */         } else {
/*     */           Integer integer;
/*     */ 
/*     */           
/* 112 */           if (integer1 == null && (
/* 113 */             integer = parseDayOfMonth(str)) != null) {
/*     */             
/* 115 */             integer1 = integer;
/*     */           } else {
/*     */             Integer integer4;
/*     */ 
/*     */             
/* 120 */             if (integer2 == null && (integer4 = parseMonth(str)) != null) {
/* 121 */               integer2 = integer4;
/*     */             } else {
/*     */               Integer integer5;
/*     */ 
/*     */               
/* 126 */               if (integer3 == null && (integer5 = parseYear(str)) != null)
/* 127 */                 integer3 = integer5; 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 132 */     }  if (integer3 != null) {
/* 133 */       if (integer3.intValue() >= 70 && integer3.intValue() <= 99) {
/* 134 */         integer3 = Integer.valueOf(integer3.intValue() + 1900);
/* 135 */       } else if (integer3.intValue() >= 0 && integer3.intValue() <= 69) {
/* 136 */         integer3 = Integer.valueOf(integer3.intValue() + 2000);
/*     */       } 
/*     */     }
/*     */     
/* 140 */     if (time == null || integer1 == null || integer2 == null || integer3 == null || integer1
/* 141 */       .intValue() < 1 || integer1.intValue() > 31 || integer3
/* 142 */       .intValue() < 1601 || time
/* 143 */       .hour > 23 || time
/* 144 */       .minute > 59 || time
/* 145 */       .second > 59)
/*     */     {
/* 147 */       throw new ParseException("Error parsing date", 0);
/*     */     }
/*     */     
/* 150 */     Calendar calendar = Calendar.getInstance(
/* 151 */         TimeZone.getTimeZone("UTC"), Locale.US);
/* 152 */     calendar.setLenient(false);
/* 153 */     calendar.clear();
/* 154 */     calendar.set(integer3.intValue(), integer2.intValue(), integer1.intValue(), time
/* 155 */         .hour, time.minute, time.second);
/*     */     
/*     */     try {
/* 158 */       long l = calendar.getTimeInMillis();
/* 159 */       if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 160 */         logger.finest("result: [{0}]", new Object[] { (new Date(l)).toString() });
/*     */       }
/* 162 */       return l;
/* 163 */     } catch (Exception exception) {
/* 164 */       ParseException parseException = new ParseException("Error parsing date", 0);
/* 165 */       parseException.initCause(exception);
/* 166 */       throw parseException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Time parseTime(String paramString) {
/* 174 */     Matcher matcher = TIME_PATTERN.matcher(paramString);
/* 175 */     if (matcher.matches()) {
/* 176 */       return new Time(
/* 177 */           Integer.parseInt(matcher.group(1)), 
/* 178 */           Integer.parseInt(matcher.group(2)), 
/* 179 */           Integer.parseInt(matcher.group(3)));
/*     */     }
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Time
/*     */   {
/*     */     private final int hour;
/*     */     
/*     */     private final int minute;
/*     */     
/*     */     private final int second;
/*     */     
/*     */     private Time(int param1Int1, int param1Int2, int param1Int3) {
/* 194 */       this.hour = param1Int1;
/* 195 */       this.minute = param1Int2;
/* 196 */       this.second = param1Int3;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Integer parseDayOfMonth(String paramString) {
/* 204 */     Matcher matcher = DAY_OF_MONTH_PATTERN.matcher(paramString);
/* 205 */     if (matcher.matches()) {
/* 206 */       return Integer.valueOf(Integer.parseInt(matcher.group(1)));
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Integer parseMonth(String paramString) {
/* 216 */     if (paramString.length() >= 3) {
/* 217 */       return MONTH_MAP.get(paramString.substring(0, 3).toLowerCase());
/*     */     }
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Integer parseYear(String paramString) {
/* 227 */     Matcher matcher = YEAR_PATTERN.matcher(paramString);
/* 228 */     if (matcher.matches()) {
/* 229 */       return Integer.valueOf(Integer.parseInt(matcher.group(1)));
/*     */     }
/* 231 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\DateParser.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */