/*     */ package com.sun.javafx.runtime.async;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import javafx.application.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAsyncOperation<V>
/*     */   implements AsyncOperation, Callable<V>
/*     */ {
/*     */   protected final FutureTask<V> future;
/*     */   protected final AsyncOperationListener listener;
/*  51 */   private int progressGranularity = 100; private int progressMax;
/*     */   private int lastProgress;
/*     */   
/*     */   protected AbstractAsyncOperation(final AsyncOperationListener<V> listener) {
/*  55 */     this.listener = listener;
/*     */     
/*  57 */     Callable callable = () -> call();
/*     */     
/*  59 */     final Runnable completionRunnable = new Runnable() {
/*     */         public void run() {
/*  61 */           if (AbstractAsyncOperation.this.future.isCancelled()) {
/*  62 */             listener.onCancel();
/*     */           } else {
/*     */             
/*     */             try {
/*  66 */               listener.onCompletion(AbstractAsyncOperation.this.future.get());
/*     */             }
/*  68 */             catch (InterruptedException interruptedException) {
/*  69 */               listener.onCancel();
/*     */             }
/*  71 */             catch (ExecutionException executionException) {
/*  72 */               listener.onException(executionException);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       };
/*  77 */     this.future = new FutureTask<V>(callable)
/*     */       {
/*     */         protected void done() {
/*     */           try {
/*  81 */             Platform.runLater(completionRunnable);
/*     */           } finally {
/*     */             
/*  84 */             super.done();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */   private int progressIncrement; private int nextProgress; private int bytesRead;
/*     */   public boolean isCancelled() {
/*  91 */     return this.future.isCancelled();
/*     */   }
/*     */   
/*     */   public boolean isDone() {
/*  95 */     return this.future.isDone();
/*     */   }
/*     */   
/*     */   public void cancel() {
/*  99 */     this.future.cancel(true);
/*     */   }
/*     */   
/*     */   public void start() {
/* 103 */     BackgroundExecutor.getExecutor().execute(this.future);
/*     */   }
/*     */   
/*     */   protected void notifyProgress() {
/* 107 */     int i = this.lastProgress;
/* 108 */     int j = this.progressMax;
/* 109 */     Platform.runLater(() -> this.listener.onProgress(paramInt1, paramInt2));
/*     */   }
/*     */   
/*     */   protected void addProgress(int paramInt) {
/* 113 */     this.bytesRead += paramInt;
/* 114 */     if (this.bytesRead > this.nextProgress) {
/* 115 */       this.lastProgress = this.bytesRead;
/* 116 */       notifyProgress();
/* 117 */       this.nextProgress = (this.lastProgress / this.progressIncrement + 1) * this.progressIncrement;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected int getProgressMax() {
/* 122 */     return this.progressMax;
/*     */   }
/*     */   
/*     */   protected void setProgressMax(int paramInt) {
/* 126 */     if (paramInt == 0) {
/* 127 */       this.progressIncrement = this.progressGranularity;
/*     */     }
/* 129 */     else if (paramInt == -1) {
/* 130 */       this.progressIncrement = this.progressGranularity;
/*     */     } else {
/*     */       
/* 133 */       this.progressMax = paramInt;
/* 134 */       this.progressIncrement = paramInt / this.progressGranularity;
/* 135 */       if (this.progressIncrement < 1) {
/* 136 */         this.progressIncrement = 1;
/*     */       }
/*     */     } 
/* 139 */     this.nextProgress = (this.lastProgress / this.progressIncrement + 1) * this.progressIncrement;
/* 140 */     notifyProgress();
/*     */   }
/*     */   
/*     */   protected int getProgressGranularity() {
/* 144 */     return this.progressGranularity;
/*     */   }
/*     */   
/*     */   protected void setProgressGranularity(int paramInt) {
/* 148 */     this.progressGranularity = paramInt;
/* 149 */     this.progressIncrement = this.progressMax / paramInt;
/* 150 */     this.nextProgress = (this.lastProgress / this.progressIncrement + 1) * this.progressIncrement;
/* 151 */     notifyProgress();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\AbstractAsyncOperation.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */