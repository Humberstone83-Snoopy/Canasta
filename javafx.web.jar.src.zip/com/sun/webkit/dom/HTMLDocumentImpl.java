/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLDocumentImpl
/*     */   extends DocumentImpl
/*     */   implements HTMLDocument
/*     */ {
/*     */   HTMLDocumentImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLDocument getImpl(long paramLong) {
/*  37 */     return (HTMLDocument)create(paramLong);
/*     */   }
/*     */   
/*     */   static native long getEmbedsImpl(long paramLong);
/*     */   
/*     */   public HTMLCollection getEmbeds() {
/*  43 */     return HTMLCollectionImpl.getImpl(getEmbedsImpl(getPeer()));
/*     */   }
/*     */   static native long getPluginsImpl(long paramLong);
/*     */   
/*     */   public HTMLCollection getPlugins() {
/*  48 */     return HTMLCollectionImpl.getImpl(getPluginsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLCollection getScripts() {
/*  53 */     return HTMLCollectionImpl.getImpl(getScriptsImpl(getPeer()));
/*     */   }
/*     */   static native long getScriptsImpl(long paramLong);
/*     */   
/*     */   public int getWidth() {
/*  58 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native int getWidthImpl(long paramLong);
/*     */   
/*     */   public int getHeight() {
/*  63 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native int getHeightImpl(long paramLong);
/*     */   
/*     */   public String getDir() {
/*  68 */     return getDirImpl(getPeer());
/*     */   }
/*     */   static native String getDirImpl(long paramLong);
/*     */   
/*     */   public void setDir(String paramString) {
/*  73 */     setDirImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDirImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getDesignMode() {
/*  78 */     return getDesignModeImpl(getPeer());
/*     */   }
/*     */   static native String getDesignModeImpl(long paramLong);
/*     */   
/*     */   public void setDesignMode(String paramString) {
/*  83 */     setDesignModeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDesignModeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCompatMode() {
/*  88 */     return getCompatModeImpl(getPeer());
/*     */   }
/*     */   static native String getCompatModeImpl(long paramLong);
/*     */   
/*     */   public String getBgColor() {
/*  93 */     return getBgColorImpl(getPeer());
/*     */   }
/*     */   static native String getBgColorImpl(long paramLong);
/*     */   
/*     */   public void setBgColor(String paramString) {
/*  98 */     setBgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFgColor() {
/* 103 */     return getFgColorImpl(getPeer());
/*     */   }
/*     */   static native String getFgColorImpl(long paramLong);
/*     */   
/*     */   public void setFgColor(String paramString) {
/* 108 */     setFgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAlinkColor() {
/* 113 */     return getAlinkColorImpl(getPeer());
/*     */   }
/*     */   static native String getAlinkColorImpl(long paramLong);
/*     */   
/*     */   public void setAlinkColor(String paramString) {
/* 118 */     setAlinkColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlinkColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getLinkColor() {
/* 123 */     return getLinkColorImpl(getPeer());
/*     */   }
/*     */   static native String getLinkColorImpl(long paramLong);
/*     */   
/*     */   public void setLinkColor(String paramString) {
/* 128 */     setLinkColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLinkColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVlinkColor() {
/* 133 */     return getVlinkColorImpl(getPeer());
/*     */   }
/*     */   static native String getVlinkColorImpl(long paramLong);
/*     */   
/*     */   public void setVlinkColor(String paramString) {
/* 138 */     setVlinkColorImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setVlinkColorImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void open() {
/* 146 */     openImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void openImpl(long paramLong);
/*     */   
/*     */   public void close() {
/* 153 */     closeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void closeImpl(long paramLong);
/*     */   
/*     */   public void write(String paramString) {
/* 160 */     writeImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void writeImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void writeln(String paramString) {
/* 169 */     writelnImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void writelnImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void clear() {
/* 178 */     clearImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void clearImpl(long paramLong);
/*     */   
/*     */   public void captureEvents() {
/* 185 */     captureEventsImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void captureEventsImpl(long paramLong);
/*     */   
/*     */   public void releaseEvents() {
/* 192 */     releaseEventsImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native void releaseEventsImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLDocumentImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */