/*     */ package javafx.scene.media;
/*     */ 
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.media.PrismMediaFrameHandler;
/*     */ import com.sun.javafx.sg.prism.MediaFrameTracker;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.media.jfxmedia.control.VideoDataBuffer;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Texture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NGMediaView
/*     */   extends NGNode
/*     */ {
/*     */   private boolean smooth = true;
/*  40 */   private final RectBounds dimension = new RectBounds();
/*  41 */   private final RectBounds viewport = new RectBounds();
/*     */   private PrismMediaFrameHandler handler;
/*     */   private MediaPlayer player;
/*     */   private MediaFrameTracker frameTracker;
/*     */   
/*     */   public void renderNextFrame() {
/*  47 */     visualsChanged();
/*     */   }
/*     */   
/*     */   public boolean isSmooth() {
/*  51 */     return this.smooth;
/*     */   }
/*     */   
/*     */   public void setSmooth(boolean paramBoolean) {
/*  55 */     if (paramBoolean != this.smooth) {
/*  56 */       this.smooth = paramBoolean;
/*  57 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setX(float paramFloat) {
/*  62 */     if (paramFloat != this.dimension.getMinX()) {
/*  63 */       float f = this.dimension.getWidth();
/*  64 */       this.dimension.setMinX(paramFloat);
/*  65 */       this.dimension.setMaxX(paramFloat + f);
/*  66 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setY(float paramFloat) {
/*  71 */     if (paramFloat != this.dimension.getMinY()) {
/*  72 */       float f = this.dimension.getHeight();
/*  73 */       this.dimension.setMinY(paramFloat);
/*  74 */       this.dimension.setMaxY(paramFloat + f);
/*  75 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMediaProvider(Object paramObject) {
/*  80 */     if (paramObject == null) {
/*  81 */       this.player = null;
/*  82 */       this.handler = null;
/*  83 */       geometryChanged();
/*  84 */     } else if (paramObject instanceof MediaPlayer) {
/*  85 */       this.player = (MediaPlayer)paramObject;
/*  86 */       this.handler = PrismMediaFrameHandler.getHandler(this.player);
/*  87 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewport(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, boolean paramBoolean) {
/*  95 */     float f1 = 0.0F;
/*  96 */     float f2 = 0.0F;
/*  97 */     float f3 = paramFloat1;
/*  98 */     float f4 = paramFloat2;
/*     */ 
/*     */     
/* 101 */     if (null != this.player) {
/* 102 */       Media media = this.player.getMedia();
/* 103 */       f1 = media.getWidth();
/* 104 */       f2 = media.getHeight();
/*     */     } 
/*     */     
/* 107 */     if (paramFloat5 > 0.0F && paramFloat6 > 0.0F) {
/* 108 */       this.viewport.setBounds(paramFloat3, paramFloat4, paramFloat3 + paramFloat5, paramFloat4 + paramFloat6);
/* 109 */       f1 = paramFloat5;
/* 110 */       f2 = paramFloat6;
/*     */     } else {
/* 112 */       this.viewport.setBounds(0.0F, 0.0F, f1, f2);
/*     */     } 
/* 114 */     if (paramFloat1 <= 0.0F && paramFloat2 <= 0.0F) {
/* 115 */       f3 = f1;
/* 116 */       f4 = f2;
/* 117 */     } else if (paramBoolean) {
/*     */ 
/*     */       
/* 120 */       if (paramFloat1 <= 0.0D) {
/* 121 */         f3 = (f2 > 0.0F) ? (f1 * paramFloat2 / f2) : 0.0F;
/* 122 */         f4 = paramFloat2;
/* 123 */       } else if (paramFloat2 <= 0.0D) {
/* 124 */         f3 = paramFloat1;
/* 125 */         f4 = (f1 > 0.0F) ? (f2 * paramFloat1 / f1) : 0.0F;
/*     */       } else {
/* 127 */         if (f1 == 0.0F) f1 = paramFloat1; 
/* 128 */         if (f2 == 0.0F) f2 = paramFloat2; 
/* 129 */         float f = Math.min(paramFloat1 / f1, paramFloat2 / f2);
/* 130 */         f3 = f1 * f;
/* 131 */         f4 = f2 * f;
/*     */       } 
/* 133 */     } else if (paramFloat2 <= 0.0D) {
/* 134 */       f4 = f2;
/* 135 */     } else if (paramFloat1 <= 0.0D) {
/* 136 */       f3 = f1;
/*     */     } 
/* 138 */     if (f4 < 1.0F) {
/* 139 */       f4 = 1.0F;
/*     */     }
/* 141 */     if (f3 < 1.0F) {
/* 142 */       f3 = 1.0F;
/*     */     }
/* 144 */     this.dimension.setMaxX(this.dimension.getMinX() + f3);
/* 145 */     this.dimension.setMaxY(this.dimension.getMinY() + f4);
/* 146 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 151 */     if (null == this.handler || null == this.player) {
/*     */       return;
/*     */     }
/*     */     
/* 155 */     VideoDataBuffer videoDataBuffer = this.player.getLatestFrame();
/* 156 */     if (null == videoDataBuffer) {
/*     */       return;
/*     */     }
/*     */     
/* 160 */     Texture texture = this.handler.getTexture(paramGraphics, videoDataBuffer);
/* 161 */     if (texture != null) {
/* 162 */       float f1 = this.viewport.getWidth();
/* 163 */       float f2 = this.viewport.getHeight();
/* 164 */       boolean bool1 = !this.dimension.isEmpty() ? true : false;
/*     */       
/* 166 */       boolean bool2 = (bool1 && (f1 != this.dimension.getWidth() || f2 != this.dimension.getHeight())) ? true : false;
/*     */       
/* 168 */       paramGraphics.translate(this.dimension.getMinX(), this.dimension.getMinY());
/*     */       
/* 170 */       if (bool2 && f1 != 0.0F && f2 != 0.0F) {
/* 171 */         float f7 = this.dimension.getWidth() / f1;
/* 172 */         float f8 = this.dimension.getHeight() / f2;
/* 173 */         paramGraphics.scale(f7, f8);
/*     */       } 
/*     */       
/* 176 */       float f3 = this.viewport.getMinX();
/* 177 */       float f4 = this.viewport.getMinY();
/* 178 */       float f5 = f3 + f1;
/* 179 */       float f6 = f4 + f2;
/*     */       
/* 181 */       paramGraphics.drawTexture(texture, 0.0F, 0.0F, f1, f2, f3, f4, f5, f6);
/*     */ 
/*     */       
/* 184 */       texture.unlock();
/*     */       
/* 186 */       if (null != this.frameTracker) {
/* 187 */         this.frameTracker.incrementRenderedFrameCount(1);
/*     */       }
/*     */     } 
/* 190 */     videoDataBuffer.releaseFrame();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 195 */     return false;
/*     */   }
/*     */   
/*     */   public void setFrameTracker(MediaFrameTracker paramMediaFrameTracker) {
/* 199 */     this.frameTracker = paramMediaFrameTracker;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\NGMediaView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */