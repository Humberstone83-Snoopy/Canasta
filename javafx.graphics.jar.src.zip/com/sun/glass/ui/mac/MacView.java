/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacView
/*     */   extends View
/*     */ {
/*     */   static {
/*  43 */     _initIDs();
/*  44 */   } private static final long multiClickTime = _getMultiClickTime_impl();
/*  45 */   private static final int multiClickMaxX = _getMultiClickMaxX_impl();
/*  46 */   private static final int multiClickMaxY = _getMultiClickMaxY_impl();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long getMultiClickTime_impl() {
/*  58 */     return multiClickTime;
/*     */   }
/*     */   
/*     */   static int getMultiClickMaxX_impl() {
/*  62 */     return multiClickMaxX;
/*     */   }
/*     */   
/*     */   static int getMultiClickMaxY_impl() {
/*  66 */     return multiClickMaxY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _uploadPixels(long paramLong, Pixels paramPixels) {
/*  83 */     Buffer buffer = paramPixels.getPixels();
/*  84 */     if (buffer.isDirect() == true) {
/*  85 */       _uploadPixelsDirect(paramLong, buffer, paramPixels.getWidth(), paramPixels.getHeight(), paramPixels.getScaleX(), paramPixels.getScaleY());
/*  86 */     } else if (buffer.hasArray() == true) {
/*  87 */       if (paramPixels.getBytesPerComponent() == 1) {
/*  88 */         ByteBuffer byteBuffer = (ByteBuffer)buffer;
/*  89 */         _uploadPixelsByteArray(paramLong, byteBuffer.array(), byteBuffer.arrayOffset(), paramPixels
/*  90 */             .getWidth(), paramPixels.getHeight(), paramPixels.getScaleX(), paramPixels.getScaleY());
/*     */       } else {
/*  92 */         IntBuffer intBuffer = (IntBuffer)buffer;
/*  93 */         _uploadPixelsIntArray(paramLong, intBuffer.array(), intBuffer.arrayOffset(), paramPixels
/*  94 */             .getWidth(), paramPixels.getHeight(), paramPixels.getScaleX(), paramPixels.getScaleY());
/*     */       } 
/*     */     } else {
/*     */       
/*  98 */       _uploadPixelsDirect(paramLong, paramPixels.asByteBuffer(), paramPixels
/*  99 */           .getWidth(), paramPixels.getHeight(), paramPixels.getScaleX(), paramPixels.getScaleY());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyResize(int paramInt1, int paramInt2) {
/* 108 */     Window window = getWindow();
/* 109 */     float f1 = (window == null) ? 1.0F : window.getPlatformScaleX();
/* 110 */     float f2 = (window == null) ? 1.0F : window.getPlatformScaleY();
/* 111 */     paramInt1 = Math.round(paramInt1 * f1);
/* 112 */     paramInt2 = Math.round(paramInt2 * f2);
/* 113 */     super.notifyResize(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyMouse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2) {
/* 120 */     Window window = getWindow();
/* 121 */     float f1 = (window == null) ? 1.0F : window.getPlatformScaleX();
/* 122 */     float f2 = (window == null) ? 1.0F : window.getPlatformScaleY();
/* 123 */     paramInt3 = Math.round(paramInt3 * f1);
/* 124 */     paramInt4 = Math.round(paramInt4 * f2);
/* 125 */     paramInt5 = Math.round(paramInt5 * f1);
/* 126 */     paramInt6 = Math.round(paramInt6 * f2);
/* 127 */     super.notifyMouse(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean1, paramBoolean2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long _getNativeView(long paramLong) {
/* 132 */     return paramLong;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getNativeLayer() {
/* 137 */     return _getNativeLayer(getNativeView());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNativeRemoteLayerId(String paramString) {
/* 143 */     return _getNativeRemoteLayerId(getNativeLayer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void hostRemoteLayerId(int paramInt) {
/* 149 */     _hostRemoteLayerId(getNativeLayer(), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifyInputMethodMac(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 154 */     byte[] arrayOfByte = new byte[1];
/* 155 */     arrayOfByte[0] = (byte)paramInt1;
/* 156 */     int[] arrayOfInt = new int[2];
/* 157 */     arrayOfInt[0] = 0;
/* 158 */     arrayOfInt[1] = paramInt2;
/* 159 */     if (paramInt1 == 4) {
/*     */       
/* 161 */       notifyInputMethod(paramString, null, arrayOfInt, arrayOfByte, paramInt2, paramInt3, 0);
/*     */     
/*     */     }
/* 164 */     else if (paramInt5 > 0 && paramString != null && paramString
/* 165 */       .length() > 0 && paramInt4 >= 0 && paramInt5 + paramInt4 <= paramString
/*     */       
/* 167 */       .length()) {
/*     */       
/* 169 */       TreeSet<Integer> treeSet = new TreeSet();
/* 170 */       treeSet.add(Integer.valueOf(0));
/* 171 */       treeSet.add(Integer.valueOf(paramInt4));
/* 172 */       treeSet.add(Integer.valueOf(paramInt4 + paramInt5));
/* 173 */       treeSet.add(Integer.valueOf(paramString.length()));
/*     */       
/* 175 */       int[] arrayOfInt1 = new int[treeSet.size()];
/* 176 */       byte b = 0;
/* 177 */       for (Iterator<Integer> iterator = treeSet.iterator(); iterator.hasNext(); ) { int i = ((Integer)iterator.next()).intValue();
/* 178 */         arrayOfInt1[b] = i;
/* 179 */         b++; }
/*     */ 
/*     */       
/* 182 */       byte[] arrayOfByte1 = new byte[arrayOfInt1.length - 1];
/*     */       
/* 184 */       for (b = 0; b < arrayOfInt1.length - 1; b++) {
/* 185 */         arrayOfByte1[b] = (arrayOfInt1[b] == paramInt4) ? 
/* 186 */           1 : 
/* 187 */           2;
/*     */       }
/*     */       
/* 190 */       notifyInputMethod(paramString, arrayOfInt1, arrayOfInt1, arrayOfByte1, 0, paramInt3, 0);
/*     */     } else {
/* 192 */       notifyInputMethod(paramString, null, arrayOfInt, arrayOfByte, 0, paramInt3, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private static native long _getMultiClickTime_impl();
/*     */   
/*     */   private static native int _getMultiClickMaxX_impl();
/*     */   
/*     */   private static native int _getMultiClickMaxY_impl();
/*     */   
/*     */   protected native int _getNativeFrameBuffer(long paramLong);
/*     */   
/*     */   protected native long _create(Map paramMap);
/*     */   
/*     */   protected native int _getX(long paramLong);
/*     */   
/*     */   protected native int _getY(long paramLong);
/*     */   
/*     */   protected native void _setParent(long paramLong1, long paramLong2);
/*     */   
/*     */   protected native boolean _close(long paramLong);
/*     */   
/*     */   protected native void _scheduleRepaint(long paramLong);
/*     */   
/*     */   protected native void _begin(long paramLong);
/*     */   
/*     */   protected native void _end(long paramLong);
/*     */   
/*     */   protected native boolean _enterFullscreen(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*     */   
/*     */   protected native void _exitFullscreen(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native void _enableInputMethodEvents(long paramLong, boolean paramBoolean);
/*     */   
/*     */   native void _uploadPixelsDirect(long paramLong, Buffer paramBuffer, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2);
/*     */   
/*     */   native void _uploadPixelsByteArray(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2);
/*     */   
/*     */   native void _uploadPixelsIntArray(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, float paramFloat1, float paramFloat2);
/*     */   
/*     */   protected native long _getNativeLayer(long paramLong);
/*     */   
/*     */   protected native int _getNativeRemoteLayerId(long paramLong, String paramString);
/*     */   
/*     */   protected native void _hostRemoteLayerId(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */