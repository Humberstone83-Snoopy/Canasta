/*     */ package com.sun.media.jfxmedia.logging;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logger
/*     */ {
/*     */   public static final int OFF = 2147483647;
/*     */   public static final int ERROR = 4;
/*     */   public static final int WARNING = 3;
/*     */   public static final int INFO = 2;
/*     */   public static final int DEBUG = 1;
/*  95 */   private static int currentLevel = Integer.MAX_VALUE;
/*  96 */   private static long startTime = 0L;
/*  97 */   private static final Object lock = new Object();
/*     */   
/*     */   static {
/* 100 */     startLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void startLogger() {
/*     */     try {
/*     */       Integer integer;
/* 110 */       String str = System.getProperty("jfxmedia.loglevel", "off").toLowerCase();
/*     */       
/* 112 */       if (str.equals("debug")) {
/* 113 */         integer = Integer.valueOf(1);
/* 114 */       } else if (str.equals("warning")) {
/* 115 */         integer = Integer.valueOf(3);
/* 116 */       } else if (str.equals("error")) {
/* 117 */         integer = Integer.valueOf(4);
/* 118 */       } else if (str.equals("info")) {
/* 119 */         integer = Integer.valueOf(2);
/*     */       } else {
/* 121 */         integer = Integer.valueOf(2147483647);
/*     */       } 
/*     */       
/* 124 */       setLevel(integer.intValue());
/*     */       
/* 126 */       startTime = System.currentTimeMillis();
/* 127 */     } catch (Exception exception) {}
/*     */     
/* 129 */     if (canLog(1)) {
/* 130 */       logMsg(1, "Logger initialized");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean initNative() {
/* 142 */     if (nativeInit()) {
/* 143 */       nativeSetNativeLevel(currentLevel);
/* 144 */       return true;
/*     */     } 
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLevel(int paramInt) {
/* 160 */     currentLevel = paramInt;
/*     */     
/*     */     try {
/* 163 */       nativeSetNativeLevel(paramInt);
/* 164 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean canLog(int paramInt) {
/* 176 */     if (paramInt < currentLevel) {
/* 177 */       return false;
/*     */     }
/* 179 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logMsg(int paramInt, String paramString) {
/* 190 */     synchronized (lock) {
/* 191 */       if (paramInt < currentLevel) {
/*     */         return;
/*     */       }
/*     */       
/* 195 */       if (paramInt == 4) {
/* 196 */         System.err.println("Error (" + getTimestamp() + "): " + paramString);
/* 197 */       } else if (paramInt == 3) {
/* 198 */         System.err.println("Warning (" + getTimestamp() + "): " + paramString);
/* 199 */       } else if (paramInt == 2) {
/* 200 */         System.out.println("Info (" + getTimestamp() + "): " + paramString);
/* 201 */       } else if (paramInt == 1) {
/* 202 */         System.out.println("Debug (" + getTimestamp() + "): " + paramString);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logMsg(int paramInt, String paramString1, String paramString2, String paramString3) {
/* 216 */     synchronized (lock) {
/* 217 */       if (paramInt < currentLevel) {
/*     */         return;
/*     */       }
/*     */       
/* 221 */       logMsg(paramInt, paramString1 + ":" + paramString1 + "() " + paramString2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTimestamp() {
/* 231 */     long l1 = System.currentTimeMillis() - startTime;
/* 232 */     long l2 = l1 / 3600000L;
/* 233 */     long l3 = (l1 - l2 * 60L * 60L * 1000L) / 60000L;
/* 234 */     long l4 = (l1 - l2 * 60L * 60L * 1000L - l3 * 60L * 1000L) / 1000L;
/* 235 */     long l5 = l1 - l2 * 60L * 60L * 1000L - l3 * 60L * 1000L - l4 * 1000L;
/*     */     
/* 237 */     return String.format("%d:%02d:%02d:%03d", new Object[] { Long.valueOf(l2), Long.valueOf(l3), Long.valueOf(l4), Long.valueOf(l5) });
/*     */   }
/*     */   
/*     */   private static native boolean nativeInit();
/*     */   
/*     */   private static native void nativeSetNativeLevel(int paramInt);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\logging\Logger.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */