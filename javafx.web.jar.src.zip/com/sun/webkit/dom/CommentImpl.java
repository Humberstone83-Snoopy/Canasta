/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.Comment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentImpl
/*    */   extends CharacterDataImpl
/*    */   implements Comment
/*    */ {
/*    */   CommentImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Comment getImpl(long paramLong) {
/* 36 */     return (Comment)create(paramLong);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CommentImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */