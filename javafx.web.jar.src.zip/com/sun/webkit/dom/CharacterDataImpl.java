/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterDataImpl
/*     */   extends NodeImpl
/*     */   implements CharacterData
/*     */ {
/*     */   public static final byte DIRECTIONALITY_LEFT_TO_RIGHT = 0;
/*     */   public static final byte DIRECTIONALITY_RIGHT_TO_LEFT = 1;
/*     */   public static final byte DIRECTIONALITY_EUROPEAN_NUMBER = 3;
/*     */   public static final byte DIRECTIONALITY_EUROPEAN_NUMBER_SEPARATOR = 4;
/*     */   public static final byte DIRECTIONALITY_EUROPEAN_NUMBER_TERMINATOR = 5;
/*     */   public static final byte DIRECTIONALITY_ARABIC_NUMBER = 6;
/*     */   public static final byte DIRECTIONALITY_COMMON_NUMBER_SEPARATOR = 7;
/*     */   public static final byte DIRECTIONALITY_PARAGRAPH_SEPARATOR = 10;
/*     */   public static final byte DIRECTIONALITY_SEGMENT_SEPARATOR = 11;
/*     */   public static final byte DIRECTIONALITY_WHITESPACE = 12;
/*     */   public static final byte DIRECTIONALITY_OTHER_NEUTRALS = 13;
/*     */   public static final byte DIRECTIONALITY_LEFT_TO_RIGHT_EMBEDDING = 14;
/*     */   public static final byte DIRECTIONALITY_LEFT_TO_RIGHT_OVERRIDE = 15;
/*     */   public static final byte DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC = 2;
/*     */   public static final byte DIRECTIONALITY_RIGHT_TO_LEFT_EMBEDDING = 16;
/*     */   public static final byte DIRECTIONALITY_RIGHT_TO_LEFT_OVERRIDE = 17;
/*     */   public static final byte DIRECTIONALITY_POP_DIRECTIONAL_FORMAT = 18;
/*     */   public static final byte DIRECTIONALITY_NONSPACING_MARK = 8;
/*     */   public static final byte DIRECTIONALITY_BOUNDARY_NEUTRAL = 9;
/*     */   public static final byte UNASSIGNED = 0;
/*     */   public static final byte UPPERCASE_LETTER = 1;
/*     */   public static final byte LOWERCASE_LETTER = 2;
/*     */   public static final byte TITLECASE_LETTER = 3;
/*     */   public static final byte MODIFIER_LETTER = 4;
/*     */   public static final byte OTHER_LETTER = 5;
/*     */   public static final byte NON_SPACING_MARK = 6;
/*     */   public static final byte ENCLOSING_MARK = 7;
/*     */   public static final byte COMBINING_SPACING_MARK = 8;
/*     */   public static final byte DECIMAL_DIGIT_NUMBER = 9;
/*     */   public static final byte LETTER_NUMBER = 10;
/*     */   public static final byte OTHER_NUMBER = 11;
/*     */   public static final byte SPACE_SEPARATOR = 12;
/*     */   public static final byte LINE_SEPARATOR = 13;
/*     */   public static final byte PARAGRAPH_SEPARATOR = 14;
/*     */   public static final byte CONTROL = 15;
/*     */   public static final byte FORMAT = 16;
/*     */   public static final byte PRIVATE_USE = 18;
/*     */   public static final byte SURROGATE = 19;
/*     */   public static final byte DASH_PUNCTUATION = 20;
/*     */   public static final byte START_PUNCTUATION = 21;
/*     */   public static final byte END_PUNCTUATION = 22;
/*     */   public static final byte CONNECTOR_PUNCTUATION = 23;
/*     */   public static final byte OTHER_PUNCTUATION = 24;
/*     */   public static final byte MATH_SYMBOL = 25;
/*     */   public static final byte CURRENCY_SYMBOL = 26;
/*     */   public static final byte MODIFIER_SYMBOL = 27;
/*     */   public static final byte OTHER_SYMBOL = 28;
/*     */   public static final byte INITIAL_QUOTE_PUNCTUATION = 29;
/*     */   public static final byte FINAL_QUOTE_PUNCTUATION = 30;
/*     */   
/*     */   CharacterDataImpl(long paramLong) {
/*  93 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static Node getImpl(long paramLong) {
/*  97 */     return create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getDataImpl(long paramLong);
/*     */   
/*     */   public String getData() {
/* 103 */     return getDataImpl(getPeer());
/*     */   }
/*     */   static native void setDataImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setData(String paramString) {
/* 108 */     setDataImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 113 */     return getLengthImpl(getPeer());
/*     */   }
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   public Element getPreviousElementSibling() {
/* 118 */     return ElementImpl.getImpl(getPreviousElementSiblingImpl(getPeer()));
/*     */   }
/*     */   static native long getPreviousElementSiblingImpl(long paramLong);
/*     */   
/*     */   public Element getNextElementSibling() {
/* 123 */     return ElementImpl.getImpl(getNextElementSiblingImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native long getNextElementSiblingImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public String substringData(int paramInt1, int paramInt2) throws DOMException {
/* 132 */     return substringDataImpl(getPeer(), paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native String substringDataImpl(long paramLong, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendData(String paramString) {
/* 143 */     appendDataImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void appendDataImpl(long paramLong, String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertData(int paramInt, String paramString) throws DOMException {
/* 153 */     insertDataImpl(getPeer(), paramInt, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void insertDataImpl(long paramLong, int paramInt, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteData(int paramInt1, int paramInt2) throws DOMException {
/* 165 */     deleteDataImpl(getPeer(), paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void deleteDataImpl(long paramLong, int paramInt1, int paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replaceData(int paramInt1, int paramInt2, String paramString) throws DOMException {
/* 178 */     replaceDataImpl(getPeer(), paramInt1, paramInt2, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void replaceDataImpl(long paramLong, int paramInt1, int paramInt2, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() throws DOMException {
/* 191 */     removeImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native void removeImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CharacterDataImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */