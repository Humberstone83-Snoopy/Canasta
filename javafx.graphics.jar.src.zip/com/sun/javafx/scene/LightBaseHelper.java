/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.LightBase;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LightBaseHelper
/*    */   extends NodeHelper
/*    */ {
/* 44 */   private static final LightBaseHelper theInstance = new LightBaseHelper(); static {
/* 45 */     Utils.forceInit(LightBase.class);
/*    */   }
/*    */   private static LightBaseAccessor lightBaseAccessor;
/*    */   private static LightBaseHelper getInstance() {
/* 49 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(LightBase paramLightBase) {
/* 53 */     setHelper(paramLightBase, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 58 */     throw new UnsupportedOperationException("Applications should not extend the LightBase class directly.");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 63 */     super.updatePeerImpl(paramNode);
/* 64 */     lightBaseAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void markDirtyImpl(Node paramNode, DirtyBits paramDirtyBits) {
/* 69 */     super.markDirtyImpl(paramNode, paramDirtyBits);
/* 70 */     lightBaseAccessor.doMarkDirty(paramNode, paramDirtyBits);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 76 */     return lightBaseAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 81 */     return lightBaseAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static void setLightBaseAccessor(LightBaseAccessor paramLightBaseAccessor) {
/* 85 */     if (lightBaseAccessor != null) {
/* 86 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 89 */     lightBaseAccessor = paramLightBaseAccessor;
/*    */   }
/*    */   
/*    */   public static interface LightBaseAccessor {
/*    */     void doMarkDirty(Node param1Node, DirtyBits param1DirtyBits);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\LightBaseHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */