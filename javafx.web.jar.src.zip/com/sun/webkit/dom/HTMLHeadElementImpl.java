/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLHeadElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLHeadElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLHeadElement
/*    */ {
/*    */   HTMLHeadElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLHeadElement getImpl(long paramLong) {
/* 36 */     return (HTMLHeadElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getProfile() {
/* 42 */     return getProfileImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProfile(String paramString) {
/* 47 */     setProfileImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getProfileImpl(long paramLong);
/*    */   
/*    */   static native void setProfileImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLHeadElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */