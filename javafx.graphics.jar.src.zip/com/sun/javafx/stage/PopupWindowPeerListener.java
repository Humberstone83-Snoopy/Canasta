/*    */ package com.sun.javafx.stage;
/*    */ 
/*    */ import com.sun.javafx.tk.FocusCause;
/*    */ import javafx.stage.PopupWindow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PopupWindowPeerListener
/*    */   extends WindowPeerListener
/*    */ {
/*    */   private final PopupWindow popupWindow;
/*    */   
/*    */   public PopupWindowPeerListener(PopupWindow paramPopupWindow) {
/* 38 */     super(paramPopupWindow);
/* 39 */     this.popupWindow = paramPopupWindow;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void changedFocused(boolean paramBoolean, FocusCause paramFocusCause) {
/* 48 */     WindowHelper.setFocused(this.popupWindow, paramBoolean);
/*    */   }
/*    */   
/*    */   public void closing() {}
/*    */   
/*    */   public void changedLocation(float paramFloat1, float paramFloat2) {}
/*    */   
/*    */   public void changedIconified(boolean paramBoolean) {}
/*    */   
/*    */   public void changedMaximized(boolean paramBoolean) {}
/*    */   
/*    */   public void changedResizable(boolean paramBoolean) {}
/*    */   
/*    */   public void changedFullscreen(boolean paramBoolean) {}
/*    */   
/*    */   public void focusUngrab() {}
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\stage\PopupWindowPeerListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */