/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FontStrikeDesc
/*    */ {
/*    */   float[] matrix;
/*    */   float size;
/*    */   int aaMode;
/*    */   private int hash;
/*    */   
/*    */   public FontStrikeDesc(float paramFloat, BaseTransform paramBaseTransform, int paramInt) {
/* 43 */     BaseTransform baseTransform = paramBaseTransform;
/* 44 */     this.size = paramFloat;
/* 45 */     this.aaMode = paramInt;
/* 46 */     this.matrix = new float[4];
/* 47 */     this.matrix[0] = (float)baseTransform.getMxx();
/* 48 */     this.matrix[1] = (float)baseTransform.getMxy();
/* 49 */     this.matrix[2] = (float)baseTransform.getMyx();
/* 50 */     this.matrix[3] = (float)baseTransform.getMyy();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 56 */     if (this.hash == 0) {
/* 57 */       this
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 63 */         .hash = this.aaMode + Float.floatToIntBits(this.size) + Float.floatToIntBits(this.matrix[0]) + Float.floatToIntBits(this.matrix[1]) + Float.floatToIntBits(this.matrix[2]) + Float.floatToIntBits(this.matrix[3]);
/*    */     }
/* 65 */     return this.hash;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 77 */     FontStrikeDesc fontStrikeDesc = (FontStrikeDesc)paramObject;
/* 78 */     return (this.aaMode == fontStrikeDesc.aaMode && this.matrix[0] == fontStrikeDesc.matrix[0] && this.matrix[1] == fontStrikeDesc.matrix[1] && this.matrix[2] == fontStrikeDesc.matrix[2] && this.matrix[3] == fontStrikeDesc.matrix[3] && this.size == fontStrikeDesc.size);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontStrikeDesc.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */