/*     */ package com.sun.webkit;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WCWidget
/*     */ {
/*  33 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCWidget.class.getName());
/*     */   
/*     */   static {
/*  36 */     initIDs();
/*     */   }
/*     */   
/*     */   private int x;
/*     */   private int y;
/*     */   private int width;
/*     */   private int height;
/*     */   private final WebPage page;
/*     */   
/*     */   WCWidget(WebPage paramWebPage) {
/*  46 */     this.page = paramWebPage;
/*     */   }
/*     */   
/*     */   WebPage getPage() {
/*  50 */     return this.page;
/*     */   }
/*     */   
/*     */   WCRectangle getBounds() {
/*  54 */     return new WCRectangle(this.x, this.y, this.width, this.height);
/*     */   }
/*     */   
/*     */   void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  58 */     this.x = paramInt1;
/*  59 */     this.y = paramInt2;
/*  60 */     this.width = paramInt3;
/*  61 */     this.height = paramInt4;
/*     */   }
/*     */   
/*     */   protected void destroy() {}
/*     */   
/*     */   protected void requestFocus() {}
/*     */   
/*     */   protected void setCursor(long paramLong) {}
/*     */   
/*     */   protected void setVisible(boolean paramBoolean) {}
/*     */   
/*     */   private void fwkDestroy() {
/*  73 */     log.finer("destroy");
/*  74 */     destroy();
/*     */   }
/*     */   
/*     */   private void fwkSetBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  78 */     if (log.isLoggable(PlatformLogger.Level.FINER))
/*  79 */       log.finer("setBounds({0}, {1}, {2}, {3})", new Object[] {
/*  80 */             Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4)
/*     */           }); 
/*  82 */     setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   private void fwkRequestFocus() {
/*  86 */     log.finer("requestFocus");
/*  87 */     requestFocus();
/*     */   }
/*     */   
/*     */   private void fwkSetCursor(long paramLong) {
/*  91 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/*  92 */       log.finer("setCursor({0})", new Object[] { Long.valueOf(paramLong) });
/*     */     }
/*  94 */     setCursor(paramLong);
/*     */   }
/*     */   
/*     */   private void fwkSetVisible(boolean paramBoolean) {
/*  98 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/*  99 */       log.finer("setVisible({0})", new Object[] { Boolean.valueOf(paramBoolean) });
/*     */     }
/* 101 */     setVisible(paramBoolean);
/*     */   }
/*     */   
/*     */   protected int fwkGetScreenDepth() {
/* 105 */     log.finer("getScreenDepth");
/* 106 */     WebPageClient webPageClient = this.page.getPageClient();
/* 107 */     return (webPageClient != null) ? 
/* 108 */       webPageClient.getScreenDepth() : 
/* 109 */       24;
/*     */   }
/*     */   
/*     */   protected WCRectangle fwkGetScreenRect(boolean paramBoolean) {
/* 113 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/* 114 */       log.finer("getScreenRect({0})", new Object[] { Boolean.valueOf(paramBoolean) });
/*     */     }
/* 116 */     WebPageClient webPageClient = this.page.getPageClient();
/* 117 */     return (webPageClient != null) ? 
/* 118 */       webPageClient.getScreenBounds(paramBoolean) : 
/* 119 */       null;
/*     */   }
/*     */   
/*     */   private static native void initIDs();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\WCWidget.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */