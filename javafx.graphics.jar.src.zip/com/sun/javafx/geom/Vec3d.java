/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vec3d
/*     */ {
/*     */   public double x;
/*     */   public double y;
/*     */   public double z;
/*     */   
/*     */   public Vec3d() {}
/*     */   
/*     */   public Vec3d(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  51 */     this.x = paramDouble1;
/*  52 */     this.y = paramDouble2;
/*  53 */     this.z = paramDouble3;
/*     */   }
/*     */   
/*     */   public Vec3d(Vec3d paramVec3d) {
/*  57 */     set(paramVec3d);
/*     */   }
/*     */   
/*     */   public Vec3d(Vec3f paramVec3f) {
/*  61 */     set(paramVec3f);
/*     */   }
/*     */   
/*     */   public void set(Vec3f paramVec3f) {
/*  65 */     this.x = paramVec3f.x;
/*  66 */     this.y = paramVec3f.y;
/*  67 */     this.z = paramVec3f.z;
/*     */   }
/*     */   
/*     */   public void set(Vec3d paramVec3d) {
/*  71 */     this.x = paramVec3d.x;
/*  72 */     this.y = paramVec3d.y;
/*  73 */     this.z = paramVec3d.z;
/*     */   }
/*     */   
/*     */   public void set(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  77 */     this.x = paramDouble1;
/*  78 */     this.y = paramDouble2;
/*  79 */     this.z = paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mul(double paramDouble) {
/*  87 */     this.x *= paramDouble;
/*  88 */     this.y *= paramDouble;
/*  89 */     this.z *= paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sub(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/*  99 */     this.x = (paramVec3f1.x - paramVec3f2.x);
/* 100 */     this.y = (paramVec3f1.y - paramVec3f2.y);
/* 101 */     this.z = (paramVec3f1.z - paramVec3f2.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sub(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 111 */     paramVec3d1.x -= paramVec3d2.x;
/* 112 */     paramVec3d1.y -= paramVec3d2.y;
/* 113 */     paramVec3d1.z -= paramVec3d2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sub(Vec3d paramVec3d) {
/* 122 */     this.x -= paramVec3d.x;
/* 123 */     this.y -= paramVec3d.y;
/* 124 */     this.z -= paramVec3d.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 134 */     paramVec3d1.x += paramVec3d2.x;
/* 135 */     paramVec3d1.y += paramVec3d2.y;
/* 136 */     paramVec3d1.z += paramVec3d2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Vec3d paramVec3d) {
/* 145 */     this.x += paramVec3d.x;
/* 146 */     this.y += paramVec3d.y;
/* 147 */     this.z += paramVec3d.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double length() {
/* 155 */     return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void normalize() {
/* 162 */     double d = 1.0D / length();
/* 163 */     this.x *= d;
/* 164 */     this.y *= d;
/* 165 */     this.z *= d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cross(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 177 */     double d1 = paramVec3d1.y * paramVec3d2.z - paramVec3d1.z * paramVec3d2.y;
/* 178 */     double d2 = paramVec3d2.x * paramVec3d1.z - paramVec3d2.z * paramVec3d1.x;
/* 179 */     this.z = paramVec3d1.x * paramVec3d2.y - paramVec3d1.y * paramVec3d2.x;
/* 180 */     this.x = d1;
/* 181 */     this.y = d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double dot(Vec3d paramVec3d) {
/* 190 */     return this.x * paramVec3d.x + this.y * paramVec3d.y + this.z * paramVec3d.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 199 */     long l = 7L;
/* 200 */     l = 31L * l + Double.doubleToLongBits(this.x);
/* 201 */     l = 31L * l + Double.doubleToLongBits(this.y);
/* 202 */     l = 31L * l + Double.doubleToLongBits(this.z);
/* 203 */     return (int)(l ^ l >> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 218 */     if (paramObject == this) {
/* 219 */       return true;
/*     */     }
/* 221 */     if (paramObject instanceof Vec3d) {
/* 222 */       Vec3d vec3d = (Vec3d)paramObject;
/* 223 */       return (this.x == vec3d.x && this.y == vec3d.y && this.z == vec3d.z);
/*     */     } 
/* 225 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 235 */     return "Vec3d[" + this.x + ", " + this.y + ", " + this.z + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec3d.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */