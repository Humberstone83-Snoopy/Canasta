/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ import com.sun.javafx.font.DisposerRecord;
/*    */ import com.sun.javafx.font.FontResource;
/*    */ import com.sun.javafx.font.FontStrikeDesc;
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CTStrikeDisposer
/*    */   implements DisposerRecord
/*    */ {
/*    */   private FontResource fontResource;
/*    */   private FontStrikeDesc desc;
/* 39 */   private long fontRef = 0L;
/*    */ 
/*    */   
/*    */   private boolean disposed = false;
/*    */ 
/*    */   
/*    */   public CTStrikeDisposer(FontResource paramFontResource, FontStrikeDesc paramFontStrikeDesc, long paramLong) {
/* 46 */     this.fontResource = paramFontResource;
/* 47 */     this.desc = paramFontStrikeDesc;
/* 48 */     this.fontRef = paramLong;
/*    */   }
/*    */   
/*    */   public synchronized void dispose() {
/* 52 */     if (!this.disposed) {
/*    */ 
/*    */ 
/*    */       
/* 56 */       WeakReference<Object> weakReference = (WeakReference)this.fontResource.getStrikeMap().get(this.desc);
/* 57 */       if (weakReference != null) {
/* 58 */         Object object = weakReference.get();
/* 59 */         if (object == null) {
/* 60 */           this.fontResource.getStrikeMap().remove(this.desc);
/*    */         }
/*    */       } 
/* 63 */       if (this.fontRef != 0L) {
/* 64 */         OS.CFRelease(this.fontRef);
/* 65 */         this.fontRef = 0L;
/*    */       } 
/* 67 */       this.disposed = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CTStrikeDisposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */