/*     */ package com.sun.javafx.geom.transform;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ import com.sun.javafx.geom.Vec3f;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GeneralTransform3D
/*     */   implements CanTransformVec3d
/*     */ {
/*  42 */   protected double[] mat = new double[16];
/*     */   
/*     */   private boolean identity;
/*     */   
/*     */   private Vec3d tempV3d;
/*     */   
/*     */   private static final double EPSILON_ABSOLUTE = 1.0E-5D;
/*     */   
/*     */   public GeneralTransform3D() {
/*  51 */     setIdentity();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAffine() {
/*  60 */     if (!isInfOrNaN() && 
/*  61 */       almostZero(this.mat[12]) && 
/*  62 */       almostZero(this.mat[13]) && 
/*  63 */       almostZero(this.mat[14]) && 
/*  64 */       almostOne(this.mat[15]))
/*     */     {
/*  66 */       return true;
/*     */     }
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D set(GeneralTransform3D paramGeneralTransform3D) {
/*  80 */     System.arraycopy(paramGeneralTransform3D.mat, 0, this.mat, 0, this.mat.length);
/*  81 */     updateState();
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D set(double[] paramArrayOfdouble) {
/*  95 */     System.arraycopy(paramArrayOfdouble, 0, this.mat, 0, this.mat.length);
/*  96 */     updateState();
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double[] get(double[] paramArrayOfdouble) {
/* 110 */     if (paramArrayOfdouble == null) {
/* 111 */       paramArrayOfdouble = new double[this.mat.length];
/*     */     }
/* 113 */     System.arraycopy(this.mat, 0, paramArrayOfdouble, 0, this.mat.length);
/*     */     
/* 115 */     return paramArrayOfdouble;
/*     */   }
/*     */   
/*     */   public double get(int paramInt) {
/* 119 */     assert paramInt >= 0 && paramInt < this.mat.length;
/* 120 */     return this.mat[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/* 126 */     if (this.tempV3d == null) {
/* 127 */       this.tempV3d = new Vec3d();
/*     */     }
/* 129 */     return TransformHelper.general3dBoundsTransform(this, paramBaseBounds1, paramBaseBounds2, this.tempV3d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point2D transform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 139 */     if (paramPoint2D2 == null) {
/* 140 */       paramPoint2D2 = new Point2D();
/*     */     }
/*     */     
/* 143 */     double d = this.mat[12] * paramPoint2D1.x + this.mat[13] * paramPoint2D1.y + this.mat[15];
/* 144 */     float f = (float)(this.mat[0] * paramPoint2D1.x + this.mat[1] * paramPoint2D1.y + this.mat[3]);
/* 145 */     paramPoint2D2.y = (float)(this.mat[4] * paramPoint2D1.x + this.mat[5] * paramPoint2D1.y + this.mat[7]);
/*     */     
/* 147 */     paramPoint2D2.x = f;
/* 148 */     if (d != 0.0D) {
/* 149 */       paramPoint2D2.x = (float)(paramPoint2D2.x / d);
/* 150 */       paramPoint2D2.y = (float)(paramPoint2D2.y / d);
/*     */     } 
/*     */     
/* 153 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 168 */     if (paramVec3d2 == null) {
/* 169 */       paramVec3d2 = new Vec3d();
/*     */     }
/*     */     
/* 172 */     double d1 = this.mat[12] * paramVec3d1.x + this.mat[13] * paramVec3d1.y + this.mat[14] * paramVec3d1.z + this.mat[15];
/*     */     
/* 174 */     double d2 = this.mat[0] * paramVec3d1.x + this.mat[1] * paramVec3d1.y + this.mat[2] * paramVec3d1.z + this.mat[3];
/*     */     
/* 176 */     double d3 = this.mat[4] * paramVec3d1.x + this.mat[5] * paramVec3d1.y + this.mat[6] * paramVec3d1.z + this.mat[7];
/*     */     
/* 178 */     paramVec3d2.z = this.mat[8] * paramVec3d1.x + this.mat[9] * paramVec3d1.y + this.mat[10] * paramVec3d1.z + this.mat[11];
/*     */ 
/*     */     
/* 181 */     paramVec3d2.x = d2;
/* 182 */     paramVec3d2.y = d3;
/* 183 */     if (d1 != 0.0D) {
/* 184 */       paramVec3d2.x /= d1;
/* 185 */       paramVec3d2.y /= d1;
/* 186 */       paramVec3d2.z /= d1;
/*     */     } 
/*     */     
/* 189 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3d transform(Vec3d paramVec3d) {
/* 203 */     return transform(paramVec3d, paramVec3d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f transformNormal(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/* 221 */     if (paramVec3f2 == null) {
/* 222 */       paramVec3f2 = new Vec3f();
/*     */     }
/*     */     
/* 225 */     float f1 = (float)(this.mat[0] * paramVec3f1.x + this.mat[1] * paramVec3f1.y + this.mat[2] * paramVec3f1.z);
/*     */     
/* 227 */     float f2 = (float)(this.mat[4] * paramVec3f1.x + this.mat[5] * paramVec3f1.y + this.mat[6] * paramVec3f1.z);
/*     */     
/* 229 */     paramVec3f2.z = (float)(this.mat[8] * paramVec3f1.x + this.mat[9] * paramVec3f1.y + this.mat[10] * paramVec3f1.z);
/*     */ 
/*     */     
/* 232 */     paramVec3f2.x = f1;
/* 233 */     paramVec3f2.y = f2;
/* 234 */     return paramVec3f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vec3f transformNormal(Vec3f paramVec3f) {
/* 250 */     return transformNormal(paramVec3f, paramVec3f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D perspective(boolean paramBoolean, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 279 */     double d4 = paramDouble1 * 0.5D;
/*     */     
/* 281 */     double d3 = paramDouble4 - paramDouble3;
/* 282 */     double d1 = Math.sin(d4);
/*     */     
/* 284 */     double d2 = Math.cos(d4) / d1;
/*     */     
/* 286 */     this.mat[0] = paramBoolean ? (d2 / paramDouble2) : d2;
/* 287 */     this.mat[5] = paramBoolean ? d2 : (d2 * paramDouble2);
/* 288 */     this.mat[10] = -(paramDouble4 + paramDouble3) / d3;
/* 289 */     this.mat[11] = -2.0D * paramDouble3 * paramDouble4 / d3;
/* 290 */     this.mat[14] = -1.0D;
/* 291 */     this.mat[15] = 0.0D; this.mat[13] = 0.0D; this.mat[12] = 0.0D; this.mat[9] = 0.0D; this.mat[8] = 0.0D; this.mat[7] = 0.0D; this.mat[6] = 0.0D; this.mat[4] = 0.0D; this.mat[3] = 0.0D; this.mat[2] = 0.0D; this.mat[1] = 0.0D;
/*     */     
/* 293 */     updateState();
/* 294 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D ortho(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 320 */     double d1 = 1.0D / (paramDouble2 - paramDouble1);
/* 321 */     double d2 = 1.0D / (paramDouble4 - paramDouble3);
/* 322 */     double d3 = 1.0D / (paramDouble6 - paramDouble5);
/*     */     
/* 324 */     this.mat[0] = 2.0D * d1;
/* 325 */     this.mat[3] = -(paramDouble2 + paramDouble1) * d1;
/* 326 */     this.mat[5] = 2.0D * d2;
/* 327 */     this.mat[7] = -(paramDouble4 + paramDouble3) * d2;
/* 328 */     this.mat[10] = 2.0D * d3;
/* 329 */     this.mat[11] = (paramDouble6 + paramDouble5) * d3;
/* 330 */     this.mat[14] = 0.0D; this.mat[13] = 0.0D; this.mat[12] = 0.0D; this.mat[9] = 0.0D; this.mat[8] = 0.0D; this.mat[6] = 0.0D; this.mat[4] = 0.0D; this.mat[2] = 0.0D; this.mat[1] = 0.0D;
/*     */     
/* 332 */     this.mat[15] = 1.0D;
/*     */     
/* 334 */     updateState();
/* 335 */     return this;
/*     */   }
/*     */   
/*     */   public double computeClipZCoord() {
/* 339 */     double d = (1.0D - this.mat[15]) / this.mat[14];
/* 340 */     return this.mat[10] * d + this.mat[11];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double determinant() {
/* 351 */     return this.mat[0] * (this.mat[5] * (this.mat[10] * this.mat[15] - this.mat[11] * this.mat[14]) - this.mat[6] * (this.mat[9] * this.mat[15] - this.mat[11] * this.mat[13]) + this.mat[7] * (this.mat[9] * this.mat[14] - this.mat[10] * this.mat[13])) - this.mat[1] * (this.mat[4] * (this.mat[10] * this.mat[15] - this.mat[11] * this.mat[14]) - this.mat[6] * (this.mat[8] * this.mat[15] - this.mat[11] * this.mat[12]) + this.mat[7] * (this.mat[8] * this.mat[14] - this.mat[10] * this.mat[12])) + this.mat[2] * (this.mat[4] * (this.mat[9] * this.mat[15] - this.mat[11] * this.mat[13]) - this.mat[5] * (this.mat[8] * this.mat[15] - this.mat[11] * this.mat[12]) + this.mat[7] * (this.mat[8] * this.mat[13] - this.mat[9] * this.mat[12])) - this.mat[3] * (this.mat[4] * (this.mat[9] * this.mat[14] - this.mat[10] * this.mat[13]) - this.mat[5] * (this.mat[8] * this.mat[14] - this.mat[10] * this.mat[12]) + this.mat[6] * (this.mat[8] * this.mat[13] - this.mat[9] * this.mat[12]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D invert() {
/* 371 */     return invert(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GeneralTransform3D invert(GeneralTransform3D paramGeneralTransform3D) {
/* 383 */     double[] arrayOfDouble = new double[16];
/* 384 */     int[] arrayOfInt = new int[4];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     System.arraycopy(paramGeneralTransform3D.mat, 0, arrayOfDouble, 0, arrayOfDouble.length);
/*     */ 
/*     */     
/* 392 */     if (!luDecomposition(arrayOfDouble, arrayOfInt))
/*     */     {
/* 394 */       throw new SingularMatrixException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     this.mat[0] = 1.0D; this.mat[1] = 0.0D; this.mat[2] = 0.0D; this.mat[3] = 0.0D;
/* 401 */     this.mat[4] = 0.0D; this.mat[5] = 1.0D; this.mat[6] = 0.0D; this.mat[7] = 0.0D;
/* 402 */     this.mat[8] = 0.0D; this.mat[9] = 0.0D; this.mat[10] = 1.0D; this.mat[11] = 0.0D;
/* 403 */     this.mat[12] = 0.0D; this.mat[13] = 0.0D; this.mat[14] = 0.0D; this.mat[15] = 1.0D;
/* 404 */     luBacksubstitution(arrayOfDouble, arrayOfInt, this.mat);
/*     */     
/* 406 */     updateState();
/* 407 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean luDecomposition(double[] paramArrayOfdouble, int[] paramArrayOfint) {
/* 434 */     double[] arrayOfDouble = new double[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     int i = 0;
/* 443 */     int j = 0;
/*     */ 
/*     */     
/* 446 */     byte b1 = 4;
/* 447 */     while (b1-- != 0) {
/* 448 */       double d = 0.0D;
/*     */ 
/*     */       
/* 451 */       byte b = 4;
/* 452 */       while (b-- != 0) {
/* 453 */         double d1 = paramArrayOfdouble[i++];
/* 454 */         d1 = Math.abs(d1);
/* 455 */         if (d1 > d) {
/* 456 */           d = d1;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 461 */       if (d == 0.0D) {
/* 462 */         return false;
/*     */       }
/* 464 */       arrayOfDouble[j++] = 1.0D / d;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 472 */     byte b2 = 0;
/*     */ 
/*     */     
/* 475 */     for (b1 = 0; b1 < 4; b1++) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 481 */       for (i = 0; i < b1; i++) {
/* 482 */         int m = b2 + 4 * i + b1;
/* 483 */         double d1 = paramArrayOfdouble[m];
/* 484 */         int k = i;
/* 485 */         int n = b2 + 4 * i;
/* 486 */         int i1 = b2 + b1;
/* 487 */         while (k-- != 0) {
/* 488 */           d1 -= paramArrayOfdouble[n] * paramArrayOfdouble[i1];
/* 489 */           n++;
/* 490 */           i1 += 4;
/*     */         } 
/* 492 */         paramArrayOfdouble[m] = d1;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 497 */       double d = 0.0D;
/* 498 */       j = -1;
/* 499 */       for (i = b1; i < 4; i++) {
/* 500 */         int k = b2 + 4 * i + b1;
/* 501 */         double d1 = paramArrayOfdouble[k];
/* 502 */         byte b = b1;
/* 503 */         int m = b2 + 4 * i;
/* 504 */         int n = b2 + b1;
/* 505 */         while (b-- != 0) {
/* 506 */           d1 -= paramArrayOfdouble[m] * paramArrayOfdouble[n];
/* 507 */           m++;
/* 508 */           n += 4;
/*     */         } 
/* 510 */         paramArrayOfdouble[k] = d1;
/*     */         
/*     */         double d2;
/* 513 */         if ((d2 = arrayOfDouble[i] * Math.abs(d1)) >= d) {
/* 514 */           d = d2;
/* 515 */           j = i;
/*     */         } 
/*     */       } 
/*     */       
/* 519 */       if (j < 0) {
/* 520 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 524 */       if (b1 != j) {
/*     */         
/* 526 */         byte b = 4;
/* 527 */         int k = b2 + 4 * j;
/* 528 */         int m = b2 + 4 * b1;
/* 529 */         while (b-- != 0) {
/* 530 */           double d1 = paramArrayOfdouble[k];
/* 531 */           paramArrayOfdouble[k++] = paramArrayOfdouble[m];
/* 532 */           paramArrayOfdouble[m++] = d1;
/*     */         } 
/*     */ 
/*     */         
/* 536 */         arrayOfDouble[j] = arrayOfDouble[b1];
/*     */       } 
/*     */ 
/*     */       
/* 540 */       paramArrayOfint[b1] = j;
/*     */ 
/*     */       
/* 543 */       if (paramArrayOfdouble[b2 + 4 * b1 + b1] == 0.0D) {
/* 544 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 548 */       if (b1 != 3) {
/* 549 */         double d1 = 1.0D / paramArrayOfdouble[b2 + 4 * b1 + b1];
/* 550 */         int k = b2 + 4 * (b1 + 1) + b1;
/* 551 */         i = 3 - b1;
/* 552 */         while (i-- != 0) {
/* 553 */           paramArrayOfdouble[k] = paramArrayOfdouble[k] * d1;
/* 554 */           k += 4;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 560 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void luBacksubstitution(double[] paramArrayOfdouble1, int[] paramArrayOfint, double[] paramArrayOfdouble2) {
/* 591 */     byte b2 = 0;
/*     */ 
/*     */     
/* 594 */     for (byte b1 = 0; b1 < 4; b1++) {
/*     */       
/* 596 */       byte b4 = b1;
/* 597 */       byte b = -1;
/*     */ 
/*     */       
/* 600 */       for (byte b3 = 0; b3 < 4; b3++) {
/*     */ 
/*     */         
/* 603 */         int i = paramArrayOfint[b2 + b3];
/* 604 */         double d = paramArrayOfdouble2[b4 + 4 * i];
/* 605 */         paramArrayOfdouble2[b4 + 4 * i] = paramArrayOfdouble2[b4 + 4 * b3];
/* 606 */         if (b >= 0) {
/*     */           
/* 608 */           int j = b3 * 4;
/* 609 */           for (byte b6 = b; b6 <= b3 - 1; b6++) {
/* 610 */             d -= paramArrayOfdouble1[j + b6] * paramArrayOfdouble2[b4 + 4 * b6];
/*     */           }
/*     */         }
/* 613 */         else if (d != 0.0D) {
/* 614 */           b = b3;
/*     */         } 
/* 616 */         paramArrayOfdouble2[b4 + 4 * b3] = d;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 621 */       byte b5 = 12;
/* 622 */       paramArrayOfdouble2[b4 + 12] = paramArrayOfdouble2[b4 + 12] / paramArrayOfdouble1[b5 + 3];
/*     */       
/* 624 */       b5 -= 4;
/* 625 */       paramArrayOfdouble2[b4 + 8] = (paramArrayOfdouble2[b4 + 8] - paramArrayOfdouble1[b5 + 3] * paramArrayOfdouble2[b4 + 12]) / paramArrayOfdouble1[b5 + 2];
/*     */ 
/*     */       
/* 628 */       b5 -= 4;
/* 629 */       paramArrayOfdouble2[b4 + 4] = (paramArrayOfdouble2[b4 + 4] - paramArrayOfdouble1[b5 + 2] * paramArrayOfdouble2[b4 + 8] - paramArrayOfdouble1[b5 + 3] * paramArrayOfdouble2[b4 + 12]) / paramArrayOfdouble1[b5 + 1];
/*     */ 
/*     */ 
/*     */       
/* 633 */       b5 -= 4;
/* 634 */       paramArrayOfdouble2[b4 + 0] = (paramArrayOfdouble2[b4 + 0] - paramArrayOfdouble1[b5 + 1] * paramArrayOfdouble2[b4 + 4] - paramArrayOfdouble1[b5 + 2] * paramArrayOfdouble2[b4 + 8] - paramArrayOfdouble1[b5 + 3] * paramArrayOfdouble2[b4 + 12]) / paramArrayOfdouble1[b5 + 0];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D mul(BaseTransform paramBaseTransform) {
/* 651 */     if (paramBaseTransform.isIdentity()) {
/* 652 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 660 */     double d17 = paramBaseTransform.getMxx();
/* 661 */     double d18 = paramBaseTransform.getMxy();
/* 662 */     double d19 = paramBaseTransform.getMxz();
/* 663 */     double d20 = paramBaseTransform.getMxt();
/* 664 */     double d21 = paramBaseTransform.getMyx();
/* 665 */     double d22 = paramBaseTransform.getMyy();
/* 666 */     double d23 = paramBaseTransform.getMyz();
/* 667 */     double d24 = paramBaseTransform.getMyt();
/* 668 */     double d25 = paramBaseTransform.getMzx();
/* 669 */     double d26 = paramBaseTransform.getMzy();
/* 670 */     double d27 = paramBaseTransform.getMzz();
/* 671 */     double d28 = paramBaseTransform.getMzt();
/*     */     
/* 673 */     double d1 = this.mat[0] * d17 + this.mat[1] * d21 + this.mat[2] * d25;
/* 674 */     double d2 = this.mat[0] * d18 + this.mat[1] * d22 + this.mat[2] * d26;
/* 675 */     double d3 = this.mat[0] * d19 + this.mat[1] * d23 + this.mat[2] * d27;
/* 676 */     double d4 = this.mat[0] * d20 + this.mat[1] * d24 + this.mat[2] * d28 + this.mat[3];
/* 677 */     double d5 = this.mat[4] * d17 + this.mat[5] * d21 + this.mat[6] * d25;
/* 678 */     double d6 = this.mat[4] * d18 + this.mat[5] * d22 + this.mat[6] * d26;
/* 679 */     double d7 = this.mat[4] * d19 + this.mat[5] * d23 + this.mat[6] * d27;
/* 680 */     double d8 = this.mat[4] * d20 + this.mat[5] * d24 + this.mat[6] * d28 + this.mat[7];
/* 681 */     double d9 = this.mat[8] * d17 + this.mat[9] * d21 + this.mat[10] * d25;
/* 682 */     double d10 = this.mat[8] * d18 + this.mat[9] * d22 + this.mat[10] * d26;
/* 683 */     double d11 = this.mat[8] * d19 + this.mat[9] * d23 + this.mat[10] * d27;
/* 684 */     double d12 = this.mat[8] * d20 + this.mat[9] * d24 + this.mat[10] * d28 + this.mat[11];
/*     */     
/* 686 */     double d15 = 0.0D, d14 = d15, d13 = d14;
/* 687 */     double d16 = 1.0D;
/*     */ 
/*     */     
/* 690 */     d13 = this.mat[12] * d17 + this.mat[13] * d21 + this.mat[14] * d25;
/* 691 */     d14 = this.mat[12] * d18 + this.mat[13] * d22 + this.mat[14] * d26;
/* 692 */     d15 = this.mat[12] * d19 + this.mat[13] * d23 + this.mat[14] * d27;
/* 693 */     d16 = this.mat[12] * d20 + this.mat[13] * d24 + this.mat[14] * d28 + this.mat[15];
/*     */ 
/*     */     
/* 696 */     this.mat[0] = d1;
/* 697 */     this.mat[1] = d2;
/* 698 */     this.mat[2] = d3;
/* 699 */     this.mat[3] = d4;
/* 700 */     this.mat[4] = d5;
/* 701 */     this.mat[5] = d6;
/* 702 */     this.mat[6] = d7;
/* 703 */     this.mat[7] = d8;
/* 704 */     this.mat[8] = d9;
/* 705 */     this.mat[9] = d10;
/* 706 */     this.mat[10] = d11;
/* 707 */     this.mat[11] = d12;
/* 708 */     this.mat[12] = d13;
/* 709 */     this.mat[13] = d14;
/* 710 */     this.mat[14] = d15;
/* 711 */     this.mat[15] = d16;
/*     */     
/* 713 */     updateState();
/* 714 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D scale(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 736 */     boolean bool = false;
/*     */     
/* 738 */     if (paramDouble1 != 1.0D) {
/* 739 */       this.mat[0] = this.mat[0] * paramDouble1;
/* 740 */       this.mat[4] = this.mat[4] * paramDouble1;
/* 741 */       this.mat[8] = this.mat[8] * paramDouble1;
/* 742 */       this.mat[12] = this.mat[12] * paramDouble1;
/* 743 */       bool = true;
/*     */     } 
/* 745 */     if (paramDouble2 != 1.0D) {
/* 746 */       this.mat[1] = this.mat[1] * paramDouble2;
/* 747 */       this.mat[5] = this.mat[5] * paramDouble2;
/* 748 */       this.mat[9] = this.mat[9] * paramDouble2;
/* 749 */       this.mat[13] = this.mat[13] * paramDouble2;
/* 750 */       bool = true;
/*     */     } 
/* 752 */     if (paramDouble3 != 1.0D) {
/* 753 */       this.mat[2] = this.mat[2] * paramDouble3;
/* 754 */       this.mat[6] = this.mat[6] * paramDouble3;
/* 755 */       this.mat[10] = this.mat[10] * paramDouble3;
/* 756 */       this.mat[14] = this.mat[14] * paramDouble3;
/* 757 */       bool = true;
/*     */     } 
/*     */     
/* 760 */     if (bool) {
/* 761 */       updateState();
/*     */     }
/* 763 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D mul(GeneralTransform3D paramGeneralTransform3D) {
/* 775 */     if (paramGeneralTransform3D.isIdentity()) {
/* 776 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 785 */     double d1 = this.mat[0] * paramGeneralTransform3D.mat[0] + this.mat[1] * paramGeneralTransform3D.mat[4] + this.mat[2] * paramGeneralTransform3D.mat[8];
/* 786 */     double d2 = this.mat[0] * paramGeneralTransform3D.mat[1] + this.mat[1] * paramGeneralTransform3D.mat[5] + this.mat[2] * paramGeneralTransform3D.mat[9];
/* 787 */     double d3 = this.mat[0] * paramGeneralTransform3D.mat[2] + this.mat[1] * paramGeneralTransform3D.mat[6] + this.mat[2] * paramGeneralTransform3D.mat[10];
/* 788 */     double d4 = this.mat[0] * paramGeneralTransform3D.mat[3] + this.mat[1] * paramGeneralTransform3D.mat[7] + this.mat[2] * paramGeneralTransform3D.mat[11] + this.mat[3];
/* 789 */     double d5 = this.mat[4] * paramGeneralTransform3D.mat[0] + this.mat[5] * paramGeneralTransform3D.mat[4] + this.mat[6] * paramGeneralTransform3D.mat[8];
/* 790 */     double d6 = this.mat[4] * paramGeneralTransform3D.mat[1] + this.mat[5] * paramGeneralTransform3D.mat[5] + this.mat[6] * paramGeneralTransform3D.mat[9];
/* 791 */     double d7 = this.mat[4] * paramGeneralTransform3D.mat[2] + this.mat[5] * paramGeneralTransform3D.mat[6] + this.mat[6] * paramGeneralTransform3D.mat[10];
/* 792 */     double d8 = this.mat[4] * paramGeneralTransform3D.mat[3] + this.mat[5] * paramGeneralTransform3D.mat[7] + this.mat[6] * paramGeneralTransform3D.mat[11] + this.mat[7];
/* 793 */     double d9 = this.mat[8] * paramGeneralTransform3D.mat[0] + this.mat[9] * paramGeneralTransform3D.mat[4] + this.mat[10] * paramGeneralTransform3D.mat[8];
/* 794 */     double d10 = this.mat[8] * paramGeneralTransform3D.mat[1] + this.mat[9] * paramGeneralTransform3D.mat[5] + this.mat[10] * paramGeneralTransform3D.mat[9];
/* 795 */     double d11 = this.mat[8] * paramGeneralTransform3D.mat[2] + this.mat[9] * paramGeneralTransform3D.mat[6] + this.mat[10] * paramGeneralTransform3D.mat[10];
/* 796 */     double d12 = this.mat[8] * paramGeneralTransform3D.mat[3] + this.mat[9] * paramGeneralTransform3D.mat[7] + this.mat[10] * paramGeneralTransform3D.mat[11] + this.mat[11];
/*     */     
/* 798 */     double d15 = 0.0D, d14 = d15, d13 = d14;
/* 799 */     double d16 = 1.0D;
/*     */ 
/*     */     
/* 802 */     d13 = this.mat[12] * paramGeneralTransform3D.mat[0] + this.mat[13] * paramGeneralTransform3D.mat[4] + this.mat[14] * paramGeneralTransform3D.mat[8];
/*     */     
/* 804 */     d14 = this.mat[12] * paramGeneralTransform3D.mat[1] + this.mat[13] * paramGeneralTransform3D.mat[5] + this.mat[14] * paramGeneralTransform3D.mat[9];
/*     */     
/* 806 */     d15 = this.mat[12] * paramGeneralTransform3D.mat[2] + this.mat[13] * paramGeneralTransform3D.mat[6] + this.mat[14] * paramGeneralTransform3D.mat[10];
/*     */     
/* 808 */     d16 = this.mat[12] * paramGeneralTransform3D.mat[3] + this.mat[13] * paramGeneralTransform3D.mat[7] + this.mat[14] * paramGeneralTransform3D.mat[11] + this.mat[15];
/*     */ 
/*     */ 
/*     */     
/* 812 */     d1 = this.mat[0] * paramGeneralTransform3D.mat[0] + this.mat[1] * paramGeneralTransform3D.mat[4] + this.mat[2] * paramGeneralTransform3D.mat[8] + this.mat[3] * paramGeneralTransform3D.mat[12];
/*     */     
/* 814 */     d2 = this.mat[0] * paramGeneralTransform3D.mat[1] + this.mat[1] * paramGeneralTransform3D.mat[5] + this.mat[2] * paramGeneralTransform3D.mat[9] + this.mat[3] * paramGeneralTransform3D.mat[13];
/*     */     
/* 816 */     d3 = this.mat[0] * paramGeneralTransform3D.mat[2] + this.mat[1] * paramGeneralTransform3D.mat[6] + this.mat[2] * paramGeneralTransform3D.mat[10] + this.mat[3] * paramGeneralTransform3D.mat[14];
/*     */     
/* 818 */     d4 = this.mat[0] * paramGeneralTransform3D.mat[3] + this.mat[1] * paramGeneralTransform3D.mat[7] + this.mat[2] * paramGeneralTransform3D.mat[11] + this.mat[3] * paramGeneralTransform3D.mat[15];
/*     */     
/* 820 */     d5 = this.mat[4] * paramGeneralTransform3D.mat[0] + this.mat[5] * paramGeneralTransform3D.mat[4] + this.mat[6] * paramGeneralTransform3D.mat[8] + this.mat[7] * paramGeneralTransform3D.mat[12];
/*     */     
/* 822 */     d6 = this.mat[4] * paramGeneralTransform3D.mat[1] + this.mat[5] * paramGeneralTransform3D.mat[5] + this.mat[6] * paramGeneralTransform3D.mat[9] + this.mat[7] * paramGeneralTransform3D.mat[13];
/*     */     
/* 824 */     d7 = this.mat[4] * paramGeneralTransform3D.mat[2] + this.mat[5] * paramGeneralTransform3D.mat[6] + this.mat[6] * paramGeneralTransform3D.mat[10] + this.mat[7] * paramGeneralTransform3D.mat[14];
/*     */     
/* 826 */     d8 = this.mat[4] * paramGeneralTransform3D.mat[3] + this.mat[5] * paramGeneralTransform3D.mat[7] + this.mat[6] * paramGeneralTransform3D.mat[11] + this.mat[7] * paramGeneralTransform3D.mat[15];
/*     */     
/* 828 */     d9 = this.mat[8] * paramGeneralTransform3D.mat[0] + this.mat[9] * paramGeneralTransform3D.mat[4] + this.mat[10] * paramGeneralTransform3D.mat[8] + this.mat[11] * paramGeneralTransform3D.mat[12];
/*     */     
/* 830 */     d10 = this.mat[8] * paramGeneralTransform3D.mat[1] + this.mat[9] * paramGeneralTransform3D.mat[5] + this.mat[10] * paramGeneralTransform3D.mat[9] + this.mat[11] * paramGeneralTransform3D.mat[13];
/*     */     
/* 832 */     d11 = this.mat[8] * paramGeneralTransform3D.mat[2] + this.mat[9] * paramGeneralTransform3D.mat[6] + this.mat[10] * paramGeneralTransform3D.mat[10] + this.mat[11] * paramGeneralTransform3D.mat[14];
/*     */ 
/*     */     
/* 835 */     d12 = this.mat[8] * paramGeneralTransform3D.mat[3] + this.mat[9] * paramGeneralTransform3D.mat[7] + this.mat[10] * paramGeneralTransform3D.mat[11] + this.mat[11] * paramGeneralTransform3D.mat[15];
/*     */     
/* 837 */     if (isAffine()) {
/* 838 */       d13 = paramGeneralTransform3D.mat[12];
/* 839 */       d14 = paramGeneralTransform3D.mat[13];
/* 840 */       d15 = paramGeneralTransform3D.mat[14];
/* 841 */       d16 = paramGeneralTransform3D.mat[15];
/*     */     } else {
/* 843 */       d13 = this.mat[12] * paramGeneralTransform3D.mat[0] + this.mat[13] * paramGeneralTransform3D.mat[4] + this.mat[14] * paramGeneralTransform3D.mat[8] + this.mat[15] * paramGeneralTransform3D.mat[12];
/*     */       
/* 845 */       d14 = this.mat[12] * paramGeneralTransform3D.mat[1] + this.mat[13] * paramGeneralTransform3D.mat[5] + this.mat[14] * paramGeneralTransform3D.mat[9] + this.mat[15] * paramGeneralTransform3D.mat[13];
/*     */       
/* 847 */       d15 = this.mat[12] * paramGeneralTransform3D.mat[2] + this.mat[13] * paramGeneralTransform3D.mat[6] + this.mat[14] * paramGeneralTransform3D.mat[10] + this.mat[15] * paramGeneralTransform3D.mat[14];
/*     */       
/* 849 */       d16 = this.mat[12] * paramGeneralTransform3D.mat[3] + this.mat[13] * paramGeneralTransform3D.mat[7] + this.mat[14] * paramGeneralTransform3D.mat[11] + this.mat[15] * paramGeneralTransform3D.mat[15];
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 854 */     this.mat[0] = d1;
/* 855 */     this.mat[1] = d2;
/* 856 */     this.mat[2] = d3;
/* 857 */     this.mat[3] = d4;
/* 858 */     this.mat[4] = d5;
/* 859 */     this.mat[5] = d6;
/* 860 */     this.mat[6] = d7;
/* 861 */     this.mat[7] = d8;
/* 862 */     this.mat[8] = d9;
/* 863 */     this.mat[9] = d10;
/* 864 */     this.mat[10] = d11;
/* 865 */     this.mat[11] = d12;
/* 866 */     this.mat[12] = d13;
/* 867 */     this.mat[13] = d14;
/* 868 */     this.mat[14] = d15;
/* 869 */     this.mat[15] = d16;
/*     */     
/* 871 */     updateState();
/* 872 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GeneralTransform3D setIdentity() {
/* 881 */     this.mat[0] = 1.0D; this.mat[1] = 0.0D; this.mat[2] = 0.0D; this.mat[3] = 0.0D;
/* 882 */     this.mat[4] = 0.0D; this.mat[5] = 1.0D; this.mat[6] = 0.0D; this.mat[7] = 0.0D;
/* 883 */     this.mat[8] = 0.0D; this.mat[9] = 0.0D; this.mat[10] = 1.0D; this.mat[11] = 0.0D;
/* 884 */     this.mat[12] = 0.0D; this.mat[13] = 0.0D; this.mat[14] = 0.0D; this.mat[15] = 1.0D;
/* 885 */     this.identity = true;
/* 886 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIdentity() {
/* 895 */     return this.identity;
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateState() {
/* 900 */     this.identity = (this.mat[0] == 1.0D && this.mat[5] == 1.0D && this.mat[10] == 1.0D && this.mat[15] == 1.0D && this.mat[1] == 0.0D && this.mat[2] == 0.0D && this.mat[3] == 0.0D && this.mat[4] == 0.0D && this.mat[6] == 0.0D && this.mat[7] == 0.0D && this.mat[8] == 0.0D && this.mat[9] == 0.0D && this.mat[11] == 0.0D && this.mat[12] == 0.0D && this.mat[13] == 0.0D && this.mat[14] == 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isInfOrNaN() {
/* 914 */     double d = 0.0D;
/* 915 */     for (byte b = 0; b < this.mat.length; b++) {
/* 916 */       d *= this.mat[b];
/*     */     }
/*     */     
/* 919 */     return (d != 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean almostZero(double paramDouble) {
/* 925 */     return (paramDouble < 1.0E-5D && paramDouble > -1.0E-5D);
/*     */   }
/*     */   
/*     */   static boolean almostOne(double paramDouble) {
/* 929 */     return (paramDouble < 1.00001D && paramDouble > 0.99999D);
/*     */   }
/*     */   
/*     */   public GeneralTransform3D copy() {
/* 933 */     GeneralTransform3D generalTransform3D = new GeneralTransform3D();
/* 934 */     generalTransform3D.set(this);
/* 935 */     return generalTransform3D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 944 */     return "" + this.mat[0] + ", " + this.mat[0] + ", " + this.mat[1] + ", " + this.mat[2] + "\n" + this.mat[3] + ", " + this.mat[4] + ", " + this.mat[5] + ", " + this.mat[6] + "\n" + this.mat[7] + ", " + this.mat[8] + ", " + this.mat[9] + ", " + this.mat[10] + "\n" + this.mat[11] + ", " + this.mat[12] + ", " + this.mat[13] + ", " + this.mat[14] + "\n";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\GeneralTransform3D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */