/*      */ package com.sun.glass.ui.mac;
/*      */ 
/*      */ import com.sun.glass.ui.Accessible;
/*      */ import com.sun.glass.ui.Screen;
/*      */ import com.sun.glass.ui.View;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.function.Function;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.geometry.BoundingBox;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.input.KeyCharacterCombination;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyCodeCombination;
/*      */ import javafx.scene.input.KeyCombination;
/*      */ import javafx.scene.text.Font;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class MacAccessible
/*      */   extends Accessible
/*      */ {
/*      */   static {
/*   62 */     _initIDs();
/*   63 */     if (!_initEnum("MacAttribute")) {
/*   64 */       System.err.println("Fail linking MacAttribute");
/*      */     }
/*   66 */     if (!_initEnum("MacAction")) {
/*   67 */       System.err.println("Fail linking MacAction");
/*      */     }
/*   69 */     if (!_initEnum("MacRole")) {
/*   70 */       System.err.println("Fail linking MacRole");
/*      */     }
/*   72 */     if (!_initEnum("MacSubrole")) {
/*   73 */       System.err.println("Fail linking MacSubrole");
/*      */     }
/*   75 */     if (!_initEnum("MacNotification")) {
/*   76 */       System.err.println("Fail linking MacNotification");
/*      */     }
/*   78 */     if (!_initEnum("MacOrientation")) {
/*   79 */       System.err.println("Fail linking MacOrientation");
/*      */     }
/*   81 */     if (!_initEnum("MacText")) {
/*   82 */       System.err.println("Fail linking MacText");
/*      */     }
/*      */   }
/*      */   
/*      */   private enum MacAttribute
/*      */   {
/*   88 */     NSAccessibilityValueAttribute(null, null),
/*      */ 
/*      */     
/*   91 */     NSAccessibilityChildrenAttribute((String)AccessibleAttribute.CHILDREN, MacVariant::createNSArray),
/*   92 */     NSAccessibilityEnabledAttribute((String)AccessibleAttribute.DISABLED, MacVariant::createNSNumberForBoolean),
/*   93 */     NSAccessibilityHelpAttribute((String)AccessibleAttribute.HELP, MacVariant::createNSString),
/*      */ 
/*      */     
/*   96 */     NSAccessibilityFocusedAttribute((String)AccessibleAttribute.FOCUSED, MacVariant::createNSNumberForBoolean),
/*   97 */     NSAccessibilityExpandedAttribute((String)AccessibleAttribute.EXPANDED, MacVariant::createNSNumberForBoolean),
/*   98 */     NSAccessibilityMaxValueAttribute((String)AccessibleAttribute.MAX_VALUE, MacVariant::createNSNumberForDouble),
/*   99 */     NSAccessibilityMinValueAttribute((String)AccessibleAttribute.MIN_VALUE, MacVariant::createNSNumberForDouble),
/*  100 */     NSAccessibilityParentAttribute((String)AccessibleAttribute.PARENT, MacVariant::createNSObject),
/*  101 */     NSAccessibilityPositionAttribute((String)AccessibleAttribute.BOUNDS, MacVariant::createNSValueForPoint),
/*  102 */     NSAccessibilityRoleAttribute((String)AccessibleAttribute.ROLE, MacVariant::createNSObject),
/*  103 */     NSAccessibilitySubroleAttribute((String)AccessibleAttribute.ROLE, MacVariant::createNSObject),
/*  104 */     NSAccessibilityRoleDescriptionAttribute((String)AccessibleAttribute.ROLE_DESCRIPTION, MacVariant::createNSString),
/*  105 */     NSAccessibilitySizeAttribute((String)AccessibleAttribute.BOUNDS, MacVariant::createNSValueForSize),
/*  106 */     NSAccessibilityTabsAttribute((String)AccessibleAttribute.ITEM_COUNT, MacVariant::createNSArray),
/*  107 */     NSAccessibilityTitleAttribute((String)AccessibleAttribute.TEXT, MacVariant::createNSString),
/*  108 */     NSAccessibilityTopLevelUIElementAttribute((String)AccessibleAttribute.SCENE, MacVariant::createNSObject),
/*  109 */     NSAccessibilityWindowAttribute((String)AccessibleAttribute.SCENE, MacVariant::createNSObject),
/*  110 */     NSAccessibilityTitleUIElementAttribute((String)AccessibleAttribute.LABELED_BY, MacVariant::createNSObject),
/*  111 */     NSAccessibilityOrientationAttribute((String)AccessibleAttribute.ORIENTATION, MacVariant::createNSObject),
/*  112 */     NSAccessibilityOverflowButtonAttribute((String)AccessibleAttribute.OVERFLOW_BUTTON, MacVariant::createNSObject),
/*      */ 
/*      */     
/*  115 */     AXVisited((String)AccessibleAttribute.VISITED, MacVariant::createNSNumberForBoolean),
/*  116 */     AXMenuItemCmdChar((String)AccessibleAttribute.ACCELERATOR, MacVariant::createNSString),
/*  117 */     AXMenuItemCmdVirtualKey((String)AccessibleAttribute.ACCELERATOR, MacVariant::createNSNumberForInt),
/*  118 */     AXMenuItemCmdGlyph((String)AccessibleAttribute.ACCELERATOR, MacVariant::createNSNumberForInt),
/*  119 */     AXMenuItemCmdModifiers((String)AccessibleAttribute.ACCELERATOR, MacVariant::createNSNumberForInt),
/*  120 */     AXMenuItemMarkChar((String)AccessibleAttribute.SELECTED, MacVariant::createNSString),
/*  121 */     AXDateTimeComponents(null, MacVariant::createNSNumberForInt),
/*      */ 
/*      */     
/*  124 */     NSAccessibilitySelectedChildrenAttribute(null, MacVariant::createNSArray),
/*      */ 
/*      */     
/*  127 */     NSAccessibilityNumberOfCharactersAttribute((String)AccessibleAttribute.TEXT, MacVariant::createNSNumberForInt),
/*  128 */     NSAccessibilitySelectedTextAttribute((String)AccessibleAttribute.SELECTION_START, MacVariant::createNSString),
/*  129 */     NSAccessibilitySelectedTextRangeAttribute((String)AccessibleAttribute.SELECTION_START, MacVariant::createNSValueForRange),
/*  130 */     NSAccessibilitySelectedTextRangesAttribute(null, null),
/*  131 */     NSAccessibilityInsertionPointLineNumberAttribute((String)AccessibleAttribute.CARET_OFFSET, MacVariant::createNSNumberForInt),
/*  132 */     NSAccessibilityVisibleCharacterRangeAttribute((String)AccessibleAttribute.TEXT, MacVariant::createNSValueForRange),
/*      */ 
/*      */     
/*  135 */     NSAccessibilityContentsAttribute((String)AccessibleAttribute.CONTENTS, MacVariant::createNSArray),
/*  136 */     NSAccessibilityHorizontalScrollBarAttribute((String)AccessibleAttribute.HORIZONTAL_SCROLLBAR, MacVariant::createNSObject),
/*  137 */     NSAccessibilityVerticalScrollBarAttribute((String)AccessibleAttribute.VERTICAL_SCROLLBAR, MacVariant::createNSObject),
/*      */ 
/*      */     
/*  140 */     NSAccessibilityIndexAttribute((String)AccessibleAttribute.INDEX, MacVariant::createNSNumberForInt),
/*  141 */     NSAccessibilitySelectedAttribute((String)AccessibleAttribute.SELECTED, MacVariant::createNSNumberForBoolean),
/*  142 */     NSAccessibilityVisibleChildrenAttribute((String)AccessibleAttribute.CHILDREN, MacVariant::createNSArray),
/*      */ 
/*      */     
/*  145 */     NSAccessibilityDisclosedByRowAttribute((String)AccessibleAttribute.TREE_ITEM_PARENT, MacVariant::createNSObject),
/*  146 */     NSAccessibilityDisclosedRowsAttribute(null, null),
/*  147 */     NSAccessibilityDisclosingAttribute((String)AccessibleAttribute.EXPANDED, MacVariant::createNSNumberForBoolean),
/*  148 */     NSAccessibilityDisclosureLevelAttribute((String)AccessibleAttribute.DISCLOSURE_LEVEL, MacVariant::createNSNumberForInt),
/*      */ 
/*      */     
/*  151 */     NSAccessibilityColumnsAttribute(null, null),
/*  152 */     NSAccessibilityRowsAttribute(null, null),
/*  153 */     NSAccessibilityHeaderAttribute((String)AccessibleAttribute.HEADER, MacVariant::createNSObject),
/*  154 */     NSAccessibilitySelectedRowsAttribute((String)AccessibleAttribute.SELECTED_ITEMS, MacVariant::createNSArray),
/*  155 */     NSAccessibilityRowCountAttribute((String)AccessibleAttribute.ROW_COUNT, MacVariant::createNSNumberForInt),
/*  156 */     NSAccessibilityColumnCountAttribute((String)AccessibleAttribute.COLUMN_COUNT, MacVariant::createNSNumberForInt),
/*  157 */     NSAccessibilitySelectedCellsAttribute((String)AccessibleAttribute.SELECTED_ITEMS, MacVariant::createNSArray),
/*  158 */     NSAccessibilityRowIndexRangeAttribute((String)AccessibleAttribute.ROW_INDEX, MacVariant::createNSValueForRange),
/*  159 */     NSAccessibilityColumnIndexRangeAttribute((String)AccessibleAttribute.COLUMN_INDEX, MacVariant::createNSValueForRange),
/*      */ 
/*      */     
/*  162 */     NSAccessibilityLineForIndexParameterizedAttribute((String)AccessibleAttribute.LINE_FOR_OFFSET, MacVariant::createNSNumberForInt, 10),
/*  163 */     NSAccessibilityStringForRangeParameterizedAttribute((String)AccessibleAttribute.TEXT, MacVariant::createNSString, 18),
/*  164 */     NSAccessibilityRangeForLineParameterizedAttribute((String)AccessibleAttribute.LINE_START, MacVariant::createNSValueForRange, 10),
/*  165 */     NSAccessibilityAttributedStringForRangeParameterizedAttribute((String)AccessibleAttribute.TEXT, MacVariant::createNSAttributedString, 18),
/*  166 */     NSAccessibilityCellForColumnAndRowParameterizedAttribute((String)AccessibleAttribute.CELL_AT_ROW_COLUMN, MacVariant::createNSObject, 3),
/*  167 */     NSAccessibilityRangeForPositionParameterizedAttribute((String)AccessibleAttribute.OFFSET_AT_POINT, MacVariant::createNSValueForRange, 15),
/*  168 */     NSAccessibilityBoundsForRangeParameterizedAttribute((String)AccessibleAttribute.BOUNDS_FOR_RANGE, MacVariant::createNSValueForRectangle, 18);
/*      */     
/*      */     long ptr;
/*      */     AccessibleAttribute jfxAttr;
/*      */     Function<Object, MacVariant> map;
/*      */     int inputType;
/*      */     
/*      */     MacAttribute(AccessibleAttribute param1AccessibleAttribute, Function<Object, MacVariant> param1Function, int param1Int1) {
/*  176 */       this.jfxAttr = param1AccessibleAttribute;
/*  177 */       this.map = param1Function;
/*  178 */       this.inputType = param1Int1;
/*      */     }
/*      */     
/*      */     MacAttribute(AccessibleAttribute param1AccessibleAttribute, Function<Object, MacVariant> param1Function) {
/*  182 */       this.jfxAttr = param1AccessibleAttribute;
/*  183 */       this.map = param1Function;
/*      */     }
/*      */     
/*      */     static MacAttribute getAttribute(long param1Long) {
/*  187 */       if (param1Long == 0L) return null; 
/*  188 */       for (MacAttribute macAttribute : values()) {
/*  189 */         if (param1Long == macAttribute.ptr || MacAccessible.isEqualToString(macAttribute.ptr, param1Long)) {
/*  190 */           return macAttribute;
/*      */         }
/*      */       } 
/*  193 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum MacRole
/*      */   {
/*  202 */     NSAccessibilityUnknownRole((String)AccessibleRole.NODE, null, null),
/*  203 */     NSAccessibilityGroupRole((String)AccessibleRole.PARENT, null, null),
/*  204 */     NSAccessibilityButtonRole((String)new AccessibleRole[] { AccessibleRole.BUTTON, AccessibleRole.INCREMENT_BUTTON, AccessibleRole.DECREMENT_BUTTON, AccessibleRole.SPLIT_MENU_BUTTON }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute }, (AccessibleRole[])new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  212 */     NSAccessibilityIncrementorRole((String)AccessibleRole.SPINNER, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityIncrementAction, MacAccessible.MacAction.NSAccessibilityDecrementAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  223 */     AXJFXTOOLTIP((String)AccessibleRole.TOOLTIP, null, null),
/*  224 */     NSAccessibilityImageRole((String)AccessibleRole.IMAGE_VIEW, null, null),
/*  225 */     NSAccessibilityRadioButtonRole((String)new AccessibleRole[] { AccessibleRole.RADIO_BUTTON, AccessibleRole.TAB_ITEM, AccessibleRole.PAGE_ITEM }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, (AccessibleRole[])new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  234 */     NSAccessibilityCheckBoxRole((String)new AccessibleRole[] { AccessibleRole.CHECK_BOX, AccessibleRole.TOGGLE_BUTTON }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, (AccessibleRole[])new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  244 */     NSAccessibilityComboBoxRole((String)AccessibleRole.COMBO_BOX, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityExpandedAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  250 */     NSAccessibilityPopUpButtonRole((String)AccessibleRole.COMBO_BOX, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  257 */     NSAccessibilityTabGroupRole((String)new AccessibleRole[] { AccessibleRole.TAB_PANE, AccessibleRole.PAGINATION }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityTabsAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, null, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  266 */     NSAccessibilityProgressIndicatorRole((String)AccessibleRole.PROGRESS_INDICATOR, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityOrientationAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMaxValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMinValueAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  275 */     NSAccessibilityMenuBarRole((String)AccessibleRole.MENU_BAR, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilitySelectedChildrenAttribute, MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityCancelAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  284 */     NSAccessibilityMenuRole((String)AccessibleRole.CONTEXT_MENU, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilitySelectedChildrenAttribute, MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction, MacAccessible.MacAction.NSAccessibilityCancelAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  294 */     NSAccessibilityMenuItemRole((String)new AccessibleRole[] { AccessibleRole.MENU_ITEM, AccessibleRole.RADIO_MENU_ITEM, AccessibleRole.CHECK_MENU_ITEM, AccessibleRole.MENU }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedAttribute, MacAccessible.MacAttribute.AXMenuItemCmdChar, MacAccessible.MacAttribute.AXMenuItemCmdVirtualKey, MacAccessible.MacAttribute.AXMenuItemCmdGlyph, MacAccessible.MacAttribute.AXMenuItemCmdModifiers, MacAccessible.MacAttribute.AXMenuItemMarkChar }, (AccessibleRole[])new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction, MacAccessible.MacAction.NSAccessibilityCancelAction }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  311 */     NSAccessibilityMenuButtonRole((String)AccessibleRole.MENU_BUTTON, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityTitleAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  320 */     NSAccessibilityStaticTextRole((String)new AccessibleRole[] { AccessibleRole.TEXT }, null, null, null),
/*      */ 
/*      */     
/*  323 */     NSAccessibilityTextFieldRole((String)new AccessibleRole[] { AccessibleRole.TEXT_FIELD, AccessibleRole.PASSWORD_FIELD }, null, null, null),
/*      */ 
/*      */     
/*  326 */     NSAccessibilityTextAreaRole((String)AccessibleRole.TEXT_AREA, null, null),
/*  327 */     NSAccessibilitySliderRole((String)AccessibleRole.SLIDER, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityOrientationAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMaxValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMinValueAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityDecrementAction, MacAccessible.MacAction.NSAccessibilityIncrementAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  340 */     NSAccessibilityScrollAreaRole((String)AccessibleRole.SCROLL_PANE, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityContentsAttribute, MacAccessible.MacAttribute.NSAccessibilityHorizontalScrollBarAttribute, MacAccessible.MacAttribute.NSAccessibilityVerticalScrollBarAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  348 */     NSAccessibilityScrollBarRole((String)AccessibleRole.SCROLL_BAR, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMinValueAttribute, MacAccessible.MacAttribute.NSAccessibilityMaxValueAttribute, MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityOrientationAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  358 */     NSAccessibilityValueIndicatorRole((String)AccessibleRole.THUMB, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  364 */     NSAccessibilityRowRole((String)new AccessibleRole[] { AccessibleRole.LIST_ITEM, AccessibleRole.TABLE_ROW, AccessibleRole.TREE_ITEM, AccessibleRole.TREE_TABLE_ROW }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilitySubroleAttribute, MacAccessible.MacAttribute.NSAccessibilityIndexAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedAttribute, MacAccessible.MacAttribute.NSAccessibilityVisibleChildrenAttribute }, null, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  373 */     NSAccessibilityTableRole((String)new AccessibleRole[] { AccessibleRole.LIST_VIEW, AccessibleRole.TABLE_VIEW }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityColumnsAttribute, MacAccessible.MacAttribute.NSAccessibilityHeaderAttribute, MacAccessible.MacAttribute.NSAccessibilityRowsAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedRowsAttribute, MacAccessible.MacAttribute.NSAccessibilityRowCountAttribute, MacAccessible.MacAttribute.NSAccessibilityColumnCountAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedCellsAttribute }, null, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityCellForColumnAndRowParameterizedAttribute
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  389 */     NSAccessibilityColumnRole((String)AccessibleRole.TABLE_COLUMN, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityHeaderAttribute, MacAccessible.MacAttribute.NSAccessibilityIndexAttribute, MacAccessible.MacAttribute.NSAccessibilityRowsAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  398 */     NSAccessibilityCellRole((String)new AccessibleRole[] { AccessibleRole.TABLE_CELL, AccessibleRole.TREE_TABLE_CELL }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityColumnIndexRangeAttribute, MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityRowIndexRangeAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedAttribute }, null, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  408 */     NSAccessibilityLinkRole((String)AccessibleRole.HYPERLINK, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.AXVisited }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  415 */     NSAccessibilityOutlineRole((String)new AccessibleRole[] { AccessibleRole.TREE_VIEW, AccessibleRole.TREE_TABLE_VIEW }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityColumnsAttribute, MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityHeaderAttribute, MacAccessible.MacAttribute.NSAccessibilityRowsAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedRowsAttribute, MacAccessible.MacAttribute.NSAccessibilitySelectedCellsAttribute }, null, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityCellForColumnAndRowParameterizedAttribute
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  429 */     NSAccessibilityDisclosureTriangleRole((String)AccessibleRole.TITLED_PANE, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute }, (AccessibleRole)new MacAccessible.MacAction[] { MacAccessible.MacAction.NSAccessibilityPressAction
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  438 */     NSAccessibilityToolbarRole((String)AccessibleRole.TOOL_BAR, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityOverflowButtonAttribute }, null),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  445 */     AXDateTimeArea((String)AccessibleRole.DATE_PICKER, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityEnabledAttribute, MacAccessible.MacAttribute.NSAccessibilityValueAttribute, MacAccessible.MacAttribute.AXDateTimeComponents }, null);
/*      */ 
/*      */     
/*      */     long ptr;
/*      */ 
/*      */     
/*      */     AccessibleRole[] jfxRoles;
/*      */ 
/*      */     
/*      */     List<MacAccessible.MacAttribute> macAttributes;
/*      */ 
/*      */     
/*      */     List<MacAccessible.MacAttribute> macParameterizedAttributes;
/*      */ 
/*      */     
/*      */     List<MacAccessible.MacAction> macActions;
/*      */ 
/*      */     
/*      */     MacRole(AccessibleRole[] param1ArrayOfAccessibleRole, MacAccessible.MacAttribute[] param1ArrayOfMacAttribute1, MacAccessible.MacAction[] param1ArrayOfMacAction, MacAccessible.MacAttribute[] param1ArrayOfMacAttribute2) {
/*  464 */       this.jfxRoles = param1ArrayOfAccessibleRole;
/*  465 */       this.macAttributes = (param1ArrayOfMacAttribute1 != null) ? Arrays.<MacAccessible.MacAttribute>asList(param1ArrayOfMacAttribute1) : null;
/*  466 */       this.macActions = (param1ArrayOfMacAction != null) ? Arrays.<MacAccessible.MacAction>asList(param1ArrayOfMacAction) : null;
/*  467 */       this.macParameterizedAttributes = (param1ArrayOfMacAttribute2 != null) ? Arrays.<MacAccessible.MacAttribute>asList(param1ArrayOfMacAttribute2) : null;
/*      */     }
/*      */     
/*      */     static MacRole getRole(AccessibleRole param1AccessibleRole) {
/*  471 */       if (param1AccessibleRole == null) return null; 
/*  472 */       for (MacRole macRole : values()) {
/*  473 */         for (AccessibleRole accessibleRole : macRole.jfxRoles) {
/*  474 */           if (accessibleRole == param1AccessibleRole) {
/*  475 */             return macRole;
/*      */           }
/*      */         } 
/*      */       } 
/*  479 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private enum MacSubrole {
/*  484 */     NSAccessibilityTableRowSubrole((String)new AccessibleRole[] { AccessibleRole.LIST_ITEM, AccessibleRole.TABLE_ROW }),
/*  485 */     NSAccessibilitySecureTextFieldSubrole((String)new AccessibleRole[] { AccessibleRole.PASSWORD_FIELD }),
/*  486 */     NSAccessibilityOutlineRowSubrole((String)new AccessibleRole[] { AccessibleRole.TREE_ITEM, AccessibleRole.TREE_TABLE_ROW }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilityDisclosedByRowAttribute, MacAccessible.MacAttribute.NSAccessibilityDisclosedRowsAttribute, MacAccessible.MacAttribute.NSAccessibilityDisclosingAttribute, MacAccessible.MacAttribute.NSAccessibilityDisclosureLevelAttribute
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  494 */     NSAccessibilityDecrementArrowSubrole((String)new AccessibleRole[] { AccessibleRole.DECREMENT_BUTTON }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilitySubroleAttribute
/*      */ 
/*      */ 
/*      */       
/*      */       }),
/*  499 */     NSAccessibilityIncrementArrowSubrole((String)new AccessibleRole[] { AccessibleRole.INCREMENT_BUTTON }, new MacAccessible.MacAttribute[] { MacAccessible.MacAttribute.NSAccessibilitySubroleAttribute });
/*      */ 
/*      */ 
/*      */     
/*      */     long ptr;
/*      */ 
/*      */     
/*      */     AccessibleRole[] jfxRoles;
/*      */ 
/*      */     
/*      */     List<MacAccessible.MacAttribute> macAttributes;
/*      */ 
/*      */ 
/*      */     
/*      */     MacSubrole(AccessibleRole[] param1ArrayOfAccessibleRole, MacAccessible.MacAttribute[] param1ArrayOfMacAttribute) {
/*  514 */       this.jfxRoles = param1ArrayOfAccessibleRole;
/*  515 */       this.macAttributes = (param1ArrayOfMacAttribute != null) ? Arrays.<MacAccessible.MacAttribute>asList(param1ArrayOfMacAttribute) : null;
/*      */     }
/*      */     
/*      */     static MacSubrole getRole(AccessibleRole param1AccessibleRole) {
/*  519 */       if (param1AccessibleRole == null) return null; 
/*  520 */       for (MacSubrole macSubrole : values()) {
/*  521 */         for (AccessibleRole accessibleRole : macSubrole.jfxRoles) {
/*  522 */           if (accessibleRole == param1AccessibleRole) {
/*  523 */             return macSubrole;
/*      */           }
/*      */         } 
/*      */       } 
/*  527 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private enum MacAction {
/*  532 */     NSAccessibilityCancelAction,
/*  533 */     NSAccessibilityConfirmAction,
/*  534 */     NSAccessibilityDecrementAction((String)AccessibleAction.DECREMENT),
/*  535 */     NSAccessibilityDeleteAction,
/*  536 */     NSAccessibilityIncrementAction((String)AccessibleAction.INCREMENT),
/*  537 */     NSAccessibilityPickAction,
/*  538 */     NSAccessibilityPressAction((String)AccessibleAction.FIRE),
/*  539 */     NSAccessibilityRaiseAction,
/*  540 */     NSAccessibilityShowMenuAction((String)AccessibleAction.SHOW_MENU);
/*      */     
/*      */     long ptr;
/*      */     AccessibleAction jfxAction;
/*      */     
/*      */     MacAction(AccessibleAction param1AccessibleAction) {
/*  546 */       this.jfxAction = param1AccessibleAction;
/*      */     }
/*      */     
/*      */     static MacAction getAction(long param1Long) {
/*  550 */       for (MacAction macAction : values()) {
/*  551 */         if (macAction.ptr == param1Long || MacAccessible.isEqualToString(macAction.ptr, param1Long)) {
/*  552 */           return macAction;
/*      */         }
/*      */       } 
/*  555 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private enum MacNotification {
/*  560 */     NSAccessibilityCreatedNotification,
/*  561 */     NSAccessibilityFocusedUIElementChangedNotification,
/*  562 */     NSAccessibilityValueChangedNotification,
/*  563 */     NSAccessibilitySelectedChildrenChangedNotification,
/*  564 */     NSAccessibilitySelectedRowsChangedNotification,
/*  565 */     NSAccessibilityTitleChangedNotification,
/*  566 */     NSAccessibilityRowCountChangedNotification,
/*  567 */     NSAccessibilitySelectedCellsChangedNotification,
/*  568 */     NSAccessibilityUIElementDestroyedNotification,
/*  569 */     NSAccessibilitySelectedTextChangedNotification,
/*  570 */     NSAccessibilityRowExpandedNotification,
/*  571 */     NSAccessibilityRowCollapsedNotification,
/*  572 */     AXMenuOpened,
/*  573 */     AXMenuClosed;
/*      */     long ptr;
/*      */   }
/*      */   
/*      */   private enum MacOrientation {
/*  578 */     NSAccessibilityHorizontalOrientationValue,
/*  579 */     NSAccessibilityVerticalOrientationValue,
/*  580 */     NSAccessibilityUnknownOrientationValue;
/*      */     long ptr;
/*      */   }
/*      */   
/*      */   private enum MacText {
/*  585 */     NSAccessibilityBackgroundColorTextAttribute,
/*  586 */     NSAccessibilityForegroundColorTextAttribute,
/*  587 */     NSAccessibilityUnderlineTextAttribute,
/*  588 */     NSAccessibilityStrikethroughTextAttribute,
/*  589 */     NSAccessibilityMarkedMisspelledTextAttribute,
/*  590 */     NSAccessibilityFontTextAttribute,
/*  591 */     NSAccessibilityFontNameKey,
/*  592 */     NSAccessibilityFontFamilyKey,
/*  593 */     NSAccessibilityVisibleNameKey,
/*  594 */     NSAccessibilityFontSizeKey;
/*      */ 
/*      */ 
/*      */     
/*      */     long ptr;
/*      */   }
/*      */ 
/*      */   
/*  602 */   private static final List<MacAttribute> baseAttributes = Arrays.asList(new MacAttribute[] { MacAttribute.NSAccessibilityRoleAttribute, MacAttribute.NSAccessibilityRoleDescriptionAttribute, MacAttribute.NSAccessibilityHelpAttribute, MacAttribute.NSAccessibilityFocusedAttribute, MacAttribute.NSAccessibilityParentAttribute, MacAttribute.NSAccessibilityChildrenAttribute, MacAttribute.NSAccessibilityPositionAttribute, MacAttribute.NSAccessibilitySizeAttribute, MacAttribute.NSAccessibilityWindowAttribute, MacAttribute.NSAccessibilityTopLevelUIElementAttribute, MacAttribute.NSAccessibilityTitleUIElementAttribute });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  616 */   private static final List<MacAttribute> textAttributes = Arrays.asList(new MacAttribute[] { MacAttribute.NSAccessibilityEnabledAttribute, MacAttribute.NSAccessibilityValueAttribute, MacAttribute.NSAccessibilityNumberOfCharactersAttribute, MacAttribute.NSAccessibilitySelectedTextAttribute, MacAttribute.NSAccessibilitySelectedTextRangeAttribute, MacAttribute.NSAccessibilityInsertionPointLineNumberAttribute, MacAttribute.NSAccessibilityVisibleCharacterRangeAttribute });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  626 */   private static final List<MacAttribute> textParameterizedAttributes = Arrays.asList(new MacAttribute[] { MacAttribute.NSAccessibilityLineForIndexParameterizedAttribute, MacAttribute.NSAccessibilityRangeForLineParameterizedAttribute, MacAttribute.NSAccessibilityAttributedStringForRangeParameterizedAttribute, MacAttribute.NSAccessibilityStringForRangeParameterizedAttribute });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  658 */   private long peer = _createGlassAccessible(); private static final int kAXMenuItemModifierNone = 0; private static final int kAXMenuItemModifierShift = 1; private static final int kAXMenuItemModifierOption = 2; private static final int kAXMenuItemModifierControl = 4; private static final int kAXMenuItemModifierNoCommand = 8; private Boolean inMenu; private Boolean inSlider; private Boolean ignoreInnerText; MacAccessible() {
/*  659 */     if (this.peer == 0L) {
/*  660 */       throw new RuntimeException("could not create platform accessible");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  666 */     if (this.peer != 0L) {
/*  667 */       if (getView() == null) {
/*  668 */         NSAccessibilityPostNotification(this.peer, MacNotification.NSAccessibilityUIElementDestroyedNotification.ptr);
/*      */       }
/*  670 */       _destroyGlassAccessible(this.peer);
/*  671 */       this.peer = 0L;
/*      */     } 
/*  673 */     super.dispose(); } public void sendNotification(AccessibleAttribute paramAccessibleAttribute) { AccessibleRole accessibleRole1; Node node1; boolean bool;
/*      */     Node node2;
/*      */     View view;
/*      */     AccessibleRole accessibleRole2;
/*      */     long l;
/*  678 */     if (isDisposed())
/*      */       return; 
/*  680 */     MacNotification macNotification = null;
/*  681 */     switch (paramAccessibleAttribute) {
/*      */       case HORIZONTAL:
/*  683 */         accessibleRole1 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  684 */         if (accessibleRole1 == AccessibleRole.TABLE_VIEW || accessibleRole1 == AccessibleRole.TREE_TABLE_VIEW) {
/*      */           
/*  686 */           macNotification = MacNotification.NSAccessibilitySelectedCellsChangedNotification; break;
/*  687 */         }  if (accessibleRole1 == AccessibleRole.LIST_VIEW || accessibleRole1 == AccessibleRole.TREE_VIEW) {
/*      */           
/*  689 */           macNotification = MacNotification.NSAccessibilitySelectedRowsChangedNotification;
/*      */           break;
/*      */         } 
/*  692 */         node2 = (Node)getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  693 */         l = getNativeAccessible(node2);
/*  694 */         if (l != 0L) {
/*  695 */           NSAccessibilityPostNotification(l, MacNotification.NSAccessibilityFocusedUIElementChangedNotification.ptr);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case VERTICAL:
/*  701 */         node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*  702 */         view = getView();
/*  703 */         if (node1 == null && view == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  708 */           Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  709 */           if (scene != null) {
/*  710 */             Accessible accessible = getAccessible(scene);
/*  711 */             if (accessible != null) {
/*  712 */               node1 = (Node)accessible.getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  717 */         l = 0L;
/*  718 */         if (node1 != null) {
/*  719 */           Node node = (Node)getAccessible(node1).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  720 */           l = (node != null) ? getNativeAccessible(node) : getNativeAccessible(node1);
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  727 */           if (view == null) view = getRootView((Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0])); 
/*  728 */           if (view != null) l = view.getNativeView();
/*      */         
/*      */         } 
/*  731 */         if (l != 0L) {
/*  732 */           NSAccessibilityPostNotification(l, MacNotification.NSAccessibilityFocusedUIElementChangedNotification.ptr);
/*      */         }
/*      */         return;
/*      */       
/*      */       case null:
/*      */         return;
/*      */       case null:
/*      */       case null:
/*  740 */         macNotification = MacNotification.NSAccessibilitySelectedTextChangedNotification;
/*      */         break;
/*      */       case null:
/*  743 */         bool = Boolean.TRUE.equals(getAttribute(AccessibleAttribute.EXPANDED, new Object[0]));
/*  744 */         if (bool) {
/*  745 */           macNotification = MacNotification.NSAccessibilityRowExpandedNotification;
/*      */         } else {
/*  747 */           macNotification = MacNotification.NSAccessibilityRowCollapsedNotification;
/*      */         } 
/*      */         
/*  750 */         accessibleRole2 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  751 */         if (accessibleRole2 == AccessibleRole.TREE_ITEM || accessibleRole2 == AccessibleRole.TREE_TABLE_ROW) {
/*  752 */           AccessibleRole accessibleRole = (accessibleRole2 == AccessibleRole.TREE_ITEM) ? AccessibleRole.TREE_VIEW : AccessibleRole.TREE_TABLE_VIEW;
/*  753 */           MacAccessible macAccessible = (MacAccessible)getContainerAccessible(accessibleRole);
/*  754 */           if (macAccessible != null) {
/*  755 */             NSAccessibilityPostNotification(macAccessible.getNativeAccessible(), MacNotification.NSAccessibilityRowCountChangedNotification.ptr);
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case null:
/*  760 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.CONTEXT_MENU) {
/*  761 */           Boolean bool1 = (Boolean)getAttribute(AccessibleAttribute.VISIBLE, new Object[0]);
/*  762 */           if (Boolean.TRUE.equals(bool1)) {
/*  763 */             macNotification = MacNotification.AXMenuOpened; break;
/*      */           } 
/*  765 */           macNotification = MacNotification.AXMenuClosed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  773 */           Node node = (Node)getAttribute(AccessibleAttribute.PARENT_MENU, new Object[0]);
/*  774 */           MacAccessible macAccessible = (MacAccessible)getAccessible(node);
/*  775 */           if (macAccessible != null) {
/*  776 */             MacAccessible macAccessible1 = (MacAccessible)macAccessible.getContainerAccessible(AccessibleRole.CONTEXT_MENU);
/*  777 */             if (macAccessible1 != null) {
/*  778 */               long l1 = macAccessible1.getNativeAccessible();
/*  779 */               NSAccessibilityPostNotification(l1, MacNotification.AXMenuClosed.ptr);
/*  780 */               NSAccessibilityPostNotification(l1, MacNotification.AXMenuOpened.ptr);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/*  788 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.SPINNER) {
/*  789 */           macNotification = MacNotification.NSAccessibilityTitleChangedNotification; break;
/*      */         } 
/*  791 */         macNotification = MacNotification.NSAccessibilityValueChangedNotification;
/*      */         break;
/*      */       
/*      */       case null:
/*  795 */         this.ignoreInnerText = null;
/*      */         break;
/*      */       default:
/*  798 */         macNotification = MacNotification.NSAccessibilityValueChangedNotification; break;
/*      */     } 
/*  800 */     if (macNotification != null) {
/*  801 */       View view1 = getView();
/*  802 */       long l1 = (view1 != null) ? view1.getNativeView() : this.peer;
/*  803 */       NSAccessibilityPostNotification(l1, macNotification.ptr);
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getNativeAccessible() {
/*  809 */     return this.peer;
/*      */   }
/*      */   
/*      */   private View getRootView(Scene paramScene) {
/*  813 */     if (paramScene == null) return null; 
/*  814 */     Accessible accessible = getAccessible(paramScene);
/*  815 */     if (accessible == null || accessible.isDisposed()) return null; 
/*  816 */     View view = accessible.getView();
/*  817 */     if (view == null || view.isClosed()) return null; 
/*  818 */     return view;
/*      */   }
/*      */   
/*      */   private long[] getUnignoredChildren(ObservableList<Node> paramObservableList) {
/*  822 */     if (paramObservableList == null) return new long[0];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  827 */     long[] arrayOfLong = paramObservableList.stream().filter(Node::isVisible).mapToLong(paramNode -> getNativeAccessible(paramNode)).filter(paramLong -> (paramLong != 0L)).toArray();
/*  828 */     return NSAccessibilityUnignoredChildren(arrayOfLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInMenu() {
/*  834 */     if (this.inMenu == null) {
/*  835 */       this.inMenu = Boolean.valueOf((getContainerAccessible(AccessibleRole.CONTEXT_MENU) != null || getContainerAccessible(AccessibleRole.MENU_BAR) != null));
/*      */     }
/*  837 */     return this.inMenu.booleanValue();
/*      */   }
/*      */   
/*      */   private boolean isMenuElement(AccessibleRole paramAccessibleRole) {
/*  841 */     if (paramAccessibleRole == null) return false; 
/*  842 */     switch (paramAccessibleRole) { case HORIZONTAL:
/*      */       case VERTICAL:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  848 */         return true; }
/*  849 */      return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInSlider() {
/*  856 */     if (this.inSlider == null) {
/*  857 */       this.inSlider = Boolean.valueOf((getContainerAccessible(AccessibleRole.SLIDER) != null));
/*      */     }
/*  859 */     return this.inSlider.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean ignoreInnerText() {
/*  864 */     if (this.ignoreInnerText != null) return this.ignoreInnerText.booleanValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  873 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  874 */     this.ignoreInnerText = Boolean.valueOf(false);
/*  875 */     if (accessibleRole == AccessibleRole.TEXT) {
/*  876 */       Node node = (Node)getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/*  877 */       if (node == null) return this.ignoreInnerText.booleanValue(); 
/*  878 */       AccessibleRole accessibleRole1 = (AccessibleRole)getAccessible(node).getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  879 */       if (accessibleRole1 == null) return this.ignoreInnerText.booleanValue(); 
/*  880 */       switch (accessibleRole1) {
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*  889 */           this.ignoreInnerText = Boolean.valueOf(true);
/*      */           break;
/*      */       } 
/*      */     } 
/*  893 */     return this.ignoreInnerText.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   private int getMenuItemCmdGlyph(KeyCode paramKeyCode) {
/*  898 */     switch (paramKeyCode) { case HORIZONTAL:
/*  899 */         return 4;
/*  900 */       case VERTICAL: return 5;
/*  901 */       case null: return 6;
/*  902 */       case null: return 7;
/*  903 */       case null: return 9;
/*  904 */       case null: return 17;
/*  905 */       case null: return 27;
/*  906 */       case null: return 28;
/*  907 */       case null: return 98;
/*  908 */       case null: return 99;
/*      */       case null: case null:
/*  910 */         return 100;
/*      */       case null: case null:
/*  912 */         return 101;
/*  913 */       case null: return 103;
/*      */       case null: case null:
/*  915 */         return 104;
/*      */       case null: case null:
/*  917 */         return 106;
/*  918 */       case null: return 107;
/*  919 */       case null: return 109;
/*  920 */       case null: return 110;
/*  921 */       case null: return 111;
/*  922 */       case null: return 112;
/*  923 */       case null: return 113;
/*  924 */       case null: return 114;
/*  925 */       case null: return 115;
/*  926 */       case null: return 116;
/*  927 */       case null: return 117;
/*  928 */       case null: return 118;
/*  929 */       case null: return 119;
/*  930 */       case null: return 120;
/*  931 */       case null: return 121;
/*  932 */       case null: return 122;
/*  933 */       case null: return 135;
/*  934 */       case null: return 136;
/*  935 */       case null: return 137; }
/*  936 */      return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isCmdCharBased(KeyCode paramKeyCode) {
/*  941 */     return (paramKeyCode.isLetterKey() || (paramKeyCode.isDigitKey() && !paramKeyCode.isKeypadKey()));
/*      */   }
/*      */   
/*      */   private MacRole getRole(AccessibleRole paramAccessibleRole) {
/*  945 */     if (paramAccessibleRole == AccessibleRole.COMBO_BOX) {
/*  946 */       if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.EDITABLE, new Object[0]))) {
/*  947 */         return MacRole.NSAccessibilityComboBoxRole;
/*      */       }
/*  949 */       return MacRole.NSAccessibilityPopUpButtonRole;
/*      */     } 
/*      */     
/*  952 */     return MacRole.getRole(paramAccessibleRole);
/*      */   }
/*      */   
/*      */   private Bounds flipBounds(Bounds paramBounds) {
/*  956 */     View view = getRootView((Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]));
/*  957 */     if (view == null || view.getWindow() == null) return null; 
/*  958 */     Screen screen = view.getWindow().getScreen();
/*  959 */     float f = screen.getHeight();
/*  960 */     return new BoundingBox(paramBounds.getMinX(), f - paramBounds
/*  961 */         .getMinY() - paramBounds.getHeight(), paramBounds
/*  962 */         .getWidth(), paramBounds
/*  963 */         .getHeight());
/*      */   }
/*      */ 
/*      */   
/*      */   private long[] accessibilityAttributeNames() {
/*  968 */     if (getView() != null) return null; 
/*  969 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  970 */     if (accessibleRole != null) {
/*  971 */       ArrayList<MacAttribute> arrayList = new ArrayList<>(baseAttributes);
/*  972 */       MacRole macRole = getRole(accessibleRole);
/*  973 */       if (macRole != null && macRole.macAttributes != null) {
/*  974 */         arrayList.addAll(macRole.macAttributes);
/*      */       }
/*      */ 
/*      */       
/*  978 */       MacSubrole macSubrole = MacSubrole.getRole(accessibleRole);
/*  979 */       if (macSubrole != null && macSubrole.macAttributes != null) {
/*  980 */         arrayList.addAll(macSubrole.macAttributes);
/*      */       }
/*      */       
/*  983 */       switch (accessibleRole) {
/*      */         
/*      */         case null:
/*      */         case null:
/*  987 */           arrayList.remove(MacAttribute.NSAccessibilitySelectedCellsAttribute);
/*      */           break;
/*      */         
/*      */         case HORIZONTAL:
/*      */         case VERTICAL:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*  996 */           arrayList.remove(MacAttribute.NSAccessibilityWindowAttribute);
/*  997 */           arrayList.remove(MacAttribute.NSAccessibilityTopLevelUIElementAttribute);
/*      */           break;
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1004 */           arrayList.addAll(textAttributes);
/*      */           break;
/*      */       } 
/*      */       
/* 1008 */       return arrayList.stream().mapToLong(paramMacAttribute -> paramMacAttribute.ptr).toArray();
/*      */     } 
/* 1010 */     return null;
/*      */   } private int accessibilityArrayAttributeCount(long paramLong) {
/*      */     AccessibleAttribute accessibleAttribute;
/*      */     Integer integer1, integer2;
/* 1014 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong);
/* 1015 */     if (macAttribute == null) {
/* 1016 */       return -1;
/*      */     }
/* 1018 */     switch (macAttribute) {
/*      */       
/*      */       case HORIZONTAL:
/* 1021 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.LIST_VIEW) {
/* 1022 */           accessibleAttribute = AccessibleAttribute.ITEM_COUNT;
/*      */         } else {
/* 1024 */           accessibleAttribute = AccessibleAttribute.ROW_COUNT;
/*      */         } 
/* 1026 */         integer2 = (Integer)getAttribute(accessibleAttribute, new Object[0]);
/* 1027 */         return (integer2 != null) ? integer2.intValue() : 0;
/*      */       
/*      */       case VERTICAL:
/* 1030 */         integer1 = (Integer)getAttribute(AccessibleAttribute.COLUMN_COUNT, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1036 */         return (integer1 != null) ? integer1.intValue() : 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1046 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.MENU) {
/*      */           
/* 1048 */           ObservableList<Node> observableList = (ObservableList)getAttribute(AccessibleAttribute.CHILDREN, new Object[0]);
/* 1049 */           if (observableList == null) return 0; 
/* 1050 */           long[] arrayOfLong = getUnignoredChildren(observableList);
/* 1051 */           int i = arrayOfLong.length;
/* 1052 */           if (getAttribute(AccessibleAttribute.SUBMENU, new Object[0]) != null) {
/* 1053 */             i++;
/*      */           }
/* 1055 */           return i;
/*      */         } 
/* 1057 */         return -1;
/*      */       
/*      */       case null:
/* 1060 */         integer1 = (Integer)getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/* 1061 */         return (integer1 != null) ? integer1.intValue() : 0;
/*      */     } 
/*      */ 
/*      */     
/* 1065 */     return -1;
/*      */   }
/*      */   
/*      */   private long[] accessibilityArrayAttributeValues(long paramLong, int paramInt1, int paramInt2) {
/* 1069 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong);
/* 1070 */     if (macAttribute == null) {
/* 1071 */       return null;
/*      */     }
/*      */     
/* 1074 */     AccessibleAttribute accessibleAttribute = null;
/* 1075 */     switch (macAttribute) { case VERTICAL:
/* 1076 */         accessibleAttribute = AccessibleAttribute.COLUMN_AT_INDEX; break;
/*      */       case HORIZONTAL:
/* 1078 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.LIST_VIEW) {
/* 1079 */           accessibleAttribute = AccessibleAttribute.ITEM_AT_INDEX; break;
/*      */         } 
/* 1081 */         accessibleAttribute = AccessibleAttribute.ROW_AT_INDEX;
/*      */         break;
/*      */       
/*      */       case null:
/* 1085 */         accessibleAttribute = AccessibleAttribute.TREE_ITEM_AT_INDEX; break;
/*      */       case null:
/* 1087 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.MENU) {
/* 1088 */           long[] arrayOfLong = new long[paramInt2];
/* 1089 */           byte b = 0;
/* 1090 */           if (paramInt1 == 0) {
/* 1091 */             Node node = (Node)getAttribute(AccessibleAttribute.SUBMENU, new Object[0]);
/* 1092 */             if (node != null) arrayOfLong[b++] = getNativeAccessible(node); 
/*      */           } 
/* 1094 */           if (b < paramInt2) {
/*      */             
/* 1096 */             ObservableList<Node> observableList = (ObservableList)getAttribute(AccessibleAttribute.CHILDREN, new Object[0]);
/* 1097 */             if (observableList == null) return null; 
/* 1098 */             long[] arrayOfLong1 = getUnignoredChildren(observableList);
/* 1099 */             paramInt1--;
/* 1100 */             while (b < paramInt2 && paramInt1 < arrayOfLong1.length) {
/* 1101 */               arrayOfLong[b++] = arrayOfLong1[paramInt1++];
/*      */             }
/*      */           } 
/* 1104 */           if (b < paramInt2) {
/* 1105 */             arrayOfLong = Arrays.copyOf(arrayOfLong, b);
/*      */           }
/* 1107 */           return arrayOfLong;
/*      */         } 
/*      */         break; }
/*      */ 
/*      */ 
/*      */     
/* 1113 */     if (accessibleAttribute != null) {
/* 1114 */       long[] arrayOfLong = new long[paramInt2];
/* 1115 */       byte b = 0;
/* 1116 */       while (b < paramInt2) {
/* 1117 */         Node node = (Node)getAttribute(accessibleAttribute, new Object[] { Integer.valueOf(paramInt1 + b) });
/* 1118 */         if (node == null)
/* 1119 */           break;  arrayOfLong[b] = getNativeAccessible(node);
/* 1120 */         b++;
/*      */       } 
/* 1122 */       if (b == paramInt2) return NSAccessibilityUnignoredChildren(arrayOfLong); 
/*      */     } 
/* 1124 */     return null;
/*      */   }
/*      */   private boolean accessibilityIsAttributeSettable(long paramLong) { Integer integer;
/*      */     AccessibleRole accessibleRole;
/* 1128 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong);
/* 1129 */     if (macAttribute == null) return false; 
/* 1130 */     switch (macAttribute) {
/*      */       case null:
/* 1132 */         integer = (Integer)getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/* 1133 */         return (integer != null && integer.intValue() > 0);
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/* 1138 */         return true;
/*      */       case null:
/*      */       case null:
/* 1141 */         accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1142 */         if ((accessibleRole == AccessibleRole.TEXT_FIELD || accessibleRole == AccessibleRole.TEXT_AREA) && 
/* 1143 */           Boolean.TRUE.equals(getAttribute(AccessibleAttribute.EDITABLE, new Object[0]))) {
/* 1144 */           return true;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     return false; } private MacVariant accessibilityAttributeValue(long paramLong) { Scene scene; MacSubrole macSubrole; MacRole macRole; Integer integer2; ObservableList<Node> observableList; KeyCombination keyCombination; String str2; int i; String str1; Integer integer1; Orientation orientation; View view;
/*      */     long[] arrayOfLong;
/*      */     int j, k;
/*      */     String str3;
/* 1155 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong);
/* 1156 */     if (macAttribute == null) {
/* 1157 */       return null;
/*      */     }
/*      */     
/* 1160 */     Function<Object, MacVariant> function = macAttribute.map;
/* 1161 */     AccessibleAttribute accessibleAttribute = macAttribute.jfxAttr;
/* 1162 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1163 */     if (accessibleRole == null) return null; 
/* 1164 */     if (accessibleAttribute == null) {
/* 1165 */       Node node; switch (macAttribute) {
/*      */         case null:
/* 1167 */           switch (accessibleRole) {
/*      */             case null:
/*      */             case null:
/* 1170 */               accessibleAttribute = AccessibleAttribute.FOCUS_ITEM;
/* 1171 */               function = MacVariant::createNSObject;
/*      */               break;
/*      */             case null:
/*      */             case null:
/*      */             case null:
/* 1176 */               accessibleAttribute = AccessibleAttribute.SELECTED;
/* 1177 */               function = MacVariant::createNSNumberForBoolean;
/*      */               break;
/*      */             case null:
/*      */             case null:
/*      */             case null:
/*      */             case null:
/* 1183 */               accessibleAttribute = AccessibleAttribute.VALUE;
/* 1184 */               function = MacVariant::createNSNumberForDouble;
/*      */               break;
/*      */             case null:
/*      */             case null:
/*      */             case null:
/*      */             case null:
/* 1190 */               accessibleAttribute = AccessibleAttribute.TEXT;
/* 1191 */               function = MacVariant::createNSString;
/*      */               break;
/*      */             case null:
/*      */             case null:
/* 1195 */               accessibleAttribute = AccessibleAttribute.SELECTED;
/* 1196 */               function = MacVariant::createNSNumberForInt;
/*      */               break;
/*      */             case null:
/* 1199 */               accessibleAttribute = AccessibleAttribute.DATE;
/* 1200 */               function = MacVariant::createNSDate;
/*      */               break;
/*      */             case null:
/* 1203 */               accessibleAttribute = AccessibleAttribute.EXPANDED;
/* 1204 */               function = MacVariant::createNSNumberForInt;
/*      */               break;
/*      */           } 
/*      */           
/* 1208 */           return null;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/* 1213 */           node = null;
/* 1214 */           if (accessibleRole == AccessibleRole.CONTEXT_MENU) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1220 */             Scene scene1 = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/* 1221 */             Accessible accessible = getAccessible(scene1);
/* 1222 */             if (accessible != null) {
/* 1223 */               node = (Node)accessible.getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*      */             }
/*      */           } 
/* 1226 */           if (accessibleRole == AccessibleRole.MENU_BAR)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 1231 */             node = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*      */           }
/* 1233 */           if (node != null) {
/* 1234 */             AccessibleRole accessibleRole1 = (AccessibleRole)getAccessible(node).getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1235 */             if (isMenuElement(accessibleRole1)) {
/* 1236 */               long[] arrayOfLong1 = { getNativeAccessible(node) };
/* 1237 */               return macAttribute.map.apply(arrayOfLong1);
/*      */             } 
/*      */           } 
/* 1240 */           return null;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/* 1246 */           if (getAttribute(AccessibleAttribute.DATE, new Object[0]) == null) return null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1254 */           return macAttribute.map.apply(Integer.valueOf(224));
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1259 */     if (accessibleAttribute == null) {
/* 1260 */       return null;
/*      */     }
/* 1262 */     Object object = getAttribute(accessibleAttribute, new Object[0]);
/* 1263 */     if (object == null) {
/* 1264 */       MacRole macRole1; MacSubrole macSubrole1; switch (macAttribute) {
/*      */         case null:
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/* 1271 */           object = Integer.valueOf(1);
/*      */           break;
/*      */         case null:
/* 1274 */           if (accessibleRole == AccessibleRole.TABLE_COLUMN) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1280 */             object = getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1281 */             if (object != null)
/*      */               break; 
/* 1283 */           }  return null;
/*      */         case null:
/* 1285 */           return macAttribute.map.apply(Integer.valueOf(8));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/* 1296 */           switch (accessibleRole) { case null:
/* 1297 */               object = "title pane"; break;
/* 1298 */             case null: object = "split button"; break;
/* 1299 */             case null: object = "page"; break;
/* 1300 */             case null: object = "tab"; break;
/* 1301 */             case null: object = "list"; break; }
/*      */           
/* 1303 */           macRole1 = getRole(accessibleRole);
/* 1304 */           macSubrole1 = MacSubrole.getRole(accessibleRole);
/* 1305 */           object = NSAccessibilityRoleDescription(macRole1.ptr, (macSubrole1 != null) ? macSubrole1.ptr : 0L);
/*      */           break;
/*      */         
/*      */         default:
/* 1309 */           return null;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/* 1314 */     switch (macAttribute) {
/*      */       case null:
/*      */       case null:
/* 1317 */         if (isMenuElement(accessibleRole)) {
/* 1318 */           return null;
/*      */         }
/* 1320 */         scene = (Scene)object;
/* 1321 */         view = getRootView(scene);
/* 1322 */         if (view == null || view.getWindow() == null) return null; 
/* 1323 */         object = Long.valueOf(view.getWindow().getNativeWindow());
/*      */         break;
/*      */       
/*      */       case null:
/* 1327 */         macSubrole = MacSubrole.getRole((AccessibleRole)object);
/* 1328 */         object = Long.valueOf((macSubrole != null) ? macSubrole.ptr : 0L);
/*      */         break;
/*      */       
/*      */       case null:
/* 1332 */         macRole = getRole(accessibleRole);
/* 1333 */         object = Long.valueOf((macRole != null) ? macRole.ptr : 0L);
/*      */         break;
/*      */       
/*      */       case null:
/* 1337 */         object = Boolean.valueOf(Boolean.FALSE.equals(object));
/*      */         break;
/*      */       
/*      */       case null:
/* 1341 */         integer2 = (Integer)object;
/* 1342 */         arrayOfLong = new long[integer2.intValue()];
/* 1343 */         for (k = 0; k < integer2.intValue(); k++) {
/* 1344 */           Node node = (Node)getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { Integer.valueOf(k) });
/* 1345 */           arrayOfLong[k] = getNativeAccessible(node);
/*      */         } 
/* 1347 */         object = NSAccessibilityUnignoredChildren(arrayOfLong);
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/* 1355 */         observableList = (ObservableList)object;
/* 1356 */         object = getUnignoredChildren(observableList);
/*      */         break;
/*      */       
/*      */       case null:
/* 1360 */         if (getView() != null) {
/* 1361 */           if (getView().getWindow() == null) return null; 
/* 1362 */           object = Long.valueOf(getView().getWindow().getNativeWindow());
/* 1363 */         } else if (object != null) {
/* 1364 */           if (accessibleRole == AccessibleRole.CONTEXT_MENU) {
/* 1365 */             Node node = (Node)getAttribute(AccessibleAttribute.PARENT_MENU, new Object[0]);
/* 1366 */             if (node != null && 
/* 1367 */               getAccessible(node).getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.MENU) {
/* 1368 */               object = node;
/*      */             }
/*      */           } 
/*      */           
/* 1372 */           object = Long.valueOf(getNativeAccessible((Node)object));
/*      */         } else {
/*      */           
/* 1375 */           View view1 = getRootView((Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]));
/* 1376 */           if (view1 == null) return null; 
/* 1377 */           object = Long.valueOf(view1.getNativeView());
/*      */         } 
/* 1379 */         object = Long.valueOf(NSAccessibilityUnignoredAncestor(((Long)object).longValue()));
/*      */         break;
/*      */       
/*      */       case null:
/* 1383 */         switch (accessibleRole) {
/*      */           case null:
/*      */           case null:
/* 1386 */             object = Long.valueOf(getNativeAccessible((Node)object));
/*      */             break;
/*      */           case null:
/*      */           case null:
/* 1390 */             if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) {
/* 1391 */               object = Integer.valueOf(2); break;
/*      */             } 
/* 1393 */             object = Integer.valueOf(Boolean.TRUE.equals(object) ? 1 : 0);
/*      */             break;
/*      */           
/*      */           case null:
/* 1397 */             object = Integer.valueOf(Boolean.TRUE.equals(object) ? 1 : 0);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1408 */         object = flipBounds((Bounds)object);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1416 */         if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) {
/* 1417 */           return null;
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1427 */         switch (accessibleRole) {
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/* 1432 */             return null;
/*      */         } 
/*      */         
/*      */         break;
/*      */       
/*      */       case null:
/* 1438 */         keyCombination = (KeyCombination)object;
/* 1439 */         object = null;
/* 1440 */         if (keyCombination instanceof KeyCharacterCombination) {
/* 1441 */           object = ((KeyCharacterCombination)keyCombination).getCharacter();
/*      */         }
/* 1443 */         if (keyCombination instanceof KeyCodeCombination) {
/* 1444 */           KeyCode keyCode = ((KeyCodeCombination)keyCombination).getCode();
/* 1445 */           if (isCmdCharBased(keyCode)) {
/* 1446 */             object = keyCode.getName();
/*      */           }
/*      */         } 
/* 1449 */         if (object == null) return null;
/*      */         
/*      */         break;
/*      */       case null:
/* 1453 */         keyCombination = (KeyCombination)object;
/* 1454 */         object = null;
/* 1455 */         if (keyCombination instanceof KeyCodeCombination) {
/* 1456 */           KeyCode keyCode = ((KeyCodeCombination)keyCombination).getCode();
/* 1457 */           if (!isCmdCharBased(keyCode)) {
/*      */             
/* 1459 */             k = keyCode.getCode();
/* 1460 */             object = Integer.valueOf(MacApplication._getMacKey(k));
/*      */           } 
/*      */         } 
/* 1463 */         if (object == null) return null;
/*      */         
/*      */         break;
/*      */       case null:
/* 1467 */         keyCombination = (KeyCombination)object;
/* 1468 */         object = null;
/* 1469 */         if (keyCombination instanceof KeyCodeCombination) {
/* 1470 */           KeyCode keyCode = ((KeyCodeCombination)keyCombination).getCode();
/* 1471 */           if (!isCmdCharBased(keyCode)) {
/* 1472 */             object = Integer.valueOf(getMenuItemCmdGlyph(keyCode));
/*      */           }
/*      */         } 
/* 1475 */         if (object == null) return null;
/*      */         
/*      */         break;
/*      */       case null:
/* 1479 */         keyCombination = (KeyCombination)object;
/* 1480 */         j = 8;
/* 1481 */         if (keyCombination != null) {
/* 1482 */           if (keyCombination.getShortcut() == KeyCombination.ModifierValue.DOWN) {
/* 1483 */             j = 0;
/*      */           }
/* 1485 */           if (keyCombination.getAlt() == KeyCombination.ModifierValue.DOWN) {
/* 1486 */             j |= 0x2;
/*      */           }
/* 1488 */           if (keyCombination.getControl() == KeyCombination.ModifierValue.DOWN) {
/* 1489 */             j |= 0x4;
/*      */           }
/* 1491 */           if (keyCombination.getShift() == KeyCombination.ModifierValue.DOWN) {
/* 1492 */             j |= 0x1;
/*      */           }
/*      */         } 
/* 1495 */         object = Integer.valueOf(j);
/*      */         break;
/*      */       
/*      */       case null:
/* 1499 */         if (Boolean.TRUE.equals(object)) {
/* 1500 */           object = "✓"; break;
/*      */         } 
/* 1502 */         return null;
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/* 1507 */         str2 = (String)object;
/* 1508 */         object = Integer.valueOf(str2.length());
/*      */         break;
/*      */       
/*      */       case null:
/* 1512 */         i = ((Integer)object).intValue(); j = -1;
/* 1513 */         if (i != -1) {
/* 1514 */           object = getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/* 1515 */           if (object == null) return null; 
/* 1516 */           j = ((Integer)object).intValue();
/*      */         } 
/* 1518 */         if (i < 0 || j < 0 || i > j) return null; 
/* 1519 */         str3 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1520 */         if (str3 == null) return null; 
/* 1521 */         if (j > str3.length()) return null; 
/* 1522 */         object = str3.substring(i, j);
/*      */         break;
/*      */       
/*      */       case null:
/* 1526 */         i = ((Integer)object).intValue(); j = -1;
/* 1527 */         if (i != -1) {
/* 1528 */           object = getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/* 1529 */           if (object == null) return null; 
/* 1530 */           j = ((Integer)object).intValue();
/*      */         } 
/* 1532 */         if (i < 0 || j < 0 || i > j) return null; 
/* 1533 */         str3 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1534 */         if (str3 == null) return null; 
/* 1535 */         if (j > str3.length()) return null; 
/* 1536 */         object = new int[] { i, j - i };
/*      */         break;
/*      */       
/*      */       case null:
/* 1540 */         if (accessibleRole == AccessibleRole.TEXT_AREA) {
/* 1541 */           Integer integer = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { object });
/* 1542 */           object = Integer.valueOf((integer != null) ? integer.intValue() : 0);
/*      */           break;
/*      */         } 
/* 1545 */         object = Integer.valueOf(0);
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/* 1550 */         str1 = (String)object;
/* 1551 */         object = new int[] { 0, str1.length() };
/*      */         break;
/*      */       
/*      */       case null:
/* 1555 */         if (object != null) {
/* 1556 */           object = new long[] { getNativeAccessible((Node)object) };
/*      */         }
/*      */         break;
/*      */       
/*      */       case null:
/*      */       case null:
/* 1562 */         integer1 = (Integer)object;
/* 1563 */         object = new int[] { integer1.intValue(), 1 };
/*      */         break;
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/* 1572 */         object = Long.valueOf(getNativeAccessible((Node)object));
/*      */         break;
/*      */       
/*      */       case null:
/* 1576 */         orientation = (Orientation)object;
/* 1577 */         switch (orientation) { case HORIZONTAL:
/* 1578 */             object = Long.valueOf(MacOrientation.NSAccessibilityHorizontalOrientationValue.ptr); break;
/* 1579 */           case VERTICAL: object = Long.valueOf(MacOrientation.NSAccessibilityVerticalOrientationValue.ptr); break; }
/* 1580 */          return null;
/*      */ 
/*      */       
/*      */       case null:
/* 1584 */         if (object == Boolean.TRUE && 
/* 1585 */           Boolean.TRUE.equals(getAttribute(AccessibleAttribute.LEAF, new Object[0]))) {
/* 1586 */           object = Boolean.FALSE;
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1593 */     return (object != null) ? function.apply(object) : null; }
/*      */ 
/*      */   
/*      */   private void accessibilitySetValue(long paramLong1, long paramLong2) {
/* 1597 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong2);
/* 1598 */     if (macAttribute != null) {
/* 1599 */       MacVariant macVariant; switch (macAttribute) {
/*      */         case null:
/* 1601 */           macVariant = idToMacVariant(paramLong1, 9);
/* 1602 */           if (macVariant != null && macVariant.int1 != 0) {
/* 1603 */             executeAction(AccessibleAction.REQUEST_FOCUS, new Object[0]);
/*      */           }
/*      */           break;
/*      */         
/*      */         case null:
/* 1608 */           macVariant = idToMacVariant(paramLong1, 9);
/* 1609 */           if (macVariant != null) {
/* 1610 */             if (macVariant.int1 != 0) {
/* 1611 */               executeAction(AccessibleAction.EXPAND, new Object[0]); break;
/*      */             } 
/* 1613 */             executeAction(AccessibleAction.COLLAPSE, new Object[0]);
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 1619 */           if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.COMBO_BOX) {
/* 1620 */             executeAction(AccessibleAction.EXPAND, new Object[0]);
/*      */           }
/*      */           break;
/*      */         
/*      */         case null:
/* 1625 */           macVariant = idToMacVariant(paramLong1, 1);
/* 1626 */           if (macVariant != null && macVariant.longArray != null && macVariant.longArray.length > 0) {
/* 1627 */             long[] arrayOfLong = macVariant.longArray;
/* 1628 */             ObservableList<?> observableList = FXCollections.observableArrayList();
/* 1629 */             for (long l : arrayOfLong) {
/* 1630 */               MacAccessible macAccessible = GlassAccessibleToMacAccessible(l);
/* 1631 */               if (macAccessible != null) {
/* 1632 */                 Integer integer1 = (Integer)macAccessible.getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/* 1633 */                 Integer integer2 = (Integer)macAccessible.getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1634 */                 if (integer1 != null && integer2 != null) {
/* 1635 */                   Node node = (Node)getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer1, integer2 });
/* 1636 */                   if (node != null) {
/* 1637 */                     observableList.add(node);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/* 1642 */             executeAction(AccessibleAction.SET_SELECTED_ITEMS, new Object[] { observableList });
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 1648 */           macVariant = idToMacVariant(paramLong1, 1);
/* 1649 */           if (macVariant != null && macVariant.longArray != null && macVariant.longArray.length > 0) {
/* 1650 */             long[] arrayOfLong = macVariant.longArray;
/* 1651 */             ObservableList<?> observableList = FXCollections.observableArrayList();
/* 1652 */             for (long l : arrayOfLong) {
/* 1653 */               MacAccessible macAccessible = GlassAccessibleToMacAccessible(l);
/* 1654 */               if (macAccessible != null) {
/* 1655 */                 Integer integer = (Integer)macAccessible.getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1656 */                 if (integer != null) {
/* 1657 */                   Node node = (Node)getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer });
/* 1658 */                   if (node != null) {
/* 1659 */                     observableList.add(node);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */             } 
/* 1664 */             executeAction(AccessibleAction.SET_SELECTED_ITEMS, new Object[] { observableList });
/*      */           } 
/*      */           break;
/*      */         
/*      */         case null:
/* 1669 */           macVariant = idToMacVariant(paramLong1, 18);
/* 1670 */           if (macVariant != null) {
/* 1671 */             int i = macVariant.int1;
/* 1672 */             int j = macVariant.int1 + macVariant.int2;
/* 1673 */             executeAction(AccessibleAction.SET_TEXT_SELECTION, new Object[] { Integer.valueOf(i), Integer.valueOf(j) });
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long accessibilityIndexOfChild(long paramLong) {
/* 1684 */     return -1L;
/*      */   }
/*      */   
/*      */   private long[] accessibilityParameterizedAttributeNames() {
/* 1688 */     if (getView() != null) return null; 
/* 1689 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1690 */     if (accessibleRole != null) {
/* 1691 */       ArrayList<MacAttribute> arrayList = new ArrayList();
/* 1692 */       MacRole macRole = getRole(accessibleRole);
/* 1693 */       if (macRole != null && macRole.macParameterizedAttributes != null) {
/* 1694 */         arrayList.addAll(macRole.macParameterizedAttributes);
/*      */       }
/* 1696 */       switch (accessibleRole) {
/*      */         
/*      */         case null:
/*      */         case null:
/* 1700 */           arrayList.remove(MacAttribute.NSAccessibilityCellForColumnAndRowParameterizedAttribute);
/*      */           break;
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1707 */           arrayList.addAll(textParameterizedAttributes);
/*      */           break;
/*      */       } 
/*      */       
/* 1711 */       return arrayList.stream().mapToLong(paramMacAttribute -> paramMacAttribute.ptr).toArray();
/*      */     } 
/* 1713 */     return null; } private MacVariant accessibilityAttributeValueForParameter(long paramLong1, long paramLong2) { Object object2; int[] arrayOfInt2; String str2; int[] arrayOfInt1; float[] arrayOfFloat; String str1; Bounds[] arrayOfBounds; Integer integer; ArrayList<MacVariant> arrayList; double d1;
/*      */     Font font;
/*      */     MacVariant macVariant2;
/*      */     double d2, d3, d4;
/* 1717 */     MacAttribute macAttribute = MacAttribute.getAttribute(paramLong1);
/* 1718 */     if (macAttribute == null || macAttribute.inputType == 0 || macAttribute.jfxAttr == null) {
/* 1719 */       return null;
/*      */     }
/* 1721 */     MacVariant macVariant1 = idToMacVariant(paramLong2, macAttribute.inputType);
/* 1722 */     if (macVariant1 == null) return null; 
/* 1723 */     Object object1 = macVariant1.getValue();
/*      */     
/* 1725 */     switch (macAttribute) {
/*      */       case null:
/* 1727 */         arrayOfInt2 = (int[])object1;
/* 1728 */         object2 = getAttribute(macAttribute.jfxAttr, new Object[] { Integer.valueOf(arrayOfInt2[1]), Integer.valueOf(arrayOfInt2[0]) });
/*      */         break;
/*      */       
/*      */       case null:
/* 1732 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.TEXT_AREA) {
/* 1733 */           object2 = getAttribute(macAttribute.jfxAttr, new Object[] { object1 });
/*      */           break;
/*      */         } 
/* 1736 */         object2 = Integer.valueOf(0);
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/* 1741 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.TEXT_AREA) {
/* 1742 */           Integer integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { object1 });
/* 1743 */           Integer integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { object1 });
/* 1744 */           if (integer1 != null && integer2 != null) {
/* 1745 */             object2 = new int[] { integer1.intValue(), integer2.intValue() - integer1.intValue() }; break;
/*      */           } 
/* 1747 */           object2 = null;
/*      */           
/*      */           break;
/*      */         } 
/* 1751 */         str2 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1752 */         object2 = new int[] { 0, (str2 != null) ? str2.length() : 0 };
/*      */         break;
/*      */ 
/*      */       
/*      */       case null:
/* 1757 */         arrayOfInt1 = (int[])object1;
/* 1758 */         arrayOfBounds = (Bounds[])getAttribute(macAttribute.jfxAttr, new Object[] { Integer.valueOf(arrayOfInt1[0]), Integer.valueOf(arrayOfInt1[0] + arrayOfInt1[1] - 1) });
/* 1759 */         d1 = Double.POSITIVE_INFINITY;
/* 1760 */         d2 = Double.POSITIVE_INFINITY;
/* 1761 */         d3 = Double.NEGATIVE_INFINITY;
/* 1762 */         d4 = Double.NEGATIVE_INFINITY;
/* 1763 */         if (arrayOfBounds != null)
/* 1764 */           for (byte b = 0; b < arrayOfBounds.length; b++) {
/* 1765 */             Bounds bounds = arrayOfBounds[b];
/* 1766 */             if (bounds != null) {
/* 1767 */               if (bounds.getMinX() < d1) d1 = bounds.getMinX(); 
/* 1768 */               if (bounds.getMinY() < d2) d2 = bounds.getMinY(); 
/* 1769 */               if (bounds.getMaxX() > d3) d3 = bounds.getMaxX(); 
/* 1770 */               if (bounds.getMaxY() > d4) d4 = bounds.getMaxY();
/*      */             
/*      */             } 
/*      */           }  
/* 1774 */         object2 = flipBounds(new BoundingBox(d1, d2, d3 - d1, d4 - d2));
/*      */         break;
/*      */       
/*      */       case null:
/* 1778 */         arrayOfFloat = (float[])object1;
/* 1779 */         integer = (Integer)getAttribute(macAttribute.jfxAttr, new Object[] { new Point2D(arrayOfFloat[0], arrayOfFloat[1]) });
/* 1780 */         if (integer != null) {
/* 1781 */           object2 = new int[] { integer.intValue(), 1 }; break;
/*      */         } 
/* 1783 */         object2 = null;
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1788 */         object2 = getAttribute(macAttribute.jfxAttr, new Object[] { object1 }); break;
/*      */     } 
/* 1790 */     if (object2 == null) return null; 
/* 1791 */     switch (macAttribute) {
/*      */       case null:
/* 1793 */         str1 = (String)object2;
/* 1794 */         str1 = str1.substring(macVariant1.int1, macVariant1.int1 + macVariant1.int2);
/* 1795 */         arrayList = new ArrayList();
/* 1796 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 1797 */         if (font != null) {
/* 1798 */           MacVariant macVariant = new MacVariant();
/* 1799 */           macVariant.type = 8;
/* 1800 */           macVariant.longArray = new long[] { MacText.NSAccessibilityFontNameKey.ptr, MacText.NSAccessibilityFontFamilyKey.ptr, MacText.NSAccessibilityVisibleNameKey.ptr, MacText.NSAccessibilityFontSizeKey.ptr };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1806 */           macVariant
/*      */ 
/*      */ 
/*      */             
/* 1810 */             .variantArray = new MacVariant[] { MacVariant.createNSString(font.getName()), MacVariant.createNSString(font.getFamily()), MacVariant.createNSString(font.getName()), MacVariant.createNSNumberForDouble(Double.valueOf(font.getSize())) };
/*      */ 
/*      */           
/* 1813 */           macVariant.key = MacText.NSAccessibilityFontTextAttribute.ptr;
/* 1814 */           macVariant.location = 0;
/* 1815 */           macVariant.length = str1.length();
/* 1816 */           arrayList.add(macVariant);
/*      */         } 
/* 1818 */         macVariant2 = macAttribute.map.apply(str1);
/* 1819 */         macVariant2.variantArray = arrayList.<MacVariant>toArray(new MacVariant[0]);
/* 1820 */         return macVariant2;
/*      */       
/*      */       case null:
/* 1823 */         str1 = (String)object2;
/* 1824 */         object2 = str1.substring(macVariant1.int1, macVariant1.int1 + macVariant1.int2);
/*      */         break;
/*      */       
/*      */       case null:
/* 1828 */         object2 = Long.valueOf(getNativeAccessible((Node)object2));
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1833 */     return macAttribute.map.apply(object2); }
/*      */ 
/*      */   
/*      */   private long[] accessibilityActionNames() {
/* 1837 */     if (getView() != null) return null; 
/* 1838 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1839 */     ArrayList<MacAction> arrayList = new ArrayList();
/* 1840 */     if (accessibleRole != null) {
/* 1841 */       MacRole macRole = getRole(accessibleRole);
/* 1842 */       if (macRole != null && macRole.macActions != null) {
/* 1843 */         arrayList.addAll(macRole.macActions);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1849 */       if (accessibleRole != AccessibleRole.NODE && accessibleRole != AccessibleRole.PARENT) {
/* 1850 */         arrayList.add(MacAction.NSAccessibilityShowMenuAction);
/*      */       }
/*      */     } 
/*      */     
/* 1854 */     return arrayList.stream().mapToLong(paramMacAction -> paramMacAction.ptr).toArray();
/*      */   }
/*      */   
/*      */   private String accessibilityActionDescription(long paramLong) {
/* 1858 */     return NSAccessibilityActionDescription(paramLong);
/*      */   }
/*      */   
/*      */   private void accessibilityPerformAction(long paramLong) {
/* 1862 */     MacAction macAction = MacAction.getAction(paramLong);
/* 1863 */     boolean bool = false;
/* 1864 */     if (macAction == MacAction.NSAccessibilityPressAction) {
/* 1865 */       AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1866 */       if (accessibleRole == AccessibleRole.TITLED_PANE || accessibleRole == AccessibleRole.COMBO_BOX) {
/* 1867 */         bool = true;
/*      */       }
/*      */     } 
/* 1870 */     if (macAction == MacAction.NSAccessibilityShowMenuAction && 
/* 1871 */       getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.SPLIT_MENU_BUTTON) {
/* 1872 */       bool = true;
/*      */     }
/*      */     
/* 1875 */     if (bool) {
/* 1876 */       if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.EXPANDED, new Object[0]))) {
/* 1877 */         executeAction(AccessibleAction.COLLAPSE, new Object[0]);
/*      */       } else {
/* 1879 */         executeAction(AccessibleAction.EXPAND, new Object[0]);
/*      */       } 
/*      */       return;
/*      */     } 
/* 1883 */     if (macAction != null && macAction.jfxAction != null) {
/* 1884 */       executeAction(macAction.jfxAction, new Object[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   private long accessibilityFocusedUIElement() {
/* 1889 */     Node node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/* 1890 */     if (node1 == null) return 0L;
/*      */     
/* 1892 */     Node node2 = (Node)getAccessible(node1).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/* 1893 */     if (node2 != null) return getNativeAccessible(node2); 
/* 1894 */     return getNativeAccessible(node1);
/*      */   }
/*      */   
/*      */   private boolean accessibilityIsIgnored() {
/* 1898 */     if (isIgnored()) return true; 
/* 1899 */     if (isInSlider())
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1904 */       return true;
/*      */     }
/* 1906 */     if (isInMenu()) {
/* 1907 */       AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*      */       
/* 1909 */       return !isMenuElement(accessibleRole);
/*      */     } 
/* 1911 */     if (ignoreInnerText()) {
/* 1912 */       return true;
/*      */     }
/* 1914 */     return false;
/*      */   }
/*      */   
/*      */   private long accessibilityHitTest(float paramFloat1, float paramFloat2) {
/* 1918 */     View view = getView();
/* 1919 */     if (view == null || view.getWindow() == null) {
/* 1920 */       return 0L;
/*      */     }
/* 1922 */     Screen screen = view.getWindow().getScreen();
/* 1923 */     paramFloat2 = screen.getHeight() - paramFloat2;
/* 1924 */     Node node = (Node)getAttribute(AccessibleAttribute.NODE_AT_POINT, new Object[] { new Point2D(paramFloat1, paramFloat2) });
/* 1925 */     return NSAccessibilityUnignoredAncestor(getNativeAccessible(node));
/*      */   }
/*      */   
/*      */   private static native void _initIDs();
/*      */   
/*      */   private static native boolean _initEnum(String paramString);
/*      */   
/*      */   private native long _createGlassAccessible();
/*      */   
/*      */   private native void _destroyGlassAccessible(long paramLong);
/*      */   
/*      */   private static native String getString(long paramLong);
/*      */   
/*      */   private static native boolean isEqualToString(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native long NSAccessibilityUnignoredAncestor(long paramLong);
/*      */   
/*      */   private static native long[] NSAccessibilityUnignoredChildren(long[] paramArrayOflong);
/*      */   
/*      */   private static native void NSAccessibilityPostNotification(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native String NSAccessibilityActionDescription(long paramLong);
/*      */   
/*      */   private static native String NSAccessibilityRoleDescription(long paramLong1, long paramLong2);
/*      */   
/*      */   private static native MacVariant idToMacVariant(long paramLong, int paramInt);
/*      */   
/*      */   private static native MacAccessible GlassAccessibleToMacAccessible(long paramLong);
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacAccessible.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */