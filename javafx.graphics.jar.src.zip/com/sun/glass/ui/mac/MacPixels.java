/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.Pixels;
/*    */ import java.nio.Buffer;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacPixels
/*    */   extends Pixels
/*    */ {
/* 43 */   private static final int nativeFormat = _initIDs();
/*    */ 
/*    */   
/*    */   private static native int _initIDs();
/*    */   
/*    */   static int getNativeFormat_impl() {
/* 49 */     return nativeFormat;
/*    */   }
/*    */   
/*    */   protected MacPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/* 53 */     super(paramInt1, paramInt2, paramByteBuffer);
/*    */   }
/*    */   
/*    */   protected MacPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 57 */     super(paramInt1, paramInt2, paramIntBuffer);
/*    */   }
/*    */   
/*    */   protected MacPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 61 */     super(paramInt1, paramInt2, paramIntBuffer, paramFloat1, paramFloat2);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void _fillDirectByteBuffer(ByteBuffer paramByteBuffer) {
/* 66 */     if (this.bytes != null) {
/* 67 */       this.bytes.rewind();
/* 68 */       if (this.bytes.isDirect() == true) {
/* 69 */         _copyPixels(paramByteBuffer, this.bytes, getWidth() * getHeight());
/*    */       } else {
/* 71 */         paramByteBuffer.put(this.bytes);
/*    */       } 
/* 73 */       this.bytes.rewind();
/*    */     } else {
/* 75 */       this.ints.rewind();
/* 76 */       if (this.ints.isDirect() == true) {
/* 77 */         _copyPixels(paramByteBuffer, this.ints, getWidth() * getHeight());
/*    */       } else {
/* 79 */         for (byte b = 0; b < this.ints.capacity(); b++) {
/* 80 */           int i = this.ints.get();
/* 81 */           paramByteBuffer.put((byte)(i >> 0 & 0xFF));
/* 82 */           paramByteBuffer.put((byte)(i >> 8 & 0xFF));
/* 83 */           paramByteBuffer.put((byte)(i >> 16 & 0xFF));
/* 84 */           paramByteBuffer.put((byte)(i >> 24 & 0xFF));
/*    */         } 
/*    */       } 
/* 87 */       this.ints.rewind();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected native void _copyPixels(Buffer paramBuffer1, Buffer paramBuffer2, int paramInt);
/*    */ 
/*    */   
/*    */   public String toString() {
/* 96 */     return "MacPixels [" + getWidth() + "x" + getHeight() + "]: " + super.toString();
/*    */   }
/*    */   
/*    */   protected native void _attachInt(long paramLong, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int[] paramArrayOfint, int paramInt3);
/*    */   
/*    */   protected native void _attachByte(long paramLong, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, byte[] paramArrayOfbyte, int paramInt3);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacPixels.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */