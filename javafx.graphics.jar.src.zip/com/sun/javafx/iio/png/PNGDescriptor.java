/*    */ package com.sun.javafx.iio.png;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.common.ImageDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PNGDescriptor
/*    */   extends ImageDescriptor
/*    */ {
/*    */   private static final String formatName = "PNG";
/* 33 */   private static final String[] extensions = new String[] { "png" };
/*    */   
/* 35 */   private static final ImageFormatDescription.Signature[] signatures = new ImageFormatDescription.Signature[] { new ImageFormatDescription.Signature(new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 }) };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   private static ImageDescriptor theInstance = null;
/*    */   
/*    */   private PNGDescriptor() {
/* 45 */     super("PNG", extensions, signatures);
/*    */   }
/*    */   
/*    */   public static synchronized ImageDescriptor getInstance() {
/* 49 */     if (theInstance == null) {
/* 50 */       theInstance = new PNGDescriptor();
/*    */     }
/* 52 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\png\PNGDescriptor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */