package javafx.beans.value;

public interface WritableNumberValue extends WritableValue<Number> {}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\value\WritableNumberValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */