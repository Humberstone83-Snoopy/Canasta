package com.sun.javafx.iio;

import java.io.IOException;

public interface ImageLoader {
  ImageFormatDescription getFormatDescription();
  
  void dispose();
  
  void addListener(ImageLoadListener paramImageLoadListener);
  
  void removeListener(ImageLoadListener paramImageLoadListener);
  
  ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */