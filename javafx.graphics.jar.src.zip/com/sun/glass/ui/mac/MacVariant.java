/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import java.time.LocalDate;
/*     */ import java.time.ZoneId;
/*     */ import java.util.Arrays;
/*     */ import javafx.geometry.Bounds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacVariant
/*     */ {
/*     */   static final int NSArray_id = 1;
/*     */   static final int NSArray_NSString = 2;
/*     */   static final int NSArray_int = 3;
/*     */   static final int NSArray_range = 4;
/*     */   static final int NSAttributedString = 5;
/*     */   static final int NSData = 6;
/*     */   static final int NSDate = 7;
/*     */   static final int NSDictionary = 8;
/*     */   static final int NSNumber_Boolean = 9;
/*     */   static final int NSNumber_Int = 10;
/*     */   static final int NSNumber_Float = 11;
/*     */   static final int NSNumber_Double = 12;
/*     */   static final int NSString = 13;
/*     */   static final int NSURL = 14;
/*     */   static final int NSValue_point = 15;
/*     */   static final int NSValue_size = 16;
/*     */   static final int NSValue_rectangle = 17;
/*     */   static final int NSValue_range = 18;
/*     */   static final int NSObject = 19;
/*     */   int type;
/*     */   long[] longArray;
/*     */   int[] intArray;
/*     */   String[] stringArray;
/*     */   MacVariant[] variantArray;
/*     */   float float1;
/*     */   float float2;
/*     */   float float3;
/*     */   float float4;
/*     */   int int1;
/*     */   int int2;
/*     */   String string;
/*     */   long long1;
/*     */   double double1;
/*     */   int location;
/*     */   int length;
/*     */   long key;
/*     */   
/*     */   static MacVariant createNSArray(Object paramObject) {
/*  76 */     MacVariant macVariant = new MacVariant();
/*  77 */     macVariant.type = 1;
/*  78 */     macVariant.longArray = (long[])paramObject;
/*  79 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSObject(Object paramObject) {
/*  83 */     MacVariant macVariant = new MacVariant();
/*  84 */     macVariant.type = 19;
/*  85 */     macVariant.long1 = ((Long)paramObject).longValue();
/*  86 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSString(Object paramObject) {
/*  90 */     MacVariant macVariant = new MacVariant();
/*  91 */     macVariant.type = 13;
/*  92 */     macVariant.string = (String)paramObject;
/*  93 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSAttributedString(Object paramObject) {
/*  97 */     MacVariant macVariant = new MacVariant();
/*  98 */     macVariant.type = 5;
/*  99 */     macVariant.string = (String)paramObject;
/* 100 */     return macVariant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MacVariant createNSDate(Object paramObject) {
/* 107 */     MacVariant macVariant = new MacVariant();
/* 108 */     macVariant.type = 7;
/* 109 */     macVariant.long1 = ((LocalDate)paramObject).atStartOfDay(ZoneId.systemDefault()).toEpochSecond();
/* 110 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSValueForSize(Object paramObject) {
/* 114 */     Bounds bounds = (Bounds)paramObject;
/* 115 */     MacVariant macVariant = new MacVariant();
/* 116 */     macVariant.type = 16;
/* 117 */     macVariant.float1 = (float)bounds.getWidth();
/* 118 */     macVariant.float2 = (float)bounds.getHeight();
/* 119 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSValueForPoint(Object paramObject) {
/* 123 */     Bounds bounds = (Bounds)paramObject;
/* 124 */     MacVariant macVariant = new MacVariant();
/* 125 */     macVariant.type = 15;
/* 126 */     macVariant.float1 = (float)bounds.getMinX();
/* 127 */     macVariant.float2 = (float)bounds.getMinY();
/* 128 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSValueForRectangle(Object paramObject) {
/* 132 */     Bounds bounds = (Bounds)paramObject;
/* 133 */     MacVariant macVariant = new MacVariant();
/* 134 */     macVariant.type = 17;
/* 135 */     macVariant.float1 = (float)bounds.getMinX();
/* 136 */     macVariant.float2 = (float)bounds.getMinY();
/* 137 */     macVariant.float3 = (float)bounds.getWidth();
/* 138 */     macVariant.float4 = (float)bounds.getHeight();
/* 139 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSValueForRange(Object paramObject) {
/* 143 */     int[] arrayOfInt = (int[])paramObject;
/* 144 */     MacVariant macVariant = new MacVariant();
/* 145 */     macVariant.type = 18;
/* 146 */     macVariant.int1 = arrayOfInt[0];
/* 147 */     macVariant.int2 = arrayOfInt[1];
/* 148 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSNumberForBoolean(Object paramObject) {
/* 152 */     Boolean bool = (Boolean)paramObject;
/* 153 */     MacVariant macVariant = new MacVariant();
/* 154 */     macVariant.type = 9;
/* 155 */     macVariant.int1 = bool.booleanValue() ? 1 : 0;
/* 156 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSNumberForDouble(Object paramObject) {
/* 160 */     MacVariant macVariant = new MacVariant();
/* 161 */     macVariant.type = 12;
/* 162 */     macVariant.double1 = ((Double)paramObject).doubleValue();
/* 163 */     return macVariant;
/*     */   }
/*     */   
/*     */   static MacVariant createNSNumberForInt(Object paramObject) {
/* 167 */     MacVariant macVariant = new MacVariant();
/* 168 */     macVariant.type = 10;
/* 169 */     macVariant.int1 = ((Integer)paramObject).intValue();
/* 170 */     return macVariant;
/*     */   }
/*     */   
/*     */   Object getValue() {
/* 174 */     switch (this.type) { case 9:
/* 175 */         return Boolean.valueOf((this.int1 != 0));
/* 176 */       case 10: return Integer.valueOf(this.int1);
/* 177 */       case 12: return Double.valueOf(this.double1);
/* 178 */       case 1: return this.longArray;
/* 179 */       case 3: return this.intArray;
/* 180 */       case 18: return new int[] { this.int1, this.int2 };
/* 181 */       case 15: return new float[] { this.float1, this.float2 };
/* 182 */       case 16: return new float[] { this.float1, this.float2 };
/* 183 */       case 17: return new float[] { this.float1, this.float2, this.float3, this.float4 };
/* 184 */       case 13: return this.string;
/* 185 */       case 5: return this.string; }
/*     */ 
/*     */     
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 193 */     Object object = getValue();
/* 194 */     switch (this.type) { case 1:
/* 195 */         object = Arrays.toString((long[])object); break;
/* 196 */       case 3: object = Arrays.toString((int[])object); break;
/* 197 */       case 18: object = Arrays.toString((int[])object); break;
/* 198 */       case 5: object = "" + object + object; break;
/* 199 */       case 8: object = "keys: " + Arrays.toString(this.longArray) + " values: " + Arrays.toString((Object[])this.variantArray); break; }
/*     */     
/* 201 */     return "MacVariant type: " + this.type + " value " + object;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacVariant.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */