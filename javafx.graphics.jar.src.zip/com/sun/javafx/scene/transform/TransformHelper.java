/*    */ package com.sun.javafx.scene.transform;
/*    */ 
/*    */ import com.sun.javafx.geom.transform.Affine3D;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.transform.Transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransformHelper
/*    */ {
/*    */   private static TransformAccessor transformAccessor;
/*    */   
/*    */   static {
/* 42 */     Utils.forceInit(Transform.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void add(Transform paramTransform, Node paramNode) {
/* 49 */     transformAccessor.add(paramTransform, paramNode);
/*    */   }
/*    */   
/*    */   public static void remove(Transform paramTransform, Node paramNode) {
/* 53 */     transformAccessor.remove(paramTransform, paramNode);
/*    */   }
/*    */   
/*    */   public static void apply(Transform paramTransform, Affine3D paramAffine3D) {
/* 57 */     transformAccessor.apply(paramTransform, paramAffine3D);
/*    */   }
/*    */   
/*    */   public static BaseTransform derive(Transform paramTransform, BaseTransform paramBaseTransform) {
/* 61 */     return transformAccessor.derive(paramTransform, paramBaseTransform);
/*    */   }
/*    */   
/*    */   public static Transform createImmutableTransform() {
/* 65 */     return transformAccessor.createImmutableTransform();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Transform createImmutableTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 72 */     return transformAccessor.createImmutableTransform(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Transform createImmutableTransform(Transform paramTransform, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 80 */     return transformAccessor.createImmutableTransform(paramTransform, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Transform createImmutableTransform(Transform paramTransform1, Transform paramTransform2, Transform paramTransform3) {
/* 86 */     return transformAccessor.createImmutableTransform(paramTransform1, paramTransform2, paramTransform3);
/*    */   }
/*    */   
/*    */   public static void setTransformAccessor(TransformAccessor paramTransformAccessor) {
/* 90 */     if (transformAccessor != null) {
/* 91 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 94 */     transformAccessor = paramTransformAccessor;
/*    */   }
/*    */   
/*    */   public static interface TransformAccessor {
/*    */     void add(Transform param1Transform, Node param1Node);
/*    */     
/*    */     void remove(Transform param1Transform, Node param1Node);
/*    */     
/*    */     void apply(Transform param1Transform, Affine3D param1Affine3D);
/*    */     
/*    */     BaseTransform derive(Transform param1Transform, BaseTransform param1BaseTransform);
/*    */     
/*    */     Transform createImmutableTransform();
/*    */     
/*    */     Transform createImmutableTransform(double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9, double param1Double10, double param1Double11, double param1Double12);
/*    */     
/*    */     Transform createImmutableTransform(Transform param1Transform, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9, double param1Double10, double param1Double11, double param1Double12);
/*    */     
/*    */     Transform createImmutableTransform(Transform param1Transform1, Transform param1Transform2, Transform param1Transform3);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\transform\TransformHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */