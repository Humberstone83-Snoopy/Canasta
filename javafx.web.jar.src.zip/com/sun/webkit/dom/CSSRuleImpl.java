/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.css.CSSRule;
/*     */ import org.w3c.dom.css.CSSStyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSSRuleImpl
/*     */   implements CSSRule
/*     */ {
/*     */   private final long peer;
/*     */   public static final int UNKNOWN_RULE = 0;
/*     */   public static final int STYLE_RULE = 1;
/*     */   public static final int CHARSET_RULE = 2;
/*     */   public static final int IMPORT_RULE = 3;
/*     */   public static final int MEDIA_RULE = 4;
/*     */   public static final int FONT_FACE_RULE = 5;
/*     */   public static final int PAGE_RULE = 6;
/*     */   public static final int KEYFRAMES_RULE = 7;
/*     */   public static final int KEYFRAME_RULE = 8;
/*     */   public static final int SUPPORTS_RULE = 12;
/*     */   public static final int WEBKIT_REGION_RULE = 16;
/*     */   public static final int WEBKIT_KEYFRAMES_RULE = 7;
/*     */   public static final int WEBKIT_KEYFRAME_RULE = 8;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       CSSRuleImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   CSSRuleImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static CSSRule create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     switch (getTypeImpl(paramLong)) { case 1:
/*  53 */         return new CSSStyleRuleImpl(paramLong);
/*  54 */       case 2: return new CSSCharsetRuleImpl(paramLong);
/*  55 */       case 3: return new CSSImportRuleImpl(paramLong);
/*  56 */       case 4: return new CSSMediaRuleImpl(paramLong);
/*  57 */       case 5: return new CSSFontFaceRuleImpl(paramLong);
/*  58 */       case 6: return new CSSPageRuleImpl(paramLong); }
/*     */     
/*  60 */     return new CSSRuleImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  66 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  70 */     return (paramObject instanceof CSSRuleImpl && this.peer == ((CSSRuleImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  74 */     long l = this.peer;
/*  75 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(CSSRule paramCSSRule) {
/*  79 */     return (paramCSSRule == null) ? 0L : ((CSSRuleImpl)paramCSSRule).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CSSRule getImpl(long paramLong) {
/*  85 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getType() {
/* 106 */     return getTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCssText() {
/* 111 */     return getCssTextImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCssText(String paramString) throws DOMException {
/* 116 */     setCssTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public CSSStyleSheet getParentStyleSheet() {
/* 121 */     return CSSStyleSheetImpl.getImpl(getParentStyleSheetImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public CSSRule getParentRule() {
/* 126 */     return getImpl(getParentRuleImpl(getPeer()));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native short getTypeImpl(long paramLong);
/*     */   
/*     */   static native String getCssTextImpl(long paramLong);
/*     */   
/*     */   static native void setCssTextImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long getParentStyleSheetImpl(long paramLong);
/*     */   
/*     */   static native long getParentRuleImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */