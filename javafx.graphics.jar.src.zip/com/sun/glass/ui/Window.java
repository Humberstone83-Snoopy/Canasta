/*      */ package com.sun.glass.ui;
/*      */ 
/*      */ import com.sun.prism.impl.PrismSettings;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Window
/*      */ {
/*      */   private long ptr;
/*      */   
/*      */   public static class EventHandler
/*      */   {
/*      */     public void handleWindowEvent(Window param1Window, long param1Long, int param1Int) {}
/*      */     
/*      */     public void handleScreenChangedEvent(Window param1Window, long param1Long, Screen param1Screen1, Screen param1Screen2) {}
/*      */     
/*      */     public void handleLevelEvent(int param1Int) {}
/*      */   }
/*      */   
/*   84 */   private volatile long delegatePtr = 0L;
/*      */ 
/*      */   
/*   87 */   private static final LinkedList<Window> visibleWindows = new LinkedList<>(); public static final int UNTITLED = 0; public static final int TITLED = 1; public static final int TRANSPARENT = 2; public static final int NORMAL = 0; public static final int UTILITY = 4; public static final int POPUP = 8;
/*      */   public static final int CLOSABLE = 16;
/*      */   
/*      */   public static synchronized List<Window> getWindows() {
/*   91 */     Application.checkEventThread();
/*   92 */     return Collections.unmodifiableList(visibleWindows);
/*      */   }
/*      */   public static final int MINIMIZABLE = 32; public static final int MAXIMIZABLE = 64; public static final int RIGHT_TO_LEFT = 128; public static final int UNIFIED = 256; private final Window owner; private final long parent; private final int styleMask; private final boolean isDecorated;
/*      */   public static List<Window> getWindowsClone() {
/*   96 */     Application.checkEventThread();
/*   97 */     return (List<Window>)visibleWindows.clone();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void add(Window paramWindow) {
/*  102 */     visibleWindows.add(paramWindow);
/*      */   }
/*      */   
/*      */   protected static void addFirst(Window paramWindow) {
/*  106 */     visibleWindows.addFirst(paramWindow);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void remove(Window paramWindow) {
/*  111 */     visibleWindows.remove(paramWindow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class State
/*      */   {
/*      */     public static final int NORMAL = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int MINIMIZED = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int MAXIMIZED = 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Level
/*      */   {
/*      */     private static final int _MIN = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int NORMAL = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int FLOATING = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int TOPMOST = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int _MAX = 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldStartUndecoratedMove = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   protected View view = null;
/*  199 */   protected Screen screen = null;
/*  200 */   private MenuBar menubar = null;
/*  201 */   private String title = "";
/*  202 */   private UndecoratedMoveResizeHelper helper = null;
/*      */   
/*  204 */   private int state = 1;
/*  205 */   private int level = 1;
/*  206 */   protected int x = 0;
/*  207 */   protected int y = 0;
/*  208 */   protected int width = 0;
/*  209 */   protected int height = 0;
/*  210 */   private float alpha = 1.0F;
/*  211 */   protected float platformScaleX = 1.0F;
/*  212 */   protected float platformScaleY = 1.0F;
/*  213 */   private float outputScaleX = 1.0F;
/*  214 */   private float outputScaleY = 1.0F;
/*  215 */   private float renderScaleX = 1.0F;
/*  216 */   private float renderScaleY = 1.0F;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean appletMode = false;
/*      */ 
/*      */   
/*  223 */   private Timer embeddedLocationTimer = null;
/*  224 */   private int lastKnownEmbeddedX = 0;
/*  225 */   private int lastKnownEmbeddedY = 0;
/*      */   
/*      */   private volatile boolean isResizable = false;
/*      */   
/*      */   private volatile boolean isVisible = false;
/*      */   
/*      */   private volatile boolean isFocused = false;
/*      */   
/*      */   private volatile boolean isFocusable = true;
/*      */   private volatile boolean isModal = false;
/*  235 */   private volatile int disableCount = 0;
/*      */   
/*  237 */   private int minimumWidth = 0, minimumHeight = 0;
/*  238 */   private int maximumWidth = Integer.MAX_VALUE; private int maximumHeight = Integer.MAX_VALUE;
/*      */   
/*      */   private EventHandler eventHandler;
/*      */ 
/*      */   
/*      */   protected Window(Window paramWindow, Screen paramScreen, int paramInt) {
/*  244 */     Application.checkEventThread();
/*  245 */     switch (paramInt & 0x3) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */         break;
/*      */       default:
/*  251 */         throw new RuntimeException("The visual kind should be UNTITLED, TITLED, or TRANSPARENT, but not a combination of these");
/*      */     } 
/*  253 */     switch (paramInt & 0xC) {
/*      */       case 0:
/*      */       case 4:
/*      */       case 8:
/*      */         break;
/*      */       default:
/*  259 */         throw new RuntimeException("The functional type should be NORMAL, POPUP, or UTILITY, but not a combination of these");
/*      */     } 
/*      */     
/*  262 */     if ((paramInt & 0x100) != 0 && 
/*  263 */       !Application.GetApplication().supportsUnifiedWindows()) {
/*  264 */       paramInt &= 0xFFFFFEFF;
/*      */     }
/*      */     
/*  267 */     if ((paramInt & 0x2) != 0 && 
/*  268 */       !Application.GetApplication().supportsTransparentWindows()) {
/*  269 */       paramInt &= 0xFFFFFFFD;
/*      */     }
/*      */ 
/*      */     
/*  273 */     this.owner = paramWindow;
/*  274 */     this.parent = 0L;
/*  275 */     this.styleMask = paramInt;
/*  276 */     this.isDecorated = ((this.styleMask & 0x1) != 0);
/*      */     
/*  278 */     this.screen = (paramScreen != null) ? paramScreen : Screen.getMainScreen();
/*  279 */     if (PrismSettings.allowHiDPIScaling) {
/*  280 */       this.platformScaleX = this.screen.getPlatformScaleX();
/*  281 */       this.platformScaleY = this.screen.getPlatformScaleY();
/*  282 */       this.outputScaleX = this.screen.getRecommendedOutputScaleX();
/*  283 */       this.outputScaleY = this.screen.getRecommendedOutputScaleY();
/*      */     } 
/*      */     
/*  286 */     this.ptr = _createWindow((paramWindow != null) ? paramWindow.getNativeHandle() : 0L, this.screen
/*  287 */         .getNativeScreen(), this.styleMask);
/*  288 */     if (this.ptr == 0L) {
/*  289 */       throw new RuntimeException("could not create platform window");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Window(long paramLong) {
/*  298 */     Application.checkEventThread();
/*  299 */     this.owner = null;
/*  300 */     this.parent = paramLong;
/*  301 */     this.styleMask = 0;
/*  302 */     this.isDecorated = false;
/*      */ 
/*      */     
/*  305 */     this.screen = null;
/*      */     
/*  307 */     this.ptr = _createChildWindow(paramLong);
/*  308 */     if (this.ptr == 0L) {
/*  309 */       throw new RuntimeException("could not create platform window");
/*      */     }
/*      */     
/*  312 */     if (this.screen == null) {
/*  313 */       this.screen = Screen.getMainScreen();
/*      */       
/*  315 */       if (PrismSettings.allowHiDPIScaling) {
/*  316 */         this.platformScaleX = this.screen.getPlatformScaleX();
/*  317 */         this.platformScaleY = this.screen.getPlatformScaleY();
/*  318 */         this.outputScaleX = this.screen.getRecommendedOutputScaleX();
/*  319 */         this.outputScaleY = this.screen.getRecommendedOutputScaleY();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  325 */     Application.checkEventThread();
/*  326 */     return (this.ptr == 0L);
/*      */   }
/*      */   
/*      */   private void checkNotClosed() {
/*  330 */     if (this.ptr == 0L) {
/*  331 */       throw new IllegalStateException("The window has already been closed");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*  337 */     Application.checkEventThread();
/*  338 */     if (this.view != null) {
/*  339 */       if (this.ptr != 0L) {
/*  340 */         _setView(this.ptr, null);
/*      */       }
/*  342 */       this.view.setWindow(null);
/*  343 */       this.view.close();
/*  344 */       this.view = null;
/*      */     } 
/*  346 */     if (this.ptr != 0L) {
/*  347 */       _close(this.ptr);
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean isChild() {
/*  352 */     Application.checkEventThread();
/*  353 */     return (this.parent != 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeWindow() {
/*  360 */     Application.checkEventThread();
/*  361 */     checkNotClosed();
/*  362 */     return (this.delegatePtr != 0L) ? this.delegatePtr : this.ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeHandle() {
/*  370 */     Application.checkEventThread();
/*  371 */     return (this.delegatePtr != 0L) ? this.delegatePtr : this.ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getRawHandle() {
/*  379 */     return this.ptr;
/*      */   }
/*      */   
/*      */   public Window getOwner() {
/*  383 */     Application.checkEventThread();
/*  384 */     return this.owner;
/*      */   }
/*      */   
/*      */   public View getView() {
/*  388 */     Application.checkEventThread();
/*  389 */     return this.view;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setView(View paramView) {
/*  394 */     Application.checkEventThread();
/*  395 */     checkNotClosed();
/*  396 */     View view = getView();
/*  397 */     if (view == paramView) {
/*      */       return;
/*      */     }
/*      */     
/*  401 */     if (view != null) {
/*  402 */       view.setWindow(null);
/*      */     }
/*  404 */     if (paramView != null) {
/*  405 */       Window window = paramView.getWindow();
/*  406 */       if (window != null) {
/*  407 */         window.setView(null);
/*      */       }
/*      */     } 
/*      */     
/*  411 */     if (paramView != null && _setView(this.ptr, paramView)) {
/*  412 */       this.view = paramView;
/*  413 */       this.view.setWindow(this);
/*  414 */       if (!this.isDecorated) {
/*  415 */         this.helper = new UndecoratedMoveResizeHelper();
/*      */       }
/*      */     } else {
/*  418 */       _setView(this.ptr, null);
/*  419 */       this.view = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Screen getScreen() {
/*  424 */     Application.checkEventThread();
/*  425 */     return this.screen;
/*      */   }
/*      */   
/*      */   protected void setScreen(Screen paramScreen) {
/*  429 */     Application.checkEventThread();
/*      */     
/*  431 */     Screen screen = this.screen;
/*  432 */     this.screen = paramScreen;
/*      */     
/*  434 */     if (this.eventHandler != null && ((
/*  435 */       screen == null && this.screen != null) || (screen != null && 
/*  436 */       !screen.equals(this.screen)))) {
/*  437 */       this.eventHandler.handleScreenChangedEvent(this, System.nanoTime(), screen, this.screen);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStyleMask() {
/*  443 */     Application.checkEventThread();
/*  444 */     return this.styleMask;
/*      */   }
/*      */   
/*      */   public MenuBar getMenuBar() {
/*  448 */     Application.checkEventThread();
/*  449 */     return this.menubar;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMenuBar(MenuBar paramMenuBar) {
/*  454 */     Application.checkEventThread();
/*  455 */     checkNotClosed();
/*  456 */     if (_setMenubar(this.ptr, paramMenuBar.getNativeMenu())) {
/*  457 */       this.menubar = paramMenuBar;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isDecorated() {
/*  462 */     Application.checkEventThread();
/*  463 */     return this.isDecorated;
/*      */   }
/*      */   
/*      */   public boolean isMinimized() {
/*  467 */     Application.checkEventThread();
/*  468 */     return (this.state == 2);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean minimize(boolean paramBoolean) {
/*  473 */     Application.checkEventThread();
/*  474 */     checkNotClosed();
/*  475 */     _minimize(this.ptr, paramBoolean);
/*      */     
/*  477 */     return isMinimized();
/*      */   }
/*      */   
/*      */   public boolean isMaximized() {
/*  481 */     Application.checkEventThread();
/*  482 */     return (this.state == 3);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean maximize(boolean paramBoolean) {
/*  487 */     Application.checkEventThread();
/*  488 */     checkNotClosed();
/*  489 */     _maximize(this.ptr, paramBoolean, isMaximized());
/*  490 */     return isMaximized();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyScaleChanged(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  496 */     if (!PrismSettings.allowHiDPIScaling)
/*  497 */       return;  this.platformScaleX = paramFloat1;
/*  498 */     this.platformScaleY = paramFloat2;
/*  499 */     this.outputScaleX = paramFloat3;
/*  500 */     this.outputScaleY = paramFloat4;
/*  501 */     notifyRescale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getPlatformScaleX() {
/*  510 */     return this.platformScaleX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getPlatformScaleY() {
/*  519 */     return this.platformScaleY;
/*      */   }
/*      */   
/*      */   public void setRenderScaleX(float paramFloat) {
/*  523 */     if (!PrismSettings.allowHiDPIScaling)
/*  524 */       return;  this.renderScaleX = paramFloat;
/*      */   }
/*      */   
/*      */   public void setRenderScaleY(float paramFloat) {
/*  528 */     if (!PrismSettings.allowHiDPIScaling)
/*  529 */       return;  this.renderScaleY = paramFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getRenderScaleX() {
/*  537 */     return this.renderScaleX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getRenderScaleY() {
/*  545 */     return this.renderScaleY;
/*      */   }
/*      */   
/*      */   public float getOutputScaleX() {
/*  549 */     return this.outputScaleX;
/*      */   }
/*      */   
/*      */   public float getOutputScaleY() {
/*  553 */     return this.outputScaleY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkScreenLocation() {
/*  560 */     this.x = _getEmbeddedX(this.ptr);
/*  561 */     this.y = _getEmbeddedY(this.ptr);
/*  562 */     if (this.x != this.lastKnownEmbeddedX || this.y != this.lastKnownEmbeddedY) {
/*  563 */       this.lastKnownEmbeddedX = this.x;
/*  564 */       this.lastKnownEmbeddedY = this.y;
/*  565 */       handleWindowEvent(System.nanoTime(), 512);
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getX() {
/*  570 */     Application.checkEventThread();
/*  571 */     return this.x;
/*      */   }
/*      */   
/*      */   public int getY() {
/*  575 */     Application.checkEventThread();
/*  576 */     return this.y;
/*      */   }
/*      */   
/*      */   public int getWidth() {
/*  580 */     Application.checkEventThread();
/*  581 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight() {
/*  585 */     Application.checkEventThread();
/*  586 */     return this.height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBounds(float paramFloat1, float paramFloat2, boolean paramBoolean1, boolean paramBoolean2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  623 */     Application.checkEventThread();
/*  624 */     checkNotClosed();
/*  625 */     float f1 = this.platformScaleX;
/*  626 */     float f2 = this.platformScaleY;
/*  627 */     int i = this.screen.getPlatformX() + Math.round((paramFloat1 - this.screen.getX()) * f1);
/*  628 */     int j = this.screen.getPlatformY() + Math.round((paramFloat2 - this.screen.getY()) * f2);
/*  629 */     int k = (int)((paramFloat3 > 0.0F) ? Math.ceil((paramFloat3 * f1)) : paramFloat3);
/*  630 */     int m = (int)((paramFloat4 > 0.0F) ? Math.ceil((paramFloat4 * f2)) : paramFloat4);
/*  631 */     int n = (int)((paramFloat5 > 0.0F) ? Math.ceil((paramFloat5 * f1)) : paramFloat5);
/*  632 */     int i1 = (int)((paramFloat6 > 0.0F) ? Math.ceil((paramFloat6 * f2)) : paramFloat6);
/*  633 */     _setBounds(this.ptr, i, j, paramBoolean1, paramBoolean2, k, m, n, i1, paramFloat7, paramFloat8);
/*      */   }
/*      */   
/*      */   public void setPosition(int paramInt1, int paramInt2) {
/*  637 */     Application.checkEventThread();
/*  638 */     checkNotClosed();
/*  639 */     _setBounds(this.ptr, paramInt1, paramInt2, true, true, 0, 0, 0, 0, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public void setSize(int paramInt1, int paramInt2) {
/*  643 */     Application.checkEventThread();
/*  644 */     checkNotClosed();
/*  645 */     _setBounds(this.ptr, 0, 0, false, false, paramInt1, paramInt2, 0, 0, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public void setContentSize(int paramInt1, int paramInt2) {
/*  649 */     Application.checkEventThread();
/*  650 */     checkNotClosed();
/*  651 */     _setBounds(this.ptr, 0, 0, false, false, 0, 0, paramInt1, paramInt2, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public boolean isVisible() {
/*  655 */     Application.checkEventThread();
/*  656 */     return this.isVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void synthesizeViewMoveEvent() {
/*  663 */     View view = getView();
/*  664 */     if (view != null) {
/*  665 */       view.notifyView(423);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean paramBoolean) {
/*  671 */     Application.checkEventThread();
/*  672 */     if (this.isVisible != paramBoolean) {
/*  673 */       if (!paramBoolean) {
/*  674 */         if (getView() != null) {
/*  675 */           getView().setVisible(paramBoolean);
/*      */         }
/*      */         
/*  678 */         if (this.ptr != 0L) {
/*  679 */           this.isVisible = _setVisible(this.ptr, paramBoolean);
/*      */         } else {
/*  681 */           this.isVisible = paramBoolean;
/*      */         } 
/*  683 */         remove(this);
/*  684 */         if (this.parent != 0L) {
/*  685 */           this.embeddedLocationTimer.stop();
/*      */         }
/*      */       } else {
/*  688 */         checkNotClosed();
/*  689 */         this.isVisible = _setVisible(this.ptr, paramBoolean);
/*      */         
/*  691 */         if (getView() != null) {
/*  692 */           getView().setVisible(this.isVisible);
/*      */         }
/*  694 */         add(this);
/*  695 */         if (this.parent != 0L) {
/*  696 */           Runnable runnable1 = () -> checkScreenLocation();
/*  697 */           Runnable runnable2 = () -> Application.invokeLater(paramRunnable);
/*  698 */           this
/*  699 */             .embeddedLocationTimer = Application.GetApplication().createTimer(runnable2);
/*  700 */           this.embeddedLocationTimer.start(16);
/*      */         } 
/*      */         
/*  703 */         synthesizeViewMoveEvent();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean setResizable(boolean paramBoolean) {
/*  710 */     Application.checkEventThread();
/*  711 */     checkNotClosed();
/*  712 */     if (this.isResizable != paramBoolean && 
/*  713 */       _setResizable(this.ptr, paramBoolean)) {
/*  714 */       this.isResizable = paramBoolean;
/*  715 */       synthesizeViewMoveEvent();
/*      */     } 
/*      */     
/*  718 */     return this.isResizable;
/*      */   }
/*      */   
/*      */   public boolean isResizable() {
/*  722 */     Application.checkEventThread();
/*  723 */     return this.isResizable;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnifiedWindow() {
/*  728 */     return ((this.styleMask & 0x100) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTransparentWindow() {
/*  733 */     return ((this.styleMask & 0x2) != 0);
/*      */   }
/*      */   
/*  736 */   private static volatile Window focusedWindow = null;
/*      */   public static Window getFocusedWindow() {
/*  738 */     Application.checkEventThread();
/*  739 */     return focusedWindow;
/*      */   }
/*      */   
/*      */   private static void setFocusedWindow(Window paramWindow) {
/*  743 */     focusedWindow = paramWindow;
/*      */   }
/*      */   
/*      */   public boolean isFocused() {
/*  747 */     Application.checkEventThread();
/*  748 */     return this.isFocused;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requestFocus(int paramInt) {
/*  768 */     Application.checkEventThread();
/*  769 */     checkNotClosed();
/*      */     
/*  771 */     if (!isChild() && paramInt != 542) {
/*  772 */       throw new IllegalArgumentException("Invalid focus event ID for top-level window");
/*      */     }
/*      */     
/*  775 */     if (isChild() && (paramInt < 541 || paramInt > 544)) {
/*  776 */       throw new IllegalArgumentException("Invalid focus event ID for child window");
/*      */     }
/*      */     
/*  779 */     if (paramInt == 541 && !isFocused())
/*      */     {
/*  781 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  786 */     if (!this.isFocusable)
/*      */     {
/*  788 */       return false;
/*      */     }
/*      */     
/*  791 */     return _requestFocus(this.ptr, paramInt);
/*      */   }
/*      */   
/*      */   public boolean requestFocus() {
/*  795 */     Application.checkEventThread();
/*  796 */     return requestFocus(542);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFocusable(boolean paramBoolean) {
/*  806 */     Application.checkEventThread();
/*  807 */     checkNotClosed();
/*  808 */     this.isFocusable = paramBoolean;
/*  809 */     if (isEnabled()) {
/*  810 */       _setFocusable(this.ptr, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean grabFocus() {
/*  860 */     Application.checkEventThread();
/*  861 */     checkNotClosed();
/*      */     
/*  863 */     if (!isFocused()) {
/*  864 */       throw new IllegalStateException("The window must be focused when calling grabFocus()");
/*      */     }
/*      */     
/*  867 */     return _grabFocus(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ungrabFocus() {
/*  881 */     Application.checkEventThread();
/*  882 */     checkNotClosed();
/*  883 */     _ungrabFocus(this.ptr);
/*      */   }
/*      */   
/*      */   public String getTitle() {
/*  887 */     Application.checkEventThread();
/*  888 */     return this.title;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTitle(String paramString) {
/*  893 */     Application.checkEventThread();
/*  894 */     checkNotClosed();
/*  895 */     if (paramString == null) {
/*  896 */       paramString = "";
/*      */     }
/*  898 */     if (!paramString.equals(this.title) && 
/*  899 */       _setTitle(this.ptr, paramString)) {
/*  900 */       this.title = paramString;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLevel(int paramInt) {
/*  913 */     Application.checkEventThread();
/*  914 */     checkNotClosed();
/*  915 */     if (paramInt < 1 || paramInt > 3) {
/*  916 */       throw new IllegalArgumentException("Level should be in the range [1..3]");
/*      */     }
/*  918 */     if (this.level != paramInt) {
/*  919 */       _setLevel(this.ptr, paramInt);
/*  920 */       this.level = paramInt;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getLevel() {
/*  925 */     Application.checkEventThread();
/*  926 */     return this.level;
/*      */   }
/*      */   
/*      */   private boolean isInFullscreen() {
/*  930 */     View view = getView();
/*  931 */     return (view == null) ? false : view.isInFullscreen();
/*      */   }
/*      */ 
/*      */   
/*      */   void notifyFullscreen(boolean paramBoolean) {
/*  936 */     float f = getAlpha();
/*  937 */     if (f < 1.0F) {
/*  938 */       if (paramBoolean) {
/*      */         
/*  940 */         _setAlpha(this.ptr, 1.0F);
/*      */       } else {
/*      */         
/*  943 */         setAlpha(f);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlpha(float paramFloat) {
/*  959 */     Application.checkEventThread();
/*  960 */     checkNotClosed();
/*  961 */     if (paramFloat < 0.0F || paramFloat > 1.0F) {
/*  962 */       throw new IllegalArgumentException("Alpha should be in the range [0f..1f]");
/*      */     }
/*      */     
/*  965 */     this.alpha = paramFloat;
/*      */     
/*  967 */     if (paramFloat < 1.0F && isInFullscreen()) {
/*      */       return;
/*      */     }
/*      */     
/*  971 */     _setAlpha(this.ptr, this.alpha);
/*      */   }
/*      */   
/*      */   public float getAlpha() {
/*  975 */     Application.checkEventThread();
/*  976 */     return this.alpha;
/*      */   }
/*      */   
/*      */   public boolean getAppletMode() {
/*  980 */     return this.appletMode;
/*      */   }
/*      */   
/*      */   public void setAppletMode(boolean paramBoolean) {
/*  984 */     this.appletMode = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setBackground(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1001 */     Application.checkEventThread();
/* 1002 */     checkNotClosed();
/* 1003 */     return _setBackground(this.ptr, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */   
/*      */   public boolean isEnabled() {
/* 1007 */     Application.checkEventThread();
/* 1008 */     return (this.disableCount == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean paramBoolean) {
/* 1039 */     Application.checkEventThread();
/* 1040 */     checkNotClosed();
/* 1041 */     if (!paramBoolean) {
/* 1042 */       if (++this.disableCount > 1) {
/*      */         return;
/*      */       }
/*      */     } else {
/*      */       
/* 1047 */       if (this.disableCount == 0) {
/*      */         return;
/*      */       }
/*      */       
/* 1051 */       if (--this.disableCount > 0) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1058 */     _setEnabled(this.ptr, isEnabled());
/*      */   }
/*      */   
/*      */   public int getMinimumWidth() {
/* 1062 */     Application.checkEventThread();
/* 1063 */     return this.minimumWidth;
/*      */   }
/*      */   
/*      */   public int getMinimumHeight() {
/* 1067 */     Application.checkEventThread();
/* 1068 */     return this.minimumHeight;
/*      */   }
/*      */   
/*      */   public int getMaximumWidth() {
/* 1072 */     Application.checkEventThread();
/* 1073 */     return this.maximumWidth;
/*      */   }
/*      */   
/*      */   public int getMaximumHeight() {
/* 1077 */     Application.checkEventThread();
/* 1078 */     return this.maximumHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinimumSize(int paramInt1, int paramInt2) {
/* 1091 */     Application.checkEventThread();
/* 1092 */     if (paramInt1 < 0 || paramInt2 < 0) {
/* 1093 */       throw new IllegalArgumentException("The width and height must be >= 0. Got: width=" + paramInt1 + "; height=" + paramInt2);
/*      */     }
/* 1095 */     checkNotClosed();
/* 1096 */     if (_setMinimumSize(this.ptr, paramInt1, paramInt2)) {
/* 1097 */       this.minimumWidth = paramInt1;
/* 1098 */       this.minimumHeight = paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaximumSize(int paramInt1, int paramInt2) {
/* 1112 */     Application.checkEventThread();
/* 1113 */     if (paramInt1 < 0 || paramInt2 < 0) {
/* 1114 */       throw new IllegalArgumentException("The width and height must be >= 0. Got: width=" + paramInt1 + "; height=" + paramInt2);
/*      */     }
/* 1116 */     checkNotClosed();
/* 1117 */     if (_setMaximumSize(this.ptr, 
/*      */         
/* 1119 */         (paramInt1 == Integer.MAX_VALUE) ? -1 : paramInt1, 
/* 1120 */         (paramInt2 == Integer.MAX_VALUE) ? -1 : paramInt2)) {
/*      */       
/* 1122 */       this.maximumWidth = paramInt1;
/* 1123 */       this.maximumHeight = paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIcon(Pixels paramPixels) {
/* 1133 */     Application.checkEventThread();
/* 1134 */     checkNotClosed();
/* 1135 */     _setIcon(this.ptr, paramPixels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(Cursor paramCursor) {
/* 1147 */     Application.checkEventThread();
/* 1148 */     _setCursor(this.ptr, paramCursor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void toFront() {
/* 1158 */     Application.checkEventThread();
/* 1159 */     checkNotClosed();
/* 1160 */     _toFront(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void toBack() {
/* 1171 */     Application.checkEventThread();
/* 1172 */     checkNotClosed();
/* 1173 */     _toBack(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterModal() {
/* 1184 */     checkNotClosed();
/* 1185 */     if (!this.isModal) {
/* 1186 */       this.isModal = true;
/* 1187 */       _enterModal(this.ptr);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterModal(Window paramWindow) {
/* 1197 */     checkNotClosed();
/* 1198 */     if (!this.isModal) {
/* 1199 */       this.isModal = true;
/* 1200 */       _enterModalWithWindow(this.ptr, paramWindow.getNativeHandle());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitModal() {
/* 1206 */     checkNotClosed();
/* 1207 */     if (this.isModal == true) {
/* 1208 */       _exitModal(this.ptr);
/* 1209 */       this.isModal = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isModal() {
/* 1214 */     return this.isModal;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispatchNpapiEvent(Map paramMap) {
/* 1219 */     Application.checkEventThread();
/* 1220 */     throw new RuntimeException("This operation is not supported on this platform");
/*      */   }
/*      */   
/*      */   public EventHandler getEventHandler() {
/* 1224 */     Application.checkEventThread();
/* 1225 */     return this.eventHandler;
/*      */   }
/*      */   
/*      */   public void setEventHandler(EventHandler paramEventHandler) {
/* 1229 */     Application.checkEventThread();
/* 1230 */     this.eventHandler = paramEventHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShouldStartUndecoratedMove(boolean paramBoolean) {
/* 1238 */     Application.checkEventThread();
/* 1239 */     this.shouldStartUndecoratedMove = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyClose() {
/* 1246 */     handleWindowEvent(System.nanoTime(), 521);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDestroy() {
/* 1251 */     if (this.ptr == 0L) {
/*      */       return;
/*      */     }
/*      */     
/* 1255 */     handleWindowEvent(System.nanoTime(), 522);
/*      */     
/* 1257 */     this.ptr = 0L;
/*      */ 
/*      */     
/* 1260 */     setVisible(false);
/*      */   }
/*      */   
/*      */   protected void notifyMove(int paramInt1, int paramInt2) {
/* 1264 */     this.x = paramInt1;
/* 1265 */     this.y = paramInt2;
/* 1266 */     handleWindowEvent(System.nanoTime(), 512);
/*      */   }
/*      */   
/*      */   protected void notifyRescale() {
/* 1270 */     handleWindowEvent(System.nanoTime(), 513);
/*      */   }
/*      */   
/*      */   protected void notifyMoveToAnotherScreen(Screen paramScreen) {
/* 1274 */     setScreen(paramScreen);
/*      */   }
/*      */   
/*      */   protected void setState(int paramInt) {
/* 1278 */     this.state = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyResize(int paramInt1, int paramInt2, int paramInt3) {
/* 1289 */     if (paramInt1 == 531) {
/* 1290 */       this.state = 2;
/*      */     } else {
/* 1292 */       if (paramInt1 == 532) {
/* 1293 */         this.state = 3;
/*      */       } else {
/* 1295 */         this.state = 1;
/*      */       } 
/* 1297 */       this.width = paramInt2;
/* 1298 */       this.height = paramInt3;
/*      */ 
/*      */       
/* 1301 */       if (this.helper != null) {
/* 1302 */         this.helper.updateRectangles();
/*      */       }
/*      */     } 
/* 1305 */     handleWindowEvent(System.nanoTime(), paramInt1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1310 */     if (paramInt1 == 532 || paramInt1 == 533) {
/* 1311 */       handleWindowEvent(System.nanoTime(), 511);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void notifyFocus(int paramInt) {
/* 1316 */     boolean bool = (paramInt != 541);
/*      */     
/* 1318 */     if (this.isFocused != bool) {
/* 1319 */       this.isFocused = bool;
/* 1320 */       if (this.isFocused) {
/* 1321 */         setFocusedWindow(this);
/*      */       } else {
/* 1323 */         setFocusedWindow(null);
/*      */       } 
/* 1325 */       handleWindowEvent(System.nanoTime(), paramInt);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyFocusDisabled() {
/* 1330 */     handleWindowEvent(System.nanoTime(), 545);
/*      */   }
/*      */   
/*      */   protected void notifyFocusUngrab() {
/* 1334 */     handleWindowEvent(System.nanoTime(), 546);
/*      */   }
/*      */   
/*      */   protected void notifyDelegatePtr(long paramLong) {
/* 1338 */     this.delegatePtr = paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleWindowEvent(long paramLong, int paramInt) {
/* 1345 */     if (this.eventHandler != null) {
/* 1346 */       this.eventHandler.handleWindowEvent(this, paramLong, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUndecoratedMoveRectangle(int paramInt) {
/* 1360 */     Application.checkEventThread();
/* 1361 */     if (this.isDecorated == true) {
/*      */       
/* 1363 */       System.err.println("Glass Window.setUndecoratedMoveRectangle is only valid for Undecorated Window. In the future this will be hard error.");
/* 1364 */       Thread.dumpStack();
/*      */       
/*      */       return;
/*      */     } 
/* 1368 */     if (this.helper != null) {
/* 1369 */       this.helper.setMoveRectangle(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldStartUndecoratedMove(int paramInt1, int paramInt2) {
/* 1378 */     Application.checkEventThread();
/* 1379 */     if (this.shouldStartUndecoratedMove == true) {
/* 1380 */       return true;
/*      */     }
/* 1382 */     if (this.isDecorated == true) {
/* 1383 */       return false;
/*      */     }
/*      */     
/* 1386 */     if (this.helper != null) {
/* 1387 */       return this.helper.shouldStartMove(paramInt1, paramInt2);
/*      */     }
/* 1389 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUndecoratedResizeRectangle(int paramInt) {
/* 1400 */     Application.checkEventThread();
/* 1401 */     if (this.isDecorated == true || !this.isResizable) {
/*      */       
/* 1403 */       System.err.println("Glass Window.setUndecoratedResizeRectangle is only valid for Undecorated Resizable Window. In the future this will be hard error.");
/* 1404 */       Thread.dumpStack();
/*      */       
/*      */       return;
/*      */     } 
/* 1408 */     if (this.helper != null) {
/* 1409 */       this.helper.setResizeRectangle(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldStartUndecoratedResize(int paramInt1, int paramInt2) {
/* 1419 */     Application.checkEventThread();
/* 1420 */     if (this.isDecorated == true || !this.isResizable) {
/* 1421 */       return false;
/*      */     }
/*      */     
/* 1424 */     if (this.helper != null) {
/* 1425 */       return this.helper.shouldStartResize(paramInt1, paramInt2);
/*      */     }
/* 1427 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean handleMouseEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 1440 */     if (!this.isDecorated) {
/* 1441 */       return this.helper.handleMouseEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*      */     }
/* 1443 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1448 */     Application.checkEventThread();
/*      */     
/* 1450 */     return "Window:\n    ptr: " + getNativeWindow() + "\n    screen ptr: " + (
/* 1451 */       (this.screen != null) ? (String)Long.valueOf(this.screen.getNativeScreen()) : "null") + "\n    isDecorated: " + 
/* 1452 */       isDecorated() + "\n    title: " + 
/* 1453 */       getTitle() + "\n    visible: " + 
/* 1454 */       isVisible() + "\n    focused: " + 
/* 1455 */       isFocused() + "\n    modal: " + 
/* 1456 */       isModal() + "\n    state: " + this.state + "\n    x: " + 
/*      */       
/* 1458 */       getX() + ", y: " + getY() + ", w: " + getWidth() + ", h: " + getHeight() + "\n";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class TrackingRectangle
/*      */   {
/* 1465 */     int size = 0;
/* 1466 */     int x = 0, y = 0, width = 0, height = 0;
/*      */     boolean contains(int param1Int1, int param1Int2) {
/* 1468 */       return (this.size > 0 && param1Int1 >= this.x && param1Int1 < this.x + this.width && param1Int2 >= this.y && param1Int2 < this.y + this.height);
/*      */     }
/*      */     
/*      */     private TrackingRectangle() {}
/*      */   }
/*      */   
/*      */   protected void notifyLevelChanged(int paramInt) {
/* 1475 */     this.level = paramInt;
/* 1476 */     if (this.eventHandler != null)
/* 1477 */       this.eventHandler.handleLevelEvent(paramInt); 
/*      */   }
/*      */   
/*      */   private class UndecoratedMoveResizeHelper
/*      */   {
/* 1482 */     Window.TrackingRectangle moveRect = null;
/* 1483 */     Window.TrackingRectangle resizeRect = null; boolean inMove = false;
/*      */     boolean inResize = false;
/*      */     int startMouseX;
/*      */     int startMouseY;
/*      */     int startX;
/*      */     int startY;
/*      */     int startWidth;
/*      */     int startHeight;
/*      */     
/*      */     UndecoratedMoveResizeHelper() {
/* 1493 */       this.moveRect = new Window.TrackingRectangle();
/* 1494 */       this.resizeRect = new Window.TrackingRectangle();
/*      */     }
/*      */     
/*      */     void setMoveRectangle(int param1Int) {
/* 1498 */       this.moveRect.size = param1Int;
/*      */       
/* 1500 */       this.moveRect.x = 0;
/* 1501 */       this.moveRect.y = 0;
/* 1502 */       this.moveRect.width = Window.this.getWidth();
/* 1503 */       this.moveRect.height = this.moveRect.size;
/*      */     }
/*      */     
/*      */     boolean shouldStartMove(int param1Int1, int param1Int2) {
/* 1507 */       return this.moveRect.contains(param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     boolean inMove() {
/* 1511 */       return this.inMove;
/*      */     }
/*      */     
/*      */     void startMove(int param1Int1, int param1Int2) {
/* 1515 */       this.inMove = true;
/*      */       
/* 1517 */       this.startMouseX = param1Int1;
/* 1518 */       this.startMouseY = param1Int2;
/*      */       
/* 1520 */       this.startX = Window.this.getX();
/* 1521 */       this.startY = Window.this.getY();
/*      */     }
/*      */     
/*      */     void deltaMove(int param1Int1, int param1Int2) {
/* 1525 */       int i = param1Int1 - this.startMouseX;
/* 1526 */       int j = param1Int2 - this.startMouseY;
/*      */       
/* 1528 */       Window.this.setPosition(this.startX + i, this.startY + j);
/*      */     }
/*      */     
/*      */     void stopMove() {
/* 1532 */       this.inMove = false;
/*      */     }
/*      */     
/*      */     void setResizeRectangle(int param1Int) {
/* 1536 */       this.resizeRect.size = param1Int;
/*      */ 
/*      */       
/* 1539 */       this.resizeRect.x = Window.this.getWidth() - this.resizeRect.size;
/* 1540 */       this.resizeRect.y = Window.this.getHeight() - this.resizeRect.size;
/* 1541 */       this.resizeRect.width = this.resizeRect.size;
/* 1542 */       this.resizeRect.height = this.resizeRect.size;
/*      */     }
/*      */     
/*      */     boolean shouldStartResize(int param1Int1, int param1Int2) {
/* 1546 */       return this.resizeRect.contains(param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     boolean inResize() {
/* 1550 */       return this.inResize;
/*      */     }
/*      */     
/*      */     void startResize(int param1Int1, int param1Int2) {
/* 1554 */       this.inResize = true;
/*      */       
/* 1556 */       this.startMouseX = param1Int1;
/* 1557 */       this.startMouseY = param1Int2;
/*      */       
/* 1559 */       this.startWidth = Window.this.getWidth();
/* 1560 */       this.startHeight = Window.this.getHeight();
/*      */     }
/*      */     
/*      */     void deltaResize(int param1Int1, int param1Int2) {
/* 1564 */       int i = param1Int1 - this.startMouseX;
/* 1565 */       int j = param1Int2 - this.startMouseY;
/*      */       
/* 1567 */       Window.this.setSize(this.startWidth + i, this.startHeight + j);
/*      */     }
/*      */     
/*      */     protected void stopResize() {
/* 1571 */       this.inResize = false;
/*      */     }
/*      */     
/*      */     void updateRectangles() {
/* 1575 */       if (this.moveRect.size > 0) {
/* 1576 */         setMoveRectangle(this.moveRect.size);
/*      */       }
/* 1578 */       if (this.resizeRect.size > 0)
/* 1579 */         setResizeRectangle(this.resizeRect.size); 
/*      */     }
/*      */     
/*      */     boolean handleMouseEvent(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/*      */       boolean bool;
/* 1584 */       switch (param1Int1) {
/*      */         case 221:
/* 1586 */           if (param1Int2 == 212) {
/* 1587 */             if (Window.this.shouldStartUndecoratedMove(param1Int3, param1Int4) == true) {
/* 1588 */               startMove(param1Int5, param1Int6);
/* 1589 */               return true;
/* 1590 */             }  if (Window.this.shouldStartUndecoratedResize(param1Int3, param1Int4) == true) {
/* 1591 */               startResize(param1Int5, param1Int6);
/* 1592 */               return true;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 223:
/*      */         case 224:
/* 1599 */           if (inMove() == true) {
/* 1600 */             deltaMove(param1Int5, param1Int6);
/* 1601 */             return true;
/* 1602 */           }  if (inResize() == true) {
/* 1603 */             deltaResize(param1Int5, param1Int6);
/* 1604 */             return true;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 222:
/* 1609 */           bool = (inMove() || inResize()) ? true : false;
/* 1610 */           stopResize();
/* 1611 */           stopMove();
/* 1612 */           return bool;
/*      */       } 
/* 1614 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void requestInput(String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14) {
/* 1634 */     Application.checkEventThread();
/* 1635 */     _requestInput(this.ptr, paramString, paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12, paramDouble13, paramDouble14);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseInput() {
/* 1646 */     Application.checkEventThread();
/* 1647 */     _releaseInput(this.ptr);
/*      */   }
/*      */   
/*      */   protected abstract long _createWindow(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   protected abstract long _createChildWindow(long paramLong);
/*      */   
/*      */   protected abstract boolean _close(long paramLong);
/*      */   
/*      */   protected abstract boolean _setView(long paramLong, View paramView);
/*      */   
/*      */   protected abstract boolean _setMenubar(long paramLong1, long paramLong2);
/*      */   
/*      */   protected abstract boolean _minimize(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2);
/*      */   
/*      */   protected abstract int _getEmbeddedX(long paramLong);
/*      */   
/*      */   protected abstract int _getEmbeddedY(long paramLong);
/*      */   
/*      */   protected abstract void _setBounds(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2);
/*      */   
/*      */   protected abstract boolean _setVisible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract boolean _setResizable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract boolean _requestFocus(long paramLong, int paramInt);
/*      */   
/*      */   protected abstract void _setFocusable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract boolean _grabFocus(long paramLong);
/*      */   
/*      */   protected abstract void _ungrabFocus(long paramLong);
/*      */   
/*      */   protected abstract boolean _setTitle(long paramLong, String paramString);
/*      */   
/*      */   protected abstract void _setLevel(long paramLong, int paramInt);
/*      */   
/*      */   protected abstract void _setAlpha(long paramLong, float paramFloat);
/*      */   
/*      */   protected abstract boolean _setBackground(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
/*      */   
/*      */   protected abstract void _setEnabled(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   protected abstract void _setIcon(long paramLong, Pixels paramPixels);
/*      */   
/*      */   protected abstract void _setCursor(long paramLong, Cursor paramCursor);
/*      */   
/*      */   protected abstract void _toFront(long paramLong);
/*      */   
/*      */   protected abstract void _toBack(long paramLong);
/*      */   
/*      */   protected abstract void _enterModal(long paramLong);
/*      */   
/*      */   protected abstract void _enterModalWithWindow(long paramLong1, long paramLong2);
/*      */   
/*      */   protected abstract void _exitModal(long paramLong);
/*      */   
/*      */   protected abstract void _requestInput(long paramLong, String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14);
/*      */   
/*      */   protected abstract void _releaseInput(long paramLong);
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Window.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */