/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WCGlyphBuffer
/*    */ {
/*    */   public int[] glyphs;
/*    */   public float[] advances;
/*    */   public float initialAdvance;
/*    */   
/*    */   public WCGlyphBuffer(int[] paramArrayOfint, float[] paramArrayOffloat, float paramFloat) {
/* 34 */     this.glyphs = paramArrayOfint;
/* 35 */     this.advances = paramArrayOffloat;
/* 36 */     this.initialAdvance = paramFloat;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCGlyphBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */