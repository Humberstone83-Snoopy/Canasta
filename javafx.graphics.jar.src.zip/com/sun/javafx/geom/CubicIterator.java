/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CubicIterator
/*     */   implements PathIterator
/*     */ {
/*     */   CubicCurve2D cubic;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   
/*     */   CubicIterator(CubicCurve2D paramCubicCurve2D, BaseTransform paramBaseTransform) {
/*  44 */     this.cubic = paramCubicCurve2D;
/*  45 */     this.transform = paramBaseTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  55 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/*  63 */     return (this.index > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/*  72 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/*     */     byte b;
/*  94 */     if (isDone()) {
/*  95 */       throw new NoSuchElementException("cubic iterator iterator out of bounds");
/*     */     }
/*     */     
/*  98 */     if (this.index == 0) {
/*  99 */       paramArrayOffloat[0] = this.cubic.x1;
/* 100 */       paramArrayOffloat[1] = this.cubic.y1;
/* 101 */       b = 0;
/*     */     } else {
/* 103 */       paramArrayOffloat[0] = this.cubic.ctrlx1;
/* 104 */       paramArrayOffloat[1] = this.cubic.ctrly1;
/* 105 */       paramArrayOffloat[2] = this.cubic.ctrlx2;
/* 106 */       paramArrayOffloat[3] = this.cubic.ctrly2;
/* 107 */       paramArrayOffloat[4] = this.cubic.x2;
/* 108 */       paramArrayOffloat[5] = this.cubic.y2;
/* 109 */       b = 3;
/*     */     } 
/* 111 */     if (this.transform != null) {
/* 112 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, (this.index == 0) ? 1 : 3);
/*     */     }
/* 114 */     return b;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\CubicIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */