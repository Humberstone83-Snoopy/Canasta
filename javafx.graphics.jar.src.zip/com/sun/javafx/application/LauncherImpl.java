/*     */ package com.sun.javafx.application;
/*     */ 
/*     */ import com.sun.javafx.stage.StageHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.text.Normalizer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Base64;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import javafx.application.Application;
/*     */ import javafx.application.Preloader;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LauncherImpl
/*     */ {
/*     */   public static final String LAUNCH_MODE_CLASS = "LM_CLASS";
/*     */   public static final String LAUNCH_MODE_JAR = "LM_JAR";
/*     */   public static final String LAUNCH_MODE_MODULE = "LM_MODULE";
/*     */   private static final boolean trace = false;
/*     */   private static final boolean verbose;
/*     */   private static final String MF_MAIN_CLASS = "Main-Class";
/*     */   private static final String MF_JAVAFX_MAIN = "JavaFX-Application-Class";
/*     */   private static final String MF_JAVAFX_PRELOADER = "JavaFX-Preloader-Class";
/*     */   private static final String MF_JAVAFX_CLASS_PATH = "JavaFX-Class-Path";
/*     */   private static final String MF_JAVAFX_ARGUMENT_PREFIX = "JavaFX-Argument-";
/*     */   private static final String MF_JAVAFX_PARAMETER_NAME_PREFIX = "JavaFX-Parameter-Name-";
/*     */   private static final String MF_JAVAFX_PARAMETER_VALUE_PREFIX = "JavaFX-Parameter-Value-";
/*     */   private static final boolean simulateSlowProgress = false;
/*  98 */   private static AtomicBoolean launchCalled = new AtomicBoolean(false);
/*     */ 
/*     */   
/* 101 */   private static final AtomicBoolean toolkitStarted = new AtomicBoolean(false);
/*     */ 
/*     */   
/* 104 */   private static volatile RuntimeException launchException = null;
/*     */ 
/*     */ 
/*     */   
/* 108 */   private static Preloader currentPreloader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static Class<? extends Preloader> savedPreloaderClass = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static ClassLoader savedMainCcl = null;
/*     */   private static volatile boolean error;
/*     */   private static volatile Throwable pConstructorError;
/* 121 */   private static volatile Throwable pInitError; private static volatile Throwable pStartError; private static volatile Throwable pStopError; private static volatile Throwable constructorError; private static volatile Throwable initError; private static volatile Throwable startError; private static volatile Throwable stopError; public static void launchApplication(Class<? extends Application> paramClass, String[] paramArrayOfString) { Class<? extends Preloader> clazz = savedPreloaderClass; if (clazz == null) { String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.preloader")); if (str != null) try { clazz = (Class)Class.forName(str, false, paramClass.getClassLoader()); } catch (Exception exception) { System.err.printf("Could not load preloader class '" + str + "', continuing without preloader.", new Object[0]); exception.printStackTrace(); }   }  launchApplication(paramClass, clazz, paramArrayOfString); } public static void launchApplication(Class<? extends Application> paramClass, Class<? extends Preloader> paramClass1, String[] paramArrayOfString) { if (launchCalled.getAndSet(true)) throw new IllegalStateException("Application launch must not be called more than once");  if (!Application.class.isAssignableFrom(paramClass)) throw new IllegalArgumentException("Error: " + paramClass.getName() + " is not a subclass of javafx.application.Application");  if (paramClass1 != null && !Preloader.class.isAssignableFrom(paramClass1)) throw new IllegalArgumentException("Error: " + paramClass1.getName() + " is not a subclass of javafx.application.Preloader");  CountDownLatch countDownLatch = new CountDownLatch(1); Thread thread = new Thread(() -> { try { launchApplication1(paramClass1, paramClass2, paramArrayOfString); } catch (RuntimeException runtimeException) { launchException = runtimeException; } catch (Exception exception) { launchException = new RuntimeException("Application launch exception", exception); } catch (Error error) { launchException = new RuntimeException("Application launch error", error); } finally { paramCountDownLatch.countDown(); }  }); thread.setName("JavaFX-Launcher"); thread.start(); try { countDownLatch.await(); } catch (InterruptedException interruptedException) { throw new RuntimeException("Unexpected exception: ", interruptedException); }  if (launchException != null) throw launchException;  } public static void launchApplication(String paramString1, String paramString2, String[] paramArrayOfString) { if (verbose) System.err.println("JavaFX launchApplication method: launchMode=" + paramString2);  String str1 = null; String str2 = null; String[] arrayOfString = paramArrayOfString; ClassLoader classLoader = null; ModuleAccess moduleAccess = null; if (paramString2.equals("LM_JAR")) { Attributes attributes = getJarAttributes(paramString1); if (attributes == null) abort(null, "Can't get manifest attributes from jar", new Object[0]);  String str = attributes.getValue("JavaFX-Class-Path"); if (str != null) if (str.trim().length() == 0) { str = null; } else { if (verbose) System.err.println("WARNING: Application jar uses deprecated JavaFX-Class-Path attribute. Please use Class-Path instead.");  classLoader = setupJavaFXClassLoader(new File(paramString1), str); }   if (paramArrayOfString.length == 0) arrayOfString = getAppArguments(attributes);  str1 = attributes.getValue("JavaFX-Application-Class"); if (str1 == null) { str1 = attributes.getValue("Main-Class"); if (str1 == null) abort(null, "JavaFX jar manifest requires a valid JavaFX-Appliation-Class or Main-Class entry", new Object[0]);  }  str1 = str1.trim(); str2 = attributes.getValue("JavaFX-Preloader-Class"); if (str2 != null) str2 = str2.trim();  } else if (paramString2.equals("LM_CLASS")) { str1 = paramString1; } else if (paramString2.equals("LM_MODULE")) { String str; int i = paramString1.indexOf('/'); if (i == -1) { str = paramString1; str1 = null; } else { str = paramString1.substring(0, i); str1 = paramString1.substring(i + 1); }  moduleAccess = ModuleAccess.load(str); if (str1 == null) { Optional<String> optional = moduleAccess.getDescriptor().mainClass(); if (!optional.isPresent()) abort(null, "Module %1$s does not have a MainClass attribute, use -m <module>/<main-class>", new Object[] { str });  str1 = optional.get(); }  } else { abort(new IllegalArgumentException("The launchMode argument must be one of LM_CLASS, LM_JAR or LM_MODULE"), "Invalid launch mode: %1$s", new Object[] { paramString2 }); }  if (str2 == null) str2 = System.getProperty("javafx.preloader");  if (str1 == null) abort(null, "No main JavaFX class to launch", new Object[0]);  if (classLoader != null) { try { Class<?> clazz = classLoader.loadClass(LauncherImpl.class.getName()); Method method = clazz.getMethod("launchApplicationWithArgs", new Class[] { ModuleAccess.class, String.class, String.class, (new String[0]).getClass() }); Thread.currentThread().setContextClassLoader(classLoader); method.invoke(null, new Object[] { null, str1, str2, arrayOfString }); } catch (Exception exception) { abort(exception, "Exception while launching application", new Object[0]); }  } else { launchApplicationWithArgs(moduleAccess, str1, str2, arrayOfString); }  } static { verbose = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.verbose")))).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 664 */     error = false;
/* 665 */     pConstructorError = null;
/* 666 */     pInitError = null;
/* 667 */     pStartError = null;
/* 668 */     pStopError = null;
/* 669 */     constructorError = null;
/* 670 */     initError = null;
/* 671 */     startError = null;
/* 672 */     stopError = null; }
/*     */   private static Class<?> loadClass(ModuleAccess paramModuleAccess, String paramString) { Class<?> clazz = null; ClassLoader classLoader = Thread.currentThread().getContextClassLoader(); if (paramModuleAccess != null) { clazz = paramModuleAccess.classForName(paramString); } else { try { clazz = Class.forName(paramString, true, classLoader); } catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {} }  if (clazz == null && System.getProperty("os.name", "").contains("OS X") && Normalizer.isNormalized(paramString, Normalizer.Form.NFD)) { String str = Normalizer.normalize(paramString, Normalizer.Form.NFC); if (paramModuleAccess != null) { clazz = paramModuleAccess.classForName(str); } else { try { clazz = Class.forName(str, true, classLoader); } catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {} }  }  return clazz; }
/*     */   public static void launchApplicationWithArgs(ModuleAccess paramModuleAccess, String paramString1, String paramString2, String[] paramArrayOfString) { try { startToolkit(); } catch (InterruptedException interruptedException) { abort(interruptedException, "Toolkit initialization error", new Object[] { paramString1 }); }  Class<? extends Preloader> clazz1 = null; Class<?> clazz2 = null; AtomicReference<Class<?>> atomicReference1 = new AtomicReference(); AtomicReference<Class<?>> atomicReference2 = new AtomicReference(); PlatformImpl.runAndWait(() -> { Class<?> clazz = loadClass(paramModuleAccess, paramString1); if (clazz == null) if (paramModuleAccess != null) { abort(null, "Missing JavaFX application class %1$s in module %2$s", new Object[] { paramString1, paramModuleAccess.getName() }); } else { abort(null, "Missing JavaFX application class %1$s", new Object[] { paramString1 }); }   paramAtomicReference1.set(clazz); if (paramString2 != null) { clazz = loadClass(null, paramString2); if (clazz == null) abort(null, "Missing JavaFX preloader class %1$s", new Object[] { paramString2 });  if (!Preloader.class.isAssignableFrom(clazz)) abort(null, "JavaFX preloader class %1$s does not extend javafx.application.Preloader", new Object[] { clazz.getName() });  paramAtomicReference2.set(clazz.asSubclass(Preloader.class)); }  }); clazz1 = (Class)atomicReference2.get(); clazz2 = atomicReference1.get(); savedPreloaderClass = clazz1; NoSuchMethodException noSuchMethodException = null; try { Method method = clazz2.getMethod("main", new Class[] { (new String[0]).getClass() }); if (verbose) System.err.println("Calling main(String[]) method");  savedMainCcl = Thread.currentThread().getContextClassLoader(); method.invoke(null, new Object[] { paramArrayOfString }); return; } catch (NoSuchMethodException|IllegalAccessException noSuchMethodException1) { noSuchMethodException = noSuchMethodException1; savedPreloaderClass = null; if (verbose)
/*     */         System.err.println("WARNING: Cannot access application main method: " + noSuchMethodException1);  } catch (InvocationTargetException invocationTargetException) { invocationTargetException.printStackTrace(); abort(null, "Exception running application %1$s", new Object[] { clazz2.getName() }); return; }  if (!Application.class.isAssignableFrom(clazz2))
/*     */       abort(noSuchMethodException, "JavaFX application class %1$s does not extend javafx.application.Application", new Object[] { clazz2.getName() });  Class<? extends Application> clazz = clazz2.asSubclass(Application.class); if (verbose)
/*     */       System.err.println("Launching application directly");  launchApplication(clazz, clazz1, paramArrayOfString); }
/* 678 */   private static URL fileToURL(File paramFile) throws IOException { return paramFile.getCanonicalFile().toURI().toURL(); } private static void launchApplication1(Class<? extends Application> paramClass, Class<? extends Preloader> paramClass1, String[] paramArrayOfString) throws Exception { startToolkit();
/*     */     
/* 680 */     if (savedMainCcl != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 688 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 689 */       if (classLoader != null && classLoader != savedMainCcl) {
/* 690 */         PlatformImpl.runLater(() -> Thread.currentThread().setContextClassLoader(paramClassLoader));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 696 */     final AtomicBoolean pStartCalled = new AtomicBoolean(false);
/* 697 */     final AtomicBoolean startCalled = new AtomicBoolean(false);
/* 698 */     final AtomicBoolean exitCalled = new AtomicBoolean(false);
/* 699 */     AtomicBoolean atomicBoolean4 = new AtomicBoolean(false);
/* 700 */     final CountDownLatch shutdownLatch = new CountDownLatch(1);
/* 701 */     final CountDownLatch pShutdownLatch = new CountDownLatch(1);
/*     */     
/* 703 */     PlatformImpl.FinishListener finishListener = new PlatformImpl.FinishListener() {
/*     */         public void idle(boolean param1Boolean) {
/* 705 */           if (!param1Boolean) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/* 710 */           if (startCalled.get()) {
/* 711 */             shutdownLatch.countDown();
/* 712 */           } else if (pStartCalled.get()) {
/* 713 */             pShutdownLatch.countDown();
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void exitCalled() {
/* 719 */           exitCalled.set(true);
/* 720 */           shutdownLatch.countDown();
/*     */         }
/*     */       };
/* 723 */     PlatformImpl.addListener(finishListener);
/*     */ 
/*     */     
/* 726 */     try { AtomicReference<Preloader> atomicReference = new AtomicReference();
/* 727 */       if (paramClass1 != null)
/*     */       {
/*     */ 
/*     */         
/* 731 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 Constructor<Preloader> constructor = paramClass.getConstructor(new Class[0]);
/*     */                 
/*     */                 paramAtomicReference.set(constructor.newInstance(new Object[0]));
/*     */                 ParametersImpl.registerParameters(paramAtomicReference.get(), new ParametersImpl(paramArrayOfString));
/* 737 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Preloader constructor");
/*     */                 pConstructorError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       }
/* 744 */       currentPreloader = atomicReference.get();
/*     */ 
/*     */       
/* 747 */       if (currentPreloader != null && !error && !atomicBoolean3.get()) {
/*     */         
/*     */         try {
/* 750 */           currentPreloader.init();
/* 751 */         } catch (Throwable throwable) {
/* 752 */           System.err.println("Exception in Preloader init method");
/* 753 */           pInitError = throwable;
/* 754 */           error = true;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 759 */       if (currentPreloader != null && !error && !atomicBoolean3.get()) {
/*     */         
/* 761 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramAtomicBoolean.set(true);
/*     */                 
/*     */                 Stage stage = new Stage();
/*     */                 
/*     */                 StageHelper.setPrimary(stage, true);
/*     */                 currentPreloader.start(stage);
/* 769 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Preloader start method");
/*     */                 
/*     */                 pStartError = throwable;
/*     */                 
/*     */                 error = true;
/*     */               } 
/*     */             });
/* 777 */         if (!error && !atomicBoolean3.get()) {
/* 778 */           notifyProgress(currentPreloader, 0.0D);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 785 */       AtomicReference<Application> atomicReference1 = new AtomicReference();
/* 786 */       if (!error && !atomicBoolean3.get()) {
/* 787 */         if (currentPreloader != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 794 */           notifyProgress(currentPreloader, 1.0D);
/* 795 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_LOAD, null);
/*     */         } 
/*     */ 
/*     */         
/* 799 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 Constructor<Application> constructor = paramClass.getConstructor(new Class[0]);
/*     */                 
/*     */                 paramAtomicReference.set(constructor.newInstance(new Object[0]));
/*     */                 ParametersImpl.registerParameters(paramAtomicReference.get(), new ParametersImpl(paramArrayOfString));
/*     */                 PlatformImpl.setApplicationName(paramClass);
/* 806 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application constructor");
/*     */                 constructorError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       } 
/* 813 */       Application application = atomicReference1.get();
/*     */ 
/*     */       
/* 816 */       if (!error && !atomicBoolean3.get()) {
/* 817 */         if (currentPreloader != null) {
/* 818 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_INIT, application);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 824 */           application.init();
/* 825 */         } catch (Throwable throwable) {
/* 826 */           System.err.println("Exception in Application init method");
/* 827 */           initError = throwable;
/* 828 */           error = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 833 */       if (!error && !atomicBoolean3.get()) {
/* 834 */         if (currentPreloader != null) {
/* 835 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_START, application);
/*     */         }
/*     */ 
/*     */         
/* 839 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramAtomicBoolean.set(true);
/*     */                 
/*     */                 Stage stage = new Stage();
/*     */                 
/*     */                 StageHelper.setPrimary(stage, true);
/*     */                 paramApplication.start(stage);
/* 847 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application start method");
/*     */                 
/*     */                 startError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       } 
/* 855 */       if (!error) {
/* 856 */         countDownLatch1.await();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 861 */       if (atomicBoolean2.get())
/*     */       {
/* 863 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramApplication.stop();
/* 866 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application stop method");
/*     */                 
/*     */                 stopError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       }
/* 874 */       if (error) {
/* 875 */         if (pConstructorError != null) {
/* 876 */           throw new RuntimeException("Unable to construct Preloader instance: " + paramClass, pConstructorError);
/*     */         }
/* 878 */         if (pInitError != null) {
/* 879 */           throw new RuntimeException("Exception in Preloader init method", pInitError);
/*     */         }
/* 881 */         if (pStartError != null) {
/* 882 */           throw new RuntimeException("Exception in Preloader start method", pStartError);
/*     */         }
/* 884 */         if (pStopError != null) {
/* 885 */           throw new RuntimeException("Exception in Preloader stop method", pStopError);
/*     */         }
/* 887 */         if (constructorError != null) {
/* 888 */           String str = "Unable to construct Application instance: " + paramClass;
/* 889 */           if (!notifyError(str, constructorError)) {
/* 890 */             throw new RuntimeException(str, constructorError);
/*     */           }
/* 892 */         } else if (initError != null) {
/* 893 */           String str = "Exception in Application init method";
/* 894 */           if (!notifyError(str, initError)) {
/* 895 */             throw new RuntimeException(str, initError);
/*     */           }
/* 897 */         } else if (startError != null) {
/* 898 */           String str = "Exception in Application start method";
/* 899 */           if (!notifyError(str, startError)) {
/* 900 */             throw new RuntimeException(str, startError);
/*     */           }
/* 902 */         } else if (stopError != null) {
/* 903 */           String str = "Exception in Application stop method";
/* 904 */           if (!notifyError(str, stopError)) {
/* 905 */             throw new RuntimeException(str, stopError);
/*     */           }
/*     */         } 
/*     */       }  }
/*     */     finally
/* 910 */     { PlatformImpl.removeListener(finishListener);
/* 911 */       PlatformImpl.tkExit(); }  } private static ClassLoader setupJavaFXClassLoader(File paramFile, String paramString) { try { File file = paramFile.getParentFile(); ArrayList<URL> arrayList = new ArrayList(); String str = paramString; if (str != null) while (str.length() > 0) { int i = str.indexOf(" "); if (i < 0) { String str1 = str; File file1 = (file == null) ? new File(str1) : new File(file, str1); if (file1.exists()) { arrayList.add(fileToURL(file1)); break; }  if (verbose) System.err.println("Class Path entry \"" + str1 + "\" does not exist, ignoring");  break; }  if (i > 0) { String str1 = str.substring(0, i); File file1 = (file == null) ? new File(str1) : new File(file, str1); if (file1.exists()) { arrayList.add(fileToURL(file1)); } else if (verbose) { System.err.println("Class Path entry \"" + str1 + "\" does not exist, ignoring"); }  }  str = str.substring(i + 1); }   if (!arrayList.isEmpty()) { ArrayList<URL> arrayList1 = new ArrayList(); str = System.getProperty("java.class.path"); if (str != null) while (str.length() > 0) { int i = str.indexOf(File.pathSeparatorChar); if (i < 0) { String str1 = str; arrayList1.add(fileToURL(new File(str1))); break; }  if (i > 0) { String str1 = str.substring(0, i); arrayList1.add(fileToURL(new File(str1))); }  str = str.substring(i + 1); }   arrayList1.addAll(arrayList); URL[] arrayOfURL = arrayList1.<URL>toArray(new URL[0]); if (verbose) { System.err.println("===== URL list"); for (byte b = 0; b < arrayOfURL.length; b++) System.err.println("" + arrayOfURL[b]);  System.err.println("====="); }  return new URLClassLoader(arrayOfURL, ClassLoader.getPlatformClassLoader()); }  } catch (Exception exception) {} return null; }
/*     */   private static String decodeBase64(String paramString) throws IOException { return new String(Base64.getDecoder().decode(paramString)); }
/*     */   private static String[] getAppArguments(Attributes paramAttributes) { LinkedList<String> linkedList = new LinkedList(); try { byte b = 1; String str1 = "JavaFX-Argument-"; while (paramAttributes.getValue(str1 + str1) != null) { linkedList.add(decodeBase64(paramAttributes.getValue(str1 + str1))); b++; }  String str2 = "JavaFX-Parameter-Name-"; String str3 = "JavaFX-Parameter-Value-"; b = 1; while (paramAttributes.getValue(str2 + str2) != null) { String str4 = decodeBase64(paramAttributes.getValue(str2 + str2)); String str5 = null; if (paramAttributes.getValue(str3 + str3) != null) str5 = decodeBase64(paramAttributes.getValue(str3 + str3));  linkedList.add("--" + str4 + "=" + ((str5 != null) ? str5 : "")); b++; }  } catch (IOException iOException) { if (verbose) System.err.println("Failed to extract application parameters");  iOException.printStackTrace(); }  return linkedList.<String>toArray(new String[0]); }
/*     */   private static void abort(Throwable paramThrowable, String paramString, Object... paramVarArgs) { String str = String.format(paramString, paramVarArgs); if (str != null) System.err.println(str);  System.exit(1); }
/*     */   private static Attributes getJarAttributes(String paramString) { JarFile jarFile = null; try { jarFile = new JarFile(paramString); Manifest manifest = jarFile.getManifest(); if (manifest == null)
/*     */         abort(null, "No manifest in jar file %1$s", new Object[] { paramString });  return manifest.getMainAttributes(); } catch (IOException iOException) { abort(iOException, "Error launching jar file %1%s", new Object[] { paramString }); } finally { try { jarFile.close(); } catch (IOException iOException) {} }  return null; }
/*     */   private static void startToolkit() throws InterruptedException { if (toolkitStarted.getAndSet(true))
/*     */       return;  CountDownLatch countDownLatch = new CountDownLatch(1); PlatformImpl.startup(() -> paramCountDownLatch.countDown()); countDownLatch.await(); }
/* 919 */   private static void notifyStateChange(Preloader paramPreloader, Preloader.StateChangeNotification.Type paramType, Application paramApplication) { PlatformImpl.runAndWait(() -> paramPreloader.handleStateChangeNotification(new Preloader.StateChangeNotification(paramType, paramApplication))); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notifyProgress(Preloader paramPreloader, double paramDouble) {
/* 924 */     PlatformImpl.runAndWait(() -> paramPreloader.handleProgressNotification(new Preloader.ProgressNotification(paramDouble)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean notifyError(String paramString, Throwable paramThrowable) {
/* 929 */     AtomicBoolean atomicBoolean = new AtomicBoolean(false);
/* 930 */     PlatformImpl.runAndWait(() -> {
/*     */           if (currentPreloader != null) {
/*     */             try {
/*     */               Preloader.ErrorNotification errorNotification = new Preloader.ErrorNotification(null, paramString, paramThrowable);
/*     */               boolean bool = currentPreloader.handleErrorNotification(errorNotification);
/*     */               paramAtomicBoolean.set(bool);
/* 936 */             } catch (Throwable throwable) {
/*     */               throwable.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 942 */     return atomicBoolean.get();
/*     */   }
/*     */   
/*     */   private static void notifyCurrentPreloader(Preloader.PreloaderNotification paramPreloaderNotification) {
/* 946 */     PlatformImpl.runAndWait(() -> {
/*     */           if (currentPreloader != null) {
/*     */             currentPreloader.handleApplicationNotification(paramPreloaderNotification);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static void notifyPreloader(Application paramApplication, Preloader.PreloaderNotification paramPreloaderNotification) {
/* 954 */     if (launchCalled.get()) {
/*     */       
/* 956 */       notifyCurrentPreloader(paramPreloaderNotification);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private LauncherImpl() {
/* 964 */     throw new InternalError();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\application\LauncherImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */