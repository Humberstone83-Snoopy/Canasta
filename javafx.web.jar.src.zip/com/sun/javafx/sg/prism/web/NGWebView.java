/*     */ package com.sun.javafx.sg.prism.web;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.sg.prism.NGGroup;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NGWebView
/*     */   extends NGGroup
/*     */ {
/*  48 */   private static final PlatformLogger log = PlatformLogger.getLogger(NGWebView.class.getName());
/*     */   
/*     */   private volatile WebPage page;
/*     */   
/*     */   public void setPage(WebPage paramWebPage) {
/*  53 */     this.page = paramWebPage;
/*     */   }
/*     */   private volatile float width; private volatile float height;
/*     */   public void resize(float paramFloat1, float paramFloat2) {
/*  57 */     if (this.width != paramFloat1 || this.height != paramFloat2) {
/*  58 */       this.width = paramFloat1;
/*  59 */       this.height = paramFloat2;
/*  60 */       geometryChanged();
/*  61 */       if (this.page != null) {
/*  62 */         this.page.setBounds(0, 0, (int)paramFloat1, (int)paramFloat2);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/*  69 */     if (this.page != null) {
/*  70 */       BaseBounds baseBounds = getClippedBounds(new RectBounds(), BaseTransform.IDENTITY_TRANSFORM);
/*  71 */       if (!baseBounds.isEmpty()) {
/*  72 */         log.finest("updating rectangle: {0}", new Object[] { baseBounds });
/*  73 */         this.page.updateContent(new WCRectangle(baseBounds.getMinX(), baseBounds.getMinY(), baseBounds
/*  74 */               .getWidth(), baseBounds.getHeight()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void requestRender() {
/*  80 */     visualsChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/*  85 */     log.finest("rendering into {0}", new Object[] { paramGraphics });
/*  86 */     if (paramGraphics == null || this.page == null || this.width <= 0.0F || this.height <= 0.0F) {
/*     */       return;
/*     */     }
/*     */     
/*  90 */     WCGraphicsContext wCGraphicsContext = WCGraphicsManager.getGraphicsManager().createGraphicsContext(paramGraphics);
/*     */     try {
/*  92 */       if (paramGraphics instanceof com.sun.prism.PrinterGraphics) {
/*  93 */         this.page.print(wCGraphicsContext, 0, 0, (int)this.width, (int)this.height);
/*     */       } else {
/*  95 */         this.page.paint(wCGraphicsContext, 0, 0, (int)this.width, (int)this.height);
/*     */       } 
/*  97 */       wCGraphicsContext.flush();
/*     */     } finally {
/*  99 */       wCGraphicsContext.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasOverlappingContents() {
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean hasVisuals() {
/* 109 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\sg\prism\web\NGWebView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */