/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.GestureSupport;
/*     */ import com.sun.glass.ui.TouchInputSupport;
/*     */ import com.sun.glass.ui.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacGestureSupport
/*     */ {
/*     */   private static final int GESTURE_ROTATE = 100;
/*     */   private static final int GESTURE_MAGNIFY = 101;
/*     */   private static final int GESTURE_SWIPE = 102;
/*     */   private static final int SCROLL_SRC_WHEEL = 50;
/*     */   private static final int SCROLL_SRC_GESTURE = 51;
/*     */   private static final int SCROLL_SRC_INERTIA = 52;
/*     */   private static final double multiplier = 10.0D;
/*     */   private static final boolean isDirect = false;
/*     */   
/*     */   static {
/*  38 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final GestureSupport gestures = new GestureSupport(false);
/*  57 */   private static final TouchInputSupport touches = new MacTouchInputSupport(gestures
/*  58 */       .createTouchCountListener(), false);
/*     */ 
/*     */   
/*     */   public static void notifyBeginTouchEvent(View paramView, int paramInt1, int paramInt2) {
/*  62 */     touches.notifyBeginTouchEvent(paramView, paramInt1, false, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notifyNextTouchEvent(View paramView, int paramInt, long paramLong, float paramFloat1, float paramFloat2) {
/*  75 */     int i = (int)(10000.0F * paramFloat1);
/*  76 */     int j = 10000 - (int)(10000.0F * paramFloat2);
/*  77 */     touches.notifyNextTouchEvent(paramView, paramInt, paramLong, i, j, i, j);
/*     */   }
/*     */   
/*     */   public static void notifyEndTouchEvent(View paramView) {
/*  81 */     touches.notifyEndTouchEvent(paramView);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rotateGesturePerformed(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat) {
/*  87 */     gestures.handleDeltaRotation(paramView, paramInt1, false, false, paramInt2, paramInt3, paramInt4, paramInt5, -paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scrollGesturePerformed(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2) {
/*  95 */     int i = touches.getTouchCount();
/*  96 */     boolean bool = (paramInt2 == 52) ? true : false;
/*  97 */     switch (paramInt2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 50:
/*     */       case 52:
/* 110 */         GestureSupport.handleScrollingPerformed(paramView, paramInt1, false, bool, i, paramInt3, paramInt4, paramInt5, paramInt6, paramFloat1, paramFloat2, 10.0D, 10.0D);
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 51:
/* 116 */         gestures.handleDeltaScrolling(paramView, paramInt1, false, bool, i, paramInt3, paramInt4, paramInt5, paramInt6, paramFloat1, paramFloat2, 10.0D, 10.0D);
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 121 */     System.err.println("Unknown scroll gesture sender: " + paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void swipeGesturePerformed(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 131 */     GestureSupport.handleSwipePerformed(paramView, paramInt1, false, false, touches
/* 132 */         .getTouchCount(), paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void magnifyGesturePerformed(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, float paramFloat) {
/* 138 */     gestures.handleDeltaZooming(paramView, paramInt1, false, false, paramInt2, paramInt3, paramInt4, paramInt5, paramFloat, Double.NaN);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void gestureFinished(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 144 */     if (gestures.isScrolling()) {
/* 145 */       gestures.handleScrollingEnd(paramView, paramInt1, touches.getTouchCount(), false, false, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     }
/*     */ 
/*     */     
/* 149 */     if (gestures.isRotating()) {
/* 150 */       gestures.handleRotationEnd(paramView, paramInt1, false, false, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     }
/*     */ 
/*     */     
/* 154 */     if (gestures.isZooming())
/* 155 */       gestures.handleZoomingEnd(paramView, paramInt1, false, false, paramInt2, paramInt3, paramInt4, paramInt5); 
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacGestureSupport.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */