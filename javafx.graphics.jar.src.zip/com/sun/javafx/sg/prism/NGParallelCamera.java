/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGParallelCamera
/*    */   extends NGCamera
/*    */ {
/*    */   public PickRay computePickRay(float paramFloat1, float paramFloat2, PickRay paramPickRay) {
/* 39 */     return PickRay.computeParallelPickRay(paramFloat1, paramFloat2, this.viewHeight, this.worldTransform, this.zNear, this.zFar, paramPickRay);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGParallelCamera.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */