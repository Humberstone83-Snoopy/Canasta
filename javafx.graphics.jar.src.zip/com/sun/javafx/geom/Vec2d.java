/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vec2d
/*     */ {
/*     */   public double x;
/*     */   public double y;
/*     */   
/*     */   public Vec2d() {}
/*     */   
/*     */   public Vec2d(double paramDouble1, double paramDouble2) {
/*  46 */     this.x = paramDouble1;
/*  47 */     this.y = paramDouble2;
/*     */   }
/*     */   
/*     */   public Vec2d(Vec2d paramVec2d) {
/*  51 */     set(paramVec2d);
/*     */   }
/*     */   
/*     */   public Vec2d(Vec2f paramVec2f) {
/*  55 */     set(paramVec2f);
/*     */   }
/*     */   
/*     */   public void set(Vec2d paramVec2d) {
/*  59 */     this.x = paramVec2d.x;
/*  60 */     this.y = paramVec2d.y;
/*     */   }
/*     */   
/*     */   public void set(Vec2f paramVec2f) {
/*  64 */     this.x = paramVec2f.x;
/*  65 */     this.y = paramVec2f.y;
/*     */   }
/*     */   
/*     */   public void set(double paramDouble1, double paramDouble2) {
/*  69 */     this.x = paramDouble1;
/*  70 */     this.y = paramDouble2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double distanceSq(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  84 */     paramDouble1 -= paramDouble3;
/*  85 */     paramDouble2 -= paramDouble4;
/*  86 */     return paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double distance(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 100 */     paramDouble1 -= paramDouble3;
/* 101 */     paramDouble2 -= paramDouble4;
/* 102 */     return Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distanceSq(double paramDouble1, double paramDouble2) {
/* 117 */     paramDouble1 -= this.x;
/* 118 */     paramDouble2 -= this.y;
/* 119 */     return paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distanceSq(Vec2d paramVec2d) {
/* 132 */     double d1 = paramVec2d.x - this.x;
/* 133 */     double d2 = paramVec2d.y - this.y;
/* 134 */     return d1 * d1 + d2 * d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distance(double paramDouble1, double paramDouble2) {
/* 149 */     paramDouble1 -= this.x;
/* 150 */     paramDouble2 -= this.y;
/* 151 */     return Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double distance(Vec2d paramVec2d) {
/* 164 */     double d1 = paramVec2d.x - this.x;
/* 165 */     double d2 = paramVec2d.y - this.y;
/* 166 */     return Math.sqrt(d1 * d1 + d2 * d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 175 */     long l = 7L;
/* 176 */     l = 31L * l + Double.doubleToLongBits(this.x);
/* 177 */     l = 31L * l + Double.doubleToLongBits(this.y);
/* 178 */     return (int)(l ^ l >> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 193 */     if (paramObject == this) {
/* 194 */       return true;
/*     */     }
/* 196 */     if (paramObject instanceof Vec2d) {
/* 197 */       Vec2d vec2d = (Vec2d)paramObject;
/* 198 */       return (this.x == vec2d.x && this.y == vec2d.y);
/*     */     } 
/* 200 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 210 */     return "Vec2d[" + this.x + ", " + this.y + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec2d.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */