/*     */ package com.sun.glass.events.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Window;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NpapiEvent
/*     */ {
/*     */   public static final int NPCocoaEventDrawRect = 1;
/*     */   public static final int NPCocoaEventMouseDown = 2;
/*     */   public static final int NPCocoaEventMouseUp = 3;
/*     */   public static final int NPCocoaEventMouseMoved = 4;
/*     */   public static final int NPCocoaEventMouseEntered = 5;
/*     */   public static final int NPCocoaEventMouseExited = 6;
/*     */   public static final int NPCocoaEventMouseDragged = 7;
/*     */   public static final int NPCocoaEventKeyDown = 8;
/*     */   public static final int NPCocoaEventKeyUp = 9;
/*     */   public static final int NPCocoaEventFlagsChanged = 10;
/*     */   public static final int NPCocoaEventFocusChanged = 11;
/*     */   public static final int NPCocoaEventWindowFocusChanged = 12;
/*     */   public static final int NPCocoaEventScrollWheel = 13;
/*     */   public static final int NPCocoaEventTextInput = 14;
/*     */   
/*     */   private static native void _dispatchCocoaNpapiDrawEvent(long paramLong1, int paramInt, long paramLong2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*     */   
/*     */   private static native void _dispatchCocoaNpapiMouseEvent(long paramLong, int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3, int paramInt4, double paramDouble3, double paramDouble4, double paramDouble5);
/*     */   
/*     */   private static native void _dispatchCocoaNpapiKeyEvent(long paramLong, int paramInt1, int paramInt2, String paramString1, String paramString2, boolean paramBoolean1, int paramInt3, boolean paramBoolean2);
/*     */   
/*     */   private static native void _dispatchCocoaNpapiFocusEvent(long paramLong, int paramInt, boolean paramBoolean);
/*     */   
/*     */   private static native void _dispatchCocoaNpapiTextInputEvent(long paramLong, int paramInt, String paramString);
/*     */   
/*     */   private static final boolean getBoolean(Map paramMap, String paramString) {
/*  71 */     boolean bool = false;
/*     */     
/*  73 */     if (paramMap.containsKey(paramString) == true) {
/*     */       try {
/*  75 */         bool = ((Boolean)paramMap.get(paramString)).booleanValue();
/*  76 */       } catch (Exception exception) {
/*  77 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  81 */     return bool;
/*     */   }
/*     */   private static final int getInt(Map paramMap, String paramString) {
/*  84 */     int i = 0;
/*     */     
/*  86 */     if (paramMap.containsKey(paramString) == true) {
/*     */       try {
/*  88 */         i = ((Integer)paramMap.get(paramString)).intValue();
/*  89 */       } catch (Exception exception) {
/*  90 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  94 */     return i;
/*     */   }
/*     */   private static final long getLong(Map paramMap, String paramString) {
/*  97 */     long l = 0L;
/*     */     
/*  99 */     if (paramMap.containsKey(paramString) == true) {
/*     */       try {
/* 101 */         l = ((Long)paramMap.get(paramString)).longValue();
/* 102 */       } catch (Exception exception) {
/* 103 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 107 */     return l;
/*     */   }
/*     */   private static final double getDouble(Map paramMap, String paramString) {
/* 110 */     double d = 0.0D;
/*     */     
/* 112 */     if (paramMap.containsKey(paramString) == true) {
/*     */       try {
/* 114 */         d = ((Double)paramMap.get(paramString)).doubleValue();
/* 115 */       } catch (Exception exception) {
/* 116 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 120 */     return d;
/*     */   }
/*     */   
/* 123 */   private static final String getString(Map paramMap, String paramString) { String str = null;
/*     */     
/* 125 */     if (paramMap.containsKey(paramString) == true) {
/*     */       try {
/* 127 */         str = (String)paramMap.get(paramString);
/* 128 */       } catch (Exception exception) {
/* 129 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 133 */     return str; } public static void dispatchCocoaNpapiEvent(Window paramWindow, Map paramMap) { long l2; int j; boolean bool1; String str1; double d1; String str2; double d2; String str3; double d3; boolean bool2; double d4; int k, m; boolean bool3; double d5;
/*     */     int n;
/*     */     double d6, d7, d8, d9;
/* 136 */     long l1 = paramWindow.getNativeWindow();
/*     */     
/* 138 */     int i = ((Integer)paramMap.get("type")).intValue();
/* 139 */     switch (i) {
/*     */       case 1:
/* 141 */         l2 = getLong(paramMap, "context");
/* 142 */         d2 = getDouble(paramMap, "x");
/* 143 */         d4 = getDouble(paramMap, "y");
/* 144 */         d5 = getDouble(paramMap, "width");
/* 145 */         d7 = getDouble(paramMap, "height");
/* 146 */         _dispatchCocoaNpapiDrawEvent(l1, i, l2, d2, d4, d5, d7);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       case 13:
/* 157 */         j = getInt(paramMap, "modifierFlags");
/* 158 */         d1 = getDouble(paramMap, "pluginX");
/* 159 */         d3 = getDouble(paramMap, "pluginY");
/* 160 */         m = getInt(paramMap, "buttonNumber");
/* 161 */         n = getInt(paramMap, "clickCount");
/* 162 */         d6 = getDouble(paramMap, "deltaX");
/* 163 */         d8 = getDouble(paramMap, "deltaY");
/* 164 */         d9 = getDouble(paramMap, "deltaZ");
/* 165 */         _dispatchCocoaNpapiMouseEvent(l1, i, j, d1, d3, m, n, d6, d8, d9);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 8:
/*     */       case 9:
/*     */       case 10:
/* 173 */         j = getInt(paramMap, "modifierFlags");
/* 174 */         str2 = getString(paramMap, "characters");
/* 175 */         str3 = getString(paramMap, "charactersIgnoringModifiers");
/* 176 */         bool2 = getBoolean(paramMap, "isARepeat");
/* 177 */         k = getInt(paramMap, "keyCode");
/* 178 */         bool3 = getBoolean(paramMap, "needsKeyTyped");
/*     */         
/* 180 */         _dispatchCocoaNpapiKeyEvent(l1, i, j, str2, str3, bool2, k, bool3);
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 11:
/*     */       case 12:
/* 187 */         bool1 = getBoolean(paramMap, "hasFocus");
/* 188 */         _dispatchCocoaNpapiFocusEvent(l1, i, bool1);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 14:
/* 193 */         str1 = getString(paramMap, "text");
/* 194 */         _dispatchCocoaNpapiTextInputEvent(l1, i, str1);
/*     */         break;
/*     */     }  }
/*     */ 
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glass\events\mac\NpapiEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */