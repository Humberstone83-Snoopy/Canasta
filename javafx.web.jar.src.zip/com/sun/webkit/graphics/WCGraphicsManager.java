/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.SharedBuffer;
/*     */ import com.sun.webkit.SimpleSharedBufferInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WCGraphicsManager
/*     */ {
/*  42 */   private static final PlatformLogger logger = PlatformLogger.getLogger(WCGraphicsManager.class.getName());
/*     */   
/*  44 */   private final AtomicInteger idCount = new AtomicInteger(0);
/*     */   
/*  46 */   private final HashMap<Integer, Ref> refMap = new HashMap<>();
/*     */   
/*  48 */   private static ResourceBundle imageProperties = null;
/*  49 */   private static WCGraphicsManager manager = null;
/*     */   
/*     */   public static void setGraphicsManager(WCGraphicsManager paramWCGraphicsManager) {
/*  52 */     manager = paramWCGraphicsManager;
/*     */   }
/*     */   
/*     */   public static WCGraphicsManager getGraphicsManager() {
/*  56 */     return manager;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract float getDevicePixelScale();
/*     */ 
/*     */   
/*     */   protected abstract WCImageDecoder getImageDecoder();
/*     */ 
/*     */   
/*     */   public abstract WCGraphicsContext createGraphicsContext(Object paramObject);
/*     */   
/*     */   public abstract WCRenderQueue createRenderQueue(WCRectangle paramWCRectangle, boolean paramBoolean);
/*     */   
/*     */   protected abstract WCRenderQueue createBufferedContextRQ(WCImage paramWCImage);
/*     */   
/*     */   public abstract WCPageBackBuffer createPageBackBuffer();
/*     */   
/*     */   protected abstract WCFont getWCFont(String paramString, boolean paramBoolean1, boolean paramBoolean2, float paramFloat);
/*     */   
/*     */   private WCFontCustomPlatformData fwkCreateFontCustomPlatformData(SharedBuffer paramSharedBuffer) {
/*     */     try {
/*  78 */       return createFontCustomPlatformData(new SimpleSharedBufferInputStream(paramSharedBuffer));
/*     */     }
/*  80 */     catch (IOException iOException) {
/*  81 */       logger.finest("Error creating font custom platform data", iOException);
/*  82 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract WCFontCustomPlatformData createFontCustomPlatformData(InputStream paramInputStream) throws IOException;
/*     */   
/*     */   protected abstract WCPath createWCPath();
/*     */   
/*     */   protected abstract WCPath createWCPath(WCPath paramWCPath);
/*     */   
/*     */   protected abstract WCImage createWCImage(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract WCImage createRTImage(int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract WCImage getIconImage(String paramString);
/*     */   
/*     */   public abstract Object toPlatformImage(WCImage paramWCImage);
/*     */   
/*     */   protected abstract WCImageFrame createFrame(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer);
/*     */   
/*     */   public static String getResourceName(String paramString) {
/* 104 */     if (imageProperties == null) {
/* 105 */       imageProperties = ResourceBundle.getBundle("com.sun.webkit.graphics.Images");
/*     */     }
/*     */     
/*     */     try {
/* 109 */       return imageProperties.getString(paramString);
/*     */     }
/* 111 */     catch (MissingResourceException missingResourceException) {
/* 112 */       return paramString;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fwkLoadFromResource(String paramString, long paramLong) {
/* 117 */     InputStream inputStream = getClass().getResourceAsStream(getResourceName(paramString));
/* 118 */     if (inputStream == null) {
/*     */       return;
/*     */     }
/*     */     
/* 122 */     byte[] arrayOfByte = new byte[1024];
/*     */     try {
/*     */       int i;
/* 125 */       while ((i = inputStream.read(arrayOfByte)) > -1) {
/* 126 */         append(paramLong, arrayOfByte, i);
/*     */       }
/* 128 */       inputStream.close();
/* 129 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract WCTransform createTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getSupportedMediaTypes() {
/* 139 */     return new String[0];
/*     */   }
/*     */   
/*     */   private WCMediaPlayer fwkCreateMediaPlayer(long paramLong) {
/* 143 */     WCMediaPlayer wCMediaPlayer = createMediaPlayer();
/* 144 */     wCMediaPlayer.setNativePointer(paramLong);
/* 145 */     return wCMediaPlayer;
/*     */   }
/*     */   
/*     */   protected abstract WCMediaPlayer createMediaPlayer();
/*     */   
/*     */   int createID() {
/* 151 */     return this.idCount.incrementAndGet();
/*     */   }
/*     */   
/*     */   synchronized void ref(Ref paramRef) {
/* 155 */     this.refMap.put(Integer.valueOf(paramRef.getID()), paramRef);
/*     */   }
/*     */   
/*     */   synchronized Ref deref(Ref paramRef) {
/* 159 */     return this.refMap.remove(Integer.valueOf(paramRef.getID()));
/*     */   }
/*     */   
/*     */   synchronized Ref getRef(int paramInt) {
/* 163 */     return this.refMap.get(Integer.valueOf(paramInt));
/*     */   }
/*     */   
/*     */   private static native void append(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCGraphicsManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */