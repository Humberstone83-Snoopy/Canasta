/*     */ package com.sun.javafx.scene.web;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.webkit.WebPage;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Printable
/*     */   extends Node
/*     */ {
/*     */   private final WebPage page;
/*     */   private final NGNode peer;
/*     */   
/*     */   static {
/*  39 */     PrintableHelper.setPrintableAccessor(new PrintableHelper.PrintableAccessor()
/*     */         {
/*     */           public NGNode doCreatePeer(Node param1Node) {
/*  42 */             return ((Printable)param1Node).doCreatePeer();
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform) {
/*  48 */             return ((Printable)param1Node).doComputeGeomBounds(param1BaseBounds, param1BaseTransform);
/*     */           }
/*     */ 
/*     */           
/*     */           public boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2) {
/*  53 */             return ((Printable)param1Node).doComputeContains(param1Double1, param1Double2);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Printable(WebPage paramWebPage, int paramInt, float paramFloat) {
/*  62 */     this.page = paramWebPage;
/*  63 */     this.peer = new Peer(paramInt, paramFloat);
/*  64 */     PrintableHelper.initHelper(this);
/*     */   }
/*     */   
/*     */   private NGNode doCreatePeer() {
/*  68 */     return this.peer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BaseBounds doComputeGeomBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  75 */     return paramBaseBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doComputeContains(double paramDouble1, double paramDouble2) {
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   private final class Peer extends NGNode {
/*     */     private final int pageIndex;
/*     */     private final float width;
/*     */     
/*     */     Peer(int param1Int, float param1Float) {
/*  90 */       this.pageIndex = param1Int;
/*  91 */       this.width = param1Float;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void renderContent(Graphics param1Graphics) {
/*  96 */       WCGraphicsContext wCGraphicsContext = WCGraphicsManager.getGraphicsManager().createGraphicsContext(param1Graphics);
/*  97 */       Printable.this.page.print(wCGraphicsContext, this.pageIndex, this.width);
/*     */     }
/*     */     
/*     */     protected boolean hasOverlappingContents() {
/* 101 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\scene\web\Printable.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */