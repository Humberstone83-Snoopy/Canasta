/*     */ package com.sun.javafx.geom.transform;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Translate2D
/*     */   extends BaseTransform
/*     */ {
/*     */   private double mxt;
/*     */   private double myt;
/*     */   private static final long BASE_HASH;
/*     */   
/*     */   public static BaseTransform getInstance(double paramDouble1, double paramDouble2) {
/*  43 */     if (paramDouble1 == 0.0D && paramDouble2 == 0.0D) {
/*  44 */       return IDENTITY_TRANSFORM;
/*     */     }
/*  46 */     return new Translate2D(paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public Translate2D(double paramDouble1, double paramDouble2) {
/*  51 */     this.mxt = paramDouble1;
/*  52 */     this.myt = paramDouble2;
/*     */   }
/*     */   
/*     */   public Translate2D(BaseTransform paramBaseTransform) {
/*  56 */     if (!paramBaseTransform.isTranslateOrIdentity()) {
/*  57 */       degreeError(BaseTransform.Degree.TRANSLATE_2D);
/*     */     }
/*  59 */     this.mxt = paramBaseTransform.getMxt();
/*  60 */     this.myt = paramBaseTransform.getMyt();
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform.Degree getDegree() {
/*  65 */     return BaseTransform.Degree.TRANSLATE_2D;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDeterminant() {
/*  70 */     return 1.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMxt() {
/*  75 */     return this.mxt;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMyt() {
/*  80 */     return this.myt;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/*  85 */     return (this.mxt == 0.0D && this.myt == 0.0D) ? 0 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIdentity() {
/*  90 */     return (this.mxt == 0.0D && this.myt == 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTranslateOrIdentity() {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean is2D() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D transform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 105 */     if (paramPoint2D2 == null) paramPoint2D2 = makePoint(paramPoint2D1, paramPoint2D2); 
/* 106 */     paramPoint2D2.setLocation((float)(paramPoint2D1.x + this.mxt), (float)(paramPoint2D1.y + this.myt));
/*     */ 
/*     */     
/* 109 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point2D inverseTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 114 */     if (paramPoint2D2 == null) paramPoint2D2 = makePoint(paramPoint2D1, paramPoint2D2); 
/* 115 */     paramPoint2D2.setLocation((float)(paramPoint2D1.x - this.mxt), (float)(paramPoint2D1.y - this.myt));
/*     */ 
/*     */     
/* 118 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 123 */     if (paramVec3d2 == null) {
/* 124 */       paramVec3d2 = new Vec3d();
/*     */     }
/* 126 */     paramVec3d1.x += this.mxt;
/* 127 */     paramVec3d1.y += this.myt;
/* 128 */     paramVec3d2.z = paramVec3d1.z;
/* 129 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d deltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 134 */     if (paramVec3d2 == null) {
/* 135 */       paramVec3d2 = new Vec3d();
/*     */     }
/* 137 */     paramVec3d2.set(paramVec3d1);
/* 138 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d inverseTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 143 */     if (paramVec3d2 == null) {
/* 144 */       paramVec3d2 = new Vec3d();
/*     */     }
/* 146 */     paramVec3d1.x -= this.mxt;
/* 147 */     paramVec3d1.y -= this.myt;
/* 148 */     paramVec3d2.z = paramVec3d1.z;
/* 149 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3d inverseDeltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/* 154 */     if (paramVec3d2 == null) {
/* 155 */       paramVec3d2 = new Vec3d();
/*     */     }
/* 157 */     paramVec3d2.set(paramVec3d1);
/* 158 */     return paramVec3d2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 166 */     float f1 = (float)this.mxt;
/* 167 */     float f2 = (float)this.myt;
/* 168 */     if (paramArrayOffloat2 == paramArrayOffloat1) {
/* 169 */       if (paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */         
/* 180 */         paramInt1 = paramInt2;
/*     */       } 
/* 182 */       if (paramInt2 == paramInt1 && f1 == 0.0F && f2 == 0.0F) {
/*     */         return;
/*     */       }
/*     */     } 
/* 186 */     for (byte b = 0; b < paramInt3; b++) {
/* 187 */       paramArrayOffloat2[paramInt2++] = paramArrayOffloat1[paramInt1++] + f1;
/* 188 */       paramArrayOffloat2[paramInt2++] = paramArrayOffloat1[paramInt1++] + f2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 197 */     double d1 = this.mxt;
/* 198 */     double d2 = this.myt;
/* 199 */     if (paramArrayOfdouble2 == paramArrayOfdouble1) {
/* 200 */       if (paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 209 */         System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */         
/* 211 */         paramInt1 = paramInt2;
/*     */       } 
/* 213 */       if (paramInt2 == paramInt1 && d1 == 0.0D && d2 == 0.0D) {
/*     */         return;
/*     */       }
/*     */     } 
/* 217 */     for (byte b = 0; b < paramInt3; b++) {
/* 218 */       paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] + d1;
/* 219 */       paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] + d2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(float[] paramArrayOffloat, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3) {
/* 228 */     double d1 = this.mxt;
/* 229 */     double d2 = this.myt;
/* 230 */     for (byte b = 0; b < paramInt3; b++) {
/* 231 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++] + d1;
/* 232 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++] + d2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(double[] paramArrayOfdouble, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
/* 241 */     double d1 = this.mxt;
/* 242 */     double d2 = this.myt;
/* 243 */     for (byte b = 0; b < paramInt3; b++) {
/* 244 */       paramArrayOffloat[paramInt2++] = (float)(paramArrayOfdouble[paramInt1++] + d1);
/* 245 */       paramArrayOffloat[paramInt2++] = (float)(paramArrayOfdouble[paramInt1++] + d2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 254 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 255 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deltaTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 264 */     if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 265 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 274 */     float f1 = (float)this.mxt;
/* 275 */     float f2 = (float)this.myt;
/* 276 */     if (paramArrayOffloat2 == paramArrayOffloat1) {
/* 277 */       if (paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 286 */         System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */         
/* 288 */         paramInt1 = paramInt2;
/*     */       } 
/* 290 */       if (paramInt2 == paramInt1 && f1 == 0.0F && f2 == 0.0F) {
/*     */         return;
/*     */       }
/*     */     } 
/* 294 */     for (byte b = 0; b < paramInt3; b++) {
/* 295 */       paramArrayOffloat2[paramInt2++] = paramArrayOffloat1[paramInt1++] - f1;
/* 296 */       paramArrayOffloat2[paramInt2++] = paramArrayOffloat1[paramInt1++] - f2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseDeltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 305 */     if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 306 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inverseTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 315 */     double d1 = this.mxt;
/* 316 */     double d2 = this.myt;
/* 317 */     if (paramArrayOfdouble2 == paramArrayOfdouble1) {
/* 318 */       if (paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 327 */         System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*     */         
/* 329 */         paramInt1 = paramInt2;
/*     */       } 
/* 331 */       if (paramInt2 == paramInt1 && d1 == 0.0D && d2 == 0.0D) {
/*     */         return;
/*     */       }
/*     */     } 
/* 335 */     for (byte b = 0; b < paramInt3; b++) {
/* 336 */       paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] - d1;
/* 337 */       paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] - d2;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/* 343 */     float f1 = (float)(paramBaseBounds1.getMinX() + this.mxt);
/* 344 */     float f2 = (float)(paramBaseBounds1.getMinY() + this.myt);
/* 345 */     float f3 = paramBaseBounds1.getMinZ();
/* 346 */     float f4 = (float)(paramBaseBounds1.getMaxX() + this.mxt);
/* 347 */     float f5 = (float)(paramBaseBounds1.getMaxY() + this.myt);
/* 348 */     float f6 = paramBaseBounds1.getMaxZ();
/* 349 */     return paramBaseBounds2.deriveWithNewBounds(f1, f2, f3, f4, f5, f6);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transform(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/* 354 */     transform(paramRectangle1, paramRectangle2, this.mxt, this.myt);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds inverseTransform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/* 359 */     float f1 = (float)(paramBaseBounds1.getMinX() - this.mxt);
/* 360 */     float f2 = (float)(paramBaseBounds1.getMinY() - this.myt);
/* 361 */     float f3 = paramBaseBounds1.getMinZ();
/* 362 */     float f4 = (float)(paramBaseBounds1.getMaxX() - this.mxt);
/* 363 */     float f5 = (float)(paramBaseBounds1.getMaxY() - this.myt);
/* 364 */     float f6 = paramBaseBounds1.getMaxZ();
/* 365 */     return paramBaseBounds2.deriveWithNewBounds(f1, f2, f3, f4, f5, f6);
/*     */   }
/*     */ 
/*     */   
/*     */   public void inverseTransform(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/* 370 */     transform(paramRectangle1, paramRectangle2, -this.mxt, -this.myt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void transform(Rectangle paramRectangle1, Rectangle paramRectangle2, double paramDouble1, double paramDouble2) {
/* 376 */     int i = (int)paramDouble1;
/* 377 */     int j = (int)paramDouble2;
/* 378 */     if (i == paramDouble1 && j == paramDouble2) {
/* 379 */       paramRectangle2.setBounds(paramRectangle1);
/* 380 */       paramRectangle2.translate(i, j);
/*     */     } else {
/* 382 */       double d1 = paramRectangle1.x + paramDouble1;
/* 383 */       double d2 = paramRectangle1.y + paramDouble2;
/* 384 */       double d3 = Math.ceil(d1 + paramRectangle1.width);
/* 385 */       double d4 = Math.ceil(d2 + paramRectangle1.height);
/* 386 */       d1 = Math.floor(d1);
/* 387 */       d2 = Math.floor(d2);
/* 388 */       paramRectangle2.setBounds((int)d1, (int)d2, (int)(d3 - d1), (int)(d4 - d2));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape createTransformedShape(Shape paramShape) {
/* 394 */     return new Path2D(paramShape, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setToIdentity() {
/* 399 */     this.mxt = this.myt = 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransform(BaseTransform paramBaseTransform) {
/* 404 */     if (!paramBaseTransform.isTranslateOrIdentity()) {
/* 405 */       degreeError(BaseTransform.Degree.TRANSLATE_2D);
/*     */     }
/* 407 */     this.mxt = paramBaseTransform.getMxt();
/* 408 */     this.myt = paramBaseTransform.getMyt();
/*     */   }
/*     */ 
/*     */   
/*     */   public void invert() {
/* 413 */     this.mxt = -this.mxt;
/* 414 */     this.myt = -this.myt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 422 */     if (paramDouble1 != 1.0D || paramDouble2 != 0.0D || paramDouble3 != 0.0D || paramDouble4 != 1.0D)
/*     */     {
/*     */       
/* 425 */       degreeError(BaseTransform.Degree.TRANSLATE_2D);
/*     */     }
/* 427 */     this.mxt = paramDouble5;
/* 428 */     this.myt = paramDouble6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 436 */     if (paramDouble1 != 1.0D || paramDouble2 != 0.0D || paramDouble3 != 0.0D || paramDouble5 != 0.0D || paramDouble6 != 1.0D || paramDouble7 != 0.0D || paramDouble9 != 0.0D || paramDouble10 != 0.0D || paramDouble11 != 1.0D || paramDouble12 != 0.0D)
/*     */     {
/*     */ 
/*     */       
/* 440 */       degreeError(BaseTransform.Degree.TRANSLATE_2D);
/*     */     }
/* 442 */     this.mxt = paramDouble4;
/* 443 */     this.myt = paramDouble8;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2) {
/* 448 */     this.mxt += paramDouble1;
/* 449 */     this.myt += paramDouble2;
/* 450 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 455 */     if (paramDouble3 == 0.0D) {
/* 456 */       this.mxt += paramDouble1;
/* 457 */       this.myt += paramDouble2;
/* 458 */       return this;
/*     */     } 
/* 460 */     Affine3D affine3D = new Affine3D();
/* 461 */     affine3D.translate(this.mxt + paramDouble1, this.myt + paramDouble2, paramDouble3);
/* 462 */     return affine3D;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 467 */     if (paramDouble3 == 1.0D) {
/* 468 */       if (paramDouble1 == 1.0D && paramDouble2 == 1.0D) {
/* 469 */         return this;
/*     */       }
/* 471 */       Affine2D affine2D = new Affine2D();
/* 472 */       affine2D.translate(this.mxt, this.myt);
/* 473 */       affine2D.scale(paramDouble1, paramDouble2);
/* 474 */       return affine2D;
/*     */     } 
/* 476 */     Affine3D affine3D = new Affine3D();
/* 477 */     affine3D.translate(this.mxt, this.myt);
/* 478 */     affine3D.scale(paramDouble1, paramDouble2, paramDouble3);
/* 479 */     return affine3D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 486 */     if (paramDouble1 == 0.0D) {
/* 487 */       return this;
/*     */     }
/* 489 */     if (almostZero(paramDouble2) && almostZero(paramDouble3)) {
/* 490 */       if (paramDouble4 == 0.0D) {
/* 491 */         return this;
/*     */       }
/* 493 */       Affine2D affine2D = new Affine2D();
/* 494 */       affine2D.translate(this.mxt, this.myt);
/* 495 */       if (paramDouble4 > 0.0D) {
/* 496 */         affine2D.rotate(paramDouble1);
/* 497 */       } else if (paramDouble4 < 0.0D) {
/* 498 */         affine2D.rotate(-paramDouble1);
/*     */       } 
/* 500 */       return affine2D;
/*     */     } 
/* 502 */     Affine3D affine3D = new Affine3D();
/* 503 */     affine3D.translate(this.mxt, this.myt);
/* 504 */     affine3D.rotate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 505 */     return affine3D;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithPreTranslation(double paramDouble1, double paramDouble2) {
/* 510 */     this.mxt += paramDouble1;
/* 511 */     this.myt += paramDouble2;
/* 512 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 520 */     if (paramDouble1 == 1.0D && paramDouble2 == 0.0D && paramDouble3 == 0.0D && paramDouble4 == 1.0D) {
/* 521 */       this.mxt += paramDouble5;
/* 522 */       this.myt += paramDouble6;
/* 523 */       return this;
/*     */     } 
/* 525 */     return new Affine2D(paramDouble1, paramDouble2, paramDouble3, paramDouble4, this.mxt + paramDouble5, this.myt + paramDouble6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 536 */     if (paramDouble3 == 0.0D && paramDouble7 == 0.0D && paramDouble9 == 0.0D && paramDouble10 == 0.0D && paramDouble11 == 1.0D && paramDouble12 == 0.0D)
/*     */     {
/*     */       
/* 539 */       return deriveWithConcatenation(paramDouble1, paramDouble5, paramDouble2, paramDouble6, paramDouble4, paramDouble8);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 544 */     return new Affine3D(paramDouble1, paramDouble2, paramDouble3, paramDouble4 + this.mxt, paramDouble5, paramDouble6, paramDouble7, paramDouble8 + this.myt, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithConcatenation(BaseTransform paramBaseTransform) {
/* 551 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/* 552 */       this.mxt += paramBaseTransform.getMxt();
/* 553 */       this.myt += paramBaseTransform.getMyt();
/* 554 */       return this;
/* 555 */     }  if (paramBaseTransform.is2D()) {
/* 556 */       return getInstance(paramBaseTransform.getMxx(), paramBaseTransform.getMyx(), paramBaseTransform
/* 557 */           .getMxy(), paramBaseTransform.getMyy(), this.mxt + paramBaseTransform
/* 558 */           .getMxt(), this.myt + paramBaseTransform.getMyt());
/*     */     }
/* 560 */     Affine3D affine3D = new Affine3D(paramBaseTransform);
/* 561 */     affine3D.preTranslate(this.mxt, this.myt, 0.0D);
/* 562 */     return affine3D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithPreConcatenation(BaseTransform paramBaseTransform) {
/* 568 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/* 569 */       this.mxt += paramBaseTransform.getMxt();
/* 570 */       this.myt += paramBaseTransform.getMyt();
/* 571 */       return this;
/* 572 */     }  if (paramBaseTransform.is2D()) {
/* 573 */       Affine2D affine2D = new Affine2D(paramBaseTransform);
/* 574 */       affine2D.translate(this.mxt, this.myt);
/* 575 */       return affine2D;
/*     */     } 
/* 577 */     Affine3D affine3D = new Affine3D(paramBaseTransform);
/* 578 */     affine3D.translate(this.mxt, this.myt, 0.0D);
/* 579 */     return affine3D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform deriveWithNewTransform(BaseTransform paramBaseTransform) {
/* 585 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/* 586 */       this.mxt = paramBaseTransform.getMxt();
/* 587 */       this.myt = paramBaseTransform.getMyt();
/* 588 */       return this;
/*     */     } 
/* 590 */     return getInstance(paramBaseTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform createInverse() {
/* 596 */     if (isIdentity()) {
/* 597 */       return IDENTITY_TRANSFORM;
/*     */     }
/* 599 */     return new Translate2D(-this.mxt, -this.myt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double _matround(double paramDouble) {
/* 606 */     return Math.rint(paramDouble * 1.0E15D) / 1.0E15D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 612 */     return "Translate2D[" + _matround(this.mxt) + ", " + 
/* 613 */       _matround(this.myt) + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseTransform copy() {
/* 618 */     return new Translate2D(this.mxt, this.myt);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 623 */     if (paramObject instanceof BaseTransform) {
/* 624 */       BaseTransform baseTransform = (BaseTransform)paramObject;
/* 625 */       return (baseTransform.isTranslateOrIdentity() && baseTransform
/* 626 */         .getMxt() == this.mxt && baseTransform
/* 627 */         .getMyt() == this.myt);
/*     */     } 
/* 629 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 634 */     long l = 0L;
/* 635 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzz());
/* 636 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzy());
/* 637 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzx());
/* 638 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMyz());
/* 639 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMxz());
/* 640 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMyy());
/* 641 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMyx());
/* 642 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMxy());
/* 643 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMxx());
/* 644 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzt());
/* 645 */     BASE_HASH = l;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 650 */     if (isIdentity()) return 0; 
/* 651 */     long l = BASE_HASH;
/* 652 */     l = l * 31L + Double.doubleToLongBits(getMyt());
/* 653 */     l = l * 31L + Double.doubleToLongBits(getMxt());
/* 654 */     return (int)l ^ (int)(l >> 32L);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\Translate2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */