/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.css.CSSPrimitiveValue;
/*    */ import org.w3c.dom.css.Rect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RectImpl
/*    */   implements Rect
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 37 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 40 */       RectImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   RectImpl(long paramLong) {
/* 45 */     this.peer = paramLong;
/* 46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static Rect create(long paramLong) {
/* 50 */     if (paramLong == 0L) return null; 
/* 51 */     return new RectImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 57 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 61 */     return (paramObject instanceof RectImpl && this.peer == ((RectImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 65 */     long l = this.peer;
/* 66 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(Rect paramRect) {
/* 70 */     return (paramRect == null) ? 0L : ((RectImpl)paramRect).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static Rect getImpl(long paramLong) {
/* 76 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getTop() {
/* 82 */     return CSSPrimitiveValueImpl.getImpl(getTopImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getRight() {
/* 87 */     return CSSPrimitiveValueImpl.getImpl(getRightImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getBottom() {
/* 92 */     return CSSPrimitiveValueImpl.getImpl(getBottomImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSPrimitiveValue getLeft() {
/* 97 */     return CSSPrimitiveValueImpl.getImpl(getLeftImpl(getPeer()));
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native long getTopImpl(long paramLong);
/*    */   
/*    */   static native long getRightImpl(long paramLong);
/*    */   
/*    */   static native long getBottomImpl(long paramLong);
/*    */   
/*    */   static native long getLeftImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\RectImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */