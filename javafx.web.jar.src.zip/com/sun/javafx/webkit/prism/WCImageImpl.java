/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Image;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.image.CompoundCoords;
/*     */ import com.sun.prism.image.CompoundTexture;
/*     */ import com.sun.prism.image.Coords;
/*     */ import com.sun.prism.image.ViewPort;
/*     */ import java.nio.ByteBuffer;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCImageImpl
/*     */   extends PrismImage
/*     */ {
/*  48 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCImageImpl.class.getName());
/*     */   
/*     */   private final Image img;
/*     */   
/*     */   private Texture texture;
/*     */   private CompoundTexture compoundTexture;
/*     */   
/*     */   WCImageImpl(int paramInt1, int paramInt2) {
/*  56 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  57 */       log.fine("Creating empty image({0},{1})", new Object[] {
/*  58 */             Integer.valueOf(paramInt1), Integer.valueOf(paramInt2)
/*     */           }); 
/*  60 */     this.img = Image.fromIntArgbPreData(new int[paramInt1 * paramInt2], paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   WCImageImpl(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/*  64 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  65 */       log.fine("Creating image({0},{1}) from buffer", new Object[] {
/*  66 */             Integer.valueOf(paramInt1), Integer.valueOf(paramInt2)
/*     */           }); 
/*  68 */     this.img = Image.fromIntArgbPreData(paramArrayOfint, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   WCImageImpl(ImageFrame paramImageFrame) {
/*  72 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  73 */       log.fine("Creating image {0}x{1} of type {2} from buffer", new Object[] {
/*  74 */             Integer.valueOf(paramImageFrame.getWidth()), Integer.valueOf(paramImageFrame.getHeight()), paramImageFrame.getImageType()
/*     */           }); 
/*  76 */     this.img = Image.convertImageFrame(paramImageFrame);
/*     */   }
/*     */   
/*     */   Image getImage() {
/*  80 */     return this.img;
/*     */   }
/*     */ 
/*     */   
/*     */   Graphics getGraphics() {
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void draw(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*  93 */     if (paramGraphics instanceof com.sun.prism.PrinterGraphics) {
/*     */       
/*  95 */       Texture texture = paramGraphics.getResourceFactory().createTexture(this.img, Texture.Usage.STATIC, Texture.WrapMode.CLAMP_NOT_NEEDED);
/*     */       
/*  97 */       paramGraphics.drawTexture(texture, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*     */ 
/*     */       
/* 100 */       texture.dispose();
/*     */       
/*     */       return;
/*     */     } 
/* 104 */     if (this.texture != null) {
/* 105 */       this.texture.lock();
/* 106 */       if (this.texture.isSurfaceLost()) {
/* 107 */         this.texture = null;
/*     */       }
/*     */     } 
/* 110 */     if (this.texture == null && this.compoundTexture == null) {
/* 111 */       ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/* 112 */       int i = resourceFactory.getMaximumTextureSize();
/* 113 */       if (this.img.getWidth() <= i && this.img.getHeight() <= i) {
/* 114 */         this.texture = resourceFactory.createTexture(this.img, Texture.Usage.DEFAULT, Texture.WrapMode.CLAMP_TO_EDGE);
/* 115 */         assert this.texture != null;
/*     */       } else {
/* 117 */         this.compoundTexture = new CompoundTexture(this.img, i);
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     if (this.texture != null) {
/* 122 */       assert this.compoundTexture == null;
/* 123 */       paramGraphics.drawTexture(this.texture, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*     */ 
/*     */ 
/*     */       
/* 127 */       this.texture.unlock();
/*     */     } else {
/* 129 */       assert this.compoundTexture != null;
/* 130 */       ViewPort viewPort = new ViewPort(paramInt5, paramInt6, (paramInt7 - paramInt5), (paramInt8 - paramInt6));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       Coords coords = new Coords((paramInt3 - paramInt1), (paramInt4 - paramInt2), viewPort);
/* 136 */       CompoundCoords compoundCoords = new CompoundCoords(this.compoundTexture, coords);
/*     */ 
/*     */       
/* 139 */       compoundCoords.draw(paramGraphics, this.compoundTexture, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void dispose() {
/* 145 */     if (this.texture != null) {
/* 146 */       this.texture.dispose();
/* 147 */       this.texture = null;
/*     */     } 
/* 149 */     if (this.compoundTexture != null) {
/* 150 */       this.compoundTexture.dispose();
/* 151 */       this.compoundTexture = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 157 */     return this.img.getWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 162 */     return this.img.getHeight();
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteBuffer getPixelBuffer() {
/* 167 */     int i = this.img.getWidth();
/* 168 */     int j = this.img.getHeight();
/* 169 */     int k = i * 4;
/* 170 */     ByteBuffer byteBuffer = ByteBuffer.allocate(k * j);
/* 171 */     this.img.getPixels(0, 0, i, j, 
/* 172 */         PixelFormat.getByteBgraInstance(), byteBuffer, k);
/*     */     
/* 174 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelScale() {
/* 179 */     return this.img.getPixelScale();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCImageImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */