/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.traversal.NodeFilter;
/*     */ import org.w3c.dom.traversal.TreeWalker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeWalkerImpl
/*     */   implements TreeWalker
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  39 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  42 */       TreeWalkerImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   TreeWalkerImpl(long paramLong) {
/*  47 */     this.peer = paramLong;
/*  48 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static TreeWalker create(long paramLong) {
/*  52 */     if (paramLong == 0L) return null; 
/*  53 */     return new TreeWalkerImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  59 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  63 */     return (paramObject instanceof TreeWalkerImpl && this.peer == ((TreeWalkerImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  67 */     long l = this.peer;
/*  68 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(TreeWalker paramTreeWalker) {
/*  72 */     return (paramTreeWalker == null) ? 0L : ((TreeWalkerImpl)paramTreeWalker).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static TreeWalker getImpl(long paramLong) {
/*  78 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getRoot() {
/*  84 */     return NodeImpl.getImpl(getRootImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWhatToShow() {
/*  89 */     return getWhatToShowImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeFilter getFilter() {
/*  94 */     return NodeFilterImpl.getImpl(getFilterImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getExpandEntityReferences() {
/*  99 */     return getExpandEntityReferencesImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getCurrentNode() {
/* 104 */     return NodeImpl.getImpl(getCurrentNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentNode(Node paramNode) throws DOMException {
/* 109 */     setCurrentNodeImpl(getPeer(), NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node parentNode() {
/* 117 */     return NodeImpl.getImpl(parentNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node firstChild() {
/* 124 */     return NodeImpl.getImpl(firstChildImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node lastChild() {
/* 131 */     return NodeImpl.getImpl(lastChildImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node previousSibling() {
/* 138 */     return NodeImpl.getImpl(previousSiblingImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node nextSibling() {
/* 145 */     return NodeImpl.getImpl(nextSiblingImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node previousNode() {
/* 152 */     return NodeImpl.getImpl(previousNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node nextNode() {
/* 159 */     return NodeImpl.getImpl(nextNodeImpl(getPeer()));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native long getRootImpl(long paramLong);
/*     */   
/*     */   static native int getWhatToShowImpl(long paramLong);
/*     */   
/*     */   static native long getFilterImpl(long paramLong);
/*     */   
/*     */   static native boolean getExpandEntityReferencesImpl(long paramLong);
/*     */   
/*     */   static native long getCurrentNodeImpl(long paramLong);
/*     */   
/*     */   static native void setCurrentNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native long parentNodeImpl(long paramLong);
/*     */   
/*     */   static native long firstChildImpl(long paramLong);
/*     */   
/*     */   static native long lastChildImpl(long paramLong);
/*     */   
/*     */   static native long previousSiblingImpl(long paramLong);
/*     */   
/*     */   static native long nextSiblingImpl(long paramLong);
/*     */   
/*     */   static native long previousNodeImpl(long paramLong);
/*     */   
/*     */   static native long nextNodeImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\TreeWalkerImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */