package com.sun.webkit.graphics;

public abstract class WCFontCustomPlatformData {
  protected abstract WCFont createFont(int paramInt, boolean paramBoolean1, boolean paramBoolean2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCFontCustomPlatformData.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */