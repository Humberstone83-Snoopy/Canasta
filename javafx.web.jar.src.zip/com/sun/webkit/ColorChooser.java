/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.javafx.scene.control.CustomColorDialog;
/*    */ import javafx.scene.paint.Color;
/*    */ import javafx.scene.web.WebView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ColorChooser
/*    */ {
/*    */   private static final double COLOR_DOUBLE_TO_UCHAR_FACTOR = 255.0D;
/*    */   private final CustomColorDialog colorChooserDialog;
/*    */   private final long pdata;
/*    */   
/*    */   private ColorChooser(WebPage paramWebPage, Color paramColor, long paramLong) {
/* 49 */     this.pdata = paramLong;
/*    */     
/* 51 */     WebPageClient<WebView> webPageClient = paramWebPage.getPageClient();
/* 52 */     assert webPageClient != null;
/* 53 */     this.colorChooserDialog = new CustomColorDialog(((WebView)webPageClient.getContainer()).getScene().getWindow());
/* 54 */     this.colorChooserDialog.setSaveBtnToOk();
/* 55 */     this.colorChooserDialog.setShowUseBtn(false);
/* 56 */     this.colorChooserDialog.setShowOpacitySlider(false);
/*    */     
/* 58 */     this.colorChooserDialog.setOnSave(() -> twkSetSelectedColor(this.pdata, (int)Math.round(this.colorChooserDialog.getCustomColor().getRed() * 255.0D), (int)Math.round(this.colorChooserDialog.getCustomColor().getGreen() * 255.0D), (int)Math.round(this.colorChooserDialog.getCustomColor().getBlue() * 255.0D)));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     this.colorChooserDialog.setCurrentColor(paramColor);
/* 66 */     this.colorChooserDialog.show();
/*    */   }
/*    */   
/*    */   private static ColorChooser fwkCreateAndShowColorChooser(WebPage paramWebPage, int paramInt1, int paramInt2, int paramInt3, long paramLong) {
/* 70 */     return new ColorChooser(paramWebPage, Color.rgb(paramInt1, paramInt2, paramInt3), paramLong);
/*    */   }
/*    */   
/*    */   private void fwkShowColorChooser(int paramInt1, int paramInt2, int paramInt3) {
/* 74 */     this.colorChooserDialog.setCurrentColor(Color.rgb(paramInt1, paramInt2, paramInt3));
/* 75 */     this.colorChooserDialog.show();
/*    */   }
/*    */   
/*    */   private void fwkHideColorChooser() {
/* 79 */     this.colorChooserDialog.hide();
/*    */   }
/*    */   
/*    */   private native void twkSetSelectedColor(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\ColorChooser.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */