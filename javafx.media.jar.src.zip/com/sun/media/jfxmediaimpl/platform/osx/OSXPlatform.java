/*     */ package com.sun.media.jfxmediaimpl.platform.osx;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.HostUtils;
/*     */ import com.sun.media.jfxmediaimpl.platform.Platform;
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OSXPlatform
/*     */   extends Platform
/*     */ {
/*  50 */   private static final String[] CONTENT_TYPES = new String[] { "audio/x-aiff", "audio/mp3", "audio/mpeg", "audio/x-m4a", "video/mp4", "video/x-m4v", "application/vnd.apple.mpegurl", "audio/mpegurl" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static final String[] PROTOCOLS = new String[] { "file", "http", "https" };
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class OSXPlatformInitializer
/*     */   {
/*     */     private static final OSXPlatform globalInstance;
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/*  75 */       boolean bool = false;
/*     */       try {
/*  77 */         bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> {
/*     */               boolean bool1 = false;
/*     */               
/*     */               boolean bool2 = false;
/*     */               
/*     */               try {
/*     */                 NativeLibLoader.loadLibrary("jfxmedia_avf");
/*     */                 bool1 = true;
/*  85 */               } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*     */               try {
/*     */                 NativeLibLoader.loadLibrary("jfxmedia_qtkit");
/*     */                 bool2 = true;
/*  89 */               } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*     */               
/*  91 */               return Boolean.valueOf((bool1 || bool2));
/*     */             })).booleanValue();
/*  93 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*  96 */       if (bool) {
/*  97 */         globalInstance = new OSXPlatform();
/*     */       } else {
/*  99 */         globalInstance = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static Platform getPlatformInstance() {
/* 105 */     return OSXPlatformInitializer.globalInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OSXPlatform() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean loadPlatform() {
/* 116 */     if (!HostUtils.isMacOSX()) {
/* 117 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 122 */       return osxPlatformInit();
/* 123 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 124 */       if (Logger.canLog(1)) {
/* 125 */         Logger.logMsg(1, "Unable to load OSX platform.");
/*     */       }
/*     */       
/* 128 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSupportedContentTypes() {
/* 134 */     return Arrays.<String>copyOf(CONTENT_TYPES, CONTENT_TYPES.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSupportedProtocols() {
/* 139 */     return Arrays.<String>copyOf(PROTOCOLS, PROTOCOLS.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public Media createMedia(Locator paramLocator) {
/* 144 */     return new OSXMedia(paramLocator);
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaPlayer createMediaPlayer(Locator paramLocator) {
/*     */     try {
/* 150 */       return new OSXMediaPlayer(paramLocator);
/* 151 */     } catch (Exception exception) {
/* 152 */       if (Logger.canLog(1)) {
/* 153 */         Logger.logMsg(1, "OSXPlatform caught exception while creating media player: " + exception);
/* 154 */         exception.printStackTrace();
/*     */       } 
/*     */       
/* 157 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native boolean osxPlatformInit();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\osx\OSXPlatform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */