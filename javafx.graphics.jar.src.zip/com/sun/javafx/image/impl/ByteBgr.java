/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBgr
/*     */ {
/*  40 */   public static final BytePixelGetter getter = Accessor.instance;
/*  41 */   public static final BytePixelSetter setter = Accessor.instance;
/*  42 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   private static ByteToBytePixelConverter ToByteBgrObj;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgrConverter() {
/*  46 */     if (ToByteBgrObj == null) {
/*  47 */       ToByteBgrObj = BaseByteToByteConverter.create(accessor);
/*     */     }
/*  49 */     return ToByteBgrObj;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  53 */     return ToByteBgrfConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/*  57 */     return ToByteBgrfConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbConverter() {
/*  61 */     return ToIntFrgbConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbPreConverter() {
/*  65 */     return ToIntFrgbConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteArgbConverter() {
/*  69 */     return ToByteFrgbConv.nonpremult;
/*     */   }
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  73 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  78 */       return AlphaType.OPAQUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  83 */       return 3;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  88 */       return param1ArrayOfbyte[param1Int] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int + 2] & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  96 */       return param1ArrayOfbyte[param1Int] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int + 2] & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/* 104 */       return param1ByteBuffer.get(param1Int) & 0xFF | (param1ByteBuffer
/* 105 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/* 106 */         .get(param1Int + 2) & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 112 */       return param1ByteBuffer.get(param1Int) & 0xFF | (param1ByteBuffer
/* 113 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/* 114 */         .get(param1Int + 2) & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 120 */       param1ArrayOfbyte[param1Int1] = (byte)param1Int2;
/* 121 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)(param1Int2 >> 8);
/* 122 */       param1ArrayOfbyte[param1Int1 + 2] = (byte)(param1Int2 >> 16);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 127 */       setArgb(param1ArrayOfbyte, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 132 */       param1ByteBuffer.put(param1Int1, (byte)param1Int2);
/* 133 */       param1ByteBuffer.put(param1Int1 + 1, (byte)(param1Int2 >> 8));
/* 134 */       param1ByteBuffer.put(param1Int1 + 2, (byte)(param1Int2 >> 16));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 139 */       setArgb(param1ByteBuffer, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgrfConv extends BaseByteToByteConverter {
/* 144 */     public static final ByteToBytePixelConverter nonpremult = new ToByteBgrfConv(ByteBgra.setter);
/*     */     
/* 146 */     public static final ByteToBytePixelConverter premult = new ToByteBgrfConv(ByteBgraPre.setter);
/*     */ 
/*     */     
/*     */     private ToByteBgrfConv(BytePixelSetter param1BytePixelSetter) {
/* 150 */       super(ByteBgr.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 158 */       param1Int2 -= param1Int5 * 3;
/* 159 */       param1Int4 -= param1Int5 * 4;
/* 160 */       while (--param1Int6 >= 0) {
/* 161 */         for (byte b = 0; b < param1Int5; b++) {
/* 162 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/* 163 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/* 164 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/* 165 */           param1ArrayOfbyte2[param1Int3++] = -1;
/*     */         } 
/* 167 */         param1Int1 += param1Int2;
/* 168 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 177 */       param1Int2 -= param1Int5 * 3;
/* 178 */       param1Int4 -= param1Int5 * 4;
/* 179 */       while (--param1Int6 >= 0) {
/* 180 */         for (byte b = 0; b < param1Int5; b++) {
/* 181 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/* 182 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/* 183 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/* 184 */           param1ByteBuffer2.put(param1Int3++, (byte)-1);
/*     */         } 
/* 186 */         param1Int1 += param1Int2;
/* 187 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntFrgbConv extends BaseByteToIntConverter {
/* 193 */     public static final ByteToIntPixelConverter nonpremult = new ToIntFrgbConv(IntArgb.setter);
/*     */     
/* 195 */     public static final ByteToIntPixelConverter premult = new ToIntFrgbConv(IntArgbPre.setter);
/*     */ 
/*     */     
/*     */     private ToIntFrgbConv(IntPixelSetter param1IntPixelSetter) {
/* 199 */       super(ByteBgr.getter, param1IntPixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 207 */       param1Int2 -= param1Int5 * 3;
/* 208 */       while (--param1Int6 >= 0) {
/* 209 */         for (byte b = 0; b < param1Int5; b++) {
/* 210 */           int i = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 211 */           int j = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 212 */           int k = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 213 */           param1ArrayOfint[param1Int3 + b] = 0xFF000000 | k << 16 | j << 8 | i;
/*     */         } 
/* 215 */         param1Int1 += param1Int2;
/* 216 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 225 */       param1Int2 -= param1Int5 * 3;
/* 226 */       while (--param1Int6 >= 0) {
/* 227 */         for (byte b = 0; b < param1Int5; b++) {
/* 228 */           int i = param1ByteBuffer.get(param1Int1++) & 0xFF;
/* 229 */           int j = param1ByteBuffer.get(param1Int1++) & 0xFF;
/* 230 */           int k = param1ByteBuffer.get(param1Int1++) & 0xFF;
/* 231 */           param1IntBuffer.put(param1Int3 + b, 0xFF000000 | k << 16 | j << 8 | i);
/*     */         } 
/* 233 */         param1Int1 += param1Int2;
/* 234 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteFrgbConv extends BaseByteToByteConverter {
/* 240 */     static final ByteToBytePixelConverter nonpremult = new ToByteFrgbConv(ByteArgb.setter);
/*     */ 
/*     */     
/*     */     private ToByteFrgbConv(BytePixelSetter param1BytePixelSetter) {
/* 244 */       super(ByteBgr.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 252 */       param1Int2 -= param1Int5 * 3;
/* 253 */       param1Int2 -= param1Int5 * 4;
/* 254 */       while (--param1Int6 >= 0) {
/* 255 */         for (byte b = 0; b < param1Int5; b++) {
/* 256 */           param1ArrayOfbyte2[param1Int3++] = -1;
/* 257 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 2];
/* 258 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 1];
/* 259 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1];
/* 260 */           param1Int1 += 3;
/*     */         } 
/* 262 */         param1Int1 += param1Int2;
/* 263 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 272 */       param1Int2 -= param1Int5 * 3;
/* 273 */       param1Int2 -= param1Int5 * 4;
/* 274 */       while (--param1Int6 >= 0) {
/* 275 */         for (byte b = 0; b < param1Int5; b++) {
/* 276 */           param1ByteBuffer2.put(param1Int3++, (byte)-1);
/* 277 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1 + 2));
/* 278 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1 + 1));
/* 279 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1));
/* 280 */           param1Int1 += 3;
/*     */         } 
/* 282 */         param1Int1 += param1Int2;
/* 283 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteBgr.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */