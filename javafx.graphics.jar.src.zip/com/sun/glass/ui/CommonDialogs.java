/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonDialogs
/*     */ {
/*     */   public static final class Type
/*     */   {
/*     */     public static final int OPEN = 0;
/*     */     public static final int SAVE = 1;
/*     */   }
/*     */   
/*     */   public static final class ExtensionFilter
/*     */   {
/*     */     private final String description;
/*     */     private final List<String> extensions;
/*     */     
/*     */     public ExtensionFilter(String param1String, List<String> param1List) {
/*  76 */       Application.checkEventThread();
/*  77 */       if (param1String == null || param1String.trim().isEmpty()) {
/*  78 */         throw new IllegalArgumentException("Description parameter must be non-null and not empty");
/*     */       }
/*     */       
/*  81 */       if (param1List == null || param1List.isEmpty()) {
/*  82 */         throw new IllegalArgumentException("Extensions parameter must be non-null and not empty");
/*     */       }
/*     */       
/*  85 */       for (String str : param1List) {
/*  86 */         if (str == null || str.length() == 0) {
/*  87 */           throw new IllegalArgumentException("Each extension must be non-null and not empty");
/*     */         }
/*     */       } 
/*     */       
/*  91 */       this.description = param1String;
/*  92 */       this.extensions = param1List;
/*     */     }
/*     */     
/*     */     public String getDescription() {
/*  96 */       Application.checkEventThread();
/*  97 */       return this.description;
/*     */     }
/*     */     
/*     */     public List<String> getExtensions() {
/* 101 */       Application.checkEventThread();
/* 102 */       return this.extensions;
/*     */     }
/*     */ 
/*     */     
/*     */     private String[] extensionsToArray() {
/* 107 */       Application.checkEventThread();
/* 108 */       return this.extensions.<String>toArray(new String[this.extensions.size()]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class FileChooserResult
/*     */   {
/*     */     private final List<File> files;
/*     */ 
/*     */     
/*     */     private final CommonDialogs.ExtensionFilter filter;
/*     */ 
/*     */ 
/*     */     
/*     */     public FileChooserResult(List<File> param1List, CommonDialogs.ExtensionFilter param1ExtensionFilter) {
/* 124 */       if (param1List == null) {
/* 125 */         throw new NullPointerException("files should not be null");
/*     */       }
/* 127 */       this.files = param1List;
/* 128 */       this.filter = param1ExtensionFilter;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FileChooserResult() {
/* 136 */       this(new ArrayList<>(), null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<File> getFiles() {
/* 151 */       return this.files;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CommonDialogs.ExtensionFilter getExtensionFilter() {
/* 162 */       return this.filter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileChooserResult showFileChooser(Window paramWindow, File paramFile, String paramString1, String paramString2, int paramInt1, boolean paramBoolean, List<ExtensionFilter> paramList, int paramInt2) {
/* 190 */     Application.checkEventThread();
/* 191 */     String str = convertFolder(paramFile);
/* 192 */     if (paramString1 == null) {
/* 193 */       paramString1 = "";
/*     */     }
/*     */     
/* 196 */     if (paramInt1 != 0 && paramInt1 != 1) {
/* 197 */       throw new IllegalArgumentException("Type parameter must be equal to one of the constants from Type");
/*     */     }
/*     */     
/* 200 */     ExtensionFilter[] arrayOfExtensionFilter = null;
/* 201 */     if (paramList != null) {
/* 202 */       arrayOfExtensionFilter = paramList.<ExtensionFilter>toArray(new ExtensionFilter[paramList.size()]);
/*     */     }
/*     */     
/* 205 */     if (paramList == null || paramList
/* 206 */       .isEmpty() || paramInt2 < 0 || paramInt2 >= paramList
/*     */       
/* 208 */       .size()) {
/* 209 */       paramInt2 = 0;
/*     */     }
/*     */     
/* 212 */     return Application.GetApplication()
/* 213 */       .staticCommonDialogs_showFileChooser(paramWindow, str, paramString1, convertTitle(paramString2), paramInt1, paramBoolean, arrayOfExtensionFilter, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File showFolderChooser(Window paramWindow, File paramFile, String paramString) {
/* 226 */     Application.checkEventThread();
/* 227 */     return Application.GetApplication().staticCommonDialogs_showFolderChooser(paramWindow, convertFolder(paramFile), convertTitle(paramString));
/*     */   }
/*     */   
/*     */   private static String convertFolder(File paramFile) {
/* 231 */     if (paramFile != null) {
/* 232 */       if (paramFile.isDirectory()) {
/*     */         try {
/* 234 */           return paramFile.getCanonicalPath();
/* 235 */         } catch (IOException iOException) {
/* 236 */           throw new IllegalArgumentException("Unable to get a canonical path for folder", iOException);
/*     */         } 
/*     */       }
/* 239 */       throw new IllegalArgumentException("Folder parameter must be a valid folder");
/*     */     } 
/*     */ 
/*     */     
/* 243 */     return "";
/*     */   }
/*     */   
/*     */   private static String convertTitle(String paramString) {
/* 247 */     return (paramString != null) ? paramString : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static FileChooserResult createFileChooserResult(String[] paramArrayOfString, ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt) {
/* 254 */     ArrayList<File> arrayList = new ArrayList();
/* 255 */     for (String str : paramArrayOfString) {
/* 256 */       if (str != null) {
/* 257 */         arrayList.add(new File(str));
/*     */       }
/*     */     } 
/* 260 */     return new FileChooserResult(arrayList, (
/* 261 */         paramArrayOfExtensionFilter == null || paramInt < 0 || paramInt >= paramArrayOfExtensionFilter.length) ? 
/* 262 */         null : paramArrayOfExtensionFilter[paramInt]);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\CommonDialogs.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */