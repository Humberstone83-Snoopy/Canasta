/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.html.HTMLButtonElement;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLButtonElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLButtonElement
/*     */ {
/*     */   HTMLButtonElementImpl(long paramLong) {
/*  34 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLButtonElement getImpl(long paramLong) {
/*  38 */     return (HTMLButtonElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native boolean getAutofocusImpl(long paramLong);
/*     */   
/*     */   public boolean getAutofocus() {
/*  44 */     return getAutofocusImpl(getPeer());
/*     */   }
/*     */   static native void setAutofocusImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public void setAutofocus(boolean paramBoolean) {
/*  49 */     setAutofocusImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDisabled() {
/*  54 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  59 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public HTMLFormElement getForm() {
/*  64 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   public String getFormAction() {
/*  69 */     return getFormActionImpl(getPeer());
/*     */   }
/*     */   static native String getFormActionImpl(long paramLong);
/*     */   
/*     */   public void setFormAction(String paramString) {
/*  74 */     setFormActionImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormActionImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFormEnctype() {
/*  79 */     return getFormEnctypeImpl(getPeer());
/*     */   }
/*     */   static native String getFormEnctypeImpl(long paramLong);
/*     */   
/*     */   public void setFormEnctype(String paramString) {
/*  84 */     setFormEnctypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormEnctypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFormMethod() {
/*  89 */     return getFormMethodImpl(getPeer());
/*     */   }
/*     */   static native String getFormMethodImpl(long paramLong);
/*     */   
/*     */   public void setFormMethod(String paramString) {
/*  94 */     setFormMethodImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormMethodImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/*  99 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 104 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getFormNoValidate() {
/* 109 */     return getFormNoValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getFormNoValidateImpl(long paramLong);
/*     */   
/*     */   public void setFormNoValidate(boolean paramBoolean) {
/* 114 */     setFormNoValidateImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setFormNoValidateImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getFormTarget() {
/* 119 */     return getFormTargetImpl(getPeer());
/*     */   }
/*     */   static native String getFormTargetImpl(long paramLong);
/*     */   
/*     */   public void setFormTarget(String paramString) {
/* 124 */     setFormTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getName() {
/* 129 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 134 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getValue() {
/* 139 */     return getValueImpl(getPeer());
/*     */   }
/*     */   static native String getValueImpl(long paramLong);
/*     */   
/*     */   public void setValue(String paramString) {
/* 144 */     setValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getWillValidate() {
/* 149 */     return getWillValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getWillValidateImpl(long paramLong);
/*     */   
/*     */   public String getValidationMessage() {
/* 154 */     return getValidationMessageImpl(getPeer());
/*     */   }
/*     */   static native String getValidationMessageImpl(long paramLong);
/*     */   
/*     */   public NodeList getLabels() {
/* 159 */     return NodeListImpl.getImpl(getLabelsImpl(getPeer()));
/*     */   }
/*     */   static native long getLabelsImpl(long paramLong);
/*     */   
/*     */   public String getAccessKey() {
/* 164 */     return getAccessKeyImpl(getPeer());
/*     */   }
/*     */   static native String getAccessKeyImpl(long paramLong);
/*     */   
/*     */   public void setAccessKey(String paramString) {
/* 169 */     setAccessKeyImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 177 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */   
/*     */   public void setCustomValidity(String paramString) {
/* 184 */     setCustomValidityImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void click() {
/* 193 */     clickImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native void clickImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLButtonElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */