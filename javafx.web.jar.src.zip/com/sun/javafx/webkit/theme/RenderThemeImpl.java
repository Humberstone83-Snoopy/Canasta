/*     */ package com.sun.javafx.webkit.theme;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.webkit.Accessor;
/*     */ import com.sun.webkit.LoadListenerClient;
/*     */ import com.sun.webkit.graphics.Ref;
/*     */ import com.sun.webkit.graphics.RenderTheme;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCSize;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.application.Application;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.geometry.Orientation;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.Control;
/*     */ import javafx.scene.control.ProgressBar;
/*     */ import javafx.scene.control.RadioButton;
/*     */ import javafx.scene.control.SkinBase;
/*     */ import javafx.scene.control.Slider;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.scene.layout.BorderPane;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RenderThemeImpl
/*     */   extends RenderTheme
/*     */ {
/*     */   private Accessor accessor;
/*     */   private boolean isDefault;
/*  62 */   private static final PlatformLogger log = PlatformLogger.getLogger(RenderThemeImpl.class.getName());
/*     */   private Pool<FormControl> pool;
/*     */   
/*  65 */   enum WidgetType { TEXTFIELD(0),
/*  66 */     BUTTON(1),
/*  67 */     CHECKBOX(2),
/*  68 */     RADIOBUTTON(3),
/*  69 */     MENULIST(4),
/*  70 */     MENULISTBUTTON(5),
/*  71 */     SLIDER(6),
/*  72 */     PROGRESSBAR(7),
/*  73 */     METER(8),
/*  74 */     SCROLLBAR(9);
/*     */     
/*  76 */     private static final HashMap<Integer, WidgetType> map = new HashMap<>();
/*     */     private final int value;
/*     */     
/*     */     static
/*     */     {
/*  81 */       for (WidgetType widgetType : values()) map.put(Integer.valueOf(widgetType.value), widgetType); 
/*     */     } private static WidgetType convert(int param1Int) {
/*  83 */       return map.get(Integer.valueOf(param1Int));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     WidgetType(int param1Int1) {
/*     */       this.value = param1Int1;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Pool<T extends Widget>
/*     */   {
/*     */     private static final int INITIAL_CAPACITY = 100;
/*     */ 
/*     */     
/* 100 */     private int capacity = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     private final LinkedHashMap<Long, Integer> ids = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */     
/* 110 */     private final Map<Long, WeakReference<T>> pool = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/*     */     private final Notifier<T> notifier;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Pool(Notifier<T> param1Notifier, Class<T> param1Class) {
/* 124 */       this.notifier = param1Notifier;
/* 125 */       this.type = param1Class.getSimpleName();
/*     */     }
/*     */     
/*     */     T get(long param1Long) {
/* 129 */       if (RenderThemeImpl.log.isLoggable(PlatformLogger.Level.FINE)) {
/* 130 */         RenderThemeImpl.log.fine("type: {0}, size: {1}, id: 0x{2}", new Object[] { this.type, 
/* 131 */               Integer.valueOf(this.pool.size()), Long.toHexString(param1Long) });
/*     */       }
/* 133 */       assert this.ids.size() == this.pool.size();
/*     */       
/* 135 */       WeakReference<RenderThemeImpl.Widget> weakReference = this.pool.get(Long.valueOf(param1Long));
/* 136 */       if (weakReference == null) {
/* 137 */         return null;
/*     */       }
/*     */       
/* 140 */       RenderThemeImpl.Widget widget = weakReference.get();
/* 141 */       if (widget == null) {
/* 142 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 146 */       Integer integer = this.ids.remove(Long.valueOf(param1Long));
/* 147 */       this.ids.put(Long.valueOf(param1Long), integer);
/*     */       
/* 149 */       return (T)widget;
/*     */     }
/*     */     
/*     */     void put(long param1Long, T param1T, int param1Int) {
/* 153 */       if (RenderThemeImpl.log.isLoggable(PlatformLogger.Level.FINEST))
/* 154 */         RenderThemeImpl.log.finest("size: {0}, id: 0x{1}, control: {2}", new Object[] {
/* 155 */               Integer.valueOf(this.pool.size()), Long.toHexString(param1Long), param1T.getType()
/*     */             }); 
/* 157 */       if (this.ids.size() >= this.capacity) {
/*     */         
/* 159 */         Long long_ = this.ids.keySet().iterator().next();
/* 160 */         Integer integer = this.ids.get(long_);
/*     */ 
/*     */         
/* 163 */         if (integer.intValue() != param1Int) {
/* 164 */           this.ids.remove(long_);
/* 165 */           RenderThemeImpl.Widget widget = ((WeakReference<RenderThemeImpl.Widget>)this.pool.remove(long_)).get();
/* 166 */           if (widget != null) {
/* 167 */             this.notifier.notifyRemoved((T)widget);
/*     */           }
/*     */         } else {
/*     */           
/* 171 */           this.capacity = Math.min(this.capacity, (int)Math.ceil(1.073741823E9D)) * 2;
/*     */         } 
/*     */       } 
/* 174 */       this.ids.put(Long.valueOf(param1Long), Integer.valueOf(param1Int));
/* 175 */       this.pool.put(Long.valueOf(param1Long), new WeakReference<>(param1T));
/*     */     }
/*     */     
/*     */     void clear() {
/* 179 */       if (RenderThemeImpl.log.isLoggable(PlatformLogger.Level.FINE)) {
/* 180 */         RenderThemeImpl.log.fine("size: " + this.pool.size() + ", controls: " + this.pool.values());
/*     */       }
/* 182 */       if (this.pool.size() == 0) {
/*     */         return;
/*     */       }
/* 185 */       this.ids.clear();
/* 186 */       for (WeakReference<RenderThemeImpl.Widget> weakReference : this.pool.values()) {
/* 187 */         RenderThemeImpl.Widget widget = weakReference.get();
/* 188 */         if (widget != null) {
/* 189 */           this.notifier.notifyRemoved((T)widget);
/*     */         }
/*     */       } 
/* 192 */       this.pool.clear();
/* 193 */       this.capacity = 100;
/*     */     }
/*     */     
/*     */     static interface Notifier<T> { void notifyRemoved(T param2T); }
/*     */   }
/*     */   
/*     */   static class ViewListener implements InvalidationListener {
/*     */     private final RenderThemeImpl.Pool pool;
/*     */     
/*     */     ViewListener(RenderThemeImpl.Pool param1Pool, Accessor param1Accessor) {
/* 203 */       this.pool = param1Pool;
/* 204 */       this.accessor = param1Accessor;
/*     */     }
/*     */     private final Accessor accessor; private LoadListenerClient loadListener;
/*     */     public void invalidated(Observable param1Observable) {
/* 208 */       this.pool.clear();
/*     */ 
/*     */       
/* 211 */       if (this.accessor.getPage() != null && this.loadListener == null) {
/* 212 */         this.loadListener = new LoadListenerClient()
/*     */           {
/*     */             
/*     */             public void dispatchLoadEvent(long param2Long, int param2Int1, String param2String1, String param2String2, double param2Double, int param2Int2)
/*     */             {
/* 217 */               if (param2Int1 == 0)
/*     */               {
/*     */                 
/* 220 */                 RenderThemeImpl.ViewListener.this.pool.clear();
/*     */               }
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void dispatchResourceLoadEvent(long param2Long, int param2Int1, String param2String1, String param2String2, double param2Double, int param2Int2) {}
/*     */           };
/* 228 */         this.accessor.getPage().addLoadListenerClient(this.loadListener);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public RenderThemeImpl(Accessor paramAccessor) {
/* 234 */     this.accessor = paramAccessor;
/* 235 */     this.pool = new Pool<>(paramFormControl -> paramAccessor.removeChild(paramFormControl.asControl()), FormControl.class);
/*     */ 
/*     */ 
/*     */     
/* 239 */     paramAccessor.addViewListener(new ViewListener(this.pool, paramAccessor));
/*     */   }
/*     */   
/*     */   public RenderThemeImpl() {
/* 243 */     this.isDefault = true;
/*     */   }
/*     */   
/*     */   private void ensureNotDefault() {
/* 247 */     if (this.isDefault) {
/* 248 */       throw new IllegalStateException("the method should not be called in this context");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Ref createWidget(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ByteBuffer paramByteBuffer) {
/* 261 */     ensureNotDefault();
/*     */     
/* 263 */     FormControl formControl = this.pool.get(paramLong);
/* 264 */     WidgetType widgetType = WidgetType.convert(paramInt1);
/*     */     
/* 266 */     if (formControl == null || formControl.getType() != widgetType) {
/* 267 */       if (formControl != null)
/*     */       {
/* 269 */         this.accessor.removeChild(formControl.asControl());
/*     */       }
/* 271 */       switch (widgetType) {
/*     */         case TEXTFIELD:
/* 273 */           formControl = new FormTextField();
/*     */           break;
/*     */         case BUTTON:
/* 276 */           formControl = new FormButton();
/*     */           break;
/*     */         case CHECKBOX:
/* 279 */           formControl = new FormCheckBox();
/*     */           break;
/*     */         case RADIOBUTTON:
/* 282 */           formControl = new FormRadioButton();
/*     */           break;
/*     */         case MENULIST:
/* 285 */           formControl = new FormMenuList();
/*     */           break;
/*     */         case MENULISTBUTTON:
/* 288 */           formControl = new FormMenuListButton();
/*     */           break;
/*     */         case SLIDER:
/* 291 */           formControl = new FormSlider();
/*     */           break;
/*     */         case PROGRESSBAR:
/* 294 */           formControl = new FormProgressBar(WidgetType.PROGRESSBAR);
/*     */           break;
/*     */         case METER:
/* 297 */           formControl = new FormProgressBar(WidgetType.METER);
/*     */           break;
/*     */         default:
/* 300 */           log.severe("unknown widget index: {0}", new Object[] { Integer.valueOf(paramInt1) });
/* 301 */           return null;
/*     */       } 
/* 303 */       formControl.asControl().setFocusTraversable(false);
/* 304 */       this.pool.put(paramLong, formControl, this.accessor.getPage().getUpdateContentCycleID());
/* 305 */       this.accessor.addChild(formControl.asControl());
/*     */     } 
/*     */     
/* 308 */     formControl.setState(paramInt2);
/* 309 */     Control control = formControl.asControl();
/* 310 */     if (control.getWidth() != paramInt3 || control.getHeight() != paramInt4) {
/* 311 */       control.resize(paramInt3, paramInt4);
/*     */     }
/* 313 */     if (control.isManaged()) {
/* 314 */       control.setManaged(false);
/*     */     }
/*     */     
/* 317 */     if (paramByteBuffer != null) {
/* 318 */       if (widgetType == WidgetType.SLIDER) {
/* 319 */         Slider slider = (Slider)control;
/* 320 */         paramByteBuffer.order(ByteOrder.nativeOrder());
/* 321 */         slider.setOrientation((paramByteBuffer.getInt() == 0) ? 
/* 322 */             Orientation.HORIZONTAL : 
/* 323 */             Orientation.VERTICAL);
/* 324 */         slider.setMax(paramByteBuffer.getFloat());
/* 325 */         slider.setMin(paramByteBuffer.getFloat());
/* 326 */         slider.setValue(paramByteBuffer.getFloat());
/* 327 */       } else if (widgetType == WidgetType.PROGRESSBAR) {
/* 328 */         ProgressBar progressBar = (ProgressBar)control;
/* 329 */         paramByteBuffer.order(ByteOrder.nativeOrder());
/* 330 */         progressBar.setProgress((paramByteBuffer.getInt() == 1) ? 
/* 331 */             paramByteBuffer.getFloat() : 
/* 332 */             -1.0D);
/* 333 */       } else if (widgetType == WidgetType.METER) {
/* 334 */         ProgressBar progressBar = (ProgressBar)control;
/* 335 */         paramByteBuffer.order(ByteOrder.nativeOrder());
/* 336 */         progressBar.setProgress(paramByteBuffer.getFloat());
/* 337 */         progressBar.setStyle(getMeterStyle(paramByteBuffer.getInt()));
/*     */       } 
/*     */     }
/* 340 */     return new FormControlRef(formControl);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getMeterStyle(int paramInt) {
/* 345 */     switch (paramInt) {
/*     */       case 1:
/* 347 */         return "-fx-accent: yellow";
/*     */       case 2:
/* 349 */         return "-fx-accent: red";
/*     */     } 
/* 351 */     return "-fx-accent: green";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawWidget(WCGraphicsContext paramWCGraphicsContext, Ref paramRef, int paramInt1, int paramInt2) {
/* 361 */     ensureNotDefault();
/*     */     
/* 363 */     FormControl formControl = ((FormControlRef)paramRef).asFormControl();
/* 364 */     if (formControl != null) {
/* 365 */       Control control = formControl.asControl();
/* 366 */       if (control != null) {
/* 367 */         paramWCGraphicsContext.saveState();
/* 368 */         paramWCGraphicsContext.translate(paramInt1, paramInt2);
/* 369 */         Renderer.getRenderer().render(control, paramWCGraphicsContext);
/* 370 */         paramWCGraphicsContext.restoreState();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public WCSize getWidgetSize(Ref paramRef) {
/* 377 */     ensureNotDefault();
/*     */     
/* 379 */     FormControl formControl = ((FormControlRef)paramRef).asFormControl();
/* 380 */     if (formControl != null) {
/* 381 */       Control control = formControl.asControl();
/* 382 */       return new WCSize((float)control.getWidth(), (float)control.getHeight());
/*     */     } 
/* 384 */     return new WCSize(0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getRadioButtonSize() {
/* 389 */     String str = Application.getUserAgentStylesheet();
/* 390 */     if ("MODENA".equalsIgnoreCase(str))
/* 391 */       return 20; 
/* 392 */     if ("CASPIAN".equalsIgnoreCase(str)) {
/* 393 */       return 19;
/*     */     }
/* 395 */     return 20;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSelectionColor(int paramInt) {
/* 401 */     switch (paramInt) { case 0:
/* 402 */         return -16739329;
/* 403 */       case 1: return -1; }
/* 404 */      return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean hasState(int paramInt1, int paramInt2) {
/* 409 */     return ((paramInt1 & paramInt2) != 0);
/*     */   }
/*     */   
/*     */   private static final class FormControlRef extends Ref {
/*     */     private final WeakReference<RenderThemeImpl.FormControl> fcRef;
/*     */     
/*     */     private FormControlRef(RenderThemeImpl.FormControl param1FormControl) {
/* 416 */       this.fcRef = new WeakReference<>(param1FormControl);
/*     */     }
/*     */     
/*     */     private RenderThemeImpl.FormControl asFormControl() {
/* 420 */       return this.fcRef.get();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FormButton
/*     */     extends Button
/*     */     implements FormControl
/*     */   {
/*     */     private FormButton() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Control asControl() {
/* 435 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 438 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 439 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 440 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/* 441 */       setPressed(RenderThemeImpl.hasState(param1Int, 16));
/* 442 */       if (isPressed()) { arm(); } else { disarm(); }
/*     */     
/*     */     } public RenderThemeImpl.WidgetType getType() {
/* 445 */       return RenderThemeImpl.WidgetType.BUTTON;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class FormTextField extends TextField implements FormControl {
/*     */     private FormTextField() {
/* 451 */       setStyle("-fx-display-caret: false");
/*     */     }
/*     */     public Control asControl() {
/* 454 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 457 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 458 */       setEditable(RenderThemeImpl.hasState(param1Int, 64));
/* 459 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 460 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 463 */       return RenderThemeImpl.WidgetType.TEXTFIELD;
/*     */     } }
/*     */   private static final class FormCheckBox extends CheckBox implements FormControl { private FormCheckBox() {}
/*     */     
/*     */     public Control asControl() {
/* 468 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 471 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 472 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 473 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/* 474 */       setSelected(RenderThemeImpl.hasState(param1Int, 1));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 477 */       return RenderThemeImpl.WidgetType.CHECKBOX;
/*     */     } }
/*     */   private static final class FormRadioButton extends RadioButton implements FormControl { private FormRadioButton() {}
/*     */     
/*     */     public Control asControl() {
/* 482 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 485 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 486 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 487 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/* 488 */       setSelected(RenderThemeImpl.hasState(param1Int, 1));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 491 */       return RenderThemeImpl.WidgetType.RADIOBUTTON;
/*     */     } }
/*     */   private static final class FormSlider extends Slider implements FormControl { private FormSlider() {}
/*     */     
/*     */     public Control asControl() {
/* 496 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 499 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 500 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 501 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 504 */       return RenderThemeImpl.WidgetType.SLIDER;
/*     */     } }
/*     */   
/*     */   private static final class FormProgressBar extends ProgressBar implements FormControl {
/*     */     private final RenderThemeImpl.WidgetType type;
/*     */     
/*     */     private FormProgressBar(RenderThemeImpl.WidgetType param1WidgetType) {
/* 511 */       this.type = param1WidgetType;
/*     */     }
/*     */     public Control asControl() {
/* 514 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 517 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 518 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 519 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 522 */       return this.type;
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class FormMenuList
/*     */     extends ChoiceBox implements FormControl {
/*     */     private FormMenuList() {
/* 529 */       ArrayList<String> arrayList = new ArrayList();
/* 530 */       arrayList.add("");
/* 531 */       setItems(FXCollections.observableList((List)arrayList));
/*     */     }
/*     */     public Control asControl() {
/* 534 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 537 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 538 */       setFocused(RenderThemeImpl.hasState(param1Int, 8));
/* 539 */       setHover((RenderThemeImpl.hasState(param1Int, 32) && !isDisabled()));
/*     */     }
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 542 */       return RenderThemeImpl.WidgetType.MENULIST;
/*     */     } }
/*     */   
/*     */   private static final class FormMenuListButton extends Button implements FormControl {
/*     */     private static final int MAX_WIDTH = 20;
/*     */     private static final int MIN_WIDTH = 16;
/*     */     
/*     */     public Control asControl() {
/* 550 */       return this;
/*     */     }
/*     */     public void setState(int param1Int) {
/* 553 */       setDisabled(!RenderThemeImpl.hasState(param1Int, 4));
/* 554 */       setHover(RenderThemeImpl.hasState(param1Int, 32));
/* 555 */       setPressed(RenderThemeImpl.hasState(param1Int, 16));
/* 556 */       if (isPressed()) { arm(); } else { disarm(); }
/*     */     
/*     */     }
/*     */     private FormMenuListButton() {
/* 560 */       setSkin(new Skin());
/* 561 */       setFocusTraversable(false);
/* 562 */       getStyleClass().add("form-select-button");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void resize(double param1Double1, double param1Double2) {
/* 570 */       param1Double1 = (param1Double2 > 20.0D) ? 20.0D : ((param1Double2 < 16.0D) ? 16.0D : param1Double2);
/*     */       
/* 572 */       super.resize(param1Double1, param1Double2);
/*     */ 
/*     */ 
/*     */       
/* 576 */       setTranslateX(-param1Double1);
/*     */     }
/*     */     
/*     */     private final class Skin extends SkinBase {
/*     */       Skin() {
/* 581 */         super((C)RenderThemeImpl.FormMenuListButton.this);
/*     */         
/* 583 */         Region region = new Region();
/* 584 */         region.getStyleClass().add("arrow");
/* 585 */         region.setMaxSize(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/* 586 */         BorderPane borderPane = new BorderPane();
/* 587 */         borderPane.setCenter(region);
/* 588 */         getChildren().add(borderPane);
/*     */       } }
/*     */     
/*     */     public RenderThemeImpl.WidgetType getType() {
/* 592 */       return RenderThemeImpl.WidgetType.MENULISTBUTTON;
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface FormControl extends Widget {
/*     */     Control asControl();
/*     */     
/*     */     void setState(int param1Int);
/*     */   }
/*     */   
/*     */   static interface Widget {
/*     */     RenderThemeImpl.WidgetType getType();
/*     */   }
/*     */   
/*     */   static interface Notifier<T> {
/*     */     void notifyRemoved(T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\theme\RenderThemeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */