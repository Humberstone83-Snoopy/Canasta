/*    */ package javafx.scene.media;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubtitleTrack
/*    */   extends Track
/*    */ {
/*    */   SubtitleTrack(long paramLong, Map<String, Object> paramMap) {
/* 37 */     super(paramLong, paramMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\SubtitleTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */