/*    */ package com.sun.javafx.iio.bmp;
/*    */ 
/*    */ import com.sun.javafx.iio.common.ImageTools;
/*    */ import java.io.EOFException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LEInputStream
/*    */ {
/*    */   public final InputStream in;
/*    */   
/*    */   LEInputStream(InputStream paramInputStream) {
/* 51 */     this.in = paramInputStream;
/*    */   }
/*    */   
/*    */   public final short readShort() throws IOException {
/* 55 */     int i = this.in.read();
/* 56 */     int j = this.in.read();
/* 57 */     if ((i | j) < 0) {
/* 58 */       throw new EOFException();
/*    */     }
/* 60 */     return (short)((j << 8) + i);
/*    */   }
/*    */   
/*    */   public final int readInt() throws IOException {
/* 64 */     int i = this.in.read();
/* 65 */     int j = this.in.read();
/* 66 */     int k = this.in.read();
/* 67 */     int m = this.in.read();
/* 68 */     if ((i | j | k | m) < 0) {
/* 69 */       throw new EOFException();
/*    */     }
/* 71 */     return (m << 24) + (k << 16) + (j << 8) + i;
/*    */   }
/*    */   
/*    */   public final void skipBytes(int paramInt) throws IOException {
/* 75 */     ImageTools.skipFully(this.in, paramInt);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\bmp\LEInputStream.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */