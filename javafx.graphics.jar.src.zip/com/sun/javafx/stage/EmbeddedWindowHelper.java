/*    */ package com.sun.javafx.stage;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.stage.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedWindowHelper
/*    */   extends WindowHelper
/*    */ {
/* 41 */   private static final EmbeddedWindowHelper theInstance = new EmbeddedWindowHelper(); static {
/* 42 */     Utils.forceInit(EmbeddedWindow.class);
/*    */   }
/*    */   private static EmbeddedWindowAccessor embeddedWindowAccessor;
/*    */   private static WindowHelper getInstance() {
/* 46 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(EmbeddedWindow paramEmbeddedWindow) {
/* 50 */     setHelper(paramEmbeddedWindow, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void visibleChangingImpl(Window paramWindow, boolean paramBoolean) {
/* 55 */     super.visibleChangingImpl(paramWindow, paramBoolean);
/* 56 */     embeddedWindowAccessor.doVisibleChanging(paramWindow, paramBoolean);
/*    */   }
/*    */   
/*    */   public static void setEmbeddedWindowAccessor(EmbeddedWindowAccessor paramEmbeddedWindowAccessor) {
/* 60 */     if (embeddedWindowAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     embeddedWindowAccessor = paramEmbeddedWindowAccessor;
/*    */   }
/*    */   
/*    */   public static interface EmbeddedWindowAccessor {
/*    */     void doVisibleChanging(Window param1Window, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\stage\EmbeddedWindowHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */