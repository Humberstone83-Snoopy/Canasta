/*      */ package javafx.beans.binding;
/*      */ 
/*      */ import com.sun.javafx.binding.BidirectionalBinding;
/*      */ import com.sun.javafx.binding.BidirectionalContentBinding;
/*      */ import com.sun.javafx.binding.ContentBinding;
/*      */ import com.sun.javafx.binding.DoubleConstant;
/*      */ import com.sun.javafx.binding.FloatConstant;
/*      */ import com.sun.javafx.binding.IntegerConstant;
/*      */ import com.sun.javafx.binding.Logging;
/*      */ import com.sun.javafx.binding.LongConstant;
/*      */ import com.sun.javafx.binding.ObjectConstant;
/*      */ import com.sun.javafx.binding.SelectBinding;
/*      */ import com.sun.javafx.binding.StringConstant;
/*      */ import com.sun.javafx.binding.StringFormatter;
/*      */ import com.sun.javafx.collections.ImmutableObservableList;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.text.Format;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Callable;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.Observable;
/*      */ import javafx.beans.property.Property;
/*      */ import javafx.beans.value.ObservableBooleanValue;
/*      */ import javafx.beans.value.ObservableIntegerValue;
/*      */ import javafx.beans.value.ObservableNumberValue;
/*      */ import javafx.beans.value.ObservableObjectValue;
/*      */ import javafx.beans.value.ObservableStringValue;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableArray;
/*      */ import javafx.collections.ObservableFloatArray;
/*      */ import javafx.collections.ObservableIntegerArray;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.collections.ObservableMap;
/*      */ import javafx.collections.ObservableSet;
/*      */ import javafx.util.StringConverter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Bindings
/*      */ {
/*      */   public static BooleanBinding createBooleanBinding(final Callable<Boolean> func, Observable... dependencies) {
/*  149 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected boolean computeValue()
/*      */         {
/*      */           try {
/*  157 */             return ((Boolean)func.call()).booleanValue();
/*  158 */           } catch (Exception exception) {
/*  159 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  160 */             return false;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  166 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  171 */           return (dependencies == null || dependencies.length == 0) ? 
/*  172 */             FXCollections.emptyObservableList() : (
/*  173 */             (dependencies.length == 1) ? 
/*  174 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  175 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding createDoubleBinding(final Callable<Double> func, Observable... dependencies) {
/*  189 */     return new DoubleBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected double computeValue()
/*      */         {
/*      */           try {
/*  197 */             return ((Double)func.call()).doubleValue();
/*  198 */           } catch (Exception exception) {
/*  199 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  200 */             return 0.0D;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  206 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  211 */           return (dependencies == null || dependencies.length == 0) ? 
/*  212 */             FXCollections.emptyObservableList() : (
/*  213 */             (dependencies.length == 1) ? 
/*  214 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  215 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding createFloatBinding(final Callable<Float> func, Observable... dependencies) {
/*  229 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected float computeValue()
/*      */         {
/*      */           try {
/*  237 */             return ((Float)func.call()).floatValue();
/*  238 */           } catch (Exception exception) {
/*  239 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  240 */             return 0.0F;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  246 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  251 */           return (dependencies == null || dependencies.length == 0) ? 
/*  252 */             FXCollections.emptyObservableList() : (
/*  253 */             (dependencies.length == 1) ? 
/*  254 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  255 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding createIntegerBinding(final Callable<Integer> func, Observable... dependencies) {
/*  269 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected int computeValue()
/*      */         {
/*      */           try {
/*  277 */             return ((Integer)func.call()).intValue();
/*  278 */           } catch (Exception exception) {
/*  279 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  280 */             return 0;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  286 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  291 */           return (dependencies == null || dependencies.length == 0) ? 
/*  292 */             FXCollections.emptyObservableList() : (
/*  293 */             (dependencies.length == 1) ? 
/*  294 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  295 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding createLongBinding(final Callable<Long> func, Observable... dependencies) {
/*  309 */     return new LongBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected long computeValue()
/*      */         {
/*      */           try {
/*  317 */             return ((Long)func.call()).longValue();
/*  318 */           } catch (Exception exception) {
/*  319 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  320 */             return 0L;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  326 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  331 */           return (dependencies == null || dependencies.length == 0) ? 
/*  332 */             FXCollections.emptyObservableList() : (
/*  333 */             (dependencies.length == 1) ? 
/*  334 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  335 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ObjectBinding<T> createObjectBinding(final Callable<T> func, Observable... dependencies) {
/*  350 */     return new ObjectBinding<T>()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected T computeValue()
/*      */         {
/*      */           try {
/*  358 */             return func.call();
/*  359 */           } catch (Exception exception) {
/*  360 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  361 */             return null;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  367 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  372 */           return (dependencies == null || dependencies.length == 0) ? 
/*  373 */             FXCollections.emptyObservableList() : (
/*  374 */             (dependencies.length == 1) ? 
/*  375 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  376 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding createStringBinding(final Callable<String> func, Observable... dependencies) {
/*  390 */     return new StringBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         protected String computeValue()
/*      */         {
/*      */           try {
/*  398 */             return func.call();
/*  399 */           } catch (Exception exception) {
/*  400 */             Logging.getLogger().warning("Exception while evaluating binding", exception);
/*  401 */             return "";
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public void dispose() {
/*  407 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/*  412 */           return (dependencies == null || dependencies.length == 0) ? 
/*  413 */             FXCollections.emptyObservableList() : (
/*  414 */             (dependencies.length == 1) ? 
/*  415 */             FXCollections.singletonObservableList(dependencies[0]) : 
/*  416 */             new ImmutableObservableList((Object[])dependencies));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ObjectBinding<T> select(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  449 */     return new SelectBinding.AsObject<>(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding selectDouble(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  475 */     return new SelectBinding.AsDouble(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding selectFloat(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  501 */     return new SelectBinding.AsFloat(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding selectInteger(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  527 */     return new SelectBinding.AsInteger(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding selectLong(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  553 */     return new SelectBinding.AsLong(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding selectBoolean(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  579 */     return new SelectBinding.AsBoolean(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding selectString(ObservableValue<?> paramObservableValue, String... paramVarArgs) {
/*  605 */     return new SelectBinding.AsString(paramObservableValue, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> ObjectBinding<T> select(Object paramObject, String... paramVarArgs) {
/*  636 */     return new SelectBinding.AsObject<>(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding selectDouble(Object paramObject, String... paramVarArgs) {
/*  666 */     return new SelectBinding.AsDouble(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding selectFloat(Object paramObject, String... paramVarArgs) {
/*  696 */     return new SelectBinding.AsFloat(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding selectInteger(Object paramObject, String... paramVarArgs) {
/*  726 */     return new SelectBinding.AsInteger(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding selectLong(Object paramObject, String... paramVarArgs) {
/*  756 */     return new SelectBinding.AsLong(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding selectBoolean(Object paramObject, String... paramVarArgs) {
/*  786 */     return new SelectBinding.AsBoolean(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding selectString(Object paramObject, String... paramVarArgs) {
/*  816 */     return new SelectBinding.AsString(paramObject, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static When when(ObservableBooleanValue paramObservableBooleanValue) {
/*  830 */     return new When(paramObservableBooleanValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void bindBidirectional(Property<T> paramProperty1, Property<T> paramProperty2) {
/*  868 */     BidirectionalBinding.bind(paramProperty1, paramProperty2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void unbindBidirectional(Property<T> paramProperty1, Property<T> paramProperty2) {
/*  887 */     BidirectionalBinding.unbind(paramProperty1, paramProperty2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unbindBidirectional(Object paramObject1, Object paramObject2) {
/*  906 */     BidirectionalBinding.unbind(paramObject1, paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void bindBidirectional(Property<String> paramProperty, Property<?> paramProperty1, Format paramFormat) {
/*  943 */     BidirectionalBinding.bind(paramProperty, paramProperty1, paramFormat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> void bindBidirectional(Property<String> paramProperty, Property<T> paramProperty1, StringConverter<T> paramStringConverter) {
/*  981 */     BidirectionalBinding.bind(paramProperty, paramProperty1, paramStringConverter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> void bindContentBidirectional(ObservableList<E> paramObservableList1, ObservableList<E> paramObservableList2) {
/* 1020 */     BidirectionalContentBinding.bind(paramObservableList1, paramObservableList2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> void bindContentBidirectional(ObservableSet<E> paramObservableSet1, ObservableSet<E> paramObservableSet2) {
/* 1059 */     BidirectionalContentBinding.bind(paramObservableSet1, paramObservableSet2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> void bindContentBidirectional(ObservableMap<K, V> paramObservableMap1, ObservableMap<K, V> paramObservableMap2) {
/* 1096 */     BidirectionalContentBinding.bind(paramObservableMap1, paramObservableMap2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unbindContentBidirectional(Object paramObject1, Object paramObject2) {
/* 1109 */     BidirectionalContentBinding.unbind(paramObject1, paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> void bindContent(List<E> paramList, ObservableList<? extends E> paramObservableList) {
/* 1132 */     ContentBinding.bind(paramList, paramObservableList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> void bindContent(Set<E> paramSet, ObservableSet<? extends E> paramObservableSet) {
/* 1159 */     ContentBinding.bind(paramSet, paramObservableSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> void bindContent(Map<K, V> paramMap, ObservableMap<? extends K, ? extends V> paramObservableMap) {
/* 1188 */     ContentBinding.bind(paramMap, paramObservableMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unbindContent(Object paramObject1, Object paramObject2) {
/* 1205 */     ContentBinding.unbind(paramObject1, paramObject2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding negate(final ObservableNumberValue value) {
/* 1224 */     if (value == null) {
/* 1225 */       throw new NullPointerException("Operand cannot be null.");
/*      */     }
/*      */     
/* 1228 */     if (value instanceof javafx.beans.value.ObservableDoubleValue)
/* 1229 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1236 */             unbind(new Observable[] { this.val$value });
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 1241 */             return -value.doubleValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1246 */             return FXCollections.singletonObservableList(value);
/*      */           }
/*      */         }; 
/* 1249 */     if (value instanceof javafx.beans.value.ObservableFloatValue)
/* 1250 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1257 */             unbind(new Observable[] { this.val$value });
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 1262 */             return -value.floatValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1267 */             return FXCollections.singletonObservableList(value);
/*      */           }
/*      */         }; 
/* 1270 */     if (value instanceof javafx.beans.value.ObservableLongValue) {
/* 1271 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1278 */             unbind(new Observable[] { this.val$value });
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 1283 */             return -value.longValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1288 */             return FXCollections.singletonObservableList(value);
/*      */           }
/*      */         };
/*      */     }
/* 1292 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 1299 */           unbind(new Observable[] { this.val$value });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 1304 */           return -value.intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 1309 */           return FXCollections.singletonObservableList(value);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding add(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 1319 */     if (op1 == null || op2 == null) {
/* 1320 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 1322 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 1324 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 1325 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1332 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 1337 */             return op1.doubleValue() + op2.doubleValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1342 */             return (dependencies.length == 1) ? 
/* 1343 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1344 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1347 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 1348 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1355 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 1360 */             return op1.floatValue() + op2.floatValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1365 */             return (dependencies.length == 1) ? 
/* 1366 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1367 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1370 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 1371 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1378 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 1383 */             return op1.longValue() + op2.longValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1388 */             return (dependencies.length == 1) ? 
/* 1389 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1390 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 1394 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 1401 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 1406 */           return op1.intValue() + op2.intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 1411 */           return (dependencies.length == 1) ? 
/* 1412 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 1413 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 1433 */     return add(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding add(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 1450 */     return (DoubleBinding)add(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding add(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 1467 */     return (DoubleBinding)add(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 1484 */     return add(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 1501 */     return add(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 1518 */     return add(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 1535 */     return add(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 1552 */     return add(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding add(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 1569 */     return add(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding subtract(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 1576 */     if (op1 == null || op2 == null) {
/* 1577 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 1579 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 1581 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 1582 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1589 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 1594 */             return op1.doubleValue() - op2.doubleValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1599 */             return (dependencies.length == 1) ? 
/* 1600 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1601 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1604 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 1605 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1612 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 1617 */             return op1.floatValue() - op2.floatValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1622 */             return (dependencies.length == 1) ? 
/* 1623 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1624 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1627 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 1628 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1635 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 1640 */             return op1.longValue() - op2.longValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1645 */             return (dependencies.length == 1) ? 
/* 1646 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1647 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 1651 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 1658 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 1663 */           return op1.intValue() - op2.intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 1668 */           return (dependencies.length == 1) ? 
/* 1669 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 1670 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 1690 */     return subtract(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding subtract(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 1707 */     return (DoubleBinding)subtract(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding subtract(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 1724 */     return (DoubleBinding)subtract(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 1741 */     return subtract(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 1758 */     return subtract(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 1775 */     return subtract(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 1792 */     return subtract(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 1809 */     return subtract(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding subtract(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 1826 */     return subtract(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding multiply(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 1833 */     if (op1 == null || op2 == null) {
/* 1834 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 1836 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 1838 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 1839 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1846 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 1851 */             return op1.doubleValue() * op2.doubleValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1856 */             return (dependencies.length == 1) ? 
/* 1857 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1858 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1861 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 1862 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1869 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 1874 */             return op1.floatValue() * op2.floatValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1879 */             return (dependencies.length == 1) ? 
/* 1880 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1881 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 1884 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 1885 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 1892 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 1897 */             return op1.longValue() * op2.longValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 1902 */             return (dependencies.length == 1) ? 
/* 1903 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 1904 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 1908 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 1915 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 1920 */           return op1.intValue() * op2.intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 1925 */           return (dependencies.length == 1) ? 
/* 1926 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 1927 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 1947 */     return multiply(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding multiply(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 1964 */     return (DoubleBinding)multiply(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding multiply(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 1981 */     return (DoubleBinding)multiply(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 1998 */     return multiply(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 2015 */     return multiply(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 2032 */     return multiply(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 2049 */     return multiply(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 2066 */     return multiply(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding multiply(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 2083 */     return multiply(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding divide(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 2090 */     if (op1 == null || op2 == null) {
/* 2091 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 2093 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 2095 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 2096 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2103 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 2108 */             return op1.doubleValue() / op2.doubleValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2113 */             return (dependencies.length == 1) ? 
/* 2114 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2115 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2118 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 2119 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2126 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 2131 */             return op1.floatValue() / op2.floatValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2136 */             return (dependencies.length == 1) ? 
/* 2137 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2138 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2141 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 2142 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2149 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 2154 */             return op1.longValue() / op2.longValue();
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2159 */             return (dependencies.length == 1) ? 
/* 2160 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2161 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 2165 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 2172 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 2177 */           return op1.intValue() / op2.intValue();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 2182 */           return (dependencies.length == 1) ? 
/* 2183 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 2184 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 2204 */     return divide(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding divide(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 2221 */     return (DoubleBinding)divide(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding divide(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 2238 */     return (DoubleBinding)divide(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 2255 */     return divide(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 2272 */     return divide(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 2289 */     return divide(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 2306 */     return divide(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 2323 */     return divide(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding divide(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 2340 */     return divide(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding equal(final ObservableNumberValue op1, final ObservableNumberValue op2, final double epsilon, Observable... dependencies) {
/* 2347 */     if (op1 == null || op2 == null) {
/* 2348 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 2350 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 2352 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 2353 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2360 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2365 */             return (Math.abs(op1.doubleValue() - op2.doubleValue()) <= epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2370 */             return (dependencies.length == 1) ? 
/* 2371 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2372 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2375 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 2376 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2383 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2388 */             return (Math.abs(op1.floatValue() - op2.floatValue()) <= epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2393 */             return (dependencies.length == 1) ? 
/* 2394 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2395 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2398 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 2399 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2406 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2411 */             return (Math.abs(op1.longValue() - op2.longValue()) <= epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2416 */             return (dependencies.length == 1) ? 
/* 2417 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2418 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 2422 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 2429 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 2434 */           return (Math.abs(op1.intValue() - op2.intValue()) <= epsilon);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 2439 */           return (dependencies.length == 1) ? 
/* 2440 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 2441 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2, double paramDouble) {
/* 2470 */     return equal(paramObservableNumberValue1, paramObservableNumberValue2, paramDouble, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 2491 */     return equal(paramObservableNumberValue1, paramObservableNumberValue2, 0.0D, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, double paramDouble1, double paramDouble2) {
/* 2516 */     return equal(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble1), paramDouble2, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(double paramDouble1, ObservableNumberValue paramObservableNumberValue, double paramDouble2) {
/* 2541 */     return equal(DoubleConstant.valueOf(paramDouble1), paramObservableNumberValue, paramDouble2, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, float paramFloat, double paramDouble) {
/* 2566 */     return equal(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(float paramFloat, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 2591 */     return equal(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, long paramLong, double paramDouble) {
/* 2616 */     return equal(paramObservableNumberValue, LongConstant.valueOf(paramLong), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 2637 */     return equal(paramObservableNumberValue, LongConstant.valueOf(paramLong), 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(long paramLong, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 2662 */     return equal(LongConstant.valueOf(paramLong), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 2683 */     return equal(LongConstant.valueOf(paramLong), paramObservableNumberValue, 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, int paramInt, double paramDouble) {
/* 2708 */     return equal(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 2729 */     return equal(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(int paramInt, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 2754 */     return equal(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 2775 */     return equal(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding notEqual(final ObservableNumberValue op1, final ObservableNumberValue op2, final double epsilon, Observable... dependencies) {
/* 2782 */     if (op1 == null || op2 == null) {
/* 2783 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 2785 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 2787 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 2788 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2795 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2800 */             return (Math.abs(op1.doubleValue() - op2.doubleValue()) > epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2805 */             return (dependencies.length == 1) ? 
/* 2806 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2807 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2810 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 2811 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2818 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2823 */             return (Math.abs(op1.floatValue() - op2.floatValue()) > epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2828 */             return (dependencies.length == 1) ? 
/* 2829 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2830 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 2833 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 2834 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 2841 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 2846 */             return (Math.abs(op1.longValue() - op2.longValue()) > epsilon);
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 2851 */             return (dependencies.length == 1) ? 
/* 2852 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 2853 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 2857 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 2864 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 2869 */           return (Math.abs(op1.intValue() - op2.intValue()) > epsilon);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 2874 */           return (dependencies.length == 1) ? 
/* 2875 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 2876 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2, double paramDouble) {
/* 2905 */     return notEqual(paramObservableNumberValue1, paramObservableNumberValue2, paramDouble, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 2926 */     return notEqual(paramObservableNumberValue1, paramObservableNumberValue2, 0.0D, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, double paramDouble1, double paramDouble2) {
/* 2951 */     return notEqual(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble1), paramDouble2, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(double paramDouble1, ObservableNumberValue paramObservableNumberValue, double paramDouble2) {
/* 2976 */     return notEqual(DoubleConstant.valueOf(paramDouble1), paramObservableNumberValue, paramDouble2, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, float paramFloat, double paramDouble) {
/* 3001 */     return notEqual(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(float paramFloat, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3026 */     return notEqual(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, long paramLong, double paramDouble) {
/* 3051 */     return notEqual(paramObservableNumberValue, LongConstant.valueOf(paramLong), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 3072 */     return notEqual(paramObservableNumberValue, LongConstant.valueOf(paramLong), 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(long paramLong, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3097 */     return notEqual(LongConstant.valueOf(paramLong), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 3118 */     return notEqual(LongConstant.valueOf(paramLong), paramObservableNumberValue, 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, int paramInt, double paramDouble) {
/* 3143 */     return notEqual(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 3164 */     return notEqual(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(int paramInt, ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3189 */     return notEqual(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, paramDouble, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 3210 */     return notEqual(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, 0.0D, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding greaterThan(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 3217 */     if (op1 == null || op2 == null) {
/* 3218 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 3220 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 3222 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 3223 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3230 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3235 */             return (op1.doubleValue() > op2.doubleValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3240 */             return (dependencies.length == 1) ? 
/* 3241 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3242 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 3245 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 3246 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3253 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3258 */             return (op1.floatValue() > op2.floatValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3263 */             return (dependencies.length == 1) ? 
/* 3264 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3265 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 3268 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 3269 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3276 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3281 */             return (op1.longValue() > op2.longValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3286 */             return (dependencies.length == 1) ? 
/* 3287 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3288 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 3292 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 3299 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 3304 */           return (op1.intValue() > op2.intValue());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 3309 */           return (dependencies.length == 1) ? 
/* 3310 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 3311 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 3332 */     return greaterThan(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3349 */     return greaterThan(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 3366 */     return greaterThan(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 3383 */     return greaterThan(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 3400 */     return greaterThan(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 3417 */     return greaterThan(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 3434 */     return greaterThan(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 3451 */     return greaterThan(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 3468 */     return greaterThan(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2, Observable... paramVarArgs) {
/* 3475 */     return greaterThan(paramObservableNumberValue2, paramObservableNumberValue1, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 3493 */     return lessThan(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3510 */     return lessThan(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 3527 */     return lessThan(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 3544 */     return lessThan(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 3561 */     return lessThan(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 3578 */     return lessThan(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 3595 */     return lessThan(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 3612 */     return lessThan(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 3629 */     return lessThan(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding greaterThanOrEqual(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 3636 */     if (op1 == null || op2 == null) {
/* 3637 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 3639 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 3641 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 3642 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3649 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3654 */             return (op1.doubleValue() >= op2.doubleValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3659 */             return (dependencies.length == 1) ? 
/* 3660 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3661 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 3664 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 3665 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3672 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3677 */             return (op1.floatValue() >= op2.floatValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3682 */             return (dependencies.length == 1) ? 
/* 3683 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3684 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 3687 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 3688 */       return new BooleanBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 3695 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected boolean computeValue() {
/* 3700 */             return (op1.longValue() >= op2.longValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 3705 */             return (dependencies.length == 1) ? 
/* 3706 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 3707 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 3711 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 3718 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 3723 */           return (op1.intValue() >= op2.intValue());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 3728 */           return (dependencies.length == 1) ? 
/* 3729 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 3730 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 3751 */     return greaterThanOrEqual(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3768 */     return greaterThanOrEqual(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 3785 */     return greaterThanOrEqual(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 3802 */     return greaterThanOrEqual(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 3819 */     return greaterThanOrEqual(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 3836 */     return greaterThanOrEqual(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 3853 */     return greaterThanOrEqual(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 3870 */     return greaterThanOrEqual(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 3887 */     return greaterThanOrEqual(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2, Observable... paramVarArgs) {
/* 3894 */     return greaterThanOrEqual(paramObservableNumberValue2, paramObservableNumberValue1, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 3913 */     return lessThanOrEqual(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 3930 */     return lessThanOrEqual(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 3947 */     return lessThanOrEqual(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 3964 */     return lessThanOrEqual(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 3981 */     return lessThanOrEqual(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 3998 */     return lessThanOrEqual(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 4015 */     return lessThanOrEqual(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 4032 */     return lessThanOrEqual(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 4049 */     return lessThanOrEqual(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding min(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 4056 */     if (op1 == null || op2 == null) {
/* 4057 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 4059 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 4061 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 4062 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4069 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 4074 */             return Math.min(op1.doubleValue(), op2.doubleValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4079 */             return (dependencies.length == 1) ? 
/* 4080 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4081 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 4084 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 4085 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4092 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 4097 */             return Math.min(op1.floatValue(), op2.floatValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4102 */             return (dependencies.length == 1) ? 
/* 4103 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4104 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 4107 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 4108 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4115 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 4120 */             return Math.min(op1.longValue(), op2.longValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4125 */             return (dependencies.length == 1) ? 
/* 4126 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4127 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 4131 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4138 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 4143 */           return Math.min(op1.intValue(), op2.intValue());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4148 */           return (dependencies.length == 1) ? 
/* 4149 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 4150 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 4170 */     return min(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding min(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 4187 */     return (DoubleBinding)min(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding min(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 4204 */     return (DoubleBinding)min(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 4221 */     return min(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 4238 */     return min(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 4255 */     return min(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 4272 */     return min(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 4289 */     return min(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding min(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 4306 */     return min(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NumberBinding max(final ObservableNumberValue op1, final ObservableNumberValue op2, Observable... dependencies) {
/* 4313 */     if (op1 == null || op2 == null) {
/* 4314 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 4316 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 4318 */     if (op1 instanceof javafx.beans.value.ObservableDoubleValue || op2 instanceof javafx.beans.value.ObservableDoubleValue)
/* 4319 */       return new DoubleBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4326 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected double computeValue() {
/* 4331 */             return Math.max(op1.doubleValue(), op2.doubleValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4336 */             return (dependencies.length == 1) ? 
/* 4337 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4338 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 4341 */     if (op1 instanceof javafx.beans.value.ObservableFloatValue || op2 instanceof javafx.beans.value.ObservableFloatValue)
/* 4342 */       return new FloatBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4349 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected float computeValue() {
/* 4354 */             return Math.max(op1.floatValue(), op2.floatValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4359 */             return (dependencies.length == 1) ? 
/* 4360 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4361 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         }; 
/* 4364 */     if (op1 instanceof javafx.beans.value.ObservableLongValue || op2 instanceof javafx.beans.value.ObservableLongValue) {
/* 4365 */       return new LongBinding()
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*      */           public void dispose()
/*      */           {
/* 4372 */             unbind(dependencies);
/*      */           }
/*      */ 
/*      */           
/*      */           protected long computeValue() {
/* 4377 */             return Math.max(op1.longValue(), op2.longValue());
/*      */           }
/*      */ 
/*      */           
/*      */           public ObservableList<?> getDependencies() {
/* 4382 */             return (dependencies.length == 1) ? 
/* 4383 */               FXCollections.singletonObservableList(dependencies[0]) : 
/* 4384 */               new ImmutableObservableList((Object[])dependencies);
/*      */           }
/*      */         };
/*      */     }
/* 4388 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4395 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 4400 */           return Math.max(op1.intValue(), op2.intValue());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4405 */           return (dependencies.length == 1) ? 
/* 4406 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 4407 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(ObservableNumberValue paramObservableNumberValue1, ObservableNumberValue paramObservableNumberValue2) {
/* 4427 */     return max(paramObservableNumberValue1, paramObservableNumberValue2, new Observable[] { paramObservableNumberValue1, paramObservableNumberValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding max(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 4444 */     return (DoubleBinding)max(paramObservableNumberValue, DoubleConstant.valueOf(paramDouble), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding max(double paramDouble, ObservableNumberValue paramObservableNumberValue) {
/* 4461 */     return (DoubleBinding)max(DoubleConstant.valueOf(paramDouble), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(ObservableNumberValue paramObservableNumberValue, float paramFloat) {
/* 4478 */     return max(paramObservableNumberValue, FloatConstant.valueOf(paramFloat), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(float paramFloat, ObservableNumberValue paramObservableNumberValue) {
/* 4495 */     return max(FloatConstant.valueOf(paramFloat), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(ObservableNumberValue paramObservableNumberValue, long paramLong) {
/* 4512 */     return max(paramObservableNumberValue, LongConstant.valueOf(paramLong), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(long paramLong, ObservableNumberValue paramObservableNumberValue) {
/* 4529 */     return max(LongConstant.valueOf(paramLong), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(ObservableNumberValue paramObservableNumberValue, int paramInt) {
/* 4546 */     return max(paramObservableNumberValue, IntegerConstant.valueOf(paramInt), new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static NumberBinding max(int paramInt, ObservableNumberValue paramObservableNumberValue) {
/* 4563 */     return max(IntegerConstant.valueOf(paramInt), paramObservableNumberValue, new Observable[] { paramObservableNumberValue });
/*      */   }
/*      */ 
/*      */   
/*      */   private static class BooleanAndBinding
/*      */     extends BooleanBinding
/*      */   {
/*      */     private final ObservableBooleanValue op1;
/*      */     
/*      */     private final ObservableBooleanValue op2;
/*      */     private final InvalidationListener observer;
/*      */     
/*      */     public BooleanAndBinding(ObservableBooleanValue param1ObservableBooleanValue1, ObservableBooleanValue param1ObservableBooleanValue2) {
/* 4576 */       this.op1 = param1ObservableBooleanValue1;
/* 4577 */       this.op2 = param1ObservableBooleanValue2;
/*      */       
/* 4579 */       this.observer = new Bindings.ShortCircuitAndInvalidator(this);
/*      */       
/* 4581 */       param1ObservableBooleanValue1.addListener(this.observer);
/* 4582 */       param1ObservableBooleanValue2.addListener(this.observer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 4588 */       this.op1.removeListener(this.observer);
/* 4589 */       this.op2.removeListener(this.observer);
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean computeValue() {
/* 4594 */       return (this.op1.get() && this.op2.get());
/*      */     }
/*      */ 
/*      */     
/*      */     public ObservableList<?> getDependencies() {
/* 4599 */       return new ImmutableObservableList((Object[])new ObservableBooleanValue[] { this.op1, this.op2 });
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ShortCircuitAndInvalidator
/*      */     implements InvalidationListener {
/*      */     private final WeakReference<Bindings.BooleanAndBinding> ref;
/*      */     
/*      */     private ShortCircuitAndInvalidator(Bindings.BooleanAndBinding param1BooleanAndBinding) {
/* 4608 */       assert param1BooleanAndBinding != null;
/* 4609 */       this.ref = new WeakReference<>(param1BooleanAndBinding);
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidated(Observable param1Observable) {
/* 4614 */       Bindings.BooleanAndBinding booleanAndBinding = this.ref.get();
/* 4615 */       if (booleanAndBinding == null) {
/* 4616 */         param1Observable.removeListener(this);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4621 */       else if (booleanAndBinding.op1.equals(param1Observable) || (booleanAndBinding.isValid() && booleanAndBinding.op1.get())) {
/* 4622 */         booleanAndBinding.invalidate();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding and(ObservableBooleanValue paramObservableBooleanValue1, ObservableBooleanValue paramObservableBooleanValue2) {
/* 4643 */     if (paramObservableBooleanValue1 == null || paramObservableBooleanValue2 == null) {
/* 4644 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 4647 */     return new BooleanAndBinding(paramObservableBooleanValue1, paramObservableBooleanValue2);
/*      */   }
/*      */   
/*      */   private static class BooleanOrBinding
/*      */     extends BooleanBinding {
/*      */     private final ObservableBooleanValue op1;
/*      */     private final ObservableBooleanValue op2;
/*      */     private final InvalidationListener observer;
/*      */     
/*      */     public BooleanOrBinding(ObservableBooleanValue param1ObservableBooleanValue1, ObservableBooleanValue param1ObservableBooleanValue2) {
/* 4657 */       this.op1 = param1ObservableBooleanValue1;
/* 4658 */       this.op2 = param1ObservableBooleanValue2;
/* 4659 */       this.observer = new Bindings.ShortCircuitOrInvalidator(this);
/* 4660 */       param1ObservableBooleanValue1.addListener(this.observer);
/* 4661 */       param1ObservableBooleanValue2.addListener(this.observer);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispose() {
/* 4667 */       this.op1.removeListener(this.observer);
/* 4668 */       this.op2.removeListener(this.observer);
/*      */     }
/*      */ 
/*      */     
/*      */     protected boolean computeValue() {
/* 4673 */       return (this.op1.get() || this.op2.get());
/*      */     }
/*      */ 
/*      */     
/*      */     public ObservableList<?> getDependencies() {
/* 4678 */       return new ImmutableObservableList((Object[])new ObservableBooleanValue[] { this.op1, this.op2 });
/*      */     }
/*      */   }
/*      */   
/*      */   private static class ShortCircuitOrInvalidator
/*      */     implements InvalidationListener
/*      */   {
/*      */     private final WeakReference<Bindings.BooleanOrBinding> ref;
/*      */     
/*      */     private ShortCircuitOrInvalidator(Bindings.BooleanOrBinding param1BooleanOrBinding) {
/* 4688 */       assert param1BooleanOrBinding != null;
/* 4689 */       this.ref = new WeakReference<>(param1BooleanOrBinding);
/*      */     }
/*      */ 
/*      */     
/*      */     public void invalidated(Observable param1Observable) {
/* 4694 */       Bindings.BooleanOrBinding booleanOrBinding = this.ref.get();
/* 4695 */       if (booleanOrBinding == null) {
/* 4696 */         param1Observable.removeListener(this);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4701 */       else if (booleanOrBinding.op1.equals(param1Observable) || (booleanOrBinding.isValid() && !booleanOrBinding.op1.get())) {
/* 4702 */         booleanOrBinding.invalidate();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding or(ObservableBooleanValue paramObservableBooleanValue1, ObservableBooleanValue paramObservableBooleanValue2) {
/* 4723 */     if (paramObservableBooleanValue1 == null || paramObservableBooleanValue2 == null) {
/* 4724 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 4727 */     return new BooleanOrBinding(paramObservableBooleanValue1, paramObservableBooleanValue2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding not(final ObservableBooleanValue op) {
/* 4741 */     if (op == null) {
/* 4742 */       throw new NullPointerException("Operand cannot be null.");
/*      */     }
/*      */     
/* 4745 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4752 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 4757 */           return !op.get();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4762 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(final ObservableBooleanValue op1, final ObservableBooleanValue op2) {
/* 4780 */     if (op1 == null || op2 == null) {
/* 4781 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 4784 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4791 */           unbind(new Observable[] { this.val$op1, this.val$op2 });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 4796 */           return (op1.get() == op2.get());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4801 */           return new ImmutableObservableList((Object[])new ObservableBooleanValue[] { this.val$op1, this.val$op2 });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(final ObservableBooleanValue op1, final ObservableBooleanValue op2) {
/* 4820 */     if (op1 == null || op2 == null) {
/* 4821 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 4824 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4831 */           unbind(new Observable[] { this.val$op1, this.val$op2 });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 4836 */           return (op1.get() != op2.get());
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4841 */           return new ImmutableObservableList((Object[])new ObservableBooleanValue[] { this.val$op1, this.val$op2 });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringExpression convert(ObservableValue<?> paramObservableValue) {
/* 4865 */     return StringFormatter.convert(paramObservableValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringExpression concat(Object... paramVarArgs) {
/* 4886 */     return StringFormatter.concat(paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringExpression format(String paramString, Object... paramVarArgs) {
/* 4909 */     return StringFormatter.format(paramString, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringExpression format(Locale paramLocale, String paramString, Object... paramVarArgs) {
/* 4936 */     return StringFormatter.format(paramLocale, paramString, paramVarArgs);
/*      */   }
/*      */   
/*      */   private static String getStringSafe(String paramString) {
/* 4940 */     return (paramString == null) ? "" : paramString;
/*      */   }
/*      */   
/*      */   private static BooleanBinding equal(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 4944 */     if (op1 == null || op2 == null) {
/* 4945 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 4947 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 4949 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 4956 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 4961 */           String str1 = Bindings.getStringSafe(op1.get());
/* 4962 */           String str2 = Bindings.getStringSafe(op2.get());
/* 4963 */           return str1.equals(str2);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 4968 */           return (dependencies.length == 1) ? 
/* 4969 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 4970 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 4992 */     return equal(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5012 */     return equal(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5032 */     return equal(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding notEqual(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 5036 */     if (op1 == null || op2 == null) {
/* 5037 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5039 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5041 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5048 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5053 */           String str1 = Bindings.getStringSafe(op1.get());
/* 5054 */           String str2 = Bindings.getStringSafe(op2.get());
/* 5055 */           return !str1.equals(str2);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5060 */           return (dependencies.length == 1) ? 
/* 5061 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5062 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5084 */     return notEqual(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5104 */     return notEqual(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5124 */     return notEqual(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding equalIgnoreCase(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 5128 */     if (op1 == null || op2 == null) {
/* 5129 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5131 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5133 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5140 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5145 */           String str1 = Bindings.getStringSafe(op1.get());
/* 5146 */           String str2 = Bindings.getStringSafe(op2.get());
/* 5147 */           return str1.equalsIgnoreCase(str2);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5152 */           return (dependencies.length == 1) ? 
/* 5153 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5154 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equalIgnoreCase(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5176 */     return equalIgnoreCase(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equalIgnoreCase(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5196 */     return equalIgnoreCase(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equalIgnoreCase(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5216 */     return equalIgnoreCase(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding notEqualIgnoreCase(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 5220 */     if (op1 == null || op2 == null) {
/* 5221 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5223 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5225 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5232 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5237 */           String str1 = Bindings.getStringSafe(op1.get());
/* 5238 */           String str2 = Bindings.getStringSafe(op2.get());
/* 5239 */           return !str1.equalsIgnoreCase(str2);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5244 */           return (dependencies.length == 1) ? 
/* 5245 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5246 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqualIgnoreCase(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5269 */     return notEqualIgnoreCase(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqualIgnoreCase(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5289 */     return notEqualIgnoreCase(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqualIgnoreCase(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5309 */     return notEqualIgnoreCase(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding greaterThan(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 5313 */     if (op1 == null || op2 == null) {
/* 5314 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5316 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5318 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5325 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5330 */           String str1 = Bindings.getStringSafe(op1.get());
/* 5331 */           String str2 = Bindings.getStringSafe(op2.get());
/* 5332 */           return (str1.compareTo(str2) > 0);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5337 */           return (dependencies.length == 1) ? 
/* 5338 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5339 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5362 */     return greaterThan(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5382 */     return greaterThan(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThan(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5402 */     return greaterThan(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding lessThan(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2, Observable... paramVarArgs) {
/* 5406 */     return greaterThan(paramObservableStringValue2, paramObservableStringValue1, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5427 */     return lessThan(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5447 */     return lessThan(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThan(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5467 */     return lessThan(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding greaterThanOrEqual(final ObservableStringValue op1, final ObservableStringValue op2, Observable... dependencies) {
/* 5471 */     if (op1 == null || op2 == null) {
/* 5472 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5474 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5476 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5483 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5488 */           String str1 = Bindings.getStringSafe(op1.get());
/* 5489 */           String str2 = Bindings.getStringSafe(op2.get());
/* 5490 */           return (str1.compareTo(str2) >= 0);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5495 */           return (dependencies.length == 1) ? 
/* 5496 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5497 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5520 */     return greaterThanOrEqual(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5540 */     return greaterThanOrEqual(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding greaterThanOrEqual(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5560 */     return greaterThanOrEqual(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding lessThanOrEqual(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2, Observable... paramVarArgs) {
/* 5564 */     return greaterThanOrEqual(paramObservableStringValue2, paramObservableStringValue1, paramVarArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableStringValue paramObservableStringValue1, ObservableStringValue paramObservableStringValue2) {
/* 5585 */     return lessThanOrEqual(paramObservableStringValue1, paramObservableStringValue2, new Observable[] { paramObservableStringValue1, paramObservableStringValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(ObservableStringValue paramObservableStringValue, String paramString) {
/* 5605 */     return lessThanOrEqual(paramObservableStringValue, StringConstant.valueOf(paramString), new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding lessThanOrEqual(String paramString, ObservableStringValue paramObservableStringValue) {
/* 5625 */     return lessThanOrEqual(StringConstant.valueOf(paramString), paramObservableStringValue, new Observable[] { paramObservableStringValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding length(final ObservableStringValue op) {
/* 5643 */     if (op == null) {
/* 5644 */       throw new NullPointerException("Operand cannot be null");
/*      */     }
/*      */     
/* 5647 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5654 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 5659 */           return Bindings.getStringSafe(op.get()).length();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5664 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding isEmpty(final ObservableStringValue op) {
/* 5684 */     if (op == null) {
/* 5685 */       throw new NullPointerException("Operand cannot be null");
/*      */     }
/*      */     
/* 5688 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5695 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5700 */           return Bindings.getStringSafe(op.get()).isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5705 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding isNotEmpty(final ObservableStringValue op) {
/* 5725 */     if (op == null) {
/* 5726 */       throw new NullPointerException("Operand cannot be null");
/*      */     }
/*      */     
/* 5729 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5736 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5741 */           return !Bindings.getStringSafe(op.get()).isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5746 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BooleanBinding equal(final ObservableObjectValue<?> op1, final ObservableObjectValue<?> op2, Observable... dependencies) {
/* 5755 */     if (op1 == null || op2 == null) {
/* 5756 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5758 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5760 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5767 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5772 */           Object object1 = op1.get();
/* 5773 */           Object object2 = op2.get();
/* 5774 */           return (object1 == null) ? ((object2 == null)) : object1.equals(object2);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5779 */           return (dependencies.length == 1) ? 
/* 5780 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5781 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableObjectValue<?> paramObservableObjectValue1, ObservableObjectValue<?> paramObservableObjectValue2) {
/* 5800 */     return equal(paramObservableObjectValue1, paramObservableObjectValue2, new Observable[] { paramObservableObjectValue1, paramObservableObjectValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(ObservableObjectValue<?> paramObservableObjectValue, Object paramObject) {
/* 5817 */     return equal(paramObservableObjectValue, ObjectConstant.valueOf(paramObject), new Observable[] { paramObservableObjectValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding equal(Object paramObject, ObservableObjectValue<?> paramObservableObjectValue) {
/* 5834 */     return equal(ObjectConstant.valueOf(paramObject), paramObservableObjectValue, new Observable[] { paramObservableObjectValue });
/*      */   }
/*      */   
/*      */   private static BooleanBinding notEqual(final ObservableObjectValue<?> op1, final ObservableObjectValue<?> op2, Observable... dependencies) {
/* 5838 */     if (op1 == null || op2 == null) {
/* 5839 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/* 5841 */     assert dependencies != null && dependencies.length > 0;
/*      */     
/* 5843 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5850 */           unbind(dependencies);
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5855 */           Object object1 = op1.get();
/* 5856 */           Object object2 = op2.get();
/* 5857 */           return (object1 == null) ? ((object2 != null)) : (!object1.equals(object2));
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5862 */           return (dependencies.length == 1) ? 
/* 5863 */             FXCollections.singletonObservableList(dependencies[0]) : 
/* 5864 */             new ImmutableObservableList((Object[])dependencies);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableObjectValue<?> paramObservableObjectValue1, ObservableObjectValue<?> paramObservableObjectValue2) {
/* 5883 */     return notEqual(paramObservableObjectValue1, paramObservableObjectValue2, new Observable[] { paramObservableObjectValue1, paramObservableObjectValue2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(ObservableObjectValue<?> paramObservableObjectValue, Object paramObject) {
/* 5900 */     return notEqual(paramObservableObjectValue, ObjectConstant.valueOf(paramObject), new Observable[] { paramObservableObjectValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding notEqual(Object paramObject, ObservableObjectValue<?> paramObservableObjectValue) {
/* 5917 */     return notEqual(ObjectConstant.valueOf(paramObject), paramObservableObjectValue, new Observable[] { paramObservableObjectValue });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding isNull(final ObservableObjectValue<?> op) {
/* 5932 */     if (op == null) {
/* 5933 */       throw new NullPointerException("Operand cannot be null.");
/*      */     }
/*      */     
/* 5936 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5943 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5948 */           return (op.get() == null);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5953 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding isNotNull(final ObservableObjectValue<?> op) {
/* 5970 */     if (op == null) {
/* 5971 */       throw new NullPointerException("Operand cannot be null.");
/*      */     }
/*      */     
/* 5974 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 5981 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 5986 */           return (op.get() != null);
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 5991 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> IntegerBinding size(final ObservableList<E> op) {
/* 6012 */     if (op == null) {
/* 6013 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/*      */     
/* 6016 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6023 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 6028 */           return op.size();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6033 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> BooleanBinding isEmpty(final ObservableList<E> op) {
/* 6051 */     if (op == null) {
/* 6052 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/*      */     
/* 6055 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6062 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 6067 */           return op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6072 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> BooleanBinding isNotEmpty(final ObservableList<E> op) {
/* 6090 */     if (op == null) {
/* 6091 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/*      */     
/* 6094 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6101 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 6106 */           return !op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6111 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObjectBinding<E> valueAt(final ObservableList<E> op, final int index) {
/* 6130 */     if (op == null) {
/* 6131 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6133 */     if (index < 0) {
/* 6134 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6137 */     return new ObjectBinding<E>()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6144 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected E computeValue() {
/*      */           try {
/* 6150 */             return op.get(index);
/* 6151 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6152 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 6154 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6159 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObjectBinding<E> valueAt(ObservableList<E> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6177 */     return valueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> ObjectBinding<E> valueAt(final ObservableList<E> op, final ObservableNumberValue index) {
/* 6193 */     if (op == null || index == null) {
/* 6194 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6197 */     return new ObjectBinding<E>()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6204 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected E computeValue() {
/*      */           try {
/* 6210 */             return op.get(index.intValue());
/* 6211 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6212 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 6214 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6219 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding booleanValueAt(final ObservableList<Boolean> op, final int index) {
/* 6237 */     if (op == null) {
/* 6238 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6240 */     if (index < 0) {
/* 6241 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6244 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6251 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/*      */           try {
/* 6257 */             Boolean bool = op.get(index);
/* 6258 */             if (bool == null) {
/* 6259 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6261 */               return bool.booleanValue();
/*      */             } 
/* 6263 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6264 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6266 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6271 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding booleanValueAt(ObservableList<Boolean> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6288 */     return booleanValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BooleanBinding booleanValueAt(final ObservableList<Boolean> op, final ObservableNumberValue index) {
/* 6303 */     if (op == null || index == null) {
/* 6304 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6307 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6314 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/*      */           try {
/* 6320 */             Boolean bool = op.get(index.intValue());
/* 6321 */             if (bool == null) {
/* 6322 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6324 */               return bool.booleanValue();
/*      */             } 
/* 6326 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6327 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6329 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6334 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding doubleValueAt(final ObservableList<? extends Number> op, final int index) {
/* 6352 */     if (op == null) {
/* 6353 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6355 */     if (index < 0) {
/* 6356 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6359 */     return new DoubleBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6366 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected double computeValue() {
/*      */           try {
/* 6372 */             Number number = op.get(index);
/* 6373 */             if (number == null) {
/* 6374 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6376 */               return number.doubleValue();
/*      */             } 
/* 6378 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6379 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6381 */           return 0.0D;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6386 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding doubleValueAt(ObservableList<? extends Number> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6403 */     return doubleValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DoubleBinding doubleValueAt(final ObservableList<? extends Number> op, final ObservableNumberValue index) {
/* 6418 */     if (op == null || index == null) {
/* 6419 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6422 */     return new DoubleBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6429 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected double computeValue() {
/*      */           try {
/* 6435 */             Number number = op.get(index.intValue());
/* 6436 */             if (number == null) {
/* 6437 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6439 */               return number.doubleValue();
/*      */             } 
/* 6441 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6442 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6444 */           return 0.0D;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6449 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(final ObservableList<? extends Number> op, final int index) {
/* 6467 */     if (op == null) {
/* 6468 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6470 */     if (index < 0) {
/* 6471 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6474 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6481 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 6487 */             Number number = op.get(index);
/* 6488 */             if (number == null) {
/* 6489 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6491 */               return number.floatValue();
/*      */             } 
/* 6493 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6494 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6496 */           return 0.0F;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6501 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(ObservableList<? extends Number> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6518 */     return floatValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(final ObservableList<? extends Number> op, final ObservableNumberValue index) {
/* 6533 */     if (op == null || index == null) {
/* 6534 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6537 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6544 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 6550 */             Number number = op.get(index.intValue());
/* 6551 */             if (number == null) {
/* 6552 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6554 */               return number.floatValue();
/*      */             } 
/* 6556 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6557 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6559 */           return 0.0F;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6564 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(final ObservableList<? extends Number> op, final int index) {
/* 6582 */     if (op == null) {
/* 6583 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6585 */     if (index < 0) {
/* 6586 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6589 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6596 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 6602 */             Number number = op.get(index);
/* 6603 */             if (number == null) {
/* 6604 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6606 */               return number.intValue();
/*      */             } 
/* 6608 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6609 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6611 */           return 0;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6616 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(ObservableList<? extends Number> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6633 */     return integerValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(final ObservableList<? extends Number> op, final ObservableNumberValue index) {
/* 6648 */     if (op == null || index == null) {
/* 6649 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6652 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6659 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 6665 */             Number number = op.get(index.intValue());
/* 6666 */             if (number == null) {
/* 6667 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6669 */               return number.intValue();
/*      */             } 
/* 6671 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6672 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6674 */           return 0;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6679 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding longValueAt(final ObservableList<? extends Number> op, final int index) {
/* 6697 */     if (op == null) {
/* 6698 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6700 */     if (index < 0) {
/* 6701 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6704 */     return new LongBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6711 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected long computeValue() {
/*      */           try {
/* 6717 */             Number number = op.get(index);
/* 6718 */             if (number == null) {
/* 6719 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6721 */               return number.longValue();
/*      */             } 
/* 6723 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6724 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6726 */           return 0L;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6731 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding longValueAt(ObservableList<? extends Number> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6748 */     return longValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LongBinding longValueAt(final ObservableList<? extends Number> op, final ObservableNumberValue index) {
/* 6763 */     if (op == null || index == null) {
/* 6764 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6767 */     return new LongBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6774 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected long computeValue() {
/*      */           try {
/* 6780 */             Number number = op.get(index.intValue());
/* 6781 */             if (number == null) {
/* 6782 */               Logging.getLogger().fine("List element is null, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 6784 */               return number.longValue();
/*      */             } 
/* 6786 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6787 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */           } 
/* 6789 */           return 0L;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6794 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding stringValueAt(final ObservableList<String> op, final int index) {
/* 6812 */     if (op == null) {
/* 6813 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/* 6815 */     if (index < 0) {
/* 6816 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 6819 */     return new StringBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6826 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected String computeValue() {
/*      */           try {
/* 6832 */             return op.get(index);
/* 6833 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6834 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 6836 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6841 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding stringValueAt(ObservableList<String> paramObservableList, ObservableIntegerValue paramObservableIntegerValue) {
/* 6858 */     return stringValueAt(paramObservableList, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StringBinding stringValueAt(final ObservableList<String> op, final ObservableNumberValue index) {
/* 6873 */     if (op == null || index == null) {
/* 6874 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 6877 */     return new StringBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6884 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected String computeValue() {
/*      */           try {
/* 6890 */             return op.get(index.intValue());
/* 6891 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 6892 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 6894 */             return null;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6899 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> IntegerBinding size(final ObservableSet<E> op) {
/* 6920 */     if (op == null) {
/* 6921 */       throw new NullPointerException("Set cannot be null.");
/*      */     }
/*      */     
/* 6924 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6931 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 6936 */           return op.size();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6941 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> BooleanBinding isEmpty(final ObservableSet<E> op) {
/* 6959 */     if (op == null) {
/* 6960 */       throw new NullPointerException("Set cannot be null.");
/*      */     }
/*      */     
/* 6963 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 6970 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 6975 */           return op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 6980 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <E> BooleanBinding isNotEmpty(final ObservableSet<E> op) {
/* 6998 */     if (op == null) {
/* 6999 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/*      */     
/* 7002 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7009 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 7014 */           return !op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7019 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding size(final ObservableArray op) {
/* 7038 */     if (op == null) {
/* 7039 */       throw new NullPointerException("Array cannot be null.");
/*      */     }
/*      */     
/* 7042 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7049 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 7054 */           return op.size();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7059 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(final ObservableFloatArray op, final int index) {
/* 7077 */     if (op == null) {
/* 7078 */       throw new NullPointerException("Array cannot be null.");
/*      */     }
/* 7080 */     if (index < 0) {
/* 7081 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 7084 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7091 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 7097 */             return op.get(index);
/* 7098 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 7099 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 7101 */             return 0.0F;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7106 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(ObservableFloatArray paramObservableFloatArray, ObservableIntegerValue paramObservableIntegerValue) {
/* 7123 */     return floatValueAt(paramObservableFloatArray, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static FloatBinding floatValueAt(final ObservableFloatArray op, final ObservableNumberValue index) {
/* 7138 */     if (op == null || index == null) {
/* 7139 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7142 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7149 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 7155 */             return op.get(index.intValue());
/* 7156 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 7157 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 7159 */             return 0.0F;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7164 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(final ObservableIntegerArray op, final int index) {
/* 7182 */     if (op == null) {
/* 7183 */       throw new NullPointerException("Array cannot be null.");
/*      */     }
/* 7185 */     if (index < 0) {
/* 7186 */       throw new IllegalArgumentException("Index cannot be negative");
/*      */     }
/*      */     
/* 7189 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7196 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 7202 */             return op.get(index);
/* 7203 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 7204 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 7206 */             return 0;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7211 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(ObservableIntegerArray paramObservableIntegerArray, ObservableIntegerValue paramObservableIntegerValue) {
/* 7228 */     return integerValueAt(paramObservableIntegerArray, paramObservableIntegerValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IntegerBinding integerValueAt(final ObservableIntegerArray op, final ObservableNumberValue index) {
/* 7243 */     if (op == null || index == null) {
/* 7244 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7247 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7254 */           unbind(new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 7260 */             return op.get(index.intValue());
/* 7261 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 7262 */             Logging.getLogger().fine("Exception while evaluating binding", indexOutOfBoundsException);
/*      */             
/* 7264 */             return 0;
/*      */           } 
/*      */         }
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7269 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$index });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> IntegerBinding size(final ObservableMap<K, V> op) {
/* 7292 */     if (op == null) {
/* 7293 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7296 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7303 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/* 7308 */           return op.size();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7313 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> BooleanBinding isEmpty(final ObservableMap<K, V> op) {
/* 7332 */     if (op == null) {
/* 7333 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7336 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7343 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 7348 */           return op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7353 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> BooleanBinding isNotEmpty(final ObservableMap<K, V> op) {
/* 7372 */     if (op == null) {
/* 7373 */       throw new NullPointerException("List cannot be null.");
/*      */     }
/*      */     
/* 7376 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7383 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/* 7388 */           return !op.isEmpty();
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7393 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObjectBinding<V> valueAt(final ObservableMap<K, V> op, final K key) {
/* 7411 */     if (op == null) {
/* 7412 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7415 */     return new ObjectBinding<V>()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7422 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected V computeValue() {
/*      */           try {
/* 7428 */             return (V)op.get(key);
/* 7429 */           } catch (ClassCastException classCastException) {
/* 7430 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7432 */           catch (NullPointerException nullPointerException) {
/* 7433 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7436 */           return null;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7441 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> ObjectBinding<V> valueAt(final ObservableMap<K, V> op, final ObservableValue<? extends K> key) {
/* 7459 */     if (op == null || key == null) {
/* 7460 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7463 */     return new ObjectBinding<V>()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7470 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected V computeValue() {
/*      */           try {
/* 7476 */             return (V)op.get(key.getValue());
/* 7477 */           } catch (ClassCastException classCastException) {
/* 7478 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7480 */           catch (NullPointerException nullPointerException) {
/* 7481 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7484 */           return null;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7489 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> BooleanBinding booleanValueAt(final ObservableMap<K, Boolean> op, final K key) {
/* 7507 */     if (op == null) {
/* 7508 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7511 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7518 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/*      */           try {
/* 7524 */             Boolean bool = (Boolean)op.get(key);
/* 7525 */             if (bool == null) {
/* 7526 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7528 */               return bool.booleanValue();
/*      */             } 
/* 7530 */           } catch (ClassCastException classCastException) {
/* 7531 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7533 */           catch (NullPointerException nullPointerException) {
/* 7534 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7537 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7542 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> BooleanBinding booleanValueAt(final ObservableMap<K, Boolean> op, final ObservableValue<? extends K> key) {
/* 7560 */     if (op == null || key == null) {
/* 7561 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7564 */     return new BooleanBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7571 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected boolean computeValue() {
/*      */           try {
/* 7577 */             Boolean bool = (Boolean)op.get(key.getValue());
/* 7578 */             if (bool == null) {
/* 7579 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7581 */               return bool.booleanValue();
/*      */             } 
/* 7583 */           } catch (ClassCastException classCastException) {
/* 7584 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7586 */           catch (NullPointerException nullPointerException) {
/* 7587 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7590 */           return false;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7595 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> DoubleBinding doubleValueAt(final ObservableMap<K, ? extends Number> op, final K key) {
/* 7613 */     if (op == null) {
/* 7614 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7617 */     return new DoubleBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7624 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected double computeValue() {
/*      */           try {
/* 7630 */             Number number = (Number)op.get(key);
/* 7631 */             if (number == null) {
/* 7632 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7634 */               return number.doubleValue();
/*      */             } 
/* 7636 */           } catch (ClassCastException classCastException) {
/* 7637 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7639 */           catch (NullPointerException nullPointerException) {
/* 7640 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7643 */           return 0.0D;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7648 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> DoubleBinding doubleValueAt(final ObservableMap<K, ? extends Number> op, final ObservableValue<? extends K> key) {
/* 7666 */     if (op == null || key == null) {
/* 7667 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7670 */     return new DoubleBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7677 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected double computeValue() {
/*      */           try {
/* 7683 */             Number number = (Number)op.get(key.getValue());
/* 7684 */             if (number == null) {
/* 7685 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7687 */               return number.doubleValue();
/*      */             } 
/* 7689 */           } catch (ClassCastException classCastException) {
/* 7690 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7692 */           catch (NullPointerException nullPointerException) {
/* 7693 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7696 */           return 0.0D;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7701 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> FloatBinding floatValueAt(final ObservableMap<K, ? extends Number> op, final K key) {
/* 7719 */     if (op == null) {
/* 7720 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7723 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7730 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 7736 */             Number number = (Number)op.get(key);
/* 7737 */             if (number == null) {
/* 7738 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7740 */               return number.floatValue();
/*      */             } 
/* 7742 */           } catch (ClassCastException classCastException) {
/* 7743 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7745 */           catch (NullPointerException nullPointerException) {
/* 7746 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7749 */           return 0.0F;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7754 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> FloatBinding floatValueAt(final ObservableMap<K, ? extends Number> op, final ObservableValue<? extends K> key) {
/* 7772 */     if (op == null || key == null) {
/* 7773 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7776 */     return new FloatBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7783 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected float computeValue() {
/*      */           try {
/* 7789 */             Number number = (Number)op.get(key.getValue());
/* 7790 */             if (number == null) {
/* 7791 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7793 */               return number.floatValue();
/*      */             } 
/* 7795 */           } catch (ClassCastException classCastException) {
/* 7796 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7798 */           catch (NullPointerException nullPointerException) {
/* 7799 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7802 */           return 0.0F;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7807 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> IntegerBinding integerValueAt(final ObservableMap<K, ? extends Number> op, final K key) {
/* 7825 */     if (op == null) {
/* 7826 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7829 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7836 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 7842 */             Number number = (Number)op.get(key);
/* 7843 */             if (number == null) {
/* 7844 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7846 */               return number.intValue();
/*      */             } 
/* 7848 */           } catch (ClassCastException classCastException) {
/* 7849 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7851 */           catch (NullPointerException nullPointerException) {
/* 7852 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7855 */           return 0;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7860 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> IntegerBinding integerValueAt(final ObservableMap<K, ? extends Number> op, final ObservableValue<? extends K> key) {
/* 7878 */     if (op == null || key == null) {
/* 7879 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7882 */     return new IntegerBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7889 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected int computeValue() {
/*      */           try {
/* 7895 */             Number number = (Number)op.get(key.getValue());
/* 7896 */             if (number == null) {
/* 7897 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7899 */               return number.intValue();
/*      */             } 
/* 7901 */           } catch (ClassCastException classCastException) {
/* 7902 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7904 */           catch (NullPointerException nullPointerException) {
/* 7905 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7908 */           return 0;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7913 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> LongBinding longValueAt(final ObservableMap<K, ? extends Number> op, final K key) {
/* 7931 */     if (op == null) {
/* 7932 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 7935 */     return new LongBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7942 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected long computeValue() {
/*      */           try {
/* 7948 */             Number number = (Number)op.get(key);
/* 7949 */             if (number == null) {
/* 7950 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 7952 */               return number.longValue();
/*      */             } 
/* 7954 */           } catch (ClassCastException classCastException) {
/* 7955 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 7957 */           catch (NullPointerException nullPointerException) {
/* 7958 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 7961 */           return 0L;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 7966 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> LongBinding longValueAt(final ObservableMap<K, ? extends Number> op, final ObservableValue<? extends K> key) {
/* 7984 */     if (op == null || key == null) {
/* 7985 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 7988 */     return new LongBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 7995 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected long computeValue() {
/*      */           try {
/* 8001 */             Number number = (Number)op.get(key.getValue());
/* 8002 */             if (number == null) {
/* 8003 */               Logging.getLogger().fine("Element not found in map, returning default value instead.", new NullPointerException());
/*      */             } else {
/* 8005 */               return number.longValue();
/*      */             } 
/* 8007 */           } catch (ClassCastException classCastException) {
/* 8008 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 8010 */           catch (NullPointerException nullPointerException) {
/* 8011 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 8014 */           return 0L;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 8019 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> StringBinding stringValueAt(final ObservableMap<K, String> op, final K key) {
/* 8037 */     if (op == null) {
/* 8038 */       throw new NullPointerException("Map cannot be null.");
/*      */     }
/*      */     
/* 8041 */     return new StringBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 8048 */           unbind(new Observable[] { this.val$op });
/*      */         }
/*      */ 
/*      */         
/*      */         protected String computeValue() {
/*      */           try {
/* 8054 */             return (String)op.get(key);
/* 8055 */           } catch (ClassCastException classCastException) {
/* 8056 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 8058 */           catch (NullPointerException nullPointerException) {
/* 8059 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 8062 */           return null;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 8067 */           return FXCollections.singletonObservableList(op);
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K> StringBinding stringValueAt(final ObservableMap<K, String> op, final ObservableValue<? extends K> key) {
/* 8085 */     if (op == null || key == null) {
/* 8086 */       throw new NullPointerException("Operands cannot be null.");
/*      */     }
/*      */     
/* 8089 */     return new StringBinding()
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         public void dispose()
/*      */         {
/* 8096 */           unbind(new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */ 
/*      */         
/*      */         protected String computeValue() {
/*      */           try {
/* 8102 */             return (String)op.get(key.getValue());
/* 8103 */           } catch (ClassCastException classCastException) {
/* 8104 */             Logging.getLogger().warning("Exception while evaluating binding", classCastException);
/*      */           }
/* 8106 */           catch (NullPointerException nullPointerException) {
/* 8107 */             Logging.getLogger().warning("Exception while evaluating binding", nullPointerException);
/*      */           } 
/*      */           
/* 8110 */           return null;
/*      */         }
/*      */ 
/*      */         
/*      */         public ObservableList<?> getDependencies() {
/* 8115 */           return new ImmutableObservableList((Object[])new Observable[] { this.val$op, this.val$key });
/*      */         }
/*      */       };
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\Bindings.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */