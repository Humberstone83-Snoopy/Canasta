package com.sun.javafx.image;

public interface PixelConverter<T extends java.nio.Buffer, U extends java.nio.Buffer> {
  void convert(T paramT, int paramInt1, int paramInt2, U paramU, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  PixelGetter<T> getGetter();
  
  PixelSetter<U> getSetter();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\PixelConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */