/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.RectBounds;
/*    */ import com.sun.javafx.scene.text.TextLayout;
/*    */ import com.sun.javafx.scene.text.TextSpan;
/*    */ import com.sun.javafx.text.PrismTextLayoutFactory;
/*    */ import com.sun.javafx.text.TextRun;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TextUtilities
/*    */ {
/*    */   static TextLayout createLayout(String paramString, Object paramObject) {
/* 36 */     TextLayout textLayout = PrismTextLayoutFactory.getFactory().createLayout();
/* 37 */     textLayout.setContent(paramString, paramObject);
/* 38 */     return textLayout;
/*    */   }
/*    */   
/*    */   static BaseBounds getLayoutBounds(String paramString, Object paramObject) {
/* 42 */     return createLayout(paramString, paramObject).getBounds();
/*    */   }
/*    */   
/*    */   static float getLayoutWidth(String paramString, Object paramObject) {
/* 46 */     return getLayoutBounds(paramString, paramObject).getWidth();
/*    */   }
/*    */   
/*    */   static TextRun createGlyphList(int[] paramArrayOfint, float[] paramArrayOffloat, float paramFloat1, float paramFloat2) {
/* 50 */     TextRun textRun = new TextRun(0, paramArrayOfint.length, (byte)0, true, 0, null, 0, false) {
/*    */         public RectBounds getLineBounds() {
/* 52 */           return new RectBounds();
/*    */         }
/*    */       };
/* 55 */     textRun.shape(paramArrayOfint.length, paramArrayOfint, paramArrayOffloat);
/* 56 */     textRun.setLocation(paramFloat1, paramFloat2);
/* 57 */     return textRun;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\TextUtilities.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */