/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontFileReader
/*     */   implements FontConstants
/*     */ {
/*     */   String filename;
/*     */   long filesize;
/*     */   RandomAccessFile raFile;
/*     */   private static final int READBUFFERSIZE = 1024;
/*     */   private byte[] readBuffer;
/*     */   private int readBufferLen;
/*     */   private int readBufferStart;
/*     */   
/*     */   public FontFileReader(String paramString) {
/*  44 */     this.filename = paramString;
/*     */   }
/*     */   
/*     */   public String getFilename() {
/*  48 */     return this.filename;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean openFile() throws PrivilegedActionException {
/*  58 */     if (this.raFile != null) {
/*  59 */       return false;
/*     */     }
/*  61 */     this.raFile = AccessController.<RandomAccessFile>doPrivileged(() -> {
/*     */           
/*     */           try {
/*     */             return new RandomAccessFile(this.filename, "r");
/*  65 */           } catch (FileNotFoundException fileNotFoundException) {
/*     */             return null;
/*     */           } 
/*     */         });
/*     */     
/*  70 */     if (this.raFile != null) {
/*     */       try {
/*  72 */         this.filesize = this.raFile.length();
/*  73 */         return true;
/*  74 */       } catch (IOException iOException) {}
/*     */     }
/*     */     
/*  77 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized void closeFile() throws IOException {
/*  81 */     if (this.raFile != null) {
/*  82 */       this.raFile.close();
/*  83 */       this.raFile = null;
/*  84 */       this.readBuffer = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized long getLength() {
/*  89 */     return this.filesize;
/*     */   }
/*     */   
/*     */   public synchronized void reset() throws IOException {
/*  93 */     if (this.raFile != null) {
/*  94 */       this.raFile.seek(0L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Buffer
/*     */   {
/*     */     byte[] data;
/*     */ 
/*     */     
/*     */     int pos;
/*     */     
/*     */     int orig;
/*     */ 
/*     */     
/*     */     Buffer(byte[] param1ArrayOfbyte, int param1Int) {
/* 111 */       this.orig = this.pos = param1Int;
/* 112 */       this.data = param1ArrayOfbyte;
/*     */     }
/*     */     
/*     */     int getInt(int param1Int) {
/* 116 */       param1Int += this.orig;
/* 117 */       int i = this.data[param1Int++] & 0xFF;
/* 118 */       i <<= 8;
/* 119 */       i |= this.data[param1Int++] & 0xFF;
/* 120 */       i <<= 8;
/* 121 */       i |= this.data[param1Int++] & 0xFF;
/* 122 */       i <<= 8;
/* 123 */       i |= this.data[param1Int++] & 0xFF;
/* 124 */       return i;
/*     */     }
/*     */     
/*     */     int getInt() {
/* 128 */       int i = this.data[this.pos++] & 0xFF;
/* 129 */       i <<= 8;
/* 130 */       i |= this.data[this.pos++] & 0xFF;
/* 131 */       i <<= 8;
/* 132 */       i |= this.data[this.pos++] & 0xFF;
/* 133 */       i <<= 8;
/* 134 */       i |= this.data[this.pos++] & 0xFF;
/* 135 */       return i;
/*     */     }
/*     */     
/*     */     short getShort(int param1Int) {
/* 139 */       param1Int += this.orig;
/* 140 */       int i = this.data[param1Int++] & 0xFF;
/* 141 */       i <<= 8;
/* 142 */       i |= this.data[param1Int++] & 0xFF;
/* 143 */       return (short)i;
/*     */     }
/*     */     
/*     */     short getShort() {
/* 147 */       int i = this.data[this.pos++] & 0xFF;
/* 148 */       i <<= 8;
/* 149 */       i |= this.data[this.pos++] & 0xFF;
/* 150 */       return (short)i;
/*     */     }
/*     */     
/*     */     char getChar(int param1Int) {
/* 154 */       param1Int += this.orig;
/* 155 */       int i = this.data[param1Int++] & 0xFF;
/* 156 */       i <<= 8;
/* 157 */       i |= this.data[param1Int++] & 0xFF;
/* 158 */       return (char)i;
/*     */     }
/*     */     
/*     */     char getChar() {
/* 162 */       int i = this.data[this.pos++] & 0xFF;
/* 163 */       i <<= 8;
/* 164 */       i |= this.data[this.pos++] & 0xFF;
/* 165 */       return (char)i;
/*     */     }
/*     */     
/*     */     void position(int param1Int) {
/* 169 */       this.pos = this.orig + param1Int;
/*     */     }
/*     */     
/*     */     int capacity() {
/* 173 */       return this.data.length - this.orig;
/*     */     }
/*     */     
/*     */     byte get() {
/* 177 */       return this.data[this.pos++];
/*     */     }
/*     */     
/*     */     byte get(int param1Int) {
/* 181 */       param1Int += this.orig;
/* 182 */       return this.data[param1Int];
/*     */     }
/*     */     
/*     */     void skip(int param1Int) {
/* 186 */       this.pos += param1Int;
/*     */     }
/*     */     
/*     */     void get(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2, int param1Int3) {
/* 190 */       System.arraycopy(this.data, this.orig + param1Int1, param1ArrayOfbyte, param1Int2, param1Int3);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized int readFromFile(byte[] paramArrayOfbyte, long paramLong, int paramInt) {
/*     */     try {
/* 204 */       this.raFile.seek(paramLong);
/*     */       
/* 206 */       return this.raFile.read(paramArrayOfbyte, 0, paramInt);
/*     */     }
/* 208 */     catch (IOException iOException) {
/* 209 */       if (PrismFontFactory.debugFonts) {
/* 210 */         iOException.printStackTrace();
/*     */       }
/* 212 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Buffer readBlock(int paramInt1, int paramInt2) {
/* 233 */     if (this.readBuffer == null) {
/* 234 */       this.readBuffer = new byte[1024];
/* 235 */       this.readBufferLen = 0;
/*     */     } 
/*     */     
/* 238 */     if (paramInt2 <= 1024) {
/* 239 */       if (this.readBufferStart <= paramInt1 && this.readBufferStart + this.readBufferLen >= paramInt1 + paramInt2)
/*     */       {
/*     */         
/* 242 */         return new Buffer(this.readBuffer, paramInt1 - this.readBufferStart);
/*     */       }
/* 244 */       this.readBufferStart = paramInt1;
/* 245 */       this
/* 246 */         .readBufferLen = ((paramInt1 + 1024) > this.filesize) ? ((int)this.filesize - paramInt1) : 1024;
/* 247 */       readFromFile(this.readBuffer, this.readBufferStart, this.readBufferLen);
/* 248 */       return new Buffer(this.readBuffer, 0);
/*     */     } 
/*     */     
/* 251 */     byte[] arrayOfByte = new byte[paramInt2];
/* 252 */     readFromFile(arrayOfByte, paramInt1, paramInt2);
/* 253 */     return new Buffer(arrayOfByte, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontFileReader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */