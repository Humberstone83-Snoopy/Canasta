/*    */ package com.sun.javafx.image.impl;
/*    */ 
/*    */ import com.sun.javafx.image.BytePixelSetter;
/*    */ import com.sun.javafx.image.IntPixelGetter;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.IntBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IntTo4ByteSameConverter
/*    */   extends BaseIntToByteConverter
/*    */ {
/*    */   IntTo4ByteSameConverter(IntPixelGetter paramIntPixelGetter, BytePixelSetter paramBytePixelSetter) {
/* 36 */     super(paramIntPixelGetter, paramBytePixelSetter);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doConvert(int[] paramArrayOfint, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 44 */     paramInt2 -= paramInt5;
/* 45 */     paramInt4 -= paramInt5 * 4;
/* 46 */     while (--paramInt6 >= 0) {
/* 47 */       for (byte b = 0; b < paramInt5; b++) {
/* 48 */         int i = paramArrayOfint[paramInt1++];
/* 49 */         paramArrayOfbyte[paramInt3++] = (byte)i;
/* 50 */         paramArrayOfbyte[paramInt3++] = (byte)(i >> 8);
/* 51 */         paramArrayOfbyte[paramInt3++] = (byte)(i >> 16);
/* 52 */         paramArrayOfbyte[paramInt3++] = (byte)(i >> 24);
/*    */       } 
/* 54 */       paramInt1 += paramInt2;
/* 55 */       paramInt3 += paramInt4;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void doConvert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 64 */     paramInt4 -= paramInt5 * 4;
/* 65 */     while (--paramInt6 >= 0) {
/* 66 */       for (byte b = 0; b < paramInt5; b++) {
/* 67 */         int i = paramIntBuffer.get(paramInt1 + b);
/* 68 */         paramByteBuffer.put(paramInt3, (byte)i);
/* 69 */         paramByteBuffer.put(paramInt3 + 1, (byte)(i >> 8));
/* 70 */         paramByteBuffer.put(paramInt3 + 2, (byte)(i >> 16));
/* 71 */         paramByteBuffer.put(paramInt3 + 3, (byte)(i >> 24));
/* 72 */         paramInt3 += 4;
/*    */       } 
/* 74 */       paramInt1 += paramInt2;
/* 75 */       paramInt3 += paramInt4;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\IntTo4ByteSameConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */