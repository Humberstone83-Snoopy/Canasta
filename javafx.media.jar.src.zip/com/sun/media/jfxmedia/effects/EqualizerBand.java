package com.sun.media.jfxmedia.effects;

public interface EqualizerBand {
  public static final double MIN_GAIN = -24.0D;
  
  public static final double MAX_GAIN = 12.0D;
  
  double getCenterFrequency();
  
  void setCenterFrequency(double paramDouble);
  
  double getBandwidth();
  
  void setBandwidth(double paramDouble);
  
  double getGain();
  
  void setGain(double paramDouble);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\effects\EqualizerBand.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */