/*     */ package com.sun.javafx.webkit;
/*     */ 
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.webkit.CursorManager;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import javafx.scene.Cursor;
/*     */ import javafx.scene.ImageCursor;
/*     */ import javafx.scene.image.Image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CursorManagerImpl
/*     */   extends CursorManager<Cursor>
/*     */ {
/*  43 */   private final Map<String, Cursor> map = new HashMap<>();
/*     */   private ResourceBundle bundle;
/*     */   
/*     */   protected Cursor getCustomCursor(WCImage paramWCImage, int paramInt1, int paramInt2) {
/*  47 */     return new ImageCursor(
/*  48 */         Toolkit.getImageAccessor().fromPlatformImage(
/*  49 */           WCGraphicsManager.getGraphicsManager().toPlatformImage(paramWCImage)), paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Cursor getPredefinedCursor(int paramInt) {
/*  54 */     switch (paramInt)
/*     */     { default:
/*  56 */         return Cursor.DEFAULT;
/*  57 */       case 1: return Cursor.CROSSHAIR;
/*  58 */       case 2: return Cursor.HAND;
/*  59 */       case 3: return Cursor.MOVE;
/*  60 */       case 4: return Cursor.TEXT;
/*  61 */       case 5: return Cursor.WAIT;
/*  62 */       case 6: return getCustomCursor("help", Cursor.DEFAULT);
/*  63 */       case 7: return Cursor.E_RESIZE;
/*  64 */       case 8: return Cursor.N_RESIZE;
/*  65 */       case 9: return Cursor.NE_RESIZE;
/*  66 */       case 10: return Cursor.NW_RESIZE;
/*  67 */       case 11: return Cursor.S_RESIZE;
/*  68 */       case 12: return Cursor.SE_RESIZE;
/*  69 */       case 13: return Cursor.SW_RESIZE;
/*  70 */       case 14: return Cursor.W_RESIZE;
/*  71 */       case 15: return Cursor.V_RESIZE;
/*  72 */       case 16: return Cursor.H_RESIZE;
/*  73 */       case 17: return getCustomCursor("resize.nesw", Cursor.DEFAULT);
/*  74 */       case 18: return getCustomCursor("resize.nwse", Cursor.DEFAULT);
/*  75 */       case 19: return getCustomCursor("resize.column", Cursor.H_RESIZE);
/*  76 */       case 20: return getCustomCursor("resize.row", Cursor.V_RESIZE);
/*  77 */       case 21: return getCustomCursor("panning.middle", Cursor.DEFAULT);
/*  78 */       case 22: return getCustomCursor("panning.east", Cursor.DEFAULT);
/*  79 */       case 23: return getCustomCursor("panning.north", Cursor.DEFAULT);
/*  80 */       case 24: return getCustomCursor("panning.ne", Cursor.DEFAULT);
/*  81 */       case 25: return getCustomCursor("panning.nw", Cursor.DEFAULT);
/*  82 */       case 26: return getCustomCursor("panning.south", Cursor.DEFAULT);
/*  83 */       case 27: return getCustomCursor("panning.se", Cursor.DEFAULT);
/*  84 */       case 28: return getCustomCursor("panning.sw", Cursor.DEFAULT);
/*  85 */       case 29: return getCustomCursor("panning.west", Cursor.DEFAULT);
/*  86 */       case 30: return getCustomCursor("vertical.text", Cursor.DEFAULT);
/*  87 */       case 31: return getCustomCursor("cell", Cursor.DEFAULT);
/*  88 */       case 32: return getCustomCursor("context.menu", Cursor.DEFAULT);
/*  89 */       case 33: return getCustomCursor("no.drop", Cursor.DEFAULT);
/*  90 */       case 34: return getCustomCursor("not.allowed", Cursor.DEFAULT);
/*  91 */       case 35: return getCustomCursor("progress", Cursor.WAIT);
/*  92 */       case 36: return getCustomCursor("alias", Cursor.DEFAULT);
/*  93 */       case 37: return getCustomCursor("zoom.in", Cursor.DEFAULT);
/*  94 */       case 38: return getCustomCursor("zoom.out", Cursor.DEFAULT);
/*  95 */       case 39: return getCustomCursor("copy", Cursor.DEFAULT);
/*  96 */       case 40: return Cursor.NONE;
/*  97 */       case 41: return getCustomCursor("grab", Cursor.OPEN_HAND);
/*  98 */       case 42: break; }  return getCustomCursor("grabbing", Cursor.CLOSED_HAND);
/*     */   }
/*     */ 
/*     */   
/*     */   private Cursor getCustomCursor(String paramString, Cursor paramCursor) {
/* 103 */     Cursor cursor = this.map.get(paramString);
/* 104 */     if (cursor == null) {
/*     */       try {
/* 106 */         if (this.bundle == null) {
/* 107 */           this.bundle = ResourceBundle.getBundle("com.sun.javafx.webkit.Cursors", Locale.getDefault());
/*     */         }
/* 109 */         if (this.bundle != null) {
/* 110 */           String str = this.bundle.getString(paramString + ".file");
/* 111 */           Image image = new Image(CursorManagerImpl.class.getResourceAsStream(str));
/*     */           
/* 113 */           str = this.bundle.getString(paramString + ".hotspotX");
/* 114 */           int i = Integer.parseInt(str);
/*     */           
/* 116 */           str = this.bundle.getString(paramString + ".hotspotY");
/* 117 */           int j = Integer.parseInt(str);
/*     */           
/* 119 */           cursor = new ImageCursor(image, i, j);
/*     */         } 
/* 121 */       } catch (MissingResourceException missingResourceException) {}
/*     */ 
/*     */       
/* 124 */       if (cursor == null) {
/* 125 */         cursor = paramCursor;
/*     */       }
/* 127 */       this.map.put(paramString, cursor);
/*     */     } 
/* 129 */     return cursor;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\CursorManagerImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */