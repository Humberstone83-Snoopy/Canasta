/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageLoadListener;
/*     */ import com.sun.javafx.iio.ImageLoader;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.ImageStorageException;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.WCGraphicsManager;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.graphics.WCImageDecoder;
/*     */ import com.sun.webkit.graphics.WCImageFrame;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.concurrent.Service;
/*     */ import javafx.concurrent.Task;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCImageDecoderImpl
/*     */   extends WCImageDecoder
/*     */ {
/*  53 */   private int imageWidth = 0;
/*  54 */   private int imageHeight = 0;
/*     */   
/*  56 */   private int frameCount = 0;
/*     */   
/*     */   private boolean fullDataReceived = false;
/*     */   
/*     */   private boolean framesDecoded = false;
/*  61 */   private volatile int dataSize = 0;
/*     */ 
/*     */ 
/*     */   
/*  65 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCImageDecoderImpl.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void destroy() {
/*  75 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  76 */       log.fine(String.format("%X Destroy image decoder", new Object[] { Integer.valueOf(hashCode()) }));
/*     */     }
/*     */     
/*  79 */     destroyLoader();
/*  80 */     this.frames = null;
/*  81 */     this.images = null;
/*  82 */     this.framesDecoded = false;
/*     */   }
/*     */   
/*     */   protected String getFilenameExtension() {
/*  86 */     return "." + this.fileNameExtension;
/*     */   }
/*     */   
/*     */   private boolean imageSizeAvilable() {
/*  90 */     return (this.imageWidth > 0 && this.imageHeight > 0);
/*     */   }
/*     */   
/*     */   protected void addImageData(byte[] paramArrayOfbyte) {
/*  94 */     if (paramArrayOfbyte != null) {
/*  95 */       this.fullDataReceived = false;
/*  96 */       if (this.data == null) {
/*  97 */         this.data = Arrays.copyOf(paramArrayOfbyte, paramArrayOfbyte.length * 2);
/*  98 */         this.dataSize = paramArrayOfbyte.length;
/*     */       } else {
/* 100 */         int i = this.dataSize + paramArrayOfbyte.length;
/* 101 */         if (i > this.data.length) {
/* 102 */           resizeDataArray(Math.max(i, this.data.length * 2));
/*     */         }
/* 104 */         System.arraycopy(paramArrayOfbyte, 0, this.data, this.dataSize, paramArrayOfbyte.length);
/* 105 */         this.dataSize = i;
/*     */       } 
/*     */       
/* 108 */       if (!imageSizeAvilable()) {
/* 109 */         loadFrames();
/*     */       }
/* 111 */     } else if (this.data != null && !this.fullDataReceived) {
/*     */       
/* 113 */       if (this.data.length > this.dataSize) {
/* 114 */         resizeDataArray(this.dataSize);
/*     */       }
/* 116 */       this.fullDataReceived = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void destroyLoader() {
/* 121 */     if (this.loader != null) {
/* 122 */       this.loader.cancel();
/* 123 */       this.loader = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startLoader() {
/* 128 */     if (this.loader == null) {
/* 129 */       this.loader = new Service<ImageFrame[]>() {
/*     */           protected Task<ImageFrame[]> createTask() {
/* 131 */             return new Task<ImageFrame[]>() {
/*     */                 protected ImageFrame[] call() throws Exception {
/* 133 */                   return WCImageDecoderImpl.this.loadFrames();
/*     */                 }
/*     */               };
/*     */           }
/*     */         };
/* 138 */       this.loader.valueProperty().addListener((paramObservableValue, paramArrayOfImageFrame1, paramArrayOfImageFrame2) -> {
/*     */             if (paramArrayOfImageFrame2 != null && this.loader != null) {
/*     */               setFrames(paramArrayOfImageFrame2);
/*     */             }
/*     */           });
/*     */     } 
/* 144 */     if (!this.loader.isRunning()) {
/* 145 */       this.loader.restart();
/*     */     }
/*     */   }
/*     */   
/*     */   private void resizeDataArray(int paramInt) {
/* 150 */     byte[] arrayOfByte = new byte[paramInt];
/* 151 */     System.arraycopy(this.data, 0, arrayOfByte, 0, this.dataSize);
/* 152 */     this.data = arrayOfByte;
/*     */   }
/*     */   
/*     */   protected void loadFromResource(String paramString) {
/* 156 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 157 */       log.fine(String.format("%X Load image from resource '%s'", new Object[] {
/* 158 */               Integer.valueOf(hashCode()), paramString
/*     */             }));
/*     */     }
/* 161 */     String str = WCGraphicsManager.getResourceName(paramString);
/* 162 */     InputStream inputStream = getClass().getResourceAsStream(str);
/* 163 */     if (inputStream == null) {
/* 164 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 165 */         log.fine(String.format("%X Unable to open resource '%s'", new Object[] {
/* 166 */                 Integer.valueOf(hashCode()), str
/*     */               }));
/*     */       }
/*     */       return;
/*     */     } 
/* 171 */     setFrames(loadFrames(inputStream));
/*     */   }
/*     */   
/*     */   private synchronized ImageFrame[] loadFrames(InputStream paramInputStream) {
/* 175 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 176 */       log.fine(String.format("%X Decoding frames", new Object[] { Integer.valueOf(hashCode()) }));
/*     */     }
/*     */     try {
/* 179 */       return ImageStorage.loadAll(paramInputStream, this.readerListener, 0.0D, 0.0D, true, 1.0F, false);
/* 180 */     } catch (ImageStorageException imageStorageException) {
/* 181 */       return null;
/*     */     } finally {
/*     */       try {
/* 184 */         paramInputStream.close();
/* 185 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageFrame[] loadFrames() {
/* 192 */     return loadFrames(new ByteArrayInputStream(this.data, 0, this.dataSize));
/*     */   }
/*     */   
/* 195 */   private final ImageLoadListener readerListener = new ImageLoadListener() {
/*     */       public void imageLoadProgress(ImageLoader param1ImageLoader, float param1Float) {}
/*     */       
/*     */       public void imageLoadWarning(ImageLoader param1ImageLoader, String param1String) {}
/*     */       
/*     */       public void imageLoadMetaData(ImageLoader param1ImageLoader, ImageMetadata param1ImageMetadata) {
/* 201 */         if (WCImageDecoderImpl.log.isLoggable(PlatformLogger.Level.FINE)) {
/* 202 */           WCImageDecoderImpl.log.fine(String.format("%X Image size %dx%d", new Object[] {
/* 203 */                   Integer.valueOf(hashCode()), param1ImageMetadata.imageWidth, param1ImageMetadata.imageHeight
/*     */                 }));
/*     */         }
/*     */         
/* 207 */         if (WCImageDecoderImpl.this.imageWidth < param1ImageMetadata.imageWidth.intValue()) {
/* 208 */           WCImageDecoderImpl.this.imageWidth = param1ImageMetadata.imageWidth.intValue();
/*     */         }
/* 210 */         if (WCImageDecoderImpl.this.imageHeight < param1ImageMetadata.imageHeight.intValue()) {
/* 211 */           WCImageDecoderImpl.this.imageHeight = param1ImageMetadata.imageHeight.intValue();
/*     */         }
/* 213 */         WCImageDecoderImpl.this.fileNameExtension = param1ImageLoader.getFormatDescription().getExtensions().get(0);
/*     */       }
/*     */     };
/*     */   
/*     */   protected int[] getImageSize() {
/* 218 */     int[] arrayOfInt = THREAD_LOCAL_SIZE_ARRAY.get();
/* 219 */     arrayOfInt[0] = this.imageWidth;
/* 220 */     arrayOfInt[1] = this.imageHeight;
/* 221 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 222 */       log.fine(String.format("%X image size = %dx%d", new Object[] { Integer.valueOf(hashCode()), Integer.valueOf(arrayOfInt[0]), Integer.valueOf(arrayOfInt[1]) }));
/*     */     }
/* 224 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   private static final class Frame extends WCImageFrame {
/*     */     private WCImage image;
/*     */     
/*     */     private Frame(WCImage param1WCImage, String param1String) {
/* 231 */       this.image = param1WCImage;
/* 232 */       this.image.setFileExtension(param1String);
/*     */     }
/*     */     
/*     */     public WCImage getFrame() {
/* 236 */       return this.image;
/*     */     }
/*     */     
/*     */     public int[] getSize() {
/* 240 */       int[] arrayOfInt = WCImageDecoderImpl.THREAD_LOCAL_SIZE_ARRAY.get();
/* 241 */       arrayOfInt[0] = this.image.getWidth();
/* 242 */       arrayOfInt[1] = this.image.getHeight();
/* 243 */       return arrayOfInt;
/*     */     }
/*     */     
/*     */     protected void destroyDecodedData() {
/* 247 */       this.image = null;
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void setFrames(ImageFrame[] paramArrayOfImageFrame) {
/* 252 */     this.frames = paramArrayOfImageFrame;
/* 253 */     this.images = null;
/* 254 */     this.frameCount = (paramArrayOfImageFrame == null) ? 0 : paramArrayOfImageFrame.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getFrameCount() {
/* 263 */     if (this.fullDataReceived) {
/* 264 */       getImageFrame(0);
/*     */     }
/* 266 */     return this.frameCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized WCImageFrame getFrame(int paramInt) {
/* 272 */     ImageFrame imageFrame = getImageFrame(paramInt);
/* 273 */     if (imageFrame != null) {
/* 274 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 275 */         ImageStorage.ImageType imageType = imageFrame.getImageType();
/* 276 */         log.fine(String.format("%X getFrame(%d): image type = %s", new Object[] {
/* 277 */                 Integer.valueOf(hashCode()), Integer.valueOf(paramInt), imageType }));
/*     */       } 
/* 279 */       PrismImage prismImage = getPrismImage(paramInt, imageFrame);
/* 280 */       return new Frame(prismImage, this.fileNameExtension);
/*     */     } 
/* 282 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 283 */       log.fine(String.format("%X FAILED getFrame(%d)", new Object[] { Integer.valueOf(hashCode()), Integer.valueOf(paramInt) }));
/*     */     }
/* 285 */     return null;
/*     */   }
/*     */   
/*     */   private synchronized ImageMetadata getFrameMetadata(int paramInt) {
/* 289 */     return (this.frames != null && this.frames.length > paramInt && this.frames[paramInt] != null) ? this.frames[paramInt].getMetadata() : null;
/*     */   }
/*     */   
/*     */   protected int getFrameDuration(int paramInt) {
/* 293 */     ImageMetadata imageMetadata = getFrameMetadata(paramInt);
/* 294 */     byte b = (imageMetadata == null || imageMetadata.delayTime == null) ? 0 : imageMetadata.delayTime.intValue();
/*     */ 
/*     */     
/* 297 */     if (b < 11) b = 100; 
/* 298 */     return b;
/*     */   }
/*     */ 
/*     */   
/* 302 */   private static final ThreadLocal<int[]> THREAD_LOCAL_SIZE_ARRAY = new ThreadLocal<int[]>()
/*     */     {
/*     */       protected int[] initialValue() {
/* 305 */         return new int[2];
/*     */       }
/*     */     };
/*     */   private Service<ImageFrame[]> loader;
/*     */   protected int[] getFrameSize(int paramInt) {
/* 310 */     ImageMetadata imageMetadata = getFrameMetadata(paramInt);
/* 311 */     if (imageMetadata == null) {
/* 312 */       return null;
/*     */     }
/* 314 */     int[] arrayOfInt = THREAD_LOCAL_SIZE_ARRAY.get();
/* 315 */     arrayOfInt[0] = imageMetadata.imageWidth.intValue();
/* 316 */     arrayOfInt[1] = imageMetadata.imageHeight.intValue();
/* 317 */     return arrayOfInt;
/*     */   }
/*     */   private ImageFrame[] frames; private PrismImage[] images;
/*     */   private volatile byte[] data;
/*     */   private String fileNameExtension;
/*     */   
/*     */   protected synchronized boolean getFrameCompleteStatus(int paramInt) {
/* 324 */     return (getFrameMetadata(paramInt) != null && this.framesDecoded);
/*     */   }
/*     */   
/*     */   private synchronized ImageFrame getImageFrame(int paramInt) {
/* 328 */     if (!this.fullDataReceived) {
/* 329 */       startLoader();
/* 330 */     } else if (this.fullDataReceived && !this.framesDecoded) {
/* 331 */       destroyLoader();
/* 332 */       setFrames(loadFrames());
/* 333 */       this.framesDecoded = true;
/*     */     } 
/* 335 */     return (paramInt >= 0 && this.frames != null && this.frames.length > paramInt) ? 
/* 336 */       this.frames[paramInt] : 
/* 337 */       null;
/*     */   }
/*     */   
/*     */   private synchronized PrismImage getPrismImage(int paramInt, ImageFrame paramImageFrame) {
/* 341 */     if (this.images == null) {
/* 342 */       this.images = new PrismImage[this.frames.length];
/*     */     }
/* 344 */     if (this.images[paramInt] == null) {
/* 345 */       this.images[paramInt] = new WCImageImpl(paramImageFrame);
/*     */     }
/* 347 */     return this.images[paramInt];
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCImageDecoderImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */