/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Arc;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArcHelper
/*    */   extends ShapeHelper
/*    */ {
/* 43 */   private static final ArcHelper theInstance = new ArcHelper(); static {
/* 44 */     Utils.forceInit(Arc.class);
/*    */   }
/*    */   private static ArcAccessor arcAccessor;
/*    */   private static ArcHelper getInstance() {
/* 48 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Arc paramArc) {
/* 52 */     setHelper(paramArc, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 57 */     return arcAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 62 */     super.updatePeerImpl(paramNode);
/* 63 */     arcAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 68 */     return arcAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setArcAccessor(ArcAccessor paramArcAccessor) {
/* 72 */     if (arcAccessor != null) {
/* 73 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 76 */     arcAccessor = paramArcAccessor;
/*    */   }
/*    */   
/*    */   public static interface ArcAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\ArcHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */