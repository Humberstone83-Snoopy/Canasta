/*    */ package com.sun.webkit.network;
/*    */ 
/*    */ import java.net.MalformedURLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Util
/*    */ {
/*    */   private Util() {
/* 40 */     throw new AssertionError();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String adjustUrlForWebKit(String paramString) throws MalformedURLException {
/* 54 */     if (URLs.newURL(paramString).getProtocol().equals("file")) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 64 */       int i = "file:".length();
/* 65 */       if (i < paramString.length() && paramString.charAt(i) != '/') {
/* 66 */         paramString = paramString.substring(0, i) + "///" + paramString.substring(0, i);
/*    */       }
/*    */     } 
/* 69 */     return paramString;
/*    */   }
/*    */   
/*    */   static String formatHeaders(String paramString) {
/* 73 */     return paramString.trim().replaceAll("(?m)^", "    ");
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\Util.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */