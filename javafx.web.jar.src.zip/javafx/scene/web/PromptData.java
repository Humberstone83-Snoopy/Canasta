/*    */ package javafx.scene.web;
/*    */ 
/*    */ import javafx.beans.NamedArg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PromptData
/*    */ {
/*    */   private final String message;
/*    */   private final String defaultValue;
/*    */   
/*    */   public PromptData(@NamedArg("message") String paramString1, @NamedArg("defaultValue") String paramString2) {
/* 52 */     this.message = paramString1;
/* 53 */     this.defaultValue = paramString2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getMessage() {
/* 61 */     return this.message;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String getDefaultValue() {
/* 69 */     return this.defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\javafx\scene\web\PromptData.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */