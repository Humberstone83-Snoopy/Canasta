/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.DocumentType;
/*    */ import org.w3c.dom.NamedNodeMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentTypeImpl
/*    */   extends NodeImpl
/*    */   implements DocumentType
/*    */ {
/*    */   DocumentTypeImpl(long paramLong) {
/* 34 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static DocumentType getImpl(long paramLong) {
/* 38 */     return (DocumentType)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   public String getName() {
/* 44 */     return getNameImpl(getPeer());
/*    */   }
/*    */   static native long getEntitiesImpl(long paramLong);
/*    */   
/*    */   public NamedNodeMap getEntities() {
/* 49 */     return NamedNodeMapImpl.getImpl(getEntitiesImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public NamedNodeMap getNotations() {
/* 54 */     return NamedNodeMapImpl.getImpl(getNotationsImpl(getPeer()));
/*    */   }
/*    */   static native long getNotationsImpl(long paramLong);
/*    */   
/*    */   public String getPublicId() {
/* 59 */     return getPublicIdImpl(getPeer());
/*    */   }
/*    */   static native String getPublicIdImpl(long paramLong);
/*    */   
/*    */   public String getSystemId() {
/* 64 */     return getSystemIdImpl(getPeer());
/*    */   }
/*    */   static native String getSystemIdImpl(long paramLong);
/*    */   
/*    */   public String getInternalSubset() {
/* 69 */     return getInternalSubsetImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native String getInternalSubsetImpl(long paramLong);
/*    */ 
/*    */   
/*    */   public void remove() throws DOMException {
/* 77 */     removeImpl(getPeer());
/*    */   }
/*    */   
/*    */   static native void removeImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\DocumentTypeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */