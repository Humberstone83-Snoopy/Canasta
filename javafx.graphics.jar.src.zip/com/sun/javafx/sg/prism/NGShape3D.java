/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Material;
/*     */ import com.sun.prism.MeshView;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import javafx.application.ConditionalFeature;
/*     */ import javafx.application.Platform;
/*     */ import javafx.scene.shape.CullFace;
/*     */ import javafx.scene.shape.DrawMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NGShape3D
/*     */   extends NGNode
/*     */ {
/*     */   private NGPhongMaterial material;
/*     */   private DrawMode drawMode;
/*     */   private CullFace cullFace;
/*     */   private boolean materialDirty = false;
/*     */   private boolean drawModeDirty = false;
/*     */   NGTriangleMesh mesh;
/*     */   private MeshView meshView;
/*     */   
/*     */   public void setMaterial(NGPhongMaterial paramNGPhongMaterial) {
/*  52 */     this.material = paramNGPhongMaterial;
/*  53 */     this.materialDirty = true;
/*  54 */     visualsChanged();
/*     */   }
/*     */   public void setDrawMode(Object paramObject) {
/*  57 */     this.drawMode = (DrawMode)paramObject;
/*  58 */     this.drawModeDirty = true;
/*  59 */     visualsChanged();
/*     */   }
/*     */   
/*     */   public void setCullFace(Object paramObject) {
/*  63 */     this.cullFace = (CullFace)paramObject;
/*  64 */     visualsChanged();
/*     */   }
/*     */   
/*     */   void invalidate() {
/*  68 */     this.meshView = null;
/*  69 */     visualsChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderMeshView(Graphics paramGraphics) {
/*  75 */     paramGraphics.setup3DRendering();
/*     */     
/*  77 */     ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/*     */     
/*  79 */     if (this.meshView == null && this.mesh != null) {
/*  80 */       this.meshView = resourceFactory.createMeshView(this.mesh.createMesh(resourceFactory));
/*  81 */       this.materialDirty = this.drawModeDirty = true;
/*     */     } 
/*     */     
/*  84 */     if (this.meshView == null || !this.mesh.validate()) {
/*     */       return;
/*     */     }
/*     */     
/*  88 */     Material material = this.material.createMaterial(resourceFactory);
/*  89 */     if (this.materialDirty) {
/*  90 */       this.meshView.setMaterial(material);
/*  91 */       this.materialDirty = false;
/*     */     } 
/*     */ 
/*     */     
/*  95 */     int i = this.cullFace.ordinal();
/*  96 */     if (this.cullFace.ordinal() != MeshView.CULL_NONE && paramGraphics
/*  97 */       .getTransformNoClone().getDeterminant() < 0.0D)
/*     */     {
/*  99 */       i = (i == MeshView.CULL_BACK) ? MeshView.CULL_FRONT : MeshView.CULL_BACK;
/*     */     }
/* 101 */     this.meshView.setCullingMode(i);
/*     */     
/* 103 */     if (this.drawModeDirty) {
/* 104 */       this.meshView.setWireframe((this.drawMode == DrawMode.LINE));
/* 105 */       this.drawModeDirty = false;
/*     */     } 
/*     */ 
/*     */     
/* 109 */     byte b = 0;
/* 110 */     if (paramGraphics.getLights() == null || paramGraphics.getLights()[0] == null) {
/*     */ 
/*     */       
/* 113 */       this.meshView.setAmbientLight(0.0F, 0.0F, 0.0F);
/* 114 */       Vec3d vec3d = paramGraphics.getCameraNoClone().getPositionInWorld(null);
/* 115 */       this.meshView.setPointLight(b++, (float)vec3d.x, (float)vec3d.y, (float)vec3d.z, 1.0F, 1.0F, 1.0F, 1.0F);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 121 */       float f1 = 0.0F;
/* 122 */       float f2 = 0.0F;
/* 123 */       float f3 = 0.0F;
/*     */       
/* 125 */       for (byte b1 = 0; b1 < (paramGraphics.getLights()).length; b1++) {
/* 126 */         NGLightBase nGLightBase = paramGraphics.getLights()[b1];
/* 127 */         if (nGLightBase == null) {
/*     */           break;
/*     */         }
/* 130 */         if (nGLightBase.affects(this)) {
/* 131 */           float f4 = nGLightBase.getColor().getRed();
/* 132 */           float f5 = nGLightBase.getColor().getGreen();
/* 133 */           float f6 = nGLightBase.getColor().getBlue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 150 */           if (nGLightBase instanceof NGPointLight) {
/* 151 */             NGPointLight nGPointLight = (NGPointLight)nGLightBase;
/* 152 */             if (f4 != 0.0F || f5 != 0.0F || f6 != 0.0F) {
/* 153 */               Affine3D affine3D = nGPointLight.getWorldTransform();
/* 154 */               this.meshView.setPointLight(b++, 
/* 155 */                   (float)affine3D.getMxt(), 
/* 156 */                   (float)affine3D.getMyt(), 
/* 157 */                   (float)affine3D.getMzt(), f4, f5, f6, 1.0F);
/*     */             }
/*     */           
/* 160 */           } else if (nGLightBase instanceof NGAmbientLight) {
/*     */             
/* 162 */             f1 += f4;
/* 163 */             f3 += f5;
/* 164 */             f2 += f6;
/*     */           } 
/*     */         } 
/*     */       } 
/* 168 */       f1 = saturate(f1);
/* 169 */       f3 = saturate(f3);
/* 170 */       f2 = saturate(f2);
/* 171 */       this.meshView.setAmbientLight(f1, f3, f2);
/*     */     } 
/*     */     
/* 174 */     while (b < 3)
/*     */     {
/* 176 */       this.meshView.setPointLight(b++, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
/*     */     }
/*     */     
/* 179 */     this.meshView.render(paramGraphics);
/*     */   }
/*     */ 
/*     */   
/*     */   private static float saturate(float paramFloat) {
/* 184 */     return (paramFloat < 1.0F) ? ((paramFloat < 0.0F) ? 0.0F : paramFloat) : 1.0F;
/*     */   }
/*     */   
/*     */   public void setMesh(NGTriangleMesh paramNGTriangleMesh) {
/* 188 */     this.mesh = paramNGTriangleMesh;
/* 189 */     this.meshView = null;
/* 190 */     visualsChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 195 */     if (!Platform.isSupported(ConditionalFeature.SCENE3D) || this.material == null || paramGraphics instanceof com.sun.prism.PrinterGraphics) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 201 */     renderMeshView(paramGraphics);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isShape3D() {
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 212 */     return false;
/*     */   }
/*     */   
/*     */   public void release() {}
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGShape3D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */