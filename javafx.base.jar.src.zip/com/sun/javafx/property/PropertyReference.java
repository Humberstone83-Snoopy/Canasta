/*     */ package com.sun.javafx.property;
/*     */ 
/*     */ import com.sun.javafx.reflect.ReflectUtil;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import javafx.beans.property.ReadOnlyProperty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertyReference<T>
/*     */ {
/*     */   private String name;
/*     */   private Method getter;
/*     */   private Method setter;
/*     */   private Method propertyGetter;
/*     */   private Class<?> clazz;
/*     */   private Class<?> type;
/*     */   private boolean reflected = false;
/*     */   
/*     */   public PropertyReference(Class<?> paramClass, String paramString) {
/*  64 */     if (paramString == null)
/*  65 */       throw new NullPointerException("Name must be specified"); 
/*  66 */     if (paramString.trim().length() == 0)
/*  67 */       throw new IllegalArgumentException("Name must be specified"); 
/*  68 */     if (paramClass == null)
/*  69 */       throw new NullPointerException("Class must be specified"); 
/*  70 */     ReflectUtil.checkPackageAccess(paramClass);
/*  71 */     this.name = paramString;
/*  72 */     this.clazz = paramClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable() {
/*  81 */     reflect();
/*  82 */     return (this.setter != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadable() {
/*  91 */     reflect();
/*  92 */     return (this.getter != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty() {
/* 102 */     reflect();
/* 103 */     return (this.propertyGetter != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 112 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getContainingClass() {
/* 121 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 131 */     reflect();
/* 132 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Object paramObject, T paramT) {
/* 146 */     if (!isWritable()) {
/* 147 */       throw new IllegalStateException("Cannot write to readonly property " + this.name);
/*     */     }
/* 149 */     assert this.setter != null;
/*     */     try {
/* 151 */       MethodHelper.invoke(this.setter, paramObject, new Object[] { paramT });
/* 152 */     } catch (Exception exception) {
/* 153 */       throw new RuntimeException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(Object paramObject) {
/* 169 */     if (!isReadable()) {
/* 170 */       throw new IllegalStateException("Cannot read from unreadable property " + this.name);
/*     */     }
/* 172 */     assert this.getter != null;
/*     */     try {
/* 174 */       return (T)MethodHelper.invoke(this.getter, paramObject, (Object[])null);
/* 175 */     } catch (Exception exception) {
/* 176 */       throw new RuntimeException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyProperty<T> getProperty(Object paramObject) {
/* 193 */     if (!hasProperty())
/* 194 */       throw new IllegalStateException("Cannot get property " + this.name); 
/* 195 */     assert this.propertyGetter != null;
/*     */     try {
/* 197 */       return (ReadOnlyProperty<T>)MethodHelper.invoke(this.propertyGetter, paramObject, (Object[])null);
/* 198 */     } catch (Exception exception) {
/* 199 */       throw new RuntimeException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 208 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void reflect() {
/* 214 */     if (!this.reflected) {
/* 215 */       this.reflected = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 222 */         String str1 = (this.name.length() == 1) ? this.name.substring(0, 1).toUpperCase() : ("" + Character.toUpperCase(this.name.charAt(0)) + Character.toUpperCase(this.name.charAt(0)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 230 */         this.type = null;
/*     */         
/* 232 */         String str2 = "get" + str1;
/*     */         try {
/* 234 */           Method method = this.clazz.getMethod(str2, new Class[0]);
/* 235 */           if (Modifier.isPublic(method.getModifiers())) {
/* 236 */             this.getter = method;
/*     */           }
/* 238 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 243 */         if (this.getter == null) {
/* 244 */           str2 = "is" + str1;
/*     */           try {
/* 246 */             Method method = this.clazz.getMethod(str2, new Class[0]);
/* 247 */             if (Modifier.isPublic(method.getModifiers())) {
/* 248 */               this.getter = method;
/*     */             }
/* 250 */           } catch (NoSuchMethodException noSuchMethodException) {}
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         String str3 = "set" + str1;
/*     */ 
/*     */ 
/*     */         
/* 262 */         if (this.getter != null) {
/* 263 */           this.type = this.getter.getReturnType();
/*     */           try {
/* 265 */             Method method = this.clazz.getMethod(str3, new Class[] { this.type });
/* 266 */             if (Modifier.isPublic(method.getModifiers())) {
/* 267 */               this.setter = method;
/*     */             }
/* 269 */           } catch (NoSuchMethodException noSuchMethodException) {}
/*     */         }
/*     */         else {
/*     */           
/* 273 */           Method[] arrayOfMethod = this.clazz.getMethods();
/* 274 */           for (Method method : arrayOfMethod) {
/* 275 */             Class[] arrayOfClass = method.getParameterTypes();
/* 276 */             if (str3.equals(method.getName()) && arrayOfClass.length == 1 && 
/*     */               
/* 278 */               Modifier.isPublic(method.getModifiers())) {
/*     */               
/* 280 */               this.setter = method;
/* 281 */               this.type = arrayOfClass[0];
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 288 */         String str4 = this.name + "Property";
/*     */         try {
/* 290 */           Method method = this.clazz.getMethod(str4, new Class[0]);
/* 291 */           if (Modifier.isPublic(method.getModifiers()))
/* 292 */           { this.propertyGetter = method; }
/*     */           else
/* 294 */           { this.propertyGetter = null; } 
/* 295 */         } catch (NoSuchMethodException noSuchMethodException) {}
/*     */       
/*     */       }
/* 298 */       catch (RuntimeException runtimeException) {
/* 299 */         System.err.println("Failed to introspect property " + this.name);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 309 */     if (this == paramObject) {
/* 310 */       return true;
/*     */     }
/* 312 */     if (!(paramObject instanceof PropertyReference)) {
/* 313 */       return false;
/*     */     }
/* 315 */     PropertyReference propertyReference = (PropertyReference)paramObject;
/* 316 */     if (this.name != propertyReference.name && (this.name == null || 
/* 317 */       !this.name.equals(propertyReference.name))) {
/* 318 */       return false;
/*     */     }
/* 320 */     if (this.clazz != propertyReference.clazz && (this.clazz == null || 
/* 321 */       !this.clazz.equals(propertyReference.clazz))) {
/* 322 */       return false;
/*     */     }
/* 324 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 332 */     int i = 5;
/* 333 */     i = 97 * i + ((this.name != null) ? this.name.hashCode() : 0);
/* 334 */     i = 97 * i + ((this.clazz != null) ? this.clazz.hashCode() : 0);
/* 335 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\property\PropertyReference.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */