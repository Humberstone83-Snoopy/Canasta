/*     */ package javafx.scene.web;
/*     */ 
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.event.EventType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebEvent<T>
/*     */   extends Event
/*     */ {
/*  49 */   public static final EventType<WebEvent> ANY = (EventType)new EventType<>(Event.ANY, "WEB");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final EventType<WebEvent> RESIZED = new EventType<>(ANY, "WEB_RESIZED");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final EventType<WebEvent> STATUS_CHANGED = new EventType<>(ANY, "WEB_STATUS_CHANGED");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final EventType<WebEvent> VISIBILITY_CHANGED = new EventType<>(ANY, "WEB_VISIBILITY_CHANGED");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final EventType<WebEvent> ALERT = new EventType<>(ANY, "WEB_ALERT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final T data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebEvent(@NamedArg("source") Object paramObject, @NamedArg("type") EventType<WebEvent> paramEventType, @NamedArg("data") T paramT) {
/*  89 */     super(paramObject, (EventTarget)null, (EventType)paramEventType);
/*  90 */     this.data = paramT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getData() {
/*  98 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 106 */     return String.format("WebEvent [source = %s, eventType = %s, data = %s]", new Object[] {
/*     */           
/* 108 */           getSource(), getEventType(), getData()
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\javafx\scene\web\WebEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */