/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextImpl
/*    */   extends CharacterDataImpl
/*    */   implements Text
/*    */ {
/*    */   TextImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static Text getImpl(long paramLong) {
/* 37 */     return (Text)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getWholeText() {
/* 43 */     return getWholeTextImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native String getWholeTextImpl(long paramLong);
/*    */ 
/*    */   
/*    */   public Text splitText(int paramInt) throws DOMException {
/* 51 */     return getImpl(splitTextImpl(getPeer(), paramInt));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native long splitTextImpl(long paramLong, int paramInt);
/*    */ 
/*    */   
/*    */   public Text replaceWholeText(String paramString) throws DOMException {
/* 60 */     return getImpl(replaceWholeTextImpl(getPeer(), paramString));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native long replaceWholeTextImpl(long paramLong, String paramString);
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isElementContentWhitespace() {
/* 70 */     throw new UnsupportedOperationException("Not supported yet.");
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\TextImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */