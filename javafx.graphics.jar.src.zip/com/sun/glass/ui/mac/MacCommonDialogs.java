/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.CommonDialogs;
/*    */ import com.sun.glass.ui.Window;
/*    */ import java.io.File;
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacCommonDialogs
/*    */ {
/*    */   static {
/* 43 */     _initIDs();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static CommonDialogs.FileChooserResult showFileChooser_impl(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2) {
/* 56 */     long l = (paramWindow != null) ? paramWindow.getNativeWindow() : 0L;
/*    */     
/* 58 */     if (paramInt1 == 0)
/* 59 */       return _showFileOpenChooser(l, paramString1, paramString3, paramBoolean, paramArrayOfExtensionFilter, paramInt2); 
/* 60 */     if (paramInt1 == 1) {
/* 61 */       return _showFileSaveChooser(l, paramString1, paramString2, paramString3, paramArrayOfExtensionFilter, paramInt2);
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static File showFolderChooser_impl(Window paramWindow, String paramString1, String paramString2) {
/* 68 */     long l = (paramWindow != null) ? paramWindow.getNativeWindow() : 0L;
/* 69 */     return _showFolderChooser(l, paramString1, paramString2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static boolean isFileNSURLEnabled() {
/* 75 */     return ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("glass.macosx.enableFileNSURL")))).booleanValue();
/*    */   }
/*    */   
/*    */   private static native void _initIDs();
/*    */   
/*    */   private static native CommonDialogs.FileChooserResult _showFileOpenChooser(long paramLong, String paramString1, String paramString2, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt);
/*    */   
/*    */   private static native CommonDialogs.FileChooserResult _showFileSaveChooser(long paramLong, String paramString1, String paramString2, String paramString3, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt);
/*    */   
/*    */   private static native File _showFolderChooser(long paramLong, String paramString1, String paramString2);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacCommonDialogs.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */