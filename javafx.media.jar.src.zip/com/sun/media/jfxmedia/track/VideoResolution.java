/*    */ package com.sun.media.jfxmedia.track;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VideoResolution
/*    */ {
/*    */   public int width;
/*    */   public int height;
/*    */   
/*    */   public VideoResolution(int paramInt1, int paramInt2) {
/* 51 */     if (paramInt1 <= 0)
/* 52 */       throw new IllegalArgumentException("width <= 0"); 
/* 53 */     if (paramInt2 <= 0)
/* 54 */       throw new IllegalArgumentException("height <= 0"); 
/* 55 */     this.width = paramInt1;
/* 56 */     this.height = paramInt2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getWidth() {
/* 63 */     return this.width;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 70 */     return this.height;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 77 */     return "VideoResolution {width: " + this.width + " height: " + this.height + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\track\VideoResolution.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */