/*     */ package javafx.util.converter;
/*     */ 
/*     */ import com.sun.javafx.binding.Logging;
/*     */ import java.time.DateTimeException;
/*     */ import java.time.LocalDate;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.LocalTime;
/*     */ import java.time.chrono.ChronoLocalDate;
/*     */ import java.time.chrono.ChronoLocalDateTime;
/*     */ import java.time.chrono.Chronology;
/*     */ import java.time.chrono.IsoChronology;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.time.format.DateTimeFormatterBuilder;
/*     */ import java.time.format.DecimalStyle;
/*     */ import java.time.format.FormatStyle;
/*     */ import java.time.temporal.Temporal;
/*     */ import java.time.temporal.TemporalAccessor;
/*     */ import java.util.Locale;
/*     */ import javafx.util.StringConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalDateTimeStringConverter
/*     */   extends StringConverter<LocalDateTime>
/*     */ {
/*     */   LdtConverter<LocalDateTime> ldtConverter;
/*     */   
/*     */   public LocalDateTimeStringConverter() {
/*  79 */     this.ldtConverter = new LdtConverter<>(LocalDateTime.class, null, null, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTimeStringConverter(FormatStyle paramFormatStyle1, FormatStyle paramFormatStyle2) {
/*  97 */     this.ldtConverter = new LdtConverter<>(LocalDateTime.class, null, null, paramFormatStyle1, paramFormatStyle2, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTimeStringConverter(DateTimeFormatter paramDateTimeFormatter1, DateTimeFormatter paramDateTimeFormatter2) {
/* 125 */     this.ldtConverter = new LdtConverter<>(LocalDateTime.class, paramDateTimeFormatter1, paramDateTimeFormatter2, null, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTimeStringConverter(FormatStyle paramFormatStyle1, FormatStyle paramFormatStyle2, Locale paramLocale, Chronology paramChronology) {
/* 149 */     this.ldtConverter = new LdtConverter<>(LocalDateTime.class, null, null, paramFormatStyle1, paramFormatStyle2, paramLocale, paramChronology);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTime fromString(String paramString) {
/* 159 */     return this.ldtConverter.fromString(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(LocalDateTime paramLocalDateTime) {
/* 164 */     return this.ldtConverter.toString(paramLocalDateTime);
/*     */   }
/*     */ 
/*     */   
/*     */   static class LdtConverter<T extends Temporal>
/*     */     extends StringConverter<T>
/*     */   {
/*     */     private Class<T> type;
/*     */     Locale locale;
/*     */     Chronology chronology;
/*     */     DateTimeFormatter formatter;
/*     */     DateTimeFormatter parser;
/*     */     FormatStyle dateStyle;
/*     */     FormatStyle timeStyle;
/*     */     
/*     */     LdtConverter(Class<T> param1Class, DateTimeFormatter param1DateTimeFormatter1, DateTimeFormatter param1DateTimeFormatter2, FormatStyle param1FormatStyle1, FormatStyle param1FormatStyle2, Locale param1Locale, Chronology param1Chronology) {
/* 180 */       this.type = param1Class;
/* 181 */       this.formatter = param1DateTimeFormatter1;
/* 182 */       this.parser = (param1DateTimeFormatter2 != null) ? param1DateTimeFormatter2 : param1DateTimeFormatter1;
/* 183 */       this.locale = (param1Locale != null) ? param1Locale : Locale.getDefault(Locale.Category.FORMAT);
/* 184 */       this.chronology = (param1Chronology != null) ? param1Chronology : IsoChronology.INSTANCE;
/*     */       
/* 186 */       if (param1Class == LocalDate.class || param1Class == LocalDateTime.class) {
/* 187 */         this.dateStyle = (param1FormatStyle1 != null) ? param1FormatStyle1 : FormatStyle.SHORT;
/*     */       }
/*     */       
/* 190 */       if (param1Class == LocalTime.class || param1Class == LocalDateTime.class) {
/* 191 */         this.timeStyle = (param1FormatStyle2 != null) ? param1FormatStyle2 : FormatStyle.SHORT;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T fromString(String param1String) {
/* 198 */       if (param1String == null || param1String.isEmpty()) {
/* 199 */         return null;
/*     */       }
/*     */       
/* 202 */       param1String = param1String.trim();
/*     */       
/* 204 */       if (this.parser == null) {
/* 205 */         this.parser = getDefaultParser();
/*     */       }
/*     */       
/* 208 */       TemporalAccessor temporalAccessor = this.parser.parse(param1String);
/*     */       
/* 210 */       if (this.type == LocalDate.class)
/* 211 */         return (T)LocalDate.from(this.chronology.date(temporalAccessor)); 
/* 212 */       if (this.type == LocalTime.class) {
/* 213 */         return (T)LocalTime.from(temporalAccessor);
/*     */       }
/* 215 */       return (T)LocalDateTime.from(this.chronology.localDateTime(temporalAccessor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString(T param1T) {
/* 223 */       if (param1T == null) {
/* 224 */         return "";
/*     */       }
/*     */       
/* 227 */       if (this.formatter == null) {
/* 228 */         this.formatter = getDefaultFormatter();
/*     */       }
/*     */       
/* 231 */       if (param1T instanceof LocalDate) {
/*     */         ChronoLocalDate chronoLocalDate;
/*     */         try {
/* 234 */           chronoLocalDate = this.chronology.date((TemporalAccessor)param1T);
/* 235 */         } catch (DateTimeException dateTimeException) {
/* 236 */           Logging.getLogger().warning("Converting LocalDate " + param1T + " to " + this.chronology + " failed, falling back to IsoChronology.", dateTimeException);
/* 237 */           this.chronology = IsoChronology.INSTANCE;
/* 238 */           chronoLocalDate = (LocalDate)param1T;
/*     */         } 
/* 240 */         return this.formatter.format(chronoLocalDate);
/* 241 */       }  if (param1T instanceof LocalDateTime) {
/*     */         ChronoLocalDateTime<? extends ChronoLocalDate> chronoLocalDateTime;
/*     */         try {
/* 244 */           chronoLocalDateTime = this.chronology.localDateTime((TemporalAccessor)param1T);
/* 245 */         } catch (DateTimeException dateTimeException) {
/* 246 */           Logging.getLogger().warning("Converting LocalDateTime " + param1T + " to " + this.chronology + " failed, falling back to IsoChronology.", dateTimeException);
/* 247 */           this.chronology = IsoChronology.INSTANCE;
/* 248 */           chronoLocalDateTime = (LocalDateTime)param1T;
/*     */         } 
/* 250 */         return this.formatter.format(chronoLocalDateTime);
/*     */       } 
/* 252 */       return this.formatter.format((TemporalAccessor)param1T);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DateTimeFormatter getDefaultParser() {
/* 259 */       String str = DateTimeFormatterBuilder.getLocalizedDateTimePattern(this.dateStyle, this.timeStyle, this.chronology, this.locale);
/*     */       
/* 261 */       return (new DateTimeFormatterBuilder()).parseLenient()
/* 262 */         .appendPattern(str)
/* 263 */         .toFormatter()
/* 264 */         .withChronology(this.chronology)
/* 265 */         .withDecimalStyle(DecimalStyle.of(this.locale));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DateTimeFormatter getDefaultFormatter() {
/* 275 */       if (this.dateStyle != null && this.timeStyle != null) {
/* 276 */         dateTimeFormatter = DateTimeFormatter.ofLocalizedDateTime(this.dateStyle, this.timeStyle);
/* 277 */       } else if (this.dateStyle != null) {
/* 278 */         dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(this.dateStyle);
/*     */       } else {
/* 280 */         dateTimeFormatter = DateTimeFormatter.ofLocalizedTime(this.timeStyle);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 285 */       DateTimeFormatter dateTimeFormatter = dateTimeFormatter.withLocale(this.locale).withChronology(this.chronology).withDecimalStyle(DecimalStyle.of(this.locale));
/*     */       
/* 287 */       if (this.dateStyle != null) {
/* 288 */         dateTimeFormatter = fixFourDigitYear(dateTimeFormatter, this.dateStyle, this.timeStyle, this.chronology, this.locale);
/*     */       }
/*     */ 
/*     */       
/* 292 */       return dateTimeFormatter;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DateTimeFormatter fixFourDigitYear(DateTimeFormatter param1DateTimeFormatter, FormatStyle param1FormatStyle1, FormatStyle param1FormatStyle2, Chronology param1Chronology, Locale param1Locale) {
/* 299 */       String str = DateTimeFormatterBuilder.getLocalizedDateTimePattern(param1FormatStyle1, param1FormatStyle2, param1Chronology, param1Locale);
/*     */       
/* 301 */       if (str.contains("yy") && !str.contains("yyy")) {
/*     */         
/* 303 */         String str1 = str.replace("yy", "yyyy");
/*     */         
/* 305 */         param1DateTimeFormatter = DateTimeFormatter.ofPattern(str1).withDecimalStyle(DecimalStyle.of(param1Locale));
/*     */       } 
/*     */       
/* 308 */       return param1DateTimeFormatter;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\LocalDateTimeStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */