/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Pixels
/*     */ {
/*     */   protected final int width;
/*     */   protected final int height;
/*     */   protected final int bytesPerComponent;
/*     */   protected final ByteBuffer bytes;
/*     */   protected final IntBuffer ints;
/*     */   private final float scalex;
/*     */   private final float scaley;
/*     */   
/*     */   public static class Format
/*     */   {
/*     */     public static final int BYTE_BGRA_PRE = 1;
/*     */     public static final int BYTE_ARGB = 2;
/*     */   }
/*     */   
/*     */   public static int getNativeFormat() {
/*  60 */     Application.checkEventThread();
/*  61 */     return Application.GetApplication().staticPixels_getNativeFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/*  88 */     this.width = paramInt1;
/*  89 */     this.height = paramInt2;
/*  90 */     this.bytesPerComponent = 1;
/*  91 */     this.bytes = paramByteBuffer.slice();
/*  92 */     if (this.width <= 0 || this.height <= 0 || this.width * this.height * 4 > this.bytes.capacity()) {
/*  93 */       throw new IllegalArgumentException("Too small byte buffer size " + this.width + "x" + this.height + " [" + this.width * this.height * 4 + "] > " + this.bytes.capacity());
/*     */     }
/*     */     
/*  96 */     this.ints = null;
/*  97 */     this.scalex = 1.0F;
/*  98 */     this.scaley = 1.0F;
/*     */   }
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 102 */     this.width = paramInt1;
/* 103 */     this.height = paramInt2;
/* 104 */     this.bytesPerComponent = 4;
/* 105 */     this.ints = paramIntBuffer.slice();
/* 106 */     if (this.width <= 0 || this.height <= 0 || this.width * this.height > this.ints.capacity()) {
/* 107 */       throw new IllegalArgumentException("Too small int buffer size " + this.width + "x" + this.height + " [" + this.width * this.height + "] > " + this.ints.capacity());
/*     */     }
/*     */     
/* 110 */     this.bytes = null;
/* 111 */     this.scalex = 1.0F;
/* 112 */     this.scaley = 1.0F;
/*     */   }
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 116 */     this.width = paramInt1;
/* 117 */     this.height = paramInt2;
/* 118 */     this.bytesPerComponent = 4;
/* 119 */     this.ints = paramIntBuffer.slice();
/* 120 */     if (this.width <= 0 || this.height <= 0 || this.width * this.height > this.ints.capacity()) {
/* 121 */       throw new IllegalArgumentException("Too small int buffer size " + this.width + "x" + this.height + " [" + this.width * this.height + "] > " + this.ints.capacity());
/*     */     }
/*     */     
/* 124 */     this.bytes = null;
/* 125 */     this.scalex = paramFloat1;
/* 126 */     this.scaley = paramFloat2;
/*     */   }
/*     */   
/*     */   public final float getScaleX() {
/* 130 */     Application.checkEventThread();
/* 131 */     return this.scalex;
/*     */   }
/*     */   
/*     */   public final float getScaleY() {
/* 135 */     Application.checkEventThread();
/* 136 */     return this.scaley;
/*     */   }
/*     */   
/*     */   public final float getScaleXUnsafe() {
/* 140 */     return this.scalex;
/*     */   }
/*     */   
/*     */   public final float getScaleYUnsafe() {
/* 144 */     return this.scaley;
/*     */   }
/*     */   
/*     */   public final int getWidth() {
/* 148 */     Application.checkEventThread();
/* 149 */     return this.width;
/*     */   }
/*     */   
/*     */   public final int getWidthUnsafe() {
/* 153 */     return this.width;
/*     */   }
/*     */   
/*     */   public final int getHeight() {
/* 157 */     Application.checkEventThread();
/* 158 */     return this.height;
/*     */   }
/*     */   
/*     */   public final int getHeightUnsafe() {
/* 162 */     return this.height;
/*     */   }
/*     */   
/*     */   public final int getBytesPerComponent() {
/* 166 */     Application.checkEventThread();
/* 167 */     return this.bytesPerComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Buffer getPixels() {
/* 174 */     if (this.bytes != null) {
/* 175 */       this.bytes.rewind();
/* 176 */       return this.bytes;
/* 177 */     }  if (this.ints != null) {
/* 178 */       this.ints.rewind();
/* 179 */       return this.ints;
/*     */     } 
/* 181 */     throw new RuntimeException("Unexpected Pixels state.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuffer asByteBuffer() {
/* 189 */     Application.checkEventThread();
/* 190 */     ByteBuffer byteBuffer = ByteBuffer.allocateDirect(getWidth() * getHeight() * 4);
/* 191 */     byteBuffer.order(ByteOrder.nativeOrder());
/* 192 */     byteBuffer.rewind();
/* 193 */     asByteBuffer(byteBuffer);
/* 194 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void asByteBuffer(ByteBuffer paramByteBuffer) {
/* 202 */     Application.checkEventThread();
/* 203 */     if (!paramByteBuffer.isDirect())
/* 204 */       throw new RuntimeException("Expected direct buffer."); 
/* 205 */     if (paramByteBuffer.remaining() < getWidth() * getHeight() * 4) {
/* 206 */       throw new RuntimeException("Too small buffer.");
/*     */     }
/* 208 */     _fillDirectByteBuffer(paramByteBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   private void attachData(long paramLong) {
/* 213 */     if (this.ints != null) {
/* 214 */       int[] arrayOfInt = !this.ints.isDirect() ? this.ints.array() : null;
/* 215 */       _attachInt(paramLong, this.width, this.height, this.ints, arrayOfInt, (arrayOfInt != null) ? this.ints.arrayOffset() : 0);
/*     */     } 
/* 217 */     if (this.bytes != null) {
/* 218 */       byte[] arrayOfByte = !this.bytes.isDirect() ? this.bytes.array() : null;
/* 219 */       _attachByte(paramLong, this.width, this.height, this.bytes, arrayOfByte, (arrayOfByte != null) ? this.bytes.arrayOffset() : 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void _fillDirectByteBuffer(ByteBuffer paramByteBuffer);
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 228 */     Application.checkEventThread();
/* 229 */     boolean bool = (paramObject != null && getClass().equals(paramObject.getClass())) ? true : false;
/* 230 */     if (bool) {
/* 231 */       Pixels pixels = (Pixels)paramObject;
/* 232 */       bool = (getWidth() == pixels.getWidth() && getHeight() == pixels.getHeight()) ? true : false;
/* 233 */       if (bool) {
/* 234 */         ByteBuffer byteBuffer1 = asByteBuffer();
/* 235 */         ByteBuffer byteBuffer2 = pixels.asByteBuffer();
/* 236 */         bool = (byteBuffer1.compareTo(byteBuffer2) == 0) ? true : false;
/*     */       } 
/*     */     } 
/* 239 */     return bool;
/*     */   } protected abstract void _attachInt(long paramLong, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int[] paramArrayOfint, int paramInt3);
/*     */   protected abstract void _attachByte(long paramLong, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, byte[] paramArrayOfbyte, int paramInt3);
/*     */   public final int hashCode() {
/* 243 */     Application.checkEventThread();
/* 244 */     int i = getWidth();
/* 245 */     i = 31 * i + getHeight();
/* 246 */     i = 17 * i + asByteBuffer().hashCode();
/* 247 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Pixels.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */