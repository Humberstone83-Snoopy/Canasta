/*     */ package com.sun.javafx.scene.layout;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import com.sun.javafx.scene.input.PickResultChooser;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.layout.Region;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RegionHelper
/*     */   extends ParentHelper
/*     */ {
/*  48 */   private static final RegionHelper theInstance = new RegionHelper(); static {
/*  49 */     Utils.forceInit(Region.class);
/*     */   }
/*     */   private static RegionAccessor regionAccessor;
/*     */   private static RegionHelper getInstance() {
/*  53 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(Region paramRegion) {
/*  57 */     setHelper(paramRegion, (NodeHelper)getInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   public static BaseBounds superComputeGeomBounds(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  62 */     return ((RegionHelper)getHelper(paramNode)).superComputeGeomBoundsImpl(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  67 */     return regionAccessor.doCreatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  72 */     super.updatePeerImpl(paramNode);
/*  73 */     regionAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   BaseBounds superComputeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  78 */     return super.computeGeomBoundsImpl(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Bounds computeLayoutBoundsImpl(Node paramNode) {
/*  83 */     return regionAccessor.doComputeLayoutBounds(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  89 */     return regionAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  94 */     return regionAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifyLayoutBoundsChangedImpl(Node paramNode) {
/*  99 */     regionAccessor.doNotifyLayoutBoundsChanged(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void pickNodeLocalImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/* 104 */     regionAccessor.doPickNodeLocal(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   public static void setRegionAccessor(RegionAccessor paramRegionAccessor) {
/* 108 */     if (regionAccessor != null) {
/* 109 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 112 */     regionAccessor = paramRegionAccessor;
/*     */   }
/*     */   
/*     */   public static interface RegionAccessor {
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     NGNode doCreatePeer(Node param1Node);
/*     */     
/*     */     Bounds doComputeLayoutBounds(Node param1Node);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     void doNotifyLayoutBoundsChanged(Node param1Node);
/*     */     
/*     */     void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\RegionHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */