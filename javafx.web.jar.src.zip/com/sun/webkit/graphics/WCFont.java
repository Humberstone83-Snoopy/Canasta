/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WCFont
/*    */   extends Ref
/*    */ {
/*    */   public abstract Object getPlatformFont();
/*    */   
/*    */   public abstract WCFont deriveFont(float paramFloat);
/*    */   
/*    */   public abstract int getOffsetForPosition(String paramString, float paramFloat);
/*    */   
/*    */   public abstract WCGlyphBuffer getGlyphsAndAdvances(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);
/*    */   
/*    */   public abstract int[] getGlyphCodes(char[] paramArrayOfchar);
/*    */   
/*    */   public abstract float getXHeight();
/*    */   
/*    */   public abstract double getGlyphWidth(int paramInt);
/*    */   
/*    */   public abstract float[] getGlyphBoundingBox(int paramInt);
/*    */   
/*    */   public abstract double[] getStringBounds(String paramString, int paramInt1, int paramInt2, boolean paramBoolean);
/*    */   
/*    */   public abstract double getStringWidth(String paramString);
/*    */   
/*    */   public int hashCode() {
/* 62 */     Object object = getPlatformFont();
/* 63 */     return (object != null) ? 
/* 64 */       object.hashCode() : 
/* 65 */       0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 78 */     if (paramObject instanceof WCFont) {
/* 79 */       Object object1 = getPlatformFont();
/* 80 */       Object object2 = ((WCFont)paramObject).getPlatformFont();
/* 81 */       return (object1 == null) ? ((object2 == null)) : object1.equals(object2);
/*    */     } 
/* 83 */     return false;
/*    */   }
/*    */   
/*    */   public abstract float getAscent();
/*    */   
/*    */   public abstract float getDescent();
/*    */   
/*    */   public abstract float getLineSpacing();
/*    */   
/*    */   public abstract float getLineGap();
/*    */   
/*    */   public abstract boolean hasUniformLineMetrics();
/*    */   
/*    */   public abstract float getCapHeight();
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCFont.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */