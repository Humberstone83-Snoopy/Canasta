package com.sun.javafx.font;

import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.geom.Shape;

public interface Glyph {
  int getGlyphCode();
  
  RectBounds getBBox();
  
  float getAdvance();
  
  Shape getShape();
  
  byte[] getPixelData();
  
  byte[] getPixelData(int paramInt);
  
  float getPixelXAdvance();
  
  float getPixelYAdvance();
  
  boolean isLCDGlyph();
  
  int getWidth();
  
  int getHeight();
  
  int getOriginX();
  
  int getOriginY();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\Glyph.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */