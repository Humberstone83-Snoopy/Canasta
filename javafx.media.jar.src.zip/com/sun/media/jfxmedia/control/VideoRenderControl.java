package com.sun.media.jfxmedia.control;

import com.sun.media.jfxmedia.events.VideoFrameRateListener;
import com.sun.media.jfxmedia.events.VideoRendererListener;

public interface VideoRenderControl {
  void addVideoRendererListener(VideoRendererListener paramVideoRendererListener);
  
  void removeVideoRendererListener(VideoRendererListener paramVideoRendererListener);
  
  void addVideoFrameRateListener(VideoFrameRateListener paramVideoFrameRateListener);
  
  void removeVideoFrameRateListener(VideoFrameRateListener paramVideoFrameRateListener);
  
  int getFrameWidth();
  
  int getFrameHeight();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\control\VideoRenderControl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */