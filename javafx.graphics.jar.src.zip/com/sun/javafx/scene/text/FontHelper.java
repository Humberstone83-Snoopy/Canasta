/*    */ package com.sun.javafx.scene.text;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FontHelper
/*    */ {
/*    */   private static FontAccessor fontAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(Font.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object getNativeFont(Font paramFont) {
/* 46 */     return fontAccessor.getNativeFont(paramFont);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setNativeFont(Font paramFont, Object paramObject, String paramString1, String paramString2, String paramString3) {
/* 51 */     fontAccessor.setNativeFont(paramFont, paramObject, paramString1, paramString2, paramString3);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Font nativeFont(Object paramObject, String paramString1, String paramString2, String paramString3, double paramDouble) {
/* 56 */     return fontAccessor.nativeFont(paramObject, paramString1, paramString2, paramString3, paramDouble);
/*    */   }
/*    */   
/*    */   public static void setFontAccessor(FontAccessor paramFontAccessor) {
/* 60 */     if (fontAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     fontAccessor = paramFontAccessor;
/*    */   }
/*    */   
/*    */   public static interface FontAccessor {
/*    */     Object getNativeFont(Font param1Font);
/*    */     
/*    */     void setNativeFont(Font param1Font, Object param1Object, String param1String1, String param1String2, String param1String3);
/*    */     
/*    */     Font nativeFont(Object param1Object, String param1String1, String param1String2, String param1String3, double param1Double);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\FontHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */