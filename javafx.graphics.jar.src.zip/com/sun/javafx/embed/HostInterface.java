package com.sun.javafx.embed;

import com.sun.javafx.cursor.CursorFrame;

public interface HostInterface {
  void setEmbeddedStage(EmbeddedStageInterface paramEmbeddedStageInterface);
  
  void setEmbeddedScene(EmbeddedSceneInterface paramEmbeddedSceneInterface);
  
  boolean requestFocus();
  
  boolean traverseFocusOut(boolean paramBoolean);
  
  void repaint();
  
  void setPreferredSize(int paramInt1, int paramInt2);
  
  void setEnabled(boolean paramBoolean);
  
  void setCursor(CursorFrame paramCursorFrame);
  
  boolean grabFocus();
  
  void ungrabFocus();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\embed\HostInterface.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */