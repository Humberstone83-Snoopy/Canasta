/*    */ package javafx.scene.media;
/*    */ 
/*    */ import javafx.event.ActionEvent;
/*    */ import javafx.util.Duration;
/*    */ import javafx.util.Pair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaMarkerEvent
/*    */   extends ActionEvent
/*    */ {
/*    */   private static final long serialVersionUID = 20121107L;
/*    */   private Pair<String, Duration> marker;
/*    */   
/*    */   MediaMarkerEvent(Pair<String, Duration> paramPair) {
/* 48 */     this.marker = paramPair;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Pair<String, Duration> getMarker() {
/* 57 */     return this.marker;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\MediaMarkerEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */