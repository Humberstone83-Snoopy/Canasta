/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.DirtyRegionContainer;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.scenario.effect.Blend;
/*     */ import com.sun.scenario.effect.FilterContext;
/*     */ import com.sun.scenario.effect.ImageData;
/*     */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*     */ import com.sun.scenario.effect.impl.prism.PrEffectHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGGroup
/*     */   extends NGNode
/*     */ {
/*  52 */   private Blend.Mode blendMode = Blend.Mode.SRC_OVER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private List<NGNode> children = new ArrayList<>(1);
/*  59 */   private List<NGNode> unmod = Collections.unmodifiableList(this.children);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<NGNode> removed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final List<NGNode> viewOrderChildren = new ArrayList<>(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int REGION_INTERSECTS_MASK = 357913941;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<NGNode> getChildren() {
/*  86 */     return this.unmod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int paramInt, NGNode paramNGNode) {
/*  96 */     if (paramInt < -1 || paramInt > this.children.size()) {
/*  97 */       throw new IndexOutOfBoundsException("invalid index");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     NGNode nGNode = paramNGNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     nGNode.setParent(this);
/* 116 */     this.childDirty = true;
/* 117 */     if (paramInt == -1) {
/* 118 */       this.children.add(paramNGNode);
/*     */     } else {
/* 120 */       this.children.add(paramInt, paramNGNode);
/*     */     } 
/* 122 */     nGNode.markDirty();
/* 123 */     markTreeDirtyNoIncrement();
/* 124 */     geometryChanged();
/*     */   }
/*     */   
/*     */   public void clearFrom(int paramInt) {
/* 128 */     if (paramInt < this.children.size()) {
/* 129 */       this.children.subList(paramInt, this.children.size()).clear();
/* 130 */       geometryChanged();
/* 131 */       this.childDirty = true;
/* 132 */       markTreeDirtyNoIncrement();
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<NGNode> getRemovedChildren() {
/* 137 */     return this.removed;
/*     */   }
/*     */   
/*     */   public void addToRemoved(NGNode paramNGNode) {
/* 141 */     if (this.removed == null) this.removed = new ArrayList<>(); 
/* 142 */     if (this.dirtyChildrenAccumulated > 12) {
/*     */       return;
/*     */     }
/*     */     
/* 146 */     this.removed.add(paramNGNode);
/* 147 */     this.dirtyChildrenAccumulated++;
/*     */     
/* 149 */     if (this.dirtyChildrenAccumulated > 12) {
/* 150 */       this.removed.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void clearDirty() {
/* 156 */     super.clearDirty();
/* 157 */     if (this.removed != null) this.removed.clear();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(NGNode paramNGNode) {
/* 166 */     this.children.remove(paramNGNode);
/* 167 */     geometryChanged();
/* 168 */     this.childDirty = true;
/* 169 */     markTreeDirtyNoIncrement();
/*     */   }
/*     */   
/*     */   public void remove(int paramInt) {
/* 173 */     this.children.remove(paramInt);
/* 174 */     geometryChanged();
/* 175 */     this.childDirty = true;
/* 176 */     markTreeDirtyNoIncrement();
/*     */   }
/*     */   
/*     */   public void clear() {
/* 180 */     this.children.clear();
/* 181 */     this.childDirty = false;
/* 182 */     geometryChanged();
/* 183 */     markTreeDirtyNoIncrement();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<NGNode> getOrderedChildren() {
/* 189 */     if (!this.viewOrderChildren.isEmpty()) {
/* 190 */       return this.viewOrderChildren;
/*     */     }
/* 192 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewOrderChildren(List<Node> paramList) {
/* 198 */     this.viewOrderChildren.clear();
/* 199 */     for (Node node : paramList) {
/* 200 */       NGNode nGNode = NodeHelper.getPeer(node);
/* 201 */       this.viewOrderChildren.add(nGNode);
/*     */     } 
/*     */ 
/*     */     
/* 205 */     visualsChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBlendMode(Object paramObject) {
/* 214 */     if (paramObject == null) {
/* 215 */       throw new IllegalArgumentException("Mode must be non-null");
/*     */     }
/*     */ 
/*     */     
/* 219 */     if (this.blendMode != paramObject) {
/* 220 */       this.blendMode = (Blend.Mode)paramObject;
/* 221 */       visualsChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderForcedContent(Graphics paramGraphics) {
/* 227 */     List<NGNode> list = getOrderedChildren();
/* 228 */     if (list == null) {
/*     */       return;
/*     */     }
/* 231 */     for (byte b = 0; b < list.size(); b++) {
/* 232 */       ((NGNode)list.get(b)).renderForcedContent(paramGraphics);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 238 */     List<NGNode> list = getOrderedChildren();
/* 239 */     if (list == null) {
/*     */       return;
/*     */     }
/*     */     
/* 243 */     NodePath nodePath = paramGraphics.getRenderRoot();
/* 244 */     int i = 0;
/* 245 */     if (nodePath != null) {
/* 246 */       if (nodePath.hasNext()) {
/* 247 */         nodePath.next();
/* 248 */         i = list.indexOf(nodePath.getCurrentNode());
/*     */         
/* 250 */         for (byte b = 0; b < i; b++) {
/* 251 */           ((NGNode)list.get(b)).clearDirtyTree();
/*     */         }
/*     */       } else {
/* 254 */         paramGraphics.setRenderRoot(null);
/*     */       } 
/*     */     }
/*     */     
/* 258 */     if (this.blendMode == Blend.Mode.SRC_OVER || list
/* 259 */       .size() < 2) {
/*     */       
/* 261 */       for (int j = i; j < list.size(); j++) {
/*     */         NGNode nGNode;
/*     */         try {
/* 264 */           nGNode = list.get(j);
/* 265 */         } catch (Exception exception) {
/* 266 */           nGNode = null;
/*     */         } 
/*     */         
/* 269 */         if (nGNode != null) {
/* 270 */           nGNode.render(paramGraphics);
/*     */         }
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 276 */     Blend blend = new Blend(this.blendMode, null, null);
/* 277 */     FilterContext filterContext = getFilterContext(paramGraphics);
/*     */     
/* 279 */     ImageData imageData = null;
/* 280 */     boolean bool = true;
/*     */     
/*     */     do {
/* 283 */       BaseTransform baseTransform = paramGraphics.getTransformNoClone().copy();
/* 284 */       if (imageData != null) {
/* 285 */         imageData.unref();
/* 286 */         imageData = null;
/*     */       } 
/* 288 */       Rectangle rectangle1 = PrEffectHelper.getGraphicsClipNoClone(paramGraphics);
/* 289 */       for (int j = i; j < list.size(); j++) {
/* 290 */         NGNode nGNode = list.get(j);
/*     */         
/* 292 */         ImageData imageData1 = NodeEffectInput.getImageDataForNode(filterContext, nGNode, false, baseTransform, rectangle1);
/* 293 */         if (imageData == null) {
/* 294 */           imageData = imageData1;
/*     */         } else {
/*     */           
/* 297 */           ImageData imageData2 = blend.filterImageDatas(filterContext, baseTransform, rectangle1, null, new ImageData[] { imageData, imageData1 });
/* 298 */           imageData.unref();
/* 299 */           imageData1.unref();
/* 300 */           imageData = imageData2;
/*     */         } 
/*     */       } 
/* 303 */       if (imageData == null || !(bool = imageData.validate(filterContext)))
/* 304 */         continue;  Rectangle rectangle2 = imageData.getUntransformedBounds();
/* 305 */       PrDrawable prDrawable = (PrDrawable)imageData.getUntransformedImage();
/* 306 */       paramGraphics.setTransform(imageData.getTransform());
/* 307 */       paramGraphics.drawTexture(prDrawable.getTextureObject(), rectangle2.x, rectangle2.y, rectangle2.width, rectangle2.height);
/*     */     
/*     */     }
/* 310 */     while (imageData == null || !bool);
/*     */     
/* 312 */     if (imageData != null) {
/* 313 */       imageData.unref();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 319 */     if (this.blendMode != Blend.Mode.SRC_OVER)
/*     */     {
/* 321 */       return false;
/*     */     }
/* 323 */     List<NGNode> list = getOrderedChildren();
/* 324 */     boolean bool = (list == null) ? false : list.size();
/* 325 */     if (bool == true) {
/* 326 */       return ((NGNode)list.get(0)).hasOverlappingContents();
/*     */     }
/* 328 */     return bool;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 332 */     return (this.children == null || this.children.isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasVisuals() {
/* 337 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needsBlending() {
/* 343 */     Blend.Mode mode = getNodeBlendMode();
/*     */ 
/*     */     
/* 346 */     return (mode != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NGNode.RenderRootResult computeRenderRoot(NodePath paramNodePath, RectBounds paramRectBounds, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 360 */     if (paramInt != -1) {
/* 361 */       int j = this.cullingBits >> paramInt * 2;
/* 362 */       if ((j & 0x3) == 0) {
/* 363 */         return NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */       }
/* 365 */       if ((j & 0x2) != 0) {
/* 366 */         paramInt = -1;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 371 */     if (!isVisible()) {
/* 372 */       return NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */     }
/*     */     
/* 375 */     if (getOpacity() != 1.0D || (getEffect() != null && getEffect().reducesOpaquePixels()) || needsBlending()) {
/* 376 */       return NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */     }
/*     */     
/* 379 */     if (getClipNode() != null) {
/* 380 */       NGNode nGNode = getClipNode();
/* 381 */       RectBounds rectBounds = nGNode.getOpaqueRegion();
/* 382 */       if (rectBounds == null) {
/* 383 */         return NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */       }
/* 385 */       TEMP_TRANSFORM.deriveWithNewTransform(paramBaseTransform).deriveWithConcatenation(getTransform()).deriveWithConcatenation(nGNode.getTransform());
/* 386 */       if (!checkBoundsInQuad(rectBounds, paramRectBounds, TEMP_TRANSFORM, paramGeneralTransform3D)) {
/* 387 */         return NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 393 */     double d1 = paramBaseTransform.getMxx();
/* 394 */     double d2 = paramBaseTransform.getMxy();
/* 395 */     double d3 = paramBaseTransform.getMxz();
/* 396 */     double d4 = paramBaseTransform.getMxt();
/*     */     
/* 398 */     double d5 = paramBaseTransform.getMyx();
/* 399 */     double d6 = paramBaseTransform.getMyy();
/* 400 */     double d7 = paramBaseTransform.getMyz();
/* 401 */     double d8 = paramBaseTransform.getMyt();
/*     */     
/* 403 */     double d9 = paramBaseTransform.getMzx();
/* 404 */     double d10 = paramBaseTransform.getMzy();
/* 405 */     double d11 = paramBaseTransform.getMzz();
/* 406 */     double d12 = paramBaseTransform.getMzt();
/* 407 */     BaseTransform baseTransform = paramBaseTransform.deriveWithConcatenation(getTransform());
/*     */ 
/*     */     
/* 410 */     NGNode.RenderRootResult renderRootResult = NGNode.RenderRootResult.NO_RENDER_ROOT;
/*     */     
/* 412 */     boolean bool = true;
/*     */     
/* 414 */     List<NGNode> list = getOrderedChildren();
/* 415 */     for (int i = list.size() - 1; i >= 0; i--) {
/*     */       
/* 417 */       NGNode nGNode = list.get(i);
/* 418 */       renderRootResult = nGNode.computeRenderRoot(paramNodePath, paramRectBounds, paramInt, baseTransform, paramGeneralTransform3D);
/*     */ 
/*     */       
/* 421 */       bool &= nGNode.isClean();
/*     */       
/* 423 */       if (renderRootResult == NGNode.RenderRootResult.HAS_RENDER_ROOT) {
/*     */ 
/*     */ 
/*     */         
/* 427 */         paramNodePath.add(this); break;
/*     */       } 
/* 429 */       if (renderRootResult == NGNode.RenderRootResult.HAS_RENDER_ROOT_AND_IS_CLEAN) {
/* 430 */         paramNodePath.add(this);
/*     */ 
/*     */ 
/*     */         
/* 434 */         if (!bool) {
/* 435 */           renderRootResult = NGNode.RenderRootResult.HAS_RENDER_ROOT;
/*     */         }
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 441 */     paramBaseTransform.restoreTransform(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12);
/* 442 */     return renderRootResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void markCullRegions(DirtyRegionContainer paramDirtyRegionContainer, int paramInt, BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D) {
/* 453 */     super.markCullRegions(paramDirtyRegionContainer, paramInt, paramBaseTransform, paramGeneralTransform3D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 458 */     if (this.cullingBits == -1 || (this.cullingBits != 0 && (this.cullingBits & 0x15555555) != 0)) {
/*     */       
/* 460 */       double d1 = paramBaseTransform.getMxx();
/* 461 */       double d2 = paramBaseTransform.getMxy();
/* 462 */       double d3 = paramBaseTransform.getMxz();
/* 463 */       double d4 = paramBaseTransform.getMxt();
/*     */       
/* 465 */       double d5 = paramBaseTransform.getMyx();
/* 466 */       double d6 = paramBaseTransform.getMyy();
/* 467 */       double d7 = paramBaseTransform.getMyz();
/* 468 */       double d8 = paramBaseTransform.getMyt();
/*     */       
/* 470 */       double d9 = paramBaseTransform.getMzx();
/* 471 */       double d10 = paramBaseTransform.getMzy();
/* 472 */       double d11 = paramBaseTransform.getMzz();
/* 473 */       double d12 = paramBaseTransform.getMzt();
/* 474 */       BaseTransform baseTransform = paramBaseTransform.deriveWithConcatenation(getTransform());
/*     */ 
/*     */       
/* 477 */       List<NGNode> list = getOrderedChildren();
/* 478 */       for (byte b = 0; b < list.size(); b++) {
/* 479 */         NGNode nGNode = list.get(b);
/* 480 */         nGNode.markCullRegions(paramDirtyRegionContainer, this.cullingBits, baseTransform, paramGeneralTransform3D);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 487 */       paramBaseTransform.restoreTransform(d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawDirtyOpts(BaseTransform paramBaseTransform, GeneralTransform3D paramGeneralTransform3D, Rectangle paramRectangle, int[] paramArrayOfint, int paramInt) {
/* 494 */     super.drawDirtyOpts(paramBaseTransform, paramGeneralTransform3D, paramRectangle, paramArrayOfint, paramInt);
/*     */ 
/*     */     
/* 497 */     BaseTransform baseTransform = paramBaseTransform.copy();
/* 498 */     baseTransform = baseTransform.deriveWithConcatenation(getTransform());
/* 499 */     List<NGNode> list = getOrderedChildren();
/* 500 */     for (byte b = 0; b < list.size(); b++) {
/* 501 */       NGNode nGNode = list.get(b);
/* 502 */       nGNode.drawDirtyOpts(baseTransform, paramGeneralTransform3D, paramRectangle, paramArrayOfint, paramInt);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGGroup.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */