/*     */ package javafx.beans.property;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.MapExpression;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyMapProperty<K, V>
/*     */   extends MapExpression<K, V>
/*     */   implements ReadOnlyProperty<ObservableMap<K, V>>
/*     */ {
/*     */   public void bindContentBidirectional(ObservableMap<K, V> paramObservableMap) {
/*  67 */     Bindings.bindContentBidirectional(this, paramObservableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContentBidirectional(Object paramObject) {
/*  79 */     Bindings.unbindContentBidirectional(this, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindContent(ObservableMap<K, V> paramObservableMap) {
/*  95 */     Bindings.bindContent(this, paramObservableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContent(Object paramObject) {
/* 107 */     Bindings.unbindContent(this, paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 112 */     if (paramObject == this) {
/* 113 */       return true;
/*     */     }
/* 115 */     if (!(paramObject instanceof Map))
/* 116 */       return false; 
/* 117 */     Map map = (Map)paramObject;
/* 118 */     if (map.size() != size()) {
/* 119 */       return false;
/*     */     }
/*     */     try {
/* 122 */       for (Map.Entry<K, V> entry : entrySet()) {
/* 123 */         Object object1 = entry.getKey();
/* 124 */         Object object2 = entry.getValue();
/* 125 */         if (object2 == null) {
/* 126 */           if (map.get(object1) != null || !map.containsKey(object1))
/* 127 */             return false;  continue;
/*     */         } 
/* 129 */         if (!object2.equals(map.get(object1))) {
/* 130 */           return false;
/*     */         }
/*     */       } 
/* 133 */     } catch (ClassCastException classCastException) {
/* 134 */       return false;
/* 135 */     } catch (NullPointerException nullPointerException) {
/* 136 */       return false;
/*     */     } 
/*     */     
/* 139 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 148 */     int i = 0;
/* 149 */     for (Map.Entry<K, V> entry : entrySet()) {
/* 150 */       i += entry.hashCode();
/*     */     }
/* 152 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 161 */     Object object = getBean();
/* 162 */     String str = getName();
/* 163 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyMapProperty [");
/*     */     
/* 165 */     if (object != null) {
/* 166 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 168 */     if (str != null && !str.equals("")) {
/* 169 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 171 */     stringBuilder.append("value: ").append(get()).append("]");
/* 172 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyMapProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */