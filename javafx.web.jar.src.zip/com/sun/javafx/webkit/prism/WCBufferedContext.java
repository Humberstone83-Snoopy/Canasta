/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.RoundRectangle2D;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.Affine3D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.sg.prism.NGRectangle;
/*     */ import com.sun.javafx.sg.prism.NodeEffectInput;
/*     */ import com.sun.prism.BasicStroke;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.scenario.effect.DropShadow;
/*     */ import com.sun.webkit.graphics.WCImage;
/*     */ import com.sun.webkit.graphics.WCTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCBufferedContext
/*     */   extends WCGraphicsPrismContext
/*     */ {
/*     */   private final PrismImage img;
/*     */   private boolean isInitialized;
/*     */   private final RectBounds TEMP_BOUNDS;
/*     */   private final NGRectangle TEMP_NGRECT;
/*     */   private final RoundRectangle2D TEMP_RECT;
/*     */   private final float[] TEMP_COORDS;
/*     */   
/*     */   WCBufferedContext(PrismImage paramPrismImage) {
/*  77 */     this.TEMP_BOUNDS = new RectBounds();
/*  78 */     this.TEMP_NGRECT = new NGRectangle();
/*  79 */     this.TEMP_RECT = new RoundRectangle2D();
/*  80 */     this.TEMP_COORDS = new float[6];
/*     */     this.img = paramPrismImage;
/*     */   }
/*     */   protected boolean shouldCalculateIntersection() {
/*  84 */     return (this.baseGraphics == null);
/*     */   } public WCGraphicsPrismContext.Type type() {
/*     */     return WCGraphicsPrismContext.Type.DEDICATED;
/*     */   }
/*     */   public WCImage getImage() {
/*     */     return this.img;
/*     */   }
/*     */   protected boolean shouldRenderRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, DropShadow paramDropShadow, BasicStroke paramBasicStroke) {
/*  92 */     if (!shouldCalculateIntersection())
/*     */     {
/*  94 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (paramDropShadow != null) {
/* 102 */       this.TEMP_RECT.setFrame(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 103 */       return shouldRenderShape(this.TEMP_RECT, paramDropShadow, paramBasicStroke);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 108 */     if (paramBasicStroke != null) {
/* 109 */       float f1 = 0.0F;
/* 110 */       float f2 = 0.0F;
/* 111 */       switch (paramBasicStroke.getType()) {
/*     */         case 0:
/* 113 */           f2 = paramBasicStroke.getLineWidth();
/* 114 */           f1 = f2 / 2.0F;
/*     */           break;
/*     */         case 2:
/* 117 */           f1 = paramBasicStroke.getLineWidth();
/* 118 */           f2 = f1 * 2.0F;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       paramFloat1 -= f1;
/* 126 */       paramFloat2 -= f1;
/* 127 */       paramFloat3 += f2;
/* 128 */       paramFloat4 += f2;
/*     */     } 
/* 130 */     this.TEMP_BOUNDS.setBounds(paramFloat1, paramFloat2, paramFloat1 + paramFloat3, paramFloat2 + paramFloat4);
/*     */ 
/*     */ 
/*     */     
/* 134 */     return trIntersectsClip(this.TEMP_BOUNDS, getTransformNoClone());
/*     */   } Graphics getGraphics(boolean paramBoolean) {
/*     */     init();
/*     */     if (this.baseGraphics == null)
/*     */       this.baseGraphics = this.img.getGraphics(); 
/*     */     return super.getGraphics(paramBoolean);
/*     */   }
/*     */   protected boolean shouldRenderShape(Shape paramShape, DropShadow paramDropShadow, BasicStroke paramBasicStroke) {
/* 142 */     if (!shouldCalculateIntersection())
/*     */     {
/* 144 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     BaseTransform baseTransform = (paramDropShadow != null) ? BaseTransform.IDENTITY_TRANSFORM : getTransformNoClone();
/*     */ 
/*     */ 
/*     */     
/* 154 */     this.TEMP_COORDS[1] = Float.POSITIVE_INFINITY; this.TEMP_COORDS[0] = Float.POSITIVE_INFINITY;
/* 155 */     this.TEMP_COORDS[3] = Float.NEGATIVE_INFINITY; this.TEMP_COORDS[2] = Float.NEGATIVE_INFINITY;
/* 156 */     if (paramBasicStroke == null) {
/* 157 */       Shape.accumulate(this.TEMP_COORDS, paramShape, baseTransform);
/*     */     } else {
/* 159 */       paramBasicStroke.accumulateShapeBounds(this.TEMP_COORDS, paramShape, baseTransform);
/*     */     } 
/* 161 */     this.TEMP_BOUNDS.setBounds(this.TEMP_COORDS[0], this.TEMP_COORDS[1], this.TEMP_COORDS[2], this.TEMP_COORDS[3]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     Affine3D affine3D = null;
/* 167 */     if (paramDropShadow != null) {
/* 168 */       this.TEMP_NGRECT.updateRectangle(this.TEMP_BOUNDS.getMinX(), this.TEMP_BOUNDS.getMinY(), this.TEMP_BOUNDS
/* 169 */           .getWidth(), this.TEMP_BOUNDS.getHeight(), 0.0F, 0.0F);
/*     */       
/* 171 */       this.TEMP_NGRECT.setContentBounds(this.TEMP_BOUNDS);
/* 172 */       BaseBounds baseBounds = paramDropShadow.getBounds(BaseTransform.IDENTITY_TRANSFORM, new NodeEffectInput(this.TEMP_NGRECT));
/*     */       
/* 174 */       assert baseBounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE;
/* 175 */       this.TEMP_BOUNDS.setBounds((RectBounds)baseBounds);
/*     */       
/* 177 */       affine3D = getTransformNoClone();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     return trIntersectsClip(this.TEMP_BOUNDS, affine3D);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean trIntersectsClip(RectBounds paramRectBounds, BaseTransform paramBaseTransform) {
/* 187 */     if (paramBaseTransform != null && !paramBaseTransform.isIdentity()) {
/* 188 */       paramBaseTransform.transform(paramRectBounds, paramRectBounds);
/*     */     }
/* 190 */     Rectangle rectangle = getClipRectNoClone();
/* 191 */     if (rectangle != null) {
/* 192 */       return paramRectBounds.intersects(rectangle.x, rectangle.y, (rectangle.x + rectangle.width), (rectangle.y + rectangle.height));
/*     */     }
/* 194 */     if (this.img != null) {
/* 195 */       return paramRectBounds.intersects(0.0F, 0.0F, this.img
/* 196 */           .getWidth() * this.img.getPixelScale(), this.img
/* 197 */           .getHeight() * this.img.getPixelScale());
/*     */     }
/* 199 */     return false;
/*     */   }
/*     */   
/*     */   public void saveState() {
/* 203 */     init();
/* 204 */     super.saveState();
/*     */   }
/*     */   
/*     */   public void setTransform(WCTransform paramWCTransform) {
/* 208 */     init();
/* 209 */     super.setTransform(paramWCTransform);
/*     */   }
/*     */   
/*     */   private void init() {
/* 213 */     if (!this.isInitialized) {
/* 214 */       BaseTransform baseTransform = PrismGraphicsManager.getPixelScaleTransform();
/* 215 */       initBaseTransform(baseTransform);
/* 216 */       setClip(0, 0, this.img.getWidth(), this.img.getHeight());
/* 217 */       this.isInitialized = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void dispose() {}
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCBufferedContext.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */