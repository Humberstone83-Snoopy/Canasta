/*    */ package com.sun.javafx.webkit;
/*    */ 
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import com.sun.webkit.EventLoop;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import javafx.application.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EventLoopImpl
/*    */   extends EventLoop
/*    */ {
/*    */   private static final long DELAY = 20L;
/* 40 */   private static final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void cycle() {
/* 50 */     Object object = new Object();
/* 51 */     executor.schedule(() -> Platform.runLater(new Runnable()
/*    */           {
/*    */             public void run()
/*    */             {
/* 55 */               Toolkit.getToolkit().exitNestedEventLoop(key, null);
/*    */             }
/*    */           }), 20L, TimeUnit.MILLISECONDS);
/*    */     
/* 59 */     Toolkit.getToolkit().enterNestedEventLoop(object);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\EventLoopImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */