/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.DocumentFragment;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.NodeList;
/*    */ import org.w3c.dom.html.HTMLCollection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DocumentFragmentImpl
/*    */   extends NodeImpl
/*    */   implements DocumentFragment
/*    */ {
/*    */   DocumentFragmentImpl(long paramLong) {
/* 36 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static DocumentFragment getImpl(long paramLong) {
/* 40 */     return (DocumentFragment)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getChildrenImpl(long paramLong);
/*    */   
/*    */   public HTMLCollection getChildren() {
/* 46 */     return HTMLCollectionImpl.getImpl(getChildrenImpl(getPeer()));
/*    */   }
/*    */   static native long getFirstElementChildImpl(long paramLong);
/*    */   
/*    */   public Element getFirstElementChild() {
/* 51 */     return ElementImpl.getImpl(getFirstElementChildImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public Element getLastElementChild() {
/* 56 */     return ElementImpl.getImpl(getLastElementChildImpl(getPeer()));
/*    */   }
/*    */   static native long getLastElementChildImpl(long paramLong);
/*    */   
/*    */   public int getChildElementCount() {
/* 61 */     return getChildElementCountImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native int getChildElementCountImpl(long paramLong);
/*    */ 
/*    */   
/*    */   public Element getElementById(String paramString) {
/* 69 */     return ElementImpl.getImpl(getElementByIdImpl(getPeer(), paramString));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native long getElementByIdImpl(long paramLong, String paramString);
/*    */ 
/*    */   
/*    */   public Element querySelector(String paramString) throws DOMException {
/* 78 */     return ElementImpl.getImpl(querySelectorImpl(getPeer(), paramString));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native long querySelectorImpl(long paramLong, String paramString);
/*    */ 
/*    */   
/*    */   public NodeList querySelectorAll(String paramString) throws DOMException {
/* 87 */     return NodeListImpl.getImpl(querySelectorAllImpl(getPeer(), paramString));
/*    */   }
/*    */   
/*    */   static native long querySelectorAllImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\DocumentFragmentImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */