/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MetadataParser;
/*     */ import com.sun.media.jfxmedia.events.MetadataListener;
/*     */ import com.sun.media.jfxmedia.locator.ConnectionHolder;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MetadataParserImpl
/*     */   extends Thread
/*     */   implements MetadataParser
/*     */ {
/*  45 */   private final List<WeakReference<MetadataListener>> listeners = new ArrayList<>();
/*  46 */   private Map<String, Object> metadata = new HashMap<>();
/*  47 */   private Locator locator = null;
/*  48 */   private ConnectionHolder connectionHolder = null;
/*  49 */   private ByteBuffer buffer = null;
/*  50 */   private Map<String, ByteBuffer> rawMetaMap = null;
/*  51 */   protected ByteBuffer rawMetaBlob = null;
/*     */   private boolean parsingRawMetadata = false;
/*  53 */   private int length = 0;
/*  54 */   private int index = 0;
/*  55 */   private int streamPosition = 0;
/*     */   
/*     */   public MetadataParserImpl(Locator paramLocator) {
/*  58 */     this.locator = paramLocator;
/*     */   }
/*     */   
/*     */   public void addListener(MetadataListener paramMetadataListener) {
/*  62 */     synchronized (this.listeners) {
/*  63 */       if (paramMetadataListener != null) {
/*  64 */         this.listeners.add(new WeakReference<>(paramMetadataListener));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeListener(MetadataListener paramMetadataListener) {
/*  70 */     synchronized (this.listeners) {
/*  71 */       if (paramMetadataListener != null) {
/*  72 */         for (ListIterator<WeakReference<MetadataListener>> listIterator = this.listeners.listIterator(); listIterator.hasNext(); ) {
/*  73 */           MetadataListener metadataListener = ((WeakReference<MetadataListener>)listIterator.next()).get();
/*  74 */           if (metadataListener == null || metadataListener == paramMetadataListener) {
/*  75 */             listIterator.remove();
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void startParser() throws IOException {
/*  83 */     start();
/*     */   }
/*     */   
/*     */   public void stopParser() {
/*  87 */     if (this.connectionHolder != null) {
/*  88 */       this.connectionHolder.closeConnection();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  95 */       this.connectionHolder = this.locator.createConnectionHolder();
/*  96 */       parse();
/*  97 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void parse();
/*     */   
/*     */   protected void addMetadataItem(String paramString, Object paramObject) {
/* 104 */     this.metadata.put(paramString, paramObject);
/*     */   }
/*     */   
/*     */   protected void done() {
/* 108 */     synchronized (this.listeners) {
/* 109 */       if (!this.metadata.isEmpty()) {
/* 110 */         for (ListIterator<WeakReference<MetadataListener>> listIterator = this.listeners.listIterator(); listIterator.hasNext(); ) {
/* 111 */           MetadataListener metadataListener = ((WeakReference<MetadataListener>)listIterator.next()).get();
/* 112 */           if (metadataListener != null) {
/* 113 */             metadataListener.onMetadata(this.metadata); continue;
/*     */           } 
/* 115 */           listIterator.remove();
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getStreamPosition() {
/* 123 */     if (this.parsingRawMetadata) {
/* 124 */       return this.rawMetaBlob.position();
/*     */     }
/* 126 */     return this.streamPosition;
/*     */   }
/*     */   
/*     */   protected void startRawMetadata(int paramInt) {
/* 130 */     this.rawMetaBlob = ByteBuffer.allocate(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   private void adjustRawMetadataSize(int paramInt) {
/* 135 */     if (this.rawMetaBlob.remaining() < paramInt) {
/* 136 */       int i = this.rawMetaBlob.position();
/* 137 */       int j = i + paramInt;
/* 138 */       ByteBuffer byteBuffer = ByteBuffer.allocate(j);
/* 139 */       this.rawMetaBlob.position(0);
/* 140 */       byteBuffer.put(this.rawMetaBlob.array(), 0, i);
/* 141 */       this.rawMetaBlob = byteBuffer;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void readRawMetadata(int paramInt) throws IOException {
/* 147 */     byte[] arrayOfByte = getBytes(paramInt);
/* 148 */     adjustRawMetadataSize(paramInt);
/* 149 */     if (null != arrayOfByte) {
/* 150 */       this.rawMetaBlob.put(arrayOfByte);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void stuffRawMetadata(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 156 */     if (null != this.rawMetaBlob) {
/* 157 */       adjustRawMetadataSize(paramInt2);
/* 158 */       this.rawMetaBlob.put(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void disposeRawMetadata() {
/* 163 */     this.parsingRawMetadata = false;
/* 164 */     this.rawMetaBlob = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setParseRawMetadata(boolean paramBoolean) {
/* 169 */     if (null == this.rawMetaBlob) {
/* 170 */       this.parsingRawMetadata = false;
/*     */       
/*     */       return;
/*     */     } 
/* 174 */     if (paramBoolean) {
/* 175 */       this.rawMetaBlob.position(0);
/*     */     }
/* 177 */     this.parsingRawMetadata = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addRawMetadata(String paramString) {
/* 182 */     if (null == this.rawMetaBlob) {
/*     */       return;
/*     */     }
/*     */     
/* 186 */     if (null == this.rawMetaMap) {
/* 187 */       this.rawMetaMap = new HashMap<>();
/*     */       
/* 189 */       this.metadata.put("raw metadata", Collections.unmodifiableMap(this.rawMetaMap));
/*     */     } 
/* 191 */     this.rawMetaMap.put(paramString, this.rawMetaBlob.asReadOnlyBuffer());
/*     */   }
/*     */   
/*     */   protected void skipBytes(int paramInt) throws IOException, EOFException {
/* 195 */     if (this.parsingRawMetadata) {
/* 196 */       this.rawMetaBlob.position(this.rawMetaBlob.position() + paramInt);
/*     */       
/*     */       return;
/*     */     } 
/* 200 */     for (byte b = 0; b < paramInt; b++) {
/* 201 */       getNextByte();
/*     */     }
/*     */   }
/*     */   
/*     */   protected byte getNextByte() throws IOException, EOFException {
/* 206 */     if (this.parsingRawMetadata)
/*     */     {
/* 208 */       return this.rawMetaBlob.get();
/*     */     }
/*     */     
/* 211 */     if (this.buffer == null) {
/* 212 */       this.buffer = this.connectionHolder.getBuffer();
/* 213 */       this.length = this.connectionHolder.readNextBlock();
/*     */     } 
/*     */     
/* 216 */     if (this.index >= this.length) {
/* 217 */       this.length = this.connectionHolder.readNextBlock();
/* 218 */       if (this.length < 1) {
/* 219 */         throw new EOFException();
/*     */       }
/* 221 */       this.index = 0;
/*     */     } 
/*     */     
/* 224 */     byte b = this.buffer.get(this.index);
/* 225 */     this.index++;
/* 226 */     this.streamPosition++;
/* 227 */     return b;
/*     */   }
/*     */   
/*     */   protected byte[] getBytes(int paramInt) throws IOException, EOFException {
/* 231 */     byte[] arrayOfByte = new byte[paramInt];
/*     */     
/* 233 */     if (this.parsingRawMetadata) {
/* 234 */       this.rawMetaBlob.get(arrayOfByte);
/* 235 */       return arrayOfByte;
/*     */     } 
/*     */     
/* 238 */     for (byte b = 0; b < paramInt; b++) {
/* 239 */       arrayOfByte[b] = getNextByte();
/*     */     }
/*     */     
/* 242 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   protected long getLong() throws IOException, EOFException {
/* 246 */     if (this.parsingRawMetadata) {
/* 247 */       return this.rawMetaBlob.getLong();
/*     */     }
/*     */     
/* 250 */     long l = 0L;
/*     */     
/* 252 */     l |= (getNextByte() & 0xFF);
/* 253 */     l <<= 8L;
/* 254 */     l |= (getNextByte() & 0xFF);
/* 255 */     l <<= 8L;
/* 256 */     l |= (getNextByte() & 0xFF);
/* 257 */     l <<= 8L;
/* 258 */     l |= (getNextByte() & 0xFF);
/* 259 */     l <<= 8L;
/* 260 */     l |= (getNextByte() & 0xFF);
/* 261 */     l <<= 8L;
/* 262 */     l |= (getNextByte() & 0xFF);
/* 263 */     l <<= 8L;
/* 264 */     l |= (getNextByte() & 0xFF);
/* 265 */     l <<= 8L;
/* 266 */     l |= (getNextByte() & 0xFF);
/*     */     
/* 268 */     return l;
/*     */   }
/*     */   
/*     */   protected int getInteger() throws IOException, EOFException {
/* 272 */     if (this.parsingRawMetadata) {
/* 273 */       return this.rawMetaBlob.getInt();
/*     */     }
/*     */     
/* 276 */     int i = 0;
/*     */     
/* 278 */     i |= getNextByte() & 0xFF;
/* 279 */     i <<= 8;
/* 280 */     i |= getNextByte() & 0xFF;
/* 281 */     i <<= 8;
/* 282 */     i |= getNextByte() & 0xFF;
/* 283 */     i <<= 8;
/* 284 */     i |= getNextByte() & 0xFF;
/*     */     
/* 286 */     return i;
/*     */   }
/*     */   
/*     */   protected short getShort() throws IOException, EOFException {
/* 290 */     if (this.parsingRawMetadata) {
/* 291 */       return this.rawMetaBlob.getShort();
/*     */     }
/*     */     
/* 294 */     short s = 0;
/*     */     
/* 296 */     s = (short)(s | getNextByte() & 0xFF);
/* 297 */     s = (short)(s << 8);
/* 298 */     s = (short)(s | getNextByte() & 0xFF);
/*     */     
/* 300 */     return s;
/*     */   }
/*     */   
/*     */   protected double getDouble() throws IOException, EOFException {
/* 304 */     if (this.parsingRawMetadata) {
/* 305 */       return this.rawMetaBlob.getDouble();
/*     */     }
/*     */     
/* 308 */     long l = getLong();
/* 309 */     return Double.longBitsToDouble(l);
/*     */   }
/*     */   
/*     */   protected String getString(int paramInt, Charset paramCharset) throws IOException, EOFException {
/* 313 */     byte[] arrayOfByte = getBytes(paramInt);
/* 314 */     return new String(arrayOfByte, 0, paramInt, paramCharset);
/*     */   }
/*     */   
/*     */   protected int getU24() throws IOException, EOFException {
/* 318 */     int i = 0;
/*     */     
/* 320 */     i |= getNextByte() & 0xFF;
/* 321 */     i <<= 8;
/* 322 */     i |= getNextByte() & 0xFF;
/* 323 */     i <<= 8;
/* 324 */     i |= getNextByte() & 0xFF;
/*     */     
/* 326 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object convertValue(String paramString, Object paramObject) {
/* 331 */     if (paramString.equals("duration") && paramObject instanceof Double) {
/* 332 */       Double double_ = Double.valueOf(((Double)paramObject).doubleValue() * 1000.0D);
/* 333 */       return Long.valueOf(double_.longValue());
/* 334 */     }  if (paramString.equals("duration") && paramObject instanceof String) {
/* 335 */       String str = (String)paramObject;
/* 336 */       return Long.valueOf(str.trim());
/* 337 */     }  if (paramString.equals("audiocodecid"))
/*     */     {
/* 339 */       return "MPEG 1 Audio"; } 
/* 340 */     if (paramString.equals("creationdate"))
/* 341 */       return ((String)paramObject).trim(); 
/* 342 */     if (paramString.equals("track number") || paramString.equals("disc number")) {
/* 343 */       String[] arrayOfString = ((String)paramObject).split("/");
/* 344 */       if (arrayOfString.length == 2) {
/* 345 */         return Integer.valueOf(arrayOfString[0].trim());
/*     */       }
/* 347 */     } else if (paramString.equals("track count") || paramString.equals("disc count")) {
/* 348 */       String[] arrayOfString = ((String)paramObject).split("/");
/* 349 */       if (arrayOfString.length == 2)
/* 350 */         return Integer.valueOf(arrayOfString[1].trim()); 
/*     */     } else {
/* 352 */       if (paramString.equals("album"))
/* 353 */         return paramObject; 
/* 354 */       if (paramString.equals("artist"))
/* 355 */         return paramObject; 
/* 356 */       if (paramString.equals("genre"))
/* 357 */         return paramObject; 
/* 358 */       if (paramString.equals("title"))
/* 359 */         return paramObject; 
/* 360 */       if (paramString.equals("album artist"))
/* 361 */         return paramObject; 
/* 362 */       if (paramString.equals("comment"))
/* 363 */         return paramObject; 
/* 364 */       if (paramString.equals("composer"))
/* 365 */         return paramObject; 
/* 366 */       if (paramString.equals("year")) {
/* 367 */         String str = (String)paramObject;
/* 368 */         return Integer.valueOf(str.trim());
/*     */       } 
/*     */     } 
/* 371 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\MetadataParserImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */