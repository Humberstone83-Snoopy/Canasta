/*    */ package javafx.util.converter;
/*    */ 
/*    */ import java.text.Format;
/*    */ import java.text.ParsePosition;
/*    */ import javafx.beans.NamedArg;
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormatStringConverter<T>
/*    */   extends StringConverter<T>
/*    */ {
/*    */   final Format format;
/*    */   
/*    */   public FormatStringConverter(@NamedArg("format") Format paramFormat) {
/* 47 */     this.format = paramFormat;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T fromString(String paramString) {
/* 55 */     if (paramString == null) {
/* 56 */       return null;
/*    */     }
/*    */     
/* 59 */     paramString = paramString.trim();
/*    */     
/* 61 */     if (paramString.length() < 1) {
/* 62 */       return null;
/*    */     }
/*    */ 
/*    */     
/* 66 */     Format format = getFormat();
/*    */ 
/*    */ 
/*    */     
/* 70 */     ParsePosition parsePosition = new ParsePosition(0);
/* 71 */     Object object = format.parseObject(paramString, parsePosition);
/* 72 */     if (parsePosition.getIndex() != paramString.length()) {
/* 73 */       throw new RuntimeException("Parsed string not according to the format");
/*    */     }
/* 75 */     return (T)object;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(T paramT) {
/* 81 */     if (paramT == null) {
/* 82 */       return "";
/*    */     }
/*    */ 
/*    */     
/* 86 */     Format format = getFormat();
/*    */ 
/*    */     
/* 89 */     return format.format(paramT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Format getFormat() {
/* 99 */     return this.format;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\FormatStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */