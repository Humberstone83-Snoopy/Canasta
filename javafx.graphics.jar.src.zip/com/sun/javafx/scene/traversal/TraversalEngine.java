/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import com.sun.javafx.application.PlatformImpl;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.geometry.BoundingBox;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TraversalEngine
/*     */ {
/*  50 */   static final Algorithm DEFAULT_ALGORITHM = PlatformImpl.isContextual2DNavigation() ? new Hueristic2D() : new ContainerTabOrder();
/*     */   
/*  52 */   private final TraversalContext context = new EngineContext();
/*     */   
/*  54 */   private final TempEngineContext tempEngineContext = new TempEngineContext();
/*     */   
/*     */   protected final Algorithm algorithm;
/*  57 */   private final Bounds initialBounds = new BoundingBox(0.0D, 0.0D, 1.0D, 1.0D);
/*  58 */   private final ArrayList<TraverseListener> listeners = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TraversalEngine(Algorithm paramAlgorithm) {
/*  65 */     this.algorithm = paramAlgorithm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TraversalEngine() {
/*  73 */     this.algorithm = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addTraverseListener(TraverseListener paramTraverseListener) {
/*  82 */     this.listeners.add(paramTraverseListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void notifyTraversedTo(Node paramNode) {
/*  90 */     for (TraverseListener traverseListener : this.listeners) {
/*  91 */       traverseListener.onTraverse(paramNode, getLayoutBounds(paramNode, getRoot()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node select(Node paramNode, Direction paramDirection) {
/* 104 */     return this.algorithm.select(paramNode, paramDirection, this.context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node selectFirst() {
/* 114 */     return this.algorithm.selectFirst(this.context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Node selectLast() {
/* 124 */     return this.algorithm.selectLast(this.context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean canTraverse() {
/* 139 */     return (this.algorithm != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Bounds getLayoutBounds(Node paramNode, Parent paramParent) {
/*     */     Bounds bounds;
/* 149 */     if (paramNode != null) {
/* 150 */       if (paramParent == null) {
/* 151 */         bounds = paramNode.localToScene(paramNode.getLayoutBounds());
/*     */       } else {
/* 153 */         bounds = paramParent.sceneToLocal(paramNode.localToScene(paramNode.getLayoutBounds()));
/*     */       } 
/*     */     } else {
/* 156 */       bounds = this.initialBounds;
/*     */     } 
/* 158 */     return bounds;
/*     */   }
/*     */   
/*     */   protected abstract Parent getRoot();
/*     */   
/*     */   private final class EngineContext extends BaseEngineContext {
/*     */     public Parent getRoot() {
/* 165 */       return TraversalEngine.this.getRoot();
/*     */     }
/*     */     
/*     */     private EngineContext() {}
/*     */   }
/*     */   
/*     */   private final class TempEngineContext extends BaseEngineContext {
/*     */     private Parent root;
/*     */     
/*     */     private TempEngineContext() {}
/*     */     
/*     */     public Parent getRoot() {
/* 177 */       return this.root;
/*     */     }
/*     */     
/*     */     public void setRoot(Parent param1Parent) {
/* 181 */       this.root = param1Parent;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private abstract class BaseEngineContext
/*     */     implements TraversalContext
/*     */   {
/*     */     private BaseEngineContext() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Node> getAllTargetNodes() {
/* 195 */       ArrayList<Node> arrayList = new ArrayList();
/* 196 */       addFocusableChildrenToList(arrayList, getRoot());
/* 197 */       return arrayList;
/*     */     }
/*     */ 
/*     */     
/*     */     public Bounds getSceneLayoutBounds(Node param1Node) {
/* 202 */       return TraversalEngine.this.getLayoutBounds(param1Node, null);
/*     */     }
/*     */     
/*     */     private void addFocusableChildrenToList(List<Node> param1List, Parent param1Parent) {
/* 206 */       ObservableList<Node> observableList = param1Parent.getChildrenUnmodifiable();
/* 207 */       for (Node node : observableList) {
/* 208 */         if (node.isFocusTraversable() && !node.isFocused() && NodeHelper.isTreeVisible(node) && !node.isDisabled()) {
/* 209 */           param1List.add(node);
/*     */         }
/* 211 */         if (node instanceof Parent) {
/* 212 */           addFocusableChildrenToList(param1List, (Parent)node);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Node selectFirstInParent(Parent param1Parent) {
/* 223 */       TraversalEngine.this.tempEngineContext.setRoot(param1Parent);
/* 224 */       return TraversalEngine.DEFAULT_ALGORITHM.selectFirst(TraversalEngine.this.tempEngineContext);
/*     */     }
/*     */ 
/*     */     
/*     */     public Node selectLastInParent(Parent param1Parent) {
/* 229 */       TraversalEngine.this.tempEngineContext.setRoot(param1Parent);
/* 230 */       return TraversalEngine.DEFAULT_ALGORITHM.selectLast(TraversalEngine.this.tempEngineContext);
/*     */     }
/*     */ 
/*     */     
/*     */     public Node selectInSubtree(Parent param1Parent, Node param1Node, Direction param1Direction) {
/* 235 */       TraversalEngine.this.tempEngineContext.setRoot(param1Parent);
/* 236 */       return TraversalEngine.DEFAULT_ALGORITHM.select(param1Node, param1Direction, TraversalEngine.this.tempEngineContext);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\TraversalEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */