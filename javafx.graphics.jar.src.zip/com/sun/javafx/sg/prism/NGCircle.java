/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Ellipse2D;
/*    */ import com.sun.javafx.geom.RectBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.prism.shape.ShapeRep;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGCircle
/*    */   extends NGShape
/*    */ {
/*    */   static final float HALF_SQRT_HALF = 0.353F;
/* 48 */   private Ellipse2D ellipse = new Ellipse2D();
/*    */   private float cx;
/*    */   
/*    */   public void updateCircle(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 52 */     this.ellipse.x = paramFloat1 - paramFloat3;
/* 53 */     this.ellipse.y = paramFloat2 - paramFloat3;
/* 54 */     this.ellipse.width = paramFloat3 * 2.0F;
/* 55 */     this.ellipse.height = this.ellipse.width;
/* 56 */     this.cx = paramFloat1;
/* 57 */     this.cy = paramFloat2;
/* 58 */     geometryChanged();
/*    */   }
/*    */   private float cy;
/*    */   
/*    */   public Shape getShape() {
/* 63 */     return this.ellipse;
/*    */   }
/*    */   protected boolean supportsOpaqueRegions() {
/* 66 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean hasOpaqueRegion() {
/* 76 */     return (super.hasOpaqueRegion() && this.ellipse.width > 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/* 81 */     float f = this.ellipse.width * 0.353F;
/* 82 */     return (RectBounds)paramRectBounds.deriveWithNewBounds(this.cx - f, this.cy - f, 0.0F, this.cx + f, this.cy + f, 0.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ShapeRep createShapeRep(Graphics paramGraphics) {
/* 91 */     return paramGraphics.getResourceFactory().createEllipseRep();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGCircle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */