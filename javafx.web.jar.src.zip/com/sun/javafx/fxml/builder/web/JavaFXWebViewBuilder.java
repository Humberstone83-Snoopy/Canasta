/*    */ package com.sun.javafx.fxml.builder.web;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import javafx.scene.web.WebEngine;
/*    */ import javafx.scene.web.WebView;
/*    */ import javafx.util.Builder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaFXWebViewBuilder
/*    */   extends AbstractMap<String, Object>
/*    */   implements Builder<WebView>
/*    */ {
/* 50 */   private final WebView view = new WebView();
/*    */   
/* 52 */   private String location = "";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WebView build() {
/* 60 */     WebEngine webEngine = this.view.getEngine();
/* 61 */     if (this.location != null) {
/* 62 */       webEngine.load(this.location);
/*    */     }
/*    */     
/* 65 */     return this.view;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object put(String paramString, Object paramObject) {
/* 70 */     if (paramObject != null) {
/* 71 */       String str = paramObject.toString();
/*    */       
/* 73 */       if ("location".equals(paramString)) {
/* 74 */         this.location = str;
/* 75 */       } else if ("onAlert".equals(paramString)) {
/*    */       
/*    */       } 
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 82 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<Map.Entry<String, Object>> entrySet() {
/* 87 */     throw new UnsupportedOperationException("Not yet implemented");
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\fxml\builder\web\JavaFXWebViewBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */