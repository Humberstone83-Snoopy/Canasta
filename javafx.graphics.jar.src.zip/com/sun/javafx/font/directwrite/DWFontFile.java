/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.Disposer;
/*     */ import com.sun.javafx.font.FontStrikeDesc;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.font.PrismFontStrike;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DWFontFile
/*     */   extends PrismFontFile
/*     */ {
/*     */   private IDWriteFontFace fontFace;
/*     */   private DWDisposer disposer;
/*     */   
/*     */   DWFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  43 */     super(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*  44 */     this.fontFace = createFontFace();
/*     */     
/*  46 */     if (PrismFontFactory.debugFonts && 
/*  47 */       this.fontFace == null) {
/*  48 */       System.err.println("Failed to create IDWriteFontFace for " + this);
/*     */     }
/*     */ 
/*     */     
/*  52 */     if (paramBoolean3) {
/*  53 */       this.disposer = new DWDisposer(this.fontFace);
/*  54 */       Disposer.addRecord(this, this.disposer);
/*     */     } 
/*     */   }
/*     */   
/*     */   private IDWriteFontFace createEmbeddedFontFace() {
/*  59 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*  60 */     IDWriteFontFile iDWriteFontFile = iDWriteFactory.CreateFontFileReference(getFileName());
/*  61 */     if (iDWriteFontFile == null) return null; 
/*  62 */     boolean[] arrayOfBoolean = new boolean[1];
/*  63 */     int[] arrayOfInt1 = new int[1];
/*  64 */     int[] arrayOfInt2 = new int[1];
/*  65 */     int[] arrayOfInt3 = new int[1];
/*  66 */     int i = iDWriteFontFile.Analyze(arrayOfBoolean, arrayOfInt1, arrayOfInt2, arrayOfInt3);
/*  67 */     IDWriteFontFace iDWriteFontFace = null;
/*  68 */     if (i == 0 && arrayOfBoolean[0]) {
/*  69 */       int j = getFontIndex();
/*  70 */       boolean bool = false;
/*  71 */       iDWriteFontFace = iDWriteFactory.CreateFontFace(arrayOfInt2[0], iDWriteFontFile, j, bool);
/*     */     } 
/*  73 */     iDWriteFontFile.Release();
/*  74 */     return iDWriteFontFace;
/*     */   }
/*     */   
/*     */   private IDWriteFontFace createFontFace() {
/*  78 */     if (isEmbeddedFont()) {
/*  79 */       return createEmbeddedFontFace();
/*     */     }
/*     */     
/*  82 */     IDWriteFontCollection iDWriteFontCollection = DWFactory.getFontCollection();
/*  83 */     int i = iDWriteFontCollection.FindFamilyName(getFamilyName());
/*  84 */     if (i == -1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       return createEmbeddedFontFace();
/*     */     }
/*     */     
/*  95 */     IDWriteFontFamily iDWriteFontFamily = iDWriteFontCollection.GetFontFamily(i);
/*  96 */     if (iDWriteFontFamily == null) return null;
/*     */     
/*  98 */     char c = isBold() ? 'ʼ' : 'Ɛ';
/*  99 */     byte b = 5;
/*     */     
/* 101 */     boolean bool = isItalic() ? true : false;
/* 102 */     IDWriteFont iDWriteFont = iDWriteFontFamily.GetFirstMatchingFont(c, b, bool);
/* 103 */     iDWriteFontFamily.Release();
/* 104 */     if (iDWriteFont == null) return null; 
/* 105 */     IDWriteFontFace iDWriteFontFace = iDWriteFont.CreateFontFace();
/* 106 */     iDWriteFont.Release();
/* 107 */     return iDWriteFontFace;
/*     */   }
/*     */   
/*     */   IDWriteFontFace getFontFace() {
/* 111 */     return this.fontFace;
/*     */   }
/*     */   
/*     */   Path2D getGlyphOutline(int paramInt, float paramFloat) {
/* 115 */     if (this.fontFace == null) return null; 
/* 116 */     if (paramFloat == 0.0F) return new Path2D(); 
/* 117 */     return this.fontFace.GetGlyphRunOutline(paramFloat, (short)paramInt, false);
/*     */   }
/*     */ 
/*     */   
/*     */   RectBounds getBBox(int paramInt, float paramFloat) {
/* 122 */     float[] arrayOfFloat = new float[4];
/* 123 */     getGlyphBoundingBox(paramInt, paramFloat, arrayOfFloat);
/* 124 */     return new RectBounds(arrayOfFloat[0], arrayOfFloat[1], arrayOfFloat[2], arrayOfFloat[3]);
/*     */   }
/*     */   
/*     */   protected int[] createGlyphBoundingBox(int paramInt) {
/* 128 */     if (this.fontFace == null) return null; 
/* 129 */     DWRITE_GLYPH_METRICS dWRITE_GLYPH_METRICS = this.fontFace.GetDesignGlyphMetrics((short)paramInt, false);
/* 130 */     if (dWRITE_GLYPH_METRICS == null) return null; 
/* 131 */     int[] arrayOfInt = new int[4];
/* 132 */     arrayOfInt[0] = dWRITE_GLYPH_METRICS.leftSideBearing;
/* 133 */     arrayOfInt[1] = dWRITE_GLYPH_METRICS.verticalOriginY - dWRITE_GLYPH_METRICS.advanceHeight + dWRITE_GLYPH_METRICS.bottomSideBearing;
/* 134 */     arrayOfInt[2] = dWRITE_GLYPH_METRICS.advanceWidth - dWRITE_GLYPH_METRICS.rightSideBearing;
/* 135 */     arrayOfInt[3] = dWRITE_GLYPH_METRICS.verticalOriginY - dWRITE_GLYPH_METRICS.topSideBearing;
/* 136 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontStrike<DWFontFile> createStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/* 142 */     return new DWFontStrike(this, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void disposeOnShutdown() {
/* 149 */     if (this.fontFace != null) {
/*     */ 
/*     */       
/* 152 */       if (this.disposer != null) {
/* 153 */         this.disposer.dispose();
/*     */       } else {
/* 155 */         this.fontFace.Release();
/* 156 */         if (PrismFontFactory.debugFonts) {
/* 157 */           System.err.println("null disposer for " + this.fontFace);
/*     */         }
/*     */       } 
/* 160 */       if (PrismFontFactory.debugFonts) {
/* 161 */         System.err.println("fontFace freed: " + this.fontFace);
/*     */       }
/* 163 */       this.fontFace = null;
/*     */     } 
/* 165 */     super.disposeOnShutdown();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWFontFile.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */