package com.sun.javafx.print;

import javafx.print.PageLayout;
import javafx.scene.Node;
import javafx.stage.Window;

public interface PrinterJobImpl {
  PrinterImpl getPrinterImpl();
  
  void setPrinterImpl(PrinterImpl paramPrinterImpl);
  
  boolean showPrintDialog(Window paramWindow);
  
  boolean showPageDialog(Window paramWindow);
  
  PageLayout validatePageLayout(PageLayout paramPageLayout);
  
  boolean print(PageLayout paramPageLayout, Node paramNode);
  
  boolean endJob();
  
  void cancelJob();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\print\PrinterJobImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */