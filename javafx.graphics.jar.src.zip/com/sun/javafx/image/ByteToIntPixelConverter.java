package com.sun.javafx.image;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public interface ByteToIntPixelConverter extends PixelConverter<ByteBuffer, IntBuffer> {
  void convert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\ByteToIntPixelConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */