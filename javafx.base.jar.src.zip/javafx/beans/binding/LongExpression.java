/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableLongValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LongExpression
/*     */   extends NumberExpressionBase
/*     */   implements ObservableLongValue
/*     */ {
/*     */   public int intValue() {
/*  47 */     return (int)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/*  52 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/*  57 */     return (float)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/*  62 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getValue() {
/*  67 */     return Long.valueOf(get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongExpression longExpression(final ObservableLongValue value) {
/*  85 */     if (value == null) {
/*  86 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/*  88 */     return (value instanceof LongExpression) ? (LongExpression)value : 
/*  89 */       new LongBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/*  96 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected long computeValue() {
/* 101 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableLongValue> getDependencies() {
/* 106 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> LongExpression longExpression(final ObservableValue<T> value) {
/* 142 */     if (value == null) {
/* 143 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/* 145 */     return (value instanceof LongExpression) ? (LongExpression)value : 
/* 146 */       new LongBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 153 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected long computeValue() {
/* 158 */           Number number = value.getValue();
/* 159 */           return (number == null) ? 0L : number.longValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableValue<T>> getDependencies() {
/* 164 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LongBinding negate() {
/* 172 */     return (LongBinding)Bindings.negate(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(double paramDouble) {
/* 177 */     return Bindings.add(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding add(float paramFloat) {
/* 182 */     return (FloatBinding)Bindings.add(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding add(long paramLong) {
/* 187 */     return (LongBinding)Bindings.add(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding add(int paramInt) {
/* 192 */     return (LongBinding)Bindings.add(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(double paramDouble) {
/* 197 */     return Bindings.subtract(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding subtract(float paramFloat) {
/* 202 */     return (FloatBinding)Bindings.subtract(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding subtract(long paramLong) {
/* 207 */     return (LongBinding)Bindings.subtract(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding subtract(int paramInt) {
/* 212 */     return (LongBinding)Bindings.subtract(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(double paramDouble) {
/* 217 */     return Bindings.multiply(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding multiply(float paramFloat) {
/* 222 */     return (FloatBinding)Bindings.multiply(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding multiply(long paramLong) {
/* 227 */     return (LongBinding)Bindings.multiply(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding multiply(int paramInt) {
/* 232 */     return (LongBinding)Bindings.multiply(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(double paramDouble) {
/* 237 */     return Bindings.divide(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding divide(float paramFloat) {
/* 242 */     return (FloatBinding)Bindings.divide(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding divide(long paramLong) {
/* 247 */     return (LongBinding)Bindings.divide(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public LongBinding divide(int paramInt) {
/* 252 */     return (LongBinding)Bindings.divide(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectExpression<Long> asObject() {
/* 265 */     return new ObjectBinding<Long>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 272 */           unbind(new Observable[] { this.this$0 });
/*     */         }
/*     */ 
/*     */         
/*     */         protected Long computeValue() {
/* 277 */           return LongExpression.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\LongExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */