/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodePath
/*    */ {
/* 36 */   private List<NGNode> path = new ArrayList<>();
/*    */   private int position;
/*    */   
/*    */   public NGNode last() {
/* 40 */     return this.path.isEmpty() ? null : this.path.get(this.path.size() - 1);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public NGNode getCurrentNode() {
/* 46 */     return this.path.get(this.position);
/*    */   }
/*    */   
/*    */   public boolean hasNext() {
/* 50 */     return (this.position < this.path.size() - 1 && !isEmpty());
/*    */   }
/*    */   
/*    */   public void next() {
/* 54 */     if (!hasNext()) {
/* 55 */       throw new IllegalStateException();
/*    */     }
/* 57 */     this.position++;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 61 */     this.position = this.path.isEmpty() ? -1 : 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void clear() {
/* 67 */     this.position = -1;
/* 68 */     this.path.clear();
/*    */   }
/*    */   
/*    */   public void add(NGNode paramNGNode) {
/* 72 */     this.path.add(0, paramNGNode);
/* 73 */     if (this.position == -1) this.position = 0; 
/*    */   }
/*    */   
/*    */   public int size() {
/* 77 */     return this.path.size();
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 81 */     return this.path.isEmpty();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 85 */     return this.path.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NodePath.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */