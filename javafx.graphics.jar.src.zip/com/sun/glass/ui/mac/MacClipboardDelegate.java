/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.Clipboard;
/*    */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacClipboardDelegate
/*    */   implements ClipboardDelegate
/*    */ {
/*    */   public Clipboard createClipboard(String paramString) {
/* 33 */     if ("SYSTEM".equals(paramString))
/* 34 */       return new MacSystemClipboard(paramString); 
/* 35 */     if ("DND".equals(paramString)) {
/* 36 */       return new MacDnDClipboard(paramString);
/*    */     }
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacClipboardDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */