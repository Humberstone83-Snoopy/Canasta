/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.track.Track;
/*     */ import com.sun.media.jfxmediaimpl.platform.Platform;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.NavigableMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NativeMedia
/*     */   extends Media
/*     */ {
/*  42 */   protected final Lock markerLock = new ReentrantLock();
/*  43 */   protected final Lock listenerLock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   protected Map<String, Double> markersByName;
/*     */ 
/*     */   
/*     */   protected NavigableMap<Double, String> markersByTime;
/*     */ 
/*     */   
/*     */   protected WeakHashMap<MarkerStateListener, Boolean> markerListeners;
/*     */ 
/*     */   
/*     */   protected NativeMedia(Locator paramLocator) {
/*  56 */     super(paramLocator);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Platform getPlatform();
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTrack(Track paramTrack) {
/*  66 */     super.addTrack(paramTrack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMarker(String paramString, double paramDouble) {
/*  72 */     if (paramString == null)
/*  73 */       throw new IllegalArgumentException("markerName == null!"); 
/*  74 */     if (paramDouble < 0.0D) {
/*  75 */       throw new IllegalArgumentException("presentationTime < 0");
/*     */     }
/*     */     
/*  78 */     this.markerLock.lock();
/*     */     try {
/*  80 */       if (this.markersByName == null) {
/*  81 */         this.markersByName = new HashMap<>();
/*  82 */         this.markersByTime = new TreeMap<>();
/*     */       } 
/*  84 */       this.markersByName.put(paramString, Double.valueOf(paramDouble));
/*  85 */       this.markersByTime.put(Double.valueOf(paramDouble), paramString);
/*     */     } finally {
/*  87 */       this.markerLock.unlock();
/*     */     } 
/*     */     
/*  90 */     fireMarkerStateEvent(true);
/*     */   }
/*     */   
/*     */   public Map<String, Double> getMarkers() {
/*  94 */     Map<String, Double> map = null;
/*  95 */     this.markerLock.lock();
/*     */     try {
/*  97 */       if (this.markersByName != null && !this.markersByName.isEmpty()) {
/*  98 */         map = Collections.unmodifiableMap(this.markersByName);
/*     */       }
/*     */     } finally {
/* 101 */       this.markerLock.unlock();
/*     */     } 
/* 103 */     return map;
/*     */   }
/*     */   
/*     */   public double removeMarker(String paramString) {
/* 107 */     if (paramString == null) {
/* 108 */       throw new IllegalArgumentException("markerName == null!");
/*     */     }
/*     */     
/* 111 */     double d = -1.0D;
/* 112 */     boolean bool = false;
/*     */     
/* 114 */     this.markerLock.lock();
/*     */     try {
/* 116 */       if (this.markersByName.containsKey(paramString)) {
/* 117 */         d = ((Double)this.markersByName.get(paramString)).doubleValue();
/* 118 */         this.markersByName.remove(paramString);
/* 119 */         this.markersByTime.remove(Double.valueOf(d));
/* 120 */         bool = (this.markersByName.size() > 0) ? true : false;
/*     */       } 
/*     */     } finally {
/* 123 */       this.markerLock.unlock();
/*     */     } 
/*     */     
/* 126 */     fireMarkerStateEvent(bool);
/*     */     
/* 128 */     return d;
/*     */   }
/*     */   
/*     */   public void removeAllMarkers() {
/* 132 */     this.markerLock.lock();
/*     */     try {
/* 134 */       this.markersByName.clear();
/* 135 */       this.markersByTime.clear();
/*     */     } finally {
/* 137 */       this.markerLock.unlock();
/*     */     } 
/*     */     
/* 140 */     fireMarkerStateEvent(false);
/*     */   }
/*     */   
/*     */   public abstract void dispose();
/*     */   
/*     */   Map.Entry<Double, String> getNextMarker(double paramDouble, boolean paramBoolean) {
/* 146 */     Map.Entry<Double, String> entry = null;
/* 147 */     this.markerLock.lock();
/*     */     try {
/* 149 */       if (this.markersByTime != null) {
/* 150 */         if (paramBoolean) {
/* 151 */           entry = this.markersByTime.ceilingEntry(Double.valueOf(paramDouble));
/*     */         } else {
/* 153 */           entry = this.markersByTime.higherEntry(Double.valueOf(paramDouble));
/*     */         } 
/*     */       }
/*     */     } finally {
/* 157 */       this.markerLock.unlock();
/*     */     } 
/* 159 */     return entry;
/*     */   }
/*     */   
/*     */   void addMarkerStateListener(MarkerStateListener paramMarkerStateListener) {
/* 163 */     if (paramMarkerStateListener != null) {
/* 164 */       this.listenerLock.lock();
/*     */       try {
/* 166 */         if (this.markerListeners == null) {
/* 167 */           this.markerListeners = new WeakHashMap<>();
/*     */         }
/* 169 */         this.markerListeners.put(paramMarkerStateListener, Boolean.TRUE);
/*     */       } finally {
/* 171 */         this.listenerLock.unlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void removeMarkerStateListener(MarkerStateListener paramMarkerStateListener) {
/* 178 */     if (paramMarkerStateListener != null) {
/* 179 */       this.listenerLock.lock();
/*     */       try {
/* 181 */         if (this.markerListeners != null) {
/* 182 */           this.markerListeners.remove(paramMarkerStateListener);
/*     */         }
/*     */       } finally {
/* 185 */         this.listenerLock.unlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void fireMarkerStateEvent(boolean paramBoolean) {
/* 191 */     this.listenerLock.lock();
/*     */     try {
/* 193 */       if (this.markerListeners != null && !this.markerListeners.isEmpty()) {
/* 194 */         for (MarkerStateListener markerStateListener : this.markerListeners.keySet()) {
/* 195 */           if (markerStateListener != null) {
/* 196 */             markerStateListener.markerStateChanged(paramBoolean);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } finally {
/* 201 */       this.listenerLock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeMedia.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */