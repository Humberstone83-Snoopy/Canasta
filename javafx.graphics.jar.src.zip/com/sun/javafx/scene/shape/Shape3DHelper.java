/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Shape3D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Shape3DHelper
/*    */   extends NodeHelper
/*    */ {
/*    */   private static Shape3DAccessor shape3DAccessor;
/*    */   
/*    */   static {
/* 43 */     Utils.forceInit(Shape3D.class);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 48 */     super.updatePeerImpl(paramNode);
/* 49 */     shape3DAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 55 */     return shape3DAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/* 60 */     return shape3DAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*    */   }
/*    */   
/*    */   public static void setShape3DAccessor(Shape3DAccessor paramShape3DAccessor) {
/* 64 */     if (shape3DAccessor != null) {
/* 65 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 68 */     shape3DAccessor = paramShape3DAccessor;
/*    */   }
/*    */   
/*    */   public static interface Shape3DAccessor {
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\Shape3DHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */