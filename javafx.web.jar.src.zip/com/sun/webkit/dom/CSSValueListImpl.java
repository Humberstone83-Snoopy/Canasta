/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.css.CSSValue;
/*    */ import org.w3c.dom.css.CSSValueList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSValueListImpl
/*    */   extends CSSValueImpl
/*    */   implements CSSValueList
/*    */ {
/*    */   CSSValueListImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSValueList getImpl(long paramLong) {
/* 37 */     return (CSSValueList)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 43 */     return getLengthImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   static native int getLengthImpl(long paramLong);
/*    */ 
/*    */   
/*    */   public CSSValue item(int paramInt) {
/* 51 */     return CSSValueImpl.getImpl(itemImpl(getPeer(), paramInt));
/*    */   }
/*    */   
/*    */   static native long itemImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSValueListImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */