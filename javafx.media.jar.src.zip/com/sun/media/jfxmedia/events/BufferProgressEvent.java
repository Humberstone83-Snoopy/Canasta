/*    */ package com.sun.media.jfxmedia.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BufferProgressEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   private double duration;
/*    */   private long start;
/*    */   private long stop;
/*    */   private long position;
/*    */   
/*    */   public BufferProgressEvent(double paramDouble, long paramLong1, long paramLong2, long paramLong3) {
/* 47 */     this.duration = paramDouble;
/* 48 */     this.start = paramLong1;
/* 49 */     this.stop = paramLong2;
/* 50 */     this.position = paramLong3;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getDuration() {
/* 55 */     return this.duration;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getBufferStart() {
/* 64 */     return this.start;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getBufferStop() {
/* 74 */     return this.stop;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long getBufferPosition() {
/* 84 */     return this.position;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\BufferProgressEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */