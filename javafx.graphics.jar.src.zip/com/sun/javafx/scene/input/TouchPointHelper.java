/*    */ package com.sun.javafx.scene.input;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.input.TouchPoint;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TouchPointHelper
/*    */ {
/*    */   private static TouchPointAccessor touchPointAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(TouchPoint.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void reset(TouchPoint paramTouchPoint) {
/* 46 */     touchPointAccessor.reset(paramTouchPoint);
/*    */   }
/*    */   
/*    */   public static void setTouchPointAccessor(TouchPointAccessor paramTouchPointAccessor) {
/* 50 */     if (touchPointAccessor != null) {
/* 51 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 54 */     touchPointAccessor = paramTouchPointAccessor;
/*    */   }
/*    */   
/*    */   public static interface TouchPointAccessor {
/*    */     void reset(TouchPoint param1TouchPoint);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\TouchPointHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */