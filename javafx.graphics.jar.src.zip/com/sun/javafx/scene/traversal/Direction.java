/*    */ package com.sun.javafx.scene.traversal;
/*    */ 
/*    */ import javafx.geometry.NodeOrientation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Direction
/*    */ {
/* 35 */   UP(false),
/* 36 */   DOWN(true),
/* 37 */   LEFT(false),
/* 38 */   RIGHT(true),
/* 39 */   NEXT(true),
/* 40 */   NEXT_IN_LINE(true),
/* 41 */   PREVIOUS(false);
/*    */   private final boolean forward;
/*    */   
/*    */   Direction(boolean paramBoolean) {
/* 45 */     this.forward = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isForward() {
/* 49 */     return this.forward;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Direction getDirectionForNodeOrientation(NodeOrientation paramNodeOrientation) {
/* 59 */     if (paramNodeOrientation == NodeOrientation.RIGHT_TO_LEFT) {
/* 60 */       switch (this) {
/*    */         case LEFT:
/* 62 */           return RIGHT;
/*    */         case RIGHT:
/* 64 */           return LEFT;
/*    */       } 
/*    */     }
/* 67 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\Direction.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */