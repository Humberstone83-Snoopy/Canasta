/*     */ package com.sun.javafx.iio;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageMetadata
/*     */ {
/*     */   public final Float gamma;
/*     */   public final Boolean blackIsZero;
/*     */   public final Integer backgroundIndex;
/*     */   public final Integer backgroundColor;
/*     */   public final Integer delayTime;
/*     */   public final Integer loopCount;
/*     */   public final Integer transparentIndex;
/*     */   public final Integer imageWidth;
/*     */   public final Integer imageHeight;
/*     */   public final Integer imageLeftPosition;
/*     */   public final Integer imageTopPosition;
/*     */   public final Integer disposalMethod;
/*     */   
/*     */   public ImageMetadata(Float paramFloat, Boolean paramBoolean, Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4, Integer paramInteger5, Integer paramInteger6, Integer paramInteger7, Integer paramInteger8, Integer paramInteger9, Integer paramInteger10) {
/* 118 */     this.gamma = paramFloat;
/* 119 */     this.blackIsZero = paramBoolean;
/* 120 */     this.backgroundIndex = paramInteger1;
/* 121 */     this.backgroundColor = paramInteger2;
/* 122 */     this.transparentIndex = paramInteger3;
/* 123 */     this.delayTime = paramInteger4;
/* 124 */     this.loopCount = paramInteger5;
/* 125 */     this.imageWidth = paramInteger6;
/* 126 */     this.imageHeight = paramInteger7;
/* 127 */     this.imageLeftPosition = paramInteger8;
/* 128 */     this.imageTopPosition = paramInteger9;
/* 129 */     this.disposalMethod = paramInteger10;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     StringBuffer stringBuffer = new StringBuffer("[" + getClass().getName());
/* 135 */     if (this.gamma != null) {
/* 136 */       stringBuffer.append(" gamma: " + this.gamma);
/*     */     }
/* 138 */     if (this.blackIsZero != null) {
/* 139 */       stringBuffer.append(" blackIsZero: " + this.blackIsZero);
/*     */     }
/* 141 */     if (this.backgroundIndex != null) {
/* 142 */       stringBuffer.append(" backgroundIndex: " + this.backgroundIndex);
/*     */     }
/* 144 */     if (this.backgroundColor != null) {
/* 145 */       stringBuffer.append(" backgroundColor: " + this.backgroundColor);
/*     */     }
/* 147 */     if (this.delayTime != null) {
/* 148 */       stringBuffer.append(" delayTime: " + this.delayTime);
/*     */     }
/* 150 */     if (this.loopCount != null) {
/* 151 */       stringBuffer.append(" loopCount: " + this.loopCount);
/*     */     }
/* 153 */     if (this.transparentIndex != null) {
/* 154 */       stringBuffer.append(" transparentIndex: " + this.transparentIndex);
/*     */     }
/* 156 */     if (this.imageWidth != null) {
/* 157 */       stringBuffer.append(" imageWidth: " + this.imageWidth);
/*     */     }
/* 159 */     if (this.imageHeight != null) {
/* 160 */       stringBuffer.append(" imageHeight: " + this.imageHeight);
/*     */     }
/* 162 */     if (this.imageLeftPosition != null) {
/* 163 */       stringBuffer.append(" imageLeftPosition: " + this.imageLeftPosition);
/*     */     }
/* 165 */     if (this.imageTopPosition != null) {
/* 166 */       stringBuffer.append(" imageTopPosition: " + this.imageTopPosition);
/*     */     }
/* 168 */     if (this.disposalMethod != null) {
/* 169 */       stringBuffer.append(" disposalMethod: " + this.disposalMethod);
/*     */     }
/* 171 */     stringBuffer.append("]");
/* 172 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageMetadata.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */