/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.ParallelCamera;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParallelCameraHelper
/*    */   extends CameraHelper
/*    */ {
/* 42 */   private static final ParallelCameraHelper theInstance = new ParallelCameraHelper(); static {
/* 43 */     Utils.forceInit(ParallelCamera.class);
/*    */   }
/*    */   private static ParallelCameraAccessor parallelCameraAccessor;
/*    */   private static ParallelCameraHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(ParallelCamera paramParallelCamera) {
/* 51 */     setHelper(paramParallelCamera, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 56 */     return parallelCameraAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */   
/*    */   public static void setParallelCameraAccessor(ParallelCameraAccessor paramParallelCameraAccessor) {
/* 60 */     if (parallelCameraAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     parallelCameraAccessor = paramParallelCameraAccessor;
/*    */   }
/*    */   
/*    */   public static interface ParallelCameraAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\ParallelCameraHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */