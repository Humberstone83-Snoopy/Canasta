/*      */ package com.sun.javafx.geom.transform;
/*      */ 
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.Path2D;
/*      */ import com.sun.javafx.geom.Point2D;
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.Shape;
/*      */ import com.sun.javafx.geom.Vec3d;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AffineBase
/*      */   extends BaseTransform
/*      */ {
/*      */   protected static final int APPLY_IDENTITY = 0;
/*      */   protected static final int APPLY_TRANSLATE = 1;
/*      */   protected static final int APPLY_SCALE = 2;
/*      */   protected static final int APPLY_SHEAR = 4;
/*      */   protected static final int APPLY_3D = 8;
/*      */   protected static final int APPLY_2D_MASK = 7;
/*      */   protected static final int APPLY_2D_DELTA_MASK = 6;
/*      */   protected static final int HI_SHIFT = 4;
/*      */   protected static final int HI_IDENTITY = 0;
/*      */   protected static final int HI_TRANSLATE = 16;
/*      */   protected static final int HI_SCALE = 32;
/*      */   protected static final int HI_SHEAR = 64;
/*      */   protected static final int HI_3D = 128;
/*      */   protected double mxx;
/*      */   protected double myx;
/*      */   protected double mxy;
/*      */   protected double myy;
/*      */   protected double mxt;
/*      */   protected double myt;
/*      */   protected transient int state;
/*      */   protected transient int type;
/*      */   
/*      */   protected static void stateError() {
/*  204 */     throw new InternalError("missing case in transform state switch");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateState() {
/*  230 */     updateState2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateState2D() {
/*  238 */     if (this.mxy == 0.0D && this.myx == 0.0D) {
/*  239 */       if (this.mxx == 1.0D && this.myy == 1.0D) {
/*  240 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  241 */           this.state = 0;
/*  242 */           this.type = 0;
/*      */         } else {
/*  244 */           this.state = 1;
/*  245 */           this.type = 1;
/*      */         } 
/*      */       } else {
/*  248 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  249 */           this.state = 2;
/*      */         } else {
/*  251 */           this.state = 3;
/*      */         } 
/*  253 */         this.type = -1;
/*      */       } 
/*      */     } else {
/*  256 */       if (this.mxx == 0.0D && this.myy == 0.0D) {
/*  257 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  258 */           this.state = 4;
/*      */         } else {
/*  260 */           this.state = 5;
/*      */         }
/*      */       
/*  263 */       } else if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  264 */         this.state = 6;
/*      */       } else {
/*  266 */         this.state = 7;
/*      */       } 
/*      */       
/*  269 */       this.type = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getType() {
/*  274 */     if (this.type == -1) {
/*  275 */       updateState();
/*  276 */       if (this.type == -1) {
/*  277 */         this.type = calculateType();
/*      */       }
/*      */     } 
/*  280 */     return this.type;
/*      */   }
/*      */   protected int calculateType() {
/*      */     boolean bool1, bool2;
/*  284 */     int i = ((this.state & 0x8) == 0) ? 0 : 128;
/*      */     
/*  286 */     switch (this.state & 0x7) {
/*      */       default:
/*  288 */         stateError();
/*      */       
/*      */       case 7:
/*  291 */         i |= 0x1;
/*      */       
/*      */       case 6:
/*  294 */         if (this.mxx * this.mxy + this.myx * this.myy != 0.0D) {
/*      */           
/*  296 */           i |= 0x20;
/*      */           break;
/*      */         } 
/*  299 */         bool1 = (this.mxx >= 0.0D) ? true : false;
/*  300 */         bool2 = (this.myy >= 0.0D) ? true : false;
/*  301 */         if (bool1 == bool2) {
/*      */ 
/*      */           
/*  304 */           if (this.mxx != this.myy || this.mxy != -this.myx) {
/*  305 */             i |= 0x14; break;
/*  306 */           }  if (this.mxx * this.myy - this.mxy * this.myx != 1.0D) {
/*  307 */             i |= 0x12; break;
/*      */           } 
/*  309 */           i |= 0x10;
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  314 */         if (this.mxx != -this.myy || this.mxy != this.myx) {
/*  315 */           i |= 0x54;
/*      */           break;
/*      */         } 
/*  318 */         if (this.mxx * this.myy - this.mxy * this.myx != 1.0D) {
/*  319 */           i |= 0x52;
/*      */           
/*      */           break;
/*      */         } 
/*  323 */         i |= 0x50;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 5:
/*  328 */         i |= 0x1;
/*      */       
/*      */       case 4:
/*  331 */         bool1 = (this.mxy >= 0.0D) ? true : false;
/*  332 */         bool2 = (this.myx >= 0.0D) ? true : false;
/*  333 */         if (bool1 != bool2) {
/*      */           
/*  335 */           if (this.mxy != -this.myx) {
/*  336 */             i |= 0xC; break;
/*  337 */           }  if (this.mxy != 1.0D && this.mxy != -1.0D) {
/*  338 */             i |= 0xA; break;
/*      */           } 
/*  340 */           i |= 0x8;
/*      */           
/*      */           break;
/*      */         } 
/*  344 */         if (this.mxy == this.myx) {
/*  345 */           i |= 0x4A;
/*      */           
/*      */           break;
/*      */         } 
/*  349 */         i |= 0x4C;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*  356 */         i |= 0x1;
/*      */       
/*      */       case 2:
/*  359 */         bool1 = (this.mxx >= 0.0D) ? true : false;
/*  360 */         bool2 = (this.myy >= 0.0D) ? true : false;
/*  361 */         if (bool1 == bool2) {
/*  362 */           if (bool1) {
/*      */ 
/*      */             
/*  365 */             if (this.mxx == this.myy) {
/*  366 */               i |= 0x2; break;
/*      */             } 
/*  368 */             i |= 0x4;
/*      */             
/*      */             break;
/*      */           } 
/*  372 */           if (this.mxx != this.myy) {
/*  373 */             i |= 0xC; break;
/*  374 */           }  if (this.mxx != -1.0D) {
/*  375 */             i |= 0xA; break;
/*      */           } 
/*  377 */           i |= 0x8;
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  382 */         if (this.mxx == -this.myy) {
/*  383 */           if (this.mxx == 1.0D || this.mxx == -1.0D) {
/*  384 */             i |= 0x40; break;
/*      */           } 
/*  386 */           i |= 0x42;
/*      */           break;
/*      */         } 
/*  389 */         i |= 0x44;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*  394 */         i |= 0x1;
/*      */         break;
/*      */       case 0:
/*      */         break;
/*      */     } 
/*  399 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMxx() {
/*  411 */     return this.mxx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMyy() {
/*  423 */     return this.myy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMxy() {
/*  435 */     return this.mxy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMyx() {
/*  447 */     return this.myx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMxt() {
/*  459 */     return this.mxt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getMyt() {
/*  471 */     return this.myt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIdentity() {
/*  481 */     return (this.state == 0 || getType() == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTranslateOrIdentity() {
/*  486 */     return (this.state <= 1 || getType() <= 1);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean is2D() {
/*  491 */     return (this.state < 8 || getType() <= 127);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDeterminant() {
/*  536 */     switch (this.state)
/*      */     { default:
/*  538 */         stateError();
/*      */       
/*      */       case 6:
/*      */       case 7:
/*  542 */         return this.mxx * this.myy - this.mxy * this.myx;
/*      */       case 4:
/*      */       case 5:
/*  545 */         return -(this.mxy * this.myx);
/*      */       case 2:
/*      */       case 3:
/*  548 */         return this.mxx * this.myy;
/*      */       case 0:
/*      */       case 1:
/*  551 */         break; }  return 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void reset3Delements();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToIdentity() {
/*  567 */     this.mxx = this.myy = 1.0D;
/*  568 */     this.myx = this.mxy = this.mxt = this.myt = 0.0D;
/*  569 */     reset3Delements();
/*  570 */     this.state = 0;
/*  571 */     this.type = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  588 */     this.mxx = paramDouble1;
/*  589 */     this.myx = paramDouble2;
/*  590 */     this.mxy = paramDouble3;
/*  591 */     this.myy = paramDouble4;
/*  592 */     this.mxt = paramDouble5;
/*  593 */     this.myt = paramDouble6;
/*  594 */     reset3Delements();
/*  595 */     updateState2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToShear(double paramDouble1, double paramDouble2) {
/*  612 */     this.mxx = 1.0D;
/*  613 */     this.mxy = paramDouble1;
/*  614 */     this.myx = paramDouble2;
/*  615 */     this.myy = 1.0D;
/*  616 */     this.mxt = 0.0D;
/*  617 */     this.myt = 0.0D;
/*  618 */     reset3Delements();
/*  619 */     if (paramDouble1 != 0.0D || paramDouble2 != 0.0D) {
/*  620 */       this.state = 6;
/*  621 */       this.type = -1;
/*      */     } else {
/*  623 */       this.state = 0;
/*  624 */       this.type = 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Point2D transform(Point2D paramPoint2D) {
/*  629 */     return transform(paramPoint2D, paramPoint2D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D transform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/*  650 */     if (paramPoint2D2 == null) {
/*  651 */       paramPoint2D2 = new Point2D();
/*      */     }
/*      */     
/*  654 */     double d1 = paramPoint2D1.x;
/*  655 */     double d2 = paramPoint2D1.y;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     switch (this.state & 0x7)
/*      */     { default:
/*  663 */         stateError();
/*      */       
/*      */       case 7:
/*  666 */         paramPoint2D2.setLocation((float)(d1 * this.mxx + d2 * this.mxy + this.mxt), (float)(d1 * this.myx + d2 * this.myy + this.myt));
/*      */         
/*  668 */         return paramPoint2D2;
/*      */       case 6:
/*  670 */         paramPoint2D2.setLocation((float)(d1 * this.mxx + d2 * this.mxy), (float)(d1 * this.myx + d2 * this.myy));
/*      */         
/*  672 */         return paramPoint2D2;
/*      */       case 5:
/*  674 */         paramPoint2D2.setLocation((float)(d2 * this.mxy + this.mxt), (float)(d1 * this.myx + this.myt));
/*      */         
/*  676 */         return paramPoint2D2;
/*      */       case 4:
/*  678 */         paramPoint2D2.setLocation((float)(d2 * this.mxy), (float)(d1 * this.myx));
/*  679 */         return paramPoint2D2;
/*      */       case 3:
/*  681 */         paramPoint2D2.setLocation((float)(d1 * this.mxx + this.mxt), (float)(d2 * this.myy + this.myt));
/*  682 */         return paramPoint2D2;
/*      */       case 2:
/*  684 */         paramPoint2D2.setLocation((float)(d1 * this.mxx), (float)(d2 * this.myy));
/*  685 */         return paramPoint2D2;
/*      */       case 1:
/*  687 */         paramPoint2D2.setLocation((float)(d1 + this.mxt), (float)(d2 + this.myt));
/*  688 */         return paramPoint2D2;
/*      */       case 0:
/*  690 */         break; }  paramPoint2D2.setLocation((float)d1, (float)d2);
/*  691 */     return paramPoint2D2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  698 */     if (paramVec3d2 == null) {
/*  699 */       paramVec3d2 = new Vec3d();
/*      */     }
/*      */     
/*  702 */     double d1 = paramVec3d1.x;
/*  703 */     double d2 = paramVec3d1.y;
/*  704 */     double d3 = paramVec3d1.z;
/*      */     
/*  706 */     switch (this.state)
/*      */     { default:
/*  708 */         stateError();
/*      */       
/*      */       case 7:
/*  711 */         paramVec3d2.x = d1 * this.mxx + d2 * this.mxy + this.mxt;
/*  712 */         paramVec3d2.y = d1 * this.myx + d2 * this.myy + this.myt;
/*  713 */         paramVec3d2.z = d3;
/*  714 */         return paramVec3d2;
/*      */       case 6:
/*  716 */         paramVec3d2.x = d1 * this.mxx + d2 * this.mxy;
/*  717 */         paramVec3d2.y = d1 * this.myx + d2 * this.myy;
/*  718 */         paramVec3d2.z = d3;
/*  719 */         return paramVec3d2;
/*      */       case 5:
/*  721 */         paramVec3d2.x = d2 * this.mxy + this.mxt;
/*  722 */         paramVec3d2.y = d1 * this.myx + this.myt;
/*  723 */         paramVec3d2.z = d3;
/*  724 */         return paramVec3d2;
/*      */       case 4:
/*  726 */         paramVec3d2.x = d2 * this.mxy;
/*  727 */         paramVec3d2.y = d1 * this.myx;
/*  728 */         paramVec3d2.z = d3;
/*  729 */         return paramVec3d2;
/*      */       case 3:
/*  731 */         paramVec3d2.x = d1 * this.mxx + this.mxt;
/*  732 */         paramVec3d2.y = d2 * this.myy + this.myt;
/*  733 */         paramVec3d2.z = d3;
/*  734 */         return paramVec3d2;
/*      */       case 2:
/*  736 */         paramVec3d2.x = d1 * this.mxx;
/*  737 */         paramVec3d2.y = d2 * this.myy;
/*  738 */         paramVec3d2.z = d3;
/*  739 */         return paramVec3d2;
/*      */       case 1:
/*  741 */         paramVec3d2.x = d1 + this.mxt;
/*  742 */         paramVec3d2.y = d2 + this.myt;
/*  743 */         paramVec3d2.z = d3;
/*  744 */         return paramVec3d2;
/*      */       case 0:
/*  746 */         break; }  paramVec3d2.x = d1;
/*  747 */     paramVec3d2.y = d2;
/*  748 */     paramVec3d2.z = d3;
/*  749 */     return paramVec3d2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d deltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) {
/*  774 */     if (paramVec3d2 == null) {
/*  775 */       paramVec3d2 = new Vec3d();
/*      */     }
/*      */     
/*  778 */     double d1 = paramVec3d1.x;
/*  779 */     double d2 = paramVec3d1.y;
/*  780 */     double d3 = paramVec3d1.z;
/*      */     
/*  782 */     switch (this.state)
/*      */     { default:
/*  784 */         stateError();
/*      */       
/*      */       case 6:
/*      */       case 7:
/*  788 */         paramVec3d2.x = d1 * this.mxx + d2 * this.mxy;
/*  789 */         paramVec3d2.y = d1 * this.myx + d2 * this.myy;
/*  790 */         paramVec3d2.z = d3;
/*  791 */         return paramVec3d2;
/*      */       case 4:
/*      */       case 5:
/*  794 */         paramVec3d2.x = d2 * this.mxy;
/*  795 */         paramVec3d2.y = d1 * this.myx;
/*  796 */         paramVec3d2.z = d3;
/*  797 */         return paramVec3d2;
/*      */       case 2:
/*      */       case 3:
/*  800 */         paramVec3d2.x = d1 * this.mxx;
/*  801 */         paramVec3d2.y = d2 * this.myy;
/*  802 */         paramVec3d2.z = d3;
/*  803 */         return paramVec3d2;
/*      */       case 0:
/*      */       case 1:
/*  806 */         break; }  paramVec3d2.x = d1;
/*  807 */     paramVec3d2.y = d2;
/*  808 */     paramVec3d2.z = d3;
/*  809 */     return paramVec3d2;
/*      */   }
/*      */   
/*      */   private BaseBounds transform2DBounds(RectBounds paramRectBounds1, RectBounds paramRectBounds2) { double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*  816 */     switch (this.state & 0x7)
/*      */     { default:
/*  818 */         stateError();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*  823 */         d1 = paramRectBounds1.getMinX();
/*  824 */         d2 = paramRectBounds1.getMinY();
/*  825 */         d3 = paramRectBounds1.getMaxX();
/*  826 */         d4 = paramRectBounds1.getMaxY();
/*  827 */         paramRectBounds2.setBoundsAndSort((float)(d1 * this.mxx + d2 * this.mxy), (float)(d1 * this.myx + d2 * this.myy), (float)(d3 * this.mxx + d4 * this.mxy), (float)(d3 * this.myx + d4 * this.myy));
/*      */ 
/*      */ 
/*      */         
/*  831 */         paramRectBounds2.add((float)(d1 * this.mxx + d4 * this.mxy), (float)(d1 * this.myx + d4 * this.myy));
/*      */         
/*  833 */         paramRectBounds2.add((float)(d3 * this.mxx + d2 * this.mxy), (float)(d3 * this.myx + d2 * this.myy));
/*      */         
/*  835 */         paramRectBounds2.setBounds((float)(paramRectBounds2.getMinX() + this.mxt), 
/*  836 */             (float)(paramRectBounds2.getMinY() + this.myt), 
/*  837 */             (float)(paramRectBounds2.getMaxX() + this.mxt), 
/*  838 */             (float)(paramRectBounds2.getMaxY() + this.myt));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  876 */         return paramRectBounds2;case 5: paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinY() * this.mxy + this.mxt), (float)(paramRectBounds1.getMinX() * this.myx + this.myt), (float)(paramRectBounds1.getMaxY() * this.mxy + this.mxt), (float)(paramRectBounds1.getMaxX() * this.myx + this.myt)); return paramRectBounds2;case 4: paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinY() * this.mxy), (float)(paramRectBounds1.getMinX() * this.myx), (float)(paramRectBounds1.getMaxY() * this.mxy), (float)(paramRectBounds1.getMaxX() * this.myx)); return paramRectBounds2;case 3: paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinX() * this.mxx + this.mxt), (float)(paramRectBounds1.getMinY() * this.myy + this.myt), (float)(paramRectBounds1.getMaxX() * this.mxx + this.mxt), (float)(paramRectBounds1.getMaxY() * this.myy + this.myt)); return paramRectBounds2;case 2: paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinX() * this.mxx), (float)(paramRectBounds1.getMinY() * this.myy), (float)(paramRectBounds1.getMaxX() * this.mxx), (float)(paramRectBounds1.getMaxY() * this.myy)); return paramRectBounds2;case 1: paramRectBounds2.setBounds((float)(paramRectBounds1.getMinX() + this.mxt), (float)(paramRectBounds1.getMinY() + this.myt), (float)(paramRectBounds1.getMaxX() + this.mxt), (float)(paramRectBounds1.getMaxY() + this.myt)); return paramRectBounds2;case 0: break; }  if (paramRectBounds1 != paramRectBounds2) paramRectBounds2.setBounds(paramRectBounds1);  return paramRectBounds2; } private BaseBounds transform3DBounds(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) { double d1; double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/*  881 */     switch (this.state & 0x7)
/*      */     { default:
/*  883 */         stateError();
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*  889 */         d1 = paramBaseBounds1.getMinX();
/*  890 */         d2 = paramBaseBounds1.getMinY();
/*  891 */         d3 = paramBaseBounds1.getMinZ();
/*  892 */         d4 = paramBaseBounds1.getMaxX();
/*  893 */         d5 = paramBaseBounds1.getMaxY();
/*  894 */         d6 = paramBaseBounds1.getMaxZ();
/*  895 */         paramBaseBounds2.setBoundsAndSort((float)(d1 * this.mxx + d2 * this.mxy), (float)(d1 * this.myx + d2 * this.myy), (float)d3, (float)(d4 * this.mxx + d5 * this.mxy), (float)(d4 * this.myx + d5 * this.myy), (float)d6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  901 */         paramBaseBounds2.add((float)(d1 * this.mxx + d5 * this.mxy), (float)(d1 * this.myx + d5 * this.myy), 0.0F);
/*      */         
/*  903 */         paramBaseBounds2.add((float)(d4 * this.mxx + d2 * this.mxy), (float)(d4 * this.myx + d2 * this.myy), 0.0F);
/*      */         
/*  905 */         paramBaseBounds2.deriveWithNewBounds((float)(paramBaseBounds2.getMinX() + this.mxt), 
/*  906 */             (float)(paramBaseBounds2.getMinY() + this.myt), paramBaseBounds2
/*  907 */             .getMinZ(), 
/*  908 */             (float)(paramBaseBounds2.getMaxX() + this.mxt), 
/*  909 */             (float)(paramBaseBounds2.getMaxY() + this.myt), paramBaseBounds2
/*  910 */             .getMaxZ());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  958 */         return paramBaseBounds2;case 5: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinY() * this.mxy + this.mxt), (float)(paramBaseBounds1.getMinX() * this.myx + this.myt), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxY() * this.mxy + this.mxt), (float)(paramBaseBounds1.getMaxX() * this.myx + this.myt), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 4: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinY() * this.mxy), (float)(paramBaseBounds1.getMinX() * this.myx), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxY() * this.mxy), (float)(paramBaseBounds1.getMaxX() * this.myx), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 3: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinX() * this.mxx + this.mxt), (float)(paramBaseBounds1.getMinY() * this.myy + this.myt), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxX() * this.mxx + this.mxt), (float)(paramBaseBounds1.getMaxY() * this.myy + this.myt), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 2: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinX() * this.mxx), (float)(paramBaseBounds1.getMinY() * this.myy), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxX() * this.mxx), (float)(paramBaseBounds1.getMaxY() * this.myy), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 1: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds((float)(paramBaseBounds1.getMinX() + this.mxt), (float)(paramBaseBounds1.getMinY() + this.myt), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxX() + this.mxt), (float)(paramBaseBounds1.getMaxY() + this.myt), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 0: break; }  if (paramBaseBounds1 != paramBaseBounds2) paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds(paramBaseBounds1);  return paramBaseBounds2; }
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) {
/*  963 */     if (paramBaseBounds1.getBoundsType() != BaseBounds.BoundsType.RECTANGLE || paramBaseBounds2
/*  964 */       .getBoundsType() != BaseBounds.BoundsType.RECTANGLE) {
/*  965 */       return transform3DBounds(paramBaseBounds1, paramBaseBounds2);
/*      */     }
/*  967 */     return transform2DBounds((RectBounds)paramBaseBounds1, (RectBounds)paramBaseBounds2);
/*      */   }
/*      */   
/*      */   public void transform(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/*      */     RectBounds rectBounds;
/*  972 */     switch (this.state & 0x7) {
/*      */       default:
/*  974 */         stateError();
/*      */       
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*  982 */         rectBounds = new RectBounds(paramRectangle1);
/*      */         
/*  984 */         rectBounds = (RectBounds)transform(rectBounds, rectBounds);
/*  985 */         paramRectangle2.setBounds(rectBounds);
/*      */         return;
/*      */       case 1:
/*  988 */         Translate2D.transform(paramRectangle1, paramRectangle2, this.mxt, this.myt); return;
/*      */       case 0:
/*      */         break;
/*  991 */     }  if (paramRectangle2 != paramRectangle1) {
/*  992 */       paramRectangle2.setBounds(paramRectangle1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 1022 */     doTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3, this.state & 0x7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) {
/* 1060 */     doTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3, this.state & 0x6);
/*      */   }
/*      */   private void doTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3, int paramInt4) {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/* 1069 */     if (paramArrayOffloat2 == paramArrayOffloat1 && paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1080 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*      */       
/* 1082 */       paramInt1 = paramInt2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1088 */     switch (paramInt4) {
/*      */       default:
/* 1090 */         stateError();
/*      */       
/*      */       case 7:
/* 1093 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 1094 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 1095 */         while (--paramInt3 >= 0) {
/* 1096 */           double d7 = paramArrayOffloat1[paramInt1++];
/* 1097 */           double d8 = paramArrayOffloat1[paramInt1++];
/* 1098 */           paramArrayOffloat2[paramInt2++] = (float)(d1 * d7 + d2 * d8 + d3);
/* 1099 */           paramArrayOffloat2[paramInt2++] = (float)(d4 * d7 + d5 * d8 + d6);
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 1103 */         d1 = this.mxx; d2 = this.mxy;
/* 1104 */         d4 = this.myx; d5 = this.myy;
/* 1105 */         while (--paramInt3 >= 0) {
/* 1106 */           double d7 = paramArrayOffloat1[paramInt1++];
/* 1107 */           double d8 = paramArrayOffloat1[paramInt1++];
/* 1108 */           paramArrayOffloat2[paramInt2++] = (float)(d1 * d7 + d2 * d8);
/* 1109 */           paramArrayOffloat2[paramInt2++] = (float)(d4 * d7 + d5 * d8);
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1113 */         d2 = this.mxy; d3 = this.mxt;
/* 1114 */         d4 = this.myx; d6 = this.myt;
/* 1115 */         while (--paramInt3 >= 0) {
/* 1116 */           double d = paramArrayOffloat1[paramInt1++];
/* 1117 */           paramArrayOffloat2[paramInt2++] = (float)(d2 * paramArrayOffloat1[paramInt1++] + d3);
/* 1118 */           paramArrayOffloat2[paramInt2++] = (float)(d4 * d + d6);
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 1122 */         d2 = this.mxy; d4 = this.myx;
/* 1123 */         while (--paramInt3 >= 0) {
/* 1124 */           double d = paramArrayOffloat1[paramInt1++];
/* 1125 */           paramArrayOffloat2[paramInt2++] = (float)(d2 * paramArrayOffloat1[paramInt1++]);
/* 1126 */           paramArrayOffloat2[paramInt2++] = (float)(d4 * d);
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1130 */         d1 = this.mxx; d3 = this.mxt;
/* 1131 */         d5 = this.myy; d6 = this.myt;
/* 1132 */         while (--paramInt3 >= 0) {
/* 1133 */           paramArrayOffloat2[paramInt2++] = (float)(d1 * paramArrayOffloat1[paramInt1++] + d3);
/* 1134 */           paramArrayOffloat2[paramInt2++] = (float)(d5 * paramArrayOffloat1[paramInt1++] + d6);
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 1138 */         d1 = this.mxx; d5 = this.myy;
/* 1139 */         while (--paramInt3 >= 0) {
/* 1140 */           paramArrayOffloat2[paramInt2++] = (float)(d1 * paramArrayOffloat1[paramInt1++]);
/* 1141 */           paramArrayOffloat2[paramInt2++] = (float)(d5 * paramArrayOffloat1[paramInt1++]);
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 1145 */         d3 = this.mxt; d6 = this.myt;
/* 1146 */         while (--paramInt3 >= 0) {
/* 1147 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] + d3);
/* 1148 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] + d6);
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 1152 */     }  if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 1153 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 1186 */     doTransform(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3, this.state & 0x7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deltaTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) {
/* 1224 */     doTransform(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3, this.state & 0x6);
/*      */   }
/*      */   private void doTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3, int paramInt4) {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/* 1233 */     if (paramArrayOfdouble2 == paramArrayOfdouble1 && paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1244 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*      */       
/* 1246 */       paramInt1 = paramInt2;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1252 */     switch (paramInt4) {
/*      */       default:
/* 1254 */         stateError();
/*      */       
/*      */       case 7:
/* 1257 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 1258 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 1259 */         while (--paramInt3 >= 0) {
/* 1260 */           double d7 = paramArrayOfdouble1[paramInt1++];
/* 1261 */           double d8 = paramArrayOfdouble1[paramInt1++];
/* 1262 */           paramArrayOfdouble2[paramInt2++] = d1 * d7 + d2 * d8 + d3;
/* 1263 */           paramArrayOfdouble2[paramInt2++] = d4 * d7 + d5 * d8 + d6;
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 1267 */         d1 = this.mxx; d2 = this.mxy;
/* 1268 */         d4 = this.myx; d5 = this.myy;
/* 1269 */         while (--paramInt3 >= 0) {
/* 1270 */           double d7 = paramArrayOfdouble1[paramInt1++];
/* 1271 */           double d8 = paramArrayOfdouble1[paramInt1++];
/* 1272 */           paramArrayOfdouble2[paramInt2++] = d1 * d7 + d2 * d8;
/* 1273 */           paramArrayOfdouble2[paramInt2++] = d4 * d7 + d5 * d8;
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1277 */         d2 = this.mxy; d3 = this.mxt;
/* 1278 */         d4 = this.myx; d6 = this.myt;
/* 1279 */         while (--paramInt3 >= 0) {
/* 1280 */           double d = paramArrayOfdouble1[paramInt1++];
/* 1281 */           paramArrayOfdouble2[paramInt2++] = d2 * paramArrayOfdouble1[paramInt1++] + d3;
/* 1282 */           paramArrayOfdouble2[paramInt2++] = d4 * d + d6;
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 1286 */         d2 = this.mxy; d4 = this.myx;
/* 1287 */         while (--paramInt3 >= 0) {
/* 1288 */           double d = paramArrayOfdouble1[paramInt1++];
/* 1289 */           paramArrayOfdouble2[paramInt2++] = d2 * paramArrayOfdouble1[paramInt1++];
/* 1290 */           paramArrayOfdouble2[paramInt2++] = d4 * d;
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1294 */         d1 = this.mxx; d3 = this.mxt;
/* 1295 */         d5 = this.myy; d6 = this.myt;
/* 1296 */         while (--paramInt3 >= 0) {
/* 1297 */           paramArrayOfdouble2[paramInt2++] = d1 * paramArrayOfdouble1[paramInt1++] + d3;
/* 1298 */           paramArrayOfdouble2[paramInt2++] = d5 * paramArrayOfdouble1[paramInt1++] + d6;
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 1302 */         d1 = this.mxx; d5 = this.myy;
/* 1303 */         while (--paramInt3 >= 0) {
/* 1304 */           paramArrayOfdouble2[paramInt2++] = d1 * paramArrayOfdouble1[paramInt1++];
/* 1305 */           paramArrayOfdouble2[paramInt2++] = d5 * paramArrayOfdouble1[paramInt1++];
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 1309 */         d3 = this.mxt; d6 = this.myt;
/* 1310 */         while (--paramInt3 >= 0) {
/* 1311 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] + d3;
/* 1312 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] + d6;
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 1316 */     }  if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 1317 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(float[] paramArrayOffloat, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3) {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/* 1350 */     switch (this.state & 0x7) {
/*      */       default:
/* 1352 */         stateError();
/*      */       
/*      */       case 7:
/* 1355 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 1356 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 1357 */         while (--paramInt3 >= 0) {
/* 1358 */           double d7 = paramArrayOffloat[paramInt1++];
/* 1359 */           double d8 = paramArrayOffloat[paramInt1++];
/* 1360 */           paramArrayOfdouble[paramInt2++] = d1 * d7 + d2 * d8 + d3;
/* 1361 */           paramArrayOfdouble[paramInt2++] = d4 * d7 + d5 * d8 + d6;
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 1365 */         d1 = this.mxx; d2 = this.mxy;
/* 1366 */         d4 = this.myx; d5 = this.myy;
/* 1367 */         while (--paramInt3 >= 0) {
/* 1368 */           double d7 = paramArrayOffloat[paramInt1++];
/* 1369 */           double d8 = paramArrayOffloat[paramInt1++];
/* 1370 */           paramArrayOfdouble[paramInt2++] = d1 * d7 + d2 * d8;
/* 1371 */           paramArrayOfdouble[paramInt2++] = d4 * d7 + d5 * d8;
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1375 */         d2 = this.mxy; d3 = this.mxt;
/* 1376 */         d4 = this.myx; d6 = this.myt;
/* 1377 */         while (--paramInt3 >= 0) {
/* 1378 */           double d = paramArrayOffloat[paramInt1++];
/* 1379 */           paramArrayOfdouble[paramInt2++] = d2 * paramArrayOffloat[paramInt1++] + d3;
/* 1380 */           paramArrayOfdouble[paramInt2++] = d4 * d + d6;
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 1384 */         d2 = this.mxy; d4 = this.myx;
/* 1385 */         while (--paramInt3 >= 0) {
/* 1386 */           double d = paramArrayOffloat[paramInt1++];
/* 1387 */           paramArrayOfdouble[paramInt2++] = d2 * paramArrayOffloat[paramInt1++];
/* 1388 */           paramArrayOfdouble[paramInt2++] = d4 * d;
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1392 */         d1 = this.mxx; d3 = this.mxt;
/* 1393 */         d5 = this.myy; d6 = this.myt;
/* 1394 */         while (--paramInt3 >= 0) {
/* 1395 */           paramArrayOfdouble[paramInt2++] = d1 * paramArrayOffloat[paramInt1++] + d3;
/* 1396 */           paramArrayOfdouble[paramInt2++] = d5 * paramArrayOffloat[paramInt1++] + d6;
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 1400 */         d1 = this.mxx; d5 = this.myy;
/* 1401 */         while (--paramInt3 >= 0) {
/* 1402 */           paramArrayOfdouble[paramInt2++] = d1 * paramArrayOffloat[paramInt1++];
/* 1403 */           paramArrayOfdouble[paramInt2++] = d5 * paramArrayOffloat[paramInt1++];
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 1407 */         d3 = this.mxt; d6 = this.myt;
/* 1408 */         while (--paramInt3 >= 0) {
/* 1409 */           paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++] + d3;
/* 1410 */           paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++] + d6;
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 1414 */     }  while (--paramInt3 >= 0) {
/* 1415 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++];
/* 1416 */       paramArrayOfdouble[paramInt2++] = paramArrayOffloat[paramInt1++];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(double[] paramArrayOfdouble, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3) {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/* 1448 */     switch (this.state & 0x7) {
/*      */       default:
/* 1450 */         stateError();
/*      */       
/*      */       case 7:
/* 1453 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 1454 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 1455 */         while (--paramInt3 >= 0) {
/* 1456 */           double d7 = paramArrayOfdouble[paramInt1++];
/* 1457 */           double d8 = paramArrayOfdouble[paramInt1++];
/* 1458 */           paramArrayOffloat[paramInt2++] = (float)(d1 * d7 + d2 * d8 + d3);
/* 1459 */           paramArrayOffloat[paramInt2++] = (float)(d4 * d7 + d5 * d8 + d6);
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 1463 */         d1 = this.mxx; d2 = this.mxy;
/* 1464 */         d4 = this.myx; d5 = this.myy;
/* 1465 */         while (--paramInt3 >= 0) {
/* 1466 */           double d7 = paramArrayOfdouble[paramInt1++];
/* 1467 */           double d8 = paramArrayOfdouble[paramInt1++];
/* 1468 */           paramArrayOffloat[paramInt2++] = (float)(d1 * d7 + d2 * d8);
/* 1469 */           paramArrayOffloat[paramInt2++] = (float)(d4 * d7 + d5 * d8);
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1473 */         d2 = this.mxy; d3 = this.mxt;
/* 1474 */         d4 = this.myx; d6 = this.myt;
/* 1475 */         while (--paramInt3 >= 0) {
/* 1476 */           double d = paramArrayOfdouble[paramInt1++];
/* 1477 */           paramArrayOffloat[paramInt2++] = (float)(d2 * paramArrayOfdouble[paramInt1++] + d3);
/* 1478 */           paramArrayOffloat[paramInt2++] = (float)(d4 * d + d6);
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 1482 */         d2 = this.mxy; d4 = this.myx;
/* 1483 */         while (--paramInt3 >= 0) {
/* 1484 */           double d = paramArrayOfdouble[paramInt1++];
/* 1485 */           paramArrayOffloat[paramInt2++] = (float)(d2 * paramArrayOfdouble[paramInt1++]);
/* 1486 */           paramArrayOffloat[paramInt2++] = (float)(d4 * d);
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 1490 */         d1 = this.mxx; d3 = this.mxt;
/* 1491 */         d5 = this.myy; d6 = this.myt;
/* 1492 */         while (--paramInt3 >= 0) {
/* 1493 */           paramArrayOffloat[paramInt2++] = (float)(d1 * paramArrayOfdouble[paramInt1++] + d3);
/* 1494 */           paramArrayOffloat[paramInt2++] = (float)(d5 * paramArrayOfdouble[paramInt1++] + d6);
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 1498 */         d1 = this.mxx; d5 = this.myy;
/* 1499 */         while (--paramInt3 >= 0) {
/* 1500 */           paramArrayOffloat[paramInt2++] = (float)(d1 * paramArrayOfdouble[paramInt1++]);
/* 1501 */           paramArrayOffloat[paramInt2++] = (float)(d5 * paramArrayOfdouble[paramInt1++]);
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 1505 */         d3 = this.mxt; d6 = this.myt;
/* 1506 */         while (--paramInt3 >= 0) {
/* 1507 */           paramArrayOffloat[paramInt2++] = (float)(paramArrayOfdouble[paramInt1++] + d3);
/* 1508 */           paramArrayOffloat[paramInt2++] = (float)(paramArrayOfdouble[paramInt1++] + d6);
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 1512 */     }  while (--paramInt3 >= 0) {
/* 1513 */       paramArrayOffloat[paramInt2++] = (float)paramArrayOfdouble[paramInt1++];
/* 1514 */       paramArrayOffloat[paramInt2++] = (float)paramArrayOfdouble[paramInt1++];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D inverseTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) throws NoninvertibleTransformException {
/*      */     double d3;
/* 1543 */     if (paramPoint2D2 == null) {
/* 1544 */       paramPoint2D2 = new Point2D();
/*      */     }
/*      */     
/* 1547 */     double d1 = paramPoint2D1.x;
/* 1548 */     double d2 = paramPoint2D1.y;
/*      */     
/* 1550 */     switch (this.state)
/*      */     { default:
/* 1552 */         stateError();
/*      */       
/*      */       case 7:
/* 1555 */         d1 -= this.mxt;
/* 1556 */         d2 -= this.myt;
/*      */       
/*      */       case 6:
/* 1559 */         d3 = this.mxx * this.myy - this.mxy * this.myx;
/* 1560 */         if (d3 == 0.0D || Math.abs(d3) <= Double.MIN_VALUE) {
/* 1561 */           throw new NoninvertibleTransformException("Determinant is " + d3);
/*      */         }
/*      */         
/* 1564 */         paramPoint2D2.setLocation((float)((d1 * this.myy - d2 * this.mxy) / d3), (float)((d2 * this.mxx - d1 * this.myx) / d3));
/*      */         
/* 1566 */         return paramPoint2D2;
/*      */       case 5:
/* 1568 */         d1 -= this.mxt;
/* 1569 */         d2 -= this.myt;
/*      */       
/*      */       case 4:
/* 1572 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1573 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1575 */         paramPoint2D2.setLocation((float)(d2 / this.myx), (float)(d1 / this.mxy));
/* 1576 */         return paramPoint2D2;
/*      */       case 3:
/* 1578 */         d1 -= this.mxt;
/* 1579 */         d2 -= this.myt;
/*      */       
/*      */       case 2:
/* 1582 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1583 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1585 */         paramPoint2D2.setLocation((float)(d1 / this.mxx), (float)(d2 / this.myy));
/* 1586 */         return paramPoint2D2;
/*      */       case 1:
/* 1588 */         paramPoint2D2.setLocation((float)(d1 - this.mxt), (float)(d2 - this.myt));
/* 1589 */         return paramPoint2D2;
/*      */       case 0:
/* 1591 */         break; }  paramPoint2D2.setLocation((float)d1, (float)d2);
/* 1592 */     return paramPoint2D2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d inverseTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException {
/*      */     double d4;
/* 1620 */     if (paramVec3d2 == null) {
/* 1621 */       paramVec3d2 = new Vec3d();
/*      */     }
/*      */     
/* 1624 */     double d1 = paramVec3d1.x;
/* 1625 */     double d2 = paramVec3d1.y;
/* 1626 */     double d3 = paramVec3d1.z;
/*      */     
/* 1628 */     switch (this.state)
/*      */     { default:
/* 1630 */         stateError();
/*      */       
/*      */       case 7:
/* 1633 */         d1 -= this.mxt;
/* 1634 */         d2 -= this.myt;
/*      */       
/*      */       case 6:
/* 1637 */         d4 = this.mxx * this.myy - this.mxy * this.myx;
/* 1638 */         if (d4 == 0.0D || Math.abs(d4) <= Double.MIN_VALUE) {
/* 1639 */           throw new NoninvertibleTransformException("Determinant is " + d4);
/*      */         }
/*      */         
/* 1642 */         paramVec3d2.set((d1 * this.myy - d2 * this.mxy) / d4, (d2 * this.mxx - d1 * this.myx) / d4, d3);
/* 1643 */         return paramVec3d2;
/*      */       case 5:
/* 1645 */         d1 -= this.mxt;
/* 1646 */         d2 -= this.myt;
/*      */       
/*      */       case 4:
/* 1649 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1650 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1652 */         paramVec3d2.set(d2 / this.myx, d1 / this.mxy, d3);
/* 1653 */         return paramVec3d2;
/*      */       case 3:
/* 1655 */         d1 -= this.mxt;
/* 1656 */         d2 -= this.myt;
/*      */       
/*      */       case 2:
/* 1659 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1660 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1662 */         paramVec3d2.set(d1 / this.mxx, d2 / this.myy, d3);
/* 1663 */         return paramVec3d2;
/*      */       case 1:
/* 1665 */         paramVec3d2.set(d1 - this.mxt, d2 - this.myt, d3);
/* 1666 */         return paramVec3d2;
/*      */       case 0:
/* 1668 */         break; }  paramVec3d2.set(d1, d2, d3);
/* 1669 */     return paramVec3d2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vec3d inverseDeltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException {
/*      */     double d4;
/* 1699 */     if (paramVec3d2 == null) {
/* 1700 */       paramVec3d2 = new Vec3d();
/*      */     }
/*      */     
/* 1703 */     double d1 = paramVec3d1.x;
/* 1704 */     double d2 = paramVec3d1.y;
/* 1705 */     double d3 = paramVec3d1.z;
/*      */     
/* 1707 */     switch (this.state)
/*      */     { default:
/* 1709 */         stateError();
/*      */       
/*      */       case 6:
/*      */       case 7:
/* 1713 */         d4 = this.mxx * this.myy - this.mxy * this.myx;
/* 1714 */         if (d4 == 0.0D || Math.abs(d4) <= Double.MIN_VALUE) {
/* 1715 */           throw new NoninvertibleTransformException("Determinant is " + d4);
/*      */         }
/*      */         
/* 1718 */         paramVec3d2.set((d1 * this.myy - d2 * this.mxy) / d4, (d2 * this.mxx - d1 * this.myx) / d4, d3);
/* 1719 */         return paramVec3d2;
/*      */       case 4:
/*      */       case 5:
/* 1722 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1723 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1725 */         paramVec3d2.set(d2 / this.myx, d1 / this.mxy, d3);
/* 1726 */         return paramVec3d2;
/*      */       case 2:
/*      */       case 3:
/* 1729 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1730 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1732 */         paramVec3d2.set(d1 / this.mxx, d2 / this.myy, d3);
/* 1733 */         return paramVec3d2;
/*      */       case 0:
/*      */       case 1:
/* 1736 */         break; }  paramVec3d2.set(d1, d2, d3);
/* 1737 */     return paramVec3d2;
/*      */   }
/*      */   
/*      */   private BaseBounds inversTransform2DBounds(RectBounds paramRectBounds1, RectBounds paramRectBounds2) throws NoninvertibleTransformException {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/* 1746 */     switch (this.state)
/*      */     { default:
/* 1748 */         stateError();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/* 1753 */         d1 = this.mxx * this.myy - this.mxy * this.myx;
/* 1754 */         if (d1 == 0.0D || Math.abs(d1) <= Double.MIN_VALUE) {
/* 1755 */           throw new NoninvertibleTransformException("Determinant is " + d1);
/*      */         }
/*      */         
/* 1758 */         d2 = paramRectBounds1.getMinX() - this.mxt;
/* 1759 */         d3 = paramRectBounds1.getMinY() - this.myt;
/* 1760 */         d4 = paramRectBounds1.getMaxX() - this.mxt;
/* 1761 */         d5 = paramRectBounds1.getMaxY() - this.myt;
/* 1762 */         paramRectBounds2.setBoundsAndSort((float)((d2 * this.myy - d3 * this.mxy) / d1), (float)((d3 * this.mxx - d2 * this.myx) / d1), (float)((d4 * this.myy - d5 * this.mxy) / d1), (float)((d5 * this.mxx - d4 * this.myx) / d1));
/*      */ 
/*      */ 
/*      */         
/* 1766 */         paramRectBounds2.add((float)((d4 * this.myy - d3 * this.mxy) / d1), (float)((d3 * this.mxx - d4 * this.myx) / d1));
/*      */         
/* 1768 */         paramRectBounds2.add((float)((d2 * this.myy - d5 * this.mxy) / d1), (float)((d5 * this.mxx - d2 * this.myx) / d1));
/*      */         
/* 1770 */         return paramRectBounds2;
/*      */       case 5:
/* 1772 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1773 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1775 */         paramRectBounds2.setBoundsAndSort((float)((paramRectBounds1.getMinY() - this.myt) / this.myx), 
/* 1776 */             (float)((paramRectBounds1.getMinX() - this.mxt) / this.mxy), 
/* 1777 */             (float)((paramRectBounds1.getMaxY() - this.myt) / this.myx), 
/* 1778 */             (float)((paramRectBounds1.getMaxX() - this.mxt) / this.mxy));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1819 */         return paramRectBounds2;case 4: if (this.mxy == 0.0D || this.myx == 0.0D) throw new NoninvertibleTransformException("Determinant is 0");  paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinY() / this.myx), (float)(paramRectBounds1.getMinX() / this.mxy), (float)(paramRectBounds1.getMaxY() / this.myx), (float)(paramRectBounds1.getMaxX() / this.mxy)); return paramRectBounds2;case 3: if (this.mxx == 0.0D || this.myy == 0.0D) throw new NoninvertibleTransformException("Determinant is 0");  paramRectBounds2.setBoundsAndSort((float)((paramRectBounds1.getMinX() - this.mxt) / this.mxx), (float)((paramRectBounds1.getMinY() - this.myt) / this.myy), (float)((paramRectBounds1.getMaxX() - this.mxt) / this.mxx), (float)((paramRectBounds1.getMaxY() - this.myt) / this.myy)); return paramRectBounds2;case 2: if (this.mxx == 0.0D || this.myy == 0.0D) throw new NoninvertibleTransformException("Determinant is 0");  paramRectBounds2.setBoundsAndSort((float)(paramRectBounds1.getMinX() / this.mxx), (float)(paramRectBounds1.getMinY() / this.myy), (float)(paramRectBounds1.getMaxX() / this.mxx), (float)(paramRectBounds1.getMaxY() / this.myy)); return paramRectBounds2;case 1: paramRectBounds2.setBounds((float)(paramRectBounds1.getMinX() - this.mxt), (float)(paramRectBounds1.getMinY() - this.myt), (float)(paramRectBounds1.getMaxX() - this.mxt), (float)(paramRectBounds1.getMaxY() - this.myt)); return paramRectBounds2;case 0: break; }  if (paramRectBounds2 != paramRectBounds1) paramRectBounds2.setBounds(paramRectBounds1);  return paramRectBounds2; } private BaseBounds inversTransform3DBounds(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) throws NoninvertibleTransformException { double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/*      */     double d7;
/* 1826 */     switch (this.state)
/*      */     { default:
/* 1828 */         stateError();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/* 1837 */         d1 = this.mxx * this.myy - this.mxy * this.myx;
/* 1838 */         if (d1 == 0.0D || Math.abs(d1) <= Double.MIN_VALUE) {
/* 1839 */           throw new NoninvertibleTransformException("Determinant is " + d1);
/*      */         }
/*      */         
/* 1842 */         d2 = paramBaseBounds1.getMinX() - this.mxt;
/* 1843 */         d3 = paramBaseBounds1.getMinY() - this.myt;
/* 1844 */         d4 = paramBaseBounds1.getMinZ();
/* 1845 */         d5 = paramBaseBounds1.getMaxX() - this.mxt;
/* 1846 */         d6 = paramBaseBounds1.getMaxY() - this.myt;
/* 1847 */         d7 = paramBaseBounds1.getMaxZ();
/* 1848 */         paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)((d2 * this.myy - d3 * this.mxy) / d1), (float)((d3 * this.mxx - d2 * this.myx) / d1), (float)(d4 / d1), (float)((d5 * this.myy - d6 * this.mxy) / d1), (float)((d6 * this.mxx - d5 * this.myx) / d1), (float)(d7 / d1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1855 */         paramBaseBounds2.add((float)((d5 * this.myy - d3 * this.mxy) / d1), (float)((d3 * this.mxx - d5 * this.myx) / d1), 0.0F);
/*      */         
/* 1857 */         paramBaseBounds2.add((float)((d2 * this.myy - d6 * this.mxy) / d1), (float)((d6 * this.mxx - d2 * this.myx) / d1), 0.0F);
/*      */         
/* 1859 */         return paramBaseBounds2;
/*      */       case 3:
/* 1861 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1862 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1864 */         paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)((paramBaseBounds1.getMinX() - this.mxt) / this.mxx), 
/* 1865 */             (float)((paramBaseBounds1.getMinY() - this.myt) / this.myy), paramBaseBounds1
/* 1866 */             .getMinZ(), 
/* 1867 */             (float)((paramBaseBounds1.getMaxX() - this.mxt) / this.mxx), 
/* 1868 */             (float)((paramBaseBounds1.getMaxY() - this.myt) / this.myy), paramBaseBounds1
/* 1869 */             .getMaxZ());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1896 */         return paramBaseBounds2;case 2: if (this.mxx == 0.0D || this.myy == 0.0D) throw new NoninvertibleTransformException("Determinant is 0");  paramBaseBounds2 = paramBaseBounds2.deriveWithNewBoundsAndSort((float)(paramBaseBounds1.getMinX() / this.mxx), (float)(paramBaseBounds1.getMinY() / this.myy), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxX() / this.mxx), (float)(paramBaseBounds1.getMaxY() / this.myy), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 1: paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds((float)(paramBaseBounds1.getMinX() - this.mxt), (float)(paramBaseBounds1.getMinY() - this.myt), paramBaseBounds1.getMinZ(), (float)(paramBaseBounds1.getMaxX() - this.mxt), (float)(paramBaseBounds1.getMaxY() - this.myt), paramBaseBounds1.getMaxZ()); return paramBaseBounds2;case 0: break; }  if (paramBaseBounds2 != paramBaseBounds1) paramBaseBounds2 = paramBaseBounds2.deriveWithNewBounds(paramBaseBounds1);  return paramBaseBounds2; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseBounds inverseTransform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) throws NoninvertibleTransformException {
/* 1903 */     if (paramBaseBounds1.getBoundsType() != BaseBounds.BoundsType.RECTANGLE || paramBaseBounds2
/* 1904 */       .getBoundsType() != BaseBounds.BoundsType.RECTANGLE) {
/* 1905 */       return inversTransform3DBounds(paramBaseBounds1, paramBaseBounds2);
/*      */     }
/* 1907 */     return inversTransform2DBounds((RectBounds)paramBaseBounds1, (RectBounds)paramBaseBounds2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(Rectangle paramRectangle1, Rectangle paramRectangle2) throws NoninvertibleTransformException {
/*      */     RectBounds rectBounds;
/* 1914 */     switch (this.state) {
/*      */       default:
/* 1916 */         stateError();
/*      */       
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/* 1924 */         rectBounds = new RectBounds(paramRectangle1);
/*      */         
/* 1926 */         rectBounds = (RectBounds)inverseTransform(rectBounds, rectBounds);
/* 1927 */         paramRectangle2.setBounds(rectBounds);
/*      */         return;
/*      */       case 1:
/* 1930 */         Translate2D.transform(paramRectangle1, paramRectangle2, -this.mxt, -this.myt); return;
/*      */       case 0:
/*      */         break;
/* 1933 */     }  if (paramRectangle2 != paramRectangle1) {
/* 1934 */       paramRectangle2.setBounds(paramRectangle1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/* 1968 */     doInverseTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3, this.state);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseDeltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/* 1999 */     doInverseTransform(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3, this.state & 0xFFFFFFFE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doInverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3, int paramInt4) throws NoninvertibleTransformException {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/*      */     double d7;
/* 2014 */     if (paramArrayOffloat2 == paramArrayOffloat1 && paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2025 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*      */       
/* 2027 */       paramInt1 = paramInt2;
/*      */     } 
/*      */     
/* 2030 */     switch (paramInt4) {
/*      */       default:
/* 2032 */         stateError();
/*      */       
/*      */       case 7:
/* 2035 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 2036 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 2037 */         d7 = d1 * d5 - d2 * d4;
/* 2038 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2039 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2042 */         while (--paramInt3 >= 0) {
/* 2043 */           double d8 = paramArrayOffloat1[paramInt1++] - d3;
/* 2044 */           double d9 = paramArrayOffloat1[paramInt1++] - d6;
/* 2045 */           paramArrayOffloat2[paramInt2++] = (float)((d8 * d5 - d9 * d2) / d7);
/* 2046 */           paramArrayOffloat2[paramInt2++] = (float)((d9 * d1 - d8 * d4) / d7);
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 2050 */         d1 = this.mxx; d2 = this.mxy;
/* 2051 */         d4 = this.myx; d5 = this.myy;
/* 2052 */         d7 = d1 * d5 - d2 * d4;
/* 2053 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2054 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2057 */         while (--paramInt3 >= 0) {
/* 2058 */           double d8 = paramArrayOffloat1[paramInt1++];
/* 2059 */           double d9 = paramArrayOffloat1[paramInt1++];
/* 2060 */           paramArrayOffloat2[paramInt2++] = (float)((d8 * d5 - d9 * d2) / d7);
/* 2061 */           paramArrayOffloat2[paramInt2++] = (float)((d9 * d1 - d8 * d4) / d7);
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 2065 */         d2 = this.mxy; d3 = this.mxt;
/* 2066 */         d4 = this.myx; d6 = this.myt;
/* 2067 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2068 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2070 */         while (--paramInt3 >= 0) {
/* 2071 */           double d = paramArrayOffloat1[paramInt1++] - d3;
/* 2072 */           paramArrayOffloat2[paramInt2++] = (float)((paramArrayOffloat1[paramInt1++] - d6) / d4);
/* 2073 */           paramArrayOffloat2[paramInt2++] = (float)(d / d2);
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 2077 */         d2 = this.mxy; d4 = this.myx;
/* 2078 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2079 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2081 */         while (--paramInt3 >= 0) {
/* 2082 */           double d = paramArrayOffloat1[paramInt1++];
/* 2083 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] / d4);
/* 2084 */           paramArrayOffloat2[paramInt2++] = (float)(d / d2);
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 2088 */         d1 = this.mxx; d3 = this.mxt;
/* 2089 */         d5 = this.myy; d6 = this.myt;
/* 2090 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2091 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2093 */         while (--paramInt3 >= 0) {
/* 2094 */           paramArrayOffloat2[paramInt2++] = (float)((paramArrayOffloat1[paramInt1++] - d3) / d1);
/* 2095 */           paramArrayOffloat2[paramInt2++] = (float)((paramArrayOffloat1[paramInt1++] - d6) / d5);
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 2099 */         d1 = this.mxx; d5 = this.myy;
/* 2100 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2101 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2103 */         while (--paramInt3 >= 0) {
/* 2104 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] / d1);
/* 2105 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] / d5);
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 2109 */         d3 = this.mxt; d6 = this.myt;
/* 2110 */         while (--paramInt3 >= 0) {
/* 2111 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] - d3);
/* 2112 */           paramArrayOffloat2[paramInt2++] = (float)(paramArrayOffloat1[paramInt1++] - d6);
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 2116 */     }  if (paramArrayOffloat1 != paramArrayOffloat2 || paramInt1 != paramInt2) {
/* 2117 */       System.arraycopy(paramArrayOffloat1, paramInt1, paramArrayOffloat2, paramInt2, paramInt3 * 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void inverseTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) throws NoninvertibleTransformException {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/*      */     double d7;
/* 2156 */     if (paramArrayOfdouble2 == paramArrayOfdouble1 && paramInt2 > paramInt1 && paramInt2 < paramInt1 + paramInt3 * 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2167 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*      */       
/* 2169 */       paramInt1 = paramInt2;
/*      */     } 
/*      */     
/* 2172 */     switch (this.state) {
/*      */       default:
/* 2174 */         stateError();
/*      */       
/*      */       case 7:
/* 2177 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 2178 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 2179 */         d7 = d1 * d5 - d2 * d4;
/* 2180 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2181 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2184 */         while (--paramInt3 >= 0) {
/* 2185 */           double d8 = paramArrayOfdouble1[paramInt1++] - d3;
/* 2186 */           double d9 = paramArrayOfdouble1[paramInt1++] - d6;
/* 2187 */           paramArrayOfdouble2[paramInt2++] = (d8 * d5 - d9 * d2) / d7;
/* 2188 */           paramArrayOfdouble2[paramInt2++] = (d9 * d1 - d8 * d4) / d7;
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 2192 */         d1 = this.mxx; d2 = this.mxy;
/* 2193 */         d4 = this.myx; d5 = this.myy;
/* 2194 */         d7 = d1 * d5 - d2 * d4;
/* 2195 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2196 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2199 */         while (--paramInt3 >= 0) {
/* 2200 */           double d8 = paramArrayOfdouble1[paramInt1++];
/* 2201 */           double d9 = paramArrayOfdouble1[paramInt1++];
/* 2202 */           paramArrayOfdouble2[paramInt2++] = (d8 * d5 - d9 * d2) / d7;
/* 2203 */           paramArrayOfdouble2[paramInt2++] = (d9 * d1 - d8 * d4) / d7;
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 2207 */         d2 = this.mxy; d3 = this.mxt;
/* 2208 */         d4 = this.myx; d6 = this.myt;
/* 2209 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2210 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2212 */         while (--paramInt3 >= 0) {
/* 2213 */           double d = paramArrayOfdouble1[paramInt1++] - d3;
/* 2214 */           paramArrayOfdouble2[paramInt2++] = (paramArrayOfdouble1[paramInt1++] - d6) / d4;
/* 2215 */           paramArrayOfdouble2[paramInt2++] = d / d2;
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 2219 */         d2 = this.mxy; d4 = this.myx;
/* 2220 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2221 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2223 */         while (--paramInt3 >= 0) {
/* 2224 */           double d = paramArrayOfdouble1[paramInt1++];
/* 2225 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] / d4;
/* 2226 */           paramArrayOfdouble2[paramInt2++] = d / d2;
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 2230 */         d1 = this.mxx; d3 = this.mxt;
/* 2231 */         d5 = this.myy; d6 = this.myt;
/* 2232 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2233 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2235 */         while (--paramInt3 >= 0) {
/* 2236 */           paramArrayOfdouble2[paramInt2++] = (paramArrayOfdouble1[paramInt1++] - d3) / d1;
/* 2237 */           paramArrayOfdouble2[paramInt2++] = (paramArrayOfdouble1[paramInt1++] - d6) / d5;
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 2241 */         d1 = this.mxx; d5 = this.myy;
/* 2242 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2243 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2245 */         while (--paramInt3 >= 0) {
/* 2246 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] / d1;
/* 2247 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] / d5;
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 2251 */         d3 = this.mxt; d6 = this.myt;
/* 2252 */         while (--paramInt3 >= 0) {
/* 2253 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] - d3;
/* 2254 */           paramArrayOfdouble2[paramInt2++] = paramArrayOfdouble1[paramInt1++] - d6;
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 2258 */     }  if (paramArrayOfdouble1 != paramArrayOfdouble2 || paramInt1 != paramInt2) {
/* 2259 */       System.arraycopy(paramArrayOfdouble1, paramInt1, paramArrayOfdouble2, paramInt2, paramInt3 * 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Shape createTransformedShape(Shape paramShape) {
/* 2278 */     if (paramShape == null) {
/* 2279 */       return null;
/*      */     }
/* 2281 */     return new Path2D(paramShape, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void translate(double paramDouble1, double paramDouble2) {
/* 2300 */     switch (this.state) {
/*      */       default:
/* 2302 */         stateError();
/*      */       
/*      */       case 7:
/* 2305 */         this.mxt = paramDouble1 * this.mxx + paramDouble2 * this.mxy + this.mxt;
/* 2306 */         this.myt = paramDouble1 * this.myx + paramDouble2 * this.myy + this.myt;
/* 2307 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/* 2308 */           this.state = 6;
/* 2309 */           if (this.type != -1) {
/* 2310 */             this.type &= 0xFFFFFFFE;
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 6:
/* 2315 */         this.mxt = paramDouble1 * this.mxx + paramDouble2 * this.mxy;
/* 2316 */         this.myt = paramDouble1 * this.myx + paramDouble2 * this.myy;
/* 2317 */         if (this.mxt != 0.0D || this.myt != 0.0D) {
/* 2318 */           this.state = 7;
/* 2319 */           this.type |= 0x1;
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 2323 */         this.mxt = paramDouble2 * this.mxy + this.mxt;
/* 2324 */         this.myt = paramDouble1 * this.myx + this.myt;
/* 2325 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/* 2326 */           this.state = 4;
/* 2327 */           if (this.type != -1) {
/* 2328 */             this.type &= 0xFFFFFFFE;
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 4:
/* 2333 */         this.mxt = paramDouble2 * this.mxy;
/* 2334 */         this.myt = paramDouble1 * this.myx;
/* 2335 */         if (this.mxt != 0.0D || this.myt != 0.0D) {
/* 2336 */           this.state = 5;
/* 2337 */           this.type |= 0x1;
/*      */         } 
/*      */         return;
/*      */       case 3:
/* 2341 */         this.mxt = paramDouble1 * this.mxx + this.mxt;
/* 2342 */         this.myt = paramDouble2 * this.myy + this.myt;
/* 2343 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/* 2344 */           this.state = 2;
/* 2345 */           if (this.type != -1) {
/* 2346 */             this.type &= 0xFFFFFFFE;
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 2:
/* 2351 */         this.mxt = paramDouble1 * this.mxx;
/* 2352 */         this.myt = paramDouble2 * this.myy;
/* 2353 */         if (this.mxt != 0.0D || this.myt != 0.0D) {
/* 2354 */           this.state = 3;
/* 2355 */           this.type |= 0x1;
/*      */         } 
/*      */         return;
/*      */       case 1:
/* 2359 */         this.mxt = paramDouble1 + this.mxt;
/* 2360 */         this.myt = paramDouble2 + this.myt;
/* 2361 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/* 2362 */           this.state = 0;
/* 2363 */           this.type = 0;
/*      */         }  return;
/*      */       case 0:
/*      */         break;
/* 2367 */     }  this.mxt = paramDouble1;
/* 2368 */     this.myt = paramDouble2;
/* 2369 */     if (paramDouble1 != 0.0D || paramDouble2 != 0.0D) {
/* 2370 */       this.state = 1;
/* 2371 */       this.type = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2380 */   private static final int[] rot90conversion = new int[] { 4, 5, 4, 5, 2, 3, 6, 7 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void rotate90() {
/* 2391 */     double d = this.mxx;
/* 2392 */     this.mxx = this.mxy;
/* 2393 */     this.mxy = -d;
/* 2394 */     d = this.myx;
/* 2395 */     this.myx = this.myy;
/* 2396 */     this.myy = -d;
/* 2397 */     int i = rot90conversion[this.state];
/* 2398 */     if ((i & 0x6) == 2 && this.mxx == 1.0D && this.myy == 1.0D)
/*      */     {
/*      */       
/* 2401 */       i -= 2;
/*      */     }
/* 2403 */     this.state = i;
/* 2404 */     this.type = -1;
/*      */   }
/*      */   protected final void rotate180() {
/* 2407 */     this.mxx = -this.mxx;
/* 2408 */     this.myy = -this.myy;
/* 2409 */     int i = this.state;
/* 2410 */     if ((i & 0x4) != 0) {
/*      */ 
/*      */       
/* 2413 */       this.mxy = -this.mxy;
/* 2414 */       this.myx = -this.myx;
/*      */ 
/*      */     
/*      */     }
/* 2418 */     else if (this.mxx == 1.0D && this.myy == 1.0D) {
/* 2419 */       this.state = i & 0xFFFFFFFD;
/*      */     } else {
/* 2421 */       this.state = i | 0x2;
/*      */     } 
/*      */     
/* 2424 */     this.type = -1;
/*      */   }
/*      */   protected final void rotate270() {
/* 2427 */     double d = this.mxx;
/* 2428 */     this.mxx = -this.mxy;
/* 2429 */     this.mxy = d;
/* 2430 */     d = this.myx;
/* 2431 */     this.myx = -this.myy;
/* 2432 */     this.myy = d;
/* 2433 */     int i = rot90conversion[this.state];
/* 2434 */     if ((i & 0x6) == 2 && this.mxx == 1.0D && this.myy == 1.0D)
/*      */     {
/*      */       
/* 2437 */       i -= 2;
/*      */     }
/* 2439 */     this.state = i;
/* 2440 */     this.type = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double paramDouble) {
/* 2461 */     double d = Math.sin(paramDouble);
/* 2462 */     if (d == 1.0D) {
/* 2463 */       rotate90();
/* 2464 */     } else if (d == -1.0D) {
/* 2465 */       rotate270();
/*      */     } else {
/* 2467 */       double d1 = Math.cos(paramDouble);
/* 2468 */       if (d1 == -1.0D) {
/* 2469 */         rotate180();
/* 2470 */       } else if (d1 != 1.0D) {
/*      */         
/* 2472 */         double d2 = this.mxx;
/* 2473 */         double d3 = this.mxy;
/* 2474 */         this.mxx = d1 * d2 + d * d3;
/* 2475 */         this.mxy = -d * d2 + d1 * d3;
/* 2476 */         d2 = this.myx;
/* 2477 */         d3 = this.myy;
/* 2478 */         this.myx = d1 * d2 + d * d3;
/* 2479 */         this.myy = -d * d2 + d1 * d3;
/* 2480 */         updateState2D();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scale(double paramDouble1, double paramDouble2) {
/* 2500 */     int i = this.state;
/*      */     
/* 2502 */     switch (i) {
/*      */       default:
/* 2504 */         stateError();
/*      */       
/*      */       case 6:
/*      */       case 7:
/* 2508 */         this.mxx *= paramDouble1;
/* 2509 */         this.myy *= paramDouble2;
/*      */       
/*      */       case 4:
/*      */       case 5:
/* 2513 */         this.mxy *= paramDouble2;
/* 2514 */         this.myx *= paramDouble1;
/* 2515 */         if (this.mxy == 0.0D && this.myx == 0.0D) {
/* 2516 */           i &= 0x1;
/* 2517 */           if (this.mxx == 1.0D && this.myy == 1.0D) {
/* 2518 */             this
/*      */               
/* 2520 */               .type = (i == 0) ? 0 : 1;
/*      */           } else {
/* 2522 */             i |= 0x2;
/* 2523 */             this.type = -1;
/*      */           } 
/* 2525 */           this.state = i;
/*      */         } 
/*      */         return;
/*      */       case 2:
/*      */       case 3:
/* 2530 */         this.mxx *= paramDouble1;
/* 2531 */         this.myy *= paramDouble2;
/* 2532 */         if (this.mxx == 1.0D && this.myy == 1.0D) {
/* 2533 */           this.state = i &= 0x1;
/* 2534 */           this
/*      */             
/* 2536 */             .type = (i == 0) ? 0 : 1;
/*      */         } else {
/* 2538 */           this.type = -1;
/*      */         }  return;
/*      */       case 0:
/*      */       case 1:
/*      */         break;
/* 2543 */     }  this.mxx = paramDouble1;
/* 2544 */     this.myy = paramDouble2;
/* 2545 */     if (paramDouble1 != 1.0D || paramDouble2 != 1.0D) {
/* 2546 */       this.state = i | 0x2;
/* 2547 */       this.type = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shear(double paramDouble1, double paramDouble2) {
/*      */     double d1, d2;
/* 2568 */     int i = this.state;
/*      */     
/* 2570 */     switch (i) {
/*      */       default:
/* 2572 */         stateError();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/* 2577 */         d1 = this.mxx;
/* 2578 */         d2 = this.mxy;
/* 2579 */         this.mxx = d1 + d2 * paramDouble2;
/* 2580 */         this.mxy = d1 * paramDouble1 + d2;
/*      */         
/* 2582 */         d1 = this.myx;
/* 2583 */         d2 = this.myy;
/* 2584 */         this.myx = d1 + d2 * paramDouble2;
/* 2585 */         this.myy = d1 * paramDouble1 + d2;
/* 2586 */         updateState2D();
/*      */         return;
/*      */       case 4:
/*      */       case 5:
/* 2590 */         this.mxx = this.mxy * paramDouble2;
/* 2591 */         this.myy = this.myx * paramDouble1;
/* 2592 */         if (this.mxx != 0.0D || this.myy != 0.0D) {
/* 2593 */           this.state = i | 0x2;
/*      */         }
/* 2595 */         this.type = -1;
/*      */         return;
/*      */       case 2:
/*      */       case 3:
/* 2599 */         this.mxy = this.mxx * paramDouble1;
/* 2600 */         this.myx = this.myy * paramDouble2;
/* 2601 */         if (this.mxy != 0.0D || this.myx != 0.0D) {
/* 2602 */           this.state = i | 0x4;
/*      */         }
/* 2604 */         this.type = -1; return;
/*      */       case 0:
/*      */       case 1:
/*      */         break;
/* 2608 */     }  this.mxy = paramDouble1;
/* 2609 */     this.myx = paramDouble2;
/* 2610 */     if (this.mxy != 0.0D || this.myx != 0.0D) {
/* 2611 */       this.state = i | 0x2 | 0x4;
/* 2612 */       this.type = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void concatenate(BaseTransform paramBaseTransform) {
/*      */     double d1, d2;
/* 2639 */     switch (paramBaseTransform.getDegree()) {
/*      */       case IDENTITY:
/*      */         return;
/*      */       case TRANSLATE_2D:
/* 2643 */         translate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt());
/*      */         return;
/*      */       case AFFINE_2D:
/*      */         break;
/*      */       default:
/* 2648 */         if (!paramBaseTransform.is2D()) {
/* 2649 */           degreeError(BaseTransform.Degree.AFFINE_2D);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2656 */         if (!(paramBaseTransform instanceof AffineBase)) {
/* 2657 */           paramBaseTransform = new Affine2D(paramBaseTransform);
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2664 */     int i = this.state;
/* 2665 */     AffineBase affineBase = (AffineBase)paramBaseTransform;
/* 2666 */     int j = affineBase.state;
/* 2667 */     switch (j << 4 | i) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/* 2682 */         this.mxy = affineBase.mxy;
/* 2683 */         this.myx = affineBase.myx;
/*      */       
/*      */       case 48:
/* 2686 */         this.mxx = affineBase.mxx;
/* 2687 */         this.myy = affineBase.myy;
/*      */       
/*      */       case 16:
/* 2690 */         this.mxt = affineBase.mxt;
/* 2691 */         this.myt = affineBase.myt;
/* 2692 */         this.state = j;
/* 2693 */         this.type = affineBase.type;
/*      */         return;
/*      */       case 96:
/* 2696 */         this.mxy = affineBase.mxy;
/* 2697 */         this.myx = affineBase.myx;
/*      */       
/*      */       case 32:
/* 2700 */         this.mxx = affineBase.mxx;
/* 2701 */         this.myy = affineBase.myy;
/* 2702 */         this.state = j;
/* 2703 */         this.type = affineBase.type;
/*      */         return;
/*      */       case 80:
/* 2706 */         this.mxt = affineBase.mxt;
/* 2707 */         this.myt = affineBase.myt;
/*      */       
/*      */       case 64:
/* 2710 */         this.mxy = affineBase.mxy;
/* 2711 */         this.myx = affineBase.myx;
/* 2712 */         this.mxx = this.myy = 0.0D;
/* 2713 */         this.state = j;
/* 2714 */         this.type = affineBase.type;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/*      */       case 20:
/*      */       case 21:
/*      */       case 22:
/*      */       case 23:
/* 2725 */         translate(affineBase.mxt, affineBase.myt);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 33:
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/* 2736 */         scale(affineBase.mxx, affineBase.myy);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 70:
/*      */       case 71:
/* 2742 */         d4 = affineBase.mxy; d5 = affineBase.myx;
/* 2743 */         d1 = this.mxx;
/* 2744 */         this.mxx = this.mxy * d5;
/* 2745 */         this.mxy = d1 * d4;
/* 2746 */         d1 = this.myx;
/* 2747 */         this.myx = this.myy * d5;
/* 2748 */         this.myy = d1 * d4;
/* 2749 */         this.type = -1;
/*      */         return;
/*      */       case 68:
/*      */       case 69:
/* 2753 */         this.mxx = this.mxy * affineBase.myx;
/* 2754 */         this.mxy = 0.0D;
/* 2755 */         this.myy = this.myx * affineBase.mxy;
/* 2756 */         this.myx = 0.0D;
/* 2757 */         this.state = i ^ 0x6;
/* 2758 */         this.type = -1;
/*      */         return;
/*      */       case 66:
/*      */       case 67:
/* 2762 */         this.mxy = this.mxx * affineBase.mxy;
/* 2763 */         this.mxx = 0.0D;
/* 2764 */         this.myx = this.myy * affineBase.myx;
/* 2765 */         this.myy = 0.0D;
/* 2766 */         this.state = i ^ 0x6;
/* 2767 */         this.type = -1;
/*      */         return;
/*      */       case 65:
/* 2770 */         this.mxx = 0.0D;
/* 2771 */         this.mxy = affineBase.mxy;
/* 2772 */         this.myx = affineBase.myx;
/* 2773 */         this.myy = 0.0D;
/* 2774 */         this.state = 5;
/* 2775 */         this.type = -1;
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/* 2780 */     double d3 = affineBase.mxx, d4 = affineBase.mxy, d7 = affineBase.mxt;
/* 2781 */     double d5 = affineBase.myx, d6 = affineBase.myy, d8 = affineBase.myt;
/* 2782 */     switch (i) {
/*      */       default:
/* 2784 */         stateError();
/*      */       
/*      */       case 6:
/* 2787 */         this.state = i | j;
/*      */       
/*      */       case 7:
/* 2790 */         d1 = this.mxx;
/* 2791 */         d2 = this.mxy;
/* 2792 */         this.mxx = d3 * d1 + d5 * d2;
/* 2793 */         this.mxy = d4 * d1 + d6 * d2;
/* 2794 */         this.mxt += d7 * d1 + d8 * d2;
/*      */         
/* 2796 */         d1 = this.myx;
/* 2797 */         d2 = this.myy;
/* 2798 */         this.myx = d3 * d1 + d5 * d2;
/* 2799 */         this.myy = d4 * d1 + d6 * d2;
/* 2800 */         this.myt += d7 * d1 + d8 * d2;
/* 2801 */         this.type = -1;
/*      */         return;
/*      */       
/*      */       case 4:
/*      */       case 5:
/* 2806 */         d1 = this.mxy;
/* 2807 */         this.mxx = d5 * d1;
/* 2808 */         this.mxy = d6 * d1;
/* 2809 */         this.mxt += d8 * d1;
/*      */         
/* 2811 */         d1 = this.myx;
/* 2812 */         this.myx = d3 * d1;
/* 2813 */         this.myy = d4 * d1;
/* 2814 */         this.myt += d7 * d1;
/*      */         break;
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 2819 */         d1 = this.mxx;
/* 2820 */         this.mxx = d3 * d1;
/* 2821 */         this.mxy = d4 * d1;
/* 2822 */         this.mxt += d7 * d1;
/*      */         
/* 2824 */         d1 = this.myy;
/* 2825 */         this.myx = d5 * d1;
/* 2826 */         this.myy = d6 * d1;
/* 2827 */         this.myt += d8 * d1;
/*      */         break;
/*      */       
/*      */       case 1:
/* 2831 */         this.mxx = d3;
/* 2832 */         this.mxy = d4;
/* 2833 */         this.mxt += d7;
/*      */         
/* 2835 */         this.myx = d5;
/* 2836 */         this.myy = d6;
/* 2837 */         this.myt += d8;
/* 2838 */         this.state = j | 0x1;
/* 2839 */         this.type = -1;
/*      */         return;
/*      */     } 
/* 2842 */     updateState2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void concatenate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 2852 */     double d1 = this.mxx * paramDouble1 + this.mxy * paramDouble4;
/* 2853 */     double d2 = this.mxx * paramDouble2 + this.mxy * paramDouble5;
/* 2854 */     double d3 = this.mxx * paramDouble3 + this.mxy * paramDouble6 + this.mxt;
/* 2855 */     double d4 = this.myx * paramDouble1 + this.myy * paramDouble4;
/* 2856 */     double d5 = this.myx * paramDouble2 + this.myy * paramDouble5;
/* 2857 */     double d6 = this.myx * paramDouble3 + this.myy * paramDouble6 + this.myt;
/* 2858 */     this.mxx = d1;
/* 2859 */     this.mxy = d2;
/* 2860 */     this.mxt = d3;
/* 2861 */     this.myx = d4;
/* 2862 */     this.myy = d5;
/* 2863 */     this.myt = d6;
/* 2864 */     updateState();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invert() throws NoninvertibleTransformException {
/*      */     double d1;
/*      */     double d2;
/*      */     double d3;
/*      */     double d4;
/*      */     double d5;
/*      */     double d6;
/*      */     double d7;
/* 2892 */     switch (this.state) {
/*      */       default:
/* 2894 */         stateError();
/*      */       
/*      */       case 7:
/* 2897 */         d1 = this.mxx; d2 = this.mxy; d3 = this.mxt;
/* 2898 */         d4 = this.myx; d5 = this.myy; d6 = this.myt;
/* 2899 */         d7 = d1 * d5 - d2 * d4;
/* 2900 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2901 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2904 */         this.mxx = d5 / d7;
/* 2905 */         this.myx = -d4 / d7;
/* 2906 */         this.mxy = -d2 / d7;
/* 2907 */         this.myy = d1 / d7;
/* 2908 */         this.mxt = (d2 * d6 - d5 * d3) / d7;
/* 2909 */         this.myt = (d4 * d3 - d1 * d6) / d7;
/*      */         break;
/*      */       case 6:
/* 2912 */         d1 = this.mxx; d2 = this.mxy;
/* 2913 */         d4 = this.myx; d5 = this.myy;
/* 2914 */         d7 = d1 * d5 - d2 * d4;
/* 2915 */         if (d7 == 0.0D || Math.abs(d7) <= Double.MIN_VALUE) {
/* 2916 */           throw new NoninvertibleTransformException("Determinant is " + d7);
/*      */         }
/*      */         
/* 2919 */         this.mxx = d5 / d7;
/* 2920 */         this.myx = -d4 / d7;
/* 2921 */         this.mxy = -d2 / d7;
/* 2922 */         this.myy = d1 / d7;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 5:
/* 2927 */         d2 = this.mxy; d3 = this.mxt;
/* 2928 */         d4 = this.myx; d6 = this.myt;
/* 2929 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2930 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/*      */         
/* 2933 */         this.myx = 1.0D / d2;
/* 2934 */         this.mxy = 1.0D / d4;
/*      */         
/* 2936 */         this.mxt = -d6 / d4;
/* 2937 */         this.myt = -d3 / d2;
/*      */         break;
/*      */       case 4:
/* 2940 */         d2 = this.mxy;
/* 2941 */         d4 = this.myx;
/* 2942 */         if (d2 == 0.0D || d4 == 0.0D) {
/* 2943 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/*      */         
/* 2946 */         this.myx = 1.0D / d2;
/* 2947 */         this.mxy = 1.0D / d4;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 2953 */         d1 = this.mxx; d3 = this.mxt;
/* 2954 */         d5 = this.myy; d6 = this.myt;
/* 2955 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2956 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2958 */         this.mxx = 1.0D / d1;
/*      */ 
/*      */         
/* 2961 */         this.myy = 1.0D / d5;
/* 2962 */         this.mxt = -d3 / d1;
/* 2963 */         this.myt = -d6 / d5;
/*      */         break;
/*      */       case 2:
/* 2966 */         d1 = this.mxx;
/* 2967 */         d5 = this.myy;
/* 2968 */         if (d1 == 0.0D || d5 == 0.0D) {
/* 2969 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 2971 */         this.mxx = 1.0D / d1;
/*      */ 
/*      */         
/* 2974 */         this.myy = 1.0D / d5;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 2983 */         this.mxt = -this.mxt;
/* 2984 */         this.myt = -this.myt;
/*      */         break;
/*      */       case 0:
/*      */         break;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\AffineBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */