/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Line2D;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.prism.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGLine
/*    */   extends NGShape
/*    */ {
/* 38 */   private Line2D line = new Line2D();
/*    */   
/*    */   public void updateLine(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 41 */     this.line.x1 = paramFloat1;
/* 42 */     this.line.y1 = paramFloat2;
/* 43 */     this.line.x2 = paramFloat3;
/* 44 */     this.line.y2 = paramFloat4;
/* 45 */     geometryChanged();
/*    */   }
/*    */   
/*    */   protected void renderContent2D(Graphics paramGraphics, boolean paramBoolean) {
/* 49 */     if ((this.mode == NGShape.Mode.STROKE || this.mode == NGShape.Mode.STROKE_FILL) && this.drawStroke
/* 50 */       .getLineWidth() > 0.0F && this.drawStroke
/* 51 */       .getType() != 1) {
/*    */       
/* 53 */       paramGraphics.setPaint(this.drawPaint);
/* 54 */       paramGraphics.setStroke(this.drawStroke);
/* 55 */       paramGraphics.drawLine(this.line.x1, this.line.y1, this.line.x2, this.line.y2);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public final Shape getShape() {
/* 61 */     return this.line;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGLine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */