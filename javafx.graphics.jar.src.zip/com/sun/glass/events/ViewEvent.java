/*    */ package com.sun.glass.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViewEvent
/*    */ {
/*    */   public static final int ADD = 411;
/*    */   public static final int REMOVE = 412;
/*    */   public static final int REPAINT = 421;
/*    */   public static final int RESIZE = 422;
/*    */   public static final int MOVE = 423;
/*    */   public static final int FULLSCREEN_ENTER = 431;
/*    */   public static final int FULLSCREEN_EXIT = 432;
/*    */   
/*    */   public static String getTypeString(int paramInt) {
/* 41 */     String str = "UNKNOWN";
/* 42 */     switch (paramInt) { case 411:
/* 43 */         str = "ADD";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 57 */         return str;case 412: str = "REMOVE"; return str;case 421: str = "REPAINT"; return str;case 422: str = "RESIZE"; return str;case 423: str = "MOVE"; return str;case 431: str = "FULLSCREEN_ENTER"; return str;case 432: str = "FULLSCREEN_EXIT"; return str; }  System.err.println("Unknown view event type: " + paramInt); return str;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glass\events\ViewEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */