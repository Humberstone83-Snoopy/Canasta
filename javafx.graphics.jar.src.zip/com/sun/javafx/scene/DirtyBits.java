/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum DirtyBits
/*     */ {
/*  32 */   NODE_CACHE,
/*  33 */   NODE_CLIP,
/*  34 */   NODE_EFFECT,
/*  35 */   NODE_OPACITY,
/*  36 */   NODE_TRANSFORM,
/*  37 */   NODE_BOUNDS,
/*  38 */   NODE_TRANSFORMED_BOUNDS,
/*  39 */   NODE_VISIBLE,
/*  40 */   NODE_DEPTH_TEST,
/*  41 */   NODE_BLENDMODE,
/*  42 */   NODE_CSS,
/*  43 */   NODE_FORCE_SYNC,
/*  44 */   NODE_VIEW_ORDER,
/*     */ 
/*     */   
/*  47 */   NODE_GEOMETRY,
/*  48 */   NODE_CULLFACE,
/*  49 */   NODE_DRAWMODE,
/*  50 */   NODE_SMOOTH,
/*  51 */   NODE_VIEWPORT,
/*  52 */   NODE_CONTENTS,
/*     */ 
/*     */   
/*  55 */   PARENT_CHILDREN,
/*  56 */   PARENT_CHILDREN_VIEW_ORDER,
/*     */ 
/*     */   
/*  59 */   SHAPE_FILL,
/*  60 */   SHAPE_FILLRULE,
/*  61 */   SHAPE_MODE,
/*  62 */   SHAPE_STROKE,
/*  63 */   SHAPE_STROKEATTRS,
/*     */ 
/*     */   
/*  66 */   REGION_SHAPE,
/*     */ 
/*     */   
/*  69 */   TEXT_ATTRS,
/*  70 */   TEXT_FONT,
/*  71 */   TEXT_SELECTION,
/*  72 */   TEXT_HELPER,
/*     */ 
/*     */   
/*  75 */   MEDIAVIEW_MEDIA,
/*     */ 
/*     */   
/*  78 */   WEBVIEW_VIEW,
/*     */ 
/*     */   
/*  81 */   EFFECT_EFFECT,
/*     */ 
/*     */   
/*  84 */   NODE_CAMERA,
/*  85 */   NODE_CAMERA_TRANSFORM,
/*     */ 
/*     */   
/*  88 */   NODE_LIGHT,
/*  89 */   NODE_LIGHT_SCOPE,
/*  90 */   NODE_LIGHT_TRANSFORM,
/*     */ 
/*     */   
/*  93 */   MATERIAL,
/*     */ 
/*     */   
/*  96 */   MESH,
/*  97 */   MESH_GEOM,
/*     */ 
/*     */   
/* 100 */   DEBUG,
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   MAX_DIRTY;
/*     */   
/*     */   private long mask;
/*     */   
/*     */   DirtyBits() {
/* 110 */     this.mask = (1 << ordinal());
/*     */   }
/*     */   public final long getMask() {
/* 113 */     return this.mask;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\DirtyBits.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */