package com.sun.javafx.scene;

import com.sun.javafx.geom.BaseBounds;
import com.sun.javafx.geom.transform.BaseTransform;
import javafx.scene.Node;

public interface BoundsAccessor {
  BaseBounds getGeomBounds(BaseBounds paramBaseBounds, BaseTransform paramBaseTransform, Node paramNode);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\BoundsAccessor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */