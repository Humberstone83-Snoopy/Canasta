/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.webkit.graphics.WCGraphicsContext;
/*    */ import com.sun.webkit.graphics.WCRectangle;
/*    */ import com.sun.webkit.graphics.WCRenderQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCRenderQueueImpl
/*    */   extends WCRenderQueue
/*    */ {
/*    */   WCRenderQueueImpl(WCGraphicsContext paramWCGraphicsContext) {
/* 35 */     super(paramWCGraphicsContext);
/*    */   }
/*    */   
/*    */   WCRenderQueueImpl(WCRectangle paramWCRectangle, boolean paramBoolean) {
/* 39 */     super(paramWCRectangle, paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void flush() {
/* 44 */     if (!isEmpty()) {
/* 45 */       PrismInvoker.invokeOnRenderThread(() -> decode());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void disposeGraphics() {
/* 53 */     PrismInvoker.invokeOnRenderThread(() -> {
/*    */           if (this.gc != null)
/*    */             this.gc.dispose(); 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCRenderQueueImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */