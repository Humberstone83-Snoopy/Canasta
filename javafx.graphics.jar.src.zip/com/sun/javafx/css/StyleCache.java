/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StyleCache
/*     */ {
/*     */   private Map<StyleCacheEntry.Key, StyleCacheEntry> entries;
/*     */   
/*     */   public void clear() {
/*  87 */     if (this.entries == null)
/*  88 */       return;  Thread.dumpStack();
/*  89 */     this.entries.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public StyleCacheEntry getStyleCacheEntry(StyleCacheEntry.Key paramKey) {
/*  94 */     StyleCacheEntry styleCacheEntry = null;
/*  95 */     if (this.entries != null) {
/*  96 */       styleCacheEntry = this.entries.get(paramKey);
/*     */     }
/*  98 */     return styleCacheEntry;
/*     */   }
/*     */   
/*     */   public void addStyleCacheEntry(StyleCacheEntry.Key paramKey, StyleCacheEntry paramStyleCacheEntry) {
/* 102 */     if (this.entries == null) {
/* 103 */       this.entries = new HashMap<>(5);
/*     */     }
/* 105 */     this.entries.put(paramKey, paramStyleCacheEntry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Key
/*     */   {
/*     */     final int[] styleMapIds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int hash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Key(int[] param1ArrayOfint, int param1Int) {
/* 179 */       this.hash = Integer.MIN_VALUE;
/*     */       this.styleMapIds = new int[param1Int];
/*     */       System.arraycopy(param1ArrayOfint, 0, this.styleMapIds, 0, param1Int);
/*     */     }
/*     */     
/*     */     public Key(Key param1Key) {
/*     */       this(param1Key.styleMapIds, param1Key.styleMapIds.length);
/*     */     }
/*     */     
/*     */     public int[] getStyleMapIds() {
/*     */       return this.styleMapIds;
/*     */     }
/*     */     
/*     */     public String toString() {
/*     */       return Arrays.toString(this.styleMapIds);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       if (this.hash == Integer.MIN_VALUE) {
/*     */         this.hash = 3;
/*     */         if (this.styleMapIds != null)
/*     */           for (byte b = 0; b < this.styleMapIds.length; b++) {
/*     */             int i = this.styleMapIds[b];
/*     */             this.hash = 17 * (this.hash + i);
/*     */           }  
/*     */       } 
/*     */       return this.hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*     */       if (param1Object == this)
/*     */         return true; 
/*     */       if (param1Object == null || param1Object.getClass() != getClass())
/*     */         return false; 
/*     */       Key key = (Key)param1Object;
/*     */       if (this.hash != key.hash)
/*     */         return false; 
/*     */       if ((((this.styleMapIds == null) ? 1 : 0) ^ ((key.styleMapIds == null) ? 1 : 0)) != 0)
/*     */         return false; 
/*     */       if (this.styleMapIds == null)
/*     */         return true; 
/*     */       if (this.styleMapIds.length != key.styleMapIds.length)
/*     */         return false; 
/*     */       for (byte b = 0; b < this.styleMapIds.length; b++) {
/*     */         if (this.styleMapIds[b] != key.styleMapIds[b])
/*     */           return false; 
/*     */       } 
/*     */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\StyleCache.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */