/*     */ package com.sun.javafx.geom.transform;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransformHelper
/*     */ {
/*     */   public static BaseBounds general3dBoundsTransform(CanTransformVec3d paramCanTransformVec3d, BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2, Vec3d paramVec3d) {
/*  41 */     if (paramVec3d == null) {
/*  42 */       paramVec3d = new Vec3d();
/*     */     }
/*     */     
/*  45 */     double d1 = paramBaseBounds1.getMinX();
/*  46 */     double d2 = paramBaseBounds1.getMinY();
/*  47 */     double d3 = paramBaseBounds1.getMinZ();
/*  48 */     double d4 = paramBaseBounds1.getMaxX();
/*  49 */     double d5 = paramBaseBounds1.getMaxY();
/*  50 */     double d6 = paramBaseBounds1.getMaxZ();
/*     */ 
/*     */     
/*  53 */     paramVec3d.set(d4, d5, d6);
/*  54 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/*  55 */     double d7 = paramVec3d.x;
/*  56 */     double d8 = paramVec3d.y;
/*  57 */     double d9 = paramVec3d.z;
/*  58 */     double d10 = paramVec3d.x;
/*  59 */     double d11 = paramVec3d.y;
/*  60 */     double d12 = paramVec3d.z;
/*     */     
/*  62 */     paramVec3d.set(d1, d5, d6);
/*  63 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/*  64 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/*  65 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/*  66 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/*  67 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/*  68 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/*  69 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/*  71 */     paramVec3d.set(d1, d2, d6);
/*  72 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/*  73 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/*  74 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/*  75 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/*  76 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/*  77 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/*  78 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/*  80 */     paramVec3d.set(d4, d2, d6);
/*  81 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/*  82 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/*  83 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/*  84 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/*  85 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/*  86 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/*  87 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/*  89 */     paramVec3d.set(d1, d5, d3);
/*  90 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/*  91 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/*  92 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/*  93 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/*  94 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/*  95 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/*  96 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/*  98 */     paramVec3d.set(d4, d5, d3);
/*  99 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/* 100 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/* 101 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/* 102 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/* 103 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/* 104 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/* 105 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/* 107 */     paramVec3d.set(d1, d2, d3);
/* 108 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/* 109 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/* 110 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/* 111 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/* 112 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/* 113 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/* 114 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/* 116 */     paramVec3d.set(d4, d2, d3);
/* 117 */     paramVec3d = paramCanTransformVec3d.transform(paramVec3d, paramVec3d);
/* 118 */     if (paramVec3d.x > d10) d10 = paramVec3d.x; 
/* 119 */     if (paramVec3d.y > d11) d11 = paramVec3d.y; 
/* 120 */     if (paramVec3d.z > d12) d12 = paramVec3d.z; 
/* 121 */     if (paramVec3d.x < d7) d7 = paramVec3d.x; 
/* 122 */     if (paramVec3d.y < d8) d8 = paramVec3d.y; 
/* 123 */     if (paramVec3d.z < d9) d9 = paramVec3d.z;
/*     */     
/* 125 */     return paramBaseBounds2.deriveWithNewBounds((float)d7, (float)d8, (float)d9, (float)d10, (float)d11, (float)d12);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\TransformHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */