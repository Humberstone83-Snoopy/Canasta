/*     */ package com.sun.webkit;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Timer
/*     */ {
/*     */   private static Timer instance;
/*     */   private static Mode mode;
/*     */   long fireTime;
/*     */   
/*     */   public enum Mode
/*     */   {
/*  41 */     PLATFORM_TICKS,
/*  42 */     SEPARATE_THREAD;
/*     */   }
/*     */   
/*     */   public static synchronized Mode getMode() {
/*  46 */     if (mode == null)
/*     */     {
/*     */       
/*  49 */       mode = Boolean.valueOf(AccessController.<String>doPrivileged(() -> System.getProperty("com.sun.webkit.platformticks", "true"))).booleanValue() ? Mode.PLATFORM_TICKS : Mode.SEPARATE_THREAD;
/*     */     }
/*  51 */     return mode;
/*     */   }
/*     */   
/*     */   public static synchronized Timer getTimer() {
/*  55 */     if (instance == null)
/*     */     {
/*  57 */       instance = (getMode() == Mode.PLATFORM_TICKS) ? new Timer() : new SeparateThreadTimer();
/*     */     }
/*  59 */     return instance;
/*     */   }
/*     */   
/*     */   public synchronized void notifyTick() {
/*  63 */     if (this.fireTime > 0L && this.fireTime <= System.currentTimeMillis()) {
/*  64 */       fireTimerEvent(this.fireTime);
/*     */     }
/*     */   }
/*     */   
/*     */   void fireTimerEvent(long paramLong) {
/*  69 */     boolean bool = false;
/*  70 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/*  74 */       if (paramLong == this.fireTime) {
/*  75 */         bool = true;
/*  76 */         this.fireTime = 0L;
/*     */       } 
/*     */     } 
/*  79 */     if (bool) {
/*  80 */       WebPage.lockPage();
/*     */       
/*     */       try {
/*  83 */         twkFireTimerEvent();
/*     */       } finally {
/*     */         
/*  86 */         WebPage.unlockPage();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized void setFireTime(long paramLong) {
/*  92 */     this.fireTime = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fwkSetFireTime(double paramDouble) {
/*  99 */     getTimer().setFireTime((long)Math.ceil(paramDouble * 1000.0D));
/*     */   }
/*     */   
/*     */   private static void fwkStopTimer() {
/* 103 */     getTimer().setFireTime(0L);
/*     */   }
/*     */   
/*     */   private static native void twkFireTimerEvent();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\Timer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */