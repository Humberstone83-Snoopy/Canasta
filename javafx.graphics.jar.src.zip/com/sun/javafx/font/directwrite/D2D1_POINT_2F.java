/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class D2D1_POINT_2F
/*    */ {
/*    */   float x;
/*    */   float y;
/*    */   
/*    */   D2D1_POINT_2F() {}
/*    */   
/*    */   D2D1_POINT_2F(float paramFloat1, float paramFloat2) {
/* 33 */     this.x = paramFloat1;
/* 34 */     this.y = paramFloat2;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\D2D1_POINT_2F.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */