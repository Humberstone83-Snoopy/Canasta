package com.sun.javafx.scene.text;

import com.sun.javafx.geom.RectBounds;

public interface TextLine {
  GlyphList[] getRuns();
  
  RectBounds getBounds();
  
  float getLeftSideBearing();
  
  float getRightSideBearing();
  
  int getStart();
  
  int getLength();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\TextLine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */