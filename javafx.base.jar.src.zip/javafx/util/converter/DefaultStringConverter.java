/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultStringConverter
/*    */   extends StringConverter<String>
/*    */ {
/*    */   public String toString(String paramString) {
/* 37 */     return (paramString != null) ? paramString : "";
/*    */   }
/*    */ 
/*    */   
/*    */   public String fromString(String paramString) {
/* 42 */     return paramString;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\DefaultStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */