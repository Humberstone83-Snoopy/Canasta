package com.sun.javafx.iio;

import java.io.IOException;
import java.io.InputStream;

public interface ImageLoaderFactory {
  ImageFormatDescription getFormatDescription();
  
  ImageLoader createImageLoader(InputStream paramInputStream) throws IOException;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageLoaderFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */