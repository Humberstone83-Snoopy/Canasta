package com.sun.webkit.plugin;

import com.sun.webkit.graphics.WCGraphicsContext;
import java.io.IOException;

public interface Plugin {
  public static final int EVENT_BEFOREACTIVATE = -4;
  
  public static final int EVENT_FOCUSCHANGE = -1;
  
  void requestFocus();
  
  void setNativeContainerBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void activate(Object paramObject, PluginListener paramPluginListener);
  
  void destroy();
  
  void setVisible(boolean paramBoolean);
  
  void setEnabled(boolean paramBoolean);
  
  void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  Object invoke(String paramString1, String paramString2, Object[] paramArrayOfObject) throws IOException;
  
  void paint(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  boolean handleMouseEvent(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, long paramLong);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\plugin\Plugin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */