/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.AmbientLight;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AmbientLightHelper
/*    */   extends LightBaseHelper
/*    */ {
/* 42 */   private static final AmbientLightHelper theInstance = new AmbientLightHelper(); static {
/* 43 */     Utils.forceInit(AmbientLight.class);
/*    */   }
/*    */   private static AmbientLightAccessor ambientLightAccessor;
/*    */   private static AmbientLightHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(AmbientLight paramAmbientLight) {
/* 51 */     setHelper(paramAmbientLight, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 56 */     return ambientLightAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */   
/*    */   public static void setAmbientLightAccessor(AmbientLightAccessor paramAmbientLightAccessor) {
/* 60 */     if (ambientLightAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     ambientLightAccessor = paramAmbientLightAccessor;
/*    */   }
/*    */   
/*    */   public static interface AmbientLightAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\AmbientLightHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */