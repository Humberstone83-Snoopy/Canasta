/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.css.CSSRule;
/*    */ import org.w3c.dom.css.CSSRuleList;
/*    */ import org.w3c.dom.css.CSSStyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSStyleSheetImpl
/*    */   extends StyleSheetImpl
/*    */   implements CSSStyleSheet
/*    */ {
/*    */   CSSStyleSheetImpl(long paramLong) {
/* 35 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSStyleSheet getImpl(long paramLong) {
/* 39 */     return (CSSStyleSheet)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getOwnerRuleImpl(long paramLong);
/*    */   
/*    */   public CSSRule getOwnerRule() {
/* 45 */     return CSSRuleImpl.getImpl(getOwnerRuleImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSRuleList getCssRules() {
/* 50 */     return CSSRuleListImpl.getImpl(getCssRulesImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public CSSRuleList getRules() {
/* 55 */     return CSSRuleListImpl.getImpl(getRulesImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   static native long getCssRulesImpl(long paramLong);
/*    */   
/*    */   static native long getRulesImpl(long paramLong);
/*    */   
/*    */   public int insertRule(String paramString, int paramInt) throws DOMException {
/* 64 */     return insertRuleImpl(getPeer(), paramString, paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static native int insertRuleImpl(long paramLong, String paramString, int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public void deleteRule(int paramInt) throws DOMException {
/* 75 */     deleteRuleImpl(getPeer(), paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static native void deleteRuleImpl(long paramLong, int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public int addRule(String paramString1, String paramString2, int paramInt) throws DOMException {
/* 86 */     return addRuleImpl(getPeer(), paramString1, paramString2, paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static native int addRuleImpl(long paramLong, String paramString1, String paramString2, int paramInt);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeRule(int paramInt) throws DOMException {
/* 99 */     removeRuleImpl(getPeer(), paramInt);
/*    */   }
/*    */   
/*    */   static native void removeRuleImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSStyleSheetImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */