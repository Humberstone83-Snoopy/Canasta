/*      */ package com.sun.javafx.webkit.prism;
/*      */ import com.sun.glass.ui.Screen;
/*      */ import com.sun.javafx.font.FontStrike;
/*      */ import com.sun.javafx.font.Metrics;
/*      */ import com.sun.javafx.font.PGFont;
/*      */ import com.sun.javafx.geom.Arc2D;
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.DirtyRegionPool;
/*      */ import com.sun.javafx.geom.Line2D;
/*      */ import com.sun.javafx.geom.Path2D;
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.Shape;
/*      */ import com.sun.javafx.geom.transform.Affine2D;
/*      */ import com.sun.javafx.geom.transform.Affine3D;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.geom.transform.GeneralTransform3D;
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.text.GlyphList;
/*      */ import com.sun.javafx.scene.text.TextLayout;
/*      */ import com.sun.javafx.sg.prism.NGImageView;
/*      */ import com.sun.javafx.sg.prism.NGNode;
/*      */ import com.sun.javafx.sg.prism.NGPath;
/*      */ import com.sun.javafx.sg.prism.NGRectangle;
/*      */ import com.sun.javafx.sg.prism.NGShape;
/*      */ import com.sun.javafx.sg.prism.NGText;
/*      */ import com.sun.javafx.text.TextRun;
/*      */ import com.sun.prism.BasicStroke;
/*      */ import com.sun.prism.CompositeMode;
/*      */ import com.sun.prism.Graphics;
/*      */ import com.sun.prism.GraphicsPipeline;
/*      */ import com.sun.prism.Image;
/*      */ import com.sun.prism.MaskTextureGraphics;
/*      */ import com.sun.prism.RTTexture;
/*      */ import com.sun.prism.ReadbackGraphics;
/*      */ import com.sun.prism.ResourceFactory;
/*      */ import com.sun.prism.Texture;
/*      */ import com.sun.prism.paint.Color;
/*      */ import com.sun.prism.paint.Gradient;
/*      */ import com.sun.prism.paint.ImagePattern;
/*      */ import com.sun.prism.paint.Paint;
/*      */ import com.sun.scenario.effect.Blend;
/*      */ import com.sun.scenario.effect.Color4f;
/*      */ import com.sun.scenario.effect.DropShadow;
/*      */ import com.sun.scenario.effect.Effect;
/*      */ import com.sun.scenario.effect.FilterContext;
/*      */ import com.sun.scenario.effect.ImageData;
/*      */ import com.sun.scenario.effect.impl.Renderer;
/*      */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*      */ import com.sun.scenario.effect.impl.prism.PrEffectHelper;
/*      */ import com.sun.scenario.effect.impl.prism.PrFilterContext;
/*      */ import com.sun.webkit.graphics.Ref;
/*      */ import com.sun.webkit.graphics.RenderTheme;
/*      */ import com.sun.webkit.graphics.ScrollBarTheme;
/*      */ import com.sun.webkit.graphics.WCFont;
/*      */ import com.sun.webkit.graphics.WCGradient;
/*      */ import com.sun.webkit.graphics.WCGraphicsContext;
/*      */ import com.sun.webkit.graphics.WCImage;
/*      */ import com.sun.webkit.graphics.WCPath;
/*      */ import com.sun.webkit.graphics.WCPoint;
/*      */ import com.sun.webkit.graphics.WCRectangle;
/*      */ import com.sun.webkit.graphics.WCSize;
/*      */ import com.sun.webkit.graphics.WCTransform;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ class WCGraphicsPrismContext extends WCGraphicsContext {
/*      */   public enum Type {
/*   72 */     PRIMARY,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   79 */     DEDICATED;
/*      */   }
/*      */ 
/*      */   
/*   83 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCGraphicsPrismContext.class.getName());
/*   84 */   private static final boolean DEBUG_DRAW_CLIP_SHAPE = Boolean.valueOf(
/*   85 */       AccessController.<String>doPrivileged(() -> System.getProperty("com.sun.webkit.debugDrawClipShape", "false"))).booleanValue();
/*      */   
/*      */   Graphics baseGraphics;
/*      */   
/*      */   private BaseTransform baseTransform;
/*      */   
/*   91 */   private final List<ContextState> states = new ArrayList<>();
/*      */   
/*   93 */   private ContextState state = new ContextState();
/*      */ 
/*      */   
/*   96 */   private Graphics cachedGraphics = null;
/*      */   
/*      */   private int fontSmoothingType;
/*      */   private boolean isRootLayerValid = false;
/*      */   
/*      */   WCGraphicsPrismContext(Graphics paramGraphics) {
/*  102 */     this.state.setClip(paramGraphics.getClipRect());
/*  103 */     this.state.setAlpha(paramGraphics.getExtraAlpha());
/*  104 */     this.baseGraphics = paramGraphics;
/*  105 */     initBaseTransform(paramGraphics.getTransformNoClone());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type type() {
/*  112 */     return Type.PRIMARY;
/*      */   }
/*      */   
/*      */   final void initBaseTransform(BaseTransform paramBaseTransform) {
/*  116 */     this.baseTransform = new Affine3D(paramBaseTransform);
/*  117 */     this.state.setTransform((Affine3D)this.baseTransform);
/*      */   }
/*      */   
/*      */   private void resetCachedGraphics() {
/*  121 */     this.cachedGraphics = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getPlatformGraphics() {
/*  126 */     return getGraphics(false);
/*      */   }
/*      */   
/*      */   Graphics getGraphics(boolean paramBoolean) {
/*  130 */     if (this.cachedGraphics == null) {
/*  131 */       Layer layer = this.state.getLayerNoClone();
/*  132 */       this
/*      */         
/*  134 */         .cachedGraphics = (layer != null) ? layer.getGraphics() : this.baseGraphics;
/*      */       
/*  136 */       this.state.apply(this.cachedGraphics);
/*      */       
/*  138 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  139 */         log.fine("getPlatformGraphics for " + this + " : " + this.cachedGraphics);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  144 */     Rectangle rectangle = this.cachedGraphics.getClipRectNoClone();
/*  145 */     return (paramBoolean && rectangle != null && rectangle.isEmpty()) ? 
/*  146 */       null : 
/*  147 */       this.cachedGraphics;
/*      */   }
/*      */ 
/*      */   
/*      */   public void saveState() {
/*  152 */     this.state.markAsRestorePoint();
/*  153 */     saveStateInternal();
/*      */   }
/*      */ 
/*      */   
/*      */   private void saveStateInternal() {
/*  158 */     this.states.add(this.state);
/*  159 */     this.state = this.state.clone();
/*      */   }
/*      */   
/*      */   private void startNewLayer(Layer paramLayer) {
/*  163 */     saveStateInternal();
/*      */ 
/*      */     
/*  166 */     Rectangle rectangle = this.state.getClipNoClone();
/*      */ 
/*      */ 
/*      */     
/*  170 */     Affine3D affine3D = new Affine3D(BaseTransform.getTranslateInstance(-rectangle.x, -rectangle.y));
/*      */ 
/*      */     
/*  173 */     affine3D.concatenate(this.state.getTransformNoClone());
/*      */ 
/*      */     
/*  176 */     rectangle.x = 0;
/*  177 */     rectangle.y = 0;
/*      */ 
/*      */     
/*  180 */     Graphics graphics = getGraphics(true);
/*  181 */     if (graphics != null && graphics != this.baseGraphics) {
/*  182 */       paramLayer.init(graphics);
/*      */     }
/*      */     
/*  185 */     this.state.setTransform(affine3D);
/*  186 */     this.state.setLayer(paramLayer);
/*      */     
/*  188 */     resetCachedGraphics();
/*      */   }
/*      */   
/*      */   private void renderLayer(Layer paramLayer) {
/*  192 */     WCTransform wCTransform = getTransform();
/*      */ 
/*      */     
/*  195 */     setTransform(new WCTransform(1.0D, 0.0D, 0.0D, 1.0D, paramLayer
/*      */ 
/*      */           
/*  198 */           .getX(), paramLayer.getY()));
/*      */ 
/*      */     
/*  201 */     Graphics graphics = getGraphics(true);
/*  202 */     if (graphics != null) {
/*  203 */       paramLayer.render(graphics);
/*      */     }
/*      */ 
/*      */     
/*  207 */     setTransform(wCTransform);
/*      */   }
/*      */   
/*      */   private void restoreStateInternal() {
/*  211 */     int i = this.states.size();
/*  212 */     if (i == 0) {
/*  213 */       assert false : "Unbalanced restoreState";
/*      */       
/*      */       return;
/*      */     } 
/*  217 */     Layer layer = this.state.getLayerNoClone();
/*  218 */     this.state = this.states.remove(i - 1);
/*  219 */     if (layer != this.state.getLayerNoClone()) {
/*  220 */       renderLayer(layer);
/*  221 */       layer.dispose();
/*  222 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  223 */         log.fine("Popped layer " + layer);
/*      */       }
/*      */     } else {
/*  226 */       resetCachedGraphics();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void restoreState() {
/*  232 */     log.fine("restoring state");
/*      */     do {
/*  234 */       restoreStateInternal();
/*  235 */     } while (!this.state.isRestorePoint());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void flushAllLayers() {
/*  243 */     if (this.state == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  248 */     if (this.isRootLayerValid) {
/*  249 */       log.fine("FlushAllLayers: root layer is valid, skipping");
/*      */       
/*      */       return;
/*      */     } 
/*  253 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  254 */       log.fine("FlushAllLayers");
/*      */     }
/*      */     
/*  257 */     ContextState contextState = this.state;
/*      */     
/*  259 */     for (int i = this.states.size() - 1; i >= 0; i--) {
/*  260 */       Layer layer1 = this.state.getLayerNoClone();
/*  261 */       this.state = this.states.get(i);
/*  262 */       if (layer1 != this.state.getLayerNoClone()) {
/*  263 */         renderLayer(layer1);
/*      */       } else {
/*  265 */         resetCachedGraphics();
/*      */       } 
/*      */     } 
/*      */     
/*  269 */     Layer layer = this.state.getLayerNoClone();
/*  270 */     if (layer != null) {
/*  271 */       renderLayer(layer);
/*      */     }
/*      */     
/*  274 */     this.state = contextState;
/*  275 */     this.isRootLayerValid = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  280 */     if (!this.states.isEmpty()) {
/*  281 */       log.fine("Unbalanced saveState/restoreState");
/*      */     }
/*  283 */     for (ContextState contextState : this.states) {
/*  284 */       if (contextState.getLayerNoClone() != null) {
/*  285 */         contextState.getLayerNoClone().dispose();
/*      */       }
/*      */     } 
/*  288 */     this.states.clear();
/*      */     
/*  290 */     if (this.state != null && this.state.getLayerNoClone() != null) {
/*  291 */       this.state.getLayerNoClone().dispose();
/*      */     }
/*  293 */     this.state = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClip(WCPath paramWCPath, boolean paramBoolean) {
/*  298 */     Affine3D affine3D = new Affine3D(this.state.getTransformNoClone());
/*  299 */     paramWCPath.transform(affine3D
/*  300 */         .getMxx(), affine3D.getMyx(), affine3D
/*  301 */         .getMxy(), affine3D.getMyy(), affine3D
/*  302 */         .getMxt(), affine3D.getMyt());
/*      */ 
/*      */     
/*  305 */     if (!paramBoolean) {
/*  306 */       WCRectangle wCRectangle = paramWCPath.getBounds();
/*      */ 
/*      */ 
/*      */       
/*  310 */       int i = (int)Math.floor(wCRectangle.getX());
/*  311 */       int j = (int)Math.floor(wCRectangle.getY());
/*  312 */       int k = (int)Math.ceil(wCRectangle.getMaxX()) - i;
/*  313 */       int m = (int)Math.ceil(wCRectangle.getMaxY()) - j;
/*      */       
/*  315 */       this.state.clip(new Rectangle(i, j, k, m));
/*      */     } 
/*      */     
/*  318 */     Rectangle rectangle = this.state.getClipNoClone();
/*      */     
/*  320 */     if (paramBoolean) {
/*  321 */       paramWCPath.addRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */     }
/*      */ 
/*      */     
/*  325 */     paramWCPath.translate(-rectangle.x, -rectangle.y);
/*      */ 
/*      */     
/*  328 */     ClipLayer clipLayer = new ClipLayer(getGraphics(false), rectangle, paramWCPath, (type() == Type.DEDICATED));
/*      */     
/*  330 */     startNewLayer(clipLayer);
/*      */     
/*  332 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  333 */       log.fine("setClip(WCPath " + paramWCPath.getID() + ")");
/*  334 */       log.fine("Pushed layer " + clipLayer);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Rectangle transformClip(Rectangle paramRectangle) {
/*  339 */     if (paramRectangle == null) {
/*  340 */       return null;
/*      */     }
/*      */     
/*  343 */     float[] arrayOfFloat = { paramRectangle.x, paramRectangle.y, (paramRectangle.x + paramRectangle.width), paramRectangle.y, paramRectangle.x, (paramRectangle.y + paramRectangle.height), (paramRectangle.x + paramRectangle.width), (paramRectangle.y + paramRectangle.height) };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  348 */     this.state.getTransformNoClone().transform(arrayOfFloat, 0, arrayOfFloat, 0, 4);
/*  349 */     float f1 = Math.min(arrayOfFloat[0], 
/*  350 */         Math.min(arrayOfFloat[2], 
/*  351 */           Math.min(arrayOfFloat[4], arrayOfFloat[6])));
/*      */     
/*  353 */     float f2 = Math.max(arrayOfFloat[0], 
/*  354 */         Math.max(arrayOfFloat[2], 
/*  355 */           Math.max(arrayOfFloat[4], arrayOfFloat[6])));
/*      */     
/*  357 */     float f3 = Math.min(arrayOfFloat[1], 
/*  358 */         Math.min(arrayOfFloat[3], 
/*  359 */           Math.min(arrayOfFloat[5], arrayOfFloat[7])));
/*      */     
/*  361 */     float f4 = Math.max(arrayOfFloat[1], 
/*  362 */         Math.max(arrayOfFloat[3], 
/*  363 */           Math.max(arrayOfFloat[5], arrayOfFloat[7])));
/*      */     
/*  365 */     return new Rectangle(new RectBounds(f1, f3, f2, f4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setClip(Rectangle paramRectangle) {
/*  381 */     Affine3D affine3D = this.state.getTransformNoClone();
/*  382 */     if (affine3D.getMxy() == 0.0D && affine3D.getMxz() == 0.0D && affine3D
/*  383 */       .getMyx() == 0.0D && affine3D.getMyz() == 0.0D && affine3D
/*  384 */       .getMzx() == 0.0D && affine3D.getMzy() == 0.0D) {
/*      */ 
/*      */       
/*  387 */       this.state.clip(transformClip(paramRectangle));
/*  388 */       if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  389 */         log.fine("setClip({0})", new Object[] { paramRectangle });
/*      */       }
/*  391 */       if (DEBUG_DRAW_CLIP_SHAPE) {
/*      */         
/*  393 */         Rectangle rectangle = this.state.getClipNoClone();
/*  394 */         if (rectangle != null && rectangle.width >= 2 && rectangle.height >= 2) {
/*  395 */           WCTransform wCTransform = getTransform();
/*      */           
/*  397 */           setTransform(new WCTransform(1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  402 */           Graphics graphics = getGraphics(true);
/*  403 */           if (graphics != null) {
/*  404 */             float f = (float)Math.random();
/*  405 */             graphics.setPaint(new Color(f, 1.0F - f, 0.5F, 0.1F));
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  410 */             graphics.setStroke(new BasicStroke());
/*  411 */             graphics.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */             
/*  413 */             graphics.setPaint(new Color(1.0F - f, f, 0.5F, 1.0F));
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  418 */             graphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */           } 
/*      */           
/*  421 */           setTransform(wCTransform);
/*  422 */           this.state.clip(new Rectangle(rectangle.x + 1, rectangle.y + 1, rectangle.width - 2, rectangle.height - 2));
/*      */         } 
/*      */       } 
/*  425 */       if (this.cachedGraphics != null) {
/*  426 */         this.cachedGraphics.setClipRect(this.state.getClipNoClone());
/*      */       }
/*      */     } else {
/*      */       
/*  430 */       WCPathImpl wCPathImpl = new WCPathImpl();
/*  431 */       wCPathImpl.addRect(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*  432 */       setClip(wCPathImpl, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  437 */     setClip(new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4));
/*      */   }
/*      */   
/*      */   public void setClip(WCRectangle paramWCRectangle) {
/*  441 */     setClip(new Rectangle((int)paramWCRectangle.getX(), (int)paramWCRectangle.getY(), 
/*  442 */           (int)paramWCRectangle.getWidth(), (int)paramWCRectangle.getHeight()));
/*      */   }
/*      */   
/*      */   public WCRectangle getClip() {
/*  446 */     Rectangle rectangle = this.state.getClipNoClone();
/*  447 */     return (rectangle == null) ? null : new WCRectangle(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */   }
/*      */   
/*      */   protected Rectangle getClipRectNoClone() {
/*  451 */     return this.state.getClipNoClone();
/*      */   }
/*      */   
/*      */   protected Affine3D getTransformNoClone() {
/*  455 */     return this.state.getTransformNoClone();
/*      */   }
/*      */   
/*      */   public void translate(float paramFloat1, float paramFloat2) {
/*  459 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  460 */       log.fine("translate({0},{1})", new Object[] { Float.valueOf(paramFloat1), Float.valueOf(paramFloat2) });
/*      */     }
/*  462 */     this.state.translate(paramFloat1, paramFloat2);
/*  463 */     if (this.cachedGraphics != null) {
/*  464 */       this.cachedGraphics.translate(paramFloat1, paramFloat2);
/*      */     }
/*      */   }
/*      */   
/*      */   public void scale(float paramFloat1, float paramFloat2) {
/*  469 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  470 */       log.fine("scale(" + paramFloat1 + " " + paramFloat2 + ")");
/*      */     }
/*  472 */     this.state.scale(paramFloat1, paramFloat2);
/*  473 */     if (this.cachedGraphics != null) {
/*  474 */       this.cachedGraphics.scale(paramFloat1, paramFloat2);
/*      */     }
/*      */   }
/*      */   
/*      */   public void rotate(float paramFloat) {
/*  479 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  480 */       log.fine("rotate(" + paramFloat + ")");
/*      */     }
/*  482 */     this.state.rotate(paramFloat);
/*  483 */     if (this.cachedGraphics != null) {
/*  484 */       this.cachedGraphics.setTransform(this.state.getTransformNoClone());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean shouldRenderRect(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, DropShadow paramDropShadow, BasicStroke paramBasicStroke) {
/*  492 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean shouldRenderShape(Shape paramShape, DropShadow paramDropShadow, BasicStroke paramBasicStroke) {
/*  497 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean shouldCalculateIntersection() {
/*  502 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void fillRect(final float x, final float y, final float w, final float h, final Integer rgba) {
/*  507 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*      */ 
/*      */       
/*  510 */       String str = (rgba != null) ? "fillRect(%f, %f, %f, %f, 0x%x)" : "fillRect(%f, %f, %f, %f, null)";
/*  511 */       log.fine(String.format(str, new Object[] { Float.valueOf(x), Float.valueOf(y), Float.valueOf(w), Float.valueOf(h), rgba }));
/*      */     } 
/*  513 */     if (!shouldRenderRect(x, y, w, h, this.state.getShadowNoClone(), null)) {
/*      */       return;
/*      */     }
/*  516 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  518 */           Paint paint = (rgba != null) ? WCGraphicsPrismContext.createColor(rgba.intValue()) : WCGraphicsPrismContext.this.state.getPaintNoClone();
/*  519 */           DropShadow dropShadow = WCGraphicsPrismContext.this.state.getShadowNoClone();
/*      */ 
/*      */           
/*  522 */           if (dropShadow != null || !WCGraphicsPrismContext.this.state.getPerspectiveTransformNoClone().isIdentity()) {
/*  523 */             NGRectangle nGRectangle = new NGRectangle();
/*  524 */             nGRectangle.updateRectangle(x, y, w, h, 0.0F, 0.0F);
/*  525 */             WCGraphicsPrismContext.this.render(param1Graphics, dropShadow, paint, null, nGRectangle);
/*      */           } else {
/*  527 */             param1Graphics.setPaint(paint);
/*  528 */             param1Graphics.fillRect(x, y, w, h);
/*      */           } 
/*      */         }
/*  531 */       }).paint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fillRoundedRect(final float x, final float y, final float w, final float h, final float topLeftW, final float topLeftH, final float topRightW, final float topRightH, final float bottomLeftW, final float bottomLeftH, final float bottomRightW, final float bottomRightH, final int rgba) {
/*  540 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  541 */       log.fine(String.format("fillRoundedRect(%f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, 0x%x)", new Object[] {
/*      */               
/*  543 */               Float.valueOf(x), Float.valueOf(y), Float.valueOf(w), Float.valueOf(h), Float.valueOf(topLeftW), Float.valueOf(topLeftH), Float.valueOf(topRightW), Float.valueOf(topRightH), 
/*  544 */               Float.valueOf(bottomLeftW), Float.valueOf(bottomLeftH), Float.valueOf(bottomRightW), Float.valueOf(bottomRightH), Integer.valueOf(rgba)
/*      */             })); 
/*  546 */     if (!shouldRenderRect(x, y, w, h, this.state.getShadowNoClone(), null)) {
/*      */       return;
/*      */     }
/*  549 */     (new Composite()
/*      */       {
/*      */         
/*      */         void doPaint(Graphics param1Graphics)
/*      */         {
/*  554 */           float f1 = (topLeftW + topRightW + bottomLeftW + bottomRightW) / 2.0F;
/*  555 */           float f2 = (topLeftH + topRightH + bottomLeftH + bottomRightH) / 2.0F;
/*      */           
/*  557 */           Color color = WCGraphicsPrismContext.createColor(rgba);
/*  558 */           DropShadow dropShadow = WCGraphicsPrismContext.this.state.getShadowNoClone();
/*  559 */           if (dropShadow != null) {
/*  560 */             NGRectangle nGRectangle = new NGRectangle();
/*  561 */             nGRectangle.updateRectangle(x, y, w, h, f1, f2);
/*  562 */             WCGraphicsPrismContext.this.render(param1Graphics, dropShadow, color, null, nGRectangle);
/*      */           } else {
/*  564 */             param1Graphics.setPaint(color);
/*  565 */             param1Graphics.fillRoundRect(x, y, w, h, f1, f2);
/*      */           } 
/*      */         }
/*  568 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearRect(final float x, final float y, final float w, final float h) {
/*  573 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  574 */       log.fine(String.format("clearRect(%f, %f, %f, %f)", new Object[] { Float.valueOf(x), Float.valueOf(y), Float.valueOf(w), Float.valueOf(h) }));
/*      */     }
/*  576 */     if (shouldCalculateIntersection()) {
/*      */       return;
/*      */     }
/*      */     
/*  580 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  582 */           param1Graphics.clearQuad(x, y, x + w, y + h);
/*      */         }
/*  584 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFillColor(int paramInt) {
/*  589 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  590 */       log.fine(String.format("setFillColor(0x%x)", new Object[] { Integer.valueOf(paramInt) }));
/*      */     }
/*  592 */     this.state.setPaint(createColor(paramInt));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFillGradient(WCGradient<Gradient> paramWCGradient) {
/*  597 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  598 */       log.fine("setFillGradient(" + paramWCGradient + ")");
/*      */     }
/*  600 */     this.state.setPaint(paramWCGradient.getPlatformGradient());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTextMode(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  605 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  606 */       log.fine("setTextMode(fill:" + paramBoolean1 + ",stroke:" + paramBoolean2 + ",clip:" + paramBoolean3 + ")");
/*      */     }
/*  608 */     this.state.setTextMode(paramBoolean1, paramBoolean2, paramBoolean3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFontSmoothingType(int paramInt) {
/*  613 */     this.fontSmoothingType = paramInt;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFontSmoothingType() {
/*  618 */     return this.fontSmoothingType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStrokeStyle(int paramInt) {
/*  623 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  624 */       log.fine("setStrokeStyle({0})", new Object[] { Integer.valueOf(paramInt) });
/*      */     }
/*  626 */     this.state.getStrokeNoClone().setStyle(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStrokeColor(int paramInt) {
/*  631 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  632 */       log.fine(String.format("setStrokeColor(0x%x)", new Object[] { Integer.valueOf(paramInt) }));
/*      */     }
/*  634 */     this.state.getStrokeNoClone().setPaint(createColor(paramInt));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStrokeWidth(float paramFloat) {
/*  639 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  640 */       log.fine("setStrokeWidth({0})", new Object[] { Float.valueOf(paramFloat) });
/*      */     }
/*  642 */     this.state.getStrokeNoClone().setThickness(paramFloat);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStrokeGradient(WCGradient<Gradient> paramWCGradient) {
/*  647 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  648 */       log.fine("setStrokeGradient(" + paramWCGradient + ")");
/*      */     }
/*  650 */     this.state.getStrokeNoClone().setPaint(paramWCGradient.getPlatformGradient());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineDash(float paramFloat, float... paramVarArgs) {
/*  655 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  656 */       StringBuilder stringBuilder = new StringBuilder("[");
/*  657 */       for (byte b = 0; b < paramVarArgs.length; b++) {
/*  658 */         stringBuilder.append(paramVarArgs[b]).append(',');
/*      */       }
/*  660 */       stringBuilder.append(']');
/*  661 */       log.fine("setLineDash({0},{1}", new Object[] { Float.valueOf(paramFloat), stringBuilder });
/*      */     } 
/*  663 */     this.state.getStrokeNoClone().setDashOffset(paramFloat);
/*  664 */     if (paramVarArgs != null) {
/*  665 */       boolean bool = true;
/*  666 */       for (byte b = 0; b < paramVarArgs.length; b++) {
/*  667 */         if (paramVarArgs[b] != 0.0F) {
/*  668 */           bool = false;
/*      */           break;
/*      */         } 
/*      */       } 
/*  672 */       if (bool) {
/*  673 */         paramVarArgs = null;
/*      */       }
/*      */     } 
/*  676 */     this.state.getStrokeNoClone().setDashSizes(paramVarArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineCap(int paramInt) {
/*  681 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  682 */       log.fine("setLineCap(" + paramInt + ")");
/*      */     }
/*  684 */     this.state.getStrokeNoClone().setLineCap(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineJoin(int paramInt) {
/*  689 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  690 */       log.fine("setLineJoin(" + paramInt + ")");
/*      */     }
/*  692 */     this.state.getStrokeNoClone().setLineJoin(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMiterLimit(float paramFloat) {
/*  697 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  698 */       log.fine("setMiterLimit(" + paramFloat + ")");
/*      */     }
/*  700 */     this.state.getStrokeNoClone().setMiterLimit(paramFloat);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShadow(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt) {
/*  705 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  706 */       String str = "setShadow(%f, %f, %f, 0x%x)";
/*  707 */       log.fine(String.format(str, new Object[] { Float.valueOf(paramFloat1), Float.valueOf(paramFloat2), Float.valueOf(paramFloat3), Integer.valueOf(paramInt) }));
/*      */     } 
/*  709 */     this.state.setShadow(createShadow(paramFloat1, paramFloat2, paramFloat3, paramInt));
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawPolygon(final WCPath path, boolean paramBoolean) {
/*  714 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  715 */       log.fine("drawPolygon({0})", new Object[] {
/*  716 */             Boolean.valueOf(paramBoolean)
/*      */           }); 
/*  718 */     if (!shouldRenderShape(((WCPathImpl)path).getPlatformPath(), null, this.state
/*  719 */         .getStrokeNoClone().getPlatformStroke())) {
/*      */       return;
/*      */     }
/*      */     
/*  723 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  725 */           Path2D path2D = path.getPlatformPath();
/*  726 */           param1Graphics.setPaint(WCGraphicsPrismContext.this.state.getPaintNoClone());
/*  727 */           param1Graphics.fill(path2D);
/*  728 */           if (WCGraphicsPrismContext.this.state.getStrokeNoClone().apply(param1Graphics)) {
/*  729 */             param1Graphics.draw(path2D);
/*      */           }
/*      */         }
/*  732 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawLine(final int x0, final int y0, final int x1, final int y1) {
/*  737 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  738 */       log.fine("drawLine({0}, {1}, {2}, {3})", new Object[] {
/*  739 */             Integer.valueOf(x0), Integer.valueOf(y0), Integer.valueOf(x1), Integer.valueOf(y1)
/*      */           }); 
/*  741 */     Line2D line2D = new Line2D(x0, y0, x1, y1);
/*  742 */     if (!shouldRenderShape(line2D, null, this.state.getStrokeNoClone().getPlatformStroke())) {
/*      */       return;
/*      */     }
/*  745 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  747 */           if (WCGraphicsPrismContext.this.state.getStrokeNoClone().apply(param1Graphics)) {
/*  748 */             param1Graphics.drawLine(x0, y0, x1, y1);
/*      */           }
/*      */         }
/*  751 */       }).paint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawPattern(final WCImage texture, final WCRectangle srcRect, final WCTransform patternTransform, final WCPoint phase, final WCRectangle destRect) {
/*  762 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  763 */       log.fine("drawPattern({0}, {1}, {2}, {3})", new Object[] {
/*  764 */             Integer.valueOf(destRect.getIntX()), Integer.valueOf(destRect.getIntY()), 
/*  765 */             Integer.valueOf(destRect.getIntWidth()), 
/*  766 */             Integer.valueOf(destRect.getIntHeight())
/*      */           }); 
/*  768 */     if (!shouldRenderRect(destRect.getX(), destRect.getY(), destRect
/*  769 */         .getWidth(), destRect.getHeight(), null, null)) {
/*      */       return;
/*      */     }
/*      */     
/*  773 */     if (texture != null) {
/*  774 */       (new Composite()
/*      */         {
/*      */           
/*      */           void doPaint(Graphics param1Graphics)
/*      */           {
/*  779 */             float f1 = phase.getX() + srcRect.getX() * (float)patternTransform.getMatrix()[0];
/*      */             
/*  781 */             float f2 = phase.getY() + srcRect.getY() * (float)patternTransform.getMatrix()[3];
/*      */             
/*  783 */             float f3 = srcRect.getWidth() * (float)patternTransform.getMatrix()[0];
/*      */             
/*  785 */             float f4 = srcRect.getHeight() * (float)patternTransform.getMatrix()[3];
/*      */             
/*  787 */             Image image = ((PrismImage)texture).getImage();
/*      */ 
/*      */             
/*  790 */             if (!srcRect.contains(new WCRectangle(0.0F, 0.0F, texture.getWidth(), texture.getHeight())))
/*      */             {
/*  792 */               image = image.createSubImage(srcRect.getIntX(), srcRect
/*  793 */                   .getIntY(), 
/*  794 */                   (int)Math.ceil(srcRect.getWidth()), 
/*  795 */                   (int)Math.ceil(srcRect.getHeight()));
/*      */             }
/*  797 */             param1Graphics.setPaint(new ImagePattern(image, f1, f2, f3, f4, false, false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  803 */             param1Graphics.fillRect(destRect.getX(), destRect.getY(), destRect
/*  804 */                 .getWidth(), destRect.getHeight());
/*      */           }
/*  806 */         }).paint();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawImage(final WCImage img, final float dstx, final float dsty, final float dstw, final float dsth, final float srcx, final float srcy, final float srcw, final float srch) {
/*  815 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  816 */       log.fine("drawImage(img, dst({0},{1},{2},{3}), src({4},{5},{6},{7}))", new Object[] {
/*      */             
/*  818 */             Float.valueOf(dstx), Float.valueOf(dsty), Float.valueOf(dstw), Float.valueOf(dsth), 
/*  819 */             Float.valueOf(srcx), Float.valueOf(srcy), Float.valueOf(srcw), Float.valueOf(srch)
/*      */           }); 
/*  821 */     if (!shouldRenderRect(dstx, dsty, dstw, dsth, this.state.getShadowNoClone(), null)) {
/*      */       return;
/*      */     }
/*  824 */     if (img instanceof PrismImage) {
/*  825 */       (new Composite() {
/*      */           void doPaint(Graphics param1Graphics) {
/*  827 */             PrismImage prismImage = (PrismImage)img;
/*  828 */             DropShadow dropShadow = WCGraphicsPrismContext.this.state.getShadowNoClone();
/*  829 */             if (dropShadow != null) {
/*  830 */               NGImageView nGImageView = new NGImageView();
/*  831 */               nGImageView.setImage(prismImage.getImage());
/*  832 */               nGImageView.setX(dstx);
/*  833 */               nGImageView.setY(dsty);
/*  834 */               nGImageView.setViewport(srcx, srcy, srcw, srch, dstw, dsth);
/*  835 */               nGImageView.setContentBounds(new RectBounds(dstx, dsty, dstx + dstw, dsty + dsth));
/*  836 */               WCGraphicsPrismContext.this.render(param1Graphics, dropShadow, null, null, nGImageView);
/*      */             } else {
/*  838 */               prismImage.draw(param1Graphics, (int)dstx, (int)dsty, (int)(dstx + dstw), (int)(dsty + dsth), (int)srcx, (int)srcy, (int)(srcx + srcw), (int)(srcy + srch));
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  845 */         }).paint();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawBitmapImage(final ByteBuffer image, final int x, final int y, final int w, final int h) {
/*  851 */     if (!shouldRenderRect(x, y, w, h, null, null)) {
/*      */       return;
/*      */     }
/*  854 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  856 */           image.order(ByteOrder.nativeOrder());
/*  857 */           Image image = Image.fromByteBgraPreData(image, w, h);
/*  858 */           ResourceFactory resourceFactory = param1Graphics.getResourceFactory();
/*  859 */           Texture texture = resourceFactory.createTexture(image, Texture.Usage.STATIC, Texture.WrapMode.REPEAT);
/*  860 */           param1Graphics.drawTexture(texture, x, y, (x + w), (y + h), 0.0F, 0.0F, w, h);
/*  861 */           texture.dispose();
/*      */         }
/*  863 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawIcon(WCIcon paramWCIcon, int paramInt1, int paramInt2) {
/*  868 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  869 */       log.fine("UNIMPLEMENTED drawIcon ({0}, {1})", new Object[] {
/*  870 */             Integer.valueOf(paramInt1), Integer.valueOf(paramInt2)
/*      */           });
/*      */     }
/*      */   }
/*      */   
/*      */   public void drawRect(final int x, final int y, final int w, final int h) {
/*  876 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  877 */       log.fine("drawRect({0}, {1}, {2}, {3})", new Object[] {
/*  878 */             Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(w), Integer.valueOf(h)
/*      */           }); 
/*  880 */     if (!shouldRenderRect(x, y, w, h, null, this.state
/*  881 */         .getStrokeNoClone().getPlatformStroke())) {
/*      */       return;
/*      */     }
/*      */     
/*  885 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/*  887 */           Paint paint = WCGraphicsPrismContext.this.state.getPaintNoClone();
/*  888 */           if (paint != null && paint.isOpaque()) {
/*  889 */             param1Graphics.setPaint(paint);
/*  890 */             param1Graphics.fillRect(x, y, w, h);
/*      */           } 
/*      */           
/*  893 */           if (WCGraphicsPrismContext.this.state.getStrokeNoClone().apply(param1Graphics)) {
/*  894 */             param1Graphics.drawRect(x, y, w, h);
/*      */           }
/*      */         }
/*  897 */       }).paint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(WCFont paramWCFont, int[] paramArrayOfint, float[] paramArrayOffloat, final float x, final float y) {
/*  904 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  905 */       log.fine(String.format("Drawing %d glyphs @(%.1f, %.1f)", new Object[] {
/*      */               
/*  907 */               Integer.valueOf(paramArrayOfint.length), Float.valueOf(x), Float.valueOf(y)
/*      */             })); 
/*  909 */     final PGFont font = (PGFont)paramWCFont.getPlatformFont();
/*  910 */     final TextRun gl = TextUtilities.createGlyphList(paramArrayOfint, paramArrayOffloat, x, y);
/*      */     
/*  912 */     final DropShadow shadow = this.state.getShadowNoClone();
/*      */ 
/*      */     
/*  915 */     final BasicStroke stroke = this.state.isTextStroke() ? this.state.getStrokeNoClone().getPlatformStroke() : null;
/*      */     
/*  917 */     final FontStrike strike = pGFont.getStrike(getTransformNoClone(), getFontSmoothingType());
/*  918 */     if (shouldCalculateIntersection()) {
/*  919 */       Metrics metrics = fontStrike.getMetrics();
/*  920 */       textRun.setMetrics(metrics.getAscent(), metrics.getDescent(), metrics.getLineGap());
/*  921 */       if (!shouldRenderRect(x, y, textRun.getWidth(), textRun.getHeight(), dropShadow, basicStroke)) {
/*      */         return;
/*      */       }
/*      */     } 
/*  925 */     (new Composite()
/*      */       {
/*      */         void doPaint(Graphics param1Graphics)
/*      */         {
/*  929 */           Paint paint = WCGraphicsPrismContext.this.state.isTextFill() ? WCGraphicsPrismContext.this.state.getPaintNoClone() : null;
/*  930 */           if (shadow != null) {
/*  931 */             NGText nGText = new NGText();
/*  932 */             nGText.setGlyphs((Object[])new GlyphList[] { this.val$gl });
/*  933 */             nGText.setFont(font);
/*  934 */             nGText.setFontSmoothingType(WCGraphicsPrismContext.this.fontSmoothingType);
/*  935 */             WCGraphicsPrismContext.this.render(param1Graphics, shadow, paint, stroke, nGText);
/*      */           } else {
/*  937 */             if (paint != null) {
/*  938 */               param1Graphics.setPaint(paint);
/*  939 */               param1Graphics.drawString(gl, strike, x, y, null, 0, 0);
/*      */             } 
/*  941 */             if (stroke != null) {
/*  942 */               paint = WCGraphicsPrismContext.this.state.getStrokeNoClone().getPaint();
/*  943 */               if (paint != null) {
/*  944 */                 param1Graphics.setPaint(paint);
/*  945 */                 param1Graphics.setStroke(stroke);
/*  946 */                 param1Graphics.draw(strike.getOutline(gl, BaseTransform.getTranslateInstance(x, y)));
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*  951 */       }).paint();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawString(WCFont paramWCFont, String paramString, boolean paramBoolean, int paramInt1, int paramInt2, float paramFloat1, float paramFloat2) {
/*  957 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  958 */       log.fine(String.format("str='%s' (length=%d), from=%d, to=%d, rtl=%b, @(%.1f, %.1f)", new Object[] { paramString, 
/*      */               
/*  960 */               Integer.valueOf(paramString.length()), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean), Float.valueOf(paramFloat1), Float.valueOf(paramFloat2) }));
/*      */     }
/*  962 */     TextLayout textLayout = TextUtilities.createLayout(paramString
/*  963 */         .substring(paramInt1, paramInt2), paramWCFont.getPlatformFont());
/*  964 */     int i = 0;
/*  965 */     GlyphList[] arrayOfGlyphList = textLayout.getRuns();
/*  966 */     for (GlyphList glyphList : arrayOfGlyphList) {
/*  967 */       i += glyphList.getGlyphCount();
/*      */     }
/*      */     
/*  970 */     int[] arrayOfInt = new int[i];
/*  971 */     float[] arrayOfFloat = new float[i];
/*  972 */     i = 0;
/*  973 */     for (GlyphList glyphList : textLayout.getRuns()) {
/*  974 */       int j = glyphList.getGlyphCount();
/*  975 */       for (byte b = 0; b < j; b++) {
/*  976 */         arrayOfInt[i] = glyphList.getGlyphCode(b);
/*  977 */         arrayOfFloat[i] = glyphList.getPosX(b + 1) - glyphList.getPosX(b);
/*  978 */         i++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  983 */     if (paramBoolean) {
/*  984 */       paramFloat1 += TextUtilities.getLayoutWidth(paramString.substring(paramInt1), paramWCFont.getPlatformFont()) - textLayout
/*  985 */         .getBounds().getWidth();
/*      */     } else {
/*  987 */       paramFloat1 += TextUtilities.getLayoutWidth(paramString.substring(0, paramInt1), paramWCFont.getPlatformFont());
/*      */     } 
/*  989 */     drawString(paramWCFont, arrayOfInt, arrayOfFloat, paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setComposite(int paramInt) {
/*  994 */     log.fine("setComposite({0})", new Object[] { Integer.valueOf(paramInt) });
/*  995 */     this.state.setCompositeOperation(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawEllipse(final int x, final int y, final int w, final int h) {
/* 1000 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 1001 */       log.fine("drawEllipse({0}, {1}, {2}, {3})", new Object[] {
/* 1002 */             Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(w), Integer.valueOf(h)
/*      */           }); 
/* 1004 */     if (!shouldRenderRect(x, y, w, h, null, this.state
/* 1005 */         .getStrokeNoClone().getPlatformStroke())) {
/*      */       return;
/*      */     }
/*      */     
/* 1009 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1011 */           param1Graphics.setPaint(WCGraphicsPrismContext.this.state.getPaintNoClone());
/* 1012 */           param1Graphics.fillEllipse(x, y, w, h);
/* 1013 */           if (WCGraphicsPrismContext.this.state.getStrokeNoClone().apply(param1Graphics)) {
/* 1014 */             param1Graphics.drawEllipse(x, y, w, h);
/*      */           }
/*      */         }
/* 1017 */       }).paint();
/*      */   }
/*      */   
/* 1020 */   private static final BasicStroke focusRingStroke = new BasicStroke(1.1F, 0, 1, 0.0F, new float[] { 1.0F }, 0.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawFocusRing(final int x, final int y, final int w, final int h, final int rgba) {
/* 1027 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1028 */       log.fine(String.format("drawFocusRing: %d, %d, %d, %d, 0x%x", new Object[] { Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(w), Integer.valueOf(h), Integer.valueOf(rgba) }));
/*      */     }
/* 1030 */     if (!shouldRenderRect(x, y, w, h, null, focusRingStroke)) {
/*      */       return;
/*      */     }
/* 1033 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1035 */           param1Graphics.setPaint(WCGraphicsPrismContext.createColor(rgba));
/* 1036 */           BasicStroke basicStroke = param1Graphics.getStroke();
/* 1037 */           param1Graphics.setStroke(WCGraphicsPrismContext.focusRingStroke);
/* 1038 */           param1Graphics.drawRoundRect(x, y, w, h, 4.0F, 4.0F);
/* 1039 */           param1Graphics.setStroke(basicStroke);
/*      */         }
/* 1041 */       }).paint();
/*      */   }
/*      */   
/*      */   public void setAlpha(float paramFloat) {
/* 1045 */     log.fine("setAlpha({0})", new Object[] { Float.valueOf(paramFloat) });
/*      */     
/* 1047 */     this.state.setAlpha(paramFloat);
/*      */     
/* 1049 */     if (null != this.cachedGraphics) {
/* 1050 */       this.cachedGraphics.setExtraAlpha(this.state.getAlpha());
/*      */     }
/*      */   }
/*      */   
/*      */   public float getAlpha() {
/* 1055 */     return this.state.getAlpha();
/*      */   }
/*      */ 
/*      */   
/*      */   public void beginTransparencyLayer(float paramFloat) {
/* 1060 */     TransparencyLayer transparencyLayer = new TransparencyLayer(getGraphics(false), this.state.getClipNoClone(), paramFloat);
/*      */     
/* 1062 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1063 */       log.fine(String.format("beginTransparencyLayer(%s)", new Object[] { transparencyLayer }));
/*      */     }
/*      */ 
/*      */     
/* 1067 */     this.state.markAsRestorePoint();
/*      */     
/* 1069 */     startNewLayer(transparencyLayer);
/*      */   }
/*      */   
/*      */   public void endTransparencyLayer() {
/* 1073 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1074 */       log.fine(String.format("endTransparencyLayer(%s)", new Object[] { ContextState.access$400(this.state) }));
/*      */     }
/*      */ 
/*      */     
/* 1078 */     restoreState();
/*      */   }
/*      */ 
/*      */   
/*      */   public void drawWidget(final RenderTheme theme, final Ref widget, final int x, final int y) {
/* 1083 */     WCSize wCSize = theme.getWidgetSize(widget);
/* 1084 */     if (!shouldRenderRect(x, y, wCSize.getWidth(), wCSize.getHeight(), null, null)) {
/*      */       return;
/*      */     }
/* 1087 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1089 */           theme.drawWidget(WCGraphicsPrismContext.this, widget, x, y);
/*      */         }
/* 1091 */       }).paint();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void drawScrollbar(final ScrollBarTheme theme, final Ref widget, final int x, final int y, final int pressedPart, final int hoveredPart) {
/* 1098 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1099 */       log.fine(String.format("drawScrollbar(%s, %s, x = %d, y = %d)", new Object[] { theme, widget, Integer.valueOf(x), Integer.valueOf(y) }));
/*      */     }
/*      */     
/* 1102 */     WCSize wCSize = theme.getWidgetSize(widget);
/* 1103 */     if (!shouldRenderRect(x, y, wCSize.getWidth(), wCSize.getHeight(), null, null)) {
/*      */       return;
/*      */     }
/* 1106 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1108 */           theme.paint(WCGraphicsPrismContext.this, widget, x, y, pressedPart, hoveredPart);
/*      */         }
/* 1110 */       }).paint();
/*      */   }
/*      */   
/*      */   private static Rectangle intersect(Rectangle paramRectangle1, Rectangle paramRectangle2) {
/* 1114 */     if (paramRectangle1 == null) {
/* 1115 */       return paramRectangle2;
/*      */     }
/* 1117 */     RectBounds rectBounds = paramRectangle1.toRectBounds();
/* 1118 */     rectBounds.intersectWith(paramRectangle2);
/* 1119 */     paramRectangle1.setBounds(rectBounds);
/* 1120 */     return paramRectangle1;
/*      */   }
/*      */   
/*      */   static Color createColor(int paramInt) {
/* 1124 */     float f1 = (0xFF & paramInt >> 24) / 255.0F;
/* 1125 */     float f2 = (0xFF & paramInt >> 16) / 255.0F;
/* 1126 */     float f3 = (0xFF & paramInt >> 8) / 255.0F;
/* 1127 */     float f4 = (0xFF & paramInt) / 255.0F;
/* 1128 */     return new Color(f2, f3, f4, f1);
/*      */   }
/*      */   
/*      */   private static Color4f createColor4f(int paramInt) {
/* 1132 */     float f1 = (0xFF & paramInt >> 24) / 255.0F;
/* 1133 */     float f2 = (0xFF & paramInt >> 16) / 255.0F;
/* 1134 */     float f3 = (0xFF & paramInt >> 8) / 255.0F;
/* 1135 */     float f4 = (0xFF & paramInt) / 255.0F;
/* 1136 */     return new Color4f(f2, f3, f4, f1);
/*      */   }
/*      */   
/*      */   private DropShadow createShadow(float paramFloat1, float paramFloat2, float paramFloat3, int paramInt) {
/* 1140 */     if (paramFloat1 == 0.0F && paramFloat2 == 0.0F && paramFloat3 == 0.0F) {
/* 1141 */       return null;
/*      */     }
/* 1143 */     DropShadow dropShadow = new DropShadow();
/* 1144 */     dropShadow.setOffsetX((int)paramFloat1);
/* 1145 */     dropShadow.setOffsetY((int)paramFloat2);
/* 1146 */     dropShadow.setRadius((paramFloat3 < 0.0F) ? 0.0F : ((paramFloat3 > 127.0F) ? 127.0F : paramFloat3));
/* 1147 */     dropShadow.setColor(createColor4f(paramInt));
/* 1148 */     return dropShadow;
/*      */   }
/*      */   
/*      */   private void render(Graphics paramGraphics, Effect paramEffect, Paint paramPaint, BasicStroke paramBasicStroke, NGNode paramNGNode) {
/* 1152 */     if (paramNGNode instanceof NGShape) {
/* 1153 */       NGShape nGShape = (NGShape)paramNGNode;
/* 1154 */       Shape shape = nGShape.getShape();
/* 1155 */       Paint paint = this.state.getStrokeNoClone().getPaint();
/* 1156 */       if (paramBasicStroke != null && paint != null) {
/* 1157 */         shape = paramBasicStroke.createStrokedShape(shape);
/* 1158 */         nGShape.setDrawStroke(paramBasicStroke);
/* 1159 */         nGShape.setDrawPaint(paint);
/* 1160 */         nGShape.setMode((paramPaint == null) ? NGShape.Mode.STROKE : NGShape.Mode.STROKE_FILL);
/*      */       } else {
/* 1162 */         nGShape.setMode((paramPaint == null) ? NGShape.Mode.EMPTY : NGShape.Mode.FILL);
/*      */       } 
/* 1164 */       nGShape.setFillPaint(paramPaint);
/* 1165 */       nGShape.setContentBounds(shape.getBounds());
/*      */     } 
/* 1167 */     boolean bool = paramGraphics.hasPreCullingBits();
/* 1168 */     paramGraphics.setHasPreCullingBits(false);
/* 1169 */     paramNGNode.setEffect(paramEffect);
/* 1170 */     paramNGNode.render(paramGraphics);
/* 1171 */     paramGraphics.setHasPreCullingBits(bool);
/*      */   }
/*      */   
/*      */   private static final class ContextState {
/* 1175 */     private final WCStrokeImpl stroke = new WCStrokeImpl();
/*      */     
/*      */     private Rectangle clip;
/*      */     
/*      */     private Paint paint;
/*      */     private float alpha;
/*      */     private boolean textFill = true;
/*      */     private boolean textStroke = false;
/*      */     private boolean textClip = false;
/*      */     private boolean restorePoint = false;
/*      */     private DropShadow shadow;
/*      */     private Affine3D xform;
/*      */     private GeneralTransform3D perspectiveTransform;
/*      */     private WCGraphicsPrismContext.Layer layer;
/*      */     private int compositeOperation;
/*      */     
/*      */     private ContextState() {
/* 1192 */       this.clip = null;
/* 1193 */       this.paint = Color.BLACK;
/* 1194 */       this.stroke.setPaint(Color.BLACK);
/* 1195 */       this.alpha = 1.0F;
/* 1196 */       this.xform = new Affine3D();
/* 1197 */       this.perspectiveTransform = new GeneralTransform3D();
/* 1198 */       this.compositeOperation = 2;
/*      */     }
/*      */     
/*      */     private ContextState(ContextState param1ContextState) {
/* 1202 */       this.stroke.copyFrom(param1ContextState.getStrokeNoClone());
/* 1203 */       setPaint(param1ContextState.getPaintNoClone());
/* 1204 */       this.clip = param1ContextState.getClipNoClone();
/* 1205 */       if (this.clip != null) {
/* 1206 */         this.clip = new Rectangle(this.clip);
/*      */       }
/* 1208 */       this.xform = new Affine3D(param1ContextState.getTransformNoClone());
/* 1209 */       this.perspectiveTransform = (new GeneralTransform3D()).set(param1ContextState.getPerspectiveTransformNoClone());
/* 1210 */       setShadow(param1ContextState.getShadowNoClone());
/* 1211 */       setLayer(param1ContextState.getLayerNoClone());
/* 1212 */       setAlpha(param1ContextState.getAlpha());
/* 1213 */       setTextMode(param1ContextState.isTextFill(), param1ContextState.isTextStroke(), param1ContextState.isTextClip());
/* 1214 */       setCompositeOperation(param1ContextState.getCompositeOperation());
/*      */     }
/*      */ 
/*      */     
/*      */     protected ContextState clone() {
/* 1219 */       return new ContextState(this);
/*      */     }
/*      */     
/*      */     private void apply(Graphics param1Graphics) {
/* 1223 */       param1Graphics.setTransform(getTransformNoClone());
/* 1224 */       param1Graphics.setPerspectiveTransform(getPerspectiveTransformNoClone());
/* 1225 */       param1Graphics.setClipRect(getClipNoClone());
/* 1226 */       param1Graphics.setExtraAlpha(getAlpha());
/*      */     }
/*      */     
/*      */     private int getCompositeOperation() {
/* 1230 */       return this.compositeOperation;
/*      */     }
/*      */     
/*      */     private void setCompositeOperation(int param1Int) {
/* 1234 */       this.compositeOperation = param1Int;
/*      */     }
/*      */     
/*      */     private WCStrokeImpl getStrokeNoClone() {
/* 1238 */       return this.stroke;
/*      */     }
/*      */     
/*      */     private Paint getPaintNoClone() {
/* 1242 */       return this.paint;
/*      */     }
/*      */     
/*      */     private void setPaint(Paint param1Paint) {
/* 1246 */       this.paint = param1Paint;
/*      */     }
/*      */     
/*      */     private Rectangle getClipNoClone() {
/* 1250 */       return this.clip;
/*      */     }
/*      */     
/*      */     private WCGraphicsPrismContext.Layer getLayerNoClone() {
/* 1254 */       return this.layer;
/*      */     }
/*      */     
/*      */     private void setLayer(WCGraphicsPrismContext.Layer param1Layer) {
/* 1258 */       this.layer = param1Layer;
/*      */     }
/*      */     
/*      */     private void setClip(Rectangle param1Rectangle) {
/* 1262 */       this.clip = param1Rectangle;
/*      */     }
/*      */     
/*      */     private void clip(Rectangle param1Rectangle) {
/* 1266 */       if (null == this.clip) {
/* 1267 */         this.clip = param1Rectangle;
/*      */       } else {
/* 1269 */         this.clip.intersectWith(param1Rectangle);
/*      */       } 
/*      */     }
/*      */     
/*      */     private void setAlpha(float param1Float) {
/* 1274 */       this.alpha = param1Float;
/*      */     }
/*      */     
/*      */     private float getAlpha() {
/* 1278 */       return this.alpha;
/*      */     }
/*      */     
/*      */     private void setTextMode(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3) {
/* 1282 */       this.textFill = param1Boolean1;
/* 1283 */       this.textStroke = param1Boolean2;
/* 1284 */       this.textClip = param1Boolean3;
/*      */     }
/*      */     
/*      */     private boolean isTextFill() {
/* 1288 */       return this.textFill;
/*      */     }
/*      */     
/*      */     private boolean isTextStroke() {
/* 1292 */       return this.textStroke;
/*      */     }
/*      */     
/*      */     private boolean isTextClip() {
/* 1296 */       return this.textClip;
/*      */     }
/*      */     
/*      */     private void markAsRestorePoint() {
/* 1300 */       this.restorePoint = true;
/*      */     }
/*      */     
/*      */     private boolean isRestorePoint() {
/* 1304 */       return this.restorePoint;
/*      */     }
/*      */     
/*      */     private void setShadow(DropShadow param1DropShadow) {
/* 1308 */       this.shadow = param1DropShadow;
/*      */     }
/*      */     
/*      */     private DropShadow getShadowNoClone() {
/* 1312 */       return this.shadow;
/*      */     }
/*      */     
/*      */     private Affine3D getTransformNoClone() {
/* 1316 */       return this.xform;
/*      */     }
/*      */     
/*      */     private GeneralTransform3D getPerspectiveTransformNoClone() {
/* 1320 */       return this.perspectiveTransform;
/*      */     }
/*      */     
/*      */     private void setTransform(Affine3D param1Affine3D) {
/* 1324 */       this.xform.setTransform(param1Affine3D);
/*      */     }
/*      */     
/*      */     private void setPerspectiveTransform(GeneralTransform3D param1GeneralTransform3D) {
/* 1328 */       this.perspectiveTransform.set(param1GeneralTransform3D);
/*      */     }
/*      */     
/*      */     private void concatTransform(Affine3D param1Affine3D) {
/* 1332 */       this.xform.concatenate(param1Affine3D);
/*      */     }
/*      */     
/*      */     private void translate(double param1Double1, double param1Double2) {
/* 1336 */       this.xform.translate(param1Double1, param1Double2);
/*      */     }
/*      */     
/*      */     private void scale(double param1Double1, double param1Double2) {
/* 1340 */       this.xform.scale(param1Double1, param1Double2);
/*      */     }
/*      */     
/*      */     private void rotate(double param1Double) {
/* 1344 */       this.xform.rotate(param1Double);
/*      */     }
/*      */   }
/*      */   
/*      */   private static abstract class Layer {
/*      */     FilterContext fctx;
/*      */     PrDrawable buffer;
/*      */     Graphics graphics;
/*      */     final Rectangle bounds;
/*      */     boolean permanent;
/*      */     
/*      */     Layer(Graphics param1Graphics, Rectangle param1Rectangle, boolean param1Boolean) {
/* 1356 */       this.bounds = new Rectangle(param1Rectangle);
/* 1357 */       this.permanent = param1Boolean;
/*      */ 
/*      */       
/* 1360 */       int i = Math.max(param1Rectangle.width, 1);
/* 1361 */       int j = Math.max(param1Rectangle.height, 1);
/* 1362 */       this.fctx = WCGraphicsPrismContext.getFilterContext(param1Graphics);
/* 1363 */       if (param1Boolean) {
/* 1364 */         ResourceFactory resourceFactory = GraphicsPipeline.getDefaultResourceFactory();
/* 1365 */         RTTexture rTTexture = resourceFactory.createRTTexture(i, j, Texture.WrapMode.CLAMP_NOT_NEEDED);
/* 1366 */         rTTexture.makePermanent();
/* 1367 */         this.buffer = ((PrRenderer)Renderer.getRenderer(this.fctx)).createDrawable(rTTexture);
/*      */       } else {
/* 1369 */         this.buffer = (PrDrawable)Effect.getCompatibleImage(this.fctx, i, j);
/*      */       } 
/*      */     }
/*      */     
/*      */     Graphics getGraphics() {
/* 1374 */       if (this.graphics == null) {
/* 1375 */         this.graphics = this.buffer.createGraphics();
/*      */       }
/* 1377 */       return this.graphics;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void dispose() {
/* 1385 */       if (this.buffer != null) {
/* 1386 */         if (this.permanent) {
/* 1387 */           this.buffer.flush();
/*      */         } else {
/* 1389 */           Effect.releaseCompatibleImage(this.fctx, this.buffer);
/*      */         } 
/* 1391 */         this.fctx = null;
/* 1392 */         this.buffer = null;
/*      */       } 
/*      */     }
/*      */     
/* 1396 */     private double getX() { return this.bounds.x; } private double getY() {
/* 1397 */       return this.bounds.y;
/*      */     }
/*      */     abstract void init(Graphics param1Graphics);
/*      */     
/*      */     abstract void render(Graphics param1Graphics); }
/*      */   
/*      */   private final class TransparencyLayer extends Layer { private TransparencyLayer(Graphics param1Graphics, Rectangle param1Rectangle, float param1Float) {
/* 1404 */       super(param1Graphics, param1Rectangle, false);
/* 1405 */       this.opacity = param1Float;
/*      */     }
/*      */     private final float opacity;
/*      */     void init(Graphics param1Graphics) {
/* 1409 */       WCGraphicsPrismContext.this.state.setCompositeOperation(2);
/*      */     }
/*      */     
/*      */     void render(Graphics param1Graphics) {
/* 1413 */       (new WCGraphicsPrismContext.Composite() {
/*      */           void doPaint(Graphics param2Graphics) {
/* 1415 */             float f = param2Graphics.getExtraAlpha();
/* 1416 */             param2Graphics.setExtraAlpha(WCGraphicsPrismContext.TransparencyLayer.this.opacity);
/* 1417 */             Affine3D affine3D = new Affine3D(param2Graphics.getTransformNoClone());
/* 1418 */             param2Graphics.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/* 1419 */             param2Graphics.drawTexture(WCGraphicsPrismContext.TransparencyLayer.this.buffer.getTextureObject(), WCGraphicsPrismContext.TransparencyLayer.this.bounds.x, WCGraphicsPrismContext.TransparencyLayer.this.bounds.y, WCGraphicsPrismContext.TransparencyLayer.this.bounds.width, WCGraphicsPrismContext.TransparencyLayer.this.bounds.height);
/*      */             
/* 1421 */             param2Graphics.setTransform(affine3D);
/* 1422 */             param2Graphics.setExtraAlpha(f);
/*      */           }
/* 1424 */         }).paint(param1Graphics);
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1428 */       return String.format("TransparencyLayer[%d,%d + %dx%d, opacity %.2f]", new Object[] {
/* 1429 */             Integer.valueOf(this.bounds.x), Integer.valueOf(this.bounds.y), Integer.valueOf(this.bounds.width), Integer.valueOf(this.bounds.height), Float.valueOf(this.opacity)
/*      */           });
/*      */     } }
/*      */ 
/*      */   
/*      */   private static final class ClipLayer
/*      */     extends Layer {
/*      */     private final WCPath normalizedToClipPath;
/*      */     private boolean srcover;
/*      */     
/*      */     private ClipLayer(Graphics param1Graphics, Rectangle param1Rectangle, WCPath param1WCPath, boolean param1Boolean) {
/* 1440 */       super(param1Graphics, param1Rectangle, param1Boolean);
/* 1441 */       this.normalizedToClipPath = param1WCPath;
/* 1442 */       this.srcover = true;
/*      */     }
/*      */     
/*      */     void init(Graphics param1Graphics) {
/* 1446 */       RTTexture rTTexture = null;
/* 1447 */       ReadbackGraphics readbackGraphics = null;
/*      */       try {
/* 1449 */         readbackGraphics = (ReadbackGraphics)param1Graphics;
/* 1450 */         rTTexture = readbackGraphics.readBack(this.bounds);
/* 1451 */         getGraphics().drawTexture(rTTexture, 0.0F, 0.0F, this.bounds.width, this.bounds.height);
/*      */       } finally {
/* 1453 */         if (readbackGraphics != null && rTTexture != null) {
/* 1454 */           readbackGraphics.releaseReadBackBuffer(rTTexture);
/*      */         }
/*      */       } 
/* 1457 */       this.srcover = false;
/*      */     }
/*      */     
/*      */     void render(Graphics param1Graphics) {
/* 1461 */       Path2D path2D = ((WCPathImpl)this.normalizedToClipPath).getPlatformPath();
/*      */ 
/*      */       
/* 1464 */       PrDrawable prDrawable = (PrDrawable)Effect.getCompatibleImage(this.fctx, this.bounds.width, this.bounds.height);
/*      */       
/* 1466 */       Graphics graphics = prDrawable.createGraphics();
/*      */       
/* 1468 */       graphics.setPaint(Color.BLACK);
/* 1469 */       graphics.fill(path2D);
/*      */ 
/*      */       
/* 1472 */       if (param1Graphics instanceof MaskTextureGraphics && !(param1Graphics instanceof com.sun.prism.PrinterGraphics)) {
/* 1473 */         MaskTextureGraphics maskTextureGraphics = (MaskTextureGraphics)param1Graphics;
/* 1474 */         if (this.srcover) {
/* 1475 */           maskTextureGraphics.drawPixelsMasked(this.buffer.getTextureObject(), prDrawable
/* 1476 */               .getTextureObject(), this.bounds.x, this.bounds.y, this.bounds.width, this.bounds.height, 0, 0, 0, 0);
/*      */         }
/*      */         else {
/*      */           
/* 1480 */           maskTextureGraphics.maskInterpolatePixels(this.buffer.getTextureObject(), prDrawable
/* 1481 */               .getTextureObject(), this.bounds.x, this.bounds.y, this.bounds.width, this.bounds.height, 0, 0, 0, 0);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1486 */         Blend blend = new Blend(Blend.Mode.SRC_IN, new WCGraphicsPrismContext.PassThrough(prDrawable, this.bounds.width, this.bounds.height), new WCGraphicsPrismContext.PassThrough(this.buffer, this.bounds.width, this.bounds.height));
/*      */ 
/*      */         
/* 1489 */         Affine3D affine3D = new Affine3D(param1Graphics.getTransformNoClone());
/* 1490 */         param1Graphics.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/* 1491 */         PrEffectHelper.render(blend, param1Graphics, this.bounds.x, this.bounds.y, null);
/* 1492 */         param1Graphics.setTransform(affine3D);
/*      */       } 
/*      */       
/* 1495 */       Effect.releaseCompatibleImage(this.fctx, prDrawable);
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1499 */       return String.format("ClipLayer[%d,%d + %dx%d, path %s]", new Object[] {
/* 1500 */             Integer.valueOf(this.bounds.x), Integer.valueOf(this.bounds.y), Integer.valueOf(this.bounds.width), Integer.valueOf(this.bounds.height), this.normalizedToClipPath
/*      */           });
/*      */     }
/*      */   }
/*      */   
/*      */   private abstract class Composite {
/*      */     private Composite() {}
/*      */     
/*      */     void paint() {
/* 1509 */       paint(WCGraphicsPrismContext.this.getGraphics(true));
/*      */     }
/*      */     
/*      */     void paint(Graphics param1Graphics) {
/* 1513 */       if (param1Graphics != null) {
/* 1514 */         CompositeMode compositeMode = param1Graphics.getCompositeMode();
/* 1515 */         switch (WCGraphicsPrismContext.this.state.getCompositeOperation()) {
/*      */           
/*      */           case 1:
/* 1518 */             param1Graphics.setCompositeMode(CompositeMode.SRC);
/* 1519 */             doPaint(param1Graphics);
/* 1520 */             param1Graphics.setCompositeMode(compositeMode);
/*      */             break;
/*      */           case 2:
/* 1523 */             param1Graphics.setCompositeMode(CompositeMode.SRC_OVER);
/* 1524 */             doPaint(param1Graphics);
/* 1525 */             param1Graphics.setCompositeMode(compositeMode);
/*      */             break;
/*      */           
/*      */           default:
/* 1529 */             blend(param1Graphics);
/*      */             break;
/*      */         } 
/* 1532 */         WCGraphicsPrismContext.this.isRootLayerValid = false;
/*      */       } 
/*      */     }
/*      */     
/*      */     private void blend(Graphics param1Graphics) {
/* 1537 */       FilterContext filterContext = WCGraphicsPrismContext.getFilterContext(param1Graphics);
/* 1538 */       PrDrawable prDrawable1 = null;
/* 1539 */       PrDrawable prDrawable2 = null;
/* 1540 */       ReadbackGraphics readbackGraphics = null;
/* 1541 */       RTTexture rTTexture = null;
/* 1542 */       Rectangle rectangle = WCGraphicsPrismContext.this.state.getClipNoClone();
/* 1543 */       WCImage wCImage = WCGraphicsPrismContext.this.getImage();
/*      */       try {
/* 1545 */         if (wCImage != null && wCImage instanceof PrismImage) {
/*      */           
/* 1547 */           prDrawable1 = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 1548 */           Graphics graphics1 = prDrawable1.createGraphics();
/* 1549 */           ((PrismImage)wCImage).draw(graphics1, 0, 0, rectangle.width, rectangle.height, rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1554 */           readbackGraphics = (ReadbackGraphics)param1Graphics;
/* 1555 */           rTTexture = readbackGraphics.readBack(rectangle);
/* 1556 */           prDrawable1 = PrDrawable.create(filterContext, rTTexture);
/*      */         } 
/*      */         
/* 1559 */         prDrawable2 = (PrDrawable)Effect.getCompatibleImage(filterContext, rectangle.width, rectangle.height);
/* 1560 */         Graphics graphics = prDrawable2.createGraphics();
/* 1561 */         WCGraphicsPrismContext.this.state.apply(graphics);
/* 1562 */         doPaint(graphics);
/*      */         
/* 1564 */         param1Graphics.clear();
/* 1565 */         PrEffectHelper.render(createEffect(prDrawable1, prDrawable2, rectangle.width, rectangle.height), param1Graphics, 0.0F, 0.0F, null);
/*      */       } finally {
/*      */         
/* 1568 */         if (prDrawable2 != null) {
/* 1569 */           Effect.releaseCompatibleImage(filterContext, prDrawable2);
/*      */         }
/* 1571 */         if (prDrawable1 != null) {
/* 1572 */           if (readbackGraphics != null && rTTexture != null) {
/* 1573 */             readbackGraphics.releaseReadBackBuffer(rTTexture);
/*      */           } else {
/* 1575 */             Effect.releaseCompatibleImage(filterContext, prDrawable1);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Effect createBlend(Blend.Mode param1Mode, PrDrawable param1PrDrawable1, PrDrawable param1PrDrawable2, int param1Int1, int param1Int2) {
/* 1588 */       return new Blend(param1Mode, new WCGraphicsPrismContext.PassThrough(param1PrDrawable1, param1Int1, param1Int2), new WCGraphicsPrismContext.PassThrough(param1PrDrawable2, param1Int1, param1Int2));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Effect createEffect(PrDrawable param1PrDrawable1, PrDrawable param1PrDrawable2, int param1Int1, int param1Int2) {
/* 1599 */       switch (WCGraphicsPrismContext.this.state.getCompositeOperation()) {
/*      */         case 0:
/*      */         case 10:
/* 1602 */           return new Blend(Blend.Mode.SRC_OVER, 
/*      */               
/* 1604 */               createBlend(Blend.Mode.SRC_OUT, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2), 
/* 1605 */               createBlend(Blend.Mode.SRC_OUT, param1PrDrawable2, param1PrDrawable1, param1Int1, param1Int2));
/*      */         
/*      */         case 3:
/* 1608 */           return createBlend(Blend.Mode.SRC_IN, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2);
/*      */         case 4:
/* 1610 */           return createBlend(Blend.Mode.SRC_OUT, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2);
/*      */         case 5:
/* 1612 */           return createBlend(Blend.Mode.SRC_ATOP, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2);
/*      */         case 6:
/* 1614 */           return createBlend(Blend.Mode.SRC_OVER, param1PrDrawable2, param1PrDrawable1, param1Int1, param1Int2);
/*      */         case 7:
/* 1616 */           return createBlend(Blend.Mode.SRC_IN, param1PrDrawable2, param1PrDrawable1, param1Int1, param1Int2);
/*      */         case 8:
/* 1618 */           return createBlend(Blend.Mode.SRC_OUT, param1PrDrawable2, param1PrDrawable1, param1Int1, param1Int2);
/*      */         case 9:
/* 1620 */           return createBlend(Blend.Mode.SRC_ATOP, param1PrDrawable2, param1PrDrawable1, param1Int1, param1Int2);
/*      */         case 12:
/* 1622 */           return createBlend(Blend.Mode.ADD, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2);
/*      */       } 
/* 1624 */       return createBlend(Blend.Mode.SRC_OVER, param1PrDrawable1, param1PrDrawable2, param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     abstract void doPaint(Graphics param1Graphics); }
/*      */   
/*      */   private static final class PassThrough extends Effect {
/*      */     private final PrDrawable img;
/*      */     private final int width;
/*      */     private final int height;
/*      */     
/*      */     private PassThrough(PrDrawable param1PrDrawable, int param1Int1, int param1Int2) {
/* 1635 */       this.img = param1PrDrawable;
/* 1636 */       this.width = param1Int1;
/* 1637 */       this.height = param1Int2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageData filter(FilterContext param1FilterContext, BaseTransform param1BaseTransform, Rectangle param1Rectangle, Object param1Object, Effect param1Effect) {
/* 1648 */       this.img.lock();
/*      */ 
/*      */       
/* 1651 */       ImageData imageData = new ImageData(param1FilterContext, this.img, new Rectangle((int)param1BaseTransform.getMxt(), (int)param1BaseTransform.getMyt(), this.width, this.height));
/*      */       
/* 1653 */       imageData.setReusable(true);
/* 1654 */       return imageData;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public RectBounds getBounds(BaseTransform param1BaseTransform, Effect param1Effect) {
/* 1660 */       return null;
/*      */     }
/*      */     
/*      */     public Effect.AccelType getAccelType(FilterContext param1FilterContext) {
/* 1664 */       return Effect.AccelType.INTRINSIC;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean reducesOpaquePixels() {
/* 1669 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public DirtyRegionContainer getDirtyRegions(Effect param1Effect, DirtyRegionPool param1DirtyRegionPool) {
/* 1674 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   private static FilterContext getFilterContext(Graphics paramGraphics) {
/* 1679 */     Screen screen = paramGraphics.getAssociatedScreen();
/* 1680 */     if (screen == null) {
/* 1681 */       ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/* 1682 */       return PrFilterContext.getPrinterContext(resourceFactory);
/*      */     } 
/* 1684 */     return PrFilterContext.getInstance(screen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void strokeArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 1692 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 1693 */       log.fine(String.format("strokeArc(%d, %d, %d, %d, %d, %d)", new Object[] {
/* 1694 */               Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4), Integer.valueOf(paramInt5), Integer.valueOf(paramInt6)
/*      */             })); 
/* 1696 */     final Arc2D arc = new Arc2D(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, 0);
/* 1697 */     if (this.state.getStrokeNoClone().isApplicable() && 
/* 1698 */       !shouldRenderShape(arc2D, null, this.state.getStrokeNoClone().getPlatformStroke())) {
/*      */       return;
/*      */     }
/*      */     
/* 1702 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1704 */           if (WCGraphicsPrismContext.this.state.getStrokeNoClone().apply(param1Graphics)) {
/* 1705 */             param1Graphics.draw(arc);
/*      */           }
/*      */         }
/* 1708 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public WCImage getImage() {
/* 1713 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void strokeRect(final float x, final float y, final float w, final float h, float paramFloat5) {
/* 1719 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 1720 */       log.fine(String.format("strokeRect_FFFFF(%f, %f, %f, %f, %f)", new Object[] {
/* 1721 */               Float.valueOf(x), Float.valueOf(y), Float.valueOf(w), Float.valueOf(h), Float.valueOf(paramFloat5)
/*      */             }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1729 */     final BasicStroke stroke = new BasicStroke(paramFloat5, 0, 0, Math.max(1.0F, paramFloat5), this.state.getStrokeNoClone().getDashSizes(), this.state.getStrokeNoClone().getDashOffset());
/*      */     
/* 1731 */     if (!shouldRenderRect(x, y, w, h, null, basicStroke)) {
/*      */       return;
/*      */     }
/* 1734 */     (new Composite() {
/*      */         void doPaint(Graphics param1Graphics) {
/* 1736 */           param1Graphics.setStroke(stroke);
/* 1737 */           Paint paint = WCGraphicsPrismContext.this.state.getStrokeNoClone().getPaint();
/* 1738 */           if (paint == null) {
/* 1739 */             paint = WCGraphicsPrismContext.this.state.getPaintNoClone();
/*      */           }
/* 1741 */           param1Graphics.setPaint(paint);
/* 1742 */           param1Graphics.drawRect(x, y, w, h);
/*      */         }
/* 1744 */       }).paint();
/*      */   }
/*      */ 
/*      */   
/*      */   public void strokePath(WCPath<Path2D> paramWCPath) {
/* 1749 */     log.fine("strokePath");
/* 1750 */     if (paramWCPath != null) {
/* 1751 */       final BasicStroke stroke = this.state.getStrokeNoClone().getPlatformStroke();
/* 1752 */       final DropShadow shadow = this.state.getShadowNoClone();
/* 1753 */       final Path2D p2d = paramWCPath.getPlatformPath();
/*      */       
/* 1755 */       if ((basicStroke == null && dropShadow == null) || 
/* 1756 */         !shouldRenderShape(path2D, dropShadow, basicStroke)) {
/*      */         return;
/*      */       }
/*      */       
/* 1760 */       (new Composite() {
/*      */           void doPaint(Graphics param1Graphics) {
/* 1762 */             if (shadow != null) {
/* 1763 */               NGPath nGPath = new NGPath();
/* 1764 */               nGPath.updateWithPath2d(p2d);
/* 1765 */               WCGraphicsPrismContext.this.render(param1Graphics, shadow, null, stroke, nGPath);
/* 1766 */             } else if (stroke != null) {
/* 1767 */               Paint paint = WCGraphicsPrismContext.this.state.getStrokeNoClone().getPaint();
/* 1768 */               if (paint == null) {
/* 1769 */                 paint = WCGraphicsPrismContext.this.state.getPaintNoClone();
/*      */               }
/* 1771 */               param1Graphics.setPaint(paint);
/* 1772 */               param1Graphics.setStroke(stroke);
/* 1773 */               param1Graphics.draw(p2d);
/*      */             } 
/*      */           }
/* 1776 */         }).paint();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void fillPath(final WCPath path) {
/* 1782 */     log.fine("fillPath");
/* 1783 */     if (path != null) {
/* 1784 */       if (!shouldRenderShape(((WCPathImpl)path).getPlatformPath(), this.state
/* 1785 */           .getShadowNoClone(), null)) {
/*      */         return;
/*      */       }
/*      */       
/* 1789 */       (new Composite() {
/*      */           void doPaint(Graphics param1Graphics) {
/* 1791 */             Path2D path2D = path.getPlatformPath();
/* 1792 */             Paint paint = WCGraphicsPrismContext.this.state.getPaintNoClone();
/* 1793 */             DropShadow dropShadow = WCGraphicsPrismContext.this.state.getShadowNoClone();
/* 1794 */             if (dropShadow != null) {
/* 1795 */               NGPath nGPath = new NGPath();
/* 1796 */               nGPath.updateWithPath2d(path2D);
/* 1797 */               WCGraphicsPrismContext.this.render(param1Graphics, dropShadow, paint, null, nGPath);
/*      */             } else {
/* 1799 */               param1Graphics.setPaint(paint);
/* 1800 */               param1Graphics.fill(path2D);
/*      */             } 
/*      */           }
/* 1803 */         }).paint();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setPerspectiveTransform(WCTransform paramWCTransform) {
/* 1808 */     GeneralTransform3D generalTransform3D = (new GeneralTransform3D()).set(paramWCTransform.getMatrix());
/* 1809 */     this.state.setPerspectiveTransform(generalTransform3D);
/* 1810 */     resetCachedGraphics();
/*      */   }
/*      */   
/*      */   public void setTransform(WCTransform paramWCTransform) {
/* 1814 */     double[] arrayOfDouble = paramWCTransform.getMatrix();
/* 1815 */     Affine3D affine3D = new Affine3D(new Affine2D(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5]));
/* 1816 */     if (this.state.getLayerNoClone() == null) {
/* 1817 */       affine3D.preConcatenate(this.baseTransform);
/*      */     }
/* 1819 */     this.state.setTransform(affine3D);
/* 1820 */     resetCachedGraphics();
/*      */   }
/*      */   
/*      */   public WCTransform getTransform() {
/* 1824 */     Affine3D affine3D = this.state.getTransformNoClone();
/* 1825 */     return new WCTransform(affine3D.getMxx(), affine3D.getMyx(), affine3D
/* 1826 */         .getMxy(), affine3D.getMyy(), affine3D
/* 1827 */         .getMxt(), affine3D.getMyt());
/*      */   }
/*      */   
/*      */   public void concatTransform(WCTransform paramWCTransform) {
/* 1831 */     double[] arrayOfDouble = paramWCTransform.getMatrix();
/* 1832 */     Affine3D affine3D = new Affine3D(new Affine2D(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5]));
/* 1833 */     this.state.concatTransform(affine3D);
/* 1834 */     resetCachedGraphics();
/*      */   }
/*      */ 
/*      */   
/*      */   public void flush() {
/* 1839 */     flushAllLayers();
/*      */   }
/*      */ 
/*      */   
/*      */   public WCGradient createLinearGradient(WCPoint paramWCPoint1, WCPoint paramWCPoint2) {
/* 1844 */     return new WCLinearGradient(paramWCPoint1, paramWCPoint2);
/*      */   }
/*      */ 
/*      */   
/*      */   public WCGradient createRadialGradient(WCPoint paramWCPoint1, float paramFloat1, WCPoint paramWCPoint2, float paramFloat2) {
/* 1849 */     return new WCRadialGradient(paramWCPoint1, paramFloat1, paramWCPoint2, paramFloat2);
/*      */   }
/*      */   
/*      */   WCGraphicsPrismContext() {}
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCGraphicsPrismContext.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */