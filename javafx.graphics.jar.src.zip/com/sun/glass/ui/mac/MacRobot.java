/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.GlassRobot;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacRobot
/*     */   extends GlassRobot
/*     */ {
/*     */   private long ptr;
/*     */   
/*     */   private native long _init();
/*     */   
/*     */   public void create() {
/*  47 */     Application.checkEventThread();
/*  48 */     this.ptr = _init();
/*     */   }
/*     */   
/*     */   private native void _destroy(long paramLong);
/*     */   
/*     */   public void destroy() {
/*  54 */     Application.checkEventThread();
/*  55 */     if (this.ptr == 0L) {
/*     */       return;
/*     */     }
/*  58 */     _destroy(this.ptr);
/*     */   }
/*     */   
/*     */   protected native void _keyPress(int paramInt);
/*     */   
/*     */   public void keyPress(KeyCode paramKeyCode) {
/*  64 */     Application.checkEventThread();
/*  65 */     _keyPress(paramKeyCode.getCode());
/*     */   }
/*     */   
/*     */   protected native void _keyRelease(int paramInt);
/*     */   
/*     */   public void keyRelease(KeyCode paramKeyCode) {
/*  71 */     Application.checkEventThread();
/*  72 */     _keyRelease(paramKeyCode.getCode());
/*     */   }
/*     */   
/*     */   private native void _mouseMove(long paramLong, float paramFloat1, float paramFloat2);
/*     */   
/*     */   public void mouseMove(double paramDouble1, double paramDouble2) {
/*  78 */     Application.checkEventThread();
/*  79 */     if (this.ptr == 0L) {
/*     */       return;
/*     */     }
/*  82 */     _mouseMove(this.ptr, (float)paramDouble1, (float)paramDouble2);
/*     */   }
/*     */   
/*     */   private native void _mousePress(long paramLong, int paramInt);
/*     */   
/*     */   public void mousePress(MouseButton... paramVarArgs) {
/*  88 */     Application.checkEventThread();
/*  89 */     if (this.ptr == 0L) {
/*     */       return;
/*     */     }
/*  92 */     _mousePress(this.ptr, GlassRobot.convertToRobotMouseButton(paramVarArgs));
/*     */   }
/*     */   
/*     */   private native void _mouseRelease(long paramLong, int paramInt);
/*     */   
/*     */   public void mouseRelease(MouseButton... paramVarArgs) {
/*  98 */     Application.checkEventThread();
/*  99 */     if (this.ptr == 0L) {
/*     */       return;
/*     */     }
/* 102 */     _mouseRelease(this.ptr, GlassRobot.convertToRobotMouseButton(paramVarArgs));
/*     */   }
/*     */   
/*     */   protected native void _mouseWheel(int paramInt);
/*     */   
/*     */   public void mouseWheel(int paramInt) {
/* 108 */     Application.checkEventThread();
/* 109 */     _mouseWheel(paramInt);
/*     */   }
/*     */   
/*     */   private native float _getMouseX(long paramLong);
/*     */   
/*     */   public double getMouseX() {
/* 115 */     Application.checkEventThread();
/* 116 */     if (this.ptr == 0L) {
/* 117 */       return 0.0D;
/*     */     }
/* 119 */     return _getMouseX(this.ptr);
/*     */   }
/*     */   
/*     */   private native float _getMouseY(long paramLong);
/*     */   
/*     */   public double getMouseY() {
/* 125 */     Application.checkEventThread();
/* 126 */     if (this.ptr == 0L) {
/* 127 */       return 0.0D;
/*     */     }
/* 129 */     return _getMouseY(this.ptr);
/*     */   }
/*     */   
/*     */   protected native int _getPixelColor(double paramDouble1, double paramDouble2);
/*     */   
/*     */   public Color getPixelColor(double paramDouble1, double paramDouble2) {
/* 135 */     Application.checkEventThread();
/* 136 */     return GlassRobot.convertFromIntArgb(_getPixelColor(paramDouble1, paramDouble2));
/*     */   }
/*     */ 
/*     */   
/*     */   protected native Pixels _getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
/*     */   
/*     */   public WritableImage getScreenCapture(WritableImage paramWritableImage, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/* 143 */     Application.checkEventThread();
/* 144 */     if (paramDouble3 <= 0.0D) {
/* 145 */       throw new IllegalArgumentException("width must be > 0");
/*     */     }
/* 147 */     if (paramDouble4 <= 0.0D) {
/* 148 */       throw new IllegalArgumentException("height must be > 0");
/*     */     }
/*     */ 
/*     */     
/* 152 */     Pixels pixels = _getScreenCapture((int)paramDouble1, (int)paramDouble2, (int)paramDouble3, (int)paramDouble4, paramBoolean);
/* 153 */     return convertFromPixels(paramWritableImage, pixels);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacRobot.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */