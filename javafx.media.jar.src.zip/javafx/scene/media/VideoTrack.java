/*    */ package javafx.scene.media;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class VideoTrack
/*    */   extends Track
/*    */ {
/*    */   private int width;
/*    */   private int height;
/*    */   
/*    */   public final int getWidth() {
/* 45 */     return this.width;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getHeight() {
/* 58 */     return this.height;
/*    */   }
/*    */   
/*    */   VideoTrack(long paramLong, Map<String, Object> paramMap) {
/* 62 */     super(paramLong, paramMap);
/*    */     
/* 64 */     Object object = paramMap.get("video width");
/* 65 */     if (null != object && object instanceof Number) {
/* 66 */       this.width = ((Number)object).intValue();
/*    */     }
/*    */     
/* 69 */     object = paramMap.get("video height");
/* 70 */     if (null != object && object instanceof Number)
/* 71 */       this.height = ((Number)object).intValue(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\VideoTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */