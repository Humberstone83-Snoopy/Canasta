package com.sun.javafx.collections;

public interface FloatArraySyncer {
  float[] syncTo(float[] paramArrayOffloat, int[] paramArrayOfint);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\collections\FloatArraySyncer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */