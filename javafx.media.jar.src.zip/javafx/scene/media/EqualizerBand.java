/*     */ package javafx.scene.media;
/*     */ 
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.DoublePropertyBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EqualizerBand
/*     */ {
/*     */   public static final double MIN_GAIN = -24.0D;
/*     */   public static final double MAX_GAIN = 12.0D;
/*     */   
/*     */   public EqualizerBand(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  74 */     setCenterFrequency(paramDouble1);
/*  75 */     setBandwidth(paramDouble2);
/*  76 */     setGain(paramDouble3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private final Object disposeLock = new Object();
/*     */   
/*     */   void setJfxBand(com.sun.media.jfxmedia.effects.EqualizerBand paramEqualizerBand) {
/*  85 */     synchronized (this.disposeLock) {
/*  86 */       this.jfxBand = paramEqualizerBand;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private com.sun.media.jfxmedia.effects.EqualizerBand jfxBand;
/*     */   
/*     */   private DoubleProperty centerFrequency;
/*     */   
/*     */   private DoubleProperty bandwidth;
/*     */   
/*     */   private DoubleProperty gain;
/*     */ 
/*     */   
/*     */   public final void setCenterFrequency(double paramDouble) {
/* 102 */     centerFrequencyProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getCenterFrequency() {
/* 110 */     return (this.centerFrequency == null) ? 0.0D : this.centerFrequency.get();
/*     */   }
/*     */   
/*     */   public DoubleProperty centerFrequencyProperty() {
/* 114 */     if (this.centerFrequency == null) {
/* 115 */       this.centerFrequency = new DoublePropertyBase()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 119 */             synchronized (EqualizerBand.this.disposeLock) {
/* 120 */               double d = EqualizerBand.this.centerFrequency.get();
/* 121 */               if (EqualizerBand.this.jfxBand != null && d > 0.0D) {
/* 122 */                 EqualizerBand.this.jfxBand.setCenterFrequency(d);
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 129 */             return EqualizerBand.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 134 */             return "centerFrequency";
/*     */           }
/*     */         };
/*     */     }
/* 138 */     return this.centerFrequency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBandwidth(double paramDouble) {
/* 153 */     bandwidthProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getBandwidth() {
/* 161 */     return (this.bandwidth == null) ? 0.0D : this.bandwidth.get();
/*     */   }
/*     */   
/*     */   public DoubleProperty bandwidthProperty() {
/* 165 */     if (this.bandwidth == null) {
/* 166 */       this.bandwidth = new DoublePropertyBase()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 170 */             synchronized (EqualizerBand.this.disposeLock) {
/* 171 */               double d = EqualizerBand.this.bandwidth.get();
/* 172 */               if (EqualizerBand.this.jfxBand != null && d > 0.0D) {
/* 173 */                 EqualizerBand.this.jfxBand.setBandwidth(d);
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 180 */             return EqualizerBand.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 185 */             return "bandwidth";
/*     */           }
/*     */         };
/*     */     }
/* 189 */     return this.bandwidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setGain(double paramDouble) {
/* 205 */     gainProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getGain() {
/* 213 */     return (this.gain == null) ? 0.0D : this.gain.get();
/*     */   }
/*     */   
/*     */   public DoubleProperty gainProperty() {
/* 217 */     if (this.gain == null) {
/* 218 */       this.gain = new DoublePropertyBase()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 222 */             synchronized (EqualizerBand.this.disposeLock) {
/* 223 */               if (EqualizerBand.this.jfxBand != null) {
/* 224 */                 EqualizerBand.this.jfxBand.setGain(EqualizerBand.this.gain.get());
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 231 */             return EqualizerBand.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 236 */             return "gain";
/*     */           }
/*     */         };
/*     */     }
/* 240 */     return this.gain;
/*     */   }
/*     */   
/*     */   public EqualizerBand() {}
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\EqualizerBand.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */