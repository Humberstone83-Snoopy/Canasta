package com.sun.javafx.image;

import java.nio.IntBuffer;

public interface IntPixelGetter extends PixelGetter<IntBuffer> {
  int getArgb(int[] paramArrayOfint, int paramInt);
  
  int getArgbPre(int[] paramArrayOfint, int paramInt);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\IntPixelGetter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */