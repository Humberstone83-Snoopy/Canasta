/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.ListExpressionHelper;
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakListener;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListPropertyBase<E>
/*     */   extends ListProperty<E>
/*     */ {
/*     */   private final ListChangeListener<E> listChangeListener;
/*     */   private ObservableList<E> value;
/*     */   private ObservableValue<? extends ObservableList<E>> observable;
/*     */   private InvalidationListener listener;
/*     */   private boolean valid;
/*     */   private ListExpressionHelper<E> helper;
/*     */   private SizeProperty size0;
/*     */   private EmptyProperty empty0;
/*     */   
/*     */   public ListPropertyBase() {
/*  54 */     this.listChangeListener = (paramChange -> {
/*     */         invalidateProperties();
/*     */         
/*     */         invalidated();
/*     */         
/*     */         fireValueChangedEvent(paramChange);
/*     */       });
/*  61 */     this.observable = null;
/*  62 */     this.listener = null;
/*  63 */     this.valid = true;
/*  64 */     this.helper = null; } public ListPropertyBase(ObservableList<E> paramObservableList) { this.listChangeListener = (paramChange -> { invalidateProperties(); invalidated(); fireValueChangedEvent(paramChange); }); this.observable = null; this.listener = null; this.valid = true; this.helper = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     this.value = paramObservableList;
/*  82 */     if (paramObservableList != null) {
/*  83 */       paramObservableList.addListener(this.listChangeListener);
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyIntegerProperty sizeProperty() {
/*  89 */     if (this.size0 == null) {
/*  90 */       this.size0 = new SizeProperty();
/*     */     }
/*  92 */     return this.size0;
/*     */   }
/*     */   
/*     */   private class SizeProperty extends ReadOnlyIntegerPropertyBase { private SizeProperty() {}
/*     */     
/*     */     public int get() {
/*  98 */       return ListPropertyBase.this.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean() {
/* 103 */       return ListPropertyBase.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 108 */       return "size";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 112 */       super.fireValueChangedEvent();
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyBooleanProperty emptyProperty() {
/* 118 */     if (this.empty0 == null) {
/* 119 */       this.empty0 = new EmptyProperty();
/*     */     }
/* 121 */     return this.empty0;
/*     */   }
/*     */   
/*     */   private class EmptyProperty extends ReadOnlyBooleanPropertyBase {
/*     */     private EmptyProperty() {}
/*     */     
/*     */     public boolean get() {
/* 128 */       return ListPropertyBase.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean() {
/* 133 */       return ListPropertyBase.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 138 */       return "empty";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 142 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 148 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 153 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ChangeListener<? super ObservableList<E>> paramChangeListener) {
/* 158 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener) {
/* 163 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ListChangeListener<? super E> paramListChangeListener) {
/* 168 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ListChangeListener<? super E> paramListChangeListener) {
/* 173 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChangedEvent() {
/* 187 */     ListExpressionHelper.fireValueChangedEvent(this.helper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange) {
/* 201 */     ListExpressionHelper.fireValueChangedEvent(this.helper, paramChange);
/*     */   }
/*     */   
/*     */   private void invalidateProperties() {
/* 205 */     if (this.size0 != null) {
/* 206 */       this.size0.fireValueChangedEvent();
/*     */     }
/* 208 */     if (this.empty0 != null) {
/* 209 */       this.empty0.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   private void markInvalid(ObservableList<E> paramObservableList) {
/* 214 */     if (this.valid) {
/* 215 */       if (paramObservableList != null) {
/* 216 */         paramObservableList.removeListener(this.listChangeListener);
/*     */       }
/* 218 */       this.valid = false;
/* 219 */       invalidateProperties();
/* 220 */       invalidated();
/* 221 */       fireValueChangedEvent();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invalidated() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<E> get() {
/* 239 */     if (!this.valid) {
/* 240 */       this.value = (this.observable == null) ? this.value : this.observable.getValue();
/* 241 */       this.valid = true;
/* 242 */       if (this.value != null) {
/* 243 */         this.value.addListener(this.listChangeListener);
/*     */       }
/*     */     } 
/* 246 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void set(ObservableList<E> paramObservableList) {
/* 251 */     if (isBound()) {
/* 252 */       throw new RuntimeException(((getBean() != null && getName() != null) ? (
/* 253 */           getBean().getClass().getSimpleName() + "." + getBean().getClass().getSimpleName() + " : ") : "") + "A bound value cannot be set.");
/*     */     }
/* 255 */     if (this.value != paramObservableList) {
/* 256 */       ObservableList<E> observableList = this.value;
/* 257 */       this.value = paramObservableList;
/* 258 */       markInvalid(observableList);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBound() {
/* 264 */     return (this.observable != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void bind(ObservableValue<? extends ObservableList<E>> paramObservableValue) {
/* 269 */     if (paramObservableValue == null) {
/* 270 */       throw new NullPointerException("Cannot bind to null");
/*     */     }
/*     */     
/* 273 */     if (!paramObservableValue.equals(this.observable)) {
/* 274 */       unbind();
/* 275 */       this.observable = paramObservableValue;
/* 276 */       if (this.listener == null) {
/* 277 */         this.listener = new Listener(this);
/*     */       }
/* 279 */       this.observable.addListener(this.listener);
/* 280 */       markInvalid(this.value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void unbind() {
/* 286 */     if (this.observable != null) {
/* 287 */       this.value = this.observable.getValue();
/* 288 */       this.observable.removeListener(this.listener);
/* 289 */       this.observable = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 299 */     Object object = getBean();
/* 300 */     String str = getName();
/* 301 */     StringBuilder stringBuilder = new StringBuilder("ListProperty [");
/* 302 */     if (object != null) {
/* 303 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 305 */     if (str != null && !str.equals("")) {
/* 306 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 308 */     if (isBound()) {
/* 309 */       stringBuilder.append("bound, ");
/* 310 */       if (this.valid) {
/* 311 */         stringBuilder.append("value: ").append(get());
/*     */       } else {
/* 313 */         stringBuilder.append("invalid");
/*     */       } 
/*     */     } else {
/* 316 */       stringBuilder.append("value: ").append(get());
/*     */     } 
/* 318 */     stringBuilder.append("]");
/* 319 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private static class Listener<E>
/*     */     implements InvalidationListener, WeakListener {
/*     */     private final WeakReference<ListPropertyBase<E>> wref;
/*     */     
/*     */     public Listener(ListPropertyBase<E> param1ListPropertyBase) {
/* 327 */       this.wref = new WeakReference<>(param1ListPropertyBase);
/*     */     }
/*     */ 
/*     */     
/*     */     public void invalidated(Observable param1Observable) {
/* 332 */       ListPropertyBase listPropertyBase = this.wref.get();
/* 333 */       if (listPropertyBase == null) {
/* 334 */         param1Observable.removeListener(this);
/*     */       } else {
/* 336 */         listPropertyBase.markInvalid(listPropertyBase.value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 342 */       return (this.wref.get() == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ListPropertyBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */