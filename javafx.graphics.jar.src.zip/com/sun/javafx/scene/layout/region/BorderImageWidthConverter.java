/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.Size;
/*    */ import javafx.css.SizeUnits;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BorderWidths;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorderImageWidthConverter
/*    */   extends StyleConverter<ParsedValue[], BorderWidths>
/*    */ {
/* 41 */   private static final BorderImageWidthConverter CONVERTER_INSTANCE = new BorderImageWidthConverter();
/*    */   
/*    */   public static BorderImageWidthConverter getInstance() {
/* 44 */     return CONVERTER_INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderWidths convert(ParsedValue<ParsedValue[], BorderWidths> paramParsedValue, Font paramFont) {
/* 51 */     ParsedValue[] arrayOfParsedValue = paramParsedValue.getValue();
/* 52 */     assert arrayOfParsedValue.length == 4;
/*    */     
/* 54 */     double d1 = 1.0D, d2 = 1.0D, d3 = 1.0D, d4 = 1.0D;
/* 55 */     boolean bool1 = false, bool2 = false, bool3 = false, bool4 = false;
/* 56 */     ParsedValue parsedValue = arrayOfParsedValue[0];
/* 57 */     if ("auto".equals(parsedValue.getValue())) {
/* 58 */       d1 = -1.0D;
/*    */     } else {
/* 60 */       Size size = (Size)parsedValue.convert(paramFont);
/* 61 */       d1 = size.pixels(paramFont);
/* 62 */       bool1 = (size.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     } 
/*    */     
/* 65 */     parsedValue = arrayOfParsedValue[1];
/* 66 */     if ("auto".equals(parsedValue.getValue())) {
/* 67 */       d2 = -1.0D;
/*    */     } else {
/* 69 */       Size size = (Size)parsedValue.convert(paramFont);
/* 70 */       d2 = size.pixels(paramFont);
/* 71 */       bool2 = (size.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     } 
/*    */     
/* 74 */     parsedValue = arrayOfParsedValue[2];
/* 75 */     if ("auto".equals(parsedValue.getValue())) {
/* 76 */       d3 = -1.0D;
/*    */     } else {
/* 78 */       Size size = (Size)parsedValue.convert(paramFont);
/* 79 */       d3 = size.pixels(paramFont);
/* 80 */       bool3 = (size.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     } 
/*    */     
/* 83 */     parsedValue = arrayOfParsedValue[3];
/* 84 */     if ("auto".equals(parsedValue.getValue())) {
/* 85 */       d4 = -1.0D;
/*    */     } else {
/* 87 */       Size size = (Size)parsedValue.convert(paramFont);
/* 88 */       d4 = size.pixels(paramFont);
/* 89 */       bool4 = (size.getUnits() == SizeUnits.PERCENT) ? true : false;
/*    */     } 
/*    */     
/* 92 */     return new BorderWidths(d1, d2, d3, d4, bool1, bool2, bool3, bool4);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 97 */     return "BorderImageWidthConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderImageWidthConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */