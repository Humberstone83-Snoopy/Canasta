/*    */ package javafx.util.converter;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BigDecimalStringConverter
/*    */   extends StringConverter<BigDecimal>
/*    */ {
/*    */   public BigDecimal fromString(String paramString) {
/* 40 */     if (paramString == null) {
/* 41 */       return null;
/*    */     }
/*    */     
/* 44 */     paramString = paramString.trim();
/*    */     
/* 46 */     if (paramString.length() < 1) {
/* 47 */       return null;
/*    */     }
/*    */     
/* 50 */     return new BigDecimal(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(BigDecimal paramBigDecimal) {
/* 56 */     if (paramBigDecimal == null) {
/* 57 */       return "";
/*    */     }
/*    */     
/* 60 */     return paramBigDecimal.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\BigDecimalStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */