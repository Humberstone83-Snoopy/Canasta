/*    */ package com.sun.webkit.plugin;
/*    */ 
/*    */ import com.sun.webkit.graphics.WCGraphicsContext;
/*    */ import java.io.IOError;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DefaultPlugin
/*    */   implements Plugin
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int w;
/*    */   private int h;
/*    */   
/*    */   private void init(String paramString) {}
/*    */   
/*    */   public void paint(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*    */     paramWCGraphicsContext.fillRect(this.x, this.y, this.w, this.h, Integer.valueOf(296419327));
/*    */   }
/*    */   
/*    */   public void activate(Object paramObject, PluginListener paramPluginListener) {}
/*    */   
/*    */   DefaultPlugin(URL paramURL, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/* 65 */     this.x = 0;
/* 66 */     this.y = 0;
/* 67 */     this.w = 0;
/* 68 */     this.h = 0;
/*    */     init("Default Plugin for: " + ((null == paramURL) ? "(null)" : paramURL.toExternalForm())); } public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 70 */     this.x = paramInt1;
/* 71 */     this.y = paramInt2;
/* 72 */     this.w = paramInt3;
/* 73 */     this.h = paramInt4;
/*    */   }
/*    */   public void destroy() {}
/*    */   
/*    */   public Object invoke(String paramString1, String paramString2, Object[] paramArrayOfObject) throws IOError {
/* 78 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setVisible(boolean paramBoolean) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEnabled(boolean paramBoolean) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleMouseEvent(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, long paramLong) {
/* 95 */     return false;
/*    */   }
/*    */   
/*    */   public void requestFocus() {}
/*    */   
/*    */   public void setNativeContainerBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\plugin\DefaultPlugin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */