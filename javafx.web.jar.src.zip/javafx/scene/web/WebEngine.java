/*      */ package javafx.scene.web;
/*      */ 
/*      */ import com.sun.glass.ui.Application;
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.web.Debugger;
/*      */ import com.sun.javafx.scene.web.Printable;
/*      */ import com.sun.javafx.tk.TKPulseListener;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.javafx.webkit.Accessor;
/*      */ import com.sun.javafx.webkit.CursorManagerImpl;
/*      */ import com.sun.javafx.webkit.EventLoopImpl;
/*      */ import com.sun.javafx.webkit.ThemeClientImpl;
/*      */ import com.sun.javafx.webkit.UIClientImpl;
/*      */ import com.sun.javafx.webkit.UtilitiesImpl;
/*      */ import com.sun.javafx.webkit.WebPageClientImpl;
/*      */ import com.sun.javafx.webkit.prism.PrismGraphicsManager;
/*      */ import com.sun.javafx.webkit.prism.PrismInvoker;
/*      */ import com.sun.javafx.webkit.prism.theme.PrismRenderer;
/*      */ import com.sun.javafx.webkit.theme.RenderThemeImpl;
/*      */ import com.sun.javafx.webkit.theme.Renderer;
/*      */ import com.sun.webkit.CursorManager;
/*      */ import com.sun.webkit.Disposer;
/*      */ import com.sun.webkit.DisposerRecord;
/*      */ import com.sun.webkit.EventLoop;
/*      */ import com.sun.webkit.InspectorClient;
/*      */ import com.sun.webkit.Invoker;
/*      */ import com.sun.webkit.LoadListenerClient;
/*      */ import com.sun.webkit.ThemeClient;
/*      */ import com.sun.webkit.Timer;
/*      */ import com.sun.webkit.Utilities;
/*      */ import com.sun.webkit.WebPage;
/*      */ import com.sun.webkit.graphics.WCGraphicsManager;
/*      */ import com.sun.webkit.network.URLs;
/*      */ import com.sun.webkit.network.Util;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URLConnection;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Path;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.nio.file.attribute.PosixFilePermissions;
/*      */ import java.security.AccessController;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Base64;
/*      */ import java.util.Objects;
/*      */ import javafx.animation.AnimationTimer;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.InvalidationListener;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.BooleanPropertyBase;
/*      */ import javafx.beans.property.ObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*      */ import javafx.beans.property.ReadOnlyBooleanWrapper;
/*      */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*      */ import javafx.beans.property.ReadOnlyDoubleWrapper;
/*      */ import javafx.beans.property.ReadOnlyObjectProperty;
/*      */ import javafx.beans.property.ReadOnlyObjectPropertyBase;
/*      */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*      */ import javafx.beans.property.ReadOnlyStringProperty;
/*      */ import javafx.beans.property.ReadOnlyStringWrapper;
/*      */ import javafx.beans.property.SimpleObjectProperty;
/*      */ import javafx.beans.property.StringProperty;
/*      */ import javafx.beans.property.StringPropertyBase;
/*      */ import javafx.concurrent.Worker;
/*      */ import javafx.event.EventHandler;
/*      */ import javafx.event.EventType;
/*      */ import javafx.geometry.Rectangle2D;
/*      */ import javafx.print.PageLayout;
/*      */ import javafx.print.PrinterJob;
/*      */ import javafx.scene.Node;
/*      */ import javafx.util.Callback;
/*      */ import org.w3c.dom.Document;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class WebEngine
/*      */ {
/*      */   static {
/*  337 */     Accessor.setPageAccessor(paramWebEngine -> (paramWebEngine == null) ? null : paramWebEngine.getPage());
/*      */     
/*  339 */     Invoker.setInvoker(new PrismInvoker());
/*  340 */     Renderer.setRenderer(new PrismRenderer());
/*  341 */     WCGraphicsManager.setGraphicsManager(new PrismGraphicsManager());
/*  342 */     CursorManager.setCursorManager(new CursorManagerImpl());
/*  343 */     EventLoop.setEventLoop(new EventLoopImpl());
/*  344 */     ThemeClient.setDefaultRenderTheme(new RenderThemeImpl());
/*  345 */     Utilities.setUtilities(new UtilitiesImpl());
/*      */   }
/*      */ 
/*      */   
/*  349 */   private static final PlatformLogger logger = PlatformLogger.getLogger(WebEngine.class.getName());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  355 */   private static int instanceCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  362 */   private final ObjectProperty<WebView> view = new SimpleObjectProperty<>(this, "view");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  367 */   private final LoadWorker loadWorker = new LoadWorker();
/*      */ 
/*      */   
/*      */   private final WebPage page;
/*      */ 
/*      */   
/*      */   private final SelfDisposer disposer;
/*      */ 
/*      */   
/*  376 */   private final DebuggerImpl debugger = new DebuggerImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean userDataDirectoryApplied = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Worker<Void> getLoadWorker() {
/*  388 */     return this.loadWorker;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  395 */   private final DocumentProperty document = new DocumentProperty();
/*      */   public final Document getDocument() {
/*  397 */     return this.document.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReadOnlyObjectProperty<Document> documentProperty() {
/*  406 */     return this.document;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  413 */   private final ReadOnlyStringWrapper location = new ReadOnlyStringWrapper(this, "location");
/*      */   public final String getLocation() {
/*  415 */     return this.location.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ReadOnlyStringProperty locationProperty() {
/*  423 */     return this.location.getReadOnlyProperty();
/*      */   }
/*      */   private void updateLocation(String paramString) {
/*  426 */     this.location.set(paramString);
/*  427 */     this.document.invalidate(false);
/*  428 */     this.title.set((String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  435 */   private final ReadOnlyStringWrapper title = new ReadOnlyStringWrapper(this, "title"); private BooleanProperty javaScriptEnabled;
/*      */   public final String getTitle() {
/*  437 */     return this.title.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   private StringProperty userStyleSheetLocation;
/*      */ 
/*      */   
/*      */   public final ReadOnlyStringProperty titleProperty() {
/*  445 */     return this.title.getReadOnlyProperty();
/*      */   }
/*      */   private void updateTitle() {
/*  448 */     this.title.set(this.page.getTitle(this.page.getMainFrame()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setJavaScriptEnabled(boolean paramBoolean) {
/*  463 */     javaScriptEnabledProperty().set(paramBoolean);
/*      */   }
/*      */   
/*      */   public final boolean isJavaScriptEnabled() {
/*  467 */     return (this.javaScriptEnabled == null) ? true : this.javaScriptEnabled.get();
/*      */   }
/*      */   
/*      */   public final BooleanProperty javaScriptEnabledProperty() {
/*  471 */     if (this.javaScriptEnabled == null) {
/*  472 */       this.javaScriptEnabled = new BooleanPropertyBase(true) {
/*      */           public void invalidated() {
/*  474 */             WebEngine.checkThread();
/*  475 */             WebEngine.this.page.setJavaScriptEnabled(get());
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  479 */             return WebEngine.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  483 */             return "javaScriptEnabled";
/*      */           }
/*      */         };
/*      */     }
/*  487 */     return this.javaScriptEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUserStyleSheetLocation(String paramString) {
/*  503 */     userStyleSheetLocationProperty().set(paramString);
/*      */   }
/*      */   
/*      */   public final String getUserStyleSheetLocation() {
/*  507 */     return (this.userStyleSheetLocation == null) ? null : this.userStyleSheetLocation.get();
/*      */   }
/*      */ 
/*      */   
/*      */   private byte[] readFully(BufferedInputStream paramBufferedInputStream) throws IOException {
/*  512 */     int i = 0;
/*  513 */     ArrayList<byte[]> arrayList = new ArrayList();
/*  514 */     byte[] arrayOfByte1 = new byte[4096];
/*      */     while (true) {
/*      */       byte[] arrayOfByte;
/*  517 */       int k = paramBufferedInputStream.read(arrayOfByte1);
/*  518 */       if (k < 0) {
/*      */         break;
/*      */       }
/*  521 */       if (k == arrayOfByte1.length) {
/*  522 */         arrayOfByte = arrayOfByte1;
/*  523 */         arrayOfByte1 = new byte[4096];
/*      */       } else {
/*  525 */         arrayOfByte = new byte[k];
/*  526 */         System.arraycopy(arrayOfByte1, 0, arrayOfByte, 0, k);
/*      */       } 
/*  528 */       arrayList.add(arrayOfByte);
/*  529 */       i += k;
/*      */     } 
/*      */     
/*  532 */     byte[] arrayOfByte2 = new byte[i];
/*  533 */     int j = 0;
/*  534 */     for (byte[] arrayOfByte : arrayList) {
/*  535 */       System.arraycopy(arrayOfByte, 0, arrayOfByte2, j, arrayOfByte.length);
/*  536 */       j += arrayOfByte.length;
/*      */     } 
/*      */     
/*  539 */     return arrayOfByte2;
/*      */   }
/*      */   
/*      */   public final StringProperty userStyleSheetLocationProperty() {
/*  543 */     if (this.userStyleSheetLocation == null) {
/*  544 */       this.userStyleSheetLocation = new StringPropertyBase(null) { private static final String DATA_PREFIX = "data:text/css;charset=utf-8;base64,";
/*      */           
/*      */           public void invalidated() {
/*      */             String str2;
/*  548 */             WebEngine.checkThread();
/*  549 */             String str1 = get();
/*      */             
/*  551 */             if (str1 == null || str1.length() <= 0) {
/*  552 */               str2 = null;
/*  553 */             } else if (str1.startsWith("data:text/css;charset=utf-8;base64,")) {
/*  554 */               str2 = str1;
/*  555 */             } else if (str1.startsWith("file:") || str1
/*  556 */               .startsWith("jar:") || str1
/*  557 */               .startsWith("data:")) {
/*      */               
/*      */               try {
/*  560 */                 URLConnection uRLConnection = URLs.newURL(str1).openConnection();
/*  561 */                 uRLConnection.connect();
/*      */ 
/*      */                 
/*  564 */                 BufferedInputStream bufferedInputStream = new BufferedInputStream(uRLConnection.getInputStream());
/*  565 */                 byte[] arrayOfByte = WebEngine.this.readFully(bufferedInputStream);
/*  566 */                 String str = Base64.getMimeEncoder().encodeToString(arrayOfByte);
/*  567 */                 str2 = "data:text/css;charset=utf-8;base64," + str;
/*  568 */               } catch (IOException iOException) {
/*  569 */                 throw new RuntimeException(iOException);
/*      */               } 
/*      */             } else {
/*  572 */               throw new IllegalArgumentException("Invalid stylesheet URL");
/*      */             } 
/*  574 */             WebEngine.this.page.setUserStyleSheetLocation(str2);
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  578 */             return WebEngine.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  582 */             return "userStyleSheetLocation";
/*      */           } }
/*      */         ;
/*      */     }
/*  586 */     return this.userStyleSheetLocation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  625 */   private final ObjectProperty<File> userDataDirectory = new SimpleObjectProperty<>(this, "userDataDirectory");
/*      */   private StringProperty userAgent;
/*      */   
/*      */   public final File getUserDataDirectory() {
/*  629 */     return this.userDataDirectory.get();
/*      */   }
/*      */   
/*      */   public final void setUserDataDirectory(File paramFile) {
/*  633 */     this.userDataDirectory.set(paramFile);
/*      */   }
/*      */   
/*      */   public final ObjectProperty<File> userDataDirectoryProperty() {
/*  637 */     return this.userDataDirectory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUserAgent(String paramString) {
/*  650 */     userAgentProperty().set(paramString);
/*      */   }
/*      */   
/*      */   public final String getUserAgent() {
/*  654 */     return (this.userAgent == null) ? this.page.getUserAgent() : this.userAgent.get();
/*      */   }
/*      */   
/*      */   public final StringProperty userAgentProperty() {
/*  658 */     if (this.userAgent == null) {
/*  659 */       this.userAgent = new StringPropertyBase(this.page.getUserAgent()) {
/*      */           public void invalidated() {
/*  661 */             WebEngine.checkThread();
/*  662 */             WebEngine.this.page.setUserAgent(get());
/*      */           }
/*      */           
/*      */           public Object getBean() {
/*  666 */             return WebEngine.this;
/*      */           }
/*      */           
/*      */           public String getName() {
/*  670 */             return "userAgent";
/*      */           }
/*      */         };
/*      */     }
/*  674 */     return this.userAgent;
/*      */   }
/*      */   
/*  677 */   private final ObjectProperty<EventHandler<WebEvent<String>>> onAlert = new SimpleObjectProperty<>(this, "onAlert");
/*      */   
/*      */   public final EventHandler<WebEvent<String>> getOnAlert() {
/*  680 */     return this.onAlert.get();
/*      */   } public final void setOnAlert(EventHandler<WebEvent<String>> paramEventHandler) {
/*  682 */     this.onAlert.set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<WebEvent<String>>> onAlertProperty() {
/*  689 */     return this.onAlert;
/*      */   }
/*      */   
/*  692 */   private final ObjectProperty<EventHandler<WebEvent<String>>> onStatusChanged = new SimpleObjectProperty<>(this, "onStatusChanged");
/*      */   
/*      */   public final EventHandler<WebEvent<String>> getOnStatusChanged() {
/*  695 */     return this.onStatusChanged.get();
/*      */   } public final void setOnStatusChanged(EventHandler<WebEvent<String>> paramEventHandler) {
/*  697 */     this.onStatusChanged.set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<WebEvent<String>>> onStatusChangedProperty() {
/*  704 */     return this.onStatusChanged;
/*      */   }
/*      */   
/*  707 */   private final ObjectProperty<EventHandler<WebEvent<Rectangle2D>>> onResized = new SimpleObjectProperty<>(this, "onResized");
/*      */   
/*      */   public final EventHandler<WebEvent<Rectangle2D>> getOnResized() {
/*  710 */     return this.onResized.get();
/*      */   } public final void setOnResized(EventHandler<WebEvent<Rectangle2D>> paramEventHandler) {
/*  712 */     this.onResized.set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<WebEvent<Rectangle2D>>> onResizedProperty() {
/*  720 */     return this.onResized;
/*      */   }
/*      */   
/*  723 */   private final ObjectProperty<EventHandler<WebEvent<Boolean>>> onVisibilityChanged = new SimpleObjectProperty<>(this, "onVisibilityChanged");
/*      */   
/*      */   public final EventHandler<WebEvent<Boolean>> getOnVisibilityChanged() {
/*  726 */     return this.onVisibilityChanged.get();
/*      */   } public final void setOnVisibilityChanged(EventHandler<WebEvent<Boolean>> paramEventHandler) {
/*  728 */     this.onVisibilityChanged.set(paramEventHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<EventHandler<WebEvent<Boolean>>> onVisibilityChangedProperty() {
/*  736 */     return this.onVisibilityChanged;
/*      */   }
/*      */   
/*  739 */   private final ObjectProperty<Callback<PopupFeatures, WebEngine>> createPopupHandler = new SimpleObjectProperty<>(this, "createPopupHandler", paramPopupFeatures -> this);
/*      */ 
/*      */   
/*      */   public final Callback<PopupFeatures, WebEngine> getCreatePopupHandler() {
/*  743 */     return this.createPopupHandler.get();
/*      */   } public final void setCreatePopupHandler(Callback<PopupFeatures, WebEngine> paramCallback) {
/*  745 */     this.createPopupHandler.set(paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Callback<PopupFeatures, WebEngine>> createPopupHandlerProperty() {
/*  761 */     return this.createPopupHandler;
/*      */   }
/*      */   
/*  764 */   private final ObjectProperty<Callback<String, Boolean>> confirmHandler = new SimpleObjectProperty<>(this, "confirmHandler");
/*      */   
/*      */   public final Callback<String, Boolean> getConfirmHandler() {
/*  767 */     return this.confirmHandler.get();
/*      */   } public final void setConfirmHandler(Callback<String, Boolean> paramCallback) {
/*  769 */     this.confirmHandler.set(paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Callback<String, Boolean>> confirmHandlerProperty() {
/*  779 */     return this.confirmHandler;
/*      */   }
/*      */   
/*  782 */   private final ObjectProperty<Callback<PromptData, String>> promptHandler = new SimpleObjectProperty<>(this, "promptHandler");
/*      */   
/*      */   public final Callback<PromptData, String> getPromptHandler() {
/*  785 */     return this.promptHandler.get();
/*      */   } public final void setPromptHandler(Callback<PromptData, String> paramCallback) {
/*  787 */     this.promptHandler.set(paramCallback);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectProperty<Callback<PromptData, String>> promptHandlerProperty() {
/*  798 */     return this.promptHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  806 */   private final ObjectProperty<EventHandler<WebErrorEvent>> onError = new SimpleObjectProperty<>(this, "onError");
/*      */   private final WebHistory history;
/*      */   
/*      */   public final EventHandler<WebErrorEvent> getOnError() {
/*  810 */     return this.onError.get();
/*      */   }
/*      */   
/*      */   public final void setOnError(EventHandler<WebErrorEvent> paramEventHandler) {
/*  814 */     this.onError.set(paramEventHandler);
/*      */   }
/*      */   
/*      */   public final ObjectProperty<EventHandler<WebErrorEvent>> onErrorProperty() {
/*  818 */     return this.onError;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebEngine() {
/*  826 */     this(null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebEngine(String paramString) {
/*  835 */     this(paramString, true);
/*      */   }
/*      */   
/*      */   private WebEngine(String paramString, boolean paramBoolean) {
/*  839 */     checkThread();
/*  840 */     AccessorImpl accessorImpl = new AccessorImpl(this);
/*  841 */     this.page = new WebPage(new WebPageClientImpl(accessorImpl), new UIClientImpl(accessorImpl), null, new InspectorClientImpl(this), new ThemeClientImpl(accessorImpl), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  848 */     this.page.addLoadListenerClient(new PageLoadListener(this));
/*      */     
/*  850 */     this.history = new WebHistory(this.page);
/*      */     
/*  852 */     this.disposer = new SelfDisposer(this.page);
/*  853 */     Disposer.addRecord(this, this.disposer);
/*      */     
/*  855 */     if (paramBoolean) {
/*  856 */       load(paramString);
/*      */     }
/*      */     
/*  859 */     if (instanceCount == 0 && 
/*  860 */       Timer.getMode() == Timer.Mode.PLATFORM_TICKS)
/*      */     {
/*  862 */       PulseTimer.start();
/*      */     }
/*  864 */     instanceCount++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void load(String paramString) {
/*  873 */     checkThread();
/*  874 */     this.loadWorker.cancelAndReset();
/*      */     
/*  876 */     if (paramString == null || paramString.equals("") || paramString.equals("about:blank")) {
/*  877 */       paramString = "";
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*  882 */         paramString = Util.adjustUrlForWebKit(paramString);
/*  883 */       } catch (MalformedURLException malformedURLException) {
/*  884 */         this.loadWorker.dispatchLoadEvent(getMainFrame(), 0, paramString, null, 0.0D, 0);
/*      */         
/*  886 */         this.loadWorker.dispatchLoadEvent(getMainFrame(), 5, paramString, null, 0.0D, 2);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  891 */     applyUserDataDirectory();
/*  892 */     this.page.open(this.page.getMainFrame(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadContent(String paramString) {
/*  904 */     loadContent(paramString, "text/html");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadContent(String paramString1, String paramString2) {
/*  919 */     checkThread();
/*  920 */     this.loadWorker.cancelAndReset();
/*  921 */     applyUserDataDirectory();
/*  922 */     this.page.load(this.page.getMainFrame(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reload() {
/*  931 */     checkThread();
/*  932 */     this.page.refresh(this.page.getMainFrame());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebHistory getHistory() {
/*  944 */     return this.history;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object executeScript(String paramString) {
/*  970 */     checkThread();
/*  971 */     applyUserDataDirectory();
/*  972 */     return this.page.executeScript(this.page.getMainFrame(), paramString);
/*      */   }
/*      */   
/*      */   private long getMainFrame() {
/*  976 */     return this.page.getMainFrame();
/*      */   }
/*      */   
/*      */   WebPage getPage() {
/*  980 */     return this.page;
/*      */   }
/*      */   
/*      */   void setView(WebView paramWebView) {
/*  984 */     this.view.setValue(paramWebView);
/*      */   }
/*      */   
/*      */   private void stop() {
/*  988 */     checkThread();
/*  989 */     this.page.stop(this.page.getMainFrame());
/*      */   }
/*      */   
/*      */   private void applyUserDataDirectory() {
/*  993 */     if (this.userDataDirectoryApplied) {
/*      */       return;
/*      */     }
/*  996 */     this.userDataDirectoryApplied = true;
/*  997 */     File file = getUserDataDirectory(); while (true) {
/*      */       File file1; String str1;
/*      */       EventType<WebErrorEvent> eventType;
/*      */       SecurityException securityException;
/* 1001 */       if (file == null) {
/* 1002 */         file1 = defaultUserDataDirectory();
/* 1003 */         str1 = String.format("null (%s)", new Object[] { file1 });
/*      */       } else {
/* 1005 */         file1 = file;
/* 1006 */         str1 = file1.toString();
/*      */       } 
/* 1008 */       logger.fine("Trying to apply user data directory [{0}]", new Object[] { str1 });
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1013 */         file1 = DirectoryLock.canonicalize(file1);
/* 1014 */         File file3 = new File(file1, "localstorage");
/* 1015 */         File[] arrayOfFile = { file1, file3 };
/*      */ 
/*      */ 
/*      */         
/* 1019 */         for (File file4 : arrayOfFile) {
/* 1020 */           createDirectories(file4);
/*      */ 
/*      */           
/* 1023 */           File file5 = new File(file4, ".test");
/* 1024 */           if (file5.createNewFile()) {
/* 1025 */             file5.delete();
/*      */           }
/*      */         } 
/* 1028 */         this.disposer.userDataDirectoryLock = new DirectoryLock(file1);
/*      */         
/* 1030 */         this.page.setLocalStorageDatabasePath(file3.getPath());
/* 1031 */         this.page.setLocalStorageEnabled(true);
/*      */         
/* 1033 */         logger.fine("User data directory [{0}] has been applied successfully", new Object[] { str1 });
/*      */ 
/*      */         
/*      */         return;
/* 1037 */       } catch (DirectoryAlreadyInUseException directoryAlreadyInUseException2) {
/* 1038 */         str2 = "User data directory [%s] is already in use";
/* 1039 */         eventType = WebErrorEvent.USER_DATA_DIRECTORY_ALREADY_IN_USE;
/* 1040 */         DirectoryLock.DirectoryAlreadyInUseException directoryAlreadyInUseException1 = directoryAlreadyInUseException2;
/* 1041 */       } catch (IOException iOException2) {
/* 1042 */         str2 = "An I/O error occurred while setting up user data directory [%s]";
/*      */         
/* 1044 */         eventType = WebErrorEvent.USER_DATA_DIRECTORY_IO_ERROR;
/* 1045 */         IOException iOException1 = iOException2;
/* 1046 */       } catch (SecurityException securityException1) {
/* 1047 */         str2 = "A security error occurred while setting up user data directory [%s]";
/*      */         
/* 1049 */         eventType = WebErrorEvent.USER_DATA_DIRECTORY_SECURITY_ERROR;
/* 1050 */         securityException = securityException1;
/*      */       } 
/*      */       
/* 1053 */       String str2 = String.format(str2, new Object[] { str1 });
/* 1054 */       logger.fine("{0}, calling error handler", new Object[] { str2 });
/* 1055 */       File file2 = file;
/* 1056 */       fireError(eventType, str2, securityException);
/* 1057 */       file = getUserDataDirectory();
/* 1058 */       if (Objects.equals(file, file2)) {
/* 1059 */         logger.fine("Error handler did not modify user data directory, continuing without user data directory");
/*      */         
/*      */         return;
/*      */       } 
/* 1063 */       logger.fine("Error handler has set user data directory to [{0}], retrying", new Object[] { file });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static File defaultUserDataDirectory() {
/* 1071 */     return new File(
/* 1072 */         Application.GetApplication()
/* 1073 */         .getDataDirectory(), "webview");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void createDirectories(File paramFile) throws IOException {
/* 1078 */     Path path = paramFile.toPath();
/*      */     try {
/* 1080 */       Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[] { PosixFilePermissions.asFileAttribute(
/* 1081 */               PosixFilePermissions.fromString("rwx------")) });
/* 1082 */     } catch (UnsupportedOperationException unsupportedOperationException) {
/* 1083 */       Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fireError(EventType<WebErrorEvent> paramEventType, String paramString, Throwable paramThrowable) {
/* 1090 */     EventHandler<WebErrorEvent> eventHandler = getOnError();
/* 1091 */     if (eventHandler != null) {
/* 1092 */       eventHandler.handle(new WebErrorEvent(this, paramEventType, paramString, paramThrowable));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void dispose() {
/* 1099 */     this.disposer.dispose();
/*      */   }
/*      */   
/*      */   private static final class SelfDisposer implements DisposerRecord {
/*      */     private WebPage page;
/*      */     private DirectoryLock userDataDirectoryLock;
/*      */     
/*      */     private SelfDisposer(WebPage param1WebPage) {
/* 1107 */       this.page = param1WebPage;
/*      */     }
/*      */     
/*      */     public void dispose() {
/* 1111 */       if (this.page == null) {
/*      */         return;
/*      */       }
/* 1114 */       this.page.dispose();
/* 1115 */       this.page = null;
/* 1116 */       if (this.userDataDirectoryLock != null) {
/* 1117 */         this.userDataDirectoryLock.close();
/*      */       }
/*      */       WebEngine.instanceCount--;
/* 1120 */       if (WebEngine.instanceCount == 0 && 
/* 1121 */         Timer.getMode() == Timer.Mode.PLATFORM_TICKS)
/*      */       {
/* 1123 */         WebEngine.PulseTimer.stop();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class AccessorImpl extends Accessor {
/*      */     private final WeakReference<WebEngine> engine;
/*      */     
/*      */     private AccessorImpl(WebEngine param1WebEngine) {
/* 1132 */       this.engine = new WeakReference<>(param1WebEngine);
/*      */     }
/*      */     
/*      */     public WebEngine getEngine() {
/* 1136 */       return this.engine.get();
/*      */     }
/*      */     
/*      */     public WebPage getPage() {
/* 1140 */       WebEngine webEngine = getEngine();
/* 1141 */       return (webEngine == null) ? null : webEngine.page;
/*      */     }
/*      */     
/*      */     public WebView getView() {
/* 1145 */       WebEngine webEngine = getEngine();
/* 1146 */       return (webEngine == null) ? null : webEngine.view.get();
/*      */     }
/*      */     
/*      */     public void addChild(Node param1Node) {
/* 1150 */       WebView webView = getView();
/* 1151 */       if (webView != null) {
/* 1152 */         webView.getChildren().add(param1Node);
/*      */       }
/*      */     }
/*      */     
/*      */     public void removeChild(Node param1Node) {
/* 1157 */       WebView webView = getView();
/* 1158 */       if (webView != null) {
/* 1159 */         webView.getChildren().remove(param1Node);
/*      */       }
/*      */     }
/*      */     
/*      */     public void addViewListener(InvalidationListener param1InvalidationListener) {
/* 1164 */       WebEngine webEngine = getEngine();
/* 1165 */       if (webEngine != null) {
/* 1166 */         webEngine.view.addListener(param1InvalidationListener);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class PulseTimer
/*      */   {
/* 1177 */     private static final AnimationTimer animation = new AnimationTimer()
/*      */       {
/*      */         public void handle(long param2Long) {}
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final TKPulseListener listener = () -> Platform.runLater(());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void start() {
/* 1196 */       Toolkit.getToolkit().addSceneTkPulseListener(listener);
/* 1197 */       animation.start();
/*      */     }
/*      */     
/*      */     private static void stop() {
/* 1201 */       Toolkit.getToolkit().removeSceneTkPulseListener(listener);
/* 1202 */       animation.stop();
/*      */     }
/*      */   }
/*      */   
/*      */   static void checkThread() {
/* 1207 */     Toolkit.getToolkit().checkFxUserThread();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class PageLoadListener
/*      */     implements LoadListenerClient
/*      */   {
/*      */     private final WeakReference<WebEngine> engine;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private PageLoadListener(WebEngine param1WebEngine) {
/* 1222 */       this.engine = new WeakReference<>(param1WebEngine);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispatchLoadEvent(long param1Long, int param1Int1, String param1String1, String param1String2, double param1Double, int param1Int2) {
/* 1229 */       WebEngine webEngine = this.engine.get();
/* 1230 */       if (webEngine != null) {
/* 1231 */         webEngine.loadWorker.dispatchLoadEvent(param1Long, param1Int1, param1String1, param1String2, param1Double, param1Int2);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void dispatchResourceLoadEvent(long param1Long, int param1Int1, String param1String1, String param1String2, double param1Double, int param1Int2) {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final class LoadWorker
/*      */     implements Worker<Void>
/*      */   {
/* 1246 */     private final ReadOnlyObjectWrapper<Worker.State> state = new ReadOnlyObjectWrapper<>(this, "state", Worker.State.READY);
/* 1247 */     public final Worker.State getState() { WebEngine.checkThread(); return this.state.get(); } public final ReadOnlyObjectProperty<Worker.State> stateProperty() {
/* 1248 */       WebEngine.checkThread(); return this.state.getReadOnlyProperty();
/*      */     } private void updateState(Worker.State param1State) {
/* 1250 */       WebEngine.checkThread();
/* 1251 */       this.state.set(param1State);
/* 1252 */       this.running.set((param1State == Worker.State.SCHEDULED || param1State == Worker.State.RUNNING));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1258 */     private final ReadOnlyObjectWrapper<Void> value = new ReadOnlyObjectWrapper<>(this, "value", null);
/* 1259 */     public final Void getValue() { WebEngine.checkThread(); return this.value.get(); } public final ReadOnlyObjectProperty<Void> valueProperty() {
/* 1260 */       WebEngine.checkThread(); return this.value.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1265 */     private final ReadOnlyObjectWrapper<Throwable> exception = new ReadOnlyObjectWrapper<>(this, "exception");
/* 1266 */     public final Throwable getException() { WebEngine.checkThread(); return this.exception.get(); } public final ReadOnlyObjectProperty<Throwable> exceptionProperty() {
/* 1267 */       WebEngine.checkThread(); return this.exception.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1272 */     private final ReadOnlyDoubleWrapper workDone = new ReadOnlyDoubleWrapper(this, "workDone", -1.0D);
/* 1273 */     public final double getWorkDone() { WebEngine.checkThread(); return this.workDone.get(); } public final ReadOnlyDoubleProperty workDoneProperty() {
/* 1274 */       WebEngine.checkThread(); return this.workDone.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1279 */     private final ReadOnlyDoubleWrapper totalWorkToBeDone = new ReadOnlyDoubleWrapper(this, "totalWork", -1.0D);
/* 1280 */     public final double getTotalWork() { WebEngine.checkThread(); return this.totalWorkToBeDone.get(); } public final ReadOnlyDoubleProperty totalWorkProperty() {
/* 1281 */       WebEngine.checkThread(); return this.totalWorkToBeDone.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1286 */     private final ReadOnlyDoubleWrapper progress = new ReadOnlyDoubleWrapper(this, "progress", -1.0D);
/* 1287 */     public final double getProgress() { WebEngine.checkThread(); return this.progress.get(); } public final ReadOnlyDoubleProperty progressProperty() {
/* 1288 */       WebEngine.checkThread(); return this.progress.getReadOnlyProperty();
/*      */     } private void updateProgress(double param1Double) {
/* 1290 */       this.totalWorkToBeDone.set(100.0D);
/* 1291 */       this.workDone.set(param1Double * 100.0D);
/* 1292 */       this.progress.set(param1Double);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1298 */     private final ReadOnlyBooleanWrapper running = new ReadOnlyBooleanWrapper(this, "running", false);
/* 1299 */     public final boolean isRunning() { WebEngine.checkThread(); return this.running.get(); } public final ReadOnlyBooleanProperty runningProperty() {
/* 1300 */       WebEngine.checkThread(); return this.running.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1305 */     private final ReadOnlyStringWrapper message = new ReadOnlyStringWrapper(this, "message", "");
/* 1306 */     public final String getMessage() { return this.message.get(); } public final ReadOnlyStringProperty messageProperty() {
/* 1307 */       return this.message.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1312 */     private final ReadOnlyStringWrapper title = new ReadOnlyStringWrapper(this, "title", "WebEngine Loader");
/* 1313 */     public final String getTitle() { return this.title.get(); } public final ReadOnlyStringProperty titleProperty() {
/* 1314 */       return this.title.getReadOnlyProperty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean cancel() {
/* 1321 */       if (isRunning()) {
/* 1322 */         WebEngine.this.stop();
/* 1323 */         return true;
/*      */       } 
/* 1325 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     private void cancelAndReset() {
/* 1330 */       cancel();
/* 1331 */       this.exception.set(null);
/* 1332 */       this.message.set("");
/* 1333 */       this.totalWorkToBeDone.set(-1.0D);
/* 1334 */       this.workDone.set(-1.0D);
/* 1335 */       this.progress.set(-1.0D);
/* 1336 */       updateState(Worker.State.READY);
/* 1337 */       this.running.set(false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void dispatchLoadEvent(long param1Long, int param1Int1, String param1String1, String param1String2, double param1Double, int param1Int2) {
/* 1343 */       if (param1Long != WebEngine.this.getMainFrame()) {
/*      */         return;
/*      */       }
/* 1346 */       switch (param1Int1) {
/*      */         case 0:
/* 1348 */           this.message.set("Loading " + param1String1);
/* 1349 */           WebEngine.this.updateLocation(param1String1);
/* 1350 */           updateProgress(0.0D);
/* 1351 */           updateState(Worker.State.SCHEDULED);
/* 1352 */           updateState(Worker.State.RUNNING);
/*      */           break;
/*      */         case 2:
/* 1355 */           this.message.set("Loading " + param1String1);
/* 1356 */           WebEngine.this.updateLocation(param1String1);
/*      */           break;
/*      */         case 3:
/* 1359 */           this.message.set("Replaced " + param1String1);
/*      */           
/* 1361 */           WebEngine.this.location.set(param1String1);
/*      */           break;
/*      */         case 1:
/* 1364 */           this.message.set("Loading complete");
/* 1365 */           updateProgress(1.0D);
/* 1366 */           updateState(Worker.State.SUCCEEDED);
/*      */           break;
/*      */         case 5:
/* 1369 */           this.message.set("Loading failed");
/* 1370 */           this.exception.set(describeError(param1Int2));
/* 1371 */           updateState(Worker.State.FAILED);
/*      */           break;
/*      */         case 6:
/* 1374 */           this.message.set("Loading stopped");
/* 1375 */           updateState(Worker.State.CANCELLED);
/*      */           break;
/*      */         case 30:
/* 1378 */           updateProgress(param1Double);
/*      */           break;
/*      */         case 11:
/* 1381 */           WebEngine.this.updateTitle();
/*      */           break;
/*      */         case 14:
/* 1384 */           if (this.state.get() != Worker.State.RUNNING)
/*      */           {
/* 1386 */             dispatchLoadEvent(param1Long, 0, param1String1, param1String2, param1Double, param1Int2);
/*      */           }
/* 1388 */           WebEngine.this.document.invalidate(true);
/*      */           break;
/*      */       } 
/*      */     }
/*      */     
/*      */     private Throwable describeError(int param1Int) {
/* 1394 */       String str = "Unknown error";
/*      */       
/* 1396 */       switch (param1Int) {
/*      */         case 1:
/* 1398 */           str = "Unknown host";
/*      */           break;
/*      */         case 2:
/* 1401 */           str = "Malformed URL";
/*      */           break;
/*      */         case 3:
/* 1404 */           str = "SSL handshake failed";
/*      */           break;
/*      */         case 4:
/* 1407 */           str = "Connection refused by server";
/*      */           break;
/*      */         case 5:
/* 1410 */           str = "Connection reset by server";
/*      */           break;
/*      */         case 6:
/* 1413 */           str = "No route to host";
/*      */           break;
/*      */         case 7:
/* 1416 */           str = "Connection timed out";
/*      */           break;
/*      */         case 8:
/* 1419 */           str = "Permission denied";
/*      */           break;
/*      */         case 9:
/* 1422 */           str = "Invalid response from server";
/*      */           break;
/*      */         case 10:
/* 1425 */           str = "Too many redirects";
/*      */           break;
/*      */         case 11:
/* 1428 */           str = "File not found";
/*      */           break;
/*      */       } 
/* 1431 */       return new Throwable(str);
/*      */     }
/*      */     
/*      */     private LoadWorker() {} }
/*      */   
/*      */   private final class DocumentProperty extends ReadOnlyObjectPropertyBase<Document> {
/*      */     private boolean available;
/*      */     private Document document;
/*      */     
/*      */     private DocumentProperty() {}
/*      */     
/*      */     private void invalidate(boolean param1Boolean) {
/* 1443 */       if (this.available || param1Boolean) {
/* 1444 */         this.available = param1Boolean;
/* 1445 */         this.document = null;
/* 1446 */         fireValueChangedEvent();
/*      */       } 
/*      */     }
/*      */     
/*      */     public Document get() {
/* 1451 */       if (!this.available) {
/* 1452 */         return null;
/*      */       }
/* 1454 */       if (this.document == null) {
/* 1455 */         this.document = WebEngine.this.page.getDocument(WebEngine.this.page.getMainFrame());
/* 1456 */         if (this.document == null) {
/* 1457 */           this.available = false;
/*      */         }
/*      */       } 
/* 1460 */       return this.document;
/*      */     }
/*      */     
/*      */     public Object getBean() {
/* 1464 */       return WebEngine.this;
/*      */     }
/*      */     
/*      */     public String getName() {
/* 1468 */       return "document";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Debugger getDebugger() {
/* 1486 */     return this.debugger;
/*      */   }
/*      */ 
/*      */   
/*      */   private final class DebuggerImpl
/*      */     implements Debugger
/*      */   {
/*      */     private boolean enabled;
/*      */     
/*      */     private Callback<String, Void> messageCallback;
/*      */     
/*      */     private DebuggerImpl() {}
/*      */     
/*      */     public boolean isEnabled() {
/* 1500 */       WebEngine.checkThread();
/* 1501 */       return this.enabled;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setEnabled(boolean param1Boolean) {
/* 1506 */       WebEngine.checkThread();
/* 1507 */       if (param1Boolean != this.enabled) {
/* 1508 */         if (param1Boolean) {
/* 1509 */           WebEngine.this.page.setDeveloperExtrasEnabled(true);
/* 1510 */           WebEngine.this.page.connectInspectorFrontend();
/*      */         } else {
/* 1512 */           WebEngine.this.page.disconnectInspectorFrontend();
/* 1513 */           WebEngine.this.page.setDeveloperExtrasEnabled(false);
/*      */         } 
/* 1515 */         this.enabled = param1Boolean;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void sendMessage(String param1String) {
/* 1521 */       WebEngine.checkThread();
/* 1522 */       if (!this.enabled) {
/* 1523 */         throw new IllegalStateException("Debugger is not enabled");
/*      */       }
/* 1525 */       if (param1String == null) {
/* 1526 */         throw new NullPointerException("message is null");
/*      */       }
/* 1528 */       WebEngine.this.page.dispatchInspectorMessageFromFrontend(param1String);
/*      */     }
/*      */ 
/*      */     
/*      */     public Callback<String, Void> getMessageCallback() {
/* 1533 */       WebEngine.checkThread();
/* 1534 */       return this.messageCallback;
/*      */     }
/*      */ 
/*      */     
/*      */     public void setMessageCallback(Callback<String, Void> param1Callback) {
/* 1539 */       WebEngine.checkThread();
/* 1540 */       this.messageCallback = param1Callback;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class InspectorClientImpl
/*      */     implements InspectorClient
/*      */   {
/*      */     private final WeakReference<WebEngine> engine;
/*      */ 
/*      */ 
/*      */     
/*      */     private InspectorClientImpl(WebEngine param1WebEngine) {
/* 1555 */       this.engine = new WeakReference<>(param1WebEngine);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean sendMessageToFrontend(String param1String) {
/* 1561 */       boolean bool = false;
/* 1562 */       WebEngine webEngine = this.engine.get();
/* 1563 */       if (webEngine != null) {
/*      */         
/* 1565 */         Callback callback = webEngine.debugger.messageCallback;
/* 1566 */         if (callback != null) {
/* 1567 */           AccessController.doPrivileged(() -> { param1Callback.call(param1String); return null; }webEngine
/*      */ 
/*      */               
/* 1570 */               .page.getAccessControlContext());
/* 1571 */           bool = true;
/*      */         } 
/*      */       } 
/* 1574 */       return bool;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final boolean printStatusOK(PrinterJob paramPrinterJob) {
/* 1579 */     switch (paramPrinterJob.getJobStatus()) {
/*      */       case NOT_STARTED:
/*      */       case PRINTING:
/* 1582 */         return true;
/*      */     } 
/* 1584 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print(PrinterJob paramPrinterJob) {
/* 1597 */     if (!printStatusOK(paramPrinterJob)) {
/*      */       return;
/*      */     }
/*      */     
/* 1601 */     PageLayout pageLayout = paramPrinterJob.getJobSettings().getPageLayout();
/* 1602 */     float f1 = (float)pageLayout.getPrintableWidth();
/* 1603 */     float f2 = (float)pageLayout.getPrintableHeight();
/* 1604 */     int i = this.page.beginPrinting(f1, f2);
/*      */     
/* 1606 */     for (byte b = 0; b < i; b++) {
/* 1607 */       if (printStatusOK(paramPrinterJob)) {
/* 1608 */         Printable printable = new Printable(this.page, b, f1);
/* 1609 */         paramPrinterJob.printPage((Node)printable);
/*      */       } 
/*      */     } 
/* 1612 */     this.page.endPrinting();
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\javafx\scene\web\WebEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */