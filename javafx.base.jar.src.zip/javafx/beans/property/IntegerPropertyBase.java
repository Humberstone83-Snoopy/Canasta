/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelper;
/*     */ import java.lang.ref.WeakReference;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakListener;
/*     */ import javafx.beans.binding.IntegerBinding;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableIntegerValue;
/*     */ import javafx.beans.value.ObservableNumberValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IntegerPropertyBase
/*     */   extends IntegerProperty
/*     */ {
/*     */   private int value;
/*  56 */   private ObservableIntegerValue observable = null;
/*  57 */   private InvalidationListener listener = null;
/*     */   private boolean valid = true;
/*  59 */   private ExpressionHelper<Number> helper = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerPropertyBase(int paramInt) {
/*  74 */     this.value = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/*  79 */     this.helper = ExpressionHelper.addListener(this.helper, this, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/*  84 */     this.helper = ExpressionHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ChangeListener<? super Number> paramChangeListener) {
/*  89 */     this.helper = ExpressionHelper.addListener(this.helper, this, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ChangeListener<? super Number> paramChangeListener) {
/*  94 */     this.helper = ExpressionHelper.removeListener(this.helper, paramChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChangedEvent() {
/* 107 */     ExpressionHelper.fireValueChangedEvent(this.helper);
/*     */   }
/*     */   
/*     */   private void markInvalid() {
/* 111 */     if (this.valid) {
/* 112 */       this.valid = false;
/* 113 */       invalidated();
/* 114 */       fireValueChangedEvent();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invalidated() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int get() {
/* 133 */     this.valid = true;
/* 134 */     return (this.observable == null) ? this.value : this.observable.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int paramInt) {
/* 142 */     if (isBound()) {
/* 143 */       throw new RuntimeException(((getBean() != null && getName() != null) ? (
/* 144 */           getBean().getClass().getSimpleName() + "." + getBean().getClass().getSimpleName() + " : ") : "") + "A bound value cannot be set.");
/*     */     }
/* 146 */     if (this.value != paramInt) {
/* 147 */       this.value = paramInt;
/* 148 */       markInvalid();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBound() {
/* 157 */     return (this.observable != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind(final ObservableValue<? extends Number> rawObservable) {
/*     */     ObservableIntegerValue observableIntegerValue;
/* 165 */     if (rawObservable == null) {
/* 166 */       throw new NullPointerException("Cannot bind to null");
/*     */     }
/*     */ 
/*     */     
/* 170 */     if (rawObservable instanceof ObservableIntegerValue) {
/* 171 */       observableIntegerValue = (ObservableIntegerValue)rawObservable;
/* 172 */     } else if (rawObservable instanceof ObservableNumberValue) {
/* 173 */       final ObservableNumberValue numberValue = (ObservableNumberValue)rawObservable;
/* 174 */       observableIntegerValue = new ValueWrapper(rawObservable)
/*     */         {
/*     */           protected int computeValue()
/*     */           {
/* 178 */             return numberValue.intValue();
/*     */           }
/*     */         };
/*     */     } else {
/* 182 */       observableIntegerValue = new ValueWrapper(rawObservable)
/*     */         {
/*     */           protected int computeValue()
/*     */           {
/* 186 */             Number number = rawObservable.getValue();
/* 187 */             return (number == null) ? 0 : number.intValue();
/*     */           }
/*     */         };
/*     */     } 
/*     */     
/* 192 */     if (!observableIntegerValue.equals(this.observable)) {
/* 193 */       unbind();
/* 194 */       this.observable = observableIntegerValue;
/* 195 */       if (this.listener == null) {
/* 196 */         this.listener = new Listener(this);
/*     */       }
/* 198 */       this.observable.addListener(this.listener);
/* 199 */       markInvalid();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbind() {
/* 208 */     if (this.observable != null) {
/* 209 */       this.value = this.observable.get();
/* 210 */       this.observable.removeListener(this.listener);
/* 211 */       if (this.observable instanceof ValueWrapper) {
/* 212 */         ((ValueWrapper)this.observable).dispose();
/*     */       }
/* 214 */       this.observable = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 224 */     Object object = getBean();
/* 225 */     String str = getName();
/* 226 */     StringBuilder stringBuilder = new StringBuilder("IntegerProperty [");
/* 227 */     if (object != null) {
/* 228 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 230 */     if (str != null && !str.equals("")) {
/* 231 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 233 */     if (isBound()) {
/* 234 */       stringBuilder.append("bound, ");
/* 235 */       if (this.valid) {
/* 236 */         stringBuilder.append("value: ").append(get());
/*     */       } else {
/* 238 */         stringBuilder.append("invalid");
/*     */       } 
/*     */     } else {
/* 241 */       stringBuilder.append("value: ").append(get());
/*     */     } 
/* 243 */     stringBuilder.append("]");
/* 244 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public IntegerPropertyBase() {}
/*     */   
/*     */   private static class Listener
/*     */     implements InvalidationListener, WeakListener {
/*     */     public Listener(IntegerPropertyBase param1IntegerPropertyBase) {
/* 252 */       this.wref = new WeakReference<>(param1IntegerPropertyBase);
/*     */     }
/*     */     private final WeakReference<IntegerPropertyBase> wref;
/*     */     
/*     */     public void invalidated(Observable param1Observable) {
/* 257 */       IntegerPropertyBase integerPropertyBase = this.wref.get();
/* 258 */       if (integerPropertyBase == null) {
/* 259 */         param1Observable.removeListener(this);
/*     */       } else {
/* 261 */         integerPropertyBase.markInvalid();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 267 */       return (this.wref.get() == null);
/*     */     }
/*     */   }
/*     */   
/*     */   private abstract class ValueWrapper
/*     */     extends IntegerBinding {
/*     */     private ObservableValue<? extends Number> observable;
/*     */     
/*     */     public ValueWrapper(ObservableValue<? extends Number> param1ObservableValue) {
/* 276 */       this.observable = param1ObservableValue;
/* 277 */       bind(new Observable[] { param1ObservableValue });
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {
/* 282 */       unbind(new Observable[] { this.observable });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\IntegerPropertyBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */