/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ import org.w3c.dom.html.HTMLOptionElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLOptionElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLOptionElement
/*     */ {
/*     */   HTMLOptionElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLOptionElement getImpl(long paramLong) {
/*  37 */     return (HTMLOptionElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   public boolean getDisabled() {
/*  43 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  48 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLFormElement getForm() {
/*  53 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   public String getLabel() {
/*  58 */     return getLabelImpl(getPeer());
/*     */   }
/*     */   static native String getLabelImpl(long paramLong);
/*     */   
/*     */   public void setLabel(String paramString) {
/*  63 */     setLabelImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLabelImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getDefaultSelected() {
/*  68 */     return getDefaultSelectedImpl(getPeer());
/*     */   }
/*     */   static native boolean getDefaultSelectedImpl(long paramLong);
/*     */   
/*     */   public void setDefaultSelected(boolean paramBoolean) {
/*  73 */     setDefaultSelectedImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDefaultSelectedImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getSelected() {
/*  78 */     return getSelectedImpl(getPeer());
/*     */   }
/*     */   static native boolean getSelectedImpl(long paramLong);
/*     */   
/*     */   public void setSelected(boolean paramBoolean) {
/*  83 */     setSelectedImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setSelectedImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getValue() {
/*  88 */     return getValueImpl(getPeer());
/*     */   }
/*     */   static native String getValueImpl(long paramLong);
/*     */   
/*     */   public void setValue(String paramString) {
/*  93 */     setValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getText() {
/*  98 */     return getTextImpl(getPeer());
/*     */   }
/*     */   static native String getTextImpl(long paramLong);
/*     */   
/*     */   public int getIndex() {
/* 103 */     return getIndexImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native int getIndexImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLOptionElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */