/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Accessible;
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.CommonDialogs;
/*     */ import com.sun.glass.ui.Cursor;
/*     */ import com.sun.glass.ui.GlassRobot;
/*     */ import com.sun.glass.ui.InvokeLaterDispatcher;
/*     */ import com.sun.glass.ui.Menu;
/*     */ import com.sun.glass.ui.MenuBar;
/*     */ import com.sun.glass.ui.MenuItem;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.glass.ui.Size;
/*     */ import com.sun.glass.ui.Timer;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MacApplication
/*     */   extends Application
/*     */   implements InvokeLaterDispatcher.InvokeLaterSubmitter
/*     */ {
/*     */   static {
/*  43 */     AccessController.doPrivileged(() -> {
/*     */           Application.loadNativeLibrary();
/*     */           
/*     */           return null;
/*     */         });
/*  48 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("glass.disableSyncRendering")))).booleanValue();
/*     */     
/*  50 */     _initIDs(bool);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isTaskbarApplication = false;
/*     */   
/*     */   private final InvokeLaterDispatcher invokeLaterDispatcher;
/*     */   private Menu appleMenu;
/*     */   static final long BROWSER_PARENT_ID = -1L;
/*     */   
/*     */   MacApplication() {
/*  61 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.embed.isEventThread")))).booleanValue();
/*  62 */     if (!bool) {
/*  63 */       this.invokeLaterDispatcher = new InvokeLaterDispatcher(this);
/*  64 */       this.invokeLaterDispatcher.start();
/*     */     } else {
/*  66 */       this.invokeLaterDispatcher = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runLoop(Runnable paramRunnable) {
/*  76 */     this
/*  77 */       .isTaskbarApplication = ((Boolean)AccessController.<Boolean>doPrivileged(() -> { String str = System.getProperty("glass.taskbarApplication"); return Boolean.valueOf(!"false".equalsIgnoreCase(str)); })).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     ClassLoader classLoader = MacApplication.class.getClassLoader();
/*  83 */     _runLoop(classLoader, paramRunnable, this.isTaskbarApplication);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finishTerminating() {
/*  89 */     _finishTerminating();
/*     */     
/*  91 */     super.finishTerminating();
/*     */   }
/*     */   
/*     */   private void notifyApplicationDidTerminate() {
/*  95 */     setEventThread(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setEventThread() {
/* 100 */     setEventThread(Thread.currentThread());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object _enterNestedEventLoop() {
/* 105 */     if (this.invokeLaterDispatcher != null) {
/* 106 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/*     */     try {
/* 109 */       return _enterNestedEventLoopImpl();
/*     */     } finally {
/* 111 */       if (this.invokeLaterDispatcher != null) {
/* 112 */         this.invokeLaterDispatcher.notifyLeftNestedEventLoop();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _leaveNestedEventLoop(Object paramObject) {
/* 119 */     if (this.invokeLaterDispatcher != null) {
/* 120 */       this.invokeLaterDispatcher.notifyLeavingNestedEventLoop();
/*     */     }
/* 122 */     _leaveNestedEventLoopImpl(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void installAppleMenu(MenuBar paramMenuBar) {
/* 130 */     this.appleMenu = createMenu("Apple");
/*     */     
/* 132 */     MenuItem menuItem1 = createMenuItem("Hide " + getName(), new MenuItem.Callback() {
/*     */           public void action() {
/* 134 */             MacApplication.this._hide();
/*     */           }
/*     */           
/*     */           public void validate() {}
/*     */         },  104, 16);
/* 139 */     this.appleMenu.add(menuItem1);
/*     */     
/* 141 */     MenuItem menuItem2 = createMenuItem("Hide Others", new MenuItem.Callback() {
/*     */           public void action() {
/* 143 */             MacApplication.this._hideOtherApplications();
/*     */           }
/*     */           
/*     */           public void validate() {}
/*     */         },  104, 24);
/* 148 */     this.appleMenu.add(menuItem2);
/*     */     
/* 150 */     MenuItem menuItem3 = createMenuItem("Show All", new MenuItem.Callback() {
/*     */           public void action() {
/* 152 */             MacApplication.this._unhideAllApplications();
/*     */           }
/*     */           
/*     */           public void validate() {}
/*     */         });
/* 157 */     this.appleMenu.add(menuItem3);
/*     */     
/* 159 */     this.appleMenu.add(MenuItem.Separator);
/*     */     
/* 161 */     MenuItem menuItem4 = createMenuItem("Quit " + getName(), new MenuItem.Callback() {
/*     */           public void action() {
/* 163 */             Application.EventHandler eventHandler = MacApplication.this.getEventHandler();
/* 164 */             if (eventHandler != null) {
/* 165 */               eventHandler.handleQuitAction(Application.GetApplication(), System.nanoTime());
/*     */             }
/*     */           }
/*     */           
/*     */           public void validate() {}
/*     */         }113, 16);
/* 171 */     this.appleMenu.add(menuItem4);
/*     */     
/* 173 */     paramMenuBar.add(this.appleMenu);
/*     */   }
/*     */   
/*     */   public Menu getAppleMenu() {
/* 177 */     return this.appleMenu;
/*     */   }
/*     */   
/*     */   public void installDefaultMenus(MenuBar paramMenuBar) {
/* 181 */     installAppleMenu(paramMenuBar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Window createWindow(Window paramWindow, Screen paramScreen, int paramInt) {
/* 188 */     return new MacWindow(paramWindow, paramScreen, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Window createWindow(long paramLong) {
/* 193 */     MacWindow macWindow = new MacWindow(paramLong);
/* 194 */     if (paramLong == -1L)
/*     */     {
/*     */       
/* 197 */       macWindow.setView(createView());
/*     */     }
/* 199 */     return macWindow;
/*     */   }
/*     */   
/*     */   public View createView() {
/* 203 */     return new MacView();
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt) {
/* 207 */     return new MacCursor(paramInt);
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt1, int paramInt2, Pixels paramPixels) {
/* 211 */     return new MacCursor(paramInt1, paramInt2, paramPixels);
/*     */   }
/*     */   
/*     */   protected void staticCursor_setVisible(boolean paramBoolean) {
/* 215 */     MacCursor.setVisible_impl(paramBoolean);
/*     */   }
/*     */   
/*     */   protected Size staticCursor_getBestSize(int paramInt1, int paramInt2) {
/* 219 */     return MacCursor.getBestSize_impl(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/* 223 */     return new MacPixels(paramInt1, paramInt2, paramByteBuffer);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 227 */     return new MacPixels(paramInt1, paramInt2, paramIntBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 232 */     return new MacPixels(paramInt1, paramInt2, paramIntBuffer, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   protected int staticPixels_getNativeFormat() {
/* 236 */     return MacPixels.getNativeFormat_impl();
/*     */   }
/*     */   
/*     */   public GlassRobot createRobot() {
/* 240 */     return new MacRobot();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer createTimer(Runnable paramRunnable) {
/* 247 */     return new MacTimer(paramRunnable);
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMinPeriod() {
/* 251 */     return MacTimer.getMinPeriod_impl();
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMaxPeriod() {
/* 255 */     return MacTimer.getMaxPeriod_impl();
/*     */   }
/*     */   
/*     */   public Accessible createAccessible() {
/* 259 */     return new MacAccessible();
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommonDialogs.FileChooserResult staticCommonDialogs_showFileChooser(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2) {
/* 264 */     return MacCommonDialogs.showFileChooser_impl(paramWindow, paramString1, paramString2, paramString3, paramInt1, paramBoolean, paramArrayOfExtensionFilter, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected File staticCommonDialogs_showFolderChooser(Window paramWindow, String paramString1, String paramString2) {
/* 269 */     return MacCommonDialogs.showFolderChooser_impl(paramWindow, paramString1, paramString2);
/*     */   }
/*     */   
/*     */   protected long staticView_getMultiClickTime() {
/* 273 */     return MacView.getMultiClickTime_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxX() {
/* 277 */     return MacView.getMultiClickMaxX_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxY() {
/* 281 */     return MacView.getMultiClickMaxY_impl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void submitForLaterInvocation(Runnable paramRunnable) {
/* 289 */     _submitForLaterInvocation(paramRunnable);
/*     */   }
/*     */   
/*     */   protected void _invokeLater(Runnable paramRunnable) {
/* 293 */     if (this.invokeLaterDispatcher != null) {
/* 294 */       this.invokeLaterDispatcher.invokeLater(paramRunnable);
/*     */     } else {
/* 296 */       submitForLaterInvocation(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsInputMethods() {
/* 302 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsTransparentWindows() {
/* 307 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean _supportsUnifiedWindows() {
/* 311 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRemoteLayerServerName() {
/* 318 */     return _getRemoteLayerServerName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDataDirectory() {
/* 323 */     checkEventThread();
/* 324 */     String str = _getDataDirectory();
/* 325 */     if (str == null || str.length() == 0) {
/* 326 */       return super.getDataDirectory();
/*     */     }
/* 328 */     return str + str + File.separator + this.name;
/*     */   }
/*     */   
/*     */   private static native void _initIDs(boolean paramBoolean);
/*     */   
/*     */   static native int _getMacKey(int paramInt);
/*     */   
/*     */   native void _runLoop(ClassLoader paramClassLoader, Runnable paramRunnable, boolean paramBoolean);
/*     */   
/*     */   private native void _finishTerminating();
/*     */   
/*     */   private native Object _enterNestedEventLoopImpl();
/*     */   
/*     */   private native void _leaveNestedEventLoopImpl(Object paramObject);
/*     */   
/*     */   private native void _hide();
/*     */   
/*     */   private native void _hideOtherApplications();
/*     */   
/*     */   private native void _unhideAllApplications();
/*     */   
/*     */   protected native double staticScreen_getVideoRefreshPeriod();
/*     */   
/*     */   protected native Screen[] staticScreen_getScreens();
/*     */   
/*     */   protected native void _invokeAndWait(Runnable paramRunnable);
/*     */   
/*     */   private native void _submitForLaterInvocation(Runnable paramRunnable);
/*     */   
/*     */   protected native boolean _supportsSystemMenu();
/*     */   
/*     */   protected native String _getRemoteLayerServerName();
/*     */   
/*     */   private native String _getDataDirectory();
/*     */   
/*     */   protected native int _getKeyCodeForChar(char paramChar);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacApplication.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */