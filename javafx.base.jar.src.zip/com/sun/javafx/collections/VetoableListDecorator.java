/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VetoableListDecorator<E>
/*     */   implements ObservableList<E>
/*     */ {
/*     */   private final ObservableList<E> list;
/*     */   private int modCount;
/*     */   private ListListenerHelper<E> helper;
/*     */   
/*     */   public VetoableListDecorator(ObservableList<E> paramObservableList) {
/*  74 */     this.list = paramObservableList;
/*  75 */     this.list.addListener(paramChange -> ListListenerHelper.fireValueChangedEvent(this.helper, new SourceAdapterChange<>(this, paramChange)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(ListChangeListener<? super E> paramListChangeListener) {
/*  83 */     this.helper = ListListenerHelper.addListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ListChangeListener<? super E> paramListChangeListener) {
/*  88 */     this.helper = ListListenerHelper.removeListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/*  93 */     this.helper = ListListenerHelper.addListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/*  98 */     this.helper = ListListenerHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 103 */     return addAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 108 */     return setAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 113 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { 0, size() });
/*     */     try {
/* 115 */       this.modCount++;
/* 116 */       this.list.setAll(paramCollection);
/* 117 */       return true;
/* 118 */     } catch (Exception exception) {
/* 119 */       this.modCount--;
/* 120 */       throw exception;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeFromList(List<E> paramList, int paramInt, Collection<?> paramCollection, boolean paramBoolean) {
/* 125 */     int[] arrayOfInt = new int[2];
/* 126 */     byte b = -1;
/* 127 */     for (byte b1 = 0; b1 < paramList.size(); b1++) {
/* 128 */       E e = paramList.get(b1);
/* 129 */       if (paramCollection.contains(e) ^ paramBoolean) {
/* 130 */         if (b == -1) {
/* 131 */           arrayOfInt[b + 1] = paramInt + b1;
/* 132 */           arrayOfInt[b + 2] = paramInt + b1 + 1;
/* 133 */           b += 2;
/*     */         }
/* 135 */         else if (arrayOfInt[b - 1] == paramInt + b1) {
/* 136 */           arrayOfInt[b - 1] = paramInt + b1 + 1;
/*     */         } else {
/* 138 */           int[] arrayOfInt1 = new int[arrayOfInt.length + 2];
/* 139 */           System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/* 140 */           arrayOfInt = arrayOfInt1;
/* 141 */           arrayOfInt[b + 1] = paramInt + b1;
/* 142 */           arrayOfInt[b + 2] = paramInt + b1 + 1;
/* 143 */           b += 2;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 148 */     if (b != -1) {
/* 149 */       onProposedChange(Collections.emptyList(), arrayOfInt);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 155 */     return removeAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 160 */     return retainAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 165 */     onProposedChange(Collections.emptyList(), new int[] { paramInt1, paramInt2 });
/*     */     try {
/* 167 */       this.modCount++;
/* 168 */       this.list.remove(paramInt1, paramInt2);
/* 169 */     } catch (Exception exception) {
/* 170 */       this.modCount--;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 176 */     return this.list.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 181 */     return this.list.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 186 */     return this.list.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 191 */     return new VetoableIteratorDecorator(new ModCountAccessorImpl(), this.list.iterator(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 196 */     return this.list.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 201 */     return (T[])this.list.toArray((Object[])paramArrayOfT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E paramE) {
/* 206 */     onProposedChange(Collections.singletonList(paramE), new int[] { size(), size() });
/*     */     try {
/* 208 */       this.modCount++;
/* 209 */       this.list.add(paramE);
/* 210 */       return true;
/* 211 */     } catch (Exception exception) {
/* 212 */       this.modCount--;
/* 213 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 219 */     int i = this.list.indexOf(paramObject);
/* 220 */     if (i != -1) {
/* 221 */       remove(i);
/* 222 */       return true;
/*     */     } 
/* 224 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 229 */     return this.list.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 234 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { size(), size() });
/*     */     try {
/* 236 */       this.modCount++;
/* 237 */       boolean bool = this.list.addAll(paramCollection);
/* 238 */       if (!bool)
/* 239 */         this.modCount--; 
/* 240 */       return bool;
/* 241 */     } catch (Exception exception) {
/* 242 */       this.modCount--;
/* 243 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 249 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { paramInt, paramInt });
/*     */     try {
/* 251 */       this.modCount++;
/* 252 */       boolean bool = this.list.addAll(paramInt, paramCollection);
/* 253 */       if (!bool)
/* 254 */         this.modCount--; 
/* 255 */       return bool;
/* 256 */     } catch (Exception exception) {
/* 257 */       this.modCount--;
/* 258 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 264 */     removeFromList(this, 0, paramCollection, false);
/*     */     try {
/* 266 */       this.modCount++;
/* 267 */       boolean bool = this.list.removeAll(paramCollection);
/* 268 */       if (!bool)
/* 269 */         this.modCount--; 
/* 270 */       return bool;
/* 271 */     } catch (Exception exception) {
/* 272 */       this.modCount--;
/* 273 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 279 */     removeFromList(this, 0, paramCollection, true);
/*     */     try {
/* 281 */       this.modCount++;
/* 282 */       boolean bool = this.list.retainAll(paramCollection);
/* 283 */       if (!bool)
/* 284 */         this.modCount--; 
/* 285 */       return bool;
/* 286 */     } catch (Exception exception) {
/* 287 */       this.modCount--;
/* 288 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 294 */     onProposedChange(Collections.emptyList(), new int[] { 0, size() });
/*     */     try {
/* 296 */       this.modCount++;
/* 297 */       this.list.clear();
/* 298 */     } catch (Exception exception) {
/* 299 */       this.modCount--;
/* 300 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 306 */     return this.list.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 311 */     onProposedChange(Collections.singletonList(paramE), new int[] { paramInt, paramInt + 1 });
/* 312 */     return this.list.set(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 317 */     onProposedChange(Collections.singletonList(paramE), new int[] { paramInt, paramInt });
/*     */     try {
/* 319 */       this.modCount++;
/* 320 */       this.list.add(paramInt, paramE);
/* 321 */     } catch (Exception exception) {
/* 322 */       this.modCount--;
/* 323 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int paramInt) {
/* 329 */     onProposedChange(Collections.emptyList(), new int[] { paramInt, paramInt + 1 });
/*     */     try {
/* 331 */       this.modCount++;
/* 332 */       return this.list.remove(paramInt);
/*     */     }
/* 334 */     catch (Exception exception) {
/* 335 */       this.modCount--;
/* 336 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 342 */     return this.list.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 347 */     return this.list.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 352 */     return new VetoableListIteratorDecorator(new ModCountAccessorImpl(), this.list.listIterator(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int paramInt) {
/* 357 */     return new VetoableListIteratorDecorator(new ModCountAccessorImpl(), this.list.listIterator(paramInt), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int paramInt1, int paramInt2) {
/* 362 */     return new VetoableSubListDecorator(new ModCountAccessorImpl(), this.list.subList(paramInt1, paramInt2), paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 367 */     return this.list.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 372 */     return this.list.equals(paramObject);
/*     */   }
/*     */   protected abstract void onProposedChange(List<E> paramList, int... paramVarArgs);
/*     */   
/*     */   public int hashCode() {
/* 377 */     return this.list.hashCode();
/*     */   }
/*     */   private static interface ModCountAccessor {
/*     */     int get();
/*     */     int incrementAndGet();
/*     */     
/*     */     int decrementAndGet(); }
/*     */   
/*     */   private class VetoableSubListDecorator implements List<E> { private final List<E> subList;
/*     */     
/*     */     public VetoableSubListDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, List<E> param1List, int param1Int) {
/* 388 */       this.modCountAccessor = param1ModCountAccessor;
/* 389 */       this.modCount = param1ModCountAccessor.get();
/* 390 */       this.subList = param1List;
/* 391 */       this.offset = param1Int;
/*     */     }
/*     */     private final int offset; private final VetoableListDecorator.ModCountAccessor modCountAccessor;
/*     */     private int modCount;
/*     */     
/*     */     public int size() {
/* 397 */       checkForComodification();
/* 398 */       return this.subList.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 403 */       checkForComodification();
/* 404 */       return this.subList.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 409 */       checkForComodification();
/* 410 */       return this.subList.contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<E> iterator() {
/* 415 */       checkForComodification();
/* 416 */       return new VetoableListDecorator.VetoableIteratorDecorator(new ModCountAccessorImplSub(), this.subList.iterator(), this.offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 421 */       checkForComodification();
/* 422 */       return this.subList.toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 427 */       checkForComodification();
/* 428 */       return this.subList.toArray(param1ArrayOfT);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(E param1E) {
/* 433 */       checkForComodification();
/* 434 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + size(), this.offset + size() });
/*     */       try {
/* 436 */         incrementModCount();
/* 437 */         this.subList.add(param1E);
/* 438 */       } catch (Exception exception) {
/* 439 */         decrementModCount();
/* 440 */         throw exception;
/*     */       } 
/* 442 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 447 */       checkForComodification();
/* 448 */       int i = indexOf(param1Object);
/* 449 */       if (i != -1) {
/* 450 */         remove(i);
/* 451 */         return true;
/*     */       } 
/* 453 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 458 */       checkForComodification();
/* 459 */       return this.subList.containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 464 */       checkForComodification();
/* 465 */       VetoableListDecorator.this.onProposedChange(Collections.unmodifiableList(new ArrayList(param1Collection)), new int[] { this.offset + size(), this.offset + size() });
/*     */       try {
/* 467 */         incrementModCount();
/* 468 */         boolean bool = this.subList.addAll(param1Collection);
/* 469 */         if (!bool)
/* 470 */           decrementModCount(); 
/* 471 */         return bool;
/* 472 */       } catch (Exception exception) {
/* 473 */         decrementModCount();
/* 474 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(int param1Int, Collection<? extends E> param1Collection) {
/* 480 */       checkForComodification();
/* 481 */       VetoableListDecorator.this.onProposedChange(Collections.unmodifiableList(new ArrayList(param1Collection)), new int[] { this.offset + param1Int, this.offset + param1Int });
/*     */       try {
/* 483 */         incrementModCount();
/* 484 */         boolean bool = this.subList.addAll(param1Int, param1Collection);
/* 485 */         if (!bool)
/* 486 */           decrementModCount(); 
/* 487 */         return bool;
/* 488 */       } catch (Exception exception) {
/* 489 */         decrementModCount();
/* 490 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 496 */       checkForComodification();
/* 497 */       VetoableListDecorator.this.removeFromList(this, this.offset, param1Collection, false);
/*     */       try {
/* 499 */         incrementModCount();
/* 500 */         boolean bool = this.subList.removeAll(param1Collection);
/* 501 */         if (!bool)
/* 502 */           decrementModCount(); 
/* 503 */         return bool;
/* 504 */       } catch (Exception exception) {
/* 505 */         decrementModCount();
/* 506 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 512 */       checkForComodification();
/* 513 */       VetoableListDecorator.this.removeFromList(this, this.offset, param1Collection, true);
/*     */       try {
/* 515 */         incrementModCount();
/* 516 */         boolean bool = this.subList.retainAll(param1Collection);
/* 517 */         if (!bool)
/* 518 */           decrementModCount(); 
/* 519 */         return bool;
/* 520 */       } catch (Exception exception) {
/* 521 */         decrementModCount();
/* 522 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 528 */       checkForComodification();
/* 529 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset, this.offset + size() });
/*     */       try {
/* 531 */         incrementModCount();
/* 532 */         this.subList.clear();
/* 533 */       } catch (Exception exception) {
/* 534 */         decrementModCount();
/* 535 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public E get(int param1Int) {
/* 541 */       checkForComodification();
/* 542 */       return this.subList.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public E set(int param1Int, E param1E) {
/* 547 */       checkForComodification();
/* 548 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + param1Int, this.offset + param1Int + 1 });
/* 549 */       return this.subList.set(param1Int, param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(int param1Int, E param1E) {
/* 554 */       checkForComodification();
/* 555 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + param1Int, this.offset + param1Int });
/*     */       try {
/* 557 */         incrementModCount();
/* 558 */         this.subList.add(param1Int, param1E);
/* 559 */       } catch (Exception exception) {
/* 560 */         decrementModCount();
/* 561 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public E remove(int param1Int) {
/* 567 */       checkForComodification();
/* 568 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset + param1Int, this.offset + param1Int + 1 });
/*     */       try {
/* 570 */         incrementModCount();
/* 571 */         return this.subList.remove(param1Int);
/*     */       }
/* 573 */       catch (Exception exception) {
/* 574 */         decrementModCount();
/* 575 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int indexOf(Object param1Object) {
/* 582 */       checkForComodification();
/* 583 */       return this.subList.indexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int lastIndexOf(Object param1Object) {
/* 588 */       checkForComodification();
/* 589 */       return this.subList.lastIndexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator() {
/* 594 */       checkForComodification();
/* 595 */       return new VetoableListDecorator.VetoableListIteratorDecorator(new ModCountAccessorImplSub(), this.subList
/* 596 */           .listIterator(), this.offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator(int param1Int) {
/* 601 */       checkForComodification();
/* 602 */       return new VetoableListDecorator.VetoableListIteratorDecorator(new ModCountAccessorImplSub(), this.subList
/* 603 */           .listIterator(param1Int), this.offset + param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<E> subList(int param1Int1, int param1Int2) {
/* 608 */       checkForComodification();
/* 609 */       return new VetoableSubListDecorator(new ModCountAccessorImplSub(), this.subList
/* 610 */           .subList(param1Int1, param1Int2), this.offset + param1Int1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 615 */       checkForComodification();
/* 616 */       return this.subList.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 621 */       checkForComodification();
/* 622 */       return this.subList.equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 627 */       checkForComodification();
/* 628 */       return this.subList.hashCode();
/*     */     }
/*     */     
/*     */     private void checkForComodification() {
/* 632 */       if (this.modCount != this.modCountAccessor.get()) {
/* 633 */         throw new ConcurrentModificationException();
/*     */       }
/*     */     }
/*     */     
/*     */     private void incrementModCount() {
/* 638 */       this.modCount = this.modCountAccessor.incrementAndGet();
/*     */     }
/*     */     
/*     */     private void decrementModCount() {
/* 642 */       this.modCount = this.modCountAccessor.decrementAndGet();
/*     */     }
/*     */     
/*     */     private class ModCountAccessorImplSub implements VetoableListDecorator.ModCountAccessor {
/*     */       private ModCountAccessorImplSub() {}
/*     */       
/*     */       public int get() {
/* 649 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount;
/*     */       }
/*     */ 
/*     */       
/*     */       public int incrementAndGet() {
/* 654 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount = VetoableListDecorator.VetoableSubListDecorator.this.modCountAccessor.incrementAndGet();
/*     */       }
/*     */ 
/*     */       
/*     */       public int decrementAndGet() {
/* 659 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount = VetoableListDecorator.VetoableSubListDecorator.this.modCountAccessor.decrementAndGet();
/*     */       }
/*     */     } }
/*     */ 
/*     */   
/*     */   private class VetoableIteratorDecorator
/*     */     implements Iterator<E> {
/*     */     private final Iterator<E> it;
/*     */     private final VetoableListDecorator.ModCountAccessor modCountAccessor;
/*     */     private int modCount;
/*     */     protected final int offset;
/*     */     protected int cursor;
/*     */     protected int lastReturned;
/*     */     
/*     */     public VetoableIteratorDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, Iterator<E> param1Iterator, int param1Int) {
/* 674 */       this.modCountAccessor = param1ModCountAccessor;
/* 675 */       this.modCount = param1ModCountAccessor.get();
/* 676 */       this.it = param1Iterator;
/* 677 */       this.offset = param1Int;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 682 */       checkForComodification();
/* 683 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 688 */       checkForComodification();
/* 689 */       E e = this.it.next();
/* 690 */       this.lastReturned = this.cursor++;
/* 691 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 696 */       checkForComodification();
/* 697 */       if (this.lastReturned == -1) {
/* 698 */         throw new IllegalStateException();
/*     */       }
/* 700 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset + this.lastReturned, this.offset + this.lastReturned + 1 });
/*     */       try {
/* 702 */         incrementModCount();
/* 703 */         this.it.remove();
/* 704 */       } catch (Exception exception) {
/* 705 */         decrementModCount();
/* 706 */         throw exception;
/*     */       } 
/* 708 */       this.lastReturned = -1;
/* 709 */       this.cursor--;
/*     */     }
/*     */     
/*     */     protected void checkForComodification() {
/* 713 */       if (this.modCount != this.modCountAccessor.get()) {
/* 714 */         throw new ConcurrentModificationException();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void incrementModCount() {
/* 719 */       this.modCount = this.modCountAccessor.incrementAndGet();
/*     */     }
/*     */     
/*     */     protected void decrementModCount() {
/* 723 */       this.modCount = this.modCountAccessor.decrementAndGet();
/*     */     }
/*     */   }
/*     */   
/*     */   private class VetoableListIteratorDecorator
/*     */     extends VetoableIteratorDecorator implements ListIterator<E> {
/*     */     private final ListIterator<E> lit;
/*     */     
/*     */     public VetoableListIteratorDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, ListIterator<E> param1ListIterator, int param1Int) {
/* 732 */       super(param1ModCountAccessor, param1ListIterator, param1Int);
/* 733 */       this.lit = param1ListIterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasPrevious() {
/* 738 */       checkForComodification();
/* 739 */       return this.lit.hasPrevious();
/*     */     }
/*     */ 
/*     */     
/*     */     public E previous() {
/* 744 */       checkForComodification();
/* 745 */       E e = this.lit.previous();
/* 746 */       this.lastReturned = --this.cursor;
/* 747 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public int nextIndex() {
/* 752 */       checkForComodification();
/* 753 */       return this.lit.nextIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     public int previousIndex() {
/* 758 */       checkForComodification();
/* 759 */       return this.lit.previousIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(E param1E) {
/* 764 */       checkForComodification();
/* 765 */       if (this.lastReturned == -1) {
/* 766 */         throw new IllegalStateException();
/*     */       }
/* 768 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + this.lastReturned, this.offset + this.lastReturned + 1 });
/* 769 */       this.lit.set(param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(E param1E) {
/* 774 */       checkForComodification();
/* 775 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + this.cursor, this.offset + this.cursor });
/*     */       try {
/* 777 */         incrementModCount();
/* 778 */         this.lit.add(param1E);
/* 779 */       } catch (Exception exception) {
/* 780 */         decrementModCount();
/* 781 */         throw exception;
/*     */       } 
/* 783 */       this.cursor++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ModCountAccessorImpl
/*     */     implements ModCountAccessor
/*     */   {
/*     */     public int get() {
/* 794 */       return VetoableListDecorator.this.modCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public int incrementAndGet() {
/* 799 */       return ++VetoableListDecorator.this.modCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public int decrementAndGet() {
/* 804 */       return --VetoableListDecorator.this.modCount;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\collections\VetoableListDecorator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */