/*     */ package com.sun.javafx.iio.jpeg;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.common.ImageLoaderImpl;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JPEGImageLoader
/*     */   extends ImageLoaderImpl
/*     */ {
/*     */   public static final int JCS_UNKNOWN = 0;
/*     */   public static final int JCS_GRAYSCALE = 1;
/*     */   public static final int JCS_RGB = 2;
/*     */   public static final int JCS_YCbCr = 3;
/*     */   public static final int JCS_CMYK = 4;
/*     */   public static final int JCS_YCC = 5;
/*     */   public static final int JCS_RGBA = 6;
/*     */   public static final int JCS_YCbCrA = 7;
/*     */   public static final int JCS_YCCA = 10;
/*     */   public static final int JCS_YCCK = 11;
/*  61 */   private long structPointer = 0L;
/*     */ 
/*     */   
/*     */   private int inWidth;
/*     */ 
/*     */   
/*     */   private int inHeight;
/*     */ 
/*     */   
/*     */   private int inColorSpaceCode;
/*     */ 
/*     */   
/*     */   private int outColorSpaceCode;
/*     */ 
/*     */   
/*     */   private byte[] iccData;
/*     */   
/*     */   private int outWidth;
/*     */   
/*     */   private int outHeight;
/*     */   
/*     */   private ImageStorage.ImageType outImageType;
/*     */   
/*     */   private boolean isDisposed = false;
/*     */   
/*  86 */   private Lock accessLock = new Lock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 106 */     AccessController.doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_iio");
/*     */           return null;
/*     */         });
/* 110 */     initJPEGMethodIDs(InputStream.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInputAttributes(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte) {
/* 122 */     this.inWidth = paramInt1;
/* 123 */     this.inHeight = paramInt2;
/* 124 */     this.inColorSpaceCode = paramInt3;
/* 125 */     this.outColorSpaceCode = paramInt4;
/* 126 */     this.iccData = paramArrayOfbyte;
/*     */ 
/*     */     
/* 129 */     switch (paramInt4) {
/*     */       case 1:
/* 131 */         this.outImageType = ImageStorage.ImageType.GRAY;
/*     */         return;
/*     */       case 2:
/*     */       case 3:
/*     */       case 5:
/* 136 */         this.outImageType = ImageStorage.ImageType.RGB;
/*     */         return;
/*     */       case 4:
/*     */       case 6:
/*     */       case 7:
/*     */       case 10:
/*     */       case 11:
/* 143 */         this.outImageType = ImageStorage.ImageType.RGBA_PRE;
/*     */         return;
/*     */       case 0:
/* 146 */         switch (paramInt5) {
/*     */           case 1:
/* 148 */             this.outImageType = ImageStorage.ImageType.GRAY;
/*     */             return;
/*     */           case 3:
/* 151 */             this.outImageType = ImageStorage.ImageType.RGB;
/*     */             return;
/*     */           case 4:
/* 154 */             this.outImageType = ImageStorage.ImageType.RGBA_PRE;
/*     */             return;
/*     */         } 
/*     */         assert false;
/*     */         return;
/*     */     } 
/*     */     assert false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setOutputAttributes(int paramInt1, int paramInt2) {
/* 170 */     this.outWidth = paramInt1;
/* 171 */     this.outHeight = paramInt2;
/*     */   }
/*     */   
/*     */   private void updateImageProgress(int paramInt) {
/* 175 */     updateImageProgress(100.0F * paramInt / this.outHeight);
/*     */   }
/*     */   
/*     */   JPEGImageLoader(InputStream paramInputStream) throws IOException {
/* 179 */     super(JPEGDescriptor.getInstance());
/* 180 */     if (paramInputStream == null) {
/* 181 */       throw new IllegalArgumentException("input == null!");
/*     */     }
/*     */     
/*     */     try {
/* 185 */       this.structPointer = initDecompressor(paramInputStream);
/* 186 */     } catch (IOException iOException) {
/* 187 */       dispose();
/* 188 */       throw iOException;
/*     */     } 
/*     */     
/* 191 */     if (this.structPointer == 0L) {
/* 192 */       throw new IOException("Unable to initialize JPEG decompressor");
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void dispose() {
/* 197 */     if (!this.accessLock.isLocked() && !this.isDisposed && this.structPointer != 0L) {
/* 198 */       this.isDisposed = true;
/* 199 */       disposeNative(this.structPointer);
/* 200 */       this.structPointer = 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void finalize() {
/* 205 */     dispose();
/*     */   }
/*     */   public ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/*     */     int i;
/* 209 */     if (paramInt1 != 0) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     this.accessLock.lock();
/*     */ 
/*     */     
/* 216 */     int[] arrayOfInt = ImageTools.computeDimensions(this.inWidth, this.inHeight, paramInt2, paramInt3, paramBoolean1);
/* 217 */     paramInt2 = arrayOfInt[0];
/* 218 */     paramInt3 = arrayOfInt[1];
/*     */ 
/*     */ 
/*     */     
/* 222 */     ImageMetadata imageMetadata = new ImageMetadata(null, Boolean.valueOf(true), null, null, null, null, null, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), null, null, null);
/*     */     
/* 224 */     updateImageMetadata(imageMetadata);
/*     */     
/* 226 */     ByteBuffer byteBuffer = null;
/*     */ 
/*     */     
/*     */     try {
/* 230 */       i = startDecompression(this.structPointer, this.outColorSpaceCode, paramInt2, paramInt3);
/*     */ 
/*     */       
/* 233 */       if (this.outWidth < 0 || this.outHeight < 0 || i < 0) {
/* 234 */         throw new IOException("negative dimension.");
/*     */       }
/* 236 */       if (this.outWidth > Integer.MAX_VALUE / i) {
/* 237 */         throw new IOException("bad width.");
/*     */       }
/* 239 */       int j = this.outWidth * i;
/* 240 */       if (j > Integer.MAX_VALUE / this.outHeight) {
/* 241 */         throw new IOException("bad height.");
/*     */       }
/*     */       
/* 244 */       byte[] arrayOfByte = new byte[j * this.outHeight];
/* 245 */       byteBuffer = ByteBuffer.wrap(arrayOfByte);
/* 246 */       decompressIndirect(this.structPointer, (this.listeners != null && !this.listeners.isEmpty()), byteBuffer.array());
/* 247 */     } catch (IOException iOException) {
/* 248 */       throw iOException;
/* 249 */     } catch (Throwable throwable) {
/* 250 */       throw new IOException(throwable);
/*     */     } finally {
/* 252 */       this.accessLock.unlock();
/* 253 */       dispose();
/*     */     } 
/*     */     
/* 256 */     if (byteBuffer == null) {
/* 257 */       throw new IOException("Error decompressing JPEG stream!");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     if (this.outWidth != paramInt2 || this.outHeight != paramInt3) {
/* 266 */       byteBuffer = ImageTools.scaleImage(byteBuffer, this.outWidth, this.outHeight, i, paramInt2, paramInt3, paramBoolean2);
/*     */     }
/*     */ 
/*     */     
/* 270 */     return new ImageFrame(this.outImageType, byteBuffer, paramInt2, paramInt3, paramInt2 * i, null, imageMetadata);
/*     */   }
/*     */   private static native void initJPEGMethodIDs(Class paramClass);
/*     */   private static native void disposeNative(long paramLong);
/*     */   
/*     */   private native long initDecompressor(InputStream paramInputStream) throws IOException;
/*     */   
/*     */   private native int startDecompression(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   private native boolean decompressIndirect(long paramLong, boolean paramBoolean, byte[] paramArrayOfbyte) throws IOException;
/*     */   
/*     */   private static class Lock { public synchronized boolean isLocked() {
/* 282 */       return this.locked;
/*     */     }
/*     */     private boolean locked = false;
/*     */     public synchronized void lock() {
/* 286 */       if (this.locked) {
/* 287 */         throw new IllegalStateException("Recursive loading is not allowed.");
/*     */       }
/* 289 */       this.locked = true;
/*     */     }
/*     */     
/*     */     public synchronized void unlock() {
/* 293 */       if (!this.locked) {
/* 294 */         throw new IllegalStateException("Invalid loader state.");
/*     */       }
/* 296 */       this.locked = false;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\jpeg\JPEGImageLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */