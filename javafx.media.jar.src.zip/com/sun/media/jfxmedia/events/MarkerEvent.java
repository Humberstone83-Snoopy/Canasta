/*    */ package com.sun.media.jfxmedia.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   private String markerName;
/*    */   private double presentationTime;
/*    */   
/*    */   public MarkerEvent(String paramString, double paramDouble) {
/* 48 */     if (paramString == null)
/* 49 */       throw new IllegalArgumentException("name == null!"); 
/* 50 */     if (paramDouble < 0.0D) {
/* 51 */       throw new IllegalArgumentException("time < 0.0!");
/*    */     }
/*    */     
/* 54 */     this.markerName = paramString;
/* 55 */     this.presentationTime = paramDouble;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMarkerName() {
/* 65 */     return this.markerName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getPresentationTime() {
/* 75 */     return this.presentationTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\MarkerEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */