/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Ref
/*    */ {
/* 33 */   private int count = 0;
/* 34 */   private final int id = WCGraphicsManager.getGraphicsManager().createID();
/*    */ 
/*    */   
/*    */   public synchronized void ref() {
/* 38 */     if (this.count == 0) {
/* 39 */       WCGraphicsManager.getGraphicsManager().ref(this);
/*    */     }
/* 41 */     this.count++;
/*    */   }
/*    */   
/*    */   public synchronized void deref() {
/* 45 */     if (this.count == 0) {
/* 46 */       throw new IllegalStateException("Object  " + this.id + " has no references.");
/*    */     }
/* 48 */     this.count--;
/* 49 */     if (this.count == 0) {
/* 50 */       WCGraphicsManager.getGraphicsManager().deref(this);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean hasRefs() {
/* 55 */     return (this.count > 0);
/*    */   }
/*    */   
/*    */   public int getID() {
/* 59 */     return this.id;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\Ref.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */