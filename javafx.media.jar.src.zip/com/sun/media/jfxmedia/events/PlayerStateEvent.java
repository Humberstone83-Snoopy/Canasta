/*     */ package com.sun.media.jfxmedia.events;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerStateEvent
/*     */   extends PlayerEvent
/*     */ {
/*     */   private PlayerState playerState;
/*     */   private double playerTime;
/*     */   private String message;
/*     */   
/*     */   public enum PlayerState
/*     */   {
/*  36 */     UNKNOWN, READY, PLAYING, PAUSED, STOPPED, STALLED, FINISHED, HALTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerStateEvent(PlayerState paramPlayerState, double paramDouble) {
/*  52 */     if (paramPlayerState == null)
/*  53 */       throw new IllegalArgumentException("state == null!"); 
/*  54 */     if (paramDouble < 0.0D) {
/*  55 */       throw new IllegalArgumentException("time < 0.0!");
/*     */     }
/*     */     
/*  58 */     this.playerState = paramPlayerState;
/*  59 */     this.playerTime = paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerStateEvent(PlayerState paramPlayerState, double paramDouble, String paramString) {
/*  72 */     this(paramPlayerState, paramDouble);
/*  73 */     this.message = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerState getState() {
/*  82 */     return this.playerState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getTime() {
/*  91 */     return this.playerTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 100 */     return this.message;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\PlayerStateEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */