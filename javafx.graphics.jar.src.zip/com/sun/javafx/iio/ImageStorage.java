/*     */ package com.sun.javafx.iio;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.iio.bmp.BMPImageLoaderFactory;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import com.sun.javafx.iio.gif.GIFImageLoaderFactory;
/*     */ import com.sun.javafx.iio.ios.IosImageLoaderFactory;
/*     */ import com.sun.javafx.iio.jpeg.JPEGImageLoaderFactory;
/*     */ import com.sun.javafx.iio.png.PNGImageLoaderFactory;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.SequenceInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageStorage
/*     */ {
/*     */   private static final HashMap<ImageFormatDescription.Signature, ImageLoaderFactory> loaderFactoriesBySignature;
/*     */   private static final ImageLoaderFactory[] loaderFactories;
/*     */   
/*     */   public enum ImageType
/*     */   {
/*  59 */     GRAY,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     GRAY_ALPHA,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     GRAY_ALPHA_PRE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     PALETTE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     PALETTE_ALPHA,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     PALETTE_ALPHA_PRE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     PALETTE_TRANS,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     RGB,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     RGBA,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     RGBA_PRE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private static final boolean isIOS = PlatformUtil.isIOS();
/*     */   
/*     */   private static int maxSignatureLength;
/*     */   
/*     */   static {
/* 126 */     if (isIOS) {
/*     */ 
/*     */ 
/*     */       
/* 130 */       loaderFactories = new ImageLoaderFactory[] { IosImageLoaderFactory.getInstance() };
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 137 */       loaderFactories = new ImageLoaderFactory[] { GIFImageLoaderFactory.getInstance(), JPEGImageLoaderFactory.getInstance(), PNGImageLoaderFactory.getInstance(), BMPImageLoaderFactory.getInstance() };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     loaderFactoriesBySignature = new HashMap<>(loaderFactories.length);
/*     */     
/* 145 */     for (byte b = 0; b < loaderFactories.length; b++) {
/* 146 */       addImageLoaderFactory(loaderFactories[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public static ImageFormatDescription[] getSupportedDescriptions() {
/* 151 */     ImageFormatDescription[] arrayOfImageFormatDescription = new ImageFormatDescription[loaderFactories.length];
/* 152 */     for (byte b = 0; b < loaderFactories.length; b++) {
/* 153 */       arrayOfImageFormatDescription[b] = loaderFactories[b].getFormatDescription();
/*     */     }
/* 155 */     return arrayOfImageFormatDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getNumBands(ImageType paramImageType) {
/* 165 */     byte b = -1;
/* 166 */     switch (paramImageType) {
/*     */       case GRAY:
/*     */       case PALETTE:
/*     */       case PALETTE_ALPHA:
/*     */       case PALETTE_ALPHA_PRE:
/*     */       case PALETTE_TRANS:
/* 172 */         b = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 188 */         return b;case GRAY_ALPHA: case GRAY_ALPHA_PRE: b = 2; return b;case RGB: b = 3; return b;case RGBA: case RGBA_PRE: b = 4; return b;
/*     */     } 
/*     */     throw new IllegalArgumentException("Unknown ImageType " + paramImageType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addImageLoaderFactory(ImageLoaderFactory paramImageLoaderFactory) {
/* 199 */     ImageFormatDescription imageFormatDescription = paramImageLoaderFactory.getFormatDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     for (ImageFormatDescription.Signature signature : imageFormatDescription.getSignatures()) {
/* 206 */       loaderFactoriesBySignature.put(signature, paramImageLoaderFactory);
/*     */     }
/*     */ 
/*     */     
/* 210 */     synchronized (ImageStorage.class) {
/* 211 */       maxSignatureLength = -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageFrame[] loadAll(InputStream paramInputStream, ImageLoadListener paramImageLoadListener, double paramDouble1, double paramDouble2, boolean paramBoolean1, float paramFloat, boolean paramBoolean2) throws ImageStorageException {
/* 259 */     ImageLoader imageLoader = null;
/*     */     try {
/* 261 */       if (isIOS) {
/*     */ 
/*     */         
/* 264 */         imageLoader = IosImageLoaderFactory.getInstance().createImageLoader(paramInputStream);
/*     */       } else {
/* 266 */         imageLoader = getLoaderBySignature(paramInputStream, paramImageLoadListener);
/*     */       } 
/* 268 */     } catch (IOException iOException) {
/* 269 */       throw new ImageStorageException(iOException.getMessage(), iOException);
/*     */     } 
/*     */     
/* 272 */     ImageFrame[] arrayOfImageFrame = null;
/* 273 */     if (imageLoader != null) {
/* 274 */       arrayOfImageFrame = loadAll(imageLoader, paramDouble1, paramDouble2, paramBoolean1, paramFloat, paramBoolean2);
/*     */     } else {
/* 276 */       throw new ImageStorageException("No loader for image data");
/*     */     } 
/*     */     
/* 279 */     return arrayOfImageFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageFrame[] loadAll(String paramString, ImageLoadListener paramImageLoadListener, double paramDouble1, double paramDouble2, boolean paramBoolean1, float paramFloat, boolean paramBoolean2) throws ImageStorageException {
/* 290 */     if (paramString == null || paramString.isEmpty()) {
/* 291 */       throw new ImageStorageException("URL can't be null or empty");
/*     */     }
/*     */     
/* 294 */     ImageFrame[] arrayOfImageFrame = null;
/* 295 */     InputStream inputStream = null;
/* 296 */     ImageLoader imageLoader = null;
/*     */     
/*     */     try {
/* 299 */       float f = 1.0F;
/*     */       try {
/* 301 */         if (paramFloat >= 1.5F) {
/*     */           
/*     */           try {
/* 304 */             String str = ImageTools.getScaledImageName(paramString);
/* 305 */             inputStream = ImageTools.createInputStream(str);
/* 306 */             f = 2.0F;
/* 307 */           } catch (IOException iOException) {}
/*     */         }
/*     */         
/* 310 */         if (inputStream == null) {
/* 311 */           inputStream = ImageTools.createInputStream(paramString);
/*     */         }
/*     */         
/* 314 */         if (isIOS) {
/* 315 */           imageLoader = IosImageLoaderFactory.getInstance().createImageLoader(inputStream);
/*     */         } else {
/* 317 */           imageLoader = getLoaderBySignature(inputStream, paramImageLoadListener);
/*     */         } 
/* 319 */       } catch (IOException iOException) {
/* 320 */         throw new ImageStorageException(iOException.getMessage(), iOException);
/*     */       } 
/*     */       
/* 323 */       if (imageLoader != null) {
/* 324 */         arrayOfImageFrame = loadAll(imageLoader, paramDouble1, paramDouble2, paramBoolean1, f, paramBoolean2);
/*     */       } else {
/* 326 */         throw new ImageStorageException("No loader for image data");
/*     */       } 
/*     */     } finally {
/*     */       try {
/* 330 */         if (inputStream != null) {
/* 331 */           inputStream.close();
/*     */         }
/* 333 */       } catch (IOException iOException) {}
/*     */     } 
/*     */ 
/*     */     
/* 337 */     return arrayOfImageFrame;
/*     */   }
/*     */   
/*     */   private static synchronized int getMaxSignatureLength() {
/* 341 */     if (maxSignatureLength < 0) {
/* 342 */       maxSignatureLength = 0;
/*     */       
/* 344 */       for (ImageFormatDescription.Signature signature : loaderFactoriesBySignature.keySet()) {
/* 345 */         int i = signature.getLength();
/* 346 */         if (maxSignatureLength < i) {
/* 347 */           maxSignatureLength = i;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 352 */     return maxSignatureLength;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImageFrame[] loadAll(ImageLoader paramImageLoader, double paramDouble1, double paramDouble2, boolean paramBoolean1, float paramFloat, boolean paramBoolean2) throws ImageStorageException {
/* 358 */     ImageFrame[] arrayOfImageFrame = null;
/* 359 */     ArrayList<ImageFrame> arrayList = new ArrayList();
/* 360 */     byte b = 0;
/* 361 */     ImageFrame imageFrame = null;
/* 362 */     int i = (int)Math.round(paramDouble1 * paramFloat);
/* 363 */     int j = (int)Math.round(paramDouble2 * paramFloat);
/*     */     while (true) {
/*     */       try {
/* 366 */         imageFrame = paramImageLoader.load(b++, i, j, paramBoolean1, paramBoolean2);
/* 367 */       } catch (Exception exception) {
/*     */         
/* 369 */         if (b > 1) {
/*     */           break;
/*     */         }
/* 372 */         throw new ImageStorageException(exception.getMessage(), exception);
/*     */       } 
/*     */       
/* 375 */       if (imageFrame != null) {
/* 376 */         imageFrame.setPixelScale(paramFloat);
/* 377 */         arrayList.add(imageFrame);
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 382 */     int k = arrayList.size();
/* 383 */     if (k > 0) {
/* 384 */       arrayOfImageFrame = new ImageFrame[k];
/* 385 */       arrayList.toArray(arrayOfImageFrame);
/*     */     } 
/* 387 */     return arrayOfImageFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImageLoader getLoaderBySignature(InputStream paramInputStream, ImageLoadListener paramImageLoadListener) throws IOException {
/* 413 */     byte[] arrayOfByte = new byte[getMaxSignatureLength()];
/* 414 */     ImageTools.readFully(paramInputStream, arrayOfByte);
/*     */ 
/*     */     
/* 417 */     for (Map.Entry<ImageFormatDescription.Signature, ImageLoaderFactory> entry : loaderFactoriesBySignature.entrySet()) {
/* 418 */       if (((ImageFormatDescription.Signature)entry.getKey()).matches(arrayOfByte)) {
/* 419 */         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
/* 420 */         SequenceInputStream sequenceInputStream = new SequenceInputStream(byteArrayInputStream, paramInputStream);
/* 421 */         ImageLoader imageLoader = ((ImageLoaderFactory)entry.getValue()).createImageLoader(sequenceInputStream);
/* 422 */         if (paramImageLoadListener != null) {
/* 423 */           imageLoader.addListener(paramImageLoadListener);
/*     */         }
/*     */         
/* 426 */         return imageLoader;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 431 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageStorage.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */