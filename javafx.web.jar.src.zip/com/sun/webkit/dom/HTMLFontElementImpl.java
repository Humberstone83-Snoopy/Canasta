/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLFontElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLFontElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLFontElement
/*    */ {
/*    */   HTMLFontElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLFontElement getImpl(long paramLong) {
/* 36 */     return (HTMLFontElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getColorImpl(long paramLong);
/*    */   
/*    */   public String getColor() {
/* 42 */     return getColorImpl(getPeer());
/*    */   }
/*    */   static native void setColorImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setColor(String paramString) {
/* 47 */     setColorImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getFace() {
/* 52 */     return getFaceImpl(getPeer());
/*    */   }
/*    */   static native String getFaceImpl(long paramLong);
/*    */   
/*    */   public void setFace(String paramString) {
/* 57 */     setFaceImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setFaceImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getSize() {
/* 62 */     return getSizeImpl(getPeer());
/*    */   }
/*    */   static native String getSizeImpl(long paramLong);
/*    */   
/*    */   public void setSize(String paramString) {
/* 67 */     setSizeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setSizeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLFontElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */