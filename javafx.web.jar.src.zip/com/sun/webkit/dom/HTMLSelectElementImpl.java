/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLElement;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ import org.w3c.dom.html.HTMLSelectElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLSelectElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLSelectElement
/*     */ {
/*     */   HTMLSelectElementImpl(long paramLong) {
/*  38 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLSelectElement getImpl(long paramLong) {
/*  42 */     return (HTMLSelectElement)create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutofocus() {
/*  48 */     return getAutofocusImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutofocus(boolean paramBoolean) {
/*  53 */     setAutofocusImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDisabled() {
/*  58 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  63 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLFormElement getForm() {
/*  68 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getMultiple() {
/*  73 */     return getMultipleImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMultiple(boolean paramBoolean) {
/*  78 */     setMultipleImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  83 */     return getNameImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/*  88 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getRequired() {
/*  93 */     return getRequiredImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRequired(boolean paramBoolean) {
/*  98 */     setRequiredImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 103 */     return getSizeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSize(int paramInt) {
/* 108 */     setSizeImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/* 113 */     return getTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLOptionsCollectionImpl getOptions() {
/* 118 */     return HTMLOptionsCollectionImpl.getImpl(getOptionsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 123 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLCollection getSelectedOptions() {
/* 128 */     return HTMLCollectionImpl.getImpl(getSelectedOptionsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSelectedIndex() {
/* 133 */     return getSelectedIndexImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSelectedIndex(int paramInt) {
/* 138 */     setSelectedIndexImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 143 */     return getValueImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 148 */     setValueImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getWillValidate() {
/* 153 */     return getWillValidateImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValidationMessage() {
/* 158 */     return getValidationMessageImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public NodeList getLabels() {
/* 163 */     return NodeListImpl.getImpl(getLabelsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAutocomplete() {
/* 168 */     return getAutocompleteImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAutocomplete(String paramString) {
/* 173 */     setAutocompleteImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node item(int paramInt) {
/* 181 */     return NodeImpl.getImpl(itemImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node namedItem(String paramString) {
/* 190 */     return NodeImpl.getImpl(namedItemImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(HTMLElement paramHTMLElement1, HTMLElement paramHTMLElement2) throws DOMException {
/* 200 */     addImpl(getPeer(), 
/* 201 */         HTMLElementImpl.getPeer(paramHTMLElement1), 
/* 202 */         HTMLElementImpl.getPeer(paramHTMLElement2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int paramInt) {
/* 211 */     removeImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 220 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomValidity(String paramString) {
/* 227 */     setCustomValidityImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native boolean getAutofocusImpl(long paramLong);
/*     */   
/*     */   static native void setAutofocusImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   static native boolean getMultipleImpl(long paramLong);
/*     */   
/*     */   static native void setMultipleImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   static native boolean getRequiredImpl(long paramLong);
/*     */   
/*     */   static native void setRequiredImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native int getSizeImpl(long paramLong);
/*     */   
/*     */   static native void setSizeImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   static native long getOptionsImpl(long paramLong);
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   static native long getSelectedOptionsImpl(long paramLong);
/*     */   
/*     */   static native int getSelectedIndexImpl(long paramLong);
/*     */   
/*     */   static native void setSelectedIndexImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native String getValueImpl(long paramLong);
/*     */   
/*     */   static native void setValueImpl(long paramLong, String paramString);
/*     */   
/*     */   static native boolean getWillValidateImpl(long paramLong);
/*     */   
/*     */   static native String getValidationMessageImpl(long paramLong);
/*     */   
/*     */   static native long getLabelsImpl(long paramLong);
/*     */   
/*     */   static native String getAutocompleteImpl(long paramLong);
/*     */   
/*     */   static native void setAutocompleteImpl(long paramLong, String paramString);
/*     */   
/*     */   static native long itemImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native long namedItemImpl(long paramLong, String paramString);
/*     */   
/*     */   static native void addImpl(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   static native void removeImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */   
/*     */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLSelectElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */