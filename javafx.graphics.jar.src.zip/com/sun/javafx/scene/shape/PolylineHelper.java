/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.paint.Paint;
/*    */ import javafx.scene.shape.Polyline;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolylineHelper
/*    */   extends ShapeHelper
/*    */ {
/* 46 */   private static final PolylineHelper theInstance = new PolylineHelper(); static {
/* 47 */     Utils.forceInit(Polyline.class);
/*    */   }
/*    */   private static PolylineAccessor polylineAccessor;
/*    */   private static PolylineHelper getInstance() {
/* 51 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Polyline paramPolyline) {
/* 55 */     setHelper(paramPolyline, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 60 */     return polylineAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 65 */     super.updatePeerImpl(paramNode);
/* 66 */     polylineAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 72 */     return polylineAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetFillInitialValueImpl(Shape paramShape) {
/* 77 */     return polylineAccessor.doCssGetFillInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Paint cssGetStrokeInitialValueImpl(Shape paramShape) {
/* 82 */     return polylineAccessor.doCssGetStrokeInitialValue(paramShape);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 87 */     return polylineAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setPolylineAccessor(PolylineAccessor paramPolylineAccessor) {
/* 91 */     if (polylineAccessor != null) {
/* 92 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 95 */     polylineAccessor = paramPolylineAccessor;
/*    */   }
/*    */   
/*    */   public static interface PolylineAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     Paint doCssGetFillInitialValue(Shape param1Shape);
/*    */     
/*    */     Paint doCssGetStrokeInitialValue(Shape param1Shape);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\PolylineHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */