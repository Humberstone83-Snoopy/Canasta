/*     */ package javafx.scene.media;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Track
/*     */ {
/*     */   private String name;
/*     */   private long trackID;
/*     */   private Locale locale;
/*     */   private Map<String, Object> metadata;
/*     */   private String description;
/*     */   
/*     */   public final String getName() {
/*  56 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Locale getLocale() {
/*  70 */     return this.locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getTrackID() {
/*  80 */     return this.trackID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<String, Object> getMetadata() {
/*  88 */     return this.metadata;
/*     */   }
/*     */   
/*     */   Track(long paramLong, Map<String, Object> paramMap) {
/*  92 */     this.trackID = paramLong;
/*     */     
/*  94 */     Object object = paramMap.get("name");
/*  95 */     if (null != object && object instanceof String) {
/*  96 */       this.name = (String)object;
/*     */     }
/*     */     
/*  99 */     object = paramMap.get("locale");
/* 100 */     if (null != object && object instanceof Locale) {
/* 101 */       this.locale = (Locale)object;
/*     */     }
/*     */     
/* 104 */     this.metadata = Collections.unmodifiableMap(paramMap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 110 */     synchronized (this) {
/* 111 */       if (null == this.description) {
/* 112 */         StringBuilder stringBuilder = new StringBuilder();
/* 113 */         Map<String, Object> map = getMetadata();
/*     */         
/* 115 */         stringBuilder.append(getClass().getName());
/* 116 */         stringBuilder.append("[ track id = ");
/* 117 */         stringBuilder.append(this.trackID);
/*     */         
/* 119 */         for (Map.Entry<String, Object> entry : map.entrySet()) {
/* 120 */           Object object = entry.getValue();
/* 121 */           if (null != object) {
/* 122 */             stringBuilder.append(", ");
/* 123 */             stringBuilder.append((String)entry.getKey());
/* 124 */             stringBuilder.append(" = ");
/* 125 */             stringBuilder.append(object.toString());
/*     */           } 
/*     */         } 
/* 128 */         stringBuilder.append("]");
/* 129 */         this.description = stringBuilder.toString();
/*     */       } 
/*     */     } 
/* 132 */     return this.description;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\Track.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */