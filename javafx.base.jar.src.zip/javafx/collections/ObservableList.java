/*     */ package javafx.collections;
/*     */ 
/*     */ import java.text.Collator;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.function.Predicate;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.transformation.FilteredList;
/*     */ import javafx.collections.transformation.SortedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ObservableList<E>
/*     */   extends List<E>, Observable
/*     */ {
/*     */   void addListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   void removeListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   boolean addAll(E... paramVarArgs);
/*     */   
/*     */   boolean setAll(E... paramVarArgs);
/*     */   
/*     */   boolean setAll(Collection<? extends E> paramCollection);
/*     */   
/*     */   boolean removeAll(E... paramVarArgs);
/*     */   
/*     */   boolean retainAll(E... paramVarArgs);
/*     */   
/*     */   void remove(int paramInt1, int paramInt2);
/*     */   
/*     */   default FilteredList<E> filtered(Predicate<E> paramPredicate) {
/* 114 */     return new FilteredList<>(this, paramPredicate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default SortedList<E> sorted(Comparator<E> paramComparator) {
/* 125 */     return new SortedList<>(this, paramComparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default SortedList<E> sorted() {
/* 135 */     Comparator<E> comparator = new Comparator<E>()
/*     */       {
/*     */         public int compare(E param1E1, E param1E2)
/*     */         {
/* 139 */           if (param1E1 == null && param1E2 == null) {
/* 140 */             return 0;
/*     */           }
/* 142 */           if (param1E1 == null) {
/* 143 */             return -1;
/*     */           }
/* 145 */           if (param1E2 == null) {
/* 146 */             return 1;
/*     */           }
/*     */           
/* 149 */           if (param1E1 instanceof Comparable) {
/* 150 */             return ((Comparable<E>)param1E1).compareTo(param1E2);
/*     */           }
/*     */           
/* 153 */           return Collator.getInstance().compare(param1E1.toString(), param1E2.toString());
/*     */         }
/*     */       };
/* 156 */     return sorted(comparator);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\ObservableList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */