package com.sun.javafx.geom.transform;

import com.sun.javafx.geom.Vec3d;

public interface CanTransformVec3d {
  Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\CanTransformVec3d.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */