/*    */ package com.sun.javafx.geom.transform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingularMatrixException
/*    */   extends RuntimeException
/*    */ {
/*    */   public SingularMatrixException() {}
/*    */   
/*    */   public SingularMatrixException(String paramString) {
/* 38 */     super(paramString);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\SingularMatrixException.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */