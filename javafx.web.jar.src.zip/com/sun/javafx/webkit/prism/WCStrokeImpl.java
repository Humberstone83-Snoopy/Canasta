/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.prism.BasicStroke;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.prism.paint.Paint;
/*    */ import com.sun.webkit.graphics.WCStroke;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCStrokeImpl
/*    */   extends WCStroke<Paint, BasicStroke>
/*    */ {
/*    */   private BasicStroke stroke;
/*    */   
/*    */   public WCStrokeImpl() {}
/*    */   
/*    */   public WCStrokeImpl(float paramFloat1, int paramInt1, int paramInt2, float paramFloat2, float[] paramArrayOffloat, float paramFloat3) {
/* 43 */     setThickness(paramFloat1);
/* 44 */     setLineCap(paramInt1);
/* 45 */     setLineJoin(paramInt2);
/* 46 */     setMiterLimit(paramFloat2);
/* 47 */     setDashSizes(paramArrayOffloat);
/* 48 */     setDashOffset(paramFloat3);
/*    */   }
/*    */   
/*    */   protected void invalidate() {
/* 52 */     this.stroke = null;
/*    */   }
/*    */   
/*    */   public BasicStroke getPlatformStroke() {
/* 56 */     if (this.stroke == null) {
/* 57 */       int i = getStyle();
/* 58 */       if (i != 0) {
/* 59 */         float f = getThickness();
/* 60 */         float[] arrayOfFloat = getDashSizes();
/* 61 */         if (arrayOfFloat == null) {
/* 62 */           switch (i) {
/*    */             case 2:
/* 64 */               arrayOfFloat = new float[] { f, f };
/*    */               break;
/*    */             case 3:
/* 67 */               arrayOfFloat = new float[] { 3.0F * f, 3.0F * f };
/*    */               break;
/*    */           } 
/*    */         }
/* 71 */         this
/* 72 */           .stroke = new BasicStroke(f, getLineCap(), getLineJoin(), getMiterLimit(), arrayOfFloat, getDashOffset());
/*    */       } 
/*    */     } 
/* 75 */     return this.stroke;
/*    */   }
/*    */   
/*    */   boolean isApplicable() {
/* 79 */     return (getPaint() != null && getPlatformStroke() != null);
/*    */   }
/*    */   
/*    */   boolean apply(Graphics paramGraphics) {
/* 83 */     if (isApplicable()) {
/* 84 */       Paint paint = getPaint();
/* 85 */       BasicStroke basicStroke = getPlatformStroke();
/* 86 */       paramGraphics.setPaint(paint);
/* 87 */       paramGraphics.setStroke(basicStroke);
/* 88 */       return true;
/*    */     } 
/* 90 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCStrokeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */