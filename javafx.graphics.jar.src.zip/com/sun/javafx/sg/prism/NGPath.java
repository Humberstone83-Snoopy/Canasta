/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Arc2D;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.PathIterator;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import javafx.scene.shape.FillRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGPath
/*     */   extends NGShape
/*     */ {
/*  39 */   private Path2D p = new Path2D();
/*     */   
/*     */   public void reset() {
/*  42 */     this.p.reset();
/*     */   }
/*     */   
/*     */   public void update() {
/*  46 */     geometryChanged();
/*     */   }
/*     */   
/*     */   private int toWindingRule(FillRule paramFillRule) {
/*  50 */     if (paramFillRule == FillRule.NON_ZERO) {
/*  51 */       return 1;
/*     */     }
/*  53 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFillRule(FillRule paramFillRule) {
/*  58 */     this.p.setWindingRule(toWindingRule(paramFillRule));
/*     */   }
/*     */   
/*     */   public float getCurrentX() {
/*  62 */     return (this.p.getCurrentPoint()).x;
/*     */   }
/*     */   
/*     */   public float getCurrentY() {
/*  66 */     return (this.p.getCurrentPoint()).y;
/*     */   }
/*     */   
/*     */   public void addClosePath() {
/*  70 */     this.p.closePath();
/*     */   }
/*     */   
/*     */   public void addMoveTo(float paramFloat1, float paramFloat2) {
/*  74 */     this.p.moveTo(paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   public void addLineTo(float paramFloat1, float paramFloat2) {
/*  78 */     this.p.lineTo(paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   public void addQuadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  82 */     this.p.quadTo(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCubicTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  89 */     this.p.curveTo(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addArcTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
/*  95 */     Arc2D arc2D = new Arc2D(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, 0);
/*     */     
/*  97 */     BaseTransform baseTransform = (paramFloat7 == 0.0D) ? null : BaseTransform.getRotateInstance(paramFloat7, arc2D
/*  98 */         .getCenterX(), arc2D.getCenterY());
/*  99 */     PathIterator pathIterator = arc2D.getPathIterator(baseTransform);
/*     */ 
/*     */ 
/*     */     
/* 103 */     pathIterator.next();
/* 104 */     this.p.append(pathIterator, true);
/*     */   }
/*     */   
/*     */   public Path2D getGeometry() {
/* 108 */     return this.p;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/* 113 */     return this.p;
/*     */   }
/*     */   
/*     */   public boolean acceptsPath2dOnUpdate() {
/* 117 */     return true;
/*     */   }
/*     */   
/*     */   public void updateWithPath2d(Path2D paramPath2D) {
/* 121 */     this.p.setTo(paramPath2D);
/* 122 */     geometryChanged();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGPath.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */