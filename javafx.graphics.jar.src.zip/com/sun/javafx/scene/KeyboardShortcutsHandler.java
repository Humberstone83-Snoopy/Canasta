/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.collections.ObservableListWrapper;
/*     */ import com.sun.javafx.collections.ObservableMapWrapper;
/*     */ import com.sun.javafx.event.BasicEventDispatcher;
/*     */ import com.sun.javafx.scene.traversal.Direction;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventTarget;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.KeyCombination;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.Mnemonic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class KeyboardShortcutsHandler
/*     */   extends BasicEventDispatcher
/*     */ {
/*     */   private ObservableMap<KeyCombination, Runnable> accelerators;
/*     */   private CopyOnWriteMap<KeyCombination, Runnable> acceleratorsBackingMap;
/*     */   private ObservableMap<KeyCombination, ObservableList<Mnemonic>> mnemonics;
/*     */   
/*     */   public void addMnemonic(Mnemonic paramMnemonic) {
/*  58 */     ObservableList<Mnemonic> observableList = getMnemonics().get(paramMnemonic.getKeyCombination());
/*  59 */     if (observableList == null) {
/*  60 */       observableList = new ObservableListWrapper(new ArrayList());
/*  61 */       getMnemonics().put(paramMnemonic.getKeyCombination(), observableList);
/*     */     } 
/*  63 */     boolean bool = false;
/*  64 */     for (Mnemonic mnemonic : observableList) {
/*  65 */       if (mnemonic == paramMnemonic) {
/*  66 */         bool = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  70 */     if (!bool) {
/*  71 */       observableList.add(paramMnemonic);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeMnemonic(Mnemonic paramMnemonic) {
/*  76 */     ObservableList<Mnemonic> observableList = getMnemonics().get(paramMnemonic.getKeyCombination());
/*  77 */     if (observableList != null) {
/*  78 */       for (byte b = 0; b < observableList.size(); b++) {
/*  79 */         if (((Mnemonic)observableList.get(b)).getNode() == paramMnemonic.getNode()) {
/*  80 */           observableList.remove(b);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public ObservableMap<KeyCombination, ObservableList<Mnemonic>> getMnemonics() {
/*  87 */     if (this.mnemonics == null) {
/*  88 */       this.mnemonics = new ObservableMapWrapper<>(new HashMap<>());
/*     */     }
/*  90 */     return this.mnemonics;
/*     */   }
/*     */   
/*     */   public ObservableMap<KeyCombination, Runnable> getAccelerators() {
/*  94 */     if (this.accelerators == null) {
/*  95 */       this.acceleratorsBackingMap = new CopyOnWriteMap<>();
/*  96 */       this.accelerators = new ObservableMapWrapper<>(this.acceleratorsBackingMap);
/*     */     } 
/*  98 */     return this.accelerators;
/*     */   }
/*     */   
/*     */   private void traverse(Event paramEvent, Node paramNode, Direction paramDirection) {
/* 102 */     if (NodeHelper.traverse(paramNode, paramDirection)) {
/* 103 */       paramEvent.consume();
/*     */     }
/*     */   }
/*     */   
/*     */   public void processTraversal(Event paramEvent) {
/* 108 */     if (paramEvent.getEventType() != KeyEvent.KEY_PRESSED)
/* 109 */       return;  if (!(paramEvent instanceof KeyEvent))
/*     */       return; 
/* 111 */     KeyEvent keyEvent = (KeyEvent)paramEvent;
/* 112 */     if (!keyEvent.isMetaDown() && !keyEvent.isControlDown() && !keyEvent.isAltDown()) {
/* 113 */       EventTarget eventTarget = paramEvent.getTarget();
/* 114 */       if (!(eventTarget instanceof Node))
/*     */         return; 
/* 116 */       Node node = (Node)eventTarget;
/* 117 */       switch (keyEvent.getCode()) {
/*     */         case TAB:
/* 119 */           if (keyEvent.isShiftDown()) {
/* 120 */             traverse(paramEvent, node, Direction.PREVIOUS);
/*     */             break;
/*     */           } 
/* 123 */           traverse(paramEvent, node, Direction.NEXT);
/*     */           break;
/*     */         
/*     */         case UP:
/* 127 */           traverse(paramEvent, node, Direction.UP);
/*     */           break;
/*     */         case DOWN:
/* 130 */           traverse(paramEvent, node, Direction.DOWN);
/*     */           break;
/*     */         case LEFT:
/* 133 */           traverse(paramEvent, node, Direction.LEFT);
/*     */           break;
/*     */         case RIGHT:
/* 136 */           traverse(paramEvent, node, Direction.RIGHT);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Event dispatchBubblingEvent(Event paramEvent) {
/* 156 */     if (!(paramEvent instanceof KeyEvent)) return paramEvent; 
/* 157 */     boolean bool = (paramEvent.getEventType() == KeyEvent.KEY_PRESSED) ? true : false;
/* 158 */     KeyEvent keyEvent = (KeyEvent)paramEvent;
/*     */     
/* 160 */     if (bool) {
/* 161 */       if (!paramEvent.isConsumed()) {
/* 162 */         processAccelerators(keyEvent);
/*     */       }
/*     */       
/* 165 */       if (!paramEvent.isConsumed()) {
/* 166 */         processTraversal(paramEvent);
/*     */       }
/*     */     } 
/*     */     
/* 170 */     return paramEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Event dispatchCapturingEvent(Event paramEvent) {
/* 185 */     if (!(paramEvent instanceof KeyEvent)) return paramEvent; 
/* 186 */     boolean bool1 = (paramEvent.getEventType() == KeyEvent.KEY_PRESSED) ? true : false;
/* 187 */     boolean bool2 = (paramEvent.getEventType() == KeyEvent.KEY_TYPED) ? true : false;
/* 188 */     boolean bool3 = (paramEvent.getEventType() == KeyEvent.KEY_RELEASED) ? true : false;
/* 189 */     KeyEvent keyEvent = (KeyEvent)paramEvent;
/*     */     
/* 191 */     if (bool1 || bool2) {
/* 192 */       if (PlatformUtil.isMac()) {
/* 193 */         if (keyEvent.isMetaDown()) {
/* 194 */           processMnemonics(keyEvent);
/*     */         }
/* 196 */       } else if (keyEvent.isAltDown() || isMnemonicsDisplayEnabled()) {
/* 197 */         processMnemonics(keyEvent);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (!PlatformUtil.isMac() && !paramEvent.isConsumed()) {
/* 206 */       if (bool1) {
/* 207 */         if (keyEvent.isAltDown()) {
/*     */           
/* 209 */           if (!isMnemonicsDisplayEnabled()) {
/* 210 */             setMnemonicsDisplayEnabled(true);
/*     */           }
/* 212 */           else if (PlatformUtil.isWindows()) {
/* 213 */             setMnemonicsDisplayEnabled(!isMnemonicsDisplayEnabled());
/*     */           }
/*     */         
/* 216 */         } else if (keyEvent.getCode() == KeyCode.ESCAPE) {
/*     */           
/* 218 */           setMnemonicsDisplayEnabled(false);
/*     */         } 
/*     */       }
/* 221 */       if (bool3 && !keyEvent.isAltDown() && !PlatformUtil.isWindows()) {
/* 222 */         setMnemonicsDisplayEnabled(false);
/*     */       }
/*     */     } 
/* 225 */     return paramEvent;
/*     */   }
/*     */   
/*     */   private void processMnemonics(KeyEvent paramKeyEvent) {
/* 229 */     if (this.mnemonics == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     KeyEvent keyEvent = paramKeyEvent;
/* 240 */     if (paramKeyEvent.getEventType() == KeyEvent.KEY_TYPED) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       keyEvent = new KeyEvent(null, paramKeyEvent.getTarget(), KeyEvent.KEY_PRESSED, " ", paramKeyEvent.getCharacter(), KeyCode.getKeyCode(paramKeyEvent.getCharacter()), paramKeyEvent.isShiftDown(), paramKeyEvent.isControlDown(), isMnemonicsDisplayEnabled(), paramKeyEvent.isMetaDown());
/* 249 */     } else if (isMnemonicsDisplayEnabled()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 257 */       keyEvent = new KeyEvent(null, paramKeyEvent.getTarget(), KeyEvent.KEY_PRESSED, paramKeyEvent.getCharacter(), paramKeyEvent.getText(), paramKeyEvent.getCode(), paramKeyEvent.isShiftDown(), paramKeyEvent.isControlDown(), isMnemonicsDisplayEnabled(), paramKeyEvent.isMetaDown());
/*     */     } 
/*     */ 
/*     */     
/* 261 */     ObservableList<Mnemonic> observableList = null;
/*     */     
/* 263 */     for (Map.Entry<KeyCombination, ObservableList<Mnemonic>> entry : this.mnemonics.entrySet()) {
/* 264 */       if (((KeyCombination)entry.getKey()).match(keyEvent)) {
/* 265 */         observableList = (ObservableList)entry.getValue();
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 270 */     if (observableList == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     boolean bool = false;
/* 281 */     Node node = null;
/* 282 */     Mnemonic mnemonic = null;
/* 283 */     byte b1 = -1;
/* 284 */     byte b2 = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 289 */     for (byte b = 0; b < observableList.size(); b++) {
/* 290 */       Mnemonic mnemonic1 = observableList.get(b);
/* 291 */       Node node1 = mnemonic1.getNode();
/*     */       
/* 293 */       if (mnemonic == null && NodeHelper.isTreeVisible(node1) && !node1.isDisabled()) {
/* 294 */         mnemonic = mnemonic1;
/*     */       }
/*     */       
/* 297 */       if (NodeHelper.isTreeVisible(node1) && node1.isFocusTraversable() && !node1.isDisabled()) {
/* 298 */         if (node == null) {
/* 299 */           node = node1;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 304 */           bool = true;
/* 305 */           if (b1 != -1 && 
/* 306 */             b2 == -1) {
/* 307 */             b2 = b;
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 316 */       if (node1.isFocused()) {
/* 317 */         b1 = b;
/*     */       }
/*     */     } 
/*     */     
/* 321 */     if (node != null) {
/* 322 */       if ((!bool ? true : false) == true) {
/*     */ 
/*     */ 
/*     */         
/* 326 */         node.requestFocus();
/* 327 */         paramKeyEvent.consume();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 335 */       else if (b1 == -1) {
/* 336 */         node.requestFocus();
/* 337 */         paramKeyEvent.consume();
/*     */       
/*     */       }
/* 340 */       else if (b1 >= observableList.size()) {
/* 341 */         node.requestFocus();
/* 342 */         paramKeyEvent.consume();
/*     */       } else {
/*     */         
/* 345 */         if (b2 != -1) {
/* 346 */           ((Mnemonic)observableList.get(b2)).getNode().requestFocus();
/*     */         } else {
/*     */           
/* 349 */           node.requestFocus();
/*     */         } 
/* 351 */         paramKeyEvent.consume();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 357 */     if (!bool && mnemonic != null) {
/* 358 */       if (paramKeyEvent.getEventType() == KeyEvent.KEY_TYPED) {
/* 359 */         paramKeyEvent.consume();
/*     */       } else {
/* 361 */         mnemonic.fire();
/* 362 */         paramKeyEvent.consume();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void processAccelerators(KeyEvent paramKeyEvent) {
/* 368 */     if (this.acceleratorsBackingMap != null) {
/* 369 */       this.acceleratorsBackingMap.lock();
/*     */       
/*     */       try {
/* 372 */         for (Map.Entry entry : this.acceleratorsBackingMap.backingMap.entrySet()) {
/*     */           
/* 374 */           if (((KeyCombination)entry.getKey()).match(paramKeyEvent)) {
/* 375 */             Runnable runnable = (Runnable)entry.getValue();
/* 376 */             if (runnable != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 382 */               runnable.run();
/* 383 */               paramKeyEvent.consume();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 388 */         this.acceleratorsBackingMap.unlock();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processMnemonicsKeyDisplay() {
/* 394 */     ObservableList<Mnemonic> observableList = null;
/* 395 */     if (this.mnemonics != null) {
/* 396 */       for (Map.Entry<KeyCombination, ObservableList<Mnemonic>> entry : this.mnemonics.entrySet()) {
/* 397 */         observableList = (ObservableList)entry.getValue();
/*     */         
/* 399 */         if (observableList != null) {
/* 400 */           for (byte b = 0; b < observableList.size(); b++) {
/* 401 */             Node node = ((Mnemonic)observableList.get(b)).getNode();
/* 402 */             NodeHelper.setShowMnemonics(node, this.mnemonicsDisplayEnabled);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mnemonicsDisplayEnabled = false;
/*     */ 
/*     */   
/*     */   public boolean isMnemonicsDisplayEnabled() {
/* 415 */     return this.mnemonicsDisplayEnabled;
/*     */   }
/*     */   public void setMnemonicsDisplayEnabled(boolean paramBoolean) {
/* 418 */     if (paramBoolean != this.mnemonicsDisplayEnabled) {
/* 419 */       this.mnemonicsDisplayEnabled = paramBoolean;
/* 420 */       processMnemonicsKeyDisplay();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearNodeMnemonics(Node paramNode) {
/* 425 */     if (this.mnemonics != null)
/* 426 */       for (ObservableList<Mnemonic> observableList : this.mnemonics.values()) {
/* 427 */         for (Iterator<Mnemonic> iterator = observableList.iterator(); iterator.hasNext(); ) {
/* 428 */           Mnemonic mnemonic = iterator.next();
/* 429 */           if (mnemonic.getNode() == paramNode) {
/* 430 */             iterator.remove();
/*     */           }
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   private static class CopyOnWriteMap<K, V>
/*     */     extends AbstractMap<K, V>
/*     */   {
/* 439 */     private Map<K, V> backingMap = new HashMap<>();
/*     */     private boolean lock;
/*     */     
/*     */     public void lock() {
/* 443 */       this.lock = true;
/*     */     }
/*     */     
/*     */     public void unlock() {
/* 447 */       this.lock = false;
/*     */     }
/*     */ 
/*     */     
/*     */     public V put(K param1K, V param1V) {
/* 452 */       if (this.lock) {
/* 453 */         this.backingMap = new HashMap<>(this.backingMap);
/* 454 */         this.lock = false;
/*     */       } 
/* 456 */       return this.backingMap.put(param1K, param1V);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<K, V>> entrySet() {
/* 461 */       return new AbstractSet<Map.Entry<K, V>>()
/*     */         {
/*     */           public Iterator<Map.Entry<K, V>> iterator() {
/* 464 */             return new Iterator<Map.Entry<K, V>>()
/*     */               {
/* 466 */                 private Iterator<Map.Entry<K, V>> backingIt = KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap.entrySet().iterator();
/* 467 */                 private Map<K, V> backingMapAtCreation = KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap;
/* 468 */                 private Map.Entry<K, V> lastNext = null;
/*     */ 
/*     */                 
/*     */                 public boolean hasNext() {
/* 472 */                   checkCoMod();
/* 473 */                   return this.backingIt.hasNext();
/*     */                 }
/*     */                 
/*     */                 private void checkCoMod() {
/* 477 */                   if (KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap != this.backingMapAtCreation) {
/* 478 */                     throw new ConcurrentModificationException();
/*     */                   }
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public Map.Entry<K, V> next() {
/* 484 */                   checkCoMod();
/* 485 */                   return this.lastNext = this.backingIt.next();
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public void remove() {
/* 490 */                   checkCoMod();
/* 491 */                   if (this.lastNext == null) {
/* 492 */                     throw new IllegalStateException();
/*     */                   }
/* 494 */                   if (KeyboardShortcutsHandler.CopyOnWriteMap.this.lock) {
/* 495 */                     KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap = new HashMap<>(KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap);
/* 496 */                     this.backingIt = KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap.entrySet().iterator();
/* 497 */                     while (!this.lastNext.equals(this.backingIt.next()));
/* 498 */                     KeyboardShortcutsHandler.CopyOnWriteMap.this.lock = false;
/*     */                   } 
/* 500 */                   this.backingIt.remove();
/* 501 */                   this.lastNext = null;
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 508 */             return KeyboardShortcutsHandler.CopyOnWriteMap.this.backingMap.size();
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     private CopyOnWriteMap() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\KeyboardShortcutsHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */