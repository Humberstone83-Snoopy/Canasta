package javafx.beans.property;

import javafx.beans.value.ObservableValue;
import javafx.beans.value.WritableValue;

public interface Property<T> extends ReadOnlyProperty<T>, WritableValue<T> {
  void bind(ObservableValue<? extends T> paramObservableValue);
  
  void unbind();
  
  boolean isBound();
  
  void bindBidirectional(Property<T> paramProperty);
  
  void unbindBidirectional(Property<T> paramProperty);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\Property.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */