/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.BidirectionalBinding;
/*     */ import com.sun.javafx.binding.Logging;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ import javafx.beans.value.WritableFloatValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FloatProperty
/*     */   extends ReadOnlyFloatProperty
/*     */   implements Property<Number>, WritableFloatValue
/*     */ {
/*     */   public void setValue(Number paramNumber) {
/*  69 */     if (paramNumber == null) {
/*  70 */       Logging.getLogger().fine("Attempt to set float property to null, using default value instead.", new NullPointerException());
/*  71 */       set(0.0F);
/*     */     } else {
/*  73 */       set(paramNumber.floatValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<Number> paramProperty) {
/*  82 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<Number> paramProperty) {
/*  90 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     Object object = getBean();
/* 100 */     String str = getName();
/* 101 */     StringBuilder stringBuilder = new StringBuilder("FloatProperty [");
/*     */     
/* 103 */     if (object != null) {
/* 104 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 106 */     if (str != null && !str.equals("")) {
/* 107 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 109 */     stringBuilder.append("value: ").append(get()).append("]");
/* 110 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FloatProperty floatProperty(final Property<Float> property) {
/* 150 */     if (property == null) {
/* 151 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/* 153 */     return new FloatPropertyBase()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 161 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 166 */           return property.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 172 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(param1Property, this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 177 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectProperty<Float> asObject() {
/* 204 */     return new ObjectPropertyBase<Float>()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 212 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 217 */           return FloatProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 223 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(this, FloatProperty.this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 228 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\FloatProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */