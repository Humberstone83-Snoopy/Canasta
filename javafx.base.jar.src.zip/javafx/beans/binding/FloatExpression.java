/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableFloatValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FloatExpression
/*     */   extends NumberExpressionBase
/*     */   implements ObservableFloatValue
/*     */ {
/*     */   public int intValue() {
/*  48 */     return (int)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/*  53 */     return (long)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/*  58 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/*  63 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Float getValue() {
/*  68 */     return Float.valueOf(get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FloatExpression floatExpression(final ObservableFloatValue value) {
/*  88 */     if (value == null) {
/*  89 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/*  91 */     return (value instanceof FloatExpression) ? (FloatExpression)value : 
/*  92 */       new FloatBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/*  99 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected float computeValue() {
/* 104 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableFloatValue> getDependencies() {
/* 109 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> FloatExpression floatExpression(final ObservableValue<T> value) {
/* 145 */     if (value == null) {
/* 146 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/* 148 */     return (value instanceof FloatExpression) ? (FloatExpression)value : 
/* 149 */       new FloatBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 156 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected float computeValue() {
/* 161 */           Number number = value.getValue();
/* 162 */           return (number == null) ? 0.0F : number.floatValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableValue<T>> getDependencies() {
/* 167 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FloatBinding negate() {
/* 175 */     return (FloatBinding)Bindings.negate(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(double paramDouble) {
/* 180 */     return Bindings.add(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding add(float paramFloat) {
/* 185 */     return (FloatBinding)Bindings.add(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding add(long paramLong) {
/* 190 */     return (FloatBinding)Bindings.add(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding add(int paramInt) {
/* 195 */     return (FloatBinding)Bindings.add(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(double paramDouble) {
/* 200 */     return Bindings.subtract(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding subtract(float paramFloat) {
/* 205 */     return (FloatBinding)Bindings.subtract(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding subtract(long paramLong) {
/* 210 */     return (FloatBinding)Bindings.subtract(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding subtract(int paramInt) {
/* 215 */     return (FloatBinding)Bindings.subtract(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(double paramDouble) {
/* 220 */     return Bindings.multiply(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding multiply(float paramFloat) {
/* 225 */     return (FloatBinding)Bindings.multiply(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding multiply(long paramLong) {
/* 230 */     return (FloatBinding)Bindings.multiply(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding multiply(int paramInt) {
/* 235 */     return (FloatBinding)Bindings.multiply(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(double paramDouble) {
/* 240 */     return Bindings.divide(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding divide(float paramFloat) {
/* 245 */     return (FloatBinding)Bindings.divide(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding divide(long paramLong) {
/* 250 */     return (FloatBinding)Bindings.divide(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public FloatBinding divide(int paramInt) {
/* 255 */     return (FloatBinding)Bindings.divide(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectExpression<Float> asObject() {
/* 268 */     return new ObjectBinding<Float>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 275 */           unbind(new Observable[] { this.this$0 });
/*     */         }
/*     */ 
/*     */         
/*     */         protected Float computeValue() {
/* 280 */           return FloatExpression.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\FloatExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */