/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeGlyphMapper
/*     */   extends CharToGlyphMapper
/*     */ {
/*     */   public static final int SLOTMASK = -16777216;
/*     */   public static final int GLYPHMASK = 16777215;
/*     */   public static final int NBLOCKS = 216;
/*     */   public static final int BLOCKSZ = 256;
/*     */   public static final int MAXUNICODE = 55296;
/*     */   private static final int SIMPLE_ASCII_MASK_START = 32;
/*     */   private static final int SIMPLE_ASCII_MASK_END = 126;
/*     */   private static final int ASCII_COUNT = 95;
/*     */   private boolean asciiCacheOK;
/*     */   private char[] charToGlyph;
/*     */   CompositeFontResource font;
/*     */   CharToGlyphMapper[] slotMappers;
/*     */   HashMap<Integer, Integer> glyphMap;
/*     */   
/*     */   public CompositeGlyphMapper(CompositeFontResource paramCompositeFontResource) {
/*  59 */     this.font = paramCompositeFontResource;
/*  60 */     this.missingGlyph = 0;
/*  61 */     this.glyphMap = new HashMap<>();
/*  62 */     this.slotMappers = new CharToGlyphMapper[paramCompositeFontResource.getNumSlots()];
/*  63 */     this.asciiCacheOK = true;
/*     */   }
/*     */   
/*     */   private final CharToGlyphMapper getSlotMapper(int paramInt) {
/*  67 */     if (paramInt >= this.slotMappers.length) {
/*  68 */       CharToGlyphMapper[] arrayOfCharToGlyphMapper = new CharToGlyphMapper[this.font.getNumSlots()];
/*  69 */       System.arraycopy(this.slotMappers, 0, arrayOfCharToGlyphMapper, 0, this.slotMappers.length);
/*  70 */       this.slotMappers = arrayOfCharToGlyphMapper;
/*     */     } 
/*  72 */     CharToGlyphMapper charToGlyphMapper = this.slotMappers[paramInt];
/*  73 */     if (charToGlyphMapper == null) {
/*  74 */       charToGlyphMapper = this.font.getSlotResource(paramInt).getGlyphMapper();
/*  75 */       this.slotMappers[paramInt] = charToGlyphMapper;
/*     */     } 
/*  77 */     return charToGlyphMapper;
/*     */   }
/*     */   
/*     */   public int getMissingGlyphCode() {
/*  81 */     return this.missingGlyph;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int compositeGlyphCode(int paramInt1, int paramInt2) {
/*  90 */     return paramInt1 << 24 | paramInt2 & 0xFFFFFF;
/*     */   }
/*     */   
/*     */   private final int convertToGlyph(int paramInt) {
/*  94 */     for (byte b = 0; b < this.font.getNumSlots(); b++) {
/*  95 */       CharToGlyphMapper charToGlyphMapper = getSlotMapper(b);
/*  96 */       int i = charToGlyphMapper.charToGlyph(paramInt);
/*  97 */       if (i != charToGlyphMapper.getMissingGlyphCode()) {
/*  98 */         i = compositeGlyphCode(b, i);
/*  99 */         this.glyphMap.put(Integer.valueOf(paramInt), Integer.valueOf(i));
/* 100 */         return i;
/*     */       } 
/*     */     } 
/* 103 */     this.glyphMap.put(Integer.valueOf(paramInt), Integer.valueOf(this.missingGlyph));
/* 104 */     return this.missingGlyph;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getAsciiGlyphCode(int paramInt) {
/* 110 */     if (!this.asciiCacheOK || paramInt > 126 || paramInt < 32)
/*     */     {
/*     */       
/* 113 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 117 */     if (this.charToGlyph == null) {
/* 118 */       char[] arrayOfChar = new char[95];
/* 119 */       CharToGlyphMapper charToGlyphMapper = getSlotMapper(0);
/* 120 */       int j = charToGlyphMapper.getMissingGlyphCode();
/* 121 */       for (byte b = 0; b < 95; b++) {
/* 122 */         int k = charToGlyphMapper.charToGlyph(32 + b);
/* 123 */         if (k == j) {
/*     */ 
/*     */           
/* 126 */           this.charToGlyph = null;
/* 127 */           this.asciiCacheOK = false;
/* 128 */           return -1;
/*     */         } 
/*     */         
/* 131 */         arrayOfChar[b] = (char)k;
/*     */       } 
/* 133 */       this.charToGlyph = arrayOfChar;
/*     */     } 
/*     */     
/* 136 */     int i = paramInt - 32;
/* 137 */     return this.charToGlyph[i];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGlyphCode(int paramInt) {
/* 142 */     int i = getAsciiGlyphCode(paramInt);
/* 143 */     if (i >= 0) {
/* 144 */       return i;
/*     */     }
/*     */     
/* 147 */     Integer integer = this.glyphMap.get(Integer.valueOf(paramInt));
/* 148 */     if (integer != null) {
/* 149 */       return integer.intValue();
/*     */     }
/* 151 */     return convertToGlyph(paramInt);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\CompositeGlyphMapper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */