/*    */ package com.sun.media.jfxmedia.control;
/*    */ 
/*    */ import java.util.EnumSet;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum VideoFormat
/*    */ {
/* 36 */   ARGB(1),
/*    */ 
/*    */   
/* 39 */   BGRA_PRE(2),
/*    */ 
/*    */   
/* 42 */   YCbCr_420p(100),
/*    */ 
/*    */   
/* 45 */   YCbCr_422(101); private int nativeType;
/*    */   
/*    */   static {
/* 48 */     lookupMap = new HashMap<>();
/*    */     
/* 50 */     for (VideoFormat videoFormat : EnumSet.<VideoFormat>allOf(VideoFormat.class))
/* 51 */       lookupMap.put(Integer.valueOf(videoFormat.getNativeType()), videoFormat); 
/*    */   }
/*    */   private static final Map<Integer, VideoFormat> lookupMap;
/*    */   
/*    */   VideoFormat(int paramInt1) {
/* 56 */     this.nativeType = paramInt1;
/*    */   }
/*    */   
/*    */   public int getNativeType() {
/* 60 */     return this.nativeType;
/*    */   }
/*    */   
/*    */   public boolean isRGB() {
/* 64 */     return (this == ARGB || this == BGRA_PRE);
/*    */   }
/*    */   
/*    */   public boolean isEqualTo(int paramInt) {
/* 68 */     return (this.nativeType == paramInt);
/*    */   }
/*    */   
/*    */   public static VideoFormat formatForType(int paramInt) {
/* 72 */     return lookupMap.get(Integer.valueOf(paramInt));
/*    */   }
/*    */   
/*    */   public static class FormatTypes {
/*    */     public static final int FORMAT_TYPE_ARGB = 1;
/*    */     public static final int FORMAT_TYPE_BGRA_PRE = 2;
/*    */     public static final int FORMAT_TYPE_YCBCR_420P = 100;
/*    */     public static final int FORMAT_TYPE_YCBCR_422 = 101;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\control\VideoFormat.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */