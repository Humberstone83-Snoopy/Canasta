package javafx.collections;

import java.util.Set;
import javafx.beans.Observable;

public interface ObservableSet<E> extends Set<E>, Observable {
  void addListener(SetChangeListener<? super E> paramSetChangeListener);
  
  void removeListener(SetChangeListener<? super E> paramSetChangeListener);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\ObservableSet.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */