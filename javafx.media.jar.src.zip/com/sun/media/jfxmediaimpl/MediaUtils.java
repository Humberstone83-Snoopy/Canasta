/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaUtils
/*     */ {
/*     */   public static final int MAX_FILE_SIGNATURE_LENGTH = 22;
/*     */   static final String NATIVE_MEDIA_ERROR_FORMAT = "Internal media error: %d";
/*     */   static final String NATIVE_MEDIA_WARNING_FORMAT = "Internal media warning: %d";
/*     */   public static final String CONTENT_TYPE_AIFF = "audio/x-aiff";
/*     */   public static final String CONTENT_TYPE_MP3 = "audio/mp3";
/*     */   public static final String CONTENT_TYPE_MPA = "audio/mpeg";
/*     */   public static final String CONTENT_TYPE_WAV = "audio/x-wav";
/*     */   public static final String CONTENT_TYPE_JFX = "video/x-javafx";
/*     */   public static final String CONTENT_TYPE_FLV = "video/x-flv";
/*     */   public static final String CONTENT_TYPE_MP4 = "video/mp4";
/*     */   public static final String CONTENT_TYPE_M4A = "audio/x-m4a";
/*     */   public static final String CONTENT_TYPE_M4V = "video/x-m4v";
/*     */   public static final String CONTENT_TYPE_M3U8 = "application/vnd.apple.mpegurl";
/*     */   public static final String CONTENT_TYPE_M3U = "audio/mpegurl";
/*     */   private static final String FILE_TYPE_AIF = "aif";
/*     */   private static final String FILE_TYPE_AIFF = "aiff";
/*     */   private static final String FILE_TYPE_FLV = "flv";
/*     */   private static final String FILE_TYPE_FXM = "fxm";
/*     */   private static final String FILE_TYPE_MPA = "mp3";
/*     */   private static final String FILE_TYPE_WAV = "wav";
/*     */   private static final String FILE_TYPE_MP4 = "mp4";
/*     */   private static final String FILE_TYPE_M4A = "m4a";
/*     */   private static final String FILE_TYPE_M4V = "m4v";
/*     */   private static final String FILE_TYPE_M3U8 = "m3u8";
/*     */   private static final String FILE_TYPE_M3U = "m3u";
/*     */   
/*     */   public static String fileSignatureToContentType(byte[] paramArrayOfbyte, int paramInt) throws MediaException {
/*  89 */     String str = "application/octet-stream";
/*     */     
/*  91 */     if (paramInt < 22)
/*  92 */       throw new MediaException("Empty signature!"); 
/*  93 */     if (paramArrayOfbyte.length < 22)
/*  94 */       return str; 
/*  95 */     if ((paramArrayOfbyte[0] & 0xFF) == 70 && (paramArrayOfbyte[1] & 0xFF) == 76 && (paramArrayOfbyte[2] & 0xFF) == 86)
/*     */     
/*     */     { 
/*  98 */       str = "video/x-javafx"; }
/*  99 */     else if (((paramArrayOfbyte[0] & 0xFF) << 24 | (paramArrayOfbyte[1] & 0xFF) << 16 | (paramArrayOfbyte[2] & 0xFF) << 8 | paramArrayOfbyte[3] & 0xFF) == 1380533830 && ((paramArrayOfbyte[8] & 0xFF) << 24 | (paramArrayOfbyte[9] & 0xFF) << 16 | (paramArrayOfbyte[10] & 0xFF) << 8 | paramArrayOfbyte[11] & 0xFF) == 1463899717 && ((paramArrayOfbyte[12] & 0xFF) << 24 | (paramArrayOfbyte[13] & 0xFF) << 16 | (paramArrayOfbyte[14] & 0xFF) << 8 | paramArrayOfbyte[15] & 0xFF) == 1718449184)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       if (((paramArrayOfbyte[20] & 0xFF) == 1 && (paramArrayOfbyte[21] & 0xFF) == 0) || ((paramArrayOfbyte[20] & 0xFF) == 3 && (paramArrayOfbyte[21] & 0xFF) == 0)) {
/* 112 */         str = "audio/x-wav";
/*     */       } else {
/* 114 */         throw new MediaException("Compressed WAVE is not supported!");
/*     */       }  }
/* 116 */     else if (((paramArrayOfbyte[0] & 0xFF) << 24 | (paramArrayOfbyte[1] & 0xFF) << 16 | (paramArrayOfbyte[2] & 0xFF) << 8 | paramArrayOfbyte[3] & 0xFF) == 1380533830 && ((paramArrayOfbyte[8] & 0xFF) << 24 | (paramArrayOfbyte[9] & 0xFF) << 16 | (paramArrayOfbyte[10] & 0xFF) << 8 | paramArrayOfbyte[11] & 0xFF) == 1463899717)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       str = "audio/x-wav"; }
/* 126 */     else if (((paramArrayOfbyte[0] & 0xFF) << 24 | (paramArrayOfbyte[1] & 0xFF) << 16 | (paramArrayOfbyte[2] & 0xFF) << 8 | paramArrayOfbyte[3] & 0xFF) == 1179603533 && ((paramArrayOfbyte[8] & 0xFF) << 24 | (paramArrayOfbyte[9] & 0xFF) << 16 | (paramArrayOfbyte[10] & 0xFF) << 8 | paramArrayOfbyte[11] & 0xFF) == 1095321158 && ((paramArrayOfbyte[12] & 0xFF) << 24 | (paramArrayOfbyte[13] & 0xFF) << 16 | (paramArrayOfbyte[14] & 0xFF) << 8 | paramArrayOfbyte[15] & 0xFF) == 1129270605)
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       str = "audio/x-aiff"; }
/* 139 */     else if ((paramArrayOfbyte[0] & 0xFF) == 73 && (paramArrayOfbyte[1] & 0xFF) == 68 && (paramArrayOfbyte[2] & 0xFF) == 51)
/*     */     
/*     */     { 
/* 142 */       str = "audio/mpeg"; }
/* 143 */     else if ((paramArrayOfbyte[0] & 0xFF) == 255 && (paramArrayOfbyte[1] & 0xE0) == 224 && (paramArrayOfbyte[2] & 0x18) != 8 && (paramArrayOfbyte[3] & 0x6) != 0)
/*     */     
/*     */     { 
/* 146 */       str = "audio/mpeg"; }
/* 147 */     else if (((paramArrayOfbyte[4] & 0xFF) << 24 | (paramArrayOfbyte[5] & 0xFF) << 16 | (paramArrayOfbyte[6] & 0xFF) << 8 | paramArrayOfbyte[7] & 0xFF) == 1718909296)
/*     */     
/*     */     { 
/*     */       
/* 151 */       if ((paramArrayOfbyte[8] & 0xFF) == 77 && (paramArrayOfbyte[9] & 0xFF) == 52 && (paramArrayOfbyte[10] & 0xFF) == 65 && (paramArrayOfbyte[11] & 0xFF) == 32) {
/* 152 */         str = "audio/x-m4a";
/* 153 */       } else if ((paramArrayOfbyte[8] & 0xFF) == 77 && (paramArrayOfbyte[9] & 0xFF) == 52 && (paramArrayOfbyte[10] & 0xFF) == 86 && (paramArrayOfbyte[11] & 0xFF) == 32) {
/* 154 */         str = "video/x-m4v";
/* 155 */       } else if ((paramArrayOfbyte[8] & 0xFF) == 109 && (paramArrayOfbyte[9] & 0xFF) == 112 && (paramArrayOfbyte[10] & 0xFF) == 52 && (paramArrayOfbyte[11] & 0xFF) == 50) {
/* 156 */         str = "video/mp4";
/* 157 */       } else if ((paramArrayOfbyte[8] & 0xFF) == 105 && (paramArrayOfbyte[9] & 0xFF) == 115 && (paramArrayOfbyte[10] & 0xFF) == 111 && (paramArrayOfbyte[11] & 0xFF) == 109) {
/* 158 */         str = "video/mp4";
/* 159 */       } else if ((paramArrayOfbyte[8] & 0xFF) == 77 && (paramArrayOfbyte[9] & 0xFF) == 80 && (paramArrayOfbyte[10] & 0xFF) == 52 && (paramArrayOfbyte[11] & 0xFF) == 32) {
/* 160 */         str = "video/mp4";
/*     */       }  }
/* 162 */     else { throw new MediaException("Unrecognized file signature!"); }
/*     */ 
/*     */     
/* 165 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String filenameToContentType(String paramString) {
/* 175 */     String str = "application/octet-stream";
/*     */     
/* 177 */     int i = paramString.lastIndexOf(".");
/*     */     
/* 179 */     if (i != -1) {
/* 180 */       String str1 = paramString.toLowerCase().substring(i + 1);
/*     */       
/* 182 */       if (str1.equals("aif") || str1.equals("aiff")) {
/* 183 */         str = "audio/x-aiff";
/* 184 */       } else if (str1.equals("flv") || str1.equals("fxm")) {
/* 185 */         str = "video/x-javafx";
/* 186 */       } else if (str1.equals("mp3")) {
/* 187 */         str = "audio/mpeg";
/* 188 */       } else if (str1.equals("wav")) {
/* 189 */         str = "audio/x-wav";
/* 190 */       } else if (str1.equals("mp4")) {
/* 191 */         str = "video/mp4";
/* 192 */       } else if (str1.equals("m4a")) {
/* 193 */         str = "audio/x-m4a";
/* 194 */       } else if (str1.equals("m4v")) {
/* 195 */         str = "video/x-m4v";
/* 196 */       } else if (str1.equals("m3u8")) {
/* 197 */         str = "application/vnd.apple.mpegurl";
/* 198 */       } else if (str1.equals("m3u")) {
/* 199 */         str = "audio/mpegurl";
/*     */       } 
/*     */     } 
/*     */     
/* 203 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void warning(Object paramObject, String paramString) {
/* 217 */     if ((((paramObject != null) ? 1 : 0) & ((paramString != null) ? 1 : 0)) != 0) {
/* 218 */       Logger.logMsg(3, paramObject
/* 219 */           .getClass().getName() + ": " + paramObject.getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void error(Object paramObject, int paramInt, String paramString, Throwable paramThrowable) {
/* 233 */     if (paramThrowable != null) {
/* 234 */       StackTraceElement[] arrayOfStackTraceElement = paramThrowable.getStackTrace();
/* 235 */       if (arrayOfStackTraceElement != null && arrayOfStackTraceElement.length > 0) {
/* 236 */         StackTraceElement stackTraceElement = arrayOfStackTraceElement[0];
/* 237 */         Logger.logMsg(4, stackTraceElement
/* 238 */             .getClassName(), stackTraceElement.getMethodName(), "( " + stackTraceElement
/* 239 */             .getLineNumber() + ") " + paramString);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 245 */     List<WeakReference<MediaErrorListener>> list = NativeMediaManager.getDefaultInstance().getMediaErrorListeners();
/* 246 */     if (!list.isEmpty()) {
/* 247 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = list.listIterator(); listIterator.hasNext(); ) {
/* 248 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/* 249 */         if (mediaErrorListener != null) {
/* 250 */           mediaErrorListener.onError(paramObject, paramInt, paramString); continue;
/*     */         } 
/* 252 */         listIterator.remove();
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 257 */       MediaException mediaException = (paramThrowable instanceof MediaException) ? (MediaException)paramThrowable : new MediaException(paramString, paramThrowable);
/* 258 */       throw mediaException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void nativeWarning(Object paramObject, int paramInt, String paramString) {
/* 269 */     String str = String.format("Internal media warning: %d", new Object[] { Integer.valueOf(paramInt) });
/*     */     
/* 271 */     if (paramString != null) {
/* 272 */       str = str + ": " + str;
/*     */     }
/*     */ 
/*     */     
/* 276 */     Logger.logMsg(3, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void nativeError(Object paramObject, MediaError paramMediaError) {
/* 287 */     Logger.logMsg(4, paramMediaError.description());
/*     */ 
/*     */ 
/*     */     
/* 291 */     List<WeakReference<MediaErrorListener>> list = NativeMediaManager.getDefaultInstance().getMediaErrorListeners();
/* 292 */     if (!list.isEmpty()) {
/* 293 */       for (ListIterator<WeakReference<MediaErrorListener>> listIterator = list.listIterator(); listIterator.hasNext(); ) {
/* 294 */         MediaErrorListener mediaErrorListener = ((WeakReference<MediaErrorListener>)listIterator.next()).get();
/* 295 */         if (mediaErrorListener != null) {
/* 296 */           mediaErrorListener.onError(paramObject, paramMediaError.code(), paramMediaError.description()); continue;
/*     */         } 
/* 298 */         listIterator.remove();
/*     */       } 
/*     */     } else {
/*     */       
/* 302 */       throw new MediaException(paramMediaError.description(), null, paramMediaError);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\MediaUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */