/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ranges.Range;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMSelectionImpl
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  38 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  41 */       DOMSelectionImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   DOMSelectionImpl(long paramLong) {
/*  46 */     this.peer = paramLong;
/*  47 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static DOMSelectionImpl create(long paramLong) {
/*  51 */     if (paramLong == 0L) return null; 
/*  52 */     return new DOMSelectionImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  58 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  62 */     return (paramObject instanceof DOMSelectionImpl && this.peer == ((DOMSelectionImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  66 */     long l = this.peer;
/*  67 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(DOMSelectionImpl paramDOMSelectionImpl) {
/*  71 */     return (paramDOMSelectionImpl == null) ? 0L : paramDOMSelectionImpl.getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static DOMSelectionImpl getImpl(long paramLong) {
/*  77 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getAnchorNode() {
/*  83 */     return NodeImpl.getImpl(getAnchorNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAnchorOffset() {
/*  88 */     return getAnchorOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getFocusNode() {
/*  93 */     return NodeImpl.getImpl(getFocusNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFocusOffset() {
/*  98 */     return getFocusOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getIsCollapsed() {
/* 103 */     return getIsCollapsedImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRangeCount() {
/* 108 */     return getRangeCountImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getBaseNode() {
/* 113 */     return NodeImpl.getImpl(getBaseNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getBaseOffset() {
/* 118 */     return getBaseOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getExtentNode() {
/* 123 */     return NodeImpl.getImpl(getExtentNodeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getExtentOffset() {
/* 128 */     return getExtentOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/* 133 */     return getTypeImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collapse(Node paramNode, int paramInt) throws DOMException {
/* 142 */     collapseImpl(getPeer(), 
/* 143 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collapseToEnd() throws DOMException {
/* 153 */     collapseToEndImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collapseToStart() throws DOMException {
/* 160 */     collapseToStartImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteFromDocument() {
/* 167 */     deleteFromDocumentImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsNode(Node paramNode, boolean paramBoolean) {
/* 175 */     return containsNodeImpl(getPeer(), 
/* 176 */         NodeImpl.getPeer(paramNode), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectAllChildren(Node paramNode) throws DOMException {
/* 186 */     selectAllChildrenImpl(getPeer(), 
/* 187 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extend(Node paramNode, int paramInt) throws DOMException {
/* 196 */     extendImpl(getPeer(), 
/* 197 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getRangeAt(int paramInt) throws DOMException {
/* 207 */     return RangeImpl.getImpl(getRangeAtImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllRanges() {
/* 216 */     removeAllRangesImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRange(Range paramRange) {
/* 223 */     addRangeImpl(getPeer(), 
/* 224 */         RangeImpl.getPeer(paramRange));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modify(String paramString1, String paramString2, String paramString3) {
/* 234 */     modifyImpl(getPeer(), paramString1, paramString2, paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseAndExtent(Node paramNode1, int paramInt1, Node paramNode2, int paramInt2) throws DOMException {
/* 250 */     setBaseAndExtentImpl(getPeer(), 
/* 251 */         NodeImpl.getPeer(paramNode1), paramInt1, 
/*     */         
/* 253 */         NodeImpl.getPeer(paramNode2), paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Node paramNode, int paramInt) throws DOMException {
/* 266 */     setPositionImpl(getPeer(), 
/* 267 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void empty() {
/* 277 */     emptyImpl(getPeer());
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native long getAnchorNodeImpl(long paramLong);
/*     */   
/*     */   static native int getAnchorOffsetImpl(long paramLong);
/*     */   
/*     */   static native long getFocusNodeImpl(long paramLong);
/*     */   
/*     */   static native int getFocusOffsetImpl(long paramLong);
/*     */   
/*     */   static native boolean getIsCollapsedImpl(long paramLong);
/*     */   
/*     */   static native int getRangeCountImpl(long paramLong);
/*     */   
/*     */   static native long getBaseNodeImpl(long paramLong);
/*     */   
/*     */   static native int getBaseOffsetImpl(long paramLong);
/*     */   
/*     */   static native long getExtentNodeImpl(long paramLong);
/*     */   
/*     */   static native int getExtentOffsetImpl(long paramLong);
/*     */   
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   static native void collapseImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native void collapseToEndImpl(long paramLong);
/*     */   
/*     */   static native void collapseToStartImpl(long paramLong);
/*     */   
/*     */   static native void deleteFromDocumentImpl(long paramLong);
/*     */   
/*     */   static native boolean containsNodeImpl(long paramLong1, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   static native void selectAllChildrenImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void extendImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native long getRangeAtImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native void removeAllRangesImpl(long paramLong);
/*     */   
/*     */   static native void addRangeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void modifyImpl(long paramLong, String paramString1, String paramString2, String paramString3);
/*     */   
/*     */   static native void setBaseAndExtentImpl(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2);
/*     */   
/*     */   static native void setPositionImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native void emptyImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\DOMSelectionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */