/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGSVGPath
/*    */   extends NGShape
/*    */ {
/*    */   private Shape path;
/*    */   
/*    */   public void setContent(Object paramObject) {
/* 38 */     this.path = (Shape)paramObject;
/* 39 */     geometryChanged();
/*    */   }
/*    */   
/*    */   public Object getGeometry() {
/* 43 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public Shape getShape() {
/* 48 */     return this.path;
/*    */   }
/*    */   
/*    */   public boolean acceptsPath2dOnUpdate() {
/* 52 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGSVGPath.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */