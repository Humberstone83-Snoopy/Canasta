package com.sun.javafx.scene.input;

import javafx.scene.input.InputMethodRequests;

public interface ExtendedInputMethodRequests extends InputMethodRequests {
  int getInsertPositionOffset();
  
  String getCommittedText(int paramInt1, int paramInt2);
  
  int getCommittedTextLength();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\ExtendedInputMethodRequests.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */