/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CGRect
/*    */ {
/* 29 */   CGPoint origin = new CGPoint();
/* 30 */   CGSize size = new CGSize();
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CGRect.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */