package com.sun.glass.events;

public class TouchEvent {
  public static final int TOUCH_PRESSED = 811;
  
  public static final int TOUCH_MOVED = 812;
  
  public static final int TOUCH_RELEASED = 813;
  
  public static final int TOUCH_STILL = 814;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glass\events\TouchEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */