/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontFileWriter
/*     */   implements FontConstants
/*     */ {
/*     */   byte[] header;
/*     */   int pos;
/*     */   int headerPos;
/*     */   int writtenBytes;
/*     */   FontTracker tracker;
/*     */   File file;
/*     */   RandomAccessFile raFile;
/*     */   
/*     */   public FontFileWriter() {
/*  56 */     if (!hasTempPermission()) {
/*  57 */       this.tracker = FontTracker.getTracker();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setLength(int paramInt) throws IOException {
/*  62 */     if (this.raFile == null) {
/*  63 */       throw new IOException("File not open");
/*     */     }
/*  65 */     checkTracker(paramInt);
/*  66 */     this.raFile.setLength(paramInt);
/*     */   }
/*     */   
/*     */   public void seek(int paramInt) throws IOException {
/*  70 */     if (this.raFile == null) {
/*  71 */       throw new IOException("File not open");
/*     */     }
/*  73 */     if (paramInt != this.pos) {
/*  74 */       this.raFile.seek(paramInt);
/*  75 */       this.pos = paramInt;
/*     */     } 
/*     */   }
/*     */   
/*     */   public File getFile() {
/*  80 */     return this.file;
/*     */   }
/*     */   
/*     */   public File openFile() throws PrivilegedActionException {
/*  84 */     this.pos = 0;
/*  85 */     this.writtenBytes = 0;
/*  86 */     this.file = AccessController.<File>doPrivileged(() -> {
/*     */           
/*     */           try {
/*     */             return Files.createTempFile("+JXF", ".tmp", (FileAttribute<?>[])new FileAttribute[0]).toFile();
/*  90 */           } catch (IOException iOException) {
/*     */             throw new IOException("Unable to create temporary file");
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  96 */     if (this.tracker != null) {
/*  97 */       this.tracker.add(this.file);
/*     */     }
/*  99 */     this.raFile = AccessController.<RandomAccessFile>doPrivileged(() -> new RandomAccessFile(this.file, "rw"));
/*     */ 
/*     */     
/* 102 */     if (this.tracker != null) {
/* 103 */       this.tracker.set(this.file, this.raFile);
/*     */     }
/* 105 */     if (PrismFontFactory.debugFonts) {
/* 106 */       System.err.println("Temp file created: " + this.file.getPath());
/*     */     }
/* 108 */     return this.file;
/*     */   }
/*     */   
/*     */   public void closeFile() throws IOException {
/* 112 */     if (this.header != null) {
/* 113 */       this.raFile.seek(0L);
/* 114 */       this.raFile.write(this.header);
/* 115 */       this.header = null;
/*     */     } 
/* 117 */     if (this.raFile != null) {
/* 118 */       this.raFile.close();
/* 119 */       this.raFile = null;
/*     */     } 
/* 121 */     if (this.tracker != null) {
/* 122 */       this.tracker.remove(this.file);
/*     */     }
/*     */   }
/*     */   
/*     */   public void deleteFile() {
/* 127 */     if (this.file != null) {
/* 128 */       if (this.tracker != null) {
/* 129 */         this.tracker.subBytes(this.writtenBytes);
/*     */       }
/*     */       try {
/* 132 */         closeFile();
/* 133 */       } catch (Exception exception) {}
/*     */       
/*     */       try {
/* 136 */         AccessController.doPrivileged(() -> {
/*     */               this.file.delete();
/*     */               
/*     */               return null;
/*     */             });
/*     */         
/* 142 */         if (PrismFontFactory.debugFonts) {
/* 143 */           System.err.println("Temp file delete: " + this.file.getPath());
/*     */         }
/* 145 */       } catch (Exception exception) {}
/*     */       
/* 147 */       this.file = null;
/* 148 */       this.raFile = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isTracking() {
/* 153 */     return (this.tracker != null);
/*     */   }
/*     */   
/*     */   private void checkTracker(int paramInt) throws IOException {
/* 157 */     if (this.tracker != null) {
/* 158 */       if (paramInt < 0 || this.pos > 33554432 - paramInt) {
/* 159 */         throw new IOException("File too big.");
/*     */       }
/* 161 */       if (this.tracker.getNumBytes() > 335544320 - paramInt) {
/* 162 */         throw new IOException("Total files too big.");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkSize(int paramInt) throws IOException {
/* 168 */     if (this.tracker != null) {
/* 169 */       checkTracker(paramInt);
/* 170 */       this.tracker.addBytes(paramInt);
/* 171 */       this.writtenBytes += paramInt;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setHeaderPos(int paramInt) {
/* 176 */     this.headerPos = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeader(int paramInt, short paramShort) throws IOException {
/* 183 */     int i = 12 + 16 * paramShort;
/* 184 */     checkSize(i);
/* 185 */     this.header = new byte[i];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     short s1 = paramShort;
/* 193 */     s1 = (short)(s1 | s1 >> 1);
/* 194 */     s1 = (short)(s1 | s1 >> 2);
/* 195 */     s1 = (short)(s1 | s1 >> 4);
/* 196 */     s1 = (short)(s1 | s1 >> 8);
/*     */ 
/*     */     
/* 199 */     s1 = (short)(s1 & (s1 >> 1 ^ 0xFFFFFFFF));
/* 200 */     short s2 = (short)(s1 * 16);
/* 201 */     short s3 = 0;
/* 202 */     while (s1 > 1) {
/* 203 */       s3 = (short)(s3 + 1);
/* 204 */       s1 = (short)(s1 >> 1);
/*     */     } 
/* 206 */     short s4 = (short)(paramShort * 16 - s2);
/*     */     
/* 208 */     setHeaderPos(0);
/* 209 */     writeInt(paramInt);
/* 210 */     writeShort(paramShort);
/* 211 */     writeShort(s2);
/* 212 */     writeShort(s3);
/* 213 */     writeShort(s4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDirectoryEntry(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws IOException {
/* 219 */     setHeaderPos(12 + 16 * paramInt1);
/* 220 */     writeInt(paramInt2);
/* 221 */     writeInt(paramInt3);
/* 222 */     writeInt(paramInt4);
/* 223 */     writeInt(paramInt5);
/*     */   }
/*     */   
/*     */   private void writeInt(int paramInt) throws IOException {
/* 227 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF000000) >> 24);
/* 228 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF0000) >> 16);
/* 229 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF00) >> 8);
/* 230 */     this.header[this.headerPos++] = (byte)(paramInt & 0xFF);
/*     */   }
/*     */   
/*     */   private void writeShort(short paramShort) throws IOException {
/* 234 */     this.header[this.headerPos++] = (byte)((paramShort & 0xFF00) >> 8);
/* 235 */     this.header[this.headerPos++] = (byte)(paramShort & 0xFF);
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] paramArrayOfbyte) throws IOException {
/* 239 */     writeBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 245 */     checkSize(paramInt2);
/* 246 */     this.raFile.write(paramArrayOfbyte, paramInt1, paramInt2);
/* 247 */     this.pos += paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasTempPermission() {
/* 256 */     if (System.getSecurityManager() == null) {
/* 257 */       return true;
/*     */     }
/* 259 */     File file = null;
/* 260 */     boolean bool = false;
/*     */     try {
/* 262 */       file = Files.createTempFile("+JXF", ".tmp", (FileAttribute<?>[])new FileAttribute[0]).toFile();
/* 263 */       file.delete();
/* 264 */       file = null;
/* 265 */       bool = true;
/* 266 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/* 269 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   static class FontTracker
/*     */   {
/*     */     public static final int MAX_FILE_SIZE = 33554432;
/*     */     
/*     */     public static final int MAX_TOTAL_BYTES = 335544320;
/*     */     
/*     */     static int numBytes;
/*     */     
/*     */     static FontTracker tracker;
/*     */     
/*     */     public static synchronized FontTracker getTracker() {
/* 284 */       if (tracker == null) {
/* 285 */         tracker = new FontTracker();
/*     */       }
/* 287 */       return tracker;
/*     */     }
/*     */     
/*     */     public synchronized int getNumBytes() {
/* 291 */       return numBytes;
/*     */     }
/*     */     
/*     */     public synchronized void addBytes(int param1Int) {
/* 295 */       numBytes += param1Int;
/*     */     }
/*     */     
/*     */     public synchronized void subBytes(int param1Int) {
/* 299 */       numBytes -= param1Int;
/*     */     }
/*     */     
/* 302 */     private static Semaphore cs = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static synchronized Semaphore getCS() {
/* 308 */       if (cs == null)
/*     */       {
/*     */         
/* 311 */         cs = new Semaphore(5, true);
/*     */       }
/* 313 */       return cs;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean acquirePermit() throws InterruptedException {
/* 318 */       return getCS().tryAcquire(120L, TimeUnit.SECONDS);
/*     */     }
/*     */     
/*     */     public void releasePermit() {
/* 322 */       getCS().release();
/*     */     }
/*     */     
/*     */     public void add(File param1File) {
/* 326 */       TempFileDeletionHook.add(param1File);
/*     */     }
/*     */     
/*     */     public void set(File param1File, RandomAccessFile param1RandomAccessFile) {
/* 330 */       TempFileDeletionHook.set(param1File, param1RandomAccessFile);
/*     */     }
/*     */     
/*     */     public void remove(File param1File) {
/* 334 */       TempFileDeletionHook.remove(param1File);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static class TempFileDeletionHook
/*     */     {
/* 341 */       private static HashMap<File, RandomAccessFile> files = new HashMap<>();
/*     */ 
/*     */       
/* 344 */       private static Thread t = null;
/*     */       static void init() {
/* 346 */         if (t == null)
/*     */         {
/* 348 */           AccessController.doPrivileged(() -> {
/*     */                 t = new Thread(());
/*     */                 Runtime.getRuntime().addShutdownHook(t);
/*     */                 return null;
/*     */               });
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       static synchronized void add(File param2File) {
/* 363 */         init();
/* 364 */         files.put(param2File, null);
/*     */       }
/*     */       
/*     */       static synchronized void set(File param2File, RandomAccessFile param2RandomAccessFile) {
/* 368 */         files.put(param2File, param2RandomAccessFile);
/*     */       }
/*     */       
/*     */       static synchronized void remove(File param2File) {
/* 372 */         files.remove(param2File);
/*     */       }
/*     */       
/*     */       static synchronized void runHooks() {
/* 376 */         if (files.isEmpty()) {
/*     */           return;
/*     */         }
/*     */         
/* 380 */         for (Map.Entry<File, RandomAccessFile> entry : files.entrySet()) {
/*     */ 
/*     */           
/*     */           try {
/* 384 */             if (entry.getValue() != null) {
/* 385 */               ((RandomAccessFile)entry.getValue()).close();
/*     */             }
/* 387 */           } catch (Exception exception) {}
/* 388 */           ((File)entry.getKey()).delete();
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\FontFileWriter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */