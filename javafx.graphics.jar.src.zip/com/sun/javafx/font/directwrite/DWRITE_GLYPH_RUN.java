package com.sun.javafx.font.directwrite;

class DWRITE_GLYPH_RUN {
  long fontFace;
  
  float fontEmSize;
  
  short glyphIndices;
  
  float glyphAdvances;
  
  float advanceOffset;
  
  float ascenderOffset;
  
  boolean isSideways;
  
  int bidiLevel;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWRITE_GLYPH_RUN.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */