/*     */ package com.sun.javafx.iio.gif;
/*     */ 
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import com.sun.javafx.iio.common.ImageLoaderImpl;
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GIFImageLoader2
/*     */   extends ImageLoaderImpl
/*     */ {
/*  45 */   static final byte[] FILE_SIG87 = new byte[] { 71, 73, 70, 56, 55, 97 };
/*  46 */   static final byte[] FILE_SIG89 = new byte[] { 71, 73, 70, 56, 57, 97 };
/*  47 */   static final byte[] NETSCAPE_SIG = new byte[] { 78, 69, 84, 83, 67, 65, 80, 69, 50, 46, 48 };
/*     */   
/*     */   static final int DEFAULT_FPS = 25;
/*  50 */   InputStream stream = null; int screenW; int screenH;
/*     */   int bgColor;
/*     */   byte[][] globalPalette;
/*     */   byte[] image;
/*  54 */   int loopCount = 1;
/*     */   
/*     */   public GIFImageLoader2(InputStream paramInputStream) throws IOException {
/*  57 */     super(GIFDescriptor.getInstance());
/*  58 */     this.stream = paramInputStream;
/*  59 */     readGlobalHeader();
/*     */   }
/*     */ 
/*     */   
/*     */   private void readGlobalHeader() throws IOException {
/*  64 */     byte[] arrayOfByte = readBytes(new byte[6]);
/*  65 */     if (!Arrays.equals(FILE_SIG87, arrayOfByte) && !Arrays.equals(FILE_SIG89, arrayOfByte)) {
/*  66 */       throw new IOException("Bad GIF signature!");
/*     */     }
/*  68 */     this.screenW = readShort();
/*  69 */     this.screenH = readShort();
/*  70 */     int i = readByte();
/*  71 */     this.bgColor = readByte();
/*  72 */     int j = readByte();
/*     */     
/*  74 */     if ((i & 0x80) != 0) {
/*  75 */       this.globalPalette = readPalete(2 << (i & 0x7), -1);
/*     */     }
/*  77 */     this.image = new byte[this.screenW * this.screenH * 4];
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[][] readPalete(int paramInt1, int paramInt2) throws IOException {
/*  82 */     byte[][] arrayOfByte = new byte[4][paramInt1];
/*  83 */     byte[] arrayOfByte1 = readBytes(new byte[paramInt1 * 3]); int i; byte b;
/*  84 */     for (i = 0, b = 0; i != paramInt1; i++) {
/*  85 */       for (byte b1 = 0; b1 != 3; b1++) {
/*  86 */         arrayOfByte[b1][i] = arrayOfByte1[b++];
/*     */       }
/*  88 */       arrayOfByte[3][i] = (i == paramInt2) ? 0 : -1;
/*     */     } 
/*  90 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   private void consumeAnExtension() throws IOException {
/*  95 */     for (int i = readByte(); i != 0; i = readByte()) {
/*  96 */       skipBytes(i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readAppExtension() throws IOException {
/* 101 */     int i = readByte();
/* 102 */     byte[] arrayOfByte = readBytes(new byte[i]);
/* 103 */     if (Arrays.equals(NETSCAPE_SIG, arrayOfByte)) {
/* 104 */       for (int j = readByte(); j != 0; j = readByte()) {
/* 105 */         byte[] arrayOfByte1 = readBytes(new byte[j]);
/* 106 */         byte b = arrayOfByte1[0];
/* 107 */         if (j == 3 && b == 1) {
/* 108 */           this.loopCount = arrayOfByte1[1] & 0xFF | (arrayOfByte1[2] & 0xFF) << 8;
/*     */         }
/*     */       } 
/*     */     } else {
/* 112 */       consumeAnExtension();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int readControlCode() throws IOException {
/* 119 */     int i = readByte();
/* 120 */     int j = readByte();
/* 121 */     int k = readShort();
/* 122 */     int m = readByte();
/*     */     
/* 124 */     if (i != 4 || readByte() != 0) {
/* 125 */       throw new IOException("Bad GIF GraphicControlExtension");
/*     */     }
/* 127 */     return ((j & 0x1F) << 24) + (m << 16) + k;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int waitForImageFrame() throws IOException {
/* 134 */     int j, i = 0;
/*     */     while (true) {
/* 136 */       j = this.stream.read();
/* 137 */       switch (j) {
/*     */         case 44:
/* 139 */           return i;
/*     */         case 33:
/* 141 */           switch (readByte()) {
/*     */             case 249:
/* 143 */               i = readControlCode();
/*     */               continue;
/*     */             case 255:
/* 146 */               readAppExtension();
/*     */               continue;
/*     */           } 
/* 149 */           consumeAnExtension();
/*     */           continue;
/*     */         case -1:
/*     */         case 59:
/* 153 */           return -1;
/*     */       }  break;
/* 155 */     }  throw new IOException("Unexpected GIF control characher 0x" + 
/* 156 */         String.format("%02X", new Object[] { Integer.valueOf(j) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decodeImage(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int[] paramArrayOfint) throws IOException {
/* 163 */     LZWDecoder lZWDecoder = new LZWDecoder();
/* 164 */     byte[] arrayOfByte = lZWDecoder.getString();
/* 165 */     byte b = 0; int i = 0, j = paramInt1;
/*     */     while (true) {
/* 167 */       int k = lZWDecoder.readString();
/* 168 */       if (k == -1) {
/* 169 */         lZWDecoder.waitForTerminator();
/*     */         return;
/*     */       } 
/* 172 */       for (int m = 0; m != k; ) {
/* 173 */         int n = (j < k - m) ? j : (k - m);
/* 174 */         System.arraycopy(arrayOfByte, m, paramArrayOfbyte, i, n);
/* 175 */         i += n;
/* 176 */         m += n;
/* 177 */         if ((j -= n) == 0) {
/* 178 */           if (++b == paramInt2) {
/* 179 */             lZWDecoder.waitForTerminator();
/*     */             return;
/*     */           } 
/* 182 */           byte b1 = (paramArrayOfint == null) ? b : paramArrayOfint[b];
/* 183 */           i = b1 * paramInt1;
/* 184 */           j = paramInt1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private int[] computeInterlaceReIndex(int paramInt) {
/* 192 */     int[] arrayOfInt = new int[paramInt]; byte b1 = 0; byte b2;
/* 193 */     for (b2 = 0; b2 < paramInt; ) { arrayOfInt[b1++] = b2; b2 += 8; }
/* 194 */      for (b2 = 4; b2 < paramInt; ) { arrayOfInt[b1++] = b2; b2 += 8; }
/* 195 */      for (b2 = 2; b2 < paramInt; ) { arrayOfInt[b1++] = b2; b2 += 4; }
/* 196 */      for (b2 = 1; b2 < paramInt; ) { arrayOfInt[b1++] = b2; b2 += 2; }
/* 197 */      return arrayOfInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageFrame load(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
/* 202 */     int i = waitForImageFrame();
/*     */     
/* 204 */     if (i < 0) {
/* 205 */       return null;
/*     */     }
/*     */     
/* 208 */     int j = readShort(), k = readShort(), m = readShort(), n = readShort();
/*     */ 
/*     */     
/* 211 */     if (j + m > this.screenW || k + n > this.screenH) {
/* 212 */       throw new IOException("Wrong GIF image frame size");
/*     */     }
/*     */     
/* 215 */     int i1 = readByte();
/*     */     
/* 217 */     boolean bool1 = ((i >>> 24 & 0x1) == 1) ? true : false;
/* 218 */     boolean bool2 = bool1 ? (i >>> 16 & 0xFF) : true;
/* 219 */     boolean bool3 = ((i1 & 0x80) != 0) ? true : false;
/* 220 */     boolean bool4 = ((i1 & 0x40) != 0) ? true : false;
/*     */     
/* 222 */     byte[][] arrayOfByte = bool3 ? readPalete(2 << (i1 & 0x7), bool2) : this.globalPalette;
/*     */     
/* 224 */     int[] arrayOfInt = ImageTools.computeDimensions(this.screenW, this.screenH, paramInt2, paramInt3, paramBoolean1);
/* 225 */     paramInt2 = arrayOfInt[0];
/* 226 */     paramInt3 = arrayOfInt[1];
/*     */     
/* 228 */     ImageMetadata imageMetadata = updateMetadata(paramInt2, paramInt3, i & 0xFFFF);
/*     */     
/* 230 */     int i2 = i >>> 26 & 0x7;
/* 231 */     byte[] arrayOfByte1 = new byte[m * n];
/* 232 */     decodeImage(arrayOfByte1, m, n, bool4 ? computeInterlaceReIndex(n) : null);
/*     */     
/* 234 */     ByteBuffer byteBuffer = decodePalette(arrayOfByte1, arrayOfByte, bool2, j, k, m, n, i2);
/*     */ 
/*     */     
/* 237 */     if (this.screenW != paramInt2 || this.screenH != paramInt3) {
/* 238 */       byteBuffer = ImageTools.scaleImage(byteBuffer, this.screenW, this.screenH, 4, paramInt2, paramInt3, paramBoolean2);
/*     */     }
/*     */ 
/*     */     
/* 242 */     return new ImageFrame(ImageStorage.ImageType.RGBA, byteBuffer, paramInt2, paramInt3, paramInt2 * 4, null, imageMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int readByte() throws IOException {
/* 248 */     int i = this.stream.read();
/* 249 */     if (i < 0) {
/* 250 */       throw new EOFException();
/*     */     }
/* 252 */     return i;
/*     */   }
/*     */   
/*     */   private int readShort() throws IOException {
/* 256 */     int i = readByte(), j = readByte();
/* 257 */     return i + (j << 8);
/*     */   }
/*     */   
/*     */   private byte[] readBytes(byte[] paramArrayOfbyte) throws IOException {
/* 261 */     return readBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   
/*     */   private byte[] readBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 265 */     while (paramInt2 > 0) {
/* 266 */       int i = this.stream.read(paramArrayOfbyte, paramInt1, paramInt2);
/* 267 */       if (i < 0) {
/* 268 */         throw new EOFException();
/*     */       }
/* 270 */       paramInt1 += i;
/* 271 */       paramInt2 -= i;
/*     */     } 
/* 273 */     return paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   private void skipBytes(int paramInt) throws IOException {
/* 277 */     ImageTools.skipFully(this.stream, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */   
/*     */   private void restoreToBackground(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 285 */     for (int i = 0; i != paramInt4; i++) {
/* 286 */       int j = ((paramInt2 + i) * this.screenW + paramInt1) * 4;
/* 287 */       for (int k = 0; k != paramInt3; j += 4, k++) {
/* 288 */         paramArrayOfbyte[j + 3] = 0;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteBuffer decodePalette(byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 297 */     byte[] arrayOfByte = (paramInt6 == 3) ? (byte[])this.image.clone() : this.image;
/*     */     
/* 299 */     for (int i = 0; i != paramInt5; i++) {
/* 300 */       int j = ((paramInt3 + i) * this.screenW + paramInt2) * 4;
/* 301 */       int k = i * paramInt4;
/* 302 */       if (paramInt1 < 0) {
/* 303 */         for (int m = 0; m != paramInt4; j += 4, m++) {
/* 304 */           int n = 0xFF & paramArrayOfbyte[k + m];
/* 305 */           arrayOfByte[j + 0] = paramArrayOfbyte1[0][n];
/* 306 */           arrayOfByte[j + 1] = paramArrayOfbyte1[1][n];
/* 307 */           arrayOfByte[j + 2] = paramArrayOfbyte1[2][n];
/* 308 */           arrayOfByte[j + 3] = paramArrayOfbyte1[3][n];
/*     */         } 
/*     */       } else {
/* 311 */         for (int m = 0; m != paramInt4; j += 4, m++) {
/* 312 */           int n = 0xFF & paramArrayOfbyte[k + m];
/* 313 */           if (n != paramInt1) {
/* 314 */             arrayOfByte[j + 0] = paramArrayOfbyte1[0][n];
/* 315 */             arrayOfByte[j + 1] = paramArrayOfbyte1[1][n];
/* 316 */             arrayOfByte[j + 2] = paramArrayOfbyte1[2][n];
/* 317 */             arrayOfByte[j + 3] = paramArrayOfbyte1[3][n];
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 323 */     if (paramInt6 != 3) arrayOfByte = (byte[])arrayOfByte.clone(); 
/* 324 */     if (paramInt6 == 2) restoreToBackground(this.image, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     
/* 326 */     return ByteBuffer.wrap(arrayOfByte);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ImageMetadata updateMetadata(int paramInt1, int paramInt2, int paramInt3) {
/* 332 */     ImageMetadata imageMetadata = new ImageMetadata(null, Boolean.valueOf(true), null, null, null, Integer.valueOf((paramInt3 != 0) ? (paramInt3 * 10) : 40), Integer.valueOf(this.loopCount), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), null, null, null);
/* 333 */     updateImageMetadata(imageMetadata);
/* 334 */     return imageMetadata;
/*     */   }
/*     */   
/*     */   class LZWDecoder
/*     */   {
/*     */     private final int initCodeSize;
/*     */     private final int clearCode;
/*     */     private final int eofCode;
/* 342 */     private int blockLength = 0; private int codeSize; private int codeMask; private int tableIndex; private int oldCode; private int blockPos = 0;
/* 343 */     private byte[] block = new byte[255];
/* 344 */     private int inData = 0; private int inBits = 0;
/*     */ 
/*     */     
/* 347 */     private int[] prefix = new int[4096];
/* 348 */     private byte[] suffix = new byte[4096];
/* 349 */     private byte[] initial = new byte[4096];
/* 350 */     private int[] length = new int[4096];
/* 351 */     private byte[] string = new byte[4096];
/*     */     
/*     */     public LZWDecoder() throws IOException {
/* 354 */       this.initCodeSize = GIFImageLoader2.this.readByte();
/* 355 */       this.clearCode = 1 << this.initCodeSize;
/* 356 */       this.eofCode = this.clearCode + 1;
/* 357 */       initTable();
/*     */     }
/*     */ 
/*     */     
/*     */     public final int readString() throws IOException {
/* 362 */       int i = getCode();
/* 363 */       if (i == this.eofCode)
/* 364 */         return -1; 
/* 365 */       if (i == this.clearCode) {
/* 366 */         initTable();
/* 367 */         i = getCode();
/* 368 */         if (i == this.eofCode) {
/* 369 */           return -1;
/*     */         }
/*     */       } else {
/*     */         
/* 373 */         int n, i1 = this.tableIndex;
/* 374 */         if (i < i1) {
/* 375 */           n = i;
/*     */         } else {
/* 377 */           n = this.oldCode;
/* 378 */           if (i != i1) {
/* 379 */             throw new IOException("Bad GIF LZW: Out-of-sequence code!");
/*     */           }
/*     */         } 
/*     */         
/* 383 */         int i2 = this.oldCode;
/*     */         
/* 385 */         this.prefix[i1] = i2;
/* 386 */         this.suffix[i1] = this.initial[n];
/* 387 */         this.initial[i1] = this.initial[i2];
/* 388 */         this.length[i1] = this.length[i2] + 1;
/*     */         
/* 390 */         this.tableIndex++;
/* 391 */         if (this.tableIndex == 1 << this.codeSize && this.tableIndex < 4096) {
/* 392 */           this.codeSize++;
/* 393 */           this.codeMask = (1 << this.codeSize) - 1;
/*     */         } 
/*     */       } 
/*     */       
/* 397 */       int j = i;
/* 398 */       int k = this.length[j];
/* 399 */       for (int m = k - 1; m >= 0; m--) {
/* 400 */         this.string[m] = this.suffix[j];
/* 401 */         j = this.prefix[j];
/*     */       } 
/*     */       
/* 404 */       this.oldCode = i;
/* 405 */       return k;
/*     */     }
/*     */     
/*     */     public final byte[] getString() {
/* 409 */       return this.string;
/*     */     }
/*     */     
/*     */     public final void waitForTerminator() throws IOException {
/* 413 */       GIFImageLoader2.this.consumeAnExtension();
/*     */     }
/*     */ 
/*     */     
/*     */     private void initTable() {
/* 418 */       int i = 1 << this.initCodeSize; int j;
/* 419 */       for (j = 0; j < i; j++) {
/* 420 */         this.prefix[j] = -1;
/* 421 */         this.suffix[j] = (byte)j;
/* 422 */         this.initial[j] = (byte)j;
/* 423 */         this.length[j] = 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 428 */       for (j = i; j < 4096; j++) {
/* 429 */         this.prefix[j] = -1;
/* 430 */         this.length[j] = 1;
/*     */       } 
/*     */       
/* 433 */       this.codeSize = this.initCodeSize + 1;
/* 434 */       this.codeMask = (1 << this.codeSize) - 1;
/* 435 */       this.tableIndex = i + 2;
/* 436 */       this.oldCode = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     private int getCode() throws IOException {
/* 441 */       while (this.inBits < this.codeSize) {
/* 442 */         this.inData |= nextByte() << this.inBits;
/* 443 */         this.inBits += 8;
/*     */       } 
/* 445 */       int i = this.inData & this.codeMask;
/* 446 */       this.inBits -= this.codeSize;
/* 447 */       this.inData >>>= this.codeSize;
/* 448 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     private int nextByte() throws IOException {
/* 453 */       if (this.blockPos == this.blockLength) {
/* 454 */         readData();
/*     */       }
/* 456 */       return this.block[this.blockPos++] & 0xFF;
/*     */     }
/*     */ 
/*     */     
/*     */     private void readData() throws IOException {
/* 461 */       this.blockPos = 0;
/* 462 */       this.blockLength = GIFImageLoader2.this.readByte();
/* 463 */       if (this.blockLength > 0) {
/* 464 */         GIFImageLoader2.this.readBytes(this.block, 0, this.blockLength);
/*     */       } else {
/* 466 */         throw new EOFException();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\gif\GIFImageLoader2.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */