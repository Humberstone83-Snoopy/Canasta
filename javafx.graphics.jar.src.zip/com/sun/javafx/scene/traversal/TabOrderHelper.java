/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.ParentHelper;
/*     */ import java.util.List;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TabOrderHelper
/*     */ {
/*     */   private static Node findPreviousFocusableInList(List<Node> paramList, int paramInt) {
/*  38 */     for (int i = paramInt; i >= 0; i--) {
/*  39 */       Node node = paramList.get(i);
/*     */       
/*  41 */       if (!isDisabledOrInvisible(node)) {
/*     */         
/*  43 */         ParentTraversalEngine parentTraversalEngine = (node instanceof Parent) ? ParentHelper.getTraversalEngine((Parent)node) : null;
/*  44 */         if (node instanceof Parent) {
/*  45 */           if (parentTraversalEngine != null && parentTraversalEngine.canTraverse()) {
/*  46 */             Node node1 = parentTraversalEngine.selectLast();
/*  47 */             if (node1 != null) {
/*  48 */               return node1;
/*     */             }
/*     */           } else {
/*  51 */             ObservableList<Node> observableList = ((Parent)node).getChildrenUnmodifiable();
/*  52 */             if (observableList.size() > 0) {
/*  53 */               Node node1 = findPreviousFocusableInList(observableList, observableList.size() - 1);
/*  54 */               if (node1 != null) {
/*  55 */                 return node1;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         }
/*  60 */         if ((parentTraversalEngine != null) ? parentTraversalEngine
/*  61 */           .isParentTraversable() : node
/*  62 */           .isFocusTraversable())
/*  63 */           return node; 
/*     */       } 
/*     */     } 
/*  66 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isDisabledOrInvisible(Node paramNode) {
/*  70 */     return (paramNode.isDisabled() || !NodeHelper.isTreeVisible(paramNode));
/*     */   }
/*     */   
/*     */   public static Node findPreviousFocusablePeer(Node paramNode, Parent paramParent) {
/*  74 */     Node node1 = paramNode;
/*  75 */     Node node2 = null;
/*  76 */     List<Node> list = findPeers(node1);
/*     */     
/*  78 */     if (list == null) {
/*     */       
/*  80 */       ObservableList<Node> observableList = ((Parent)paramNode).getChildrenUnmodifiable();
/*  81 */       return findPreviousFocusableInList(observableList, observableList.size() - 1);
/*     */     } 
/*     */     
/*  84 */     int i = list.indexOf(node1);
/*     */ 
/*     */     
/*  87 */     node2 = findPreviousFocusableInList(list, i - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     while (node2 == null && node1.getParent() != paramParent) {
/*     */ 
/*     */ 
/*     */       
/*  97 */       Parent parent = node1.getParent();
/*  98 */       if (parent != null) {
/*     */ 
/*     */         
/* 101 */         ParentTraversalEngine parentTraversalEngine = ParentHelper.getTraversalEngine(parent);
/* 102 */         if ((parentTraversalEngine != null) ? parentTraversalEngine.isParentTraversable() : parent.isFocusTraversable()) {
/* 103 */           node2 = parent;
/*     */         } else {
/* 105 */           List<Node> list1 = findPeers(parent);
/* 106 */           if (list1 != null) {
/* 107 */             int j = list1.indexOf(parent);
/* 108 */             node2 = findPreviousFocusableInList(list1, j - 1);
/*     */           } 
/*     */         } 
/*     */       } 
/* 112 */       node1 = parent;
/*     */     } 
/*     */     
/* 115 */     return node2;
/*     */   }
/*     */   
/*     */   private static List<Node> findPeers(Node paramNode) {
/* 119 */     ObservableList<Node> observableList = null;
/* 120 */     Parent parent = paramNode.getParent();
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (parent != null) {
/* 125 */       observableList = parent.getChildrenUnmodifiable();
/*     */     }
/* 127 */     return observableList;
/*     */   }
/*     */   
/*     */   private static Node findNextFocusableInList(List<Node> paramList, int paramInt) {
/* 131 */     for (int i = paramInt; i < paramList.size(); i++) {
/* 132 */       Node node = paramList.get(i);
/* 133 */       if (!isDisabledOrInvisible(node)) {
/*     */         
/* 135 */         ParentTraversalEngine parentTraversalEngine = (node instanceof Parent) ? ParentHelper.getTraversalEngine((Parent)node) : null;
/*     */         
/* 137 */         if ((parentTraversalEngine != null) ? parentTraversalEngine
/* 138 */           .isParentTraversable() : node
/* 139 */           .isFocusTraversable()) {
/* 140 */           return node;
/*     */         }
/* 142 */         if (node instanceof Parent)
/* 143 */           if (parentTraversalEngine != null && parentTraversalEngine.canTraverse()) {
/* 144 */             Node node1 = parentTraversalEngine.selectFirst();
/* 145 */             if (node1 != null) {
/* 146 */               return node1;
/*     */             
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 152 */             ObservableList<Node> observableList = ((Parent)node).getChildrenUnmodifiable();
/* 153 */             if (observableList.size() > 0) {
/* 154 */               Node node1 = findNextFocusableInList(observableList, 0);
/* 155 */               if (node1 != null)
/* 156 */                 return node1; 
/*     */             } 
/*     */           }  
/*     */       } 
/*     */     } 
/* 161 */     return null;
/*     */   }
/*     */   
/*     */   public static Node findNextFocusablePeer(Node paramNode, Parent paramParent, boolean paramBoolean) {
/* 165 */     Node node1 = paramNode;
/* 166 */     Node node2 = null;
/*     */ 
/*     */     
/* 169 */     if (paramBoolean && paramNode instanceof Parent) {
/* 170 */       node2 = findNextFocusableInList(((Parent)paramNode).getChildrenUnmodifiable(), 0);
/*     */     }
/*     */ 
/*     */     
/* 174 */     if (node2 == null) {
/* 175 */       List<Node> list = findPeers(node1);
/* 176 */       if (list == null)
/*     */       {
/*     */         
/* 179 */         return null;
/*     */       }
/* 181 */       int i = list.indexOf(node1);
/* 182 */       node2 = findNextFocusableInList(list, i + 1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 189 */     while (node2 == null && node1.getParent() != paramParent) {
/*     */ 
/*     */ 
/*     */       
/* 193 */       Parent parent = node1.getParent();
/* 194 */       if (parent != null) {
/* 195 */         List<Node> list = findPeers(parent);
/* 196 */         if (list != null) {
/* 197 */           int i = list.indexOf(parent);
/* 198 */           node2 = findNextFocusableInList(list, i + 1);
/*     */         } 
/*     */       } 
/* 201 */       node1 = parent;
/*     */     } 
/*     */     
/* 204 */     return node2;
/*     */   }
/*     */   
/*     */   public static Node getFirstTargetNode(Parent paramParent) {
/* 208 */     if (paramParent == null || isDisabledOrInvisible(paramParent)) return null;
/*     */     
/* 210 */     ParentTraversalEngine parentTraversalEngine = ParentHelper.getTraversalEngine(paramParent);
/* 211 */     if (parentTraversalEngine != null && parentTraversalEngine.canTraverse()) {
/* 212 */       Node node = parentTraversalEngine.selectFirst();
/* 213 */       if (node != null) {
/* 214 */         return node;
/*     */       }
/*     */     } 
/* 217 */     ObservableList<Node> observableList = paramParent.getChildrenUnmodifiable();
/* 218 */     for (Node node : observableList) {
/* 219 */       if (isDisabledOrInvisible(node))
/*     */         continue; 
/* 221 */       ParentTraversalEngine parentTraversalEngine1 = (node instanceof Parent) ? ParentHelper.getTraversalEngine((Parent)node) : null;
/* 222 */       if ((parentTraversalEngine1 != null) ? parentTraversalEngine1.isParentTraversable() : node.isFocusTraversable()) {
/* 223 */         return node;
/*     */       }
/* 225 */       if (node instanceof Parent) {
/* 226 */         Node node1 = getFirstTargetNode((Parent)node);
/* 227 */         if (node1 != null) return node1; 
/*     */       } 
/*     */     } 
/* 230 */     return null;
/*     */   }
/*     */   
/*     */   public static Node getLastTargetNode(Parent paramParent) {
/* 234 */     if (paramParent == null || isDisabledOrInvisible(paramParent)) return null;
/*     */     
/* 236 */     ParentTraversalEngine parentTraversalEngine = ParentHelper.getTraversalEngine(paramParent);
/* 237 */     if (parentTraversalEngine != null && parentTraversalEngine.canTraverse()) {
/* 238 */       Node node = parentTraversalEngine.selectLast();
/* 239 */       if (node != null) {
/* 240 */         return node;
/*     */       }
/*     */     } 
/* 243 */     ObservableList<Node> observableList = paramParent.getChildrenUnmodifiable();
/* 244 */     for (int i = observableList.size() - 1; i >= 0; i--) {
/* 245 */       Node node = observableList.get(i);
/* 246 */       if (!isDisabledOrInvisible(node)) {
/*     */         
/* 248 */         if (node instanceof Parent) {
/* 249 */           Node node1 = getLastTargetNode((Parent)node);
/* 250 */           if (node1 != null) return node1;
/*     */         
/*     */         } 
/* 253 */         ParentTraversalEngine parentTraversalEngine1 = (node instanceof Parent) ? ParentHelper.getTraversalEngine((Parent)node) : null;
/* 254 */         if ((parentTraversalEngine1 != null) ? parentTraversalEngine1.isParentTraversable() : node.isFocusTraversable())
/* 255 */           return node; 
/*     */       } 
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\TabOrderHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */