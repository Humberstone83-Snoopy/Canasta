/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CssFlags
/*    */ {
/* 39 */   CLEAN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   DIRTY_BRANCH,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   UPDATE,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   REAPPLY;
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\CssFlags.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */