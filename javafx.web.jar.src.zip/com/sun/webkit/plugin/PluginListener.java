package com.sun.webkit.plugin;

public interface PluginListener {
  void fwkRedraw(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
  
  String fwkEvent(int paramInt, String paramString1, String paramString2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\plugin\PluginListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */