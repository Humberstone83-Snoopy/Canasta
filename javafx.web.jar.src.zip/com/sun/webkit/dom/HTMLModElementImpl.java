/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLModElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLModElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLModElement
/*    */ {
/*    */   HTMLModElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLModElement getImpl(long paramLong) {
/* 36 */     return (HTMLModElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getCiteImpl(long paramLong);
/*    */   
/*    */   public String getCite() {
/* 42 */     return getCiteImpl(getPeer());
/*    */   }
/*    */   static native void setCiteImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setCite(String paramString) {
/* 47 */     setCiteImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDateTime() {
/* 52 */     return getDateTimeImpl(getPeer());
/*    */   }
/*    */   static native String getDateTimeImpl(long paramLong);
/*    */   
/*    */   public void setDateTime(String paramString) {
/* 57 */     setDateTimeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setDateTimeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLModElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */