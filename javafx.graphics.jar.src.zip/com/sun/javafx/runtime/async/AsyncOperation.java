package com.sun.javafx.runtime.async;

public interface AsyncOperation {
  void start();
  
  void cancel();
  
  boolean isCancelled();
  
  boolean isDone();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\AsyncOperation.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */