/*     */ package com.sun.javafx.print;
/*     */ 
/*     */ import javafx.print.JobSettings;
/*     */ import javafx.print.Paper;
/*     */ import javafx.print.PaperSource;
/*     */ import javafx.print.PrintResolution;
/*     */ import javafx.print.Printer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrintHelper
/*     */ {
/*     */   private static PrintAccessor printAccessor;
/*     */   
/*     */   static {
/*  44 */     forceInit(Printer.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrintResolution createPrintResolution(int paramInt1, int paramInt2) {
/*  51 */     return printAccessor.createPrintResolution(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Paper createPaper(String paramString, double paramDouble1, double paramDouble2, Units paramUnits) {
/*  58 */     return printAccessor.createPaper(paramString, paramDouble1, paramDouble2, paramUnits);
/*     */   }
/*     */   
/*     */   public static PaperSource createPaperSource(String paramString) {
/*  62 */     return printAccessor.createPaperSource(paramString);
/*     */   }
/*     */   
/*     */   public static JobSettings createJobSettings(Printer paramPrinter) {
/*  66 */     return printAccessor.createJobSettings(paramPrinter);
/*     */   }
/*     */   
/*     */   public static Printer createPrinter(PrinterImpl paramPrinterImpl) {
/*  70 */     return printAccessor.createPrinter(paramPrinterImpl);
/*     */   }
/*     */   
/*     */   public static PrinterImpl getPrinterImpl(Printer paramPrinter) {
/*  74 */     return printAccessor.getPrinterImpl(paramPrinter);
/*     */   }
/*     */   
/*     */   public static void setPrintAccessor(PrintAccessor paramPrintAccessor) {
/*  78 */     if (printAccessor != null) {
/*  79 */       throw new IllegalStateException();
/*     */     }
/*     */     
/*  82 */     printAccessor = paramPrintAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void forceInit(Class<?> paramClass) {
/*     */     try {
/* 104 */       Class.forName(paramClass.getName(), true, paramClass
/* 105 */           .getClassLoader());
/* 106 */     } catch (ClassNotFoundException classNotFoundException) {
/* 107 */       throw new AssertionError(classNotFoundException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface PrintAccessor {
/*     */     PrintResolution createPrintResolution(int param1Int1, int param1Int2);
/*     */     
/*     */     Paper createPaper(String param1String, double param1Double1, double param1Double2, Units param1Units);
/*     */     
/*     */     PaperSource createPaperSource(String param1String);
/*     */     
/*     */     JobSettings createJobSettings(Printer param1Printer);
/*     */     
/*     */     Printer createPrinter(PrinterImpl param1PrinterImpl);
/*     */     
/*     */     PrinterImpl getPrinterImpl(Printer param1Printer);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\print\PrintHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */