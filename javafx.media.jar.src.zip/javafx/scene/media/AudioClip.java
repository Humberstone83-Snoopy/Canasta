/*     */ package javafx.scene.media;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.DoublePropertyBase;
/*     */ import javafx.beans.property.IntegerProperty;
/*     */ import javafx.beans.property.IntegerPropertyBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AudioClip
/*     */ {
/*     */   private String sourceURL;
/*     */   private com.sun.media.jfxmedia.AudioClip audioClip;
/*     */   private DoubleProperty volume;
/*     */   private DoubleProperty balance;
/*     */   private DoubleProperty rate;
/*     */   private DoubleProperty pan;
/*     */   private IntegerProperty priority;
/*     */   public static final int INDEFINITE = -1;
/*     */   private IntegerProperty cycleCount;
/*     */   
/*     */   public AudioClip(@NamedArg("source") String paramString) {
/*  80 */     URI uRI = URI.create(paramString);
/*  81 */     this.sourceURL = paramString;
/*     */     try {
/*  83 */       this.audioClip = com.sun.media.jfxmedia.AudioClip.load(uRI);
/*  84 */     } catch (URISyntaxException uRISyntaxException) {
/*  85 */       throw new IllegalArgumentException(uRISyntaxException);
/*  86 */     } catch (FileNotFoundException fileNotFoundException) {
/*  87 */       throw new MediaException(MediaException.Type.MEDIA_UNAVAILABLE, fileNotFoundException.getMessage());
/*  88 */     } catch (IOException iOException) {
/*  89 */       throw new MediaException(MediaException.Type.MEDIA_INACCESSIBLE, iOException.getMessage());
/*  90 */     } catch (MediaException mediaException) {
/*  91 */       throw new MediaException(MediaException.Type.MEDIA_UNSUPPORTED, mediaException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSource() {
/* 100 */     return this.sourceURL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setVolume(double paramDouble) {
/* 119 */     volumeProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getVolume() {
/* 128 */     return (null == this.volume) ? 1.0D : this.volume.get();
/*     */   }
/*     */   public DoubleProperty volumeProperty() {
/* 131 */     if (this.volume == null) {
/* 132 */       this.volume = new DoublePropertyBase(1.0D)
/*     */         {
/*     */           protected void invalidated() {
/* 135 */             if (null != AudioClip.this.audioClip) {
/* 136 */               AudioClip.this.audioClip.setVolume(AudioClip.this.volume.get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 142 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 147 */             return "volume";
/*     */           }
/*     */         };
/*     */     }
/* 151 */     return this.volume;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBalance(double paramDouble) {
/* 170 */     balanceProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getBalance() {
/* 179 */     return (null != this.balance) ? this.balance.get() : 0.0D;
/*     */   }
/*     */   public DoubleProperty balanceProperty() {
/* 182 */     if (null == this.balance) {
/* 183 */       this.balance = new DoublePropertyBase(0.0D)
/*     */         {
/*     */           protected void invalidated() {
/* 186 */             if (null != AudioClip.this.audioClip) {
/* 187 */               AudioClip.this.audioClip.setBalance(AudioClip.this.balance.get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 193 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 198 */             return "balance";
/*     */           }
/*     */         };
/*     */     }
/* 202 */     return this.balance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRate(double paramDouble) {
/* 220 */     rateProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRate() {
/* 229 */     return (null != this.rate) ? this.rate.get() : 1.0D;
/*     */   }
/*     */   public DoubleProperty rateProperty() {
/* 232 */     if (null == this.rate) {
/* 233 */       this.rate = new DoublePropertyBase(1.0D)
/*     */         {
/*     */           protected void invalidated() {
/* 236 */             if (null != AudioClip.this.audioClip) {
/* 237 */               AudioClip.this.audioClip.setPlaybackRate(AudioClip.this.rate.get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 243 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 248 */             return "rate";
/*     */           }
/*     */         };
/*     */     }
/* 252 */     return this.rate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPan(double paramDouble) {
/* 273 */     panProperty().set(paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getPan() {
/* 282 */     return (null != this.pan) ? this.pan.get() : 0.0D;
/*     */   }
/*     */   public DoubleProperty panProperty() {
/* 285 */     if (null == this.pan) {
/* 286 */       this.pan = new DoublePropertyBase(0.0D)
/*     */         {
/*     */           protected void invalidated() {
/* 289 */             if (null != AudioClip.this.audioClip) {
/* 290 */               AudioClip.this.audioClip.setPan(AudioClip.this.pan.get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 296 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 301 */             return "pan";
/*     */           }
/*     */         };
/*     */     }
/* 305 */     return this.pan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPriority(int paramInt) {
/* 326 */     priorityProperty().set(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPriority() {
/* 335 */     return (null != this.priority) ? this.priority.get() : 0;
/*     */   }
/*     */   public IntegerProperty priorityProperty() {
/* 338 */     if (null == this.priority) {
/* 339 */       this.priority = new IntegerPropertyBase(0)
/*     */         {
/*     */           protected void invalidated() {
/* 342 */             if (null != AudioClip.this.audioClip) {
/* 343 */               AudioClip.this.audioClip.setPriority(AudioClip.this.priority.get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 349 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 354 */             return "priority";
/*     */           }
/*     */         };
/*     */     }
/* 358 */     return this.priority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCycleCount(int paramInt) {
/* 386 */     cycleCountProperty().set(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCycleCount() {
/* 395 */     return (null != this.cycleCount) ? this.cycleCount.get() : 1;
/*     */   }
/*     */   public IntegerProperty cycleCountProperty() {
/* 398 */     if (null == this.cycleCount) {
/* 399 */       this.cycleCount = new IntegerPropertyBase(1)
/*     */         {
/*     */           protected void invalidated() {
/* 402 */             if (null != AudioClip.this.audioClip) {
/* 403 */               int i = AudioClip.this.cycleCount.get();
/* 404 */               if (-1 != i) {
/* 405 */                 i = Math.max(1, i);
/* 406 */                 AudioClip.this.audioClip.setLoopCount(i - 1);
/*     */               } else {
/* 408 */                 AudioClip.this.audioClip.setLoopCount(i);
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 415 */             return AudioClip.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 420 */             return "cycleCount";
/*     */           }
/*     */         };
/*     */     }
/* 424 */     return this.cycleCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void play() {
/* 430 */     if (null != this.audioClip) {
/* 431 */       this.audioClip.play();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play(double paramDouble) {
/* 441 */     if (null != this.audioClip) {
/* 442 */       this.audioClip.play(paramDouble);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt) {
/* 464 */     if (null != this.audioClip) {
/* 465 */       this.audioClip.play(paramDouble1, paramDouble2, paramDouble3, paramDouble4, this.audioClip.loopCount(), paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPlaying() {
/* 475 */     return (null != this.audioClip && this.audioClip.isPlaying());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 482 */     if (null != this.audioClip)
/* 483 */       this.audioClip.stop(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\AudioClip.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */