/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLFormElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLFormElement
/*     */ {
/*     */   HTMLFormElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLFormElement getImpl(long paramLong) {
/*  37 */     return (HTMLFormElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAcceptCharsetImpl(long paramLong);
/*     */   
/*     */   public String getAcceptCharset() {
/*  43 */     return getAcceptCharsetImpl(getPeer());
/*     */   }
/*     */   static native void setAcceptCharsetImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAcceptCharset(String paramString) {
/*  48 */     setAcceptCharsetImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAction() {
/*  53 */     return getActionImpl(getPeer());
/*     */   }
/*     */   static native String getActionImpl(long paramLong);
/*     */   
/*     */   public void setAction(String paramString) {
/*  58 */     setActionImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setActionImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAutocomplete() {
/*  63 */     return getAutocompleteImpl(getPeer());
/*     */   }
/*     */   static native String getAutocompleteImpl(long paramLong);
/*     */   
/*     */   public void setAutocomplete(String paramString) {
/*  68 */     setAutocompleteImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAutocompleteImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getEnctype() {
/*  73 */     return getEnctypeImpl(getPeer());
/*     */   }
/*     */   static native String getEnctypeImpl(long paramLong);
/*     */   
/*     */   public void setEnctype(String paramString) {
/*  78 */     setEnctypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setEnctypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getEncoding() {
/*  83 */     return getEncodingImpl(getPeer());
/*     */   }
/*     */   static native String getEncodingImpl(long paramLong);
/*     */   
/*     */   public void setEncoding(String paramString) {
/*  88 */     setEncodingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setEncodingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMethod() {
/*  93 */     return getMethodImpl(getPeer());
/*     */   }
/*     */   static native String getMethodImpl(long paramLong);
/*     */   
/*     */   public void setMethod(String paramString) {
/*  98 */     setMethodImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMethodImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getName() {
/* 103 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 108 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getNoValidate() {
/* 113 */     return getNoValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getNoValidateImpl(long paramLong);
/*     */   
/*     */   public void setNoValidate(boolean paramBoolean) {
/* 118 */     setNoValidateImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setNoValidateImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getTarget() {
/* 123 */     return getTargetImpl(getPeer());
/*     */   }
/*     */   static native String getTargetImpl(long paramLong);
/*     */   
/*     */   public void setTarget(String paramString) {
/* 128 */     setTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public HTMLCollection getElements() {
/* 133 */     return HTMLCollectionImpl.getImpl(getElementsImpl(getPeer()));
/*     */   }
/*     */   static native long getElementsImpl(long paramLong);
/*     */   
/*     */   public int getLength() {
/* 138 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public void submit() {
/* 146 */     submitImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void submitImpl(long paramLong);
/*     */   
/*     */   public void reset() {
/* 153 */     resetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void resetImpl(long paramLong);
/*     */   
/*     */   public boolean checkValidity() {
/* 160 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLFormElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */