/*    */ package com.sun.media.jfxmediaimpl;
/*    */ 
/*    */ import com.sun.media.jfxmedia.effects.AudioEqualizer;
/*    */ import com.sun.media.jfxmedia.effects.EqualizerBand;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class NativeAudioEqualizer
/*    */   implements AudioEqualizer
/*    */ {
/*    */   private final long nativeRef;
/*    */   
/*    */   NativeAudioEqualizer(long paramLong) {
/* 46 */     if (paramLong == 0L) {
/* 47 */       throw new IllegalArgumentException("Invalid native media reference");
/*    */     }
/*    */     
/* 50 */     this.nativeRef = paramLong;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getEnabled() {
/* 59 */     return nativeGetEnabled(this.nativeRef);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEnabled(boolean paramBoolean) {
/* 64 */     nativeSetEnabled(this.nativeRef, paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public EqualizerBand addBand(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 69 */     return (nativeGetNumBands(this.nativeRef) >= 64 && paramDouble3 >= -24.0D && paramDouble3 <= 12.0D) ? 
/*    */       
/* 71 */       null : nativeAddBand(this.nativeRef, paramDouble1, paramDouble2, paramDouble3);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean removeBand(double paramDouble) {
/* 76 */     return (paramDouble > 0.0D) ? nativeRemoveBand(this.nativeRef, paramDouble) : false;
/*    */   }
/*    */   
/*    */   private native boolean nativeGetEnabled(long paramLong);
/*    */   
/*    */   private native void nativeSetEnabled(long paramLong, boolean paramBoolean);
/*    */   
/*    */   private native int nativeGetNumBands(long paramLong);
/*    */   
/*    */   private native EqualizerBand nativeAddBand(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3);
/*    */   
/*    */   private native boolean nativeRemoveBand(long paramLong, double paramDouble);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeAudioEqualizer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */