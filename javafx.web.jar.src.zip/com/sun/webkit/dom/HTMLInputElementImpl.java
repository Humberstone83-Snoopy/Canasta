/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ import org.w3c.dom.html.HTMLInputElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLInputElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLInputElement
/*     */ {
/*     */   HTMLInputElementImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLInputElement getImpl(long paramLong) {
/*  39 */     return (HTMLInputElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAcceptImpl(long paramLong);
/*     */   
/*     */   public String getAccept() {
/*  45 */     return getAcceptImpl(getPeer());
/*     */   }
/*     */   static native void setAcceptImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAccept(String paramString) {
/*  50 */     setAcceptImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAlt() {
/*  55 */     return getAltImpl(getPeer());
/*     */   }
/*     */   static native String getAltImpl(long paramLong);
/*     */   
/*     */   public void setAlt(String paramString) {
/*  60 */     setAltImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAltImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAutocomplete() {
/*  65 */     return getAutocompleteImpl(getPeer());
/*     */   }
/*     */   static native String getAutocompleteImpl(long paramLong);
/*     */   
/*     */   public void setAutocomplete(String paramString) {
/*  70 */     setAutocompleteImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAutocompleteImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getAutofocus() {
/*  75 */     return getAutofocusImpl(getPeer());
/*     */   }
/*     */   static native boolean getAutofocusImpl(long paramLong);
/*     */   
/*     */   public void setAutofocus(boolean paramBoolean) {
/*  80 */     setAutofocusImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setAutofocusImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getDefaultChecked() {
/*  85 */     return getDefaultCheckedImpl(getPeer());
/*     */   }
/*     */   static native boolean getDefaultCheckedImpl(long paramLong);
/*     */   
/*     */   public void setDefaultChecked(boolean paramBoolean) {
/*  90 */     setDefaultCheckedImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDefaultCheckedImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getChecked() {
/*  95 */     return getCheckedImpl(getPeer());
/*     */   }
/*     */   static native boolean getCheckedImpl(long paramLong);
/*     */   
/*     */   public void setChecked(boolean paramBoolean) {
/* 100 */     setCheckedImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setCheckedImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getDirName() {
/* 105 */     return getDirNameImpl(getPeer());
/*     */   }
/*     */   static native String getDirNameImpl(long paramLong);
/*     */   
/*     */   public void setDirName(String paramString) {
/* 110 */     setDirNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDirNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getDisabled() {
/* 115 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/* 120 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public HTMLFormElement getForm() {
/* 125 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   public String getFormAction() {
/* 130 */     return getFormActionImpl(getPeer());
/*     */   }
/*     */   static native String getFormActionImpl(long paramLong);
/*     */   
/*     */   public void setFormAction(String paramString) {
/* 135 */     setFormActionImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormActionImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFormEnctype() {
/* 140 */     return getFormEnctypeImpl(getPeer());
/*     */   }
/*     */   static native String getFormEnctypeImpl(long paramLong);
/*     */   
/*     */   public void setFormEnctype(String paramString) {
/* 145 */     setFormEnctypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormEnctypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getFormMethod() {
/* 150 */     return getFormMethodImpl(getPeer());
/*     */   }
/*     */   static native String getFormMethodImpl(long paramLong);
/*     */   
/*     */   public void setFormMethod(String paramString) {
/* 155 */     setFormMethodImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormMethodImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getFormNoValidate() {
/* 160 */     return getFormNoValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getFormNoValidateImpl(long paramLong);
/*     */   
/*     */   public void setFormNoValidate(boolean paramBoolean) {
/* 165 */     setFormNoValidateImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setFormNoValidateImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getFormTarget() {
/* 170 */     return getFormTargetImpl(getPeer());
/*     */   }
/*     */   static native String getFormTargetImpl(long paramLong);
/*     */   
/*     */   public void setFormTarget(String paramString) {
/* 175 */     setFormTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setFormTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getHeight() {
/* 180 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native int getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(int paramInt) {
/* 185 */     setHeightImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, int paramInt);
/*     */   
/*     */   public boolean getIndeterminate() {
/* 190 */     return getIndeterminateImpl(getPeer());
/*     */   }
/*     */   static native boolean getIndeterminateImpl(long paramLong);
/*     */   
/*     */   public void setIndeterminate(boolean paramBoolean) {
/* 195 */     setIndeterminateImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setIndeterminateImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getMax() {
/* 200 */     return getMaxImpl(getPeer());
/*     */   }
/*     */   static native String getMaxImpl(long paramLong);
/*     */   
/*     */   public void setMax(String paramString) {
/* 205 */     setMaxImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMaxImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getMaxLength() {
/* 210 */     return getMaxLengthImpl(getPeer());
/*     */   }
/*     */   static native int getMaxLengthImpl(long paramLong);
/*     */   
/*     */   public void setMaxLength(int paramInt) throws DOMException {
/* 215 */     setMaxLengthImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setMaxLengthImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getMin() {
/* 220 */     return getMinImpl(getPeer());
/*     */   }
/*     */   static native String getMinImpl(long paramLong);
/*     */   
/*     */   public void setMin(String paramString) {
/* 225 */     setMinImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMinImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getMultiple() {
/* 230 */     return getMultipleImpl(getPeer());
/*     */   }
/*     */   static native boolean getMultipleImpl(long paramLong);
/*     */   
/*     */   public void setMultiple(boolean paramBoolean) {
/* 235 */     setMultipleImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setMultipleImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getName() {
/* 240 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 245 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPattern() {
/* 250 */     return getPatternImpl(getPeer());
/*     */   }
/*     */   static native String getPatternImpl(long paramLong);
/*     */   
/*     */   public void setPattern(String paramString) {
/* 255 */     setPatternImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPatternImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPlaceholder() {
/* 260 */     return getPlaceholderImpl(getPeer());
/*     */   }
/*     */   static native String getPlaceholderImpl(long paramLong);
/*     */   
/*     */   public void setPlaceholder(String paramString) {
/* 265 */     setPlaceholderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPlaceholderImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getReadOnly() {
/* 270 */     return getReadOnlyImpl(getPeer());
/*     */   }
/*     */   static native boolean getReadOnlyImpl(long paramLong);
/*     */   
/*     */   public void setReadOnly(boolean paramBoolean) {
/* 275 */     setReadOnlyImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setReadOnlyImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getRequired() {
/* 280 */     return getRequiredImpl(getPeer());
/*     */   }
/*     */   static native boolean getRequiredImpl(long paramLong);
/*     */   
/*     */   public void setRequired(boolean paramBoolean) {
/* 285 */     setRequiredImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setRequiredImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getSize() {
/* 290 */     return getSizeImpl(getPeer());
/*     */   }
/*     */   static native String getSizeImpl(long paramLong);
/*     */   
/*     */   public void setSize(String paramString) {
/* 295 */     setSizeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSizeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrc() {
/* 300 */     return getSrcImpl(getPeer());
/*     */   }
/*     */   static native String getSrcImpl(long paramLong);
/*     */   
/*     */   public void setSrc(String paramString) {
/* 305 */     setSrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getStep() {
/* 310 */     return getStepImpl(getPeer());
/*     */   }
/*     */   static native String getStepImpl(long paramLong);
/*     */   
/*     */   public void setStep(String paramString) {
/* 315 */     setStepImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setStepImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 320 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 325 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getDefaultValue() {
/* 330 */     return getDefaultValueImpl(getPeer());
/*     */   }
/*     */   static native String getDefaultValueImpl(long paramLong);
/*     */   
/*     */   public void setDefaultValue(String paramString) {
/* 335 */     setDefaultValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDefaultValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getValue() {
/* 340 */     return getValueImpl(getPeer());
/*     */   }
/*     */   static native String getValueImpl(long paramLong);
/*     */   
/*     */   public void setValue(String paramString) {
/* 345 */     setValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public long getValueAsDate() {
/* 350 */     return getValueAsDateImpl(getPeer());
/*     */   }
/*     */   static native long getValueAsDateImpl(long paramLong);
/*     */   
/*     */   public void setValueAsDate(long paramLong) throws DOMException {
/* 355 */     setValueAsDateImpl(getPeer(), paramLong);
/*     */   }
/*     */   static native void setValueAsDateImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   public double getValueAsNumber() {
/* 360 */     return getValueAsNumberImpl(getPeer());
/*     */   }
/*     */   static native double getValueAsNumberImpl(long paramLong);
/*     */   
/*     */   public void setValueAsNumber(double paramDouble) throws DOMException {
/* 365 */     setValueAsNumberImpl(getPeer(), paramDouble);
/*     */   }
/*     */   static native void setValueAsNumberImpl(long paramLong, double paramDouble);
/*     */   
/*     */   public int getWidth() {
/* 370 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native int getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(int paramInt) {
/* 375 */     setWidthImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setWidthImpl(long paramLong, int paramInt);
/*     */   
/*     */   public boolean getWillValidate() {
/* 380 */     return getWillValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getWillValidateImpl(long paramLong);
/*     */   
/*     */   public String getValidationMessage() {
/* 385 */     return getValidationMessageImpl(getPeer());
/*     */   }
/*     */   static native String getValidationMessageImpl(long paramLong);
/*     */   
/*     */   public NodeList getLabels() {
/* 390 */     return NodeListImpl.getImpl(getLabelsImpl(getPeer()));
/*     */   }
/*     */   static native long getLabelsImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/* 395 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public void setAlign(String paramString) {
/* 400 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getUseMap() {
/* 405 */     return getUseMapImpl(getPeer());
/*     */   }
/*     */   static native String getUseMapImpl(long paramLong);
/*     */   
/*     */   public void setUseMap(String paramString) {
/* 410 */     setUseMapImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setUseMapImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getIncremental() {
/* 415 */     return getIncrementalImpl(getPeer());
/*     */   }
/*     */   static native boolean getIncrementalImpl(long paramLong);
/*     */   
/*     */   public void setIncremental(boolean paramBoolean) {
/* 420 */     setIncrementalImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setIncrementalImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getAccessKey() {
/* 425 */     return getAccessKeyImpl(getPeer());
/*     */   }
/*     */   static native String getAccessKeyImpl(long paramLong);
/*     */   
/*     */   public void setAccessKey(String paramString) {
/* 430 */     setAccessKeyImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void stepUp(int paramInt) throws DOMException {
/* 438 */     stepUpImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void stepUpImpl(long paramLong, int paramInt);
/*     */ 
/*     */   
/*     */   public void stepDown(int paramInt) throws DOMException {
/* 447 */     stepDownImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void stepDownImpl(long paramLong, int paramInt);
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 456 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */   
/*     */   public void setCustomValidity(String paramString) {
/* 463 */     setCustomValidityImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void select() {
/* 472 */     selectImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void selectImpl(long paramLong);
/*     */   
/*     */   public void setRangeText(String paramString) throws DOMException {
/* 479 */     setRangeTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setRangeTextImpl(long paramLong, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRangeTextEx(String paramString1, int paramInt1, int paramInt2, String paramString2) throws DOMException {
/* 491 */     setRangeTextExImpl(getPeer(), paramString1, paramInt1, paramInt2, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setRangeTextExImpl(long paramLong, String paramString1, int paramInt1, int paramInt2, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void click() {
/* 506 */     clickImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void clickImpl(long paramLong);
/*     */   
/*     */   public void setValueForUser(String paramString) {
/* 513 */     setValueForUserImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setValueForUserImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLInputElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */