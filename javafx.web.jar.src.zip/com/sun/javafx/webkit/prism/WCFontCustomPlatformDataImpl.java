/*    */ package com.sun.javafx.webkit.prism;
/*    */ 
/*    */ import com.sun.javafx.font.FontFactory;
/*    */ import com.sun.javafx.font.PGFont;
/*    */ import com.sun.prism.GraphicsPipeline;
/*    */ import com.sun.webkit.graphics.WCFont;
/*    */ import com.sun.webkit.graphics.WCFontCustomPlatformData;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WCFontCustomPlatformDataImpl
/*    */   extends WCFontCustomPlatformData
/*    */ {
/*    */   private final PGFont font;
/*    */   
/*    */   WCFontCustomPlatformDataImpl(InputStream paramInputStream) throws IOException {
/* 42 */     FontFactory fontFactory = GraphicsPipeline.getPipeline().getFontFactory();
/* 43 */     PGFont[] arrayOfPGFont = fontFactory.loadEmbeddedFont(null, paramInputStream, 10.0F, false, false);
/*    */     
/* 45 */     if (arrayOfPGFont == null) {
/* 46 */       throw new IOException("Error loading font");
/*    */     }
/* 48 */     this.font = arrayOfPGFont[0];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected WCFont createFont(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 54 */     FontFactory fontFactory = GraphicsPipeline.getPipeline().getFontFactory();
/* 55 */     return new WCFontImpl(fontFactory.deriveFont(this.font, paramBoolean1, paramBoolean2, paramInt));
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCFontCustomPlatformDataImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */