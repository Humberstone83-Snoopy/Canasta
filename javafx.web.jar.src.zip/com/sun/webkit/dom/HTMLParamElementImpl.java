/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLParamElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLParamElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLParamElement
/*    */ {
/*    */   HTMLParamElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLParamElement getImpl(long paramLong) {
/* 36 */     return (HTMLParamElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   public String getName() {
/* 42 */     return getNameImpl(getPeer());
/*    */   }
/*    */   static native void setNameImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setName(String paramString) {
/* 47 */     setNameImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getType() {
/* 52 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public void setType(String paramString) {
/* 57 */     setTypeImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setTypeImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getValue() {
/* 62 */     return getValueImpl(getPeer());
/*    */   }
/*    */   static native String getValueImpl(long paramLong);
/*    */   
/*    */   public void setValue(String paramString) {
/* 67 */     setValueImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setValueImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getValueType() {
/* 72 */     return getValueTypeImpl(getPeer());
/*    */   }
/*    */   static native String getValueTypeImpl(long paramLong);
/*    */   
/*    */   public void setValueType(String paramString) {
/* 77 */     setValueTypeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setValueTypeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLParamElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */