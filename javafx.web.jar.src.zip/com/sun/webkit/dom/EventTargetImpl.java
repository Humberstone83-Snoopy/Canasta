/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.events.Event;
/*     */ import org.w3c.dom.events.EventListener;
/*     */ import org.w3c.dom.events.EventTarget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventTargetImpl
/*     */   implements EventTarget
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  39 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  42 */       EventTargetImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   EventTargetImpl(long paramLong) {
/*  47 */     this.peer = paramLong;
/*  48 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static EventTarget create(long paramLong) {
/*  52 */     if (paramLong == 0L) return null; 
/*  53 */     return new EventTargetImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  59 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  63 */     return (paramObject instanceof EventTargetImpl && this.peer == ((EventTargetImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  67 */     long l = this.peer;
/*  68 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(EventTarget paramEventTarget) {
/*  72 */     return (paramEventTarget == null) ? 0L : ((EventTargetImpl)paramEventTarget).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static EventTarget getImpl(long paramLong) {
/*  78 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/*  87 */     addEventListenerImpl(getPeer(), paramString, 
/*     */         
/*  89 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/* 102 */     removeEventListenerImpl(getPeer(), paramString, 
/*     */         
/* 104 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean dispatchEvent(Event paramEvent) throws DOMException {
/* 115 */     return dispatchEventImpl(getPeer(), 
/* 116 */         EventImpl.getPeer(paramEvent));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native void addEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   static native void removeEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   static native boolean dispatchEventImpl(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\EventTargetImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */