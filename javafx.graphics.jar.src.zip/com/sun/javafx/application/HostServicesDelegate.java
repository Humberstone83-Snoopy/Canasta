/*     */ package com.sun.javafx.application;
/*     */ 
/*     */ import java.awt.Desktop;
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import javafx.application.Application;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HostServicesDelegate
/*     */ {
/*     */   public static HostServicesDelegate getInstance(Application paramApplication) {
/*  36 */     return StandaloneHostService.getInstance(paramApplication);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract String getCodeBase();
/*     */ 
/*     */   
/*     */   public abstract String getDocumentBase();
/*     */ 
/*     */   
/*     */   public abstract void showDocument(String paramString);
/*     */   
/*     */   private static class StandaloneHostService
/*     */     extends HostServicesDelegate
/*     */   {
/*  51 */     private static HostServicesDelegate instance = null;
/*     */     
/*  53 */     private Class appClass = null;
/*     */     
/*     */     public static HostServicesDelegate getInstance(Application param1Application) {
/*  56 */       synchronized (StandaloneHostService.class) {
/*  57 */         if (instance == null) {
/*  58 */           instance = new StandaloneHostService(param1Application);
/*     */         }
/*  60 */         return instance;
/*     */       } 
/*     */     }
/*     */     
/*     */     private StandaloneHostService(Application param1Application) {
/*  65 */       this.appClass = param1Application.getClass();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getCodeBase() {
/*  74 */       String str1 = this.appClass.getName();
/*  75 */       int i = str1.lastIndexOf(".");
/*  76 */       if (i >= 0)
/*     */       {
/*     */ 
/*     */         
/*  80 */         str1 = str1.substring(i + 1);
/*     */       }
/*  82 */       str1 = str1 + ".class";
/*     */       
/*  84 */       String str2 = this.appClass.getResource(str1).toString();
/*  85 */       if (!str2.startsWith("jar:file:") || str2
/*  86 */         .indexOf("!") == -1) {
/*  87 */         return "";
/*     */       }
/*     */       
/*  90 */       String str3 = str2.substring(4, str2
/*  91 */           .lastIndexOf("!"));
/*  92 */       File file = null;
/*     */       try {
/*  94 */         file = new File((new URI(str3)).getPath());
/*  95 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*  98 */       if (file != null) {
/*  99 */         String str = file.getParent();
/* 100 */         if (str != null) {
/* 101 */           return toURIString(str);
/*     */         }
/*     */       } 
/*     */       
/* 105 */       return "";
/*     */     }
/*     */     
/*     */     private String toURIString(String param1String) {
/*     */       try {
/* 110 */         return (new File(param1String)).toURI().toString();
/* 111 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 114 */         exception.printStackTrace();
/*     */         
/* 116 */         return "";
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDocumentBase() {
/* 122 */       return toURIString(System.getProperty("user.dir"));
/*     */     }
/*     */     
/* 125 */     static final String[] browsers = new String[] { "google-chrome", "firefox", "opera", "konqueror", "mozilla" };
/*     */ 
/*     */ 
/*     */     
/*     */     public void showDocument(String param1String) {
/* 130 */       String str = System.getProperty("os.name");
/*     */       try {
/* 132 */         if (str.startsWith("Mac OS")) {
/* 133 */           Desktop.getDesktop().browse(URI.create(param1String));
/* 134 */         } else if (str.startsWith("Windows")) {
/* 135 */           Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + param1String);
/*     */         } else {
/*     */           
/* 138 */           String str1 = null;
/* 139 */           for (String str2 : browsers) {
/* 140 */             if (str1 == null && Runtime.getRuntime().exec(new String[] { "which", str2
/* 141 */                 }).getInputStream().read() != -1) {
/* 142 */               Runtime.getRuntime().exec(new String[] { str1 = str2, param1String });
/*     */             }
/*     */           } 
/* 145 */           if (str1 == null) {
/* 146 */             throw new Exception("No web browser found");
/*     */           }
/*     */         } 
/* 149 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 152 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\application\HostServicesDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */