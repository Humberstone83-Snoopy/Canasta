/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BackgroundPosition;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LayeredBackgroundPositionConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue[], BackgroundPosition>[], BackgroundPosition[]>
/*    */ {
/* 42 */   private static final LayeredBackgroundPositionConverter LAYERED_BACKGROUND_POSITION_CONVERTER = new LayeredBackgroundPositionConverter();
/*    */ 
/*    */   
/*    */   public static LayeredBackgroundPositionConverter getInstance() {
/* 46 */     return LAYERED_BACKGROUND_POSITION_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BackgroundPosition[] convert(ParsedValue<ParsedValue<ParsedValue[], BackgroundPosition>[], BackgroundPosition[]> paramParsedValue, Font paramFont) {
/* 55 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 56 */     BackgroundPosition[] arrayOfBackgroundPosition = new BackgroundPosition[arrayOfParsedValue.length];
/* 57 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 58 */       arrayOfBackgroundPosition[b] = arrayOfParsedValue[b].convert(paramFont);
/*    */     }
/* 60 */     return arrayOfBackgroundPosition;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "LayeredBackgroundPositionConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\LayeredBackgroundPositionConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */