/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteGrayAlpha
/*     */ {
/*  37 */   public static final BytePixelGetter getter = Accessor.nonpremul;
/*  38 */   public static final BytePixelSetter setter = Accessor.nonpremul;
/*  39 */   public static final BytePixelAccessor accessor = Accessor.nonpremul;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteGrayAlphaPreConverter() {
/*  42 */     return ToByteGrayAlphaPreConv.instance;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  46 */     return ToByteBgraSameConv.nonpremul;
/*     */   }
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  50 */     static final BytePixelAccessor nonpremul = new Accessor(false);
/*  51 */     static final BytePixelAccessor premul = new Accessor(true);
/*     */     private boolean isPremult;
/*     */     
/*     */     private Accessor(boolean param1Boolean) {
/*  55 */       this.isPremult = param1Boolean;
/*     */     }
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  60 */       return this.isPremult ? AlphaType.PREMULTIPLIED : AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  65 */       return 2;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  70 */       int i = param1ArrayOfbyte[param1Int] & 0xFF;
/*  71 */       int j = param1ArrayOfbyte[param1Int + 1] & 0xFF;
/*  72 */       if (this.isPremult) i = PixelUtils.PreToNonPre(i, j); 
/*  73 */       return j << 24 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  78 */       int i = param1ArrayOfbyte[param1Int] & 0xFF;
/*  79 */       int j = param1ArrayOfbyte[param1Int + 1] & 0xFF;
/*  80 */       if (!this.isPremult) i = PixelUtils.NonPretoPre(i, j); 
/*  81 */       return j << 24 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  86 */       int i = param1ByteBuffer.get(param1Int) & 0xFF;
/*  87 */       int j = param1ByteBuffer.get(param1Int + 1) & 0xFF;
/*  88 */       if (this.isPremult) i = PixelUtils.PreToNonPre(i, j); 
/*  89 */       return j << 24 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/*  94 */       int i = param1ByteBuffer.get(param1Int) & 0xFF;
/*  95 */       int j = param1ByteBuffer.get(param1Int + 1) & 0xFF;
/*  96 */       if (!this.isPremult) i = PixelUtils.NonPretoPre(i, j); 
/*  97 */       return j << 24 | i << 16 | i << 8 | i;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 102 */       int i = PixelUtils.RgbToGray(param1Int2);
/* 103 */       int j = param1Int2 >>> 24;
/* 104 */       if (this.isPremult) i = PixelUtils.NonPretoPre(i, j); 
/* 105 */       param1ArrayOfbyte[param1Int1] = (byte)i;
/* 106 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)j;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 111 */       int i = PixelUtils.RgbToGray(param1Int2);
/* 112 */       int j = param1Int2 >>> 24;
/* 113 */       if (!this.isPremult) i = PixelUtils.PreToNonPre(i, j); 
/* 114 */       param1ArrayOfbyte[param1Int1] = (byte)i;
/* 115 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)j;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 120 */       int i = PixelUtils.RgbToGray(param1Int2);
/* 121 */       int j = param1Int2 >>> 24;
/* 122 */       if (this.isPremult) i = PixelUtils.NonPretoPre(i, j); 
/* 123 */       param1ByteBuffer.put(param1Int1, (byte)i);
/* 124 */       param1ByteBuffer.put(param1Int1 + 1, (byte)j);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 129 */       int i = PixelUtils.RgbToGray(param1Int2);
/* 130 */       int j = param1Int2 >>> 24;
/* 131 */       if (!this.isPremult) i = PixelUtils.PreToNonPre(i, j); 
/* 132 */       param1ByteBuffer.put(param1Int1, (byte)i);
/* 133 */       param1ByteBuffer.put(param1Int1 + 1, (byte)j);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteGrayAlphaPreConv extends BaseByteToByteConverter {
/* 138 */     static final ByteToBytePixelConverter instance = new ToByteGrayAlphaPreConv();
/*     */ 
/*     */     
/*     */     private ToByteGrayAlphaPreConv() {
/* 142 */       super(ByteGrayAlpha.getter, ByteGrayAlphaPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 150 */       param1Int2 -= param1Int5 * 2;
/* 151 */       param1Int4 -= param1Int5 * 2;
/* 152 */       while (--param1Int6 >= 0) {
/* 153 */         for (byte b = 0; b < param1Int5; b++) {
/* 154 */           int i = param1ArrayOfbyte1[param1Int1++] & 0xFF;
/* 155 */           byte b1 = param1ArrayOfbyte1[param1Int1++];
/* 156 */           if (b1 != -1) {
/* 157 */             if (b1 == 0) {
/* 158 */               i = 0;
/*     */             } else {
/* 160 */               i = (i * (b1 & 0xFF) + 127) / 255;
/*     */             } 
/*     */           }
/* 163 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/* 164 */           param1ArrayOfbyte2[param1Int3++] = (byte)b1;
/*     */         } 
/* 166 */         param1Int1 += param1Int2;
/* 167 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 176 */       param1Int2 -= param1Int5 * 2;
/* 177 */       param1Int4 -= param1Int5 * 2;
/* 178 */       while (--param1Int6 >= 0) {
/* 179 */         for (byte b = 0; b < param1Int5; b++) {
/* 180 */           int i = param1ByteBuffer1.get(param1Int1++) & 0xFF;
/* 181 */           byte b1 = param1ByteBuffer1.get(param1Int1++);
/* 182 */           if (b1 != -1) {
/* 183 */             if (b1 == 0) {
/* 184 */               i = 0;
/*     */             } else {
/* 186 */               i = (i * (b1 & 0xFF) + 127) / 255;
/*     */             } 
/*     */           }
/* 189 */           param1ByteBuffer2.put(param1Int3++, (byte)i);
/* 190 */           param1ByteBuffer2.put(param1Int3++, (byte)b1);
/*     */         } 
/* 192 */         param1Int1 += param1Int2;
/* 193 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgraSameConv extends BaseByteToByteConverter {
/* 199 */     static final ByteToBytePixelConverter nonpremul = new ToByteBgraSameConv(false);
/*     */     
/* 201 */     static final ByteToBytePixelConverter premul = new ToByteBgraSameConv(true);
/*     */ 
/*     */     
/*     */     private ToByteBgraSameConv(boolean param1Boolean) {
/* 205 */       super(param1Boolean ? ByteGrayAlphaPre.getter : ByteGrayAlpha.getter, 
/* 206 */           param1Boolean ? ByteBgraPre.setter : ByteBgra.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 214 */       param1Int2 -= param1Int5 * 2;
/* 215 */       param1Int4 -= param1Int5 * 4;
/* 216 */       while (--param1Int6 >= 0) {
/* 217 */         for (byte b = 0; b < param1Int5; b++) {
/* 218 */           byte b1 = param1ArrayOfbyte1[param1Int1++];
/* 219 */           byte b2 = param1ArrayOfbyte1[param1Int1++];
/* 220 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 221 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 222 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 223 */           param1ArrayOfbyte2[param1Int3++] = b2;
/*     */         } 
/* 225 */         param1Int1 += param1Int2;
/* 226 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 235 */       param1Int2 -= param1Int5 * 2;
/* 236 */       param1Int4 -= param1Int5 * 4;
/* 237 */       while (--param1Int6 >= 0) {
/* 238 */         for (byte b = 0; b < param1Int5; b++) {
/* 239 */           byte b1 = param1ByteBuffer1.get(param1Int1++);
/* 240 */           byte b2 = param1ByteBuffer1.get(param1Int1++);
/* 241 */           param1ByteBuffer2.put(param1Int3++, b1);
/* 242 */           param1ByteBuffer2.put(param1Int3++, b1);
/* 243 */           param1ByteBuffer2.put(param1Int3++, b1);
/* 244 */           param1ByteBuffer2.put(param1Int3++, b2);
/*     */         } 
/* 246 */         param1Int1 += param1Int2;
/* 247 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteGrayAlpha.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */