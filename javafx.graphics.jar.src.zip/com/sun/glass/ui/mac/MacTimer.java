/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.Timer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacTimer
/*    */   extends Timer
/*    */ {
/* 38 */   private static final int minPeriod = _getMinPeriod();
/* 39 */   private static final int maxPeriod = _getMaxPeriod(); static {
/* 40 */     _initIDs();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected MacTimer(Runnable paramRunnable) {
/* 46 */     super(paramRunnable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static int getMinPeriod_impl() {
/* 53 */     return minPeriod;
/*    */   }
/*    */   
/*    */   static int getMaxPeriod_impl() {
/* 57 */     return maxPeriod;
/*    */   }
/*    */   
/*    */   private static native int _getMinPeriod();
/*    */   
/*    */   private static native int _getMaxPeriod();
/*    */   
/*    */   protected native long _start(Runnable paramRunnable);
/*    */   
/*    */   protected native long _start(Runnable paramRunnable, int paramInt);
/*    */   
/*    */   protected native void _stop(long paramLong);
/*    */   
/*    */   private static native void _initIDs();
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacTimer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */