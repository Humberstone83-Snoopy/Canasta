/*     */ package com.sun.javafx.scene.paint;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.Stop;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GradientUtils
/*     */ {
/*     */   public static String lengthToString(double paramDouble, boolean paramBoolean) {
/*  36 */     if (paramBoolean) {
/*  37 */       return "" + paramDouble * 100.0D + "%";
/*     */     }
/*  39 */     return "" + paramDouble + "px";
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Point
/*     */   {
/*  45 */     public static final Point MIN = new Point(0.0D, true);
/*  46 */     public static final Point MAX = new Point(1.0D, true);
/*     */     
/*     */     public double value;
/*     */     public boolean proportional;
/*     */     
/*     */     public String toString() {
/*  52 */       return "value = " + this.value + ", proportional = " + this.proportional;
/*     */     }
/*     */     
/*     */     public Point(double param1Double, boolean param1Boolean) {
/*  56 */       this.value = param1Double;
/*  57 */       this.proportional = param1Boolean;
/*     */     }
/*     */ 
/*     */     
/*     */     public Point() {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Parser
/*     */   {
/*     */     private int index;
/*     */     
/*     */     private String[] tokens;
/*     */     
/*     */     private boolean proportional;
/*     */     
/*     */     private boolean proportionalSet = false;
/*     */     
/*     */     private String[] splitString(String param1String, Delimiter param1Delimiter, boolean param1Boolean) {
/*  76 */       LinkedList<String> linkedList = new LinkedList();
/*  77 */       StringBuilder stringBuilder = new StringBuilder();
/*  78 */       byte b = 0;
/*  79 */       char[] arrayOfChar = param1String.toCharArray();
/*  80 */       while (b < arrayOfChar.length) {
/*  81 */         char c = arrayOfChar[b];
/*     */         
/*  83 */         if (param1Delimiter.isDelimiter(c)) {
/*  84 */           if (!param1Boolean || stringBuilder.length() > 0) {
/*  85 */             linkedList.add(stringBuilder.toString());
/*     */           }
/*  87 */           stringBuilder.setLength(0);
/*  88 */         } else if (c == '(') {
/*  89 */           while (b < arrayOfChar.length) {
/*  90 */             stringBuilder.append(arrayOfChar[b]);
/*  91 */             if (arrayOfChar[b] == ')') {
/*     */               break;
/*     */             }
/*  94 */             b++;
/*     */           } 
/*     */         } else {
/*  97 */           stringBuilder.append(arrayOfChar[b]);
/*     */         } 
/*  99 */         b++;
/*     */       } 
/* 101 */       if (!param1Boolean || stringBuilder.length() > 0) {
/* 102 */         linkedList.add(stringBuilder.toString());
/*     */       }
/*     */       
/* 105 */       return linkedList.<String>toArray(new String[linkedList.size()]);
/*     */     }
/*     */     
/*     */     public Parser(String param1String) {
/* 109 */       this.tokens = splitString(param1String, param1Char -> (param1Char == ','), false);
/*     */       
/* 111 */       this.index = 0;
/*     */     }
/*     */     
/*     */     public int getSize() {
/* 115 */       return this.tokens.length;
/*     */     }
/*     */     
/*     */     public void shift() {
/* 119 */       this.index++;
/*     */     }
/*     */     
/*     */     public String getCurrentToken() {
/* 123 */       String str = this.tokens[this.index].trim();
/* 124 */       if (str.isEmpty()) {
/* 125 */         throw new IllegalArgumentException("Invalid gradient specification: found empty token.");
/*     */       }
/*     */       
/* 128 */       return str;
/*     */     }
/*     */     
/*     */     public String[] splitCurrentToken() {
/* 132 */       return getCurrentToken().split("\\s");
/*     */     }
/*     */     
/*     */     public static void checkNumberOfArguments(String[] param1ArrayOfString, int param1Int) {
/* 136 */       if (param1ArrayOfString.length < param1Int + 1) {
/* 137 */         throw new IllegalArgumentException("Invalid gradient specification: parameter '" + param1ArrayOfString[0] + "' needs " + param1Int + " argument(s).");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public static double parseAngle(String param1String) {
/* 143 */       double d = 0.0D;
/* 144 */       if (param1String.endsWith("deg")) {
/* 145 */         param1String = param1String.substring(0, param1String.length() - 3);
/* 146 */         d = Double.parseDouble(param1String);
/* 147 */       } else if (param1String.endsWith("grad")) {
/* 148 */         param1String = param1String.substring(0, param1String.length() - 4);
/* 149 */         d = Double.parseDouble(param1String);
/* 150 */         d = d * 9.0D / 10.0D;
/* 151 */       } else if (param1String.endsWith("rad")) {
/* 152 */         param1String = param1String.substring(0, param1String.length() - 3);
/* 153 */         d = Double.parseDouble(param1String);
/* 154 */         d = d * 180.0D / Math.PI;
/* 155 */       } else if (param1String.endsWith("turn")) {
/* 156 */         param1String = param1String.substring(0, param1String.length() - 4);
/* 157 */         d = Double.parseDouble(param1String);
/* 158 */         d *= 360.0D;
/*     */       } else {
/* 160 */         throw new IllegalArgumentException("Invalid gradient specification:angle must end in deg, rad, grad, or turn");
/*     */       } 
/*     */ 
/*     */       
/* 164 */       return d;
/*     */     }
/*     */     
/*     */     public static double parsePercentage(String param1String) {
/*     */       double d;
/* 169 */       if (param1String.endsWith("%")) {
/* 170 */         param1String = param1String.substring(0, param1String.length() - 1);
/* 171 */         d = Double.parseDouble(param1String) / 100.0D;
/*     */       } else {
/* 173 */         throw new IllegalArgumentException("Invalid gradient specification: focus-distance must be specified as percentage");
/*     */       } 
/*     */       
/* 176 */       return d;
/*     */     }
/*     */     
/*     */     public GradientUtils.Point parsePoint(String param1String) {
/* 180 */       GradientUtils.Point point = new GradientUtils.Point();
/* 181 */       if (param1String.endsWith("%")) {
/* 182 */         point.proportional = true;
/* 183 */         param1String = param1String.substring(0, param1String.length() - 1);
/* 184 */       } else if (param1String.endsWith("px")) {
/* 185 */         param1String = param1String.substring(0, param1String.length() - 2);
/*     */       } 
/* 187 */       point.value = Double.parseDouble(param1String);
/* 188 */       if (point.proportional) {
/* 189 */         point.value /= 100.0D;
/*     */       }
/*     */       
/* 192 */       if (this.proportionalSet && this.proportional != point.proportional) {
/* 193 */         throw new IllegalArgumentException("Invalid gradient specification:cannot mix proportional and non-proportional values");
/*     */       }
/*     */ 
/*     */       
/* 197 */       this.proportionalSet = true;
/* 198 */       this.proportional = point.proportional;
/*     */       
/* 200 */       return point;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Stop[] parseStops(boolean param1Boolean, double param1Double) {
/* 206 */       int i = this.tokens.length - this.index;
/* 207 */       Color[] arrayOfColor = new Color[i];
/* 208 */       double[] arrayOfDouble = new double[i];
/* 209 */       Stop[] arrayOfStop = new Stop[i];
/*     */       
/* 211 */       for (byte b1 = 0; b1 < i; b1++) {
/* 212 */         String str1 = this.tokens[b1 + this.index].trim();
/* 213 */         String[] arrayOfString = splitString(str1, param1Char -> Character.isWhitespace(param1Char), true);
/*     */         
/* 215 */         if (arrayOfString.length == 0) {
/* 216 */           throw new IllegalArgumentException("Invalid gradient specification, empty stop found");
/*     */         }
/*     */ 
/*     */         
/* 220 */         String str2 = arrayOfString[0];
/* 221 */         double d1 = -1.0D;
/*     */         
/* 223 */         Color color = Color.web(str2);
/* 224 */         if (arrayOfString.length == 2) {
/*     */           
/* 226 */           String str = arrayOfString[1];
/* 227 */           if (str.endsWith("%")) {
/* 228 */             str = str.substring(0, str.length() - 1);
/* 229 */             d1 = Double.parseDouble(str) / 100.0D;
/* 230 */           } else if (!param1Boolean) {
/* 231 */             if (str.endsWith("px")) {
/* 232 */               str = str.substring(0, str.length() - 2);
/*     */             }
/* 234 */             d1 = Double.parseDouble(str) / param1Double;
/*     */           } else {
/* 236 */             throw new IllegalArgumentException("Invalid gradient specification, non-proportional stops not permited in proportional gradient: " + str);
/*     */           }
/*     */         
/* 239 */         } else if (arrayOfString.length > 2) {
/* 240 */           throw new IllegalArgumentException("Invalid gradient specification, unexpected content in stop specification: " + arrayOfString[2]);
/*     */         } 
/*     */ 
/*     */         
/* 244 */         arrayOfColor[b1] = color;
/* 245 */         arrayOfDouble[b1] = d1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 251 */       if (arrayOfDouble[0] < 0.0D) {
/* 252 */         arrayOfDouble[0] = 0.0D;
/*     */       }
/* 254 */       if (arrayOfDouble[arrayOfDouble.length - 1] < 0.0D) {
/* 255 */         arrayOfDouble[arrayOfDouble.length - 1] = 1.0D;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 261 */       double d = arrayOfDouble[0]; byte b;
/* 262 */       for (b = 1; b < arrayOfDouble.length; b++) {
/* 263 */         if (arrayOfDouble[b] < d && arrayOfDouble[b] > 0.0D) {
/* 264 */           arrayOfDouble[b] = d;
/*     */         } else {
/* 266 */           d = arrayOfDouble[b];
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       b = -1; byte b2;
/* 275 */       for (b2 = 1; b2 < arrayOfDouble.length; b2++) {
/* 276 */         double d1 = arrayOfDouble[b2];
/* 277 */         if (d1 < 0.0D && b < 0) {
/* 278 */           b = b2;
/* 279 */         } else if (d1 >= 0.0D && b > 0) {
/* 280 */           int j = b2 - b + 1;
/* 281 */           double d2 = (arrayOfDouble[b2] - arrayOfDouble[b - 1]) / j;
/* 282 */           for (byte b3 = 0; b3 < j - 1; b3++) {
/* 283 */             arrayOfDouble[b + b3] = arrayOfDouble[b - 1] + d2 * (b3 + 1);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 288 */       for (b2 = 0; b2 < arrayOfStop.length; b2++) {
/* 289 */         Stop stop = new Stop(arrayOfDouble[b2], arrayOfColor[b2]);
/* 290 */         arrayOfStop[b2] = stop;
/*     */       } 
/*     */       
/* 293 */       return arrayOfStop;
/*     */     }
/*     */     
/*     */     private static interface Delimiter {
/*     */       boolean isDelimiter(char param2Char);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\paint\GradientUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */