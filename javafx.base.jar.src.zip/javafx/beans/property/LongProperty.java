/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.BidirectionalBinding;
/*     */ import com.sun.javafx.binding.Logging;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ import javafx.beans.value.WritableLongValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LongProperty
/*     */   extends ReadOnlyLongProperty
/*     */   implements Property<Number>, WritableLongValue
/*     */ {
/*     */   public void setValue(Number paramNumber) {
/*  68 */     if (paramNumber == null) {
/*  69 */       Logging.getLogger().fine("Attempt to set long property to null, using default value instead.", new NullPointerException());
/*  70 */       set(0L);
/*     */     } else {
/*  72 */       set(paramNumber.longValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<Number> paramProperty) {
/*  81 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<Number> paramProperty) {
/*  89 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     Object object = getBean();
/*  99 */     String str = getName();
/* 100 */     StringBuilder stringBuilder = new StringBuilder("LongProperty [");
/* 101 */     if (object != null) {
/* 102 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 104 */     if (str != null && !str.equals("")) {
/* 105 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 107 */     stringBuilder.append("value: ").append(get()).append("]");
/* 108 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LongProperty longProperty(final Property<Long> property) {
/* 148 */     if (property == null) {
/* 149 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/* 151 */     return new LongPropertyBase()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 159 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 164 */           return property.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 170 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(param1Property, this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 175 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectProperty<Long> asObject() {
/* 202 */     return new ObjectPropertyBase<Long>()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 210 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 215 */           return LongProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 221 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(this, LongProperty.this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 226 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\LongProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */