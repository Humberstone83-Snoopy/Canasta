/*     */ package com.sun.javafx.iio.png;
/*     */ 
/*     */ import com.sun.javafx.iio.common.ImageTools;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PNGIDATChunkInputStream
/*     */   extends InputStream
/*     */ {
/*     */   static final int IDAT_TYPE = 1229209940;
/*     */   private DataInputStream source;
/*  52 */   private int numBytesAvailable = 0;
/*     */   private boolean foundAllIDATChunks = false;
/*  54 */   private int nextChunkLength = 0;
/*  55 */   private int nextChunkType = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PNGIDATChunkInputStream(DataInputStream paramDataInputStream, int paramInt) throws IOException {
/*  66 */     if (paramInt < 0) {
/*  67 */       throw new IOException("Invalid chunk length");
/*     */     }
/*  69 */     this.source = paramDataInputStream;
/*  70 */     this.numBytesAvailable = paramInt;
/*     */   }
/*     */   
/*     */   private void nextChunk() throws IOException {
/*  74 */     if (!this.foundAllIDATChunks) {
/*  75 */       ImageTools.skipFully(this.source, 4L);
/*  76 */       int i = this.source.readInt();
/*  77 */       if (i < 0) {
/*  78 */         throw new IOException("Invalid chunk length");
/*     */       }
/*  80 */       int j = this.source.readInt();
/*  81 */       if (j == 1229209940) {
/*  82 */         this.numBytesAvailable += i;
/*     */       } else {
/*  84 */         this.foundAllIDATChunks = true;
/*  85 */         this.nextChunkLength = i;
/*  86 */         this.nextChunkType = j;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isFoundAllIDATChunks() {
/*  92 */     return this.foundAllIDATChunks;
/*     */   }
/*     */   
/*     */   int getNextChunkLength() {
/*  96 */     return this.nextChunkLength;
/*     */   }
/*     */   
/*     */   int getNextChunkType() {
/* 100 */     return this.nextChunkType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 105 */     if (this.numBytesAvailable == 0) {
/* 106 */       nextChunk();
/*     */     }
/*     */     
/* 109 */     if (this.numBytesAvailable == 0) {
/* 110 */       return -1;
/*     */     }
/* 112 */     this.numBytesAvailable--;
/* 113 */     return this.source.read();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 119 */     if (this.numBytesAvailable == 0) {
/* 120 */       nextChunk();
/* 121 */       if (this.numBytesAvailable == 0) {
/* 122 */         return -1;
/*     */       }
/*     */     } 
/*     */     
/* 126 */     int i = 0;
/* 127 */     while (this.numBytesAvailable > 0 && paramInt2 > 0) {
/* 128 */       int j = (paramInt2 < this.numBytesAvailable) ? paramInt2 : this.numBytesAvailable;
/*     */       
/* 130 */       int k = this.source.read(paramArrayOfbyte, paramInt1, j);
/* 131 */       if (k == -1) {
/* 132 */         throw new EOFException();
/*     */       }
/*     */       
/* 135 */       this.numBytesAvailable -= k;
/* 136 */       paramInt1 += k;
/* 137 */       paramInt2 -= k;
/* 138 */       i += k;
/* 139 */       if (this.numBytesAvailable == 0 && paramInt2 > 0) {
/* 140 */         nextChunk();
/*     */       }
/*     */     } 
/*     */     
/* 144 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\png\PNGIDATChunkInputStream.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */