/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteRgb
/*     */ {
/*  38 */   public static final BytePixelGetter getter = Getter.instance;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  41 */     return ToByteBgrfConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/*  45 */     return ToByteBgrfConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbConverter() {
/*  49 */     return ToIntFrgbConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbPreConverter() {
/*  53 */     return ToIntFrgbConv.premult;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteArgbConverter() {
/*  57 */     return ToByteFrgbConv.nonpremult;
/*     */   }
/*     */   
/*     */   public static final ByteToBytePixelConverter ToByteBgrConverter() {
/*  61 */     return SwapThreeByteConverter.rgbToBgrInstance;
/*     */   }
/*     */   
/*     */   static class Getter implements BytePixelGetter {
/*  65 */     static final BytePixelGetter instance = new Getter();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  70 */       return AlphaType.OPAQUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  75 */       return 3;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  80 */       return param1ArrayOfbyte[param1Int + 2] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int] & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  88 */       return param1ArrayOfbyte[param1Int + 2] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int] & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  96 */       return param1ByteBuffer.get(param1Int + 2) & 0xFF | (param1ByteBuffer
/*  97 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/*  98 */         .get(param1Int) & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 104 */       return param1ByteBuffer.get(param1Int + 2) & 0xFF | (param1ByteBuffer
/* 105 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/* 106 */         .get(param1Int) & 0xFF) << 16 | 0xFF000000;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgrfConv
/*     */     extends BaseByteToByteConverter {
/* 112 */     public static final ByteToBytePixelConverter nonpremult = new ToByteBgrfConv(ByteBgra.setter);
/*     */     
/* 114 */     public static final ByteToBytePixelConverter premult = new ToByteBgrfConv(ByteBgraPre.setter);
/*     */ 
/*     */     
/*     */     private ToByteBgrfConv(BytePixelSetter param1BytePixelSetter) {
/* 118 */       super(ByteRgb.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 126 */       param1Int2 -= param1Int5 * 3;
/* 127 */       param1Int4 -= param1Int5 * 4;
/* 128 */       while (--param1Int6 >= 0) {
/* 129 */         for (byte b = 0; b < param1Int5; b++) {
/* 130 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 2];
/* 131 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 1];
/* 132 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1];
/* 133 */           param1ArrayOfbyte2[param1Int3++] = -1;
/* 134 */           param1Int1 += 3;
/*     */         } 
/* 136 */         param1Int1 += param1Int2;
/* 137 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 146 */       param1Int2 -= param1Int5 * 3;
/* 147 */       param1Int4 -= param1Int5 * 4;
/* 148 */       while (--param1Int6 >= 0) {
/* 149 */         for (byte b = 0; b < param1Int5; b++) {
/* 150 */           param1ByteBuffer2.put(param1Int3, param1ByteBuffer1.get(param1Int1 + 2));
/* 151 */           param1ByteBuffer2.put(param1Int3 + 1, param1ByteBuffer1.get(param1Int1 + 1));
/* 152 */           param1ByteBuffer2.put(param1Int3 + 2, param1ByteBuffer1.get(param1Int1));
/* 153 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)-1);
/* 154 */           param1Int1 += 3;
/* 155 */           param1Int3 += 4;
/*     */         } 
/* 157 */         param1Int1 += param1Int2;
/* 158 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntFrgbConv extends BaseByteToIntConverter {
/* 164 */     public static final ByteToIntPixelConverter nonpremult = new ToIntFrgbConv(IntArgb.setter);
/*     */     
/* 166 */     public static final ByteToIntPixelConverter premult = new ToIntFrgbConv(IntArgbPre.setter);
/*     */ 
/*     */     
/*     */     private ToIntFrgbConv(IntPixelSetter param1IntPixelSetter) {
/* 170 */       super(ByteRgb.getter, param1IntPixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 178 */       param1Int2 -= param1Int5 * 3;
/* 179 */       while (--param1Int6 >= 0) {
/* 180 */         for (byte b = 0; b < param1Int5; b++) {
/* 181 */           int i = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 182 */           int j = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 183 */           int k = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 184 */           param1ArrayOfint[param1Int3 + b] = 0xFF000000 | i << 16 | j << 8 | k;
/*     */         } 
/* 186 */         param1Int1 += param1Int2;
/* 187 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 196 */       param1Int2 -= param1Int5 * 3;
/* 197 */       while (--param1Int6 >= 0) {
/* 198 */         for (byte b = 0; b < param1Int5; b++) {
/* 199 */           int i = param1ByteBuffer.get(param1Int1) & 0xFF;
/* 200 */           int j = param1ByteBuffer.get(param1Int1 + 1) & 0xFF;
/* 201 */           int k = param1ByteBuffer.get(param1Int1 + 2) & 0xFF;
/* 202 */           param1Int1 += 3;
/* 203 */           param1IntBuffer.put(param1Int3 + b, 0xFF000000 | i << 16 | j << 8 | k);
/*     */         } 
/* 205 */         param1Int1 += param1Int2;
/* 206 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteFrgbConv extends BaseByteToByteConverter {
/* 212 */     static final ByteToBytePixelConverter nonpremult = new ToByteFrgbConv(ByteArgb.setter);
/*     */ 
/*     */     
/*     */     private ToByteFrgbConv(BytePixelSetter param1BytePixelSetter) {
/* 216 */       super(ByteRgb.getter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 224 */       param1Int2 -= param1Int5 * 3;
/* 225 */       param1Int2 -= param1Int5 * 4;
/* 226 */       while (--param1Int6 >= 0) {
/* 227 */         for (byte b = 0; b < param1Int5; b++) {
/* 228 */           param1ArrayOfbyte2[param1Int3++] = -1;
/* 229 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/* 230 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/* 231 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1++];
/*     */         } 
/* 233 */         param1Int1 += param1Int2;
/* 234 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 243 */       param1Int2 -= param1Int5 * 3;
/* 244 */       param1Int2 -= param1Int5 * 4;
/* 245 */       while (--param1Int6 >= 0) {
/* 246 */         for (byte b = 0; b < param1Int5; b++) {
/* 247 */           param1ByteBuffer2.put(param1Int3++, (byte)-1);
/* 248 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/* 249 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/* 250 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1++));
/*     */         } 
/* 252 */         param1Int1 += param1Int2;
/* 253 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class SwapThreeByteConverter extends BaseByteToByteConverter {
/* 259 */     static final ByteToBytePixelConverter rgbToBgrInstance = new SwapThreeByteConverter(ByteRgb.getter, ByteBgr.accessor);
/*     */ 
/*     */     
/*     */     public SwapThreeByteConverter(BytePixelGetter param1BytePixelGetter, BytePixelSetter param1BytePixelSetter) {
/* 263 */       super(param1BytePixelGetter, param1BytePixelSetter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 271 */       param1Int2 -= param1Int5 * 3;
/* 272 */       param1Int2 -= param1Int5 * 4;
/* 273 */       while (--param1Int6 >= 0) {
/* 274 */         for (byte b = 0; b < param1Int5; b++) {
/* 275 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 2];
/* 276 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1 + 1];
/* 277 */           param1ArrayOfbyte2[param1Int3++] = param1ArrayOfbyte1[param1Int1];
/* 278 */           param1Int1 += 3;
/*     */         } 
/* 280 */         param1Int1 += param1Int2;
/* 281 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 290 */       param1Int2 -= param1Int5 * 3;
/* 291 */       param1Int2 -= param1Int5 * 4;
/* 292 */       while (--param1Int6 >= 0) {
/* 293 */         for (byte b = 0; b < param1Int5; b++) {
/* 294 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1 + 2));
/* 295 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1 + 1));
/* 296 */           param1ByteBuffer2.put(param1Int3++, param1ByteBuffer1.get(param1Int1));
/* 297 */           param1Int1 += 3;
/*     */         } 
/* 299 */         param1Int1 += param1Int2;
/* 300 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteRgb.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */