/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SliceSequenceConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue[], BorderImageSlices>[], BorderImageSlices[]>
/*    */ {
/* 36 */   private static final SliceSequenceConverter BORDER_IMAGE_SLICE_SEQUENCE_CONVERTER = new SliceSequenceConverter();
/*    */ 
/*    */   
/*    */   public static SliceSequenceConverter getInstance() {
/* 40 */     return BORDER_IMAGE_SLICE_SEQUENCE_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderImageSlices[] convert(ParsedValue<ParsedValue<ParsedValue[], BorderImageSlices>[], BorderImageSlices[]> paramParsedValue, Font paramFont) {
/* 61 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 62 */     BorderImageSlices[] arrayOfBorderImageSlices = new BorderImageSlices[arrayOfParsedValue.length];
/* 63 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 64 */       arrayOfBorderImageSlices[b] = BorderImageSliceConverter.getInstance().convert(arrayOfParsedValue[b], paramFont);
/*    */     }
/* 66 */     return arrayOfBorderImageSlices;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return "BorderImageSliceSequenceConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\SliceSequenceConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */