/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.xpath.XPathExpression;
/*    */ import org.w3c.dom.xpath.XPathResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XPathExpressionImpl
/*    */   implements XPathExpression
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 39 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 42 */       XPathExpressionImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   XPathExpressionImpl(long paramLong) {
/* 47 */     this.peer = paramLong;
/* 48 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static XPathExpression create(long paramLong) {
/* 52 */     if (paramLong == 0L) return null; 
/* 53 */     return new XPathExpressionImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 59 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 63 */     return (paramObject instanceof XPathExpressionImpl && this.peer == ((XPathExpressionImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 67 */     long l = this.peer;
/* 68 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(XPathExpression paramXPathExpression) {
/* 72 */     return (paramXPathExpression == null) ? 0L : ((XPathExpressionImpl)paramXPathExpression).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static XPathExpression getImpl(long paramLong) {
/* 78 */     return create(paramLong);
/*    */   }
/*    */   
/*    */   public Object evaluate(Node paramNode, short paramShort, Object paramObject) throws DOMException {
/* 82 */     return evaluate(paramNode, paramShort, (XPathResult)paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XPathResult evaluate(Node paramNode, short paramShort, XPathResult paramXPathResult) throws DOMException {
/* 90 */     return XPathResultImpl.getImpl(evaluateImpl(getPeer(), 
/* 91 */           NodeImpl.getPeer(paramNode), paramShort, 
/*    */           
/* 93 */           XPathResultImpl.getPeer(paramXPathResult)));
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native long evaluateImpl(long paramLong1, long paramLong2, short paramShort, long paramLong3);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\XPathExpressionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */