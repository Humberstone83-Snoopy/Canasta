/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontFile
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFontFile(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int Analyze(boolean[] paramArrayOfboolean, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3) {
/* 34 */     return OS.Analyze(this.ptr, paramArrayOfboolean, paramArrayOfint1, paramArrayOfint2, paramArrayOfint3);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteFontFile.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */