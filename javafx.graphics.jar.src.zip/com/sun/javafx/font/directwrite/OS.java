/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import java.security.AccessController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OS
/*     */ {
/*     */   static final int S_OK = 0;
/*     */   static final int E_NOT_SUFFICIENT_BUFFER = -2147024774;
/*     */   static final int D2D1_FACTORY_TYPE_SINGLE_THREADED = 0;
/*     */   static final int D2D1_RENDER_TARGET_TYPE_DEFAULT = 0;
/*     */   static final int D2D1_RENDER_TARGET_TYPE_SOFTWARE = 1;
/*     */   static final int D2D1_RENDER_TARGET_TYPE_HARDWARE = 2;
/*     */   static final int D2D1_RENDER_TARGET_USAGE_NONE = 0;
/*     */   static final int D2D1_RENDER_TARGET_USAGE_FORCE_BITMAP_REMOTING = 1;
/*     */   static final int D2D1_RENDER_TARGET_USAGE_GDI_COMPATIBLE = 2;
/*     */   static final int D2D1_FEATURE_LEVEL_DEFAULT = 0;
/*     */   static final int D2D1_ALPHA_MODE_UNKNOWN = 0;
/*     */   static final int D2D1_ALPHA_MODE_PREMULTIPLIED = 1;
/*     */   static final int D2D1_ALPHA_MODE_STRAIGHT = 2;
/*     */   
/*     */   static {
/*  36 */     AccessController.doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_font");
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   static final int D2D1_ALPHA_MODE_IGNORE = 3;
/*     */   
/*     */   static final int DXGI_FORMAT_UNKNOWN = 0;
/*     */   
/*     */   static final int DXGI_FORMAT_A8_UNORM = 65;
/*     */   
/*     */   static final int DXGI_FORMAT_B8G8R8A8_UNORM = 87;
/*     */   
/*     */   static final int D2D1_TEXT_ANTIALIAS_MODE_DEFAULT = 0;
/*     */   
/*     */   static final int D2D1_TEXT_ANTIALIAS_MODE_CLEARTYPE = 1;
/*     */   
/*     */   static final int D2D1_TEXT_ANTIALIAS_MODE_GRAYSCALE = 2;
/*     */   
/*     */   static final int D2D1_TEXT_ANTIALIAS_MODE_ALIASED = 3;
/*     */   
/*     */   static final int GUID_WICPixelFormat8bppGray = 1;
/*     */   
/*     */   static final int GUID_WICPixelFormat8bppAlpha = 2;
/*     */   
/*     */   static final int GUID_WICPixelFormat16bppGray = 3;
/*     */   
/*     */   static final int GUID_WICPixelFormat24bppRGB = 4;
/*     */   
/*     */   static final int GUID_WICPixelFormat24bppBGR = 5;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppBGR = 6;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppBGRA = 7;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppPBGRA = 8;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppGrayFloat = 9;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppRGBA = 10;
/*     */   
/*     */   static final int GUID_WICPixelFormat32bppPRGBA = 11;
/*     */   
/*     */   static final int WICBitmapNoCache = 0;
/*     */   
/*     */   static final int WICBitmapCacheOnDemand = 1;
/*     */   
/*     */   static final int WICBitmapCacheOnLoad = 2;
/*     */   static final int WICBitmapLockRead = 1;
/*     */   static final int WICBitmapLockWrite = 2;
/*     */   static final int DWRITE_FONT_WEIGHT_THIN = 100;
/*     */   static final int DWRITE_FONT_WEIGHT_EXTRA_LIGHT = 200;
/*     */   static final int DWRITE_FONT_WEIGHT_ULTRA_LIGHT = 200;
/*     */   static final int DWRITE_FONT_WEIGHT_LIGHT = 300;
/*     */   static final int DWRITE_FONT_WEIGHT_SEMI_LIGHT = 350;
/*     */   static final int DWRITE_FONT_WEIGHT_NORMAL = 400;
/*     */   static final int DWRITE_FONT_WEIGHT_REGULAR = 400;
/*     */   static final int DWRITE_FONT_WEIGHT_MEDIUM = 500;
/*     */   static final int DWRITE_FONT_WEIGHT_DEMI_BOLD = 600;
/*     */   static final int DWRITE_FONT_WEIGHT_SEMI_BOLD = 600;
/*     */   static final int DWRITE_FONT_WEIGHT_BOLD = 700;
/*     */   static final int DWRITE_FONT_WEIGHT_EXTRA_BOLD = 800;
/*     */   static final int DWRITE_FONT_WEIGHT_ULTRA_BOLD = 800;
/*     */   static final int DWRITE_FONT_WEIGHT_BLACK = 900;
/*     */   static final int DWRITE_FONT_WEIGHT_HEAVY = 900;
/*     */   static final int DWRITE_FONT_WEIGHT_EXTRA_BLACK = 950;
/*     */   static final int DWRITE_FONT_WEIGHT_ULTRA_BLACK = 950;
/*     */   static final int DWRITE_FONT_STRETCH_UNDEFINED = 0;
/*     */   static final int DWRITE_FONT_STRETCH_ULTRA_CONDENSED = 1;
/*     */   static final int DWRITE_FONT_STRETCH_EXTRA_CONDENSED = 2;
/*     */   static final int DWRITE_FONT_STRETCH_CONDENSED = 3;
/*     */   static final int DWRITE_FONT_STRETCH_SEMI_CONDENSED = 4;
/*     */   static final int DWRITE_FONT_STRETCH_NORMAL = 5;
/*     */   static final int DWRITE_FONT_STRETCH_MEDIUM = 5;
/*     */   static final int DWRITE_FONT_STRETCH_SEMI_EXPANDED = 6;
/*     */   static final int DWRITE_FONT_STRETCH_EXPANDED = 7;
/*     */   static final int DWRITE_FONT_STRETCH_EXTRA_EXPANDED = 8;
/*     */   static final int DWRITE_FONT_STRETCH_ULTRA_EXPANDED = 9;
/*     */   static final int DWRITE_FONT_STYLE_NORMAL = 0;
/*     */   static final int DWRITE_FONT_STYLE_OBLIQUE = 1;
/*     */   static final int DWRITE_FONT_STYLE_ITALIC = 2;
/*     */   static final int DWRITE_TEXTURE_ALIASED_1x1 = 0;
/*     */   static final int DWRITE_TEXTURE_CLEARTYPE_3x1 = 1;
/*     */   static final int DWRITE_RENDERING_MODE_DEFAULT = 0;
/*     */   static final int DWRITE_RENDERING_MODE_ALIASED = 1;
/*     */   static final int DWRITE_RENDERING_MODE_GDI_CLASSIC = 2;
/*     */   static final int DWRITE_RENDERING_MODE_GDI_NATURAL = 3;
/*     */   static final int DWRITE_RENDERING_MODE_NATURAL = 4;
/*     */   static final int DWRITE_RENDERING_MODE_NATURAL_SYMMETRIC = 5;
/*     */   static final int DWRITE_RENDERING_MODE_OUTLINE = 6;
/*     */   static final int DWRITE_RENDERING_MODE_CLEARTYPE_GDI_CLASSIC = 2;
/*     */   static final int DWRITE_RENDERING_MODE_CLEARTYPE_GDI_NATURAL = 3;
/*     */   static final int DWRITE_RENDERING_MODE_CLEARTYPE_NATURAL = 4;
/*     */   static final int DWRITE_RENDERING_MODE_CLEARTYPE_NATURAL_SYMMETRIC = 5;
/*     */   static final int DWRITE_MEASURING_MODE_NATURAL = 0;
/*     */   static final int DWRITE_MEASURING_MODE_GDI_CLASSIC = 1;
/*     */   static final int DWRITE_MEASURING_MODE_GDI_NATURAL = 2;
/*     */   static final int DWRITE_FACTORY_TYPE_SHARED = 0;
/*     */   static final int DWRITE_READING_DIRECTION_LEFT_TO_RIGHT = 0;
/*     */   static final int DWRITE_READING_DIRECTION_RIGHT_TO_LEFT = 1;
/*     */   static final int DWRITE_FONT_SIMULATIONS_NONE = 0;
/*     */   static final int DWRITE_FONT_SIMULATIONS_BOLD = 1;
/*     */   static final int DWRITE_FONT_SIMULATIONS_OBLIQUE = 2;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_NONE = 0;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_COPYRIGHT_NOTICE = 1;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_VERSION_STRINGS = 2;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_TRADEMARK = 3;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_MANUFACTURER = 4;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_DESIGNER = 5;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_DESIGNER_URL = 6;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_DESCRIPTION = 7;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_FONT_VENDOR_URL = 8;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_LICENSE_DESCRIPTION = 9;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_LICENSE_INFO_URL = 10;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_WIN32_FAMILY_NAMES = 11;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_WIN32_SUBFAMILY_NAMES = 12;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_PREFERRED_FAMILY_NAMES = 13;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_PREFERRED_SUBFAMILY_NAMES = 14;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_SAMPLE_TEXT = 15;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_FULL_NAME = 16;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_POSTSCRIPT_NAME = 17;
/*     */   static final int DWRITE_INFORMATIONAL_STRING_POSTSCRIPT_CID_NAME = 18;
/*     */   
/*     */   static final IDWriteFactory DWriteCreateFactory(int paramInt) {
/* 162 */     long l = _DWriteCreateFactory(paramInt);
/* 163 */     return (l != 0L) ? new IDWriteFactory(l) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final ID2D1Factory D2D1CreateFactory(int paramInt) {
/* 168 */     long l = _D2D1CreateFactory(paramInt);
/* 169 */     return (l != 0L) ? new ID2D1Factory(l) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final IWICImagingFactory WICCreateImagingFactory() {
/* 174 */     long l = _WICCreateImagingFactory();
/* 175 */     return (l != 0L) ? new IWICImagingFactory(l) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final JFXTextAnalysisSink NewJFXTextAnalysisSink(char[] paramArrayOfchar, int paramInt1, int paramInt2, String paramString, int paramInt3) {
/* 190 */     long l = _NewJFXTextAnalysisSink(paramArrayOfchar, paramInt1, paramInt2, (paramString + "\000")
/*     */         
/* 192 */         .toCharArray(), paramInt3, 0L);
/*     */     
/* 194 */     return (l != 0L) ? new JFXTextAnalysisSink(l) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   static final JFXTextRenderer NewJFXTextRenderer() {
/* 199 */     long l = _NewJFXTextRenderer();
/* 200 */     return (l != 0L) ? new JFXTextRenderer(l) : null;
/*     */   }
/*     */   
/*     */   private static final native long _DWriteCreateFactory(int paramInt);
/*     */   
/*     */   private static final native long _D2D1CreateFactory(int paramInt);
/*     */   
/*     */   private static final native long _WICCreateImagingFactory();
/*     */   
/*     */   private static final native long _NewJFXTextAnalysisSink(char[] paramArrayOfchar1, int paramInt1, int paramInt2, char[] paramArrayOfchar2, int paramInt3, long paramLong);
/*     */   
/*     */   private static final native long _NewJFXTextRenderer();
/*     */   
/*     */   static final native boolean Next(long paramLong);
/*     */   
/*     */   static final native int GetStart(long paramLong);
/*     */   
/*     */   static final native int GetLength(long paramLong);
/*     */   
/*     */   static final native DWRITE_SCRIPT_ANALYSIS GetAnalysis(long paramLong);
/*     */   
/*     */   static final native boolean JFXTextRendererNext(long paramLong);
/*     */   
/*     */   static final native int JFXTextRendererGetStart(long paramLong);
/*     */   
/*     */   static final native int JFXTextRendererGetLength(long paramLong);
/*     */   
/*     */   static final native int JFXTextRendererGetGlyphCount(long paramLong);
/*     */   
/*     */   static final native int JFXTextRendererGetTotalGlyphCount(long paramLong);
/*     */   
/*     */   static final native long JFXTextRendererGetFontFace(long paramLong);
/*     */   
/*     */   static final native int JFXTextRendererGetGlyphIndices(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2);
/*     */   
/*     */   static final native int JFXTextRendererGetGlyphAdvances(long paramLong, float[] paramArrayOffloat, int paramInt);
/*     */   
/*     */   static final native int JFXTextRendererGetGlyphOffsets(long paramLong, float[] paramArrayOffloat, int paramInt);
/*     */   
/*     */   static final native int JFXTextRendererGetClusterMap(long paramLong, short[] paramArrayOfshort, int paramInt1, int paramInt2);
/*     */   
/*     */   static final native DWRITE_GLYPH_METRICS GetDesignGlyphMetrics(long paramLong, short paramShort, boolean paramBoolean);
/*     */   
/*     */   static final native Path2D GetGlyphRunOutline(long paramLong, float paramFloat, short paramShort, boolean paramBoolean);
/*     */   
/*     */   static final native long CreateFontFace(long paramLong);
/*     */   
/*     */   static final native long GetFaceNames(long paramLong);
/*     */   
/*     */   static final native long GetFontFamily(long paramLong);
/*     */   
/*     */   static final native int GetStretch(long paramLong);
/*     */   
/*     */   static final native int GetStyle(long paramLong);
/*     */   
/*     */   static final native int GetWeight(long paramLong);
/*     */   
/*     */   static final native long GetInformationalStrings(long paramLong, int paramInt);
/*     */   
/*     */   static final native int GetSimulations(long paramLong);
/*     */   
/*     */   static final native int GetFontCount(long paramLong);
/*     */   
/*     */   static final native long GetFont(long paramLong, int paramInt);
/*     */   
/*     */   static final native int Analyze(long paramLong, boolean[] paramArrayOfboolean, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3);
/*     */   
/*     */   static final native char[] GetString(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   static final native int GetStringLength(long paramLong, int paramInt);
/*     */   
/*     */   static final native int FindLocaleName(long paramLong, char[] paramArrayOfchar);
/*     */   
/*     */   static final native long GetFamilyNames(long paramLong);
/*     */   
/*     */   static final native long GetFirstMatchingFont(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   static final native int GetFontFamilyCount(long paramLong);
/*     */   
/*     */   static final native long GetFontFamily(long paramLong, int paramInt);
/*     */   
/*     */   static final native int FindFamilyName(long paramLong, char[] paramArrayOfchar);
/*     */   
/*     */   static final native long GetFontFromFontFace(long paramLong1, long paramLong2);
/*     */   
/*     */   static final native byte[] CreateAlphaTexture(long paramLong, int paramInt, RECT paramRECT);
/*     */   
/*     */   static final native RECT GetAlphaTextureBounds(long paramLong, int paramInt);
/*     */   
/*     */   static final native long GetSystemFontCollection(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static final native long CreateGlyphRunAnalysis(long paramLong, DWRITE_GLYPH_RUN paramDWRITE_GLYPH_RUN, float paramFloat1, DWRITE_MATRIX paramDWRITE_MATRIX, int paramInt1, int paramInt2, float paramFloat2, float paramFloat3);
/*     */   
/*     */   static final native long CreateTextAnalyzer(long paramLong);
/*     */   
/*     */   static final native long CreateTextFormat(long paramLong1, char[] paramArrayOfchar1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, float paramFloat, char[] paramArrayOfchar2);
/*     */   
/*     */   static final native long CreateTextLayout(long paramLong1, char[] paramArrayOfchar, int paramInt1, int paramInt2, long paramLong2, float paramFloat1, float paramFloat2);
/*     */   
/*     */   static final native long CreateFontFileReference(long paramLong, char[] paramArrayOfchar);
/*     */   
/*     */   static final native long CreateFontFace(long paramLong1, int paramInt1, long paramLong2, int paramInt2, int paramInt3);
/*     */   
/*     */   static final native int AddRef(long paramLong);
/*     */   
/*     */   static final native int Release(long paramLong);
/*     */   
/*     */   static final native int AnalyzeScript(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3);
/*     */   
/*     */   static final native int GetGlyphs(long paramLong1, char[] paramArrayOfchar1, int paramInt1, int paramInt2, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, DWRITE_SCRIPT_ANALYSIS paramDWRITE_SCRIPT_ANALYSIS, char[] paramArrayOfchar2, long paramLong3, long[] paramArrayOflong, int[] paramArrayOfint1, int paramInt3, int paramInt4, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int[] paramArrayOfint2);
/*     */   
/*     */   static final native int GetGlyphPlacements(long paramLong1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt3, long paramLong2, float paramFloat, boolean paramBoolean1, boolean paramBoolean2, DWRITE_SCRIPT_ANALYSIS paramDWRITE_SCRIPT_ANALYSIS, char[] paramArrayOfchar2, long[] paramArrayOflong, int[] paramArrayOfint, int paramInt4, float[] paramArrayOffloat1, float[] paramArrayOffloat2);
/*     */   
/*     */   static final native int Draw(long paramLong1, long paramLong2, long paramLong3, float paramFloat1, float paramFloat2);
/*     */   
/*     */   static final native long CreateBitmap(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   static final native long Lock(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*     */   
/*     */   static final native byte[] GetDataPointer(long paramLong);
/*     */   
/*     */   static final native int GetStride(long paramLong);
/*     */   
/*     */   static final native long CreateWicBitmapRenderTarget(long paramLong1, long paramLong2, D2D1_RENDER_TARGET_PROPERTIES paramD2D1_RENDER_TARGET_PROPERTIES);
/*     */   
/*     */   static final native void BeginDraw(long paramLong);
/*     */   
/*     */   static final native int EndDraw(long paramLong);
/*     */   
/*     */   static final native void Clear(long paramLong, D2D1_COLOR_F paramD2D1_COLOR_F);
/*     */   
/*     */   static final native void SetTextAntialiasMode(long paramLong, int paramInt);
/*     */   
/*     */   static final native void SetTransform(long paramLong, D2D1_MATRIX_3X2_F paramD2D1_MATRIX_3X2_F);
/*     */   
/*     */   static final native void DrawGlyphRun(long paramLong1, D2D1_POINT_2F paramD2D1_POINT_2F, DWRITE_GLYPH_RUN paramDWRITE_GLYPH_RUN, long paramLong2, int paramInt);
/*     */   
/*     */   static final native long CreateSolidColorBrush(long paramLong, D2D1_COLOR_F paramD2D1_COLOR_F);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\OS.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */