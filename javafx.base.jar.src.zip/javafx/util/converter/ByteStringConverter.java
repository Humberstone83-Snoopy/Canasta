/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteStringConverter
/*    */   extends StringConverter<Byte>
/*    */ {
/*    */   public Byte fromString(String paramString) {
/* 39 */     if (paramString == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     paramString = paramString.trim();
/*    */     
/* 45 */     if (paramString.length() < 1) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return Byte.valueOf(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(Byte paramByte) {
/* 55 */     if (paramByte == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return Byte.toString(paramByte.byteValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\ByteStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */