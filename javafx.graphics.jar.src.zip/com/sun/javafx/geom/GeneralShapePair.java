/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneralShapePair
/*     */   extends ShapePair
/*     */ {
/*     */   private final Shape outer;
/*     */   private final Shape inner;
/*     */   private final int combinationType;
/*     */   
/*     */   public GeneralShapePair(Shape paramShape1, Shape paramShape2, int paramInt) {
/*  46 */     this.outer = paramShape1;
/*  47 */     this.inner = paramShape2;
/*  48 */     this.combinationType = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getCombinationType() {
/*  53 */     return this.combinationType;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Shape getOuterShape() {
/*  58 */     return this.outer;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Shape getInnerShape() {
/*  63 */     return this.inner;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape copy() {
/*  68 */     return new GeneralShapePair(this.outer.copy(), this.inner.copy(), this.combinationType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/*  73 */     if (this.combinationType == 4) {
/*  74 */       return (this.outer.contains(paramFloat1, paramFloat2) && this.inner.contains(paramFloat1, paramFloat2));
/*     */     }
/*  76 */     return (this.outer.contains(paramFloat1, paramFloat2) && !this.inner.contains(paramFloat1, paramFloat2));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  82 */     if (this.combinationType == 4) {
/*  83 */       return (this.outer.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && this.inner.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */     }
/*  85 */     return (this.outer.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && !this.inner.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  91 */     if (this.combinationType == 4) {
/*  92 */       return (this.outer.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && this.inner.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */     }
/*  94 */     return (this.outer.contains(paramFloat1, paramFloat2, paramFloat3, paramFloat4) && !this.inner.intersects(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds getBounds() {
/* 100 */     RectBounds rectBounds = this.outer.getBounds();
/* 101 */     if (this.combinationType == 4) {
/* 102 */       rectBounds.intersectWith(this.inner.getBounds());
/*     */     }
/* 104 */     return rectBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 109 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ 
/*     */   
/*     */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 114 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\GeneralShapePair.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */