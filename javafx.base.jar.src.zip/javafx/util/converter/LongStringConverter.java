/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LongStringConverter
/*    */   extends StringConverter<Long>
/*    */ {
/*    */   public Long fromString(String paramString) {
/* 39 */     if (paramString == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     paramString = paramString.trim();
/*    */     
/* 45 */     if (paramString.length() < 1) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return Long.valueOf(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(Long paramLong) {
/* 55 */     if (paramLong == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return Long.toString(paramLong.longValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\LongStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */