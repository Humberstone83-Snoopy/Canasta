package javafx.beans.property;

import javafx.beans.value.ObservableValue;

public interface ReadOnlyProperty<T> extends ObservableValue<T> {
  Object getBean();
  
  String getName();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */