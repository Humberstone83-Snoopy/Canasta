/*     */ package com.sun.webkit;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.WCGraphicsContext;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ import com.sun.webkit.network.URLs;
/*     */ import com.sun.webkit.plugin.Plugin;
/*     */ import com.sun.webkit.plugin.PluginListener;
/*     */ import com.sun.webkit.plugin.PluginManager;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCPluginWidget
/*     */   extends WCWidget
/*     */   implements PluginListener
/*     */ {
/*  43 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCPluginWidget.class.getName());
/*     */   
/*     */   private final Plugin plugin;
/*  46 */   private long pData = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  51 */     initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WCPluginWidget(WebPage paramWebPage, Plugin paramPlugin, int paramInt1, int paramInt2) {
/*  59 */     super(paramWebPage);
/*  60 */     this.plugin = paramPlugin;
/*  61 */     setBounds(0, 0, paramInt1, paramInt2);
/*     */     
/*  63 */     WebPageClient webPageClient = paramWebPage.getPageClient();
/*  64 */     this.plugin.activate(
/*  65 */         (null == webPageClient) ? null : webPageClient.getContainer(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requestFocus() {
/*  71 */     this.plugin.requestFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static WCPluginWidget create(WebPage paramWebPage, int paramInt1, int paramInt2, String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  82 */     URL uRL = null;
/*     */     try {
/*  84 */       uRL = URLs.newURL(paramString1);
/*  85 */     } catch (MalformedURLException malformedURLException) {
/*  86 */       log.fine(null, malformedURLException);
/*     */     } 
/*  88 */     return new WCPluginWidget(paramWebPage, 
/*     */         
/*  90 */         PluginManager.createPlugin(uRL, paramString2, paramArrayOfString1, paramArrayOfString2), paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fwkSetNativeContainerBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 100 */     this.plugin.setNativeContainerBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 111 */     super.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/* 112 */     this.plugin.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEnabled(boolean paramBoolean) {
/* 118 */     this.plugin.setEnabled(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setVisible(boolean paramBoolean) {
/* 123 */     this.plugin.setVisible(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void destroy() {
/* 129 */     this.pData = 0L;
/* 130 */     this.plugin.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paint(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 140 */     WCRectangle wCRectangle1 = getBounds();
/* 141 */     WCRectangle wCRectangle2 = wCRectangle1.intersection(new WCRectangle(paramInt1, paramInt2, paramInt3, paramInt4));
/* 142 */     if (!wCRectangle2.isEmpty()) {
/* 143 */       paramWCGraphicsContext.translate(wCRectangle1.getX(), wCRectangle1.getY());
/* 144 */       wCRectangle2.translate(-wCRectangle1.getX(), -wCRectangle1.getY());
/* 145 */       paramWCGraphicsContext.setClip(wCRectangle2.getIntX(), wCRectangle2.getIntY(), wCRectangle2.getIntWidth(), wCRectangle2.getIntHeight());
/* 146 */       this.plugin.paint(paramWCGraphicsContext, wCRectangle2
/*     */ 
/*     */           
/* 149 */           .getIntX(), wCRectangle2
/* 150 */           .getIntY(), wCRectangle2
/* 151 */           .getIntWidth(), wCRectangle2
/* 152 */           .getIntHeight());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fwkHandleMouseEvent(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, long paramLong) {
/* 180 */     return this.plugin.handleMouseEvent(paramString, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fwkRedraw(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 197 */     twkInvalidateWindowlessPluginRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String fwkEvent(int paramInt, String paramString1, String paramString2) {
/* 207 */     if (-1 == paramInt && Boolean.parseBoolean(paramString2)) {
/* 208 */       twkSetPlugunFocused(Boolean.valueOf(paramString2).booleanValue());
/*     */     }
/* 210 */     return "";
/*     */   }
/*     */   
/*     */   private static native void initIDs();
/*     */   
/*     */   private native WCRectangle twkConvertToPage(WCRectangle paramWCRectangle);
/*     */   
/*     */   private native void twkInvalidateWindowlessPluginRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   private native void twkSetPlugunFocused(boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\WCPluginWidget.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */