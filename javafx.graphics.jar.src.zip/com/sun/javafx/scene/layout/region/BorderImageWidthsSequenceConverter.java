/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.BorderWidths;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorderImageWidthsSequenceConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue[], BorderWidths>[], BorderWidths[]>
/*    */ {
/* 40 */   private static final BorderImageWidthsSequenceConverter CONVERTER = new BorderImageWidthsSequenceConverter();
/*    */ 
/*    */   
/*    */   public static BorderImageWidthsSequenceConverter getInstance() {
/* 44 */     return CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BorderWidths[] convert(ParsedValue<ParsedValue<ParsedValue[], BorderWidths>[], BorderWidths[]> paramParsedValue, Font paramFont) {
/* 65 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 66 */     BorderWidths[] arrayOfBorderWidths = new BorderWidths[arrayOfParsedValue.length];
/* 67 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 68 */       arrayOfBorderWidths[b] = BorderImageWidthConverter.getInstance().convert(arrayOfParsedValue[b], paramFont);
/*    */     }
/* 70 */     return arrayOfBorderWidths;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 75 */     return "BorderImageWidthsSequenceConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderImageWidthsSequenceConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */