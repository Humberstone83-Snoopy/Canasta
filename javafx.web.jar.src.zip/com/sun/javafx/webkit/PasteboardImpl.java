/*    */ package com.sun.javafx.webkit;
/*    */ 
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import com.sun.webkit.Pasteboard;
/*    */ import com.sun.webkit.graphics.WCGraphicsManager;
/*    */ import com.sun.webkit.graphics.WCImageFrame;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Arrays;
/*    */ import javafx.scene.image.Image;
/*    */ import javafx.scene.input.Clipboard;
/*    */ import javafx.scene.input.ClipboardContent;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PasteboardImpl
/*    */   implements Pasteboard
/*    */ {
/* 43 */   private final Clipboard clipboard = Clipboard.getSystemClipboard();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPlainText() {
/* 49 */     return this.clipboard.getString();
/*    */   }
/*    */   
/*    */   public String getHtml() {
/* 53 */     return this.clipboard.getHtml();
/*    */   }
/*    */   
/*    */   public void writePlainText(String paramString) {
/* 57 */     ClipboardContent clipboardContent = new ClipboardContent();
/* 58 */     clipboardContent.putString(paramString);
/* 59 */     this.clipboard.setContent(clipboardContent);
/*    */   }
/*    */   
/*    */   public void writeSelection(boolean paramBoolean, String paramString1, String paramString2) {
/* 63 */     ClipboardContent clipboardContent = new ClipboardContent();
/* 64 */     clipboardContent.putString(paramString1);
/* 65 */     clipboardContent.putHtml(paramString2);
/* 66 */     this.clipboard.setContent(clipboardContent);
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeImage(WCImageFrame paramWCImageFrame) {
/* 71 */     Object object = WCGraphicsManager.getGraphicsManager().toPlatformImage(paramWCImageFrame.getFrame());
/* 72 */     Image image = Toolkit.getImageAccessor().fromPlatformImage(object);
/* 73 */     if (image != null) {
/* 74 */       ClipboardContent clipboardContent = new ClipboardContent();
/* 75 */       clipboardContent.putImage(image);
/* 76 */       String str = paramWCImageFrame.getFrame().getFileExtension();
/*    */       try {
/* 78 */         File file = File.createTempFile("jfx", "." + str);
/* 79 */         file.deleteOnExit();
/* 80 */         ImageIO.write(UIClientImpl.toBufferedImage(image), str, file);
/*    */ 
/*    */         
/* 83 */         clipboardContent.putFiles(Arrays.asList(new File[] { file }));
/* 84 */       } catch (IOException|SecurityException iOException) {}
/*    */ 
/*    */       
/* 87 */       this.clipboard.setContent(clipboardContent);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void writeUrl(String paramString1, String paramString2) {
/* 92 */     ClipboardContent clipboardContent = new ClipboardContent();
/* 93 */     clipboardContent.putString(paramString1);
/* 94 */     clipboardContent.putHtml(paramString2);
/* 95 */     clipboardContent.putUrl(paramString1);
/* 96 */     this.clipboard.setContent(clipboardContent);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\PasteboardImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */