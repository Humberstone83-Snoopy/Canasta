/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.Size;
/*    */ import javafx.css.SizeUnits;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.layout.CornerRadii;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CornerRadiiConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue<?, Size>[][], CornerRadii>[], CornerRadii[]>
/*    */ {
/* 40 */   private static final CornerRadiiConverter INSTANCE = new CornerRadiiConverter();
/*    */ 
/*    */   
/*    */   public static CornerRadiiConverter getInstance() {
/* 44 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CornerRadii[] convert(ParsedValue<ParsedValue<ParsedValue<?, Size>[][], CornerRadii>[], CornerRadii[]> paramParsedValue, Font paramFont) {
/* 54 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 55 */     CornerRadii[] arrayOfCornerRadii = new CornerRadii[arrayOfParsedValue.length];
/*    */ 
/*    */     
/* 58 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/*    */       
/* 60 */       ParsedValue[][] arrayOfParsedValue1 = arrayOfParsedValue[b].getValue();
/*    */       
/* 62 */       Size size1 = arrayOfParsedValue1[0][0].convert(paramFont);
/* 63 */       Size size2 = arrayOfParsedValue1[0][1].convert(paramFont);
/* 64 */       Size size3 = arrayOfParsedValue1[0][2].convert(paramFont);
/* 65 */       Size size4 = arrayOfParsedValue1[0][3].convert(paramFont);
/* 66 */       Size size5 = arrayOfParsedValue1[1][0].convert(paramFont);
/* 67 */       Size size6 = arrayOfParsedValue1[1][1].convert(paramFont);
/* 68 */       Size size7 = arrayOfParsedValue1[1][2].convert(paramFont);
/* 69 */       Size size8 = arrayOfParsedValue1[1][3].convert(paramFont);
/*    */       
/* 71 */       arrayOfCornerRadii[b] = new CornerRadii(size1
/* 72 */           .pixels(paramFont), size5.pixels(paramFont), size6
/* 73 */           .pixels(paramFont), size2.pixels(paramFont), size3
/* 74 */           .pixels(paramFont), size7.pixels(paramFont), size8
/* 75 */           .pixels(paramFont), size4.pixels(paramFont), 
/* 76 */           (size1.getUnits() == SizeUnits.PERCENT), (size5.getUnits() == SizeUnits.PERCENT), 
/* 77 */           (size6.getUnits() == SizeUnits.PERCENT), (size2.getUnits() == SizeUnits.PERCENT), 
/* 78 */           (size3.getUnits() == SizeUnits.PERCENT), (size7.getUnits() == SizeUnits.PERCENT), 
/* 79 */           (size7.getUnits() == SizeUnits.PERCENT), (size4.getUnits() == SizeUnits.PERCENT));
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 84 */     return arrayOfCornerRadii;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\CornerRadiiConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */