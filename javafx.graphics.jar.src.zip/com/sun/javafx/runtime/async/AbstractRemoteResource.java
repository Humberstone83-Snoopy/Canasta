/*     */ package com.sun.javafx.runtime.async;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRemoteResource<T>
/*     */   extends AbstractAsyncOperation<T>
/*     */ {
/*     */   protected final String url;
/*     */   protected final String method;
/*     */   protected final String outboundContent;
/*     */   protected int fileSize;
/*  53 */   private Map<String, String> headers = new HashMap<>();
/*  54 */   private Map<String, List<String>> responseHeaders = new HashMap<>();
/*     */   
/*     */   protected AbstractRemoteResource(String paramString, AsyncOperationListener<T> paramAsyncOperationListener) {
/*  57 */     this(paramString, "GET", paramAsyncOperationListener);
/*     */   }
/*     */   
/*     */   protected AbstractRemoteResource(String paramString1, String paramString2, AsyncOperationListener<T> paramAsyncOperationListener) {
/*  61 */     this(paramString1, paramString2, (String)null, paramAsyncOperationListener);
/*     */   }
/*     */   
/*     */   protected AbstractRemoteResource(String paramString1, String paramString2, String paramString3, AsyncOperationListener<T> paramAsyncOperationListener) {
/*  65 */     super(paramAsyncOperationListener);
/*  66 */     this.url = paramString1;
/*  67 */     this.method = paramString2;
/*  68 */     this.outboundContent = paramString3;
/*     */   }
/*     */   
/*     */   protected abstract T processStream(InputStream paramInputStream) throws IOException;
/*     */   
/*     */   public T call() throws IOException {
/*  74 */     URL uRL = new URL(this.url);
/*  75 */     ProgressInputStream progressInputStream = null;
/*  76 */     String str = uRL.getProtocol();
/*  77 */     if (str.equals("http") || str.equals("https")) {
/*  78 */       HttpURLConnection httpURLConnection = (HttpURLConnection)uRL.openConnection();
/*  79 */       httpURLConnection.setRequestMethod(this.method);
/*  80 */       httpURLConnection.setDoInput(true);
/*     */       
/*  82 */       for (Map.Entry<String, String> entry : this.headers.entrySet()) {
/*  83 */         String str1 = (String)entry.getKey();
/*  84 */         String str2 = (String)entry.getValue();
/*  85 */         if (str2 != null && !str2.equals(""))
/*  86 */           httpURLConnection.setRequestProperty(str1, str2); 
/*     */       } 
/*  88 */       if (this.outboundContent != null && this.method.equals("POST")) {
/*  89 */         httpURLConnection.setDoOutput(true);
/*  90 */         byte[] arrayOfByte = this.outboundContent.getBytes("utf-8");
/*  91 */         httpURLConnection.setRequestProperty("Content-Length", String.valueOf(arrayOfByte.length));
/*  92 */         OutputStream outputStream = httpURLConnection.getOutputStream();
/*  93 */         outputStream.write(arrayOfByte);
/*  94 */         outputStream.close();
/*     */       } 
/*  96 */       httpURLConnection.connect();
/*  97 */       this.fileSize = httpURLConnection.getContentLength();
/*  98 */       setProgressMax(this.fileSize);
/*  99 */       this.responseHeaders = httpURLConnection.getHeaderFields();
/*     */       
/* 101 */       progressInputStream = new ProgressInputStream(httpURLConnection.getInputStream());
/*     */     } else {
/* 103 */       URLConnection uRLConnection = uRL.openConnection();
/* 104 */       setProgressMax(uRLConnection.getContentLength());
/* 105 */       progressInputStream = new ProgressInputStream(uRLConnection.getInputStream());
/*     */     } 
/*     */     
/*     */     try {
/* 109 */       return processStream(progressInputStream);
/*     */     } finally {
/*     */       
/* 112 */       progressInputStream.close();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected class ProgressInputStream extends BufferedInputStream {
/*     */     public ProgressInputStream(InputStream param1InputStream) {
/* 118 */       super(param1InputStream);
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized int read() throws IOException {
/* 123 */       if (Thread.currentThread().isInterrupted())
/* 124 */         throw new InterruptedIOException(); 
/* 125 */       int i = super.read();
/* 126 */       AbstractRemoteResource.this.addProgress(1);
/* 127 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 132 */       if (Thread.currentThread().isInterrupted())
/* 133 */         throw new InterruptedIOException(); 
/* 134 */       int i = super.read(param1ArrayOfbyte, param1Int1, param1Int2);
/* 135 */       AbstractRemoteResource.this.addProgress(i);
/* 136 */       return i;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] param1ArrayOfbyte) throws IOException {
/* 141 */       if (Thread.currentThread().isInterrupted())
/* 142 */         throw new InterruptedIOException(); 
/* 143 */       int i = super.read(param1ArrayOfbyte);
/* 144 */       AbstractRemoteResource.this.addProgress(i);
/* 145 */       return i;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setHeader(String paramString1, String paramString2) {
/* 150 */     this.headers.put(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   public String getResponseHeader(String paramString) {
/* 154 */     String str = null;
/* 155 */     List list = this.responseHeaders.get(paramString);
/*     */     
/* 157 */     if (list != null) {
/* 158 */       StringBuilder stringBuilder = new StringBuilder();
/* 159 */       Iterator iterator = list.iterator();
/* 160 */       while (iterator.hasNext()) {
/* 161 */         stringBuilder.append(iterator.next());
/* 162 */         if (iterator.hasNext()) {
/* 163 */           stringBuilder.append(',');
/*     */         }
/*     */       } 
/* 166 */       str = stringBuilder.toString();
/*     */     } 
/* 168 */     return str;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\runtime\async\AbstractRemoteResource.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */