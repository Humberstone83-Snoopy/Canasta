/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class QuadIterator
/*     */   implements PathIterator
/*     */ {
/*     */   QuadCurve2D quad;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   
/*     */   QuadIterator(QuadCurve2D paramQuadCurve2D, BaseTransform paramBaseTransform) {
/*  44 */     this.quad = paramQuadCurve2D;
/*  45 */     this.transform = paramBaseTransform;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  55 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/*  63 */     return (this.index > 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/*  72 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/*     */     byte b;
/*  94 */     if (isDone()) {
/*  95 */       throw new NoSuchElementException("quad iterator iterator out of bounds");
/*     */     }
/*     */     
/*  98 */     if (this.index == 0) {
/*  99 */       paramArrayOffloat[0] = this.quad.x1;
/* 100 */       paramArrayOffloat[1] = this.quad.y1;
/* 101 */       b = 0;
/*     */     } else {
/* 103 */       paramArrayOffloat[0] = this.quad.ctrlx;
/* 104 */       paramArrayOffloat[1] = this.quad.ctrly;
/* 105 */       paramArrayOffloat[2] = this.quad.x2;
/* 106 */       paramArrayOffloat[3] = this.quad.y2;
/* 107 */       b = 2;
/*     */     } 
/* 109 */     if (this.transform != null) {
/* 110 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, (this.index == 0) ? 1 : 2);
/*     */     }
/* 112 */     return b;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\QuadIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */