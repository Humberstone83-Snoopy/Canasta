/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GraphicsDecoder
/*     */ {
/*     */   public static final int FILLRECT_FFFFI = 0;
/*     */   public static final int SETFILLCOLOR = 1;
/*     */   public static final int SETSTROKESTYLE = 2;
/*     */   public static final int SETSTROKECOLOR = 3;
/*     */   public static final int SETSTROKEWIDTH = 4;
/*     */   public static final int DRAWPOLYGON = 6;
/*     */   public static final int DRAWLINE = 7;
/*     */   public static final int DRAWIMAGE = 8;
/*     */   public static final int DRAWICON = 9;
/*     */   public static final int DRAWPATTERN = 10;
/*     */   public static final int TRANSLATE = 11;
/*     */   public static final int SAVESTATE = 12;
/*     */   public static final int RESTORESTATE = 13;
/*     */   public static final int CLIP_PATH = 14;
/*     */   public static final int SETCLIP_IIII = 15;
/*     */   public static final int DRAWRECT = 16;
/*     */   public static final int SETCOMPOSITE = 17;
/*     */   public static final int STROKEARC = 18;
/*     */   public static final int DRAWELLIPSE = 19;
/*     */   public static final int DRAWFOCUSRING = 20;
/*     */   public static final int SETALPHA = 21;
/*     */   public static final int BEGINTRANSPARENCYLAYER = 22;
/*     */   public static final int ENDTRANSPARENCYLAYER = 23;
/*     */   public static final int STROKE_PATH = 24;
/*     */   public static final int FILL_PATH = 25;
/*     */   public static final int GETIMAGE = 26;
/*     */   public static final int SCALE = 27;
/*     */   public static final int SETSHADOW = 28;
/*     */   public static final int DRAWSTRING = 29;
/*     */   public static final int DRAWSTRING_FAST = 31;
/*     */   public static final int DRAWWIDGET = 33;
/*     */   public static final int DRAWSCROLLBAR = 34;
/*     */   public static final int CLEARRECT_FFFF = 36;
/*     */   public static final int STROKERECT_FFFFF = 37;
/*     */   public static final int RENDERMEDIAPLAYER = 38;
/*     */   public static final int CONCATTRANSFORM_FFFFFF = 39;
/*     */   public static final int COPYREGION = 40;
/*     */   public static final int DECODERQ = 41;
/*     */   public static final int SET_TRANSFORM = 42;
/*     */   public static final int ROTATE = 43;
/*     */   public static final int RENDERMEDIACONTROL = 44;
/*     */   public static final int RENDERMEDIA_TIMETRACK = 45;
/*     */   public static final int RENDERMEDIA_VOLUMETRACK = 46;
/*     */   public static final int FILLRECT_FFFF = 47;
/*     */   public static final int FILL_ROUNDED_RECT = 48;
/*     */   public static final int SET_FILL_GRADIENT = 49;
/*     */   public static final int SET_STROKE_GRADIENT = 50;
/*     */   public static final int SET_LINE_DASH = 51;
/*     */   public static final int SET_LINE_CAP = 52;
/*     */   public static final int SET_LINE_JOIN = 53;
/*     */   public static final int SET_MITER_LIMIT = 54;
/*     */   public static final int SET_TEXT_MODE = 55;
/*     */   public static final int SET_PERSPECTIVE_TRANSFORM = 56;
/*  90 */   private static final PlatformLogger log = PlatformLogger.getLogger(GraphicsDecoder.class.getName());
/*     */   
/*     */   static void decode(WCGraphicsManager paramWCGraphicsManager, WCGraphicsContext paramWCGraphicsContext, BufferData paramBufferData) {
/*  93 */     if (paramWCGraphicsContext == null) {
/*     */       return;
/*     */     }
/*  96 */     ByteBuffer byteBuffer = paramBufferData.getBuffer();
/*  97 */     byteBuffer.order(ByteOrder.nativeOrder());
/*  98 */     while (byteBuffer.remaining() > 0) {
/*  99 */       WCMediaPlayer wCMediaPlayer; WCPageBackBuffer wCPageBackBuffer; WCRenderQueue wCRenderQueue; int j; float[] arrayOfFloat; int i = byteBuffer.getInt();
/* 100 */       switch (i) {
/*     */         case 47:
/* 102 */           paramWCGraphicsContext.fillRect(byteBuffer
/* 103 */               .getFloat(), byteBuffer
/* 104 */               .getFloat(), byteBuffer
/* 105 */               .getFloat(), byteBuffer
/* 106 */               .getFloat(), null);
/*     */           continue;
/*     */         
/*     */         case 0:
/* 110 */           paramWCGraphicsContext.fillRect(byteBuffer
/* 111 */               .getFloat(), byteBuffer
/* 112 */               .getFloat(), byteBuffer
/* 113 */               .getFloat(), byteBuffer
/* 114 */               .getFloat(), 
/* 115 */               Integer.valueOf(byteBuffer.getInt()));
/*     */           continue;
/*     */         case 48:
/* 118 */           paramWCGraphicsContext.fillRoundedRect(byteBuffer
/*     */               
/* 120 */               .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/*     */               
/* 122 */               .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/*     */               
/* 124 */               .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 125 */               .getInt());
/*     */           continue;
/*     */         case 36:
/* 128 */           paramWCGraphicsContext.clearRect(byteBuffer
/* 129 */               .getFloat(), byteBuffer
/* 130 */               .getFloat(), byteBuffer
/* 131 */               .getFloat(), byteBuffer
/* 132 */               .getFloat());
/*     */           continue;
/*     */         case 37:
/* 135 */           paramWCGraphicsContext.strokeRect(byteBuffer
/* 136 */               .getFloat(), byteBuffer
/* 137 */               .getFloat(), byteBuffer
/* 138 */               .getFloat(), byteBuffer
/* 139 */               .getFloat(), byteBuffer
/* 140 */               .getFloat());
/*     */           continue;
/*     */         case 1:
/* 143 */           paramWCGraphicsContext.setFillColor(byteBuffer.getInt());
/*     */           continue;
/*     */         case 55:
/* 146 */           paramWCGraphicsContext.setTextMode(getBoolean(byteBuffer), getBoolean(byteBuffer), getBoolean(byteBuffer));
/*     */           continue;
/*     */         case 2:
/* 149 */           paramWCGraphicsContext.setStrokeStyle(byteBuffer.getInt());
/*     */           continue;
/*     */         case 3:
/* 152 */           paramWCGraphicsContext.setStrokeColor(byteBuffer.getInt());
/*     */           continue;
/*     */         case 4:
/* 155 */           paramWCGraphicsContext.setStrokeWidth(byteBuffer.getFloat());
/*     */           continue;
/*     */         case 49:
/* 158 */           paramWCGraphicsContext.setFillGradient(getGradient(paramWCGraphicsContext, byteBuffer));
/*     */           continue;
/*     */         case 50:
/* 161 */           paramWCGraphicsContext.setStrokeGradient(getGradient(paramWCGraphicsContext, byteBuffer));
/*     */           continue;
/*     */         case 51:
/* 164 */           paramWCGraphicsContext.setLineDash(byteBuffer.getFloat(), getFloatArray(byteBuffer));
/*     */           continue;
/*     */         case 52:
/* 167 */           paramWCGraphicsContext.setLineCap(byteBuffer.getInt());
/*     */           continue;
/*     */         case 53:
/* 170 */           paramWCGraphicsContext.setLineJoin(byteBuffer.getInt());
/*     */           continue;
/*     */         case 54:
/* 173 */           paramWCGraphicsContext.setMiterLimit(byteBuffer.getFloat());
/*     */           continue;
/*     */         case 6:
/* 176 */           paramWCGraphicsContext.drawPolygon(getPath(paramWCGraphicsManager, byteBuffer), (byteBuffer.getInt() == -1));
/*     */           continue;
/*     */         case 7:
/* 179 */           paramWCGraphicsContext.drawLine(byteBuffer
/* 180 */               .getInt(), byteBuffer
/* 181 */               .getInt(), byteBuffer
/* 182 */               .getInt(), byteBuffer
/* 183 */               .getInt());
/*     */           continue;
/*     */         case 8:
/* 186 */           drawImage(paramWCGraphicsContext, paramWCGraphicsManager
/* 187 */               .getRef(byteBuffer.getInt()), byteBuffer
/*     */               
/* 189 */               .getFloat(), byteBuffer
/* 190 */               .getFloat(), byteBuffer
/* 191 */               .getFloat(), byteBuffer
/* 192 */               .getFloat(), byteBuffer
/*     */               
/* 194 */               .getFloat(), byteBuffer
/* 195 */               .getFloat(), byteBuffer
/* 196 */               .getFloat(), byteBuffer
/* 197 */               .getFloat());
/*     */           continue;
/*     */         case 9:
/* 200 */           paramWCGraphicsContext.drawIcon((WCIcon)paramWCGraphicsManager.getRef(byteBuffer.getInt()), byteBuffer
/* 201 */               .getInt(), byteBuffer
/* 202 */               .getInt());
/*     */           continue;
/*     */         case 10:
/* 205 */           drawPattern(paramWCGraphicsContext, paramWCGraphicsManager
/* 206 */               .getRef(byteBuffer.getInt()), 
/* 207 */               getRectangle(byteBuffer), (WCTransform)paramWCGraphicsManager
/* 208 */               .getRef(byteBuffer.getInt()), 
/* 209 */               getPoint(byteBuffer), 
/* 210 */               getRectangle(byteBuffer));
/*     */           continue;
/*     */         case 11:
/* 213 */           paramWCGraphicsContext.translate(byteBuffer.getFloat(), byteBuffer.getFloat());
/*     */           continue;
/*     */         case 27:
/* 216 */           paramWCGraphicsContext.scale(byteBuffer.getFloat(), byteBuffer.getFloat());
/*     */           continue;
/*     */         case 12:
/* 219 */           paramWCGraphicsContext.saveState();
/*     */           continue;
/*     */         case 13:
/* 222 */           paramWCGraphicsContext.restoreState();
/*     */           continue;
/*     */         case 14:
/* 225 */           paramWCGraphicsContext.setClip(
/* 226 */               getPath(paramWCGraphicsManager, byteBuffer), 
/* 227 */               (byteBuffer.getInt() > 0));
/*     */           continue;
/*     */         case 15:
/* 230 */           paramWCGraphicsContext.setClip(byteBuffer
/* 231 */               .getInt(), byteBuffer
/* 232 */               .getInt(), byteBuffer
/* 233 */               .getInt(), byteBuffer
/* 234 */               .getInt());
/*     */           continue;
/*     */         case 16:
/* 237 */           paramWCGraphicsContext.drawRect(byteBuffer
/* 238 */               .getInt(), byteBuffer
/* 239 */               .getInt(), byteBuffer
/* 240 */               .getInt(), byteBuffer
/* 241 */               .getInt());
/*     */           continue;
/*     */         case 17:
/* 244 */           paramWCGraphicsContext.setComposite(byteBuffer.getInt());
/*     */           continue;
/*     */         case 18:
/* 247 */           paramWCGraphicsContext.strokeArc(byteBuffer
/* 248 */               .getInt(), byteBuffer
/* 249 */               .getInt(), byteBuffer
/* 250 */               .getInt(), byteBuffer
/* 251 */               .getInt(), byteBuffer
/* 252 */               .getInt(), byteBuffer
/* 253 */               .getInt());
/*     */           continue;
/*     */         case 19:
/* 256 */           paramWCGraphicsContext.drawEllipse(byteBuffer
/* 257 */               .getInt(), byteBuffer
/* 258 */               .getInt(), byteBuffer
/* 259 */               .getInt(), byteBuffer
/* 260 */               .getInt());
/*     */           continue;
/*     */         case 20:
/* 263 */           paramWCGraphicsContext.drawFocusRing(byteBuffer
/* 264 */               .getInt(), byteBuffer
/* 265 */               .getInt(), byteBuffer
/* 266 */               .getInt(), byteBuffer
/* 267 */               .getInt(), byteBuffer
/* 268 */               .getInt());
/*     */           continue;
/*     */         case 21:
/* 271 */           paramWCGraphicsContext.setAlpha(byteBuffer.getFloat());
/*     */           continue;
/*     */         case 22:
/* 274 */           paramWCGraphicsContext.beginTransparencyLayer(byteBuffer.getFloat());
/*     */           continue;
/*     */         case 23:
/* 277 */           paramWCGraphicsContext.endTransparencyLayer();
/*     */           continue;
/*     */         case 24:
/* 280 */           paramWCGraphicsContext.strokePath(getPath(paramWCGraphicsManager, byteBuffer));
/*     */           continue;
/*     */         case 25:
/* 283 */           paramWCGraphicsContext.fillPath(getPath(paramWCGraphicsManager, byteBuffer));
/*     */           continue;
/*     */         case 28:
/* 286 */           paramWCGraphicsContext.setShadow(byteBuffer
/* 287 */               .getFloat(), byteBuffer
/* 288 */               .getFloat(), byteBuffer
/* 289 */               .getFloat(), byteBuffer
/* 290 */               .getInt());
/*     */           continue;
/*     */         case 29:
/* 293 */           paramWCGraphicsContext.drawString((WCFont)paramWCGraphicsManager
/* 294 */               .getRef(byteBuffer.getInt()), paramBufferData
/* 295 */               .getString(byteBuffer.getInt()), 
/* 296 */               (byteBuffer.getInt() == -1), byteBuffer
/* 297 */               .getInt(), byteBuffer.getInt(), byteBuffer
/* 298 */               .getFloat(), byteBuffer.getFloat());
/*     */           continue;
/*     */         case 31:
/* 301 */           paramWCGraphicsContext.drawString((WCFont)paramWCGraphicsManager
/* 302 */               .getRef(byteBuffer.getInt()), paramBufferData
/* 303 */               .getIntArray(byteBuffer.getInt()), paramBufferData
/* 304 */               .getFloatArray(byteBuffer.getInt()), byteBuffer
/* 305 */               .getFloat(), byteBuffer
/* 306 */               .getFloat());
/*     */           continue;
/*     */         case 33:
/* 309 */           paramWCGraphicsContext.drawWidget((RenderTheme)paramWCGraphicsManager.getRef(byteBuffer.getInt()), paramWCGraphicsManager
/* 310 */               .getRef(byteBuffer.getInt()), byteBuffer.getInt(), byteBuffer.getInt());
/*     */           continue;
/*     */         case 34:
/* 313 */           paramWCGraphicsContext.drawScrollbar((ScrollBarTheme)paramWCGraphicsManager.getRef(byteBuffer.getInt()), paramWCGraphicsManager
/* 314 */               .getRef(byteBuffer.getInt()), byteBuffer.getInt(), byteBuffer.getInt(), byteBuffer
/* 315 */               .getInt(), byteBuffer.getInt());
/*     */           continue;
/*     */         case 38:
/* 318 */           wCMediaPlayer = (WCMediaPlayer)paramWCGraphicsManager.getRef(byteBuffer.getInt());
/* 319 */           wCMediaPlayer.render(paramWCGraphicsContext, byteBuffer
/* 320 */               .getInt(), byteBuffer
/* 321 */               .getInt(), byteBuffer
/* 322 */               .getInt(), byteBuffer
/* 323 */               .getInt());
/*     */           continue;
/*     */         case 39:
/* 326 */           paramWCGraphicsContext.concatTransform(new WCTransform(byteBuffer
/* 327 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 328 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat()));
/*     */           continue;
/*     */         case 56:
/* 331 */           paramWCGraphicsContext.setPerspectiveTransform(new WCTransform(byteBuffer
/* 332 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 333 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 334 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 335 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat()));
/*     */           continue;
/*     */         case 42:
/* 338 */           paramWCGraphicsContext.setTransform(new WCTransform(byteBuffer
/* 339 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat(), byteBuffer
/* 340 */                 .getFloat(), byteBuffer.getFloat(), byteBuffer.getFloat()));
/*     */           continue;
/*     */         case 40:
/* 343 */           wCPageBackBuffer = (WCPageBackBuffer)paramWCGraphicsManager.getRef(byteBuffer.getInt());
/* 344 */           wCPageBackBuffer.copyArea(byteBuffer.getInt(), byteBuffer.getInt(), byteBuffer.getInt(), byteBuffer.getInt(), byteBuffer
/* 345 */               .getInt(), byteBuffer.getInt());
/*     */           continue;
/*     */         case 41:
/* 348 */           wCRenderQueue = (WCRenderQueue)paramWCGraphicsManager.getRef(byteBuffer.getInt());
/* 349 */           wCRenderQueue.decode(paramWCGraphicsContext.getFontSmoothingType());
/*     */           continue;
/*     */         case 43:
/* 352 */           paramWCGraphicsContext.rotate(byteBuffer.getFloat());
/*     */           continue;
/*     */         case 44:
/* 355 */           RenderMediaControls.paintControl(paramWCGraphicsContext, byteBuffer
/* 356 */               .getInt(), byteBuffer
/* 357 */               .getInt(), byteBuffer
/* 358 */               .getInt(), byteBuffer
/* 359 */               .getInt(), byteBuffer
/* 360 */               .getInt());
/*     */           continue;
/*     */         case 45:
/* 363 */           j = byteBuffer.getInt();
/* 364 */           arrayOfFloat = new float[j * 2];
/* 365 */           byteBuffer.asFloatBuffer().get(arrayOfFloat);
/* 366 */           byteBuffer.position(byteBuffer.position() + j * 4 * 2);
/* 367 */           RenderMediaControls.paintTimeSliderTrack(paramWCGraphicsContext, byteBuffer
/* 368 */               .getFloat(), byteBuffer
/* 369 */               .getFloat(), arrayOfFloat, byteBuffer
/*     */               
/* 371 */               .getInt(), byteBuffer
/* 372 */               .getInt(), byteBuffer
/* 373 */               .getInt(), byteBuffer
/* 374 */               .getInt());
/*     */           continue;
/*     */         
/*     */         case 46:
/* 378 */           RenderMediaControls.paintVolumeTrack(paramWCGraphicsContext, byteBuffer
/* 379 */               .getFloat(), 
/* 380 */               (byteBuffer.getInt() != 0), byteBuffer
/* 381 */               .getInt(), byteBuffer
/* 382 */               .getInt(), byteBuffer
/* 383 */               .getInt(), byteBuffer
/* 384 */               .getInt());
/*     */           continue;
/*     */       } 
/* 387 */       log.fine("ERROR. Unknown primitive found");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void drawPattern(WCGraphicsContext paramWCGraphicsContext, Object paramObject, WCRectangle paramWCRectangle1, WCTransform paramWCTransform, WCPoint paramWCPoint, WCRectangle paramWCRectangle2) {
/* 402 */     WCImage wCImage = WCImage.getImage(paramObject);
/* 403 */     if (wCImage != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 410 */         paramWCGraphicsContext.drawPattern(wCImage, paramWCRectangle1, paramWCTransform, paramWCPoint, paramWCRectangle2);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 416 */       catch (OutOfMemoryError outOfMemoryError) {
/* 417 */         outOfMemoryError.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void drawImage(WCGraphicsContext paramWCGraphicsContext, Object paramObject, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/* 428 */     WCImage wCImage = WCImage.getImage(paramObject);
/* 429 */     if (wCImage != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 436 */         paramWCGraphicsContext.drawImage(wCImage, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*     */ 
/*     */       
/*     */       }
/* 440 */       catch (OutOfMemoryError outOfMemoryError) {
/* 441 */         outOfMemoryError.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static boolean getBoolean(ByteBuffer paramByteBuffer) {
/* 447 */     return (0 != paramByteBuffer.getInt());
/*     */   }
/*     */   
/*     */   private static float[] getFloatArray(ByteBuffer paramByteBuffer) {
/* 451 */     float[] arrayOfFloat = new float[paramByteBuffer.getInt()];
/* 452 */     for (byte b = 0; b < arrayOfFloat.length; b++) {
/* 453 */       arrayOfFloat[b] = paramByteBuffer.getFloat();
/*     */     }
/* 455 */     return arrayOfFloat;
/*     */   }
/*     */   
/*     */   private static WCPath getPath(WCGraphicsManager paramWCGraphicsManager, ByteBuffer paramByteBuffer) {
/* 459 */     WCPath wCPath = (WCPath)paramWCGraphicsManager.getRef(paramByteBuffer.getInt());
/* 460 */     wCPath.setWindingRule(paramByteBuffer.getInt());
/* 461 */     return wCPath;
/*     */   }
/*     */   
/*     */   private static WCPoint getPoint(ByteBuffer paramByteBuffer) {
/* 465 */     return new WCPoint(paramByteBuffer.getFloat(), paramByteBuffer
/* 466 */         .getFloat());
/*     */   }
/*     */   
/*     */   private static WCRectangle getRectangle(ByteBuffer paramByteBuffer) {
/* 470 */     return new WCRectangle(paramByteBuffer.getFloat(), paramByteBuffer
/* 471 */         .getFloat(), paramByteBuffer
/* 472 */         .getFloat(), paramByteBuffer
/* 473 */         .getFloat());
/*     */   }
/*     */   
/*     */   private static WCGradient getGradient(WCGraphicsContext paramWCGraphicsContext, ByteBuffer paramByteBuffer) {
/* 477 */     WCPoint wCPoint1 = getPoint(paramByteBuffer);
/* 478 */     WCPoint wCPoint2 = getPoint(paramByteBuffer);
/*     */ 
/*     */     
/* 481 */     WCGradient wCGradient = getBoolean(paramByteBuffer) ? paramWCGraphicsContext.createRadialGradient(wCPoint1, paramByteBuffer.getFloat(), wCPoint2, paramByteBuffer.getFloat()) : paramWCGraphicsContext.createLinearGradient(wCPoint1, wCPoint2);
/*     */     
/* 483 */     boolean bool = getBoolean(paramByteBuffer);
/* 484 */     int i = paramByteBuffer.getInt();
/* 485 */     if (wCGradient != null) {
/* 486 */       wCGradient.setProportional(bool);
/* 487 */       wCGradient.setSpreadMethod(i);
/*     */     } 
/* 489 */     int j = paramByteBuffer.getInt();
/* 490 */     for (byte b = 0; b < j; b++) {
/* 491 */       int k = paramByteBuffer.getInt();
/* 492 */       float f = paramByteBuffer.getFloat();
/* 493 */       if (wCGradient != null) {
/* 494 */         wCGradient.addStop(k, f);
/*     */       }
/*     */     } 
/* 497 */     return wCGradient;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\GraphicsDecoder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */