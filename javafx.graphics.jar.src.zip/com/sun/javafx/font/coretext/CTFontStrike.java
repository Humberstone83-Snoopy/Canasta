/*     */ package com.sun.javafx.font.coretext;
/*     */ 
/*     */ import com.sun.javafx.font.DisposerRecord;
/*     */ import com.sun.javafx.font.FontStrikeDesc;
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontStrike;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CTFontStrike
/*     */   extends PrismFontStrike<CTFontFile>
/*     */ {
/*     */   private long fontRef;
/*     */   CGAffineTransform matrix;
/*     */   static final float SUBPIXEL4_SIZE = 12.0F;
/*     */   static final float SUBPIXEL3_SIZE = 18.0F;
/*     */   static final float SUBPIXEL2_SIZE = 34.0F;
/*     */   private static final boolean SUBPIXEL;
/*     */   
/*     */   static {
/*  53 */     int i = PrismFontFactory.getFontFactory().getSubPixelMode();
/*  54 */     SUBPIXEL = ((i & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   CTFontStrike(CTFontFile paramCTFontFile, float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/*  60 */     super(paramCTFontFile, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/*  61 */     float f = PrismFontFactory.getFontSizeLimit();
/*  62 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  63 */       this.drawShapes = (paramFloat > f);
/*     */     } else {
/*  65 */       BaseTransform baseTransform = getTransform();
/*  66 */       this.matrix = new CGAffineTransform();
/*  67 */       this.matrix.a = baseTransform.getMxx();
/*  68 */       this.matrix.b = -baseTransform.getMyx();
/*  69 */       this.matrix.c = -baseTransform.getMxy();
/*  70 */       this.matrix.d = baseTransform.getMyy();
/*     */       
/*  72 */       if (Math.abs(this.matrix.a * paramFloat) > f || 
/*  73 */         Math.abs(this.matrix.b * paramFloat) > f || 
/*  74 */         Math.abs(this.matrix.c * paramFloat) > f || 
/*  75 */         Math.abs(this.matrix.d * paramFloat) > f)
/*     */       {
/*  77 */         this.drawShapes = true;
/*     */       }
/*     */     } 
/*     */     
/*  81 */     if (paramCTFontFile.isEmbeddedFont()) {
/*  82 */       long l = paramCTFontFile.getCGFontRef();
/*  83 */       if (l != 0L) {
/*  84 */         this.fontRef = OS.CTFontCreateWithGraphicsFont(l, paramFloat, this.matrix, 0L);
/*     */       }
/*     */     } else {
/*     */       
/*  88 */       long l = OS.CFStringCreate(paramCTFontFile.getPSName());
/*  89 */       if (l != 0L) {
/*  90 */         this.fontRef = OS.CTFontCreateWithName(l, paramFloat, this.matrix);
/*  91 */         OS.CFRelease(l);
/*     */       } 
/*     */     } 
/*  94 */     if (this.fontRef == 0L && 
/*  95 */       PrismFontFactory.debugFonts) {
/*  96 */       System.err.println("Failed to create CTFont for " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   long getFontRef() {
/* 102 */     return this.fontRef;
/*     */   }
/*     */   
/*     */   protected DisposerRecord createDisposer(FontStrikeDesc paramFontStrikeDesc) {
/* 106 */     CTFontFile cTFontFile = getFontResource();
/* 107 */     return new CTStrikeDisposer(cTFontFile, paramFontStrikeDesc, this.fontRef);
/*     */   }
/*     */   
/*     */   protected Glyph createGlyph(int paramInt) {
/* 111 */     return new CTGlyph(this, paramInt, this.drawShapes);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQuantizedPosition(Point2D paramPoint2D) {
/* 116 */     if (SUBPIXEL && this.matrix == null) {
/*     */ 
/*     */ 
/*     */       
/* 120 */       if (getSize() < 12.0F) {
/* 121 */         float f = paramPoint2D.x;
/* 122 */         paramPoint2D.x = (int)paramPoint2D.x;
/* 123 */         f -= paramPoint2D.x;
/* 124 */         paramPoint2D.y = Math.round(paramPoint2D.y);
/* 125 */         if (f >= 0.75F) return 3; 
/* 126 */         if (f >= 0.5F) return 2; 
/* 127 */         if (f >= 0.25F) return 1; 
/* 128 */         return 0;
/*     */       } 
/* 130 */       if (getAAMode() == 0) {
/* 131 */         if (getSize() < 18.0F) {
/* 132 */           float f = paramPoint2D.x;
/* 133 */           paramPoint2D.x = (int)paramPoint2D.x;
/* 134 */           f -= paramPoint2D.x;
/* 135 */           paramPoint2D.y = Math.round(paramPoint2D.y);
/* 136 */           if (f >= 0.66F) return 2; 
/* 137 */           if (f >= 0.33F) return 1; 
/* 138 */           return 0;
/*     */         } 
/* 140 */         if (getSize() < 34.0F) {
/* 141 */           float f = paramPoint2D.x;
/* 142 */           paramPoint2D.x = (int)paramPoint2D.x;
/* 143 */           f -= paramPoint2D.x;
/* 144 */           paramPoint2D.y = Math.round(paramPoint2D.y);
/* 145 */           if (f >= 0.5F) return 1; 
/*     */         } 
/* 147 */         return 0;
/*     */       } 
/*     */     } 
/* 150 */     return super.getQuantizedPosition(paramPoint2D);
/*     */   }
/*     */   
/*     */   float getSubPixelPosition(int paramInt) {
/* 154 */     if (paramInt == 0) return 0.0F; 
/* 155 */     float f = getSize();
/* 156 */     if (f < 12.0F) {
/* 157 */       if (paramInt == 3) return 0.75F; 
/* 158 */       if (paramInt == 2) return 0.5F; 
/* 159 */       if (paramInt == 1) return 0.25F; 
/* 160 */       return 0.0F;
/*     */     } 
/* 162 */     if (getAAMode() == 1) return 0.0F; 
/* 163 */     if (f < 18.0F) {
/* 164 */       if (paramInt == 2) return 0.66F; 
/* 165 */       if (paramInt == 1) return 0.33F; 
/* 166 */       return 0.0F;
/*     */     } 
/* 168 */     if (f < 34.0F && 
/* 169 */       paramInt == 1) return 0.5F;
/*     */     
/* 171 */     return 0.0F;
/*     */   }
/*     */   
/*     */   boolean isSubPixelGlyph() {
/* 175 */     return (SUBPIXEL && this.matrix == null);
/*     */   }
/*     */   
/*     */   protected Path2D createGlyphOutline(int paramInt) {
/* 179 */     CTFontFile cTFontFile = getFontResource();
/* 180 */     return cTFontFile.getGlyphOutline(paramInt, getSize());
/*     */   }
/*     */   
/*     */   CGRect getBBox(int paramInt) {
/* 184 */     CTFontFile cTFontFile = getFontResource();
/* 185 */     return cTFontFile.getBBox(paramInt, getSize());
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\CTFontStrike.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */