/*     */ package com.sun.webkit;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.io.File;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.InvalidPathException;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class FileSystem
/*     */ {
/*     */   private static final int TYPE_UNKNOWN = 0;
/*     */   private static final int TYPE_FILE = 1;
/*     */   private static final int TYPE_DIRECTORY = 2;
/*  44 */   private static final PlatformLogger logger = PlatformLogger.getLogger(FileSystem.class.getName());
/*     */ 
/*     */   
/*     */   private FileSystem() {
/*  48 */     throw new AssertionError();
/*     */   }
/*     */   
/*     */   private static boolean fwkFileExists(String paramString) {
/*  52 */     return (new File(paramString)).exists();
/*     */   }
/*     */   
/*     */   private static long fwkGetFileSize(String paramString) {
/*     */     try {
/*  57 */       File file = new File(paramString);
/*  58 */       if (file.exists()) {
/*  59 */         return file.length();
/*     */       }
/*  61 */     } catch (SecurityException securityException) {
/*  62 */       logger.fine(String.format("Error determining size of file [%s]", new Object[] { paramString }), securityException);
/*     */     } 
/*  64 */     return -1L;
/*     */   }
/*     */   
/*     */   private static boolean fwkGetFileMetadata(String paramString, long[] paramArrayOflong) {
/*     */     try {
/*  69 */       File file = new File(paramString);
/*  70 */       if (file.exists()) {
/*  71 */         paramArrayOflong[0] = file.lastModified();
/*  72 */         paramArrayOflong[1] = file.length();
/*  73 */         if (file.isDirectory()) {
/*  74 */           paramArrayOflong[2] = 2L;
/*  75 */         } else if (file.isFile()) {
/*  76 */           paramArrayOflong[2] = 1L;
/*     */         } else {
/*  78 */           paramArrayOflong[2] = 0L;
/*     */         } 
/*  80 */         return true;
/*     */       } 
/*  82 */     } catch (SecurityException securityException) {
/*  83 */       logger.fine(String.format("Error determining Metadata for file [%s]", new Object[] { paramString }), securityException);
/*     */     } 
/*  85 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String fwkPathByAppendingComponent(String paramString1, String paramString2) {
/*  91 */     return (new File(paramString1, paramString2)).getPath();
/*     */   }
/*     */   
/*     */   private static boolean fwkMakeAllDirectories(String paramString) {
/*     */     try {
/*  96 */       Files.createDirectories(Paths.get(paramString, new String[0]), (FileAttribute<?>[])new FileAttribute[0]);
/*  97 */       return true;
/*  98 */     } catch (InvalidPathException|java.io.IOException invalidPathException) {
/*  99 */       logger.fine(String.format("Error creating directory [%s]", new Object[] { paramString }), invalidPathException);
/* 100 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String fwkPathGetFileName(String paramString) {
/* 105 */     return (new File(paramString)).getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\FileSystem.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */