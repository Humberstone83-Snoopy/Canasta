/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ import javafx.css.PseudoClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PseudoClassImpl
/*    */   extends PseudoClass
/*    */ {
/*    */   private final String pseudoClassName;
/*    */   private final int index;
/*    */   
/*    */   PseudoClassImpl(String paramString, int paramInt) {
/* 37 */     this.pseudoClassName = paramString;
/* 38 */     this.index = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPseudoClassName() {
/* 44 */     return this.pseudoClassName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return this.pseudoClassName;
/*    */   }
/*    */   
/*    */   public int getIndex() {
/* 53 */     return this.index;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\PseudoClassImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */