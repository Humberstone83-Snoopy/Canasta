package com.sun.javafx.collections;

public interface IntegerArraySyncer {
  int[] syncTo(int[] paramArrayOfint1, int[] paramArrayOfint2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\collections\IntegerArraySyncer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */