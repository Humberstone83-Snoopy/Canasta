package javafx.beans.binding;

public interface NumberBinding extends Binding<Number>, NumberExpression {}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\NumberBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */