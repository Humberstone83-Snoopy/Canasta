package com.sun.webkit.graphics;

public abstract class WCPageBackBuffer extends Ref {
  public abstract WCGraphicsContext createGraphics();
  
  public abstract void disposeGraphics(WCGraphicsContext paramWCGraphicsContext);
  
  public abstract void flush(WCGraphicsContext paramWCGraphicsContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  protected abstract void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public abstract boolean validate(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCPageBackBuffer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */