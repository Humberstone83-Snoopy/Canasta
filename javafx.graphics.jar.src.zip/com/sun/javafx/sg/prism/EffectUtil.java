/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Image;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.paint.Color;
/*     */ import com.sun.scenario.effect.Color4f;
/*     */ import com.sun.scenario.effect.DropShadow;
/*     */ import com.sun.scenario.effect.Effect;
/*     */ import com.sun.scenario.effect.InnerShadow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EffectUtil
/*     */ {
/*     */   private static final int TEX_SIZE = 256;
/*     */   private static Texture itex;
/*     */   private static Texture dtex;
/*     */   
/*     */   static boolean renderEffectForRectangularNode(NGNode paramNGNode, Graphics paramGraphics, Effect paramEffect, float paramFloat1, boolean paramBoolean, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/*  60 */     if (!paramGraphics.getTransformNoClone().is2D() && paramGraphics.isDepthBuffer() && paramGraphics.isDepthTest())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  92 */       return false;
/*     */     }
/*  94 */     if (paramEffect instanceof InnerShadow && !paramBoolean) {
/*     */ 
/*     */       
/*  97 */       InnerShadow innerShadow = (InnerShadow)paramEffect;
/*  98 */       float f = innerShadow.getRadius();
/*  99 */       if (f > 0.0F && f < paramFloat4 / 2.0F && f < paramFloat5 / 2.0F && innerShadow
/*     */ 
/*     */         
/* 102 */         .getChoke() == 0.0F && innerShadow
/* 103 */         .getShadowSourceInput() == null && innerShadow
/* 104 */         .getContentInput() == null) {
/*     */         
/* 106 */         paramNGNode.renderContent(paramGraphics);
/* 107 */         renderRectInnerShadow(paramGraphics, innerShadow, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/* 108 */         return true;
/*     */       } 
/* 110 */     } else if (paramEffect instanceof DropShadow) {
/* 111 */       DropShadow dropShadow = (DropShadow)paramEffect;
/* 112 */       float f = dropShadow.getRadius();
/* 113 */       if (f > 0.0F && f < paramFloat4 / 2.0F && f < paramFloat5 / 2.0F && dropShadow
/*     */ 
/*     */         
/* 116 */         .getSpread() == 0.0F && dropShadow
/* 117 */         .getShadowSourceInput() == null && dropShadow
/* 118 */         .getContentInput() == null) {
/*     */         
/* 120 */         renderRectDropShadow(paramGraphics, dropShadow, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5);
/* 121 */         paramNGNode.renderContent(paramGraphics);
/* 122 */         return true;
/*     */       } 
/*     */     } 
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void renderRectInnerShadow(Graphics paramGraphics, InnerShadow paramInnerShadow, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/* 131 */     if (itex == null) {
/* 132 */       byte[] arrayOfByte = new byte[65536];
/* 133 */       fillGaussian(arrayOfByte, 256, 128.0F, paramInnerShadow.getChoke(), true);
/* 134 */       Image image = Image.fromByteAlphaData(arrayOfByte, 256, 256);
/* 135 */       itex = paramGraphics.getResourceFactory().createTexture(image, Texture.Usage.STATIC, Texture.WrapMode.CLAMP_TO_EDGE);
/*     */ 
/*     */ 
/*     */       
/* 139 */       assert itex.getWrapMode() == Texture.WrapMode.CLAMP_TO_EDGE;
/* 140 */       itex.contentsUseful();
/* 141 */       itex.makePermanent();
/*     */     } 
/* 143 */     float f1 = paramInnerShadow.getRadius();
/* 144 */     int i = itex.getPhysicalWidth();
/* 145 */     int j = itex.getContentX();
/* 146 */     int k = j + itex.getContentWidth();
/* 147 */     float f2 = (j + 0.5F) / i;
/* 148 */     float f3 = (k - 0.5F) / i;
/* 149 */     float f4 = paramFloat2;
/* 150 */     float f5 = paramFloat3;
/* 151 */     float f6 = paramFloat2 + paramFloat4;
/* 152 */     float f7 = paramFloat3 + paramFloat5;
/* 153 */     float f8 = f4 + paramInnerShadow.getOffsetX();
/* 154 */     float f9 = f5 + paramInnerShadow.getOffsetY();
/* 155 */     float f10 = f8 + paramFloat4;
/* 156 */     float f11 = f9 + paramFloat5;
/* 157 */     paramGraphics.setPaint(toPrismColor(paramInnerShadow.getColor(), paramFloat1));
/*     */     
/* 159 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f4, f5, f6, f9 - f1, f2, f2, f2, f2);
/*     */ 
/*     */ 
/*     */     
/* 163 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f8 - f1, f9 - f1, f8 + f1, f9 + f1, f2, f2, f3, f3);
/*     */ 
/*     */ 
/*     */     
/* 167 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f8 + f1, f9 - f1, f10 - f1, f9 + f1, f3, f2, f3, f3);
/*     */ 
/*     */ 
/*     */     
/* 171 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f10 - f1, f9 - f1, f10 + f1, f9 + f1, f3, f2, f2, f3);
/*     */ 
/*     */ 
/*     */     
/* 175 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f4, f9 - f1, f8 - f1, f11 + f1, f2, f2, f2, f2);
/*     */ 
/*     */ 
/*     */     
/* 179 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f8 - f1, f9 + f1, f8 + f1, f11 - f1, f2, f3, f3, f3);
/*     */ 
/*     */ 
/*     */     
/* 183 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f10 - f1, f9 + f1, f10 + f1, f11 - f1, f3, f3, f2, f3);
/*     */ 
/*     */ 
/*     */     
/* 187 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f10 + f1, f9 - f1, f6, f11 + f1, f2, f2, f2, f2);
/*     */ 
/*     */ 
/*     */     
/* 191 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f8 - f1, f11 - f1, f8 + f1, f11 + f1, f2, f3, f3, f2);
/*     */ 
/*     */ 
/*     */     
/* 195 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f8 + f1, f11 - f1, f10 - f1, f11 + f1, f3, f3, f3, f2);
/*     */ 
/*     */ 
/*     */     
/* 199 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f10 - f1, f11 - f1, f10 + f1, f11 + f1, f3, f3, f2, f2);
/*     */ 
/*     */ 
/*     */     
/* 203 */     drawClippedTexture(paramGraphics, itex, f4, f5, f6, f7, f4, f11 + f1, f6, f7, f2, f2, f2, f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawClippedTexture(Graphics paramGraphics, Texture paramTexture, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, float paramFloat11, float paramFloat12) {
/* 214 */     if (paramFloat5 >= paramFloat7 || paramFloat6 >= paramFloat8 || paramFloat1 >= paramFloat3 || paramFloat2 >= paramFloat4)
/* 215 */       return;  if (paramFloat7 > paramFloat1 && paramFloat5 < paramFloat3) {
/* 216 */       if (paramFloat5 < paramFloat1) {
/* 217 */         paramFloat9 += (paramFloat11 - paramFloat9) * (paramFloat1 - paramFloat5) / (paramFloat7 - paramFloat5);
/* 218 */         paramFloat5 = paramFloat1;
/*     */       } 
/* 220 */       if (paramFloat7 > paramFloat3) {
/* 221 */         paramFloat11 -= (paramFloat11 - paramFloat9) * (paramFloat7 - paramFloat3) / (paramFloat7 - paramFloat5);
/* 222 */         paramFloat7 = paramFloat3;
/*     */       } 
/*     */     } else {
/*     */       return;
/*     */     } 
/* 227 */     if (paramFloat8 > paramFloat2 && paramFloat6 < paramFloat4) {
/* 228 */       if (paramFloat6 < paramFloat2) {
/* 229 */         paramFloat10 += (paramFloat12 - paramFloat10) * (paramFloat2 - paramFloat6) / (paramFloat8 - paramFloat6);
/* 230 */         paramFloat6 = paramFloat2;
/*     */       } 
/* 232 */       if (paramFloat8 > paramFloat4) {
/* 233 */         paramFloat12 -= (paramFloat12 - paramFloat10) * (paramFloat8 - paramFloat4) / (paramFloat8 - paramFloat6);
/* 234 */         paramFloat8 = paramFloat4;
/*     */       } 
/*     */     } else {
/*     */       return;
/*     */     } 
/* 239 */     paramGraphics.drawTextureRaw(paramTexture, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramFloat11, paramFloat12);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void renderRectDropShadow(Graphics paramGraphics, DropShadow paramDropShadow, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/* 245 */     if (dtex == null) {
/* 246 */       byte[] arrayOfByte = new byte[65536];
/* 247 */       fillGaussian(arrayOfByte, 256, 128.0F, paramDropShadow.getSpread(), false);
/*     */       
/* 249 */       Image image = Image.fromByteAlphaData(arrayOfByte, 256, 256);
/* 250 */       dtex = paramGraphics.getResourceFactory().createTexture(image, Texture.Usage.STATIC, Texture.WrapMode.CLAMP_TO_EDGE);
/*     */ 
/*     */ 
/*     */       
/* 254 */       assert dtex.getWrapMode() == Texture.WrapMode.CLAMP_TO_EDGE;
/* 255 */       dtex.contentsUseful();
/* 256 */       dtex.makePermanent();
/*     */     } 
/* 258 */     float f1 = paramDropShadow.getRadius();
/* 259 */     int i = dtex.getPhysicalWidth();
/* 260 */     int j = dtex.getContentX();
/* 261 */     int k = j + dtex.getContentWidth();
/* 262 */     float f2 = (j + 0.5F) / i;
/* 263 */     float f3 = (k - 0.5F) / i;
/* 264 */     float f4 = paramFloat2 + paramDropShadow.getOffsetX();
/* 265 */     float f5 = paramFloat3 + paramDropShadow.getOffsetY();
/* 266 */     float f6 = f4 + paramFloat4;
/* 267 */     float f7 = f5 + paramFloat5;
/* 268 */     paramGraphics.setPaint(toPrismColor(paramDropShadow.getColor(), paramFloat1));
/* 269 */     paramGraphics.drawTextureRaw(dtex, f4 - f1, f5 - f1, f4 + f1, f5 + f1, f2, f2, f3, f3);
/*     */ 
/*     */     
/* 272 */     paramGraphics.drawTextureRaw(dtex, f6 - f1, f5 - f1, f6 + f1, f5 + f1, f3, f2, f2, f3);
/*     */ 
/*     */     
/* 275 */     paramGraphics.drawTextureRaw(dtex, f6 - f1, f7 - f1, f6 + f1, f7 + f1, f3, f3, f2, f2);
/*     */ 
/*     */     
/* 278 */     paramGraphics.drawTextureRaw(dtex, f4 - f1, f7 - f1, f4 + f1, f7 + f1, f2, f3, f3, f2);
/*     */ 
/*     */     
/* 281 */     paramGraphics.drawTextureRaw(dtex, f4 + f1, f5 + f1, f6 - f1, f7 - f1, f3, f3, f3, f3);
/*     */ 
/*     */     
/* 284 */     paramGraphics.drawTextureRaw(dtex, f4 - f1, f5 + f1, f4 + f1, f7 - f1, f2, f3, f3, f3);
/*     */ 
/*     */     
/* 287 */     paramGraphics.drawTextureRaw(dtex, f6 - f1, f5 + f1, f6 + f1, f7 - f1, f3, f3, f2, f3);
/*     */ 
/*     */     
/* 290 */     paramGraphics.drawTextureRaw(dtex, f4 + f1, f5 - f1, f6 - f1, f5 + f1, f3, f2, f3, f3);
/*     */ 
/*     */     
/* 293 */     paramGraphics.drawTextureRaw(dtex, f4 + f1, f7 - f1, f6 - f1, f7 + f1, f3, f3, f3, f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fillGaussian(byte[] paramArrayOfbyte, int paramInt, float paramFloat1, float paramFloat2, boolean paramBoolean) {
/* 303 */     float f1 = paramFloat1 / 3.0F;
/* 304 */     float f2 = 2.0F * f1 * f1;
/* 305 */     if (f2 < Float.MIN_VALUE)
/*     */     {
/* 307 */       f2 = Float.MIN_VALUE;
/*     */     }
/*     */     
/* 310 */     float[] arrayOfFloat = new float[paramInt];
/* 311 */     int i = (paramInt + 1) / 2;
/* 312 */     float f3 = 0.0F; byte b;
/* 313 */     for (b = 0; b < arrayOfFloat.length; b++) {
/* 314 */       int j = i - b;
/* 315 */       f3 += (float)Math.exp((-(j * j) / f2));
/* 316 */       arrayOfFloat[b] = f3;
/*     */     } 
/*     */     
/* 319 */     for (b = 0; b < arrayOfFloat.length; b++) {
/* 320 */       arrayOfFloat[b] = arrayOfFloat[b] / f3;
/*     */     }
/* 322 */     for (b = 0; b < paramInt; b++) {
/* 323 */       for (byte b1 = 0; b1 < paramInt; b1++) {
/* 324 */         float f = arrayOfFloat[b] * arrayOfFloat[b1];
/* 325 */         if (paramBoolean)
/*     */         {
/* 327 */           f = 1.0F - f;
/*     */         }
/* 329 */         int j = (int)(f * 255.0F);
/*     */         
/* 331 */         if (j < 0) { j = 0; } else if (j > 255) { j = 255; }
/* 332 */          paramArrayOfbyte[b * paramInt + b1] = (byte)j;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Color toPrismColor(Color4f paramColor4f, float paramFloat) {
/* 338 */     float f1 = paramColor4f.getRed();
/* 339 */     float f2 = paramColor4f.getGreen();
/* 340 */     float f3 = paramColor4f.getBlue();
/* 341 */     float f4 = paramColor4f.getAlpha() * paramFloat;
/* 342 */     return new Color(f1, f2, f3, f4);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\EffectUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */