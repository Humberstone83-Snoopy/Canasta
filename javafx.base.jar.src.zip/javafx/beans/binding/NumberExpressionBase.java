/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.StringFormatter;
/*     */ import java.util.Locale;
/*     */ import javafx.beans.value.ObservableDoubleValue;
/*     */ import javafx.beans.value.ObservableFloatValue;
/*     */ import javafx.beans.value.ObservableIntegerValue;
/*     */ import javafx.beans.value.ObservableLongValue;
/*     */ import javafx.beans.value.ObservableNumberValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NumberExpressionBase
/*     */   implements NumberExpression
/*     */ {
/*     */   public static <S extends Number> NumberExpressionBase numberExpression(ObservableNumberValue paramObservableNumberValue) {
/*  70 */     if (paramObservableNumberValue == null) {
/*  71 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     NumberExpressionBase numberExpressionBase = (paramObservableNumberValue instanceof NumberExpressionBase) ? (NumberExpressionBase)paramObservableNumberValue : ((paramObservableNumberValue instanceof ObservableIntegerValue) ? IntegerExpression.integerExpression((ObservableIntegerValue)paramObservableNumberValue) : ((paramObservableNumberValue instanceof ObservableDoubleValue) ? DoubleExpression.doubleExpression((ObservableDoubleValue)paramObservableNumberValue) : ((paramObservableNumberValue instanceof ObservableFloatValue) ? FloatExpression.floatExpression((ObservableFloatValue)paramObservableNumberValue) : ((paramObservableNumberValue instanceof ObservableLongValue) ? LongExpression.longExpression((ObservableLongValue)paramObservableNumberValue) : null))));
/*  83 */     if (numberExpressionBase != null) {
/*  84 */       return numberExpressionBase;
/*     */     }
/*  86 */     throw new IllegalArgumentException("Unsupported Type");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberBinding add(ObservableNumberValue paramObservableNumberValue) {
/*  92 */     return Bindings.add(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumberBinding subtract(ObservableNumberValue paramObservableNumberValue) {
/*  97 */     return Bindings.subtract(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumberBinding multiply(ObservableNumberValue paramObservableNumberValue) {
/* 102 */     return Bindings.multiply(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public NumberBinding divide(ObservableNumberValue paramObservableNumberValue) {
/* 107 */     return Bindings.divide(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(ObservableNumberValue paramObservableNumberValue) {
/* 115 */     return Bindings.equal(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 121 */     return Bindings.equal(this, paramObservableNumberValue, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(double paramDouble1, double paramDouble2) {
/* 126 */     return Bindings.equal(this, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(float paramFloat, double paramDouble) {
/* 131 */     return Bindings.equal(this, paramFloat, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(long paramLong) {
/* 136 */     return Bindings.equal(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(long paramLong, double paramDouble) {
/* 141 */     return Bindings.equal(this, paramLong, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(int paramInt) {
/* 146 */     return Bindings.equal(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(int paramInt, double paramDouble) {
/* 151 */     return Bindings.equal(this, paramInt, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(ObservableNumberValue paramObservableNumberValue) {
/* 159 */     return Bindings.notEqual(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(ObservableNumberValue paramObservableNumberValue, double paramDouble) {
/* 165 */     return Bindings.notEqual(this, paramObservableNumberValue, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(double paramDouble1, double paramDouble2) {
/* 170 */     return Bindings.notEqual(this, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(float paramFloat, double paramDouble) {
/* 175 */     return Bindings.notEqual(this, paramFloat, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(long paramLong) {
/* 180 */     return Bindings.notEqual(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(long paramLong, double paramDouble) {
/* 185 */     return Bindings.notEqual(this, paramLong, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(int paramInt) {
/* 190 */     return Bindings.notEqual(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(int paramInt, double paramDouble) {
/* 195 */     return Bindings.notEqual(this, paramInt, paramDouble);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThan(ObservableNumberValue paramObservableNumberValue) {
/* 203 */     return Bindings.greaterThan(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThan(double paramDouble) {
/* 208 */     return Bindings.greaterThan(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThan(float paramFloat) {
/* 213 */     return Bindings.greaterThan(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThan(long paramLong) {
/* 218 */     return Bindings.greaterThan(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThan(int paramInt) {
/* 223 */     return Bindings.greaterThan(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThan(ObservableNumberValue paramObservableNumberValue) {
/* 231 */     return Bindings.lessThan(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThan(double paramDouble) {
/* 236 */     return Bindings.lessThan(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThan(float paramFloat) {
/* 241 */     return Bindings.lessThan(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThan(long paramLong) {
/* 246 */     return Bindings.lessThan(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThan(int paramInt) {
/* 251 */     return Bindings.lessThan(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThanOrEqualTo(ObservableNumberValue paramObservableNumberValue) {
/* 259 */     return Bindings.greaterThanOrEqual(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThanOrEqualTo(double paramDouble) {
/* 264 */     return Bindings.greaterThanOrEqual(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThanOrEqualTo(float paramFloat) {
/* 269 */     return Bindings.greaterThanOrEqual(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThanOrEqualTo(long paramLong) {
/* 274 */     return Bindings.greaterThanOrEqual(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding greaterThanOrEqualTo(int paramInt) {
/* 279 */     return Bindings.greaterThanOrEqual(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThanOrEqualTo(ObservableNumberValue paramObservableNumberValue) {
/* 287 */     return Bindings.lessThanOrEqual(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThanOrEqualTo(double paramDouble) {
/* 292 */     return Bindings.lessThanOrEqual(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThanOrEqualTo(float paramFloat) {
/* 297 */     return Bindings.lessThanOrEqual(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThanOrEqualTo(long paramLong) {
/* 302 */     return Bindings.lessThanOrEqual(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public BooleanBinding lessThanOrEqualTo(int paramInt) {
/* 307 */     return Bindings.lessThanOrEqual(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBinding asString() {
/* 315 */     return (StringBinding)StringFormatter.convert(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBinding asString(String paramString) {
/* 320 */     return (StringBinding)Bindings.format(paramString, new Object[] { this });
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBinding asString(Locale paramLocale, String paramString) {
/* 325 */     return (StringBinding)Bindings.format(paramLocale, paramString, new Object[] { this });
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\NumberExpressionBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */