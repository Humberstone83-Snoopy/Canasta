package com.sun.javafx.font.directwrite;

class DWRITE_SCRIPT_ANALYSIS {
  short script;
  
  int shapes;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWRITE_SCRIPT_ANALYSIS.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */