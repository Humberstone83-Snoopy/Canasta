/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.IntPixelAccessor;
/*     */ import com.sun.javafx.image.IntPixelGetter;
/*     */ import com.sun.javafx.image.IntPixelSetter;
/*     */ import com.sun.javafx.image.IntToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelGetter;
/*     */ import com.sun.javafx.image.PixelSetter;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseIntToIntConverter
/*     */   implements IntToIntPixelConverter
/*     */ {
/*     */   protected final IntPixelGetter getter;
/*     */   protected final IntPixelSetter setter;
/*     */   
/*     */   public BaseIntToIntConverter(IntPixelGetter paramIntPixelGetter, IntPixelSetter paramIntPixelSetter) {
/*  41 */     this.getter = paramIntPixelGetter;
/*  42 */     this.setter = paramIntPixelSetter;
/*     */   }
/*     */ 
/*     */   
/*     */   public final IntPixelGetter getGetter() {
/*  47 */     return this.getter;
/*     */   }
/*     */ 
/*     */   
/*     */   public final IntPixelSetter getSetter() {
/*  52 */     return this.setter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(int[] paramArrayOfint1, int paramInt1, int paramInt2, int[] paramArrayOfint2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  68 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  69 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5) {
/*     */ 
/*     */       
/*  72 */       paramInt5 *= paramInt6;
/*  73 */       paramInt6 = 1;
/*     */     } 
/*  75 */     doConvert(paramArrayOfint1, paramInt1, paramInt2, paramArrayOfint2, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(IntBuffer paramIntBuffer1, int paramInt1, int paramInt2, IntBuffer paramIntBuffer2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  85 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  86 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5) {
/*     */ 
/*     */       
/*  89 */       paramInt5 *= paramInt6;
/*  90 */       paramInt6 = 1;
/*     */     } 
/*  92 */     if (paramIntBuffer1.hasArray() && paramIntBuffer2.hasArray()) {
/*  93 */       paramInt1 += paramIntBuffer1.arrayOffset();
/*  94 */       paramInt3 += paramIntBuffer2.arrayOffset();
/*  95 */       doConvert(paramIntBuffer1.array(), paramInt1, paramInt2, paramIntBuffer2
/*  96 */           .array(), paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } else {
/*     */       
/*  99 */       doConvert(paramIntBuffer1, paramInt1, paramInt2, paramIntBuffer2, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 110 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 111 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5) {
/*     */ 
/*     */       
/* 114 */       paramInt5 *= paramInt6;
/* 115 */       paramInt6 = 1;
/*     */     } 
/* 117 */     if (paramIntBuffer.hasArray()) {
/* 118 */       int[] arrayOfInt = paramIntBuffer.array();
/* 119 */       paramInt1 += paramIntBuffer.arrayOffset();
/* 120 */       doConvert(arrayOfInt, paramInt1, paramInt2, paramArrayOfint, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 124 */       IntBuffer intBuffer = IntBuffer.wrap(paramArrayOfint);
/* 125 */       doConvert(paramIntBuffer, paramInt1, paramInt2, intBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 136 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 137 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5) {
/*     */ 
/*     */       
/* 140 */       paramInt5 *= paramInt6;
/* 141 */       paramInt6 = 1;
/*     */     } 
/* 143 */     if (paramIntBuffer.hasArray()) {
/* 144 */       int[] arrayOfInt = paramIntBuffer.array();
/* 145 */       paramInt3 += paramIntBuffer.arrayOffset();
/* 146 */       doConvert(paramArrayOfint, paramInt1, paramInt2, arrayOfInt, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 150 */       IntBuffer intBuffer = IntBuffer.wrap(paramArrayOfint);
/* 151 */       doConvert(intBuffer, paramInt1, paramInt2, paramIntBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */   abstract void doConvert(int[] paramArrayOfint1, int paramInt1, int paramInt2, int[] paramArrayOfint2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */   abstract void doConvert(IntBuffer paramIntBuffer1, int paramInt1, int paramInt2, IntBuffer paramIntBuffer2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   static IntToIntPixelConverter create(IntPixelAccessor paramIntPixelAccessor) {
/* 158 */     return new IntAnyToSameConverter(paramIntPixelAccessor);
/*     */   }
/*     */   
/*     */   static class IntAnyToSameConverter extends BaseIntToIntConverter {
/*     */     IntAnyToSameConverter(IntPixelAccessor param1IntPixelAccessor) {
/* 163 */       super(param1IntPixelAccessor, param1IntPixelAccessor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(int[] param1ArrayOfint1, int param1Int1, int param1Int2, int[] param1ArrayOfint2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 171 */       while (--param1Int6 >= 0) {
/* 172 */         System.arraycopy(param1ArrayOfint1, param1Int1, param1ArrayOfint2, param1Int3, param1Int5);
/* 173 */         param1Int1 += param1Int2;
/* 174 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(IntBuffer param1IntBuffer1, int param1Int1, int param1Int2, IntBuffer param1IntBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 183 */       int i = param1IntBuffer1.limit();
/* 184 */       int j = param1IntBuffer1.position();
/* 185 */       int k = param1IntBuffer2.position();
/*     */       try {
/* 187 */         while (--param1Int6 >= 0) {
/* 188 */           int m = param1Int1 + param1Int5;
/* 189 */           if (m > i) {
/* 190 */             throw new IndexOutOfBoundsException("" + i);
/*     */           }
/* 192 */           param1IntBuffer1.limit(m);
/* 193 */           param1IntBuffer1.position(param1Int1);
/* 194 */           param1IntBuffer2.position(param1Int3);
/* 195 */           param1IntBuffer2.put(param1IntBuffer1);
/* 196 */           param1Int1 += param1Int2;
/* 197 */           param1Int3 += param1Int4;
/*     */         } 
/*     */       } finally {
/* 200 */         param1IntBuffer1.limit(i);
/* 201 */         param1IntBuffer1.position(j);
/* 202 */         param1IntBuffer2.position(k);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\BaseIntToIntConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */