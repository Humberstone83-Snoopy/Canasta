/*     */ package javafx.beans.property;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.SetExpression;
/*     */ import javafx.collections.ObservableSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlySetProperty<E>
/*     */   extends SetExpression<E>
/*     */   implements ReadOnlyProperty<ObservableSet<E>>
/*     */ {
/*     */   public void bindContentBidirectional(ObservableSet<E> paramObservableSet) {
/*  67 */     Bindings.bindContentBidirectional(this, paramObservableSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContentBidirectional(Object paramObject) {
/*  79 */     Bindings.unbindContentBidirectional(this, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindContent(ObservableSet<E> paramObservableSet) {
/*  95 */     Bindings.bindContent(this, paramObservableSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContent(Object paramObject) {
/* 107 */     Bindings.unbindContent(this, paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 112 */     if (paramObject == this) {
/* 113 */       return true;
/*     */     }
/* 115 */     if (!(paramObject instanceof Set))
/* 116 */       return false; 
/* 117 */     Set<?> set = (Set)paramObject;
/* 118 */     if (set.size() != size())
/* 119 */       return false; 
/*     */     try {
/* 121 */       return containsAll(set);
/* 122 */     } catch (ClassCastException classCastException) {
/* 123 */       return false;
/* 124 */     } catch (NullPointerException nullPointerException) {
/* 125 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 135 */     int i = 0;
/* 136 */     for (E e : this) {
/* 137 */       if (e != null)
/* 138 */         i += e.hashCode(); 
/*     */     } 
/* 140 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     Object object = getBean();
/* 150 */     String str = getName();
/* 151 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlySetProperty [");
/*     */     
/* 153 */     if (object != null) {
/* 154 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 156 */     if (str != null && !str.equals("")) {
/* 157 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 159 */     stringBuilder.append("value: ").append(get()).append("]");
/* 160 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlySetProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */