/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IUnknown
/*    */ {
/*    */   long ptr;
/*    */   
/*    */   IUnknown(long paramLong) {
/* 32 */     this.ptr = paramLong;
/*    */   }
/*    */   
/*    */   int AddRef() {
/* 36 */     return OS.AddRef(this.ptr);
/*    */   }
/*    */   
/*    */   int Release() {
/* 40 */     int i = 0;
/* 41 */     if (this.ptr != 0L) {
/* 42 */       i = OS.Release(this.ptr);
/* 43 */       this.ptr = 0L;
/*    */     } 
/* 45 */     return i;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IUnknown.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */