/*     */ package com.sun.webkit.plugin;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.TreeMap;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PluginManager
/*     */ {
/*  40 */   private static final PlatformLogger log = PlatformLogger.getLogger("com.sun.browser.plugin.PluginManager");
/*     */ 
/*     */   
/*  43 */   private static final ServiceLoader<PluginHandler> pHandlers = ServiceLoader.load(PluginHandler.class);
/*     */   
/*  45 */   private static final TreeMap<String, PluginHandler> hndMap = new TreeMap<>();
/*     */ 
/*     */   
/*     */   private static PluginHandler[] hndArray;
/*     */   
/*  50 */   private static final HashSet<String> disabledPluginHandlers = new HashSet<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updatePluginHandlers() {
/*  55 */     log.fine("Update plugin handlers");
/*     */     
/*  57 */     hndMap.clear();
/*     */     
/*  59 */     Iterator<PluginHandler> iterator = pHandlers.iterator();
/*  60 */     while (iterator.hasNext()) {
/*  61 */       PluginHandler pluginHandler = iterator.next();
/*  62 */       if (pluginHandler.isSupportedPlatform() && !isDisabledPlugin(pluginHandler)) {
/*     */         
/*  64 */         String[] arrayOfString = pluginHandler.supportedMIMETypes();
/*  65 */         for (String str : arrayOfString) {
/*  66 */           hndMap.put(str, pluginHandler);
/*  67 */           log.fine(str);
/*     */         } 
/*     */       } 
/*     */     } 
/*  71 */     Collection<PluginHandler> collection = hndMap.values();
/*  72 */     hndArray = collection.<PluginHandler>toArray(new PluginHandler[collection.size()]);
/*     */   }
/*     */   
/*     */   static {
/*  76 */     if ("false".equalsIgnoreCase(
/*  77 */         System.getProperty("com.sun.browser.plugin")))
/*     */     {
/*  79 */       for (PluginHandler pluginHandler : getAvailablePlugins()) {
/*  80 */         disabledPluginHandlers.add(pluginHandler.getClass().getCanonicalName());
/*     */       }
/*     */     }
/*     */     
/*  84 */     updatePluginHandlers();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Plugin createPlugin(URL paramURL, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*     */     try {
/*  91 */       PluginHandler pluginHandler = hndMap.get(paramString);
/*  92 */       if (pluginHandler == null) {
/*  93 */         return new DefaultPlugin(paramURL, paramString, paramArrayOfString1, paramArrayOfString2);
/*     */       }
/*  95 */       Plugin plugin = pluginHandler.createPlugin(paramURL, paramString, paramArrayOfString1, paramArrayOfString2);
/*  96 */       if (plugin == null) {
/*  97 */         return new DefaultPlugin(paramURL, paramString, paramArrayOfString1, paramArrayOfString2);
/*     */       }
/*  99 */       return plugin;
/*     */     
/*     */     }
/* 102 */     catch (Throwable throwable) {
/* 103 */       log.fine("Cannot create plugin", throwable);
/* 104 */       return new DefaultPlugin(paramURL, paramString, paramArrayOfString1, paramArrayOfString2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static List<PluginHandler> getAvailablePlugins() {
/* 110 */     Vector<PluginHandler> vector = new Vector();
/* 111 */     Iterator<PluginHandler> iterator = pHandlers.iterator();
/* 112 */     while (iterator.hasNext()) {
/* 113 */       PluginHandler pluginHandler = iterator.next();
/* 114 */       if (pluginHandler.isSupportedPlatform()) {
/* 115 */         vector.add(pluginHandler);
/*     */       }
/*     */     } 
/* 118 */     return vector;
/*     */   }
/*     */   
/*     */   private static PluginHandler getEnabledPlugin(int paramInt) {
/* 122 */     if (paramInt < 0 || paramInt >= hndArray.length) return null; 
/* 123 */     return hndArray[paramInt];
/*     */   }
/*     */   
/*     */   private static int getEnabledPluginCount() {
/* 127 */     return hndArray.length;
/*     */   }
/*     */   
/*     */   private static void disablePlugin(PluginHandler paramPluginHandler) {
/* 131 */     disabledPluginHandlers.add(paramPluginHandler.getClass().getCanonicalName());
/* 132 */     updatePluginHandlers();
/*     */   }
/*     */   
/*     */   private static void enablePlugin(PluginHandler paramPluginHandler) {
/* 136 */     disabledPluginHandlers.remove(paramPluginHandler.getClass().getCanonicalName());
/* 137 */     updatePluginHandlers();
/*     */   }
/*     */   
/*     */   private static boolean isDisabledPlugin(PluginHandler paramPluginHandler) {
/* 141 */     return disabledPluginHandlers.contains(paramPluginHandler
/* 142 */         .getClass().getCanonicalName());
/*     */   }
/*     */   
/*     */   private static boolean supportsMIMEType(String paramString) {
/* 146 */     return hndMap.containsKey(paramString);
/*     */   }
/*     */   
/*     */   private static String getPluginNameForMIMEType(String paramString) {
/* 150 */     PluginHandler pluginHandler = hndMap.get(paramString);
/* 151 */     if (pluginHandler != null) return pluginHandler.getName(); 
/* 152 */     return "";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\plugin\PluginManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */