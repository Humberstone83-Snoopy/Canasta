/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.scene.layout.BorderWidths;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorderImageSlices
/*    */ {
/* 39 */   public static final BorderImageSlices EMPTY = new BorderImageSlices(BorderWidths.EMPTY, false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static final BorderImageSlices DEFAULT = new BorderImageSlices(BorderWidths.FULL, false);
/*    */   
/*    */   public BorderWidths widths;
/*    */   public boolean filled;
/*    */   
/*    */   public BorderImageSlices(BorderWidths paramBorderWidths, boolean paramBoolean) {
/* 51 */     this.widths = paramBorderWidths;
/* 52 */     this.filled = paramBoolean;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\BorderImageSlices.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */