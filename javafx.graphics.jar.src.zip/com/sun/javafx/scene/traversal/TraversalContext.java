package com.sun.javafx.scene.traversal;

import java.util.List;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.Parent;

public interface TraversalContext {
  List<Node> getAllTargetNodes();
  
  Bounds getSceneLayoutBounds(Node paramNode);
  
  Parent getRoot();
  
  Node selectFirstInParent(Parent paramParent);
  
  Node selectLastInParent(Parent paramParent);
  
  Node selectInSubtree(Parent paramParent, Node paramNode, Direction paramDirection);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\TraversalContext.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */