/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.css.CSSValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSSValueImpl
/*     */   implements CSSValue
/*     */ {
/*     */   private final long peer;
/*     */   public static final int CSS_INHERIT = 0;
/*     */   public static final int CSS_PRIMITIVE_VALUE = 1;
/*     */   public static final int CSS_VALUE_LIST = 2;
/*     */   public static final int CSS_CUSTOM = 3;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  37 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  40 */       CSSValueImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   CSSValueImpl(long paramLong) {
/*  45 */     this.peer = paramLong;
/*  46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static CSSValue create(long paramLong) {
/*  50 */     if (paramLong == 0L) return null; 
/*  51 */     switch (getCssValueTypeImpl(paramLong)) { case 1:
/*  52 */         return new CSSPrimitiveValueImpl(paramLong);
/*  53 */       case 2: return new CSSValueListImpl(paramLong); }
/*     */     
/*  55 */     return new CSSValueImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  61 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  65 */     return (paramObject instanceof CSSValueImpl && this.peer == ((CSSValueImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  69 */     long l = this.peer;
/*  70 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(CSSValue paramCSSValue) {
/*  74 */     return (paramCSSValue == null) ? 0L : ((CSSValueImpl)paramCSSValue).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static CSSValue getImpl(long paramLong) {
/*  80 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCssText() {
/*  92 */     return getCssTextImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCssText(String paramString) throws DOMException {
/*  97 */     setCssTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getCssValueType() {
/* 102 */     return getCssValueTypeImpl(getPeer());
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native String getCssTextImpl(long paramLong);
/*     */   
/*     */   static native void setCssTextImpl(long paramLong, String paramString);
/*     */   
/*     */   static native short getCssValueTypeImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSValueImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */