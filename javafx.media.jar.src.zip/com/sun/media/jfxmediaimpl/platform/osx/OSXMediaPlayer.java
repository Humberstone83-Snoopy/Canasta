/*     */ package com.sun.media.jfxmediaimpl.platform.osx;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.control.MediaPlayerOverlay;
/*     */ import com.sun.media.jfxmedia.effects.AudioEqualizer;
/*     */ import com.sun.media.jfxmedia.effects.AudioSpectrum;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmediaimpl.NativeMedia;
/*     */ import com.sun.media.jfxmediaimpl.NativeMediaPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class OSXMediaPlayer
/*     */   extends NativeMediaPlayer
/*     */ {
/*     */   private final AudioEqualizer audioEq;
/*     */   private final AudioSpectrum audioSpectrum;
/*     */   private final Locator mediaLocator;
/*     */   
/*     */   OSXMediaPlayer(NativeMedia paramNativeMedia) {
/*  45 */     super(paramNativeMedia);
/*  46 */     init();
/*  47 */     this.mediaLocator = paramNativeMedia.getLocator();
/*     */     
/*  49 */     osxCreatePlayer(this.mediaLocator.getStringLocation());
/*  50 */     this.audioEq = createNativeAudioEqualizer(osxGetAudioEqualizerRef());
/*  51 */     this.audioSpectrum = createNativeAudioSpectrum(osxGetAudioSpectrumRef());
/*     */   }
/*     */   
/*     */   OSXMediaPlayer(Locator paramLocator) {
/*  55 */     this(new OSXMedia(paramLocator));
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioEqualizer getEqualizer() {
/*  60 */     return this.audioEq;
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioSpectrum getAudioSpectrum() {
/*  65 */     return this.audioSpectrum;
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaPlayerOverlay getMediaPlayerOverlay() {
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected long playerGetAudioSyncDelay() throws MediaException {
/*  75 */     return osxGetAudioSyncDelay();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetAudioSyncDelay(long paramLong) throws MediaException {
/*  80 */     osxSetAudioSyncDelay(paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerPlay() throws MediaException {
/*  85 */     osxPlay();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerStop() throws MediaException {
/*  90 */     osxStop();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerPause() throws MediaException {
/*  95 */     osxPause();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerFinish() throws MediaException {
/* 100 */     osxFinish();
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetRate() throws MediaException {
/* 105 */     return osxGetRate();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetRate(float paramFloat) throws MediaException {
/* 110 */     osxSetRate(paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double playerGetPresentationTime() throws MediaException {
/* 115 */     return osxGetPresentationTime();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean playerGetMute() throws MediaException {
/* 120 */     return osxGetMute();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetMute(boolean paramBoolean) throws MediaException {
/* 125 */     osxSetMute(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetVolume() throws MediaException {
/* 130 */     return osxGetVolume();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetVolume(float paramFloat) throws MediaException {
/* 135 */     osxSetVolume(paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetBalance() throws MediaException {
/* 140 */     return osxGetBalance();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetBalance(float paramFloat) throws MediaException {
/* 145 */     osxSetBalance(paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   protected double playerGetDuration() throws MediaException {
/* 150 */     double d = osxGetDuration();
/* 151 */     if (d == -1.0D) {
/* 152 */       return Double.POSITIVE_INFINITY;
/*     */     }
/*     */     
/* 155 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSeek(double paramDouble) throws MediaException {
/* 160 */     osxSeek(paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerDispose() {
/* 165 */     osxDispose();
/*     */   }
/*     */   
/*     */   public void playerInit() throws MediaException {}
/*     */   
/*     */   private native void osxCreatePlayer(String paramString) throws MediaException;
/*     */   
/*     */   private native long osxGetAudioEqualizerRef();
/*     */   
/*     */   private native long osxGetAudioSpectrumRef();
/*     */   
/*     */   private native long osxGetAudioSyncDelay() throws MediaException;
/*     */   
/*     */   private native void osxSetAudioSyncDelay(long paramLong) throws MediaException;
/*     */   
/*     */   private native void osxPlay() throws MediaException;
/*     */   
/*     */   private native void osxStop() throws MediaException;
/*     */   
/*     */   private native void osxPause() throws MediaException;
/*     */   
/*     */   private native void osxFinish() throws MediaException;
/*     */   
/*     */   private native float osxGetRate() throws MediaException;
/*     */   
/*     */   private native void osxSetRate(float paramFloat) throws MediaException;
/*     */   
/*     */   private native double osxGetPresentationTime() throws MediaException;
/*     */   
/*     */   private native boolean osxGetMute() throws MediaException;
/*     */   
/*     */   private native void osxSetMute(boolean paramBoolean) throws MediaException;
/*     */   
/*     */   private native float osxGetVolume() throws MediaException;
/*     */   
/*     */   private native void osxSetVolume(float paramFloat) throws MediaException;
/*     */   
/*     */   private native float osxGetBalance() throws MediaException;
/*     */   
/*     */   private native void osxSetBalance(float paramFloat) throws MediaException;
/*     */   
/*     */   private native double osxGetDuration() throws MediaException;
/*     */   
/*     */   private native void osxSeek(double paramDouble) throws MediaException;
/*     */   
/*     */   private native void osxDispose();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\osx\OSXMediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */