/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.stylesheets.MediaList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MediaListImpl
/*     */   implements MediaList
/*     */ {
/*     */   private final long peer;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  37 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  40 */       MediaListImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   MediaListImpl(long paramLong) {
/*  45 */     this.peer = paramLong;
/*  46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static MediaList create(long paramLong) {
/*  50 */     if (paramLong == 0L) return null; 
/*  51 */     return new MediaListImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  57 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  61 */     return (paramObject instanceof MediaListImpl && this.peer == ((MediaListImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  65 */     long l = this.peer;
/*  66 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(MediaList paramMediaList) {
/*  70 */     return (paramMediaList == null) ? 0L : ((MediaListImpl)paramMediaList).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static MediaList getImpl(long paramLong) {
/*  76 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMediaText() {
/*  82 */     return getMediaTextImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMediaText(String paramString) throws DOMException {
/*  87 */     setMediaTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getLength() {
/*  92 */     return getLengthImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String item(int paramInt) {
/* 100 */     return itemImpl(getPeer(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteMedium(String paramString) throws DOMException {
/* 109 */     deleteMediumImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendMedium(String paramString) throws DOMException {
/* 118 */     appendMediumImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native String getMediaTextImpl(long paramLong);
/*     */   
/*     */   static native void setMediaTextImpl(long paramLong, String paramString);
/*     */   
/*     */   static native int getLengthImpl(long paramLong);
/*     */   
/*     */   static native String itemImpl(long paramLong, int paramInt);
/*     */   
/*     */   static native void deleteMediumImpl(long paramLong, String paramString);
/*     */   
/*     */   static native void appendMediumImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\MediaListImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */