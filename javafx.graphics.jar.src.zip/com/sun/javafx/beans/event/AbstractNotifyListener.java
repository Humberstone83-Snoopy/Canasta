/*    */ package com.sun.javafx.beans.event;
/*    */ 
/*    */ import javafx.beans.InvalidationListener;
/*    */ import javafx.beans.WeakInvalidationListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractNotifyListener
/*    */   implements InvalidationListener
/*    */ {
/* 61 */   private final WeakInvalidationListener weakListener = new WeakInvalidationListener(this);
/*    */   
/*    */   public InvalidationListener getWeakListener() {
/* 64 */     return this.weakListener;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\beans\event\AbstractNotifyListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */