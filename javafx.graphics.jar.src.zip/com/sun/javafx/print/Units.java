/*    */ package com.sun.javafx.print;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Units
/*    */ {
/* 36 */   MM,
/*    */ 
/*    */ 
/*    */   
/* 40 */   INCH,
/*    */ 
/*    */ 
/*    */   
/* 44 */   POINT;
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\print\Units.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */