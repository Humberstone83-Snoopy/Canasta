/*    */ package com.sun.javafx.image.impl;
/*    */ 
/*    */ import com.sun.javafx.image.BytePixelAccessor;
/*    */ import com.sun.javafx.image.BytePixelGetter;
/*    */ import com.sun.javafx.image.BytePixelSetter;
/*    */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteGrayAlphaPre
/*    */ {
/* 34 */   public static final BytePixelGetter getter = ByteGrayAlpha.Accessor.premul;
/* 35 */   public static final BytePixelSetter setter = ByteGrayAlpha.Accessor.premul;
/* 36 */   public static final BytePixelAccessor accessor = ByteGrayAlpha.Accessor.premul;
/*    */   
/*    */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/* 39 */     return ByteGrayAlpha.ToByteBgraSameConv.premul;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteGrayAlphaPre.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */