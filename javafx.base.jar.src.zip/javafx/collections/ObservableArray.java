package javafx.collections;

import javafx.beans.Observable;

public interface ObservableArray<T extends ObservableArray<T>> extends Observable {
  void addListener(ArrayChangeListener<T> paramArrayChangeListener);
  
  void removeListener(ArrayChangeListener<T> paramArrayChangeListener);
  
  void resize(int paramInt);
  
  void ensureCapacity(int paramInt);
  
  void trimToSize();
  
  void clear();
  
  int size();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\ObservableArray.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */