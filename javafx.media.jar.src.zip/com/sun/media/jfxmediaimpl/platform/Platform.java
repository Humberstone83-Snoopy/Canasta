/*    */ package com.sun.media.jfxmediaimpl.platform;
/*    */ 
/*    */ import com.sun.media.jfxmedia.Media;
/*    */ import com.sun.media.jfxmedia.MediaPlayer;
/*    */ import com.sun.media.jfxmedia.MetadataParser;
/*    */ import com.sun.media.jfxmedia.locator.Locator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Platform
/*    */ {
/*    */   public static Platform getPlatformInstance() {
/* 41 */     throw new UnsupportedOperationException("Invalid platform class.");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean loadPlatform() {
/* 48 */     return false;
/*    */   }
/*    */   
/*    */   public boolean canPlayContentType(String paramString) {
/* 52 */     String[] arrayOfString = getSupportedContentTypes();
/* 53 */     if (arrayOfString != null) {
/* 54 */       for (String str : arrayOfString) {
/* 55 */         if (str.equalsIgnoreCase(paramString)) {
/* 56 */           return true;
/*    */         }
/*    */       } 
/*    */     }
/* 60 */     return false;
/*    */   }
/*    */   
/*    */   public boolean canPlayProtocol(String paramString) {
/* 64 */     String[] arrayOfString = getSupportedProtocols();
/* 65 */     if (arrayOfString != null) {
/* 66 */       for (String str : arrayOfString) {
/* 67 */         if (str.equalsIgnoreCase(paramString)) {
/* 68 */           return true;
/*    */         }
/*    */       } 
/*    */     }
/* 72 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getSupportedContentTypes() {
/* 79 */     return new String[0];
/*    */   }
/*    */   
/*    */   public String[] getSupportedProtocols() {
/* 83 */     return new String[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public MetadataParser createMetadataParser(Locator paramLocator) {
/* 88 */     return null;
/*    */   }
/*    */   
/*    */   public abstract Media createMedia(Locator paramLocator);
/*    */   
/*    */   public abstract MediaPlayer createMediaPlayer(Locator paramLocator);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\Platform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */