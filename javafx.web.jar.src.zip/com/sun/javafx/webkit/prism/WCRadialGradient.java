/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.paint.RadialGradient;
/*     */ import com.sun.prism.paint.Stop;
/*     */ import com.sun.webkit.graphics.WCGradient;
/*     */ import com.sun.webkit.graphics.WCPoint;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCRadialGradient
/*     */   extends WCGradient<RadialGradient>
/*     */ {
/*     */   static final Comparator<Stop> COMPARATOR;
/*     */   private final boolean reverse;
/*     */   private final WCPoint p1;
/*     */   private final WCPoint p2;
/*     */   private final float r1over;
/*     */   private final float r1;
/*     */   private final float r2;
/*     */   
/*     */   static {
/*  41 */     COMPARATOR = ((paramStop1, paramStop2) -> {
/*     */         float f1 = paramStop1.getOffset();
/*     */         float f2 = paramStop2.getOffset();
/*     */         return (f1 < f2) ? -1 : ((f1 > f2) ? 1 : 0);
/*     */       });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private final List<Stop> stops = new ArrayList<>();
/*     */   
/*     */   WCRadialGradient(WCPoint paramWCPoint1, float paramFloat1, WCPoint paramWCPoint2, float paramFloat2) {
/*  62 */     this.reverse = (paramFloat1 < paramFloat2);
/*  63 */     this.p1 = this.reverse ? paramWCPoint2 : paramWCPoint1;
/*  64 */     this.p2 = this.reverse ? paramWCPoint1 : paramWCPoint2;
/*  65 */     this.r1 = this.reverse ? paramFloat2 : paramFloat1;
/*  66 */     this.r2 = this.reverse ? paramFloat1 : paramFloat2;
/*  67 */     this
/*     */       
/*  69 */       .r1over = (this.r1 > 0.0F) ? (1.0F / this.r1) : 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addStop(int paramInt, float paramFloat) {
/*  74 */     if (this.reverse) {
/*  75 */       paramFloat = 1.0F - paramFloat;
/*     */     }
/*  77 */     paramFloat = 1.0F - paramFloat + paramFloat * this.r2 * this.r1over;
/*  78 */     this.stops.add(new Stop(WCGraphicsPrismContext.createColor(paramInt), paramFloat));
/*     */   }
/*     */   
/*     */   public RadialGradient getPlatformGradient() {
/*  82 */     Collections.sort(this.stops, COMPARATOR);
/*  83 */     float f1 = this.p2.getX() - this.p1.getX();
/*  84 */     float f2 = this.p2.getY() - this.p1.getY();
/*  85 */     return new RadialGradient(this.p1
/*  86 */         .getX(), this.p1
/*  87 */         .getY(), 
/*  88 */         (float)(Math.atan2(f2, f1) * 180.0D / Math.PI), 
/*  89 */         (float)Math.sqrt((f1 * f1 + f2 * f2)) * this.r1over, this.r1, BaseTransform.IDENTITY_TRANSFORM, 
/*     */ 
/*     */         
/*  92 */         isProportional(), 
/*  93 */         getSpreadMethod() - 1, this.stops);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     return toString(this, this.p1, this.p2, Float.valueOf(this.r1), this.stops);
/*     */   }
/*     */   
/*     */   static String toString(WCGradient paramWCGradient, WCPoint paramWCPoint1, WCPoint paramWCPoint2, Float paramFloat, List<Stop> paramList) {
/* 103 */     StringBuilder stringBuilder = new StringBuilder(paramWCGradient.getClass().getSimpleName());
/* 104 */     switch (paramWCGradient.getSpreadMethod()) {
/*     */       case 1:
/* 106 */         stringBuilder.append("[spreadMethod=PAD");
/*     */         break;
/*     */       case 2:
/* 109 */         stringBuilder.append("[spreadMethod=REFLECT");
/*     */         break;
/*     */       case 3:
/* 112 */         stringBuilder.append("[spreadMethod=REPEAT");
/*     */         break;
/*     */     } 
/* 115 */     stringBuilder.append(", proportional=").append(paramWCGradient.isProportional());
/* 116 */     if (paramFloat != null) {
/* 117 */       stringBuilder.append(", radius=").append(paramFloat);
/*     */     }
/* 119 */     stringBuilder.append(", x1=").append(paramWCPoint1.getX());
/* 120 */     stringBuilder.append(", y1=").append(paramWCPoint1.getY());
/* 121 */     stringBuilder.append(", x2=").append(paramWCPoint2.getX());
/* 122 */     stringBuilder.append(", y2=").append(paramWCPoint2.getY());
/* 123 */     stringBuilder.append(", stops=");
/* 124 */     for (byte b = 0; b < paramList.size(); b++) {
/* 125 */       stringBuilder.append((b == 0) ? "[" : ", ");
/* 126 */       stringBuilder.append(((Stop)paramList.get(b)).getOffset()).append(":").append(((Stop)paramList.get(b)).getColor());
/*     */     } 
/* 128 */     return stringBuilder.append("]]").toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCRadialGradient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */