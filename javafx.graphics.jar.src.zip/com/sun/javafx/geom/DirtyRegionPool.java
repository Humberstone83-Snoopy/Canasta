/*    */ package com.sun.javafx.geom;
/*    */ 
/*    */ import java.util.Deque;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DirtyRegionPool
/*    */ {
/*    */   private static final int POOL_SIZE_MIN = 4;
/*    */   private static final int EXPIRATION_TIME = 3000;
/*    */   private static final int COUNT_BETWEEN_EXPIRATION_CHECK = 90;
/*    */   private final int containerSize;
/*    */   
/*    */   private class PoolItem
/*    */   {
/*    */     DirtyRegionContainer container;
/*    */     long timeStamp;
/*    */     
/*    */     public PoolItem(DirtyRegionContainer param1DirtyRegionContainer, long param1Long) {
/* 39 */       this.container = param1DirtyRegionContainer;
/* 40 */       this.timeStamp = param1Long;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   private int clearCounter = 90;
/*    */   private final Deque<DirtyRegionContainer> fixed;
/*    */   private final Deque<PoolItem> unlocked;
/*    */   private final Deque<PoolItem> locked;
/*    */   
/*    */   public DirtyRegionPool(int paramInt) {
/* 53 */     this.containerSize = paramInt;
/* 54 */     this.fixed = new LinkedList<>();
/* 55 */     this.unlocked = new LinkedList<>();
/* 56 */     this.locked = new LinkedList<>();
/* 57 */     for (byte b = 0; b < 4; b++) {
/* 58 */       this.fixed.add(new DirtyRegionContainer(paramInt));
/*    */     }
/*    */   }
/*    */   
/*    */   public DirtyRegionContainer checkOut() {
/* 63 */     clearExpired();
/* 64 */     if (!this.fixed.isEmpty()) {
/* 65 */       return this.fixed.pop();
/*    */     }
/* 67 */     if (!this.unlocked.isEmpty()) {
/* 68 */       PoolItem poolItem = this.unlocked.pop();
/* 69 */       this.locked.push(poolItem);
/* 70 */       return poolItem.container;
/*    */     } 
/* 72 */     DirtyRegionContainer dirtyRegionContainer = new DirtyRegionContainer(this.containerSize);
/* 73 */     this.locked.push(new PoolItem(null, -1L));
/* 74 */     return dirtyRegionContainer;
/*    */   }
/*    */   
/*    */   public void checkIn(DirtyRegionContainer paramDirtyRegionContainer) {
/* 78 */     paramDirtyRegionContainer.reset();
/* 79 */     if (this.locked.isEmpty()) {
/* 80 */       this.fixed.push(paramDirtyRegionContainer);
/*    */     } else {
/* 82 */       PoolItem poolItem = this.locked.pop();
/* 83 */       poolItem.container = paramDirtyRegionContainer;
/* 84 */       poolItem.timeStamp = System.currentTimeMillis();
/* 85 */       this.unlocked.push(poolItem);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void clearExpired() {
/* 90 */     if (this.unlocked.isEmpty()) {
/*    */       return;
/*    */     }
/* 93 */     if (this.clearCounter-- == 0) {
/* 94 */       this.clearCounter = 90;
/* 95 */       PoolItem poolItem = this.unlocked.peekLast();
/* 96 */       long l = System.currentTimeMillis();
/* 97 */       while (poolItem != null && poolItem.timeStamp + 3000L < l) {
/* 98 */         this.unlocked.removeLast();
/* 99 */         poolItem = this.unlocked.peekLast();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\DirtyRegionPool.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */