/*     */ package com.sun.media.jfxmedia.locator;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.MediaManager;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.HostUtils;
/*     */ import com.sun.media.jfxmediaimpl.MediaUtils;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Locator
/*     */ {
/*     */   public static final String DEFAULT_CONTENT_TYPE = "application/octet-stream";
/*     */   private static final int MAX_CONNECTION_ATTEMPTS = 5;
/*     */   private static final long CONNECTION_RETRY_INTERVAL = 1000L;
/*     */   private static final int CONNECTION_TIMEOUT = 300000;
/*  77 */   protected String contentType = "application/octet-stream";
/*     */ 
/*     */ 
/*     */   
/*  81 */   protected long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URI uri;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> connectionProperties;
/*     */ 
/*     */ 
/*     */   
/*  95 */   private final Object propertyLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private String uriString = null;
/* 101 */   private String scheme = null;
/* 102 */   private String protocol = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private LocatorCache.CacheReference cacheEntry = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canBlock = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private CountDownLatch readySignal = new CountDownLatch(1);
/*     */ 
/*     */   
/*     */   private boolean isIpod;
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LocatorConnection
/*     */   {
/*     */     private LocatorConnection() {}
/*     */ 
/*     */     
/* 130 */     public HttpURLConnection connection = null;
/* 131 */     public int responseCode = 200;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LocatorConnection getConnection(URI paramURI, String paramString) throws MalformedURLException, IOException {
/* 138 */     LocatorConnection locatorConnection = new LocatorConnection();
/* 139 */     HttpURLConnection httpURLConnection = (HttpURLConnection)paramURI.toURL().openConnection();
/* 140 */     httpURLConnection.setRequestMethod(paramString);
/*     */     
/* 142 */     httpURLConnection.setConnectTimeout(300000);
/* 143 */     httpURLConnection.setReadTimeout(300000);
/*     */ 
/*     */     
/* 146 */     synchronized (this.propertyLock) {
/* 147 */       if (this.connectionProperties != null) {
/* 148 */         for (String str : this.connectionProperties.keySet()) {
/* 149 */           Object object = this.connectionProperties.get(str);
/* 150 */           if (object instanceof String) {
/* 151 */             httpURLConnection.setRequestProperty(str, (String)object);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 159 */     locatorConnection.responseCode = httpURLConnection.getResponseCode();
/* 160 */     if (httpURLConnection.getResponseCode() == 200) {
/* 161 */       locatorConnection.connection = httpURLConnection;
/*     */     } else {
/* 163 */       closeConnection(httpURLConnection);
/* 164 */       locatorConnection.connection = null;
/*     */     } 
/* 166 */     return locatorConnection;
/*     */   }
/*     */   
/*     */   private static long getContentLengthLong(URLConnection paramURLConnection) {
/* 170 */     Method method = AccessController.<Method>doPrivileged(() -> {
/*     */           try {
/*     */             return URLConnection.class.getMethod("getContentLengthLong", new Class[0]);
/* 173 */           } catch (NoSuchMethodException noSuchMethodException) {
/*     */             return null;
/*     */           } 
/*     */         });
/*     */     
/*     */     try {
/* 179 */       if (method != null) {
/* 180 */         return ((Long)method.invoke(paramURLConnection, new Object[0])).longValue();
/*     */       }
/* 182 */       return paramURLConnection.getContentLength();
/*     */     }
/* 184 */     catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 185 */       return -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locator(URI paramURI) throws URISyntaxException {
/* 210 */     if (paramURI == null) {
/* 211 */       throw new NullPointerException("uri == null!");
/*     */     }
/*     */ 
/*     */     
/* 215 */     this.uriString = paramURI.toASCIIString();
/* 216 */     this.scheme = paramURI.getScheme();
/* 217 */     if (this.scheme == null) {
/* 218 */       throw new IllegalArgumentException("uri.getScheme() == null! uri == '" + paramURI + "'");
/*     */     }
/* 220 */     this.scheme = this.scheme.toLowerCase();
/*     */ 
/*     */     
/* 223 */     if (this.scheme.equals("jar")) {
/* 224 */       URI uRI = new URI(this.uriString.substring(4));
/* 225 */       this.protocol = uRI.getScheme();
/* 226 */       if (this.protocol == null) {
/* 227 */         throw new IllegalArgumentException("uri.getScheme() == null! subURI == '" + uRI + "'");
/*     */       }
/* 229 */       this.protocol = this.protocol.toLowerCase();
/*     */     } else {
/* 231 */       this.protocol = this.scheme;
/*     */     } 
/*     */     
/* 234 */     if (HostUtils.isIOS() && this.protocol.equals("ipod-library")) {
/* 235 */       this.isIpod = true;
/*     */     }
/*     */ 
/*     */     
/* 239 */     if (!this.isIpod && !MediaManager.canPlayProtocol(this.protocol)) {
/* 240 */       throw new UnsupportedOperationException("Unsupported protocol \"" + this.protocol + "\"");
/*     */     }
/*     */ 
/*     */     
/* 244 */     if (this.protocol.equals("http") || this.protocol.equals("https")) {
/* 245 */       this.canBlock = true;
/*     */     }
/*     */ 
/*     */     
/* 249 */     this.uri = paramURI;
/*     */   }
/*     */ 
/*     */   
/*     */   private InputStream getInputStream(URI paramURI) throws MalformedURLException, IOException {
/* 254 */     URL uRL = paramURI.toURL();
/* 255 */     URLConnection uRLConnection = uRL.openConnection();
/*     */ 
/*     */     
/* 258 */     synchronized (this.propertyLock) {
/* 259 */       if (this.connectionProperties != null) {
/* 260 */         for (String str : this.connectionProperties.keySet()) {
/* 261 */           Object object = this.connectionProperties.get(str);
/* 262 */           if (object instanceof String) {
/* 263 */             uRLConnection.setRequestProperty(str, (String)object);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 269 */     InputStream inputStream = uRL.openStream();
/* 270 */     this.contentLength = getContentLengthLong(uRLConnection);
/* 271 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cacheMedia() {
/* 279 */     LocatorCache.CacheReference cacheReference = LocatorCache.locatorCache().fetchURICache(this.uri);
/* 280 */     if (null == cacheReference) {
/*     */       InputStream inputStream;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 286 */         inputStream = getInputStream(this.uri);
/* 287 */       } catch (Throwable throwable) {
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 292 */       ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)this.contentLength);
/* 293 */       byte[] arrayOfByte = new byte[8192];
/* 294 */       boolean bool = false;
/*     */       
/* 296 */       while (bool < this.contentLength) {
/*     */         int i; try {
/* 298 */           i = inputStream.read(arrayOfByte);
/* 299 */         } catch (IOException iOException) {
/*     */           try {
/* 301 */             inputStream.close();
/* 302 */           } catch (Throwable throwable) {}
/*     */           
/* 304 */           if (Logger.canLog(1)) {
/* 305 */             Logger.logMsg(1, "IOException trying to preload media: " + iOException);
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 310 */         if (i == -1) {
/*     */           break;
/*     */         }
/*     */         
/* 314 */         byteBuffer.put(arrayOfByte, 0, i);
/*     */       } 
/*     */       
/*     */       try {
/* 318 */         inputStream.close();
/* 319 */       } catch (Throwable throwable) {}
/*     */ 
/*     */       
/* 322 */       this.cacheEntry = LocatorCache.locatorCache().registerURICache(this.uri, byteBuffer, this.contentType);
/* 323 */       this.canBlock = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBlock() {
/* 331 */     return this.canBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() throws URISyntaxException, IOException, FileNotFoundException {
/*     */     try {
/* 347 */       int i = this.uriString.indexOf("/");
/* 348 */       if (i != -1 && this.uriString.charAt(i + 1) != '/')
/*     */       {
/* 350 */         if (this.protocol.equals("file")) {
/*     */           
/* 352 */           this.uriString = this.uriString.replaceFirst("/", "///");
/* 353 */         } else if (this.protocol.equals("http") || this.protocol.equals("https")) {
/*     */           
/* 355 */           this.uriString = this.uriString.replaceFirst("/", "//");
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 360 */       if (System.getProperty("os.name").toLowerCase().indexOf("win") == -1 && this.protocol
/* 361 */         .equals("file")) {
/* 362 */         int j = this.uriString.indexOf("/~/");
/* 363 */         if (j != -1) {
/* 364 */           this
/*     */             
/* 366 */             .uriString = this.uriString.substring(0, j) + this.uriString.substring(0, j) + System.getProperty("user.home");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 371 */       this.uri = new URI(this.uriString);
/*     */ 
/*     */       
/* 374 */       this.cacheEntry = LocatorCache.locatorCache().fetchURICache(this.uri);
/* 375 */       if (null != this.cacheEntry) {
/*     */         
/* 377 */         this.contentType = this.cacheEntry.getMIMEType();
/* 378 */         this.contentLength = this.cacheEntry.getBuffer().capacity();
/* 379 */         if (Logger.canLog(1)) {
/* 380 */           Logger.logMsg(1, "Locator init cache hit:\n    uri " + this.uri + "\n    type " + this.contentType + "\n    length " + this.contentLength);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 389 */       boolean bool1 = false;
/* 390 */       boolean bool2 = false;
/* 391 */       boolean bool3 = true;
/* 392 */       if (!this.isIpod) {
/* 393 */         for (byte b = 0; b < 5; b++)
/*     */         {
/*     */           try {
/* 396 */             if (this.scheme.equals("http") || this.scheme.equals("https")) {
/*     */               
/* 398 */               LocatorConnection locatorConnection = getConnection(this.uri, "HEAD");
/* 399 */               if (locatorConnection == null || locatorConnection.connection == null) {
/* 400 */                 locatorConnection = getConnection(this.uri, "GET");
/*     */               }
/*     */               
/* 403 */               if (locatorConnection != null && locatorConnection.connection != null) {
/* 404 */                 bool1 = true;
/*     */ 
/*     */                 
/* 407 */                 this.contentType = locatorConnection.connection.getContentType();
/* 408 */                 this.contentLength = getContentLengthLong(locatorConnection.connection);
/*     */ 
/*     */                 
/* 411 */                 closeConnection(locatorConnection.connection);
/* 412 */                 locatorConnection.connection = null;
/* 413 */               } else if (locatorConnection != null && 
/* 414 */                 locatorConnection.responseCode == 404) {
/* 415 */                 bool2 = true;
/*     */               
/*     */               }
/*     */             
/*     */             }
/* 420 */             else if (this.scheme.equals("file") || this.scheme.equals("jar")) {
/* 421 */               InputStream inputStream = getInputStream(this.uri);
/* 422 */               inputStream.close();
/* 423 */               bool1 = true;
/* 424 */               this.contentType = MediaUtils.filenameToContentType(this.uriString);
/*     */             } 
/*     */             
/* 427 */             if (bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 432 */               if ("audio/x-wav".equals(this.contentType)) {
/* 433 */                 this.contentType = getContentTypeFromFileSignature(this.uri);
/* 434 */                 if (!MediaManager.canPlayContentType(this.contentType))
/* 435 */                   bool3 = false; 
/*     */                 break;
/*     */               } 
/* 438 */               if (this.contentType == null || !MediaManager.canPlayContentType(this.contentType)) {
/*     */                 
/* 440 */                 this.contentType = MediaUtils.filenameToContentType(this.uriString);
/*     */                 
/* 442 */                 if ("application/octet-stream".equals(this.contentType))
/*     */                 {
/* 444 */                   this.contentType = getContentTypeFromFileSignature(this.uri);
/*     */                 }
/*     */                 
/* 447 */                 if (!MediaManager.canPlayContentType(this.contentType)) {
/* 448 */                   bool3 = false;
/*     */                 }
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/* 456 */           } catch (IOException iOException) {
/* 457 */             if (b + 1 >= 5) {
/* 458 */               throw iOException;
/*     */             }
/*     */           } 
/*     */           
/*     */           try {
/* 463 */             Thread.sleep(1000L);
/* 464 */           } catch (InterruptedException interruptedException) {}
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 471 */         this.contentType = MediaUtils.filenameToContentType(this.uriString);
/*     */       } 
/*     */       
/* 474 */       if (Logger.canLog(3)) {
/* 475 */         if (this.contentType.equals("video/x-flv")) {
/* 476 */           Logger.logMsg(3, "Support for FLV container and VP6 video is removed.");
/* 477 */           throw new MediaException("media type not supported (" + this.uri.toString() + ")");
/* 478 */         }  if (this.contentType.equals("video/x-javafx")) {
/* 479 */           Logger.logMsg(3, "Support for FXM container and VP6 video is removed.");
/* 480 */           throw new MediaException("media type not supported (" + this.uri.toString() + ")");
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 485 */       if (!this.isIpod && !bool1) {
/* 486 */         if (bool2) {
/* 487 */           throw new FileNotFoundException("media is unavailable (" + this.uri.toString() + ")");
/*     */         }
/* 489 */         throw new IOException("could not connect to media (" + this.uri.toString() + ")");
/*     */       } 
/* 491 */       if (!bool3) {
/* 492 */         throw new MediaException("media type not supported (" + this.uri.toString() + ")");
/*     */       }
/* 494 */     } catch (FileNotFoundException fileNotFoundException) {
/* 495 */       throw fileNotFoundException;
/* 496 */     } catch (IOException iOException) {
/* 497 */       throw iOException;
/* 498 */     } catch (MediaException mediaException) {
/* 499 */       throw mediaException;
/*     */     } finally {
/* 501 */       this.readySignal.countDown();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*     */     try {
/* 512 */       this.readySignal.await();
/* 513 */     } catch (Exception exception) {}
/*     */     
/* 515 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProtocol() {
/* 522 */     return this.protocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/*     */     try {
/* 533 */       this.readySignal.await();
/* 534 */     } catch (Exception exception) {}
/*     */     
/* 536 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForReadySignal() {
/*     */     try {
/* 544 */       this.readySignal.await();
/* 545 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 556 */     return this.uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 569 */     return LocatorCache.locatorCache().isCached(this.uri) ? ("{LocatorURI uri: " + 
/* 570 */       this.uri.toString() + " (media cached)}") : ("{LocatorURI uri: " + 
/*     */       
/* 572 */       this.uri.toString() + "}");
/*     */   }
/*     */   
/*     */   public String getStringLocation() {
/* 576 */     return this.uri.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionProperty(String paramString, Object paramObject) {
/* 589 */     synchronized (this.propertyLock) {
/* 590 */       if (this.connectionProperties == null) {
/* 591 */         this.connectionProperties = new TreeMap<>();
/*     */       }
/*     */       
/* 594 */       this.connectionProperties.put(paramString, paramObject);
/*     */     } 
/*     */   }
/*     */   
/*     */   public ConnectionHolder createConnectionHolder() throws IOException {
/*     */     ConnectionHolder connectionHolder;
/* 600 */     if (null != this.cacheEntry) {
/* 601 */       if (Logger.canLog(1)) {
/* 602 */         Logger.logMsg(1, "Locator.createConnectionHolder: media cached, creating memory connection holder");
/*     */       }
/* 604 */       return ConnectionHolder.createMemoryConnectionHolder(this.cacheEntry.getBuffer());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 609 */     if ("file".equals(this.scheme)) {
/* 610 */       connectionHolder = ConnectionHolder.createFileConnectionHolder(this.uri);
/* 611 */     } else if (this.uri.toString().endsWith(".m3u8") || this.uri.toString().endsWith(".m3u")) {
/* 612 */       connectionHolder = ConnectionHolder.createHLSConnectionHolder(this.uri);
/*     */     } else {
/* 614 */       synchronized (this.propertyLock) {
/* 615 */         connectionHolder = ConnectionHolder.createURIConnectionHolder(this.uri, this.connectionProperties);
/*     */       } 
/*     */     } 
/*     */     
/* 619 */     return connectionHolder;
/*     */   }
/*     */   
/*     */   private String getContentTypeFromFileSignature(URI paramURI) throws MalformedURLException, IOException {
/* 623 */     InputStream inputStream = getInputStream(paramURI);
/* 624 */     byte[] arrayOfByte = new byte[22];
/* 625 */     int i = inputStream.read(arrayOfByte);
/* 626 */     inputStream.close();
/*     */     
/* 628 */     return MediaUtils.fileSignatureToContentType(arrayOfByte, i);
/*     */   }
/*     */   
/*     */   static void closeConnection(URLConnection paramURLConnection) {
/* 632 */     if (paramURLConnection instanceof HttpURLConnection) {
/* 633 */       HttpURLConnection httpURLConnection = (HttpURLConnection)paramURLConnection;
/*     */       try {
/* 635 */         if (httpURLConnection.getResponseCode() < 400 && httpURLConnection
/* 636 */           .getInputStream() != null) {
/* 637 */           httpURLConnection.getInputStream().close();
/*     */         }
/* 639 */       } catch (IOException iOException) {
/*     */         try {
/* 641 */           if (httpURLConnection.getErrorStream() != null) {
/* 642 */             httpURLConnection.getErrorStream().close();
/*     */           }
/* 644 */         } catch (IOException iOException1) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\locator\Locator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */