package com.sun.javafx.geom;

public interface PathConsumer2D {
  void moveTo(float paramFloat1, float paramFloat2);
  
  void lineTo(float paramFloat1, float paramFloat2);
  
  void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  void curveTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  void closePath();
  
  void pathDone();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\PathConsumer2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */