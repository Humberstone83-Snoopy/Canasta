/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.PickRay;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGPerspectiveCamera
/*    */   extends NGCamera
/*    */ {
/*    */   private final boolean fixedEyeAtCameraZero;
/*    */   private double fovrad;
/*    */   private boolean verticalFieldOfView;
/*    */   
/*    */   public NGPerspectiveCamera(boolean paramBoolean) {
/* 49 */     this.fixedEyeAtCameraZero = paramBoolean;
/*    */   }
/*    */   
/*    */   public void setFieldOfView(float paramFloat) {
/* 53 */     this.fovrad = Math.toRadians(paramFloat);
/*    */   }
/*    */   
/*    */   public void setVerticalFieldOfView(boolean paramBoolean) {
/* 57 */     this.verticalFieldOfView = paramBoolean;
/*    */   }
/*    */ 
/*    */   
/*    */   public PickRay computePickRay(float paramFloat1, float paramFloat2, PickRay paramPickRay) {
/* 62 */     return PickRay.computePerspectivePickRay(paramFloat1, paramFloat2, this.fixedEyeAtCameraZero, this.viewWidth, this.viewHeight, this.fovrad, this.verticalFieldOfView, this.worldTransform, this.zNear, this.zFar, paramPickRay);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGPerspectiveCamera.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */