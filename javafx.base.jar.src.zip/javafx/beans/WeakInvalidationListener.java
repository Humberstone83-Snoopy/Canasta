/*    */ package javafx.beans;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WeakInvalidationListener
/*    */   implements InvalidationListener, WeakListener
/*    */ {
/*    */   private final WeakReference<InvalidationListener> ref;
/*    */   
/*    */   public WeakInvalidationListener(@NamedArg("listener") InvalidationListener paramInvalidationListener) {
/* 62 */     if (paramInvalidationListener == null) {
/* 63 */       throw new NullPointerException("Listener must be specified.");
/*    */     }
/* 65 */     this.ref = new WeakReference<>(paramInvalidationListener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean wasGarbageCollected() {
/* 73 */     return (this.ref.get() == null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invalidated(Observable paramObservable) {
/* 81 */     InvalidationListener invalidationListener = this.ref.get();
/* 82 */     if (invalidationListener != null) {
/* 83 */       invalidationListener.invalidated(paramObservable);
/*    */     
/*    */     }
/*    */     else {
/*    */       
/* 88 */       paramObservable.removeListener(this);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\WeakInvalidationListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */