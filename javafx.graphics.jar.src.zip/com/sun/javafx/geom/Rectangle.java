/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Rectangle
/*     */ {
/*     */   public int x;
/*     */   public int y;
/*     */   public int width;
/*     */   public int height;
/*     */   
/*     */   public Rectangle() {
/* 141 */     this(0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle(BaseBounds paramBaseBounds) {
/* 151 */     setBounds(paramBaseBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle(Rectangle paramRectangle) {
/* 164 */     this(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 178 */     this.x = paramInt1;
/* 179 */     this.y = paramInt2;
/* 180 */     this.width = paramInt3;
/* 181 */     this.height = paramInt4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle(int paramInt1, int paramInt2) {
/* 192 */     this(0, 0, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(Rectangle paramRectangle) {
/* 206 */     setBounds(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 227 */     reshape(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void setBounds(BaseBounds paramBaseBounds) {
/* 231 */     this.x = (int)Math.floor(paramBaseBounds.getMinX());
/* 232 */     this.y = (int)Math.floor(paramBaseBounds.getMinY());
/* 233 */     int i = (int)Math.ceil(paramBaseBounds.getMaxX());
/* 234 */     int j = (int)Math.ceil(paramBaseBounds.getMaxY());
/* 235 */     this.width = i - this.x;
/* 236 */     this.height = j - this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(int paramInt1, int paramInt2) {
/* 251 */     int i = this.width;
/* 252 */     int j = this.height;
/* 253 */     if ((i | j) < 0)
/*     */     {
/* 255 */       return false;
/*     */     }
/*     */     
/* 258 */     int k = this.x;
/* 259 */     int m = this.y;
/* 260 */     if (paramInt1 < k || paramInt2 < m) {
/* 261 */       return false;
/*     */     }
/* 263 */     i += k;
/* 264 */     j += m;
/*     */     
/* 266 */     return ((i < k || i > paramInt1) && (j < m || j > paramInt2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Rectangle paramRectangle) {
/* 280 */     return contains(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 298 */     int i = this.width;
/* 299 */     int j = this.height;
/* 300 */     if ((i | j | paramInt3 | paramInt4) < 0)
/*     */     {
/* 302 */       return false;
/*     */     }
/*     */     
/* 305 */     int k = this.x;
/* 306 */     int m = this.y;
/* 307 */     if (paramInt1 < k || paramInt2 < m) {
/* 308 */       return false;
/*     */     }
/* 310 */     i += k;
/* 311 */     paramInt3 += paramInt1;
/* 312 */     if (paramInt3 <= paramInt1)
/*     */     
/*     */     { 
/*     */ 
/*     */       
/* 317 */       if (i >= k || paramInt3 > i) return false;
/*     */       
/*     */       
/*     */        }
/*     */     
/* 322 */     else if (i >= k && paramInt3 > i) { return false; }
/*     */     
/* 324 */     j += m;
/* 325 */     paramInt4 += paramInt2;
/* 326 */     if (paramInt4 <= paramInt2)
/* 327 */     { if (j >= m || paramInt4 > j) return false;
/*     */        }
/* 329 */     else if (j >= m && paramInt4 > j) { return false; }
/*     */     
/* 331 */     return true;
/*     */   }
/*     */   
/*     */   public Rectangle intersection(Rectangle paramRectangle) {
/* 335 */     Rectangle rectangle = new Rectangle(this);
/* 336 */     rectangle.intersectWith(paramRectangle);
/* 337 */     return rectangle;
/*     */   }
/*     */   
/*     */   public void intersectWith(Rectangle paramRectangle) {
/* 341 */     if (paramRectangle == null) {
/*     */       return;
/*     */     }
/* 344 */     int i = this.x;
/* 345 */     int j = this.y;
/* 346 */     int k = paramRectangle.x;
/* 347 */     int m = paramRectangle.y;
/* 348 */     long l1 = i; l1 += this.width;
/* 349 */     long l2 = j; l2 += this.height;
/* 350 */     long l3 = k; l3 += paramRectangle.width;
/* 351 */     long l4 = m; l4 += paramRectangle.height;
/* 352 */     if (i < k) i = k; 
/* 353 */     if (j < m) j = m; 
/* 354 */     if (l1 > l3) l1 = l3; 
/* 355 */     if (l2 > l4) l2 = l4; 
/* 356 */     l1 -= i;
/* 357 */     l2 -= j;
/*     */ 
/*     */ 
/*     */     
/* 361 */     if (l1 < -2147483648L) l1 = -2147483648L; 
/* 362 */     if (l2 < -2147483648L) l2 = -2147483648L; 
/* 363 */     setBounds(i, j, (int)l1, (int)l2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void translate(int paramInt1, int paramInt2) {
/* 378 */     int i = this.x;
/* 379 */     int j = i + paramInt1;
/* 380 */     if (paramInt1 < 0) {
/*     */       
/* 382 */       if (j > i)
/*     */       {
/*     */         
/* 385 */         if (this.width >= 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 393 */           this.width += j - Integer.MIN_VALUE;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         j = Integer.MIN_VALUE;
/*     */       }
/*     */     
/*     */     }
/* 403 */     else if (j < i) {
/*     */       
/* 405 */       if (this.width >= 0) {
/*     */ 
/*     */         
/* 408 */         this.width += j - Integer.MAX_VALUE;
/*     */ 
/*     */         
/* 411 */         if (this.width < 0) this.width = Integer.MAX_VALUE; 
/*     */       } 
/* 413 */       j = Integer.MAX_VALUE;
/*     */     } 
/*     */     
/* 416 */     this.x = j;
/*     */     
/* 418 */     i = this.y;
/* 419 */     j = i + paramInt2;
/* 420 */     if (paramInt2 < 0) {
/*     */       
/* 422 */       if (j > i)
/*     */       {
/* 424 */         if (this.height >= 0) {
/* 425 */           this.height += j - Integer.MIN_VALUE;
/*     */         }
/*     */         
/* 428 */         j = Integer.MIN_VALUE;
/*     */       }
/*     */     
/*     */     }
/* 432 */     else if (j < i) {
/*     */       
/* 434 */       if (this.height >= 0) {
/* 435 */         this.height += j - Integer.MAX_VALUE;
/* 436 */         if (this.height < 0) this.height = Integer.MAX_VALUE; 
/*     */       } 
/* 438 */       j = Integer.MAX_VALUE;
/*     */     } 
/*     */     
/* 441 */     this.y = j;
/*     */   }
/*     */   
/*     */   public RectBounds toRectBounds() {
/* 445 */     return new RectBounds(this.x, this.y, (this.x + this.width), (this.y + this.height));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int paramInt1, int paramInt2) {
/* 476 */     if ((this.width | this.height) < 0) {
/* 477 */       this.x = paramInt1;
/* 478 */       this.y = paramInt2;
/* 479 */       this.width = this.height = 0;
/*     */       return;
/*     */     } 
/* 482 */     int i = this.x;
/* 483 */     int j = this.y;
/* 484 */     long l1 = this.width;
/* 485 */     long l2 = this.height;
/* 486 */     l1 += i;
/* 487 */     l2 += j;
/* 488 */     if (i > paramInt1) i = paramInt1; 
/* 489 */     if (j > paramInt2) j = paramInt2; 
/* 490 */     if (l1 < paramInt1) l1 = paramInt1; 
/* 491 */     if (l2 < paramInt2) l2 = paramInt2; 
/* 492 */     l1 -= i;
/* 493 */     l2 -= j;
/* 494 */     if (l1 > 2147483647L) l1 = 2147483647L; 
/* 495 */     if (l2 > 2147483647L) l2 = 2147483647L; 
/* 496 */     reshape(i, j, (int)l1, (int)l2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Rectangle paramRectangle) {
/* 523 */     long l1 = this.width;
/* 524 */     long l2 = this.height;
/* 525 */     if ((l1 | l2) < 0L) {
/* 526 */       reshape(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */     }
/* 528 */     long l3 = paramRectangle.width;
/* 529 */     long l4 = paramRectangle.height;
/* 530 */     if ((l3 | l4) < 0L) {
/*     */       return;
/*     */     }
/* 533 */     int i = this.x;
/* 534 */     int j = this.y;
/* 535 */     l1 += i;
/* 536 */     l2 += j;
/* 537 */     int k = paramRectangle.x;
/* 538 */     int m = paramRectangle.y;
/* 539 */     l3 += k;
/* 540 */     l4 += m;
/* 541 */     if (i > k) i = k; 
/* 542 */     if (j > m) j = m; 
/* 543 */     if (l1 < l3) l1 = l3; 
/* 544 */     if (l2 < l4) l2 = l4; 
/* 545 */     l1 -= i;
/* 546 */     l2 -= j;
/*     */ 
/*     */ 
/*     */     
/* 550 */     if (l1 > 2147483647L) l1 = 2147483647L; 
/* 551 */     if (l2 > 2147483647L) l2 = 2147483647L; 
/* 552 */     reshape(i, j, (int)l1, (int)l2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void grow(int paramInt1, int paramInt2) {
/* 579 */     long l1 = this.x;
/* 580 */     long l2 = this.y;
/* 581 */     long l3 = this.width;
/* 582 */     long l4 = this.height;
/* 583 */     l3 += l1;
/* 584 */     l4 += l2;
/*     */     
/* 586 */     l1 -= paramInt1;
/* 587 */     l2 -= paramInt2;
/* 588 */     l3 += paramInt1;
/* 589 */     l4 += paramInt2;
/*     */     
/* 591 */     if (l3 < l1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 596 */       l3 -= l1;
/* 597 */       if (l3 < -2147483648L) l3 = -2147483648L; 
/* 598 */       if (l1 < -2147483648L) { l1 = -2147483648L; }
/* 599 */       else if (l1 > 2147483647L) { l1 = 2147483647L; }
/*     */     
/*     */     } else {
/*     */       
/* 603 */       if (l1 < -2147483648L) { l1 = -2147483648L; }
/* 604 */       else if (l1 > 2147483647L) { l1 = 2147483647L; }
/* 605 */        l3 -= l1;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 610 */       if (l3 < -2147483648L) { l3 = -2147483648L; }
/* 611 */       else if (l3 > 2147483647L) { l3 = 2147483647L; }
/*     */     
/*     */     } 
/* 614 */     if (l4 < l2)
/*     */     
/* 616 */     { l4 -= l2;
/* 617 */       if (l4 < -2147483648L) l4 = -2147483648L; 
/* 618 */       if (l2 < -2147483648L) { l2 = -2147483648L; }
/* 619 */       else if (l2 > 2147483647L) { l2 = 2147483647L; }
/*     */        }
/* 621 */     else { if (l2 < -2147483648L) { l2 = -2147483648L; }
/* 622 */       else if (l2 > 2147483647L) { l2 = 2147483647L; }
/* 623 */        l4 -= l2;
/* 624 */       if (l4 < -2147483648L) { l4 = -2147483648L; }
/* 625 */       else if (l4 > 2147483647L) { l4 = 2147483647L; }
/*     */        }
/*     */     
/* 628 */     reshape((int)l1, (int)l2, (int)l3, (int)l4);
/*     */   }
/*     */   
/*     */   private void reshape(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 632 */     this.x = paramInt1;
/* 633 */     this.y = paramInt2;
/* 634 */     this.width = paramInt3;
/* 635 */     this.height = paramInt4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 642 */     return (this.width <= 0 || this.height <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 659 */     if (paramObject instanceof Rectangle) {
/* 660 */       Rectangle rectangle = (Rectangle)paramObject;
/* 661 */       return (this.x == rectangle.x && this.y == rectangle.y && this.width == rectangle.width && this.height == rectangle.height);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 666 */     return super.equals(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 671 */     int i = Float.floatToIntBits(this.x);
/* 672 */     i += Float.floatToIntBits(this.y) * 37;
/* 673 */     i += Float.floatToIntBits(this.width) * 43;
/* 674 */     i += Float.floatToIntBits(this.height) * 47;
/* 675 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 686 */     return getClass().getName() + "[x=" + getClass().getName() + ",y=" + this.x + ",width=" + this.y + ",height=" + this.width + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Rectangle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */