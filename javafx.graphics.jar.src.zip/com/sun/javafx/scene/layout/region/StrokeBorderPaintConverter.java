/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.paint.Color;
/*    */ import javafx.scene.paint.Paint;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StrokeBorderPaintConverter
/*    */   extends StyleConverter<ParsedValue<?, Paint>[], Paint[]>
/*    */ {
/* 41 */   private static final StrokeBorderPaintConverter STROKE_BORDER_PAINT_CONVERTER = new StrokeBorderPaintConverter();
/*    */ 
/*    */   
/*    */   public static StrokeBorderPaintConverter getInstance() {
/* 45 */     return STROKE_BORDER_PAINT_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Paint[] convert(ParsedValue<ParsedValue<?, Paint>[], Paint[]> paramParsedValue, Font paramFont) {
/* 53 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 54 */     Paint[] arrayOfPaint = new Paint[4];
/*    */     
/* 56 */     arrayOfPaint[0] = (arrayOfParsedValue.length > 0) ? 
/* 57 */       arrayOfParsedValue[0].convert(paramFont) : Color.BLACK;
/*    */     
/* 59 */     arrayOfPaint[1] = (arrayOfParsedValue.length > 1) ? 
/* 60 */       arrayOfParsedValue[1].convert(paramFont) : arrayOfPaint[0];
/*    */     
/* 62 */     arrayOfPaint[2] = (arrayOfParsedValue.length > 2) ? 
/* 63 */       arrayOfParsedValue[2].convert(paramFont) : arrayOfPaint[0];
/*    */     
/* 65 */     arrayOfPaint[3] = (arrayOfParsedValue.length > 3) ? 
/* 66 */       arrayOfParsedValue[3].convert(paramFont) : arrayOfPaint[1];
/*    */     
/* 68 */     return arrayOfPaint;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 72 */     return "StrokeBorderPaintConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\StrokeBorderPaintConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */