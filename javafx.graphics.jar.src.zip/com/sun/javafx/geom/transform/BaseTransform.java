/*     */ package com.sun.javafx.geom.transform;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseTransform
/*     */   implements CanTransformVec3d
/*     */ {
/*     */   protected static final int TYPE_UNKNOWN = -1;
/*     */   public static final int TYPE_IDENTITY = 0;
/*     */   public static final int TYPE_TRANSLATION = 1;
/*     */   public static final int TYPE_UNIFORM_SCALE = 2;
/*     */   public static final int TYPE_GENERAL_SCALE = 4;
/*     */   public static final int TYPE_MASK_SCALE = 6;
/*     */   public static final int TYPE_FLIP = 64;
/*     */   public static final int TYPE_QUADRANT_ROTATION = 8;
/*     */   public static final int TYPE_GENERAL_ROTATION = 16;
/*     */   public static final int TYPE_MASK_ROTATION = 24;
/*     */   public static final int TYPE_GENERAL_TRANSFORM = 32;
/*     */   public static final int TYPE_AFFINE2D_MASK = 127;
/*     */   public static final int TYPE_AFFINE_3D = 128;
/*  38 */   public static final BaseTransform IDENTITY_TRANSFORM = new Identity();
/*     */   static final double EPSILON_ABSOLUTE = 1.0E-5D;
/*     */   
/*  41 */   public enum Degree { IDENTITY,
/*  42 */     TRANSLATE_2D,
/*  43 */     AFFINE_2D,
/*  44 */     TRANSLATE_3D,
/*  45 */     AFFINE_3D; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void degreeError(Degree paramDegree) {
/* 249 */     throw new InternalError("does not support higher than " + paramDegree + " operations");
/*     */   }
/*     */ 
/*     */   
/*     */   public static BaseTransform getInstance(BaseTransform paramBaseTransform) {
/* 254 */     if (paramBaseTransform.isIdentity())
/* 255 */       return IDENTITY_TRANSFORM; 
/* 256 */     if (paramBaseTransform.isTranslateOrIdentity())
/* 257 */       return new Translate2D(paramBaseTransform); 
/* 258 */     if (paramBaseTransform.is2D()) {
/* 259 */       return new Affine2D(paramBaseTransform);
/*     */     }
/* 261 */     return new Affine3D(paramBaseTransform);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BaseTransform getInstance(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 268 */     if (paramDouble3 == 0.0D && paramDouble7 == 0.0D && paramDouble9 == 0.0D && paramDouble10 == 0.0D && paramDouble11 == 1.0D && paramDouble12 == 0.0D)
/*     */     {
/*     */       
/* 271 */       return getInstance(paramDouble1, paramDouble5, paramDouble2, paramDouble6, paramDouble4, paramDouble8);
/*     */     }
/* 273 */     return new Affine3D(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BaseTransform getInstance(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 283 */     if (paramDouble1 == 1.0D && paramDouble2 == 0.0D && paramDouble3 == 0.0D && paramDouble4 == 1.0D) {
/* 284 */       return getTranslateInstance(paramDouble5, paramDouble6);
/*     */     }
/* 286 */     return new Affine2D(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*     */   }
/*     */ 
/*     */   
/*     */   public static BaseTransform getTranslateInstance(double paramDouble1, double paramDouble2) {
/* 291 */     if (paramDouble1 == 0.0D && paramDouble2 == 0.0D) {
/* 292 */       return IDENTITY_TRANSFORM;
/*     */     }
/* 294 */     return new Translate2D(paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static BaseTransform getScaleInstance(double paramDouble1, double paramDouble2) {
/* 299 */     return getInstance(paramDouble1, 0.0D, 0.0D, paramDouble2, 0.0D, 0.0D);
/*     */   }
/*     */   
/*     */   public static BaseTransform getRotateInstance(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 303 */     Affine2D affine2D = new Affine2D();
/* 304 */     affine2D.setToRotation(paramDouble1, paramDouble2, paramDouble3);
/* 305 */     return affine2D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Degree getDegree();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getType();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isIdentity();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isTranslateOrIdentity();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean is2D();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract double getDeterminant();
/*     */ 
/*     */ 
/*     */   
/*     */   public double getMxx() {
/* 341 */     return 1.0D;
/* 342 */   } public double getMxy() { return 0.0D; }
/* 343 */   public double getMxz() { return 0.0D; }
/* 344 */   public double getMxt() { return 0.0D; }
/* 345 */   public double getMyx() { return 0.0D; }
/* 346 */   public double getMyy() { return 1.0D; }
/* 347 */   public double getMyz() { return 0.0D; }
/* 348 */   public double getMyt() { return 0.0D; }
/* 349 */   public double getMzx() { return 0.0D; }
/* 350 */   public double getMzy() { return 0.0D; }
/* 351 */   public double getMzz() { return 1.0D; } public double getMzt() {
/* 352 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Point2D transform(Point2D paramPoint2D1, Point2D paramPoint2D2);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Point2D inverseTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) throws NoninvertibleTransformException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Vec3d transform(Vec3d paramVec3d1, Vec3d paramVec3d2);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Vec3d deltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2);
/*     */ 
/*     */   
/*     */   public abstract Vec3d inverseTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract Vec3d inverseDeltaTransform(Vec3d paramVec3d1, Vec3d paramVec3d2) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract void transform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void transform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void transform(float[] paramArrayOffloat, int paramInt1, double[] paramArrayOfdouble, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void transform(double[] paramArrayOfdouble, int paramInt1, float[] paramArrayOffloat, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void deltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void deltaTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3);
/*     */ 
/*     */   
/*     */   public abstract void inverseTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract void inverseDeltaTransform(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, int paramInt3) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract void inverseTransform(double[] paramArrayOfdouble1, int paramInt1, double[] paramArrayOfdouble2, int paramInt2, int paramInt3) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract BaseBounds transform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2);
/*     */ 
/*     */   
/*     */   public abstract void transform(Rectangle paramRectangle1, Rectangle paramRectangle2);
/*     */ 
/*     */   
/*     */   public abstract BaseBounds inverseTransform(BaseBounds paramBaseBounds1, BaseBounds paramBaseBounds2) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract void inverseTransform(Rectangle paramRectangle1, Rectangle paramRectangle2) throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract Shape createTransformedShape(Shape paramShape);
/*     */ 
/*     */   
/*     */   public abstract void setToIdentity();
/*     */ 
/*     */   
/*     */   public abstract void setTransform(BaseTransform paramBaseTransform);
/*     */ 
/*     */   
/*     */   public abstract void invert() throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */ 
/*     */   
/*     */   public abstract void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2, double paramDouble3);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithScale(double paramDouble1, double paramDouble2, double paramDouble3);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithPreTranslation(double paramDouble1, double paramDouble2);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithPreConcatenation(BaseTransform paramBaseTransform);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithConcatenation(BaseTransform paramBaseTransform);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform deriveWithNewTransform(BaseTransform paramBaseTransform);
/*     */ 
/*     */   
/*     */   public abstract BaseTransform createInverse() throws NoninvertibleTransformException;
/*     */ 
/*     */   
/*     */   public abstract BaseTransform copy();
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 472 */     if (isIdentity()) return 0; 
/* 473 */     long l = 0L;
/* 474 */     l = l * 31L + Double.doubleToLongBits(getMzz());
/* 475 */     l = l * 31L + Double.doubleToLongBits(getMzy());
/* 476 */     l = l * 31L + Double.doubleToLongBits(getMzx());
/* 477 */     l = l * 31L + Double.doubleToLongBits(getMyz());
/* 478 */     l = l * 31L + Double.doubleToLongBits(getMxz());
/* 479 */     l = l * 31L + Double.doubleToLongBits(getMyy());
/* 480 */     l = l * 31L + Double.doubleToLongBits(getMyx());
/* 481 */     l = l * 31L + Double.doubleToLongBits(getMxy());
/* 482 */     l = l * 31L + Double.doubleToLongBits(getMxx());
/* 483 */     l = l * 31L + Double.doubleToLongBits(getMzt());
/* 484 */     l = l * 31L + Double.doubleToLongBits(getMyt());
/* 485 */     l = l * 31L + Double.doubleToLongBits(getMxt());
/* 486 */     return (int)l ^ (int)(l >> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 500 */     if (!(paramObject instanceof BaseTransform)) {
/* 501 */       return false;
/*     */     }
/*     */     
/* 504 */     BaseTransform baseTransform = (BaseTransform)paramObject;
/*     */     
/* 506 */     return (getMxx() == baseTransform.getMxx() && 
/* 507 */       getMxy() == baseTransform.getMxy() && 
/* 508 */       getMxz() == baseTransform.getMxz() && 
/* 509 */       getMxt() == baseTransform.getMxt() && 
/* 510 */       getMyx() == baseTransform.getMyx() && 
/* 511 */       getMyy() == baseTransform.getMyy() && 
/* 512 */       getMyz() == baseTransform.getMyz() && 
/* 513 */       getMyt() == baseTransform.getMyt() && 
/* 514 */       getMzx() == baseTransform.getMzx() && 
/* 515 */       getMzy() == baseTransform.getMzy() && 
/* 516 */       getMzz() == baseTransform.getMzz() && 
/* 517 */       getMzt() == baseTransform.getMzt());
/*     */   }
/*     */   
/*     */   static Point2D makePoint(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 521 */     if (paramPoint2D2 == null) {
/* 522 */       paramPoint2D2 = new Point2D();
/*     */     }
/* 524 */     return paramPoint2D2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean almostZero(double paramDouble) {
/* 530 */     return (paramDouble < 1.0E-5D && paramDouble > -1.0E-5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 539 */     return "Matrix: degree " + getDegree() + "\n" + 
/* 540 */       getMxx() + ", " + getMxy() + ", " + getMxz() + ", " + getMxt() + "\n" + 
/* 541 */       getMyx() + ", " + getMyy() + ", " + getMyz() + ", " + getMyt() + "\n" + 
/* 542 */       getMzx() + ", " + getMzy() + ", " + getMzz() + ", " + getMzt() + "\n";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\BaseTransform.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */