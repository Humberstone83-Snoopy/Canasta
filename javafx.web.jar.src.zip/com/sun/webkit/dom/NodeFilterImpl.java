/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.traversal.NodeFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeFilterImpl
/*     */   implements NodeFilter
/*     */ {
/*     */   private final long peer;
/*     */   public static final int FILTER_ACCEPT = 1;
/*     */   public static final int FILTER_REJECT = 2;
/*     */   public static final int FILTER_SKIP = 3;
/*     */   public static final int SHOW_ALL = -1;
/*     */   public static final int SHOW_ELEMENT = 1;
/*     */   public static final int SHOW_ATTRIBUTE = 2;
/*     */   public static final int SHOW_TEXT = 4;
/*     */   public static final int SHOW_CDATA_SECTION = 8;
/*     */   public static final int SHOW_ENTITY_REFERENCE = 16;
/*     */   public static final int SHOW_ENTITY = 32;
/*     */   public static final int SHOW_PROCESSING_INSTRUCTION = 64;
/*     */   public static final int SHOW_COMMENT = 128;
/*     */   public static final int SHOW_DOCUMENT = 256;
/*     */   public static final int SHOW_DOCUMENT_TYPE = 512;
/*     */   public static final int SHOW_DOCUMENT_FRAGMENT = 1024;
/*     */   public static final int SHOW_NOTATION = 2048;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  37 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  40 */       NodeFilterImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   NodeFilterImpl(long paramLong) {
/*  45 */     this.peer = paramLong;
/*  46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static NodeFilter create(long paramLong) {
/*  50 */     if (paramLong == 0L) return null; 
/*  51 */     return new NodeFilterImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  57 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  61 */     return (paramObject instanceof NodeFilterImpl && this.peer == ((NodeFilterImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  65 */     long l = this.peer;
/*  66 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(NodeFilter paramNodeFilter) {
/*  70 */     return (paramNodeFilter == null) ? 0L : ((NodeFilterImpl)paramNodeFilter).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static NodeFilter getImpl(long paramLong) {
/*  76 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short acceptNode(Node paramNode) {
/* 101 */     return acceptNodeImpl(getPeer(), 
/* 102 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native short acceptNodeImpl(long paramLong1, long paramLong2);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\NodeFilterImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */