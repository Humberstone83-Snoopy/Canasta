package com.sun.javafx.geom;

public interface PathIterator {
  public static final int WIND_EVEN_ODD = 0;
  
  public static final int WIND_NON_ZERO = 1;
  
  public static final int SEG_MOVETO = 0;
  
  public static final int SEG_LINETO = 1;
  
  public static final int SEG_QUADTO = 2;
  
  public static final int SEG_CUBICTO = 3;
  
  public static final int SEG_CLOSE = 4;
  
  int getWindingRule();
  
  boolean isDone();
  
  void next();
  
  int currentSegment(float[] paramArrayOffloat);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\PathIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */