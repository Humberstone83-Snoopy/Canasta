package javafx.collections;

import java.util.Map;
import javafx.beans.Observable;

public interface ObservableMap<K, V> extends Map<K, V>, Observable {
  void addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
  
  void removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\collections\ObservableMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */