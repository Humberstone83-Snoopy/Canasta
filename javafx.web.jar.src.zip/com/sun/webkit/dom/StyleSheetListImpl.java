/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.stylesheets.StyleSheet;
/*    */ import org.w3c.dom.stylesheets.StyleSheetList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StyleSheetListImpl
/*    */   implements StyleSheetList
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 37 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 40 */       StyleSheetListImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   StyleSheetListImpl(long paramLong) {
/* 45 */     this.peer = paramLong;
/* 46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static StyleSheetList create(long paramLong) {
/* 50 */     if (paramLong == 0L) return null; 
/* 51 */     return new StyleSheetListImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 57 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 61 */     return (paramObject instanceof StyleSheetListImpl && this.peer == ((StyleSheetListImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 65 */     long l = this.peer;
/* 66 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(StyleSheetList paramStyleSheetList) {
/* 70 */     return (paramStyleSheetList == null) ? 0L : ((StyleSheetListImpl)paramStyleSheetList).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static StyleSheetList getImpl(long paramLong) {
/* 76 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 82 */     return getLengthImpl(getPeer());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StyleSheet item(int paramInt) {
/* 90 */     return StyleSheetImpl.getImpl(itemImpl(getPeer(), paramInt));
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native int getLengthImpl(long paramLong);
/*    */   
/*    */   static native long itemImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\StyleSheetListImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */