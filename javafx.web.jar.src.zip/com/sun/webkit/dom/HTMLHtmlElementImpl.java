/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLHtmlElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLHtmlElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLHtmlElement
/*    */ {
/*    */   HTMLHtmlElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLHtmlElement getImpl(long paramLong) {
/* 36 */     return (HTMLHtmlElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native String getVersionImpl(long paramLong);
/*    */   
/*    */   public String getVersion() {
/* 42 */     return getVersionImpl(getPeer());
/*    */   }
/*    */   static native void setVersionImpl(long paramLong, String paramString);
/*    */   
/*    */   public void setVersion(String paramString) {
/* 47 */     setVersionImpl(getPeer(), paramString);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getManifest() {
/* 52 */     return getManifestImpl(getPeer());
/*    */   }
/*    */   static native String getManifestImpl(long paramLong);
/*    */   
/*    */   public void setManifest(String paramString) {
/* 57 */     setManifestImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setManifestImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLHtmlElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */