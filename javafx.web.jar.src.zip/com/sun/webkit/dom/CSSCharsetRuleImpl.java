/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.css.CSSCharsetRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSSCharsetRuleImpl
/*    */   extends CSSRuleImpl
/*    */   implements CSSCharsetRule
/*    */ {
/*    */   CSSCharsetRuleImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static CSSCharsetRule getImpl(long paramLong) {
/* 37 */     return (CSSCharsetRule)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getEncoding() {
/* 43 */     return getEncodingImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setEncoding(String paramString) throws DOMException {
/* 48 */     setEncodingImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getEncodingImpl(long paramLong);
/*    */   
/*    */   static native void setEncodingImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CSSCharsetRuleImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */