/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ import com.sun.glass.utils.NativeLibLoader;
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import java.nio.ByteOrder;
/*    */ import java.security.AccessController;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OS
/*    */ {
/*    */   static final int kCFURLPOSIXPathStyle = 0;
/*    */   static final int kCTFontOrientationDefault = 0;
/*    */   static final int kCTFontManagerScopeProcess = 1;
/*    */   static final int kCGBitmapByteOrder32Big = 16384;
/*    */   static final int kCGBitmapByteOrder32Little = 8192;
/*    */   
/*    */   static {
/* 37 */     AccessController.doPrivileged(() -> {
/*    */           NativeLibLoader.loadLibrary("javafx_font");
/*    */           return null;
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   static final int kCGBitmapByteOrder32Host = (ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN) ? 8192 : 16384;
/*    */   static final int kCGImageAlphaPremultipliedFirst = 2;
/*    */   static final int kCGImageAlphaNone = 0;
/*    */   static final int kCTWritingDirectionRightToLeft = 1;
/*    */   
/*    */   static final long CFStringCreate(String paramString) {
/* 54 */     char[] arrayOfChar = paramString.toCharArray();
/* 55 */     long l = kCFAllocatorDefault();
/* 56 */     return CFStringCreateWithCharacters(l, arrayOfChar, arrayOfChar.length);
/*    */   }
/*    */   
/*    */   static final native long CTParagraphStyleCreate(int paramInt);
/*    */   
/*    */   static final native long CTRunGetAttributes(long paramLong);
/*    */   
/*    */   static final native long CTRunGetGlyphCount(long paramLong);
/*    */   
/*    */   static final native double CTLineGetTypographicBounds(long paramLong);
/*    */   
/*    */   static final native long CTLineGetGlyphCount(long paramLong);
/*    */   
/*    */   static final native long CTLineGetGlyphRuns(long paramLong);
/*    */   
/*    */   static final native long CTLineCreateWithAttributedString(long paramLong);
/*    */   
/*    */   static final native boolean CTFontManagerRegisterFontsForURL(long paramLong1, int paramInt, long paramLong2);
/*    */   
/*    */   static final native long CTFontCreateWithName(long paramLong, double paramDouble, CGAffineTransform paramCGAffineTransform);
/*    */   
/*    */   static final native long CTFontCreateWithGraphicsFont(long paramLong1, double paramDouble, CGAffineTransform paramCGAffineTransform, long paramLong2);
/*    */   
/*    */   static final native long CTFontCreatePathForGlyph(long paramLong, short paramShort, CGAffineTransform paramCGAffineTransform);
/*    */   
/*    */   static final native void CGPathRelease(long paramLong);
/*    */   
/*    */   static final native long CGFontCreateWithDataProvider(long paramLong);
/*    */   
/*    */   static final native long CGDataProviderCreateWithURL(long paramLong);
/*    */   
/*    */   static final native void CGColorSpaceRelease(long paramLong);
/*    */   
/*    */   static final native long CGColorSpaceCreateDeviceRGB();
/*    */   
/*    */   static final native long CGColorSpaceCreateDeviceGray();
/*    */   
/*    */   static final native void CGContextTranslateCTM(long paramLong, double paramDouble1, double paramDouble2);
/*    */   
/*    */   static final native void CGContextSetRGBFillColor(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*    */   
/*    */   static final native void CGContextSetAllowsFontSubpixelQuantization(long paramLong, boolean paramBoolean);
/*    */   
/*    */   static final native void CGContextSetAllowsFontSubpixelPositioning(long paramLong, boolean paramBoolean);
/*    */   
/*    */   static final native void CGContextSetAllowsAntialiasing(long paramLong, boolean paramBoolean);
/*    */   
/*    */   static final native void CGContextSetAllowsFontSmoothing(long paramLong, boolean paramBoolean);
/*    */   
/*    */   static final native void CGContextRelease(long paramLong);
/*    */   
/*    */   static final native void CGContextFillRect(long paramLong, CGRect paramCGRect);
/*    */   
/*    */   static final native long CGBitmapContextCreate(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, int paramInt);
/*    */   
/*    */   static final native long CFURLCreateWithFileSystemPath(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean);
/*    */   
/*    */   static final native long CFStringCreateWithCharacters(long paramLong1, char[] paramArrayOfchar, long paramLong2);
/*    */   
/*    */   static final native void CFRelease(long paramLong);
/*    */   
/*    */   static final native long CFDictionaryGetValue(long paramLong1, long paramLong2);
/*    */   
/*    */   static final native long CFDictionaryCreateMutable(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*    */   
/*    */   static final native void CFDictionaryAddValue(long paramLong1, long paramLong2, long paramLong3);
/*    */   
/*    */   static final native long CFAttributedStringCreate(long paramLong1, long paramLong2, long paramLong3);
/*    */   
/*    */   static final native long CFArrayGetValueAtIndex(long paramLong1, long paramLong2);
/*    */   
/*    */   static final native long CFArrayGetCount(long paramLong);
/*    */   
/*    */   static final native long kCTParagraphStyleAttributeName();
/*    */   
/*    */   static final native long kCTFontAttributeName();
/*    */   
/*    */   static final native long kCFTypeDictionaryValueCallBacks();
/*    */   
/*    */   static final native long kCFTypeDictionaryKeyCallBacks();
/*    */   
/*    */   static final native long kCFAllocatorDefault();
/*    */   
/*    */   static final native int CTRunGetPositions(long paramLong, int paramInt, float[] paramArrayOffloat);
/*    */   
/*    */   static final native int CTRunGetStringIndices(long paramLong, int paramInt, int[] paramArrayOfint);
/*    */   
/*    */   static final native int CTRunGetGlyphs(long paramLong, int paramInt1, int paramInt2, int[] paramArrayOfint);
/*    */   
/*    */   static final native boolean CTFontGetBoundingRectForGlyphUsingTables(long paramLong, short paramShort1, short paramShort2, int[] paramArrayOfint);
/*    */   
/*    */   static final native double CTFontGetAdvancesForGlyphs(long paramLong, int paramInt, short paramShort, CGSize paramCGSize);
/*    */   
/*    */   static final native void CTFontDrawGlyphs(long paramLong1, short paramShort, double paramDouble1, double paramDouble2, long paramLong2);
/*    */   
/*    */   static final native String CTFontCopyAttributeDisplayName(long paramLong);
/*    */   
/*    */   static final native long CFStringCreateWithCharacters(long paramLong1, char[] paramArrayOfchar, long paramLong2, long paramLong3);
/*    */   
/*    */   static final native CGRect CGPathGetPathBoundingBox(long paramLong);
/*    */   
/*    */   static final native Path2D CGPathApply(long paramLong);
/*    */   
/*    */   static final native void CGRectApplyAffineTransform(CGRect paramCGRect, CGAffineTransform paramCGAffineTransform);
/*    */   
/*    */   static final native byte[] CGBitmapContextGetData(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\coretext\OS.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */