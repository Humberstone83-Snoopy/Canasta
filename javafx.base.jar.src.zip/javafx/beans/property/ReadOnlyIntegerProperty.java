/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.binding.IntegerExpression;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyIntegerProperty
/*     */   extends IntegerExpression
/*     */   implements ReadOnlyProperty<Number>
/*     */ {
/*     */   public String toString() {
/*  58 */     Object object = getBean();
/*  59 */     String str = getName();
/*  60 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyIntegerProperty [");
/*     */     
/*  62 */     if (object != null) {
/*  63 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  65 */     if (str != null && !str.equals("")) {
/*  66 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  68 */     stringBuilder.append("value: ").append(get()).append("]");
/*  69 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> ReadOnlyIntegerProperty readOnlyIntegerProperty(final ReadOnlyProperty<T> property) {
/*  92 */     if (property == null) {
/*  93 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/*     */     
/*  96 */     return (property instanceof ReadOnlyIntegerProperty) ? (ReadOnlyIntegerProperty)property : 
/*  97 */       new ReadOnlyIntegerPropertyBase()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int get() {
/* 112 */           this.valid = true;
/* 113 */           Number number = property.getValue();
/* 114 */           return (number == null) ? 0 : number.intValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 119 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 124 */           return property.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<Integer> asObject() {
/* 140 */     return new ReadOnlyObjectPropertyBase<Integer>()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 156 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 161 */           return ReadOnlyIntegerProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public Integer get() {
/* 166 */           this.valid = true;
/* 167 */           return ReadOnlyIntegerProperty.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyIntegerProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */