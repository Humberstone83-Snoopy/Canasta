/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.binding.BooleanExpression;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyBooleanProperty
/*     */   extends BooleanExpression
/*     */   implements ReadOnlyProperty<Boolean>
/*     */ {
/*     */   public String toString() {
/*  57 */     Object object = getBean();
/*  58 */     String str = getName();
/*  59 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyBooleanProperty [");
/*     */     
/*  61 */     if (object != null) {
/*  62 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  64 */     if (str != null && !str.equals("")) {
/*  65 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  67 */     stringBuilder.append("value: ").append(get()).append("]");
/*  68 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyBooleanProperty readOnlyBooleanProperty(final ReadOnlyProperty<Boolean> property) {
/*  90 */     if (property == null) {
/*  91 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/*     */     
/*  94 */     return (property instanceof ReadOnlyBooleanProperty) ? (ReadOnlyBooleanProperty)property : 
/*  95 */       new ReadOnlyBooleanPropertyBase()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean get() {
/* 110 */           this.valid = true;
/* 111 */           Boolean bool = property.getValue();
/* 112 */           return (bool == null) ? false : bool.booleanValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 117 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 122 */           return property.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<Boolean> asObject() {
/* 138 */     return new ReadOnlyObjectPropertyBase<Boolean>()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 154 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 159 */           return ReadOnlyBooleanProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public Boolean get() {
/* 164 */           this.valid = true;
/* 165 */           return ReadOnlyBooleanProperty.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyBooleanProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */