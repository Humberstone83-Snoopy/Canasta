/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.css.Counter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CounterImpl
/*    */   implements Counter
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 36 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 39 */       CounterImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   CounterImpl(long paramLong) {
/* 44 */     this.peer = paramLong;
/* 45 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static Counter create(long paramLong) {
/* 49 */     if (paramLong == 0L) return null; 
/* 50 */     return new CounterImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 56 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 60 */     return (paramObject instanceof CounterImpl && this.peer == ((CounterImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 64 */     long l = this.peer;
/* 65 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(Counter paramCounter) {
/* 69 */     return (paramCounter == null) ? 0L : ((CounterImpl)paramCounter).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static Counter getImpl(long paramLong) {
/* 75 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getIdentifier() {
/* 81 */     return getIdentifierImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getListStyle() {
/* 86 */     return getListStyleImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSeparator() {
/* 91 */     return getSeparatorImpl(getPeer());
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native String getIdentifierImpl(long paramLong);
/*    */   
/*    */   static native String getListStyleImpl(long paramLong);
/*    */   
/*    */   static native String getSeparatorImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\CounterImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */