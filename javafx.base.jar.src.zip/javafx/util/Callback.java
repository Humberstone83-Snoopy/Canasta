package javafx.util;

@FunctionalInterface
public interface Callback<P, R> {
  R call(P paramP);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\Callback.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */