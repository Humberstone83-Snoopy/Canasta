/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacDnDClipboard
/*    */   extends MacSystemClipboard
/*    */ {
/*    */   public MacDnDClipboard(String paramString) {
/* 30 */     super(paramString);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 34 */     return "Mac DnD Clipboard";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacDnDClipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */