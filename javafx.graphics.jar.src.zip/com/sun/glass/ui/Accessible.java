/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.SceneHelper;
/*     */ import com.sun.javafx.tk.quantum.QuantumToolkit;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Accessible
/*     */ {
/*     */   private EventHandler eventHandler;
/*     */   private View view;
/*     */   
/*     */   public static abstract class EventHandler
/*     */   {
/*     */     public Object getAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/*  49 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void executeAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {}
/*     */     
/*     */     public abstract AccessControlContext getAccessControlContext();
/*     */   }
/*     */   
/*     */   public EventHandler getEventHandler() {
/*  59 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void setEventHandler(EventHandler paramEventHandler) {
/*  63 */     this.eventHandler = paramEventHandler;
/*     */   }
/*     */   
/*     */   public void setView(View paramView) {
/*  67 */     this.view = paramView;
/*     */   }
/*     */   
/*     */   public View getView() {
/*  71 */     return this.view;
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  75 */     this.eventHandler = null;
/*  76 */     this.view = null;
/*     */   }
/*     */   
/*     */   public boolean isDisposed() {
/*  80 */     return (getNativeAccessible() == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  85 */     return getClass().getSimpleName() + " (" + getClass().getSimpleName() + ")";
/*     */   }
/*     */   
/*     */   protected boolean isIgnored() {
/*  89 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  90 */     if (accessibleRole == null) return true; 
/*  91 */     return (accessibleRole == AccessibleRole.NODE || accessibleRole == AccessibleRole.PARENT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Accessible getAccessible(Scene paramScene) {
/*  97 */     if (paramScene == null) return null; 
/*  98 */     return SceneHelper.getAccessible(paramScene);
/*     */   }
/*     */   
/*     */   protected Accessible getAccessible(Node paramNode) {
/* 102 */     if (paramNode == null) return null; 
/* 103 */     return NodeHelper.getAccessible(paramNode);
/*     */   }
/*     */   
/*     */   protected long getNativeAccessible(Node paramNode) {
/* 107 */     if (paramNode == null) return 0L; 
/* 108 */     Accessible accessible = getAccessible(paramNode);
/* 109 */     if (accessible == null) return 0L; 
/* 110 */     return accessible.getNativeAccessible();
/*     */   }
/*     */   
/*     */   protected Accessible getContainerAccessible(AccessibleRole paramAccessibleRole) {
/* 114 */     Node node = (Node)getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/* 115 */     while (node != null) {
/* 116 */       Accessible accessible = getAccessible(node);
/* 117 */       AccessibleRole accessibleRole = (AccessibleRole)accessible.getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 118 */       if (accessibleRole == paramAccessibleRole) return accessible; 
/* 119 */       node = (Node)accessible.getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/*     */     } 
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AccessControlContext getAccessControlContext() {
/* 129 */     AccessControlContext accessControlContext = null;
/*     */     try {
/* 131 */       accessControlContext = this.eventHandler.getAccessControlContext();
/* 132 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 135 */     return accessControlContext;
/*     */   }
/*     */   
/*     */   private class GetAttribute implements PrivilegedAction<Object> {
/*     */     AccessibleAttribute attribute;
/*     */     
/*     */     public Object run() {
/* 142 */       Object object = Accessible.this.eventHandler.getAttribute(this.attribute, this.parameters);
/* 143 */       if (object != null) {
/* 144 */         Class<?> clazz = this.attribute.getReturnType();
/* 145 */         if (clazz != null) {
/*     */           try {
/* 147 */             clazz.cast(object);
/* 148 */           } catch (Exception exception) {
/*     */ 
/*     */             
/* 151 */             String str = "The expected return type for the " + this.attribute + " attribute is " + clazz.getSimpleName() + " but found " + object.getClass().getSimpleName();
/* 152 */             System.err.println(str);
/* 153 */             return null;
/*     */           } 
/*     */         }
/*     */       } 
/* 157 */       return object;
/*     */     }
/*     */     Object[] parameters;
/*     */     private GetAttribute() {} }
/* 161 */   private GetAttribute getAttribute = new GetAttribute();
/*     */   
/*     */   public Object getAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 164 */     AccessControlContext accessControlContext = getAccessControlContext();
/* 165 */     if (accessControlContext == null) return null; 
/* 166 */     return QuantumToolkit.runWithoutRenderLock(() -> {
/*     */           this.getAttribute.attribute = paramAccessibleAttribute;
/*     */           this.getAttribute.parameters = paramArrayOfObject;
/*     */           return AccessController.doPrivileged(this.getAttribute, paramAccessControlContext);
/*     */         });
/*     */   }
/*     */   private class ExecuteAction implements PrivilegedAction<Void> { AccessibleAction action; Object[] parameters;
/*     */     
/*     */     private ExecuteAction() {}
/*     */     
/*     */     public Void run() {
/* 177 */       Accessible.this.eventHandler.executeAction(this.action, this.parameters);
/* 178 */       return null;
/*     */     } }
/*     */ 
/*     */   
/* 182 */   private ExecuteAction executeAction = new ExecuteAction();
/*     */   
/*     */   public void executeAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 185 */     AccessControlContext accessControlContext = getAccessControlContext();
/* 186 */     if (accessControlContext == null)
/* 187 */       return;  QuantumToolkit.runWithoutRenderLock(() -> {
/*     */           this.executeAction.action = paramAccessibleAction;
/*     */           this.executeAction.parameters = paramArrayOfObject;
/*     */           return AccessController.<Void>doPrivileged(this.executeAction, paramAccessControlContext);
/*     */         });
/*     */   }
/*     */   
/*     */   protected abstract long getNativeAccessible();
/*     */   
/*     */   public abstract void sendNotification(AccessibleAttribute paramAccessibleAttribute);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Accessible.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */