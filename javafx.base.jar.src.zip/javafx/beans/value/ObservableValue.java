package javafx.beans.value;

import javafx.beans.Observable;

public interface ObservableValue<T> extends Observable {
  void addListener(ChangeListener<? super T> paramChangeListener);
  
  void removeListener(ChangeListener<? super T> paramChangeListener);
  
  T getValue();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\value\ObservableValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */