/*    */ package com.sun.javafx.stage;
/*    */ 
/*    */ import com.sun.javafx.embed.HostInterface;
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.stage.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmbeddedWindow
/*    */   extends Window
/*    */ {
/*    */   private HostInterface host;
/*    */   
/*    */   static {
/* 42 */     EmbeddedWindowHelper.setEmbeddedWindowAccessor(new EmbeddedWindowHelper.EmbeddedWindowAccessor() {
/*    */           public void doVisibleChanging(Window param1Window, boolean param1Boolean) {
/* 44 */             ((EmbeddedWindow)param1Window).doVisibleChanging(param1Boolean);
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public EmbeddedWindow(HostInterface paramHostInterface) {
/* 52 */     this.host = paramHostInterface;
/* 53 */     EmbeddedWindowHelper.initHelper(this);
/*    */   }
/*    */   
/*    */   public HostInterface getHost() {
/* 57 */     return this.host;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setScene(Scene paramScene) {
/* 64 */     super.setScene(paramScene);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void show() {
/* 71 */     super.show();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void doVisibleChanging(boolean paramBoolean) {
/* 79 */     Toolkit toolkit = Toolkit.getToolkit();
/* 80 */     if (paramBoolean && WindowHelper.getPeer(this) == null) {
/*    */       
/* 82 */       WindowHelper.setPeer(this, toolkit.createTKEmbeddedStage(this.host, 
/* 83 */             WindowHelper.getAccessControlContext(this)));
/* 84 */       WindowHelper.setPeerListener(this, new WindowPeerListener(this));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\stage\EmbeddedWindow.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */