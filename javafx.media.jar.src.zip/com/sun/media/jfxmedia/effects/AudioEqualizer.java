package com.sun.media.jfxmedia.effects;

public interface AudioEqualizer {
  public static final int MAX_NUM_BANDS = 64;
  
  boolean getEnabled();
  
  void setEnabled(boolean paramBoolean);
  
  EqualizerBand addBand(double paramDouble1, double paramDouble2, double paramDouble3);
  
  boolean removeBand(double paramDouble);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\effects\AudioEqualizer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */