/*     */ package javafx.beans.property;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ListExpression;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyListProperty<E>
/*     */   extends ListExpression<E>
/*     */   implements ReadOnlyProperty<ObservableList<E>>
/*     */ {
/*     */   public void bindContentBidirectional(ObservableList<E> paramObservableList) {
/*  66 */     Bindings.bindContentBidirectional(this, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContentBidirectional(Object paramObject) {
/*  78 */     Bindings.unbindContentBidirectional(this, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindContent(ObservableList<E> paramObservableList) {
/*  94 */     Bindings.bindContent(this, paramObservableList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindContent(Object paramObject) {
/* 106 */     Bindings.unbindContent(this, paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 111 */     if (this == paramObject) {
/* 112 */       return true;
/*     */     }
/* 114 */     if (!(paramObject instanceof List)) {
/* 115 */       return false;
/*     */     }
/* 117 */     List list = (List)paramObject;
/*     */     
/* 119 */     if (size() != list.size()) {
/* 120 */       return false;
/*     */     }
/*     */     
/* 123 */     ListIterator<E> listIterator = listIterator();
/* 124 */     ListIterator<Object> listIterator1 = list.listIterator();
/* 125 */     while (listIterator.hasNext() && listIterator1.hasNext()) {
/* 126 */       E e = listIterator.next();
/* 127 */       Object object = listIterator1.next();
/* 128 */       if ((e == null) ? (object == null) : e.equals(object))
/* 129 */         continue;  return false;
/*     */     } 
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 136 */     int i = 1;
/* 137 */     for (E e : this)
/* 138 */       i = 31 * i + ((e == null) ? 0 : e.hashCode()); 
/* 139 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     Object object = getBean();
/* 149 */     String str = getName();
/* 150 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyListProperty [");
/*     */     
/* 152 */     if (object != null) {
/* 153 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 155 */     if (str != null && !str.equals("")) {
/* 156 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 158 */     stringBuilder.append("value: ").append(get()).append("]");
/* 159 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyListProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */