/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RoundRectIterator
/*     */   implements PathIterator
/*     */ {
/*     */   double x;
/*     */   double y;
/*     */   double w;
/*     */   double h;
/*     */   double aw;
/*     */   double ah;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   private static final double angle = 0.7853981633974483D;
/*     */   
/*     */   RoundRectIterator(RoundRectangle2D paramRoundRectangle2D, BaseTransform paramBaseTransform) {
/*  44 */     this.x = paramRoundRectangle2D.x;
/*  45 */     this.y = paramRoundRectangle2D.y;
/*  46 */     this.w = paramRoundRectangle2D.width;
/*  47 */     this.h = paramRoundRectangle2D.height;
/*  48 */     this.aw = Math.min(this.w, Math.abs(paramRoundRectangle2D.arcWidth));
/*  49 */     this.ah = Math.min(this.h, Math.abs(paramRoundRectangle2D.arcHeight));
/*  50 */     this.transform = paramBaseTransform;
/*  51 */     if (this.aw < 0.0D || this.ah < 0.0D)
/*     */     {
/*  53 */       this.index = ctrlpts.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  64 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/*  72 */     return (this.index >= ctrlpts.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/*  81 */     this.index++;
/*  82 */     if (this.index < ctrlpts.length && this.aw == 0.0D && this.ah == 0.0D && types[this.index] == 3)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  87 */       this.index++;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  92 */   private static final double a = 1.0D - Math.cos(0.7853981633974483D);
/*  93 */   private static final double b = Math.tan(0.7853981633974483D);
/*  94 */   private static final double c = Math.sqrt(1.0D + b * b) - 1.0D + a;
/*  95 */   private static final double cv = 1.3333333333333333D * a * b / c;
/*  96 */   private static final double acv = (1.0D - cv) / 2.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final double[][] ctrlpts = new double[][] { { 0.0D, 0.0D, 0.0D, 0.5D }, { 0.0D, 0.0D, 1.0D, -0.5D }, { 0.0D, 0.0D, 1.0D, -acv, 0.0D, acv, 1.0D, 0.0D, 0.0D, 0.5D, 1.0D, 0.0D }, { 1.0D, -0.5D, 1.0D, 0.0D }, { 1.0D, -acv, 1.0D, 0.0D, 1.0D, 0.0D, 1.0D, -acv, 1.0D, 0.0D, 1.0D, -0.5D }, { 1.0D, 0.0D, 0.0D, 0.5D }, { 1.0D, 0.0D, 0.0D, acv, 1.0D, -acv, 0.0D, 0.0D, 1.0D, -0.5D, 0.0D, 0.0D }, { 0.0D, 0.5D, 0.0D, 0.0D }, { 0.0D, acv, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D, acv, 0.0D, 0.0D, 0.0D, 0.5D }, {} };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private static final int[] types = new int[] { 0, 1, 3, 1, 3, 1, 3, 1, 3, 4 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/* 151 */     if (isDone()) {
/* 152 */       throw new NoSuchElementException("roundrect iterator out of bounds");
/*     */     }
/* 154 */     double[] arrayOfDouble = ctrlpts[this.index];
/* 155 */     byte b1 = 0;
/* 156 */     for (byte b2 = 0; b2 < arrayOfDouble.length; b2 += 4) {
/* 157 */       paramArrayOffloat[b1++] = (float)(this.x + arrayOfDouble[b2 + 0] * this.w + arrayOfDouble[b2 + 1] * this.aw);
/* 158 */       paramArrayOffloat[b1++] = (float)(this.y + arrayOfDouble[b2 + 2] * this.h + arrayOfDouble[b2 + 3] * this.ah);
/*     */     } 
/* 160 */     if (this.transform != null) {
/* 161 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, b1 / 2);
/*     */     }
/* 163 */     return types[this.index];
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\RoundRectIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */