/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.scene.text.FontHelper;
/*     */ import com.sun.javafx.tk.FontLoader;
/*     */ import com.sun.javafx.tk.FontMetrics;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.FontPosture;
/*     */ import javafx.scene.text.FontWeight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrismFontLoader
/*     */   extends FontLoader
/*     */ {
/*  40 */   private static PrismFontLoader theInstance = new PrismFontLoader(); public static PrismFontLoader getInstance() {
/*  41 */     return theInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean embeddedFontsLoaded = false;
/*     */ 
/*     */   
/*     */   Properties loadEmbeddedFontDefinitions() {
/*  50 */     Properties properties = new Properties();
/*     */ 
/*     */     
/*  53 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*  54 */     if (classLoader == null) return properties; 
/*  55 */     URL uRL = classLoader.getResource("META-INF/fonts.mf");
/*  56 */     if (uRL == null) return properties;
/*     */ 
/*     */     
/*  59 */     try { InputStream inputStream = uRL.openStream(); 
/*  60 */       try { properties.load(inputStream);
/*  61 */         if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception exception)
/*  62 */     { exception.printStackTrace(); }
/*     */     
/*  64 */     return properties;
/*     */   }
/*     */   
/*     */   private void loadEmbeddedFonts() {
/*  68 */     if (!this.embeddedFontsLoaded) {
/*  69 */       FontFactory fontFactory = getFontFactoryFromPipeline();
/*  70 */       if (!fontFactory.hasPermission()) {
/*  71 */         this.embeddedFontsLoaded = true;
/*     */         return;
/*     */       } 
/*  74 */       Properties properties = loadEmbeddedFontDefinitions();
/*  75 */       Enumeration<String> enumeration = properties.keys();
/*  76 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*  77 */       while (enumeration.hasMoreElements()) {
/*  78 */         String str1 = enumeration.nextElement();
/*  79 */         String str2 = properties.getProperty(str1);
/*  80 */         if (str2.startsWith("/")) {
/*  81 */           str2 = str2.substring(1); 
/*  82 */           try { InputStream inputStream = classLoader.getResourceAsStream(str2); 
/*  83 */             try { fontFactory.loadEmbeddedFont(str1, inputStream, 0.0F, true, false);
/*  84 */               if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (Exception exception) {}
/*     */         } 
/*     */       } 
/*     */       
/*  88 */       this.embeddedFontsLoaded = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Font[] createFonts(PGFont[] paramArrayOfPGFont) {
/*  93 */     if (paramArrayOfPGFont == null || paramArrayOfPGFont.length == 0) {
/*  94 */       return null;
/*     */     }
/*  96 */     Font[] arrayOfFont = new Font[paramArrayOfPGFont.length];
/*  97 */     for (byte b = 0; b < paramArrayOfPGFont.length; b++) {
/*  98 */       arrayOfFont[b] = createFont(paramArrayOfPGFont[b]);
/*     */     }
/* 100 */     return arrayOfFont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font[] loadFont(InputStream paramInputStream, double paramDouble, boolean paramBoolean) {
/* 107 */     FontFactory fontFactory = getFontFactoryFromPipeline();
/*     */     
/* 109 */     PGFont[] arrayOfPGFont = fontFactory.loadEmbeddedFont((String)null, paramInputStream, (float)paramDouble, true, paramBoolean);
/* 110 */     return createFonts(arrayOfPGFont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font[] loadFont(String paramString, double paramDouble, boolean paramBoolean) {
/* 117 */     FontFactory fontFactory = getFontFactoryFromPipeline();
/*     */     
/* 119 */     PGFont[] arrayOfPGFont = fontFactory.loadEmbeddedFont((String)null, paramString, (float)paramDouble, true, paramBoolean);
/* 120 */     return createFonts(arrayOfPGFont);
/*     */   }
/*     */ 
/*     */   
/*     */   private Font createFont(PGFont paramPGFont) {
/* 125 */     return FontHelper.nativeFont(paramPGFont, paramPGFont
/* 126 */         .getName(), paramPGFont
/* 127 */         .getFamilyName(), paramPGFont
/* 128 */         .getStyleName(), paramPGFont
/* 129 */         .getSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFamilies() {
/* 139 */     loadEmbeddedFonts();
/* 140 */     return Arrays.asList(getFontFactoryFromPipeline()
/* 141 */         .getFontFamilyNames());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFontNames() {
/* 151 */     loadEmbeddedFonts();
/* 152 */     return Arrays.asList(getFontFactoryFromPipeline().getFontFullNames());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getFontNames(String paramString) {
/* 163 */     loadEmbeddedFonts();
/* 164 */     return Arrays.asList(getFontFactoryFromPipeline()
/* 165 */         .getFontFullNames(paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font font(String paramString, FontWeight paramFontWeight, FontPosture paramFontPosture, float paramFloat) {
/* 190 */     FontFactory fontFactory = getFontFactoryFromPipeline();
/* 191 */     if (!this.embeddedFontsLoaded && !fontFactory.isPlatformFont(paramString)) {
/* 192 */       loadEmbeddedFonts();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 198 */     boolean bool1 = (paramFontWeight != null && paramFontWeight.ordinal() >= FontWeight.BOLD.ordinal()) ? true : false;
/* 199 */     boolean bool2 = (paramFontPosture == FontPosture.ITALIC) ? true : false;
/* 200 */     PGFont pGFont = fontFactory.createFont(paramString, bool1, bool2, paramFloat);
/*     */ 
/*     */     
/* 203 */     return FontHelper.nativeFont(pGFont, pGFont.getName(), pGFont
/* 204 */         .getFamilyName(), pGFont
/* 205 */         .getStyleName(), paramFloat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadFont(Font paramFont) {
/* 213 */     FontFactory fontFactory = getFontFactoryFromPipeline();
/* 214 */     String str1 = paramFont.getName();
/* 215 */     if (!this.embeddedFontsLoaded && !fontFactory.isPlatformFont(str1)) {
/* 216 */       loadEmbeddedFonts();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     PGFont pGFont = fontFactory.createFont(str1, (float)paramFont.getSize());
/*     */ 
/*     */     
/* 227 */     String str2 = pGFont.getName();
/* 228 */     String str3 = pGFont.getFamilyName();
/* 229 */     String str4 = pGFont.getStyleName();
/* 230 */     FontHelper.setNativeFont(paramFont, pGFont, str2, str3, str4);
/*     */   }
/*     */   
/*     */   public FontMetrics getFontMetrics(Font paramFont) {
/* 234 */     if (paramFont != null) {
/* 235 */       PGFont pGFont = (PGFont)FontHelper.getNativeFont(paramFont);
/* 236 */       Metrics metrics = PrismFontUtils.getFontMetrics(pGFont);
/*     */       
/* 238 */       float f1 = -metrics.getAscent();
/* 239 */       float f2 = -metrics.getAscent();
/* 240 */       float f3 = metrics.getXHeight();
/* 241 */       float f4 = metrics.getDescent();
/*     */       
/* 243 */       float f5 = metrics.getDescent();
/* 244 */       float f6 = metrics.getLineGap();
/* 245 */       return FontMetrics.createFontMetrics(f1, f2, f3, f4, f5, f6, paramFont);
/*     */     } 
/* 247 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getCharWidth(char paramChar, Font paramFont) {
/* 252 */     PGFont pGFont = (PGFont)FontHelper.getNativeFont(paramFont);
/* 253 */     return (float)PrismFontUtils.getCharWidth(pGFont, paramChar);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getSystemFontSize() {
/* 259 */     return PrismFontFactory.getSystemFontSize();
/*     */   }
/*     */   
/* 262 */   FontFactory installedFontFactory = null;
/*     */   private FontFactory getFontFactoryFromPipeline() {
/* 264 */     if (this.installedFontFactory != null) {
/* 265 */       return this.installedFontFactory;
/*     */     }
/*     */     try {
/* 268 */       Class<?> clazz = Class.forName("com.sun.prism.GraphicsPipeline");
/* 269 */       Method method1 = clazz.getMethod("getPipeline", (Class[])null);
/* 270 */       Object object1 = method1.invoke(null, new Object[0]);
/* 271 */       Method method2 = clazz.getMethod("getFontFactory", (Class[])null);
/* 272 */       Object object2 = method2.invoke(object1, new Object[0]);
/* 273 */       this.installedFontFactory = (FontFactory)object2;
/* 274 */     } catch (Exception exception) {}
/*     */     
/* 276 */     return this.installedFontFactory;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismFontLoader.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */