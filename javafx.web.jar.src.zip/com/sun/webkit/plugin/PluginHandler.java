package com.sun.webkit.plugin;

import java.net.URL;

interface PluginHandler {
  String getName();
  
  String getFileName();
  
  String getDescription();
  
  String[] supportedMIMETypes();
  
  boolean isSupportedMIMEType(String paramString);
  
  boolean isSupportedPlatform();
  
  Plugin createPlugin(URL paramURL, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\plugin\PluginHandler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */