/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ import javafx.css.StyleOrigin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CalculatedValue
/*    */ {
/* 31 */   public static final CalculatedValue SKIP = new CalculatedValue(new int[0], null, false);
/*    */   
/*    */   private final Object value;
/*    */   
/*    */   public CalculatedValue(Object paramObject, StyleOrigin paramStyleOrigin, boolean paramBoolean) {
/* 36 */     this.value = paramObject;
/* 37 */     this.origin = paramStyleOrigin;
/* 38 */     this.relative = paramBoolean;
/*    */   }
/*    */   private final StyleOrigin origin; private final boolean relative;
/*    */   public Object getValue() {
/* 42 */     return this.value;
/*    */   }
/*    */   
/*    */   public StyleOrigin getOrigin() {
/* 46 */     return this.origin;
/*    */   }
/*    */   
/*    */   public boolean isRelative() {
/* 50 */     return this.relative;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 54 */     return '{' + 
/*    */ 
/*    */       
/* 57 */       String.valueOf(this.value) + ", " + 
/* 58 */       this.origin + ", " + 
/* 59 */       this.relative + '}';
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 66 */     if (paramObject == null) {
/* 67 */       return false;
/*    */     }
/*    */     
/* 70 */     if (getClass() != paramObject.getClass()) {
/* 71 */       return false;
/*    */     }
/*    */     
/* 74 */     CalculatedValue calculatedValue = (CalculatedValue)paramObject;
/*    */     
/* 76 */     if (this.relative != calculatedValue.relative) {
/* 77 */       return false;
/*    */     }
/*    */     
/* 80 */     if (this.origin != calculatedValue.origin) {
/* 81 */       return false;
/*    */     }
/*    */     
/* 84 */     if ((this.value == null) ? (calculatedValue.value != null) : !this.value.equals(calculatedValue.value)) {
/* 85 */       return false;
/*    */     }
/*    */     
/* 88 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\CalculatedValue.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */