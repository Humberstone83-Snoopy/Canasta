/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteGlyphRunAnalysis
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteGlyphRunAnalysis(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   byte[] CreateAlphaTexture(int paramInt, RECT paramRECT) {
/* 34 */     return OS.CreateAlphaTexture(this.ptr, paramInt, paramRECT);
/*    */   }
/*    */   
/*    */   RECT GetAlphaTextureBounds(int paramInt) {
/* 38 */     return OS.GetAlphaTextureBounds(this.ptr, paramInt);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteGlyphRunAnalysis.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */