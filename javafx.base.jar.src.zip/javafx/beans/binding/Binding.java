package javafx.beans.binding;

import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;

public interface Binding<T> extends ObservableValue<T> {
  boolean isValid();
  
  void invalidate();
  
  ObservableList<?> getDependencies();
  
  void dispose();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\Binding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */