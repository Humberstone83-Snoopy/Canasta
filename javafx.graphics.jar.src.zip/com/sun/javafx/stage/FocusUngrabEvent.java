/*    */ package com.sun.javafx.stage;
/*    */ 
/*    */ import javafx.event.Event;
/*    */ import javafx.event.EventTarget;
/*    */ import javafx.event.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FocusUngrabEvent
/*    */   extends Event
/*    */ {
/*    */   private static final long serialVersionUID = 20121107L;
/* 35 */   public static final EventType<FocusUngrabEvent> FOCUS_UNGRAB = (EventType)new EventType<>(Event.ANY, "FOCUS_UNGRAB");
/*    */ 
/*    */   
/* 38 */   public static final EventType<FocusUngrabEvent> ANY = FOCUS_UNGRAB;
/*    */   
/*    */   public FocusUngrabEvent() {
/* 41 */     super((EventType)FOCUS_UNGRAB);
/*    */   }
/*    */ 
/*    */   
/*    */   public FocusUngrabEvent(Object paramObject, EventTarget paramEventTarget) {
/* 46 */     super(paramObject, paramEventTarget, (EventType)FOCUS_UNGRAB);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\stage\FocusUngrabEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */