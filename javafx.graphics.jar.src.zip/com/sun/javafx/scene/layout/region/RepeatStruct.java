/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.scene.layout.BackgroundRepeat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RepeatStruct
/*    */ {
/*    */   public final BackgroundRepeat repeatX;
/*    */   public final BackgroundRepeat repeatY;
/*    */   
/*    */   public RepeatStruct(BackgroundRepeat paramBackgroundRepeat1, BackgroundRepeat paramBackgroundRepeat2) {
/* 40 */     this.repeatX = paramBackgroundRepeat1;
/* 41 */     this.repeatY = paramBackgroundRepeat2;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\RepeatStruct.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */