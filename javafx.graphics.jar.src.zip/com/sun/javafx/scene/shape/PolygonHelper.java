/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Polygon;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PolygonHelper
/*    */   extends ShapeHelper
/*    */ {
/* 45 */   private static final PolygonHelper theInstance = new PolygonHelper(); static {
/* 46 */     Utils.forceInit(Polygon.class);
/*    */   }
/*    */   private static PolygonAccessor polygonAccessor;
/*    */   private static PolygonHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Polygon paramPolygon) {
/* 54 */     setHelper(paramPolygon, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return polygonAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     polygonAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 71 */     return polygonAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 76 */     return polygonAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setPolygonAccessor(PolygonAccessor paramPolygonAccessor) {
/* 80 */     if (polygonAccessor != null) {
/* 81 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 84 */     polygonAccessor = paramPolygonAccessor;
/*    */   }
/*    */   
/*    */   public static interface PolygonAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\PolygonHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */