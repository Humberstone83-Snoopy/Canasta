/*    */ package com.sun.webkit.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCMouseWheelEvent
/*    */ {
/*    */   private final long when;
/*    */   private final int x;
/*    */   private final int y;
/*    */   private final int screenX;
/*    */   private final int screenY;
/*    */   private final float deltaX;
/*    */   private final float deltaY;
/*    */   private final boolean shift;
/*    */   private final boolean control;
/*    */   private final boolean alt;
/*    */   private final boolean meta;
/*    */   
/*    */   public WCMouseWheelEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, float paramFloat1, float paramFloat2) {
/* 49 */     this.x = paramInt1;
/* 50 */     this.y = paramInt2;
/* 51 */     this.screenX = paramInt3;
/* 52 */     this.screenY = paramInt4;
/* 53 */     this.when = paramLong;
/* 54 */     this.shift = paramBoolean1;
/* 55 */     this.control = paramBoolean2;
/* 56 */     this.alt = paramBoolean3;
/* 57 */     this.meta = paramBoolean4;
/* 58 */     this.deltaX = paramFloat1;
/* 59 */     this.deltaY = paramFloat2;
/*    */   }
/*    */   public long getWhen() {
/* 62 */     return this.when;
/*    */   }
/* 64 */   public int getX() { return this.x; }
/* 65 */   public int getY() { return this.y; }
/* 66 */   public int getScreenX() { return this.screenX; } public int getScreenY() {
/* 67 */     return this.screenY;
/*    */   }
/* 69 */   public boolean isShiftDown() { return this.shift; }
/* 70 */   public boolean isControlDown() { return this.control; }
/* 71 */   public boolean isAltDown() { return this.alt; } public boolean isMetaDown() {
/* 72 */     return this.meta;
/*    */   }
/* 74 */   public float getDeltaX() { return this.deltaX; } public float getDeltaY() {
/* 75 */     return this.deltaY;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\event\WCMouseWheelEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */