package com.sun.javafx.menu;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyBooleanProperty;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;

public interface MenuBase extends MenuItemBase {
  boolean isShowing();
  
  ReadOnlyBooleanProperty showingProperty();
  
  ObjectProperty<EventHandler<Event>> onShowingProperty();
  
  void setOnShowing(EventHandler<Event> paramEventHandler);
  
  EventHandler<Event> getOnShowing();
  
  ObjectProperty<EventHandler<Event>> onShownProperty();
  
  void setOnShown(EventHandler<Event> paramEventHandler);
  
  EventHandler<Event> getOnShown();
  
  ObjectProperty<EventHandler<Event>> onHidingProperty();
  
  void setOnHiding(EventHandler<Event> paramEventHandler);
  
  EventHandler<Event> getOnHiding();
  
  ObjectProperty<EventHandler<Event>> onHiddenProperty();
  
  void setOnHidden(EventHandler<Event> paramEventHandler);
  
  EventHandler<Event> getOnHidden();
  
  ObservableList<MenuItemBase> getItemsBase();
  
  void show();
  
  void hide();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\menu\MenuBase.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */