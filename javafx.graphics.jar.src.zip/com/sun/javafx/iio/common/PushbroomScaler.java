package com.sun.javafx.iio.common;

import java.nio.ByteBuffer;

public interface PushbroomScaler {
  ByteBuffer getDestination();
  
  boolean putSourceScanline(byte[] paramArrayOfbyte, int paramInt);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\PushbroomScaler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */