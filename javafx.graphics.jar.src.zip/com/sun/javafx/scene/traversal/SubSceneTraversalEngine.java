/*    */ package com.sun.javafx.scene.traversal;
/*    */ 
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.SubScene;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SubSceneTraversalEngine
/*    */   extends TopMostTraversalEngine
/*    */ {
/*    */   private final SubScene subScene;
/*    */   
/*    */   public SubSceneTraversalEngine(SubScene paramSubScene) {
/* 39 */     this.subScene = paramSubScene;
/*    */   }
/*    */   
/*    */   protected Parent getRoot() {
/* 43 */     return this.subScene.getRoot();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\SubSceneTraversalEngine.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */