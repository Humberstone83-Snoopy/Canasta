/*     */ package com.sun.javafx.iio.common;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoughScaler
/*     */   implements PushbroomScaler
/*     */ {
/*     */   protected int numBands;
/*     */   protected int destWidth;
/*     */   protected int destHeight;
/*     */   protected double scaleY;
/*     */   protected ByteBuffer destBuf;
/*     */   protected int[] colPositions;
/*     */   protected int sourceLine;
/*     */   protected int nextSourceLine;
/*     */   protected int destLine;
/*     */   
/*     */   public RoughScaler(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  54 */     if (paramInt1 <= 0 || paramInt2 <= 0 || paramInt3 <= 0 || paramInt4 <= 0 || paramInt5 <= 0)
/*     */     {
/*  56 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/*  60 */     this.numBands = paramInt3;
/*  61 */     this.destWidth = paramInt4;
/*  62 */     this.destHeight = paramInt5;
/*     */ 
/*     */     
/*  65 */     this.destBuf = ByteBuffer.wrap(new byte[paramInt5 * paramInt4 * paramInt3]);
/*     */ 
/*     */     
/*  68 */     double d = paramInt1 / paramInt4;
/*  69 */     this.scaleY = paramInt2 / paramInt5;
/*     */     
/*  71 */     this.colPositions = new int[paramInt4];
/*  72 */     for (byte b = 0; b < paramInt4; b++) {
/*  73 */       int i = (int)((b + 0.5D) * d);
/*  74 */       this.colPositions[b] = i * paramInt3;
/*     */     } 
/*     */ 
/*     */     
/*  78 */     this.sourceLine = 0;
/*  79 */     this.destLine = 0;
/*     */     
/*  81 */     this.nextSourceLine = (int)(0.5D * this.scaleY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteBuffer getDestination() {
/*  90 */     return this.destBuf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean putSourceScanline(byte[] paramArrayOfbyte, int paramInt) {
/* 103 */     if (paramInt < 0) {
/* 104 */       throw new IllegalArgumentException("off < 0!");
/*     */     }
/*     */     
/* 107 */     if (this.destLine < this.destHeight) {
/* 108 */       if (this.sourceLine == this.nextSourceLine) {
/* 109 */         assert this.destBuf.hasArray() : "destBuf.hasArray() == false => destBuf is direct";
/* 110 */         byte[] arrayOfByte = this.destBuf.array();
/*     */         
/* 112 */         int i = this.destLine * this.destWidth * this.numBands;
/*     */         
/* 114 */         int j = i;
/* 115 */         for (byte b = 0; b < this.destWidth; b++) {
/* 116 */           int k = paramInt + this.colPositions[b];
/* 117 */           for (byte b1 = 0; b1 < this.numBands; b1++) {
/* 118 */             arrayOfByte[j++] = paramArrayOfbyte[k + b1];
/*     */           }
/*     */         } 
/*     */         
/* 122 */         while ((int)((++this.destLine + 0.5D) * this.scaleY) == this.sourceLine) {
/*     */           
/* 124 */           System.arraycopy(arrayOfByte, i, arrayOfByte, j, this.destWidth * this.numBands);
/* 125 */           j += this.destWidth * this.numBands;
/*     */         } 
/* 127 */         this.nextSourceLine = (int)((this.destLine + 0.5D) * this.scaleY);
/*     */       } 
/*     */       
/* 130 */       this.sourceLine++;
/*     */     } 
/*     */     
/* 133 */     return (this.destLine == this.destHeight);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\RoughScaler.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */