/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ObservableDoubleValue;
/*     */ import javafx.beans.value.ObservableNumberValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DoubleExpression
/*     */   extends NumberExpressionBase
/*     */   implements ObservableDoubleValue
/*     */ {
/*     */   public int intValue() {
/*  49 */     return (int)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public long longValue() {
/*  54 */     return (long)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public float floatValue() {
/*  59 */     return (float)get();
/*     */   }
/*     */ 
/*     */   
/*     */   public double doubleValue() {
/*  64 */     return get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Double getValue() {
/*  69 */     return Double.valueOf(get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DoubleExpression doubleExpression(final ObservableDoubleValue value) {
/*  89 */     if (value == null) {
/*  90 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/*  92 */     return (value instanceof DoubleExpression) ? (DoubleExpression)value : 
/*  93 */       new DoubleBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 100 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected double computeValue() {
/* 105 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableDoubleValue> getDependencies() {
/* 110 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> DoubleExpression doubleExpression(final ObservableValue<T> value) {
/* 146 */     if (value == null) {
/* 147 */       throw new NullPointerException("Value must be specified.");
/*     */     }
/* 149 */     return (value instanceof DoubleExpression) ? (DoubleExpression)value : 
/* 150 */       new DoubleBinding()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 157 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected double computeValue() {
/* 162 */           Number number = value.getValue();
/* 163 */           return (number == null) ? 0.0D : number.doubleValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<ObservableValue<T>> getDependencies() {
/* 168 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding negate() {
/* 175 */     return (DoubleBinding)Bindings.negate(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(ObservableNumberValue paramObservableNumberValue) {
/* 180 */     return (DoubleBinding)Bindings.add(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(double paramDouble) {
/* 185 */     return Bindings.add(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(float paramFloat) {
/* 190 */     return (DoubleBinding)Bindings.add(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(long paramLong) {
/* 195 */     return (DoubleBinding)Bindings.add(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding add(int paramInt) {
/* 200 */     return (DoubleBinding)Bindings.add(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(ObservableNumberValue paramObservableNumberValue) {
/* 205 */     return (DoubleBinding)Bindings.subtract(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(double paramDouble) {
/* 210 */     return Bindings.subtract(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(float paramFloat) {
/* 215 */     return (DoubleBinding)Bindings.subtract(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(long paramLong) {
/* 220 */     return (DoubleBinding)Bindings.subtract(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding subtract(int paramInt) {
/* 225 */     return (DoubleBinding)Bindings.subtract(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(ObservableNumberValue paramObservableNumberValue) {
/* 230 */     return (DoubleBinding)Bindings.multiply(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(double paramDouble) {
/* 235 */     return Bindings.multiply(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(float paramFloat) {
/* 240 */     return (DoubleBinding)Bindings.multiply(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(long paramLong) {
/* 245 */     return (DoubleBinding)Bindings.multiply(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding multiply(int paramInt) {
/* 250 */     return (DoubleBinding)Bindings.multiply(this, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(ObservableNumberValue paramObservableNumberValue) {
/* 255 */     return (DoubleBinding)Bindings.divide(this, paramObservableNumberValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(double paramDouble) {
/* 260 */     return Bindings.divide(this, paramDouble);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(float paramFloat) {
/* 265 */     return (DoubleBinding)Bindings.divide(this, paramFloat);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(long paramLong) {
/* 270 */     return (DoubleBinding)Bindings.divide(this, paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public DoubleBinding divide(int paramInt) {
/* 275 */     return (DoubleBinding)Bindings.divide(this, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectExpression<Double> asObject() {
/* 288 */     return new ObjectBinding<Double>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 295 */           unbind(new Observable[] { this.this$0 });
/*     */         }
/*     */ 
/*     */         
/*     */         protected Double computeValue() {
/* 300 */           return DoubleExpression.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\DoubleExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */