/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLImageElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLImageElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLImageElement
/*     */ {
/*     */   HTMLImageElementImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLImageElement getImpl(long paramLong) {
/*  36 */     return (HTMLImageElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public String getName() {
/*  42 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setName(String paramString) {
/*  47 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAlign() {
/*  52 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  57 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAlt() {
/*  62 */     return getAltImpl(getPeer());
/*     */   }
/*     */   static native String getAltImpl(long paramLong);
/*     */   
/*     */   public void setAlt(String paramString) {
/*  67 */     setAltImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAltImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBorder() {
/*  72 */     return getBorderImpl(getPeer());
/*     */   }
/*     */   static native String getBorderImpl(long paramLong);
/*     */   
/*     */   public void setBorder(String paramString) {
/*  77 */     setBorderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBorderImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCrossOrigin() {
/*  82 */     return getCrossOriginImpl(getPeer());
/*     */   }
/*     */   static native String getCrossOriginImpl(long paramLong);
/*     */   
/*     */   public void setCrossOrigin(String paramString) {
/*  87 */     setCrossOriginImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCrossOriginImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHeight() {
/*  92 */     return "" + getHeightImpl(getPeer());
/*     */   }
/*     */   static native int getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(String paramString) {
/*  97 */     setHeightImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getHspace() {
/* 102 */     return "" + getHspaceImpl(getPeer());
/*     */   }
/*     */   static native int getHspaceImpl(long paramLong);
/*     */   
/*     */   public void setHspace(String paramString) {
/* 107 */     setHspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setHspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public boolean getIsMap() {
/* 112 */     return getIsMapImpl(getPeer());
/*     */   }
/*     */   static native boolean getIsMapImpl(long paramLong);
/*     */   
/*     */   public void setIsMap(boolean paramBoolean) {
/* 117 */     setIsMapImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setIsMapImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getLongDesc() {
/* 122 */     return getLongDescImpl(getPeer());
/*     */   }
/*     */   static native String getLongDescImpl(long paramLong);
/*     */   
/*     */   public void setLongDesc(String paramString) {
/* 127 */     setLongDescImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLongDescImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrc() {
/* 132 */     return getSrcImpl(getPeer());
/*     */   }
/*     */   static native String getSrcImpl(long paramLong);
/*     */   
/*     */   public void setSrc(String paramString) {
/* 137 */     setSrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSrcset() {
/* 142 */     return getSrcsetImpl(getPeer());
/*     */   }
/*     */   static native String getSrcsetImpl(long paramLong);
/*     */   
/*     */   public void setSrcset(String paramString) {
/* 147 */     setSrcsetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSrcsetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSizes() {
/* 152 */     return getSizesImpl(getPeer());
/*     */   }
/*     */   static native String getSizesImpl(long paramLong);
/*     */   
/*     */   public void setSizes(String paramString) {
/* 157 */     setSizesImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSizesImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCurrentSrc() {
/* 162 */     return getCurrentSrcImpl(getPeer());
/*     */   }
/*     */   static native String getCurrentSrcImpl(long paramLong);
/*     */   
/*     */   public String getUseMap() {
/* 167 */     return getUseMapImpl(getPeer());
/*     */   }
/*     */   static native String getUseMapImpl(long paramLong);
/*     */   
/*     */   public void setUseMap(String paramString) {
/* 172 */     setUseMapImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setUseMapImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVspace() {
/* 177 */     return "" + getVspaceImpl(getPeer());
/*     */   }
/*     */   static native int getVspaceImpl(long paramLong);
/*     */   
/*     */   public void setVspace(String paramString) {
/* 182 */     setVspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setVspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getWidth() {
/* 187 */     return "" + getWidthImpl(getPeer());
/*     */   }
/*     */   static native int getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 192 */     setWidthImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setWidthImpl(long paramLong, int paramInt);
/*     */   
/*     */   public boolean getComplete() {
/* 197 */     return getCompleteImpl(getPeer());
/*     */   }
/*     */   static native boolean getCompleteImpl(long paramLong);
/*     */   
/*     */   public String getLowsrc() {
/* 202 */     return getLowsrcImpl(getPeer());
/*     */   }
/*     */   static native String getLowsrcImpl(long paramLong);
/*     */   
/*     */   public void setLowsrc(String paramString) {
/* 207 */     setLowsrcImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setLowsrcImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getNaturalHeight() {
/* 212 */     return getNaturalHeightImpl(getPeer());
/*     */   }
/*     */   static native int getNaturalHeightImpl(long paramLong);
/*     */   
/*     */   public int getNaturalWidth() {
/* 217 */     return getNaturalWidthImpl(getPeer());
/*     */   }
/*     */   static native int getNaturalWidthImpl(long paramLong);
/*     */   
/*     */   public int getX() {
/* 222 */     return getXImpl(getPeer());
/*     */   }
/*     */   static native int getXImpl(long paramLong);
/*     */   
/*     */   public int getY() {
/* 227 */     return getYImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native int getYImpl(long paramLong);
/*     */   
/*     */   public void setLowSrc(String paramString) {
/* 234 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   public String getLowSrc() {
/* 237 */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLImageElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */