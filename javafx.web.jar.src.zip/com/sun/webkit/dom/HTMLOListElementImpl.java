/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLOListElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLOListElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLOListElement
/*    */ {
/*    */   HTMLOListElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLOListElement getImpl(long paramLong) {
/* 36 */     return (HTMLOListElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native boolean getCompactImpl(long paramLong);
/*    */   
/*    */   public boolean getCompact() {
/* 42 */     return getCompactImpl(getPeer());
/*    */   }
/*    */   static native void setCompactImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public void setCompact(boolean paramBoolean) {
/* 47 */     setCompactImpl(getPeer(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStart() {
/* 52 */     return getStartImpl(getPeer());
/*    */   }
/*    */   static native int getStartImpl(long paramLong);
/*    */   
/*    */   public void setStart(int paramInt) {
/* 57 */     setStartImpl(getPeer(), paramInt);
/*    */   }
/*    */   static native void setStartImpl(long paramLong, int paramInt);
/*    */   
/*    */   public boolean getReversed() {
/* 62 */     return getReversedImpl(getPeer());
/*    */   }
/*    */   static native boolean getReversedImpl(long paramLong);
/*    */   
/*    */   public void setReversed(boolean paramBoolean) {
/* 67 */     setReversedImpl(getPeer(), paramBoolean);
/*    */   }
/*    */   static native void setReversedImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public String getType() {
/* 72 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public void setType(String paramString) {
/* 77 */     setTypeImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setTypeImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLOListElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */