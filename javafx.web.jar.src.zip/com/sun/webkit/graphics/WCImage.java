/*    */ package com.sun.webkit.graphics;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WCImage
/*    */   extends Ref
/*    */ {
/*    */   private WCRenderQueue rq;
/*    */   private String fileExtension;
/*    */   
/*    */   public abstract int getWidth();
/*    */   
/*    */   public abstract int getHeight();
/*    */   
/*    */   public String getFileExtension() {
/* 39 */     return this.fileExtension;
/*    */   }
/*    */   
/*    */   public void setFileExtension(String paramString) {
/* 43 */     this.fileExtension = paramString;
/*    */   }
/*    */   public Object getPlatformImage() {
/* 46 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract byte[] toData(String paramString);
/*    */   
/*    */   public ByteBuffer getPixelBuffer() {
/* 52 */     return null;
/*    */   }
/*    */   protected abstract String toDataURL(String paramString);
/*    */   protected void drawPixelBuffer() {}
/*    */   public synchronized void setRQ(WCRenderQueue paramWCRenderQueue) {
/* 57 */     this.rq = paramWCRenderQueue;
/*    */   }
/*    */ 
/*    */   
/*    */   protected synchronized void flushRQ() {
/* 62 */     if (this.rq != null) {
/* 63 */       this.rq.decode();
/*    */     }
/*    */   }
/*    */   
/*    */   protected synchronized boolean isDirty() {
/* 68 */     return (this.rq == null) ? false : (
/*    */       
/* 70 */       !this.rq.isEmpty());
/*    */   }
/*    */   
/*    */   public static WCImage getImage(Object paramObject) {
/* 74 */     WCImage wCImage = null;
/* 75 */     if (paramObject instanceof WCImage) {
/*    */ 
/*    */       
/* 78 */       wCImage = (WCImage)paramObject;
/* 79 */     } else if (paramObject instanceof WCImageFrame) {
/*    */ 
/*    */       
/* 82 */       wCImage = ((WCImageFrame)paramObject).getFrame();
/*    */     } 
/* 84 */     return wCImage;
/*    */   }
/*    */   
/*    */   public abstract float getPixelScale();
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCImage.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */