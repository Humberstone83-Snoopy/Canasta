/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.shape.ClosePath;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClosePathHelper
/*    */   extends PathElementHelper
/*    */ {
/* 42 */   private static final ClosePathHelper theInstance = new ClosePathHelper(); static {
/* 43 */     Utils.forceInit(ClosePath.class);
/*    */   }
/*    */   private static ClosePathAccessor closePathAccessor;
/*    */   private static ClosePathHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(ClosePath paramClosePath) {
/* 51 */     setHelper(paramClosePath, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addToImpl(PathElement paramPathElement, Path2D paramPath2D) {
/* 56 */     closePathAccessor.doAddTo(paramPathElement, paramPath2D);
/*    */   }
/*    */   
/*    */   public static void setClosePathAccessor(ClosePathAccessor paramClosePathAccessor) {
/* 60 */     if (closePathAccessor != null) {
/* 61 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 64 */     closePathAccessor = paramClosePathAccessor;
/*    */   }
/*    */   
/*    */   public static interface ClosePathAccessor {
/*    */     void doAddTo(PathElement param1PathElement, Path2D param1Path2D);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\ClosePathHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */