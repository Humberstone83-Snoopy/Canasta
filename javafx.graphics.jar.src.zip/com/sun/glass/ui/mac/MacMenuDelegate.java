/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Menu;
/*     */ import com.sun.glass.ui.MenuItem;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.delegate.MenuDelegate;
/*     */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MacMenuDelegate
/*     */   implements MenuDelegate, MenuItemDelegate
/*     */ {
/*     */   long ptr;
/*     */   private Menu menu;
/*     */   
/*     */   static {
/*  43 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MacMenuDelegate(Menu paramMenu) {
/*  52 */     this.menu = paramMenu;
/*     */   }
/*     */ 
/*     */   
/*     */   public MacMenuDelegate() {}
/*     */ 
/*     */   
/*     */   public boolean createMenu(String paramString, boolean paramBoolean) {
/*  60 */     this.ptr = _createMenu(paramString, paramBoolean);
/*  61 */     return (this.ptr != 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2) {
/*  71 */     this.ptr = _createMenuItem(paramString, (char)paramInt1, paramInt2, paramPixels, paramBoolean1, paramBoolean2, paramCallback);
/*     */     
/*  73 */     return (this.ptr != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean insert(MenuDelegate paramMenuDelegate, int paramInt) {
/*  78 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuDelegate;
/*  79 */     _insert(this.ptr, macMenuDelegate.ptr, paramInt);
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public boolean insert(MenuItemDelegate paramMenuItemDelegate, int paramInt) {
/*  84 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuItemDelegate;
/*  85 */     _insert(this.ptr, (macMenuDelegate != null) ? macMenuDelegate.ptr : 0L, paramInt);
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(MenuDelegate paramMenuDelegate, int paramInt) {
/*  91 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuDelegate;
/*  92 */     _remove(this.ptr, macMenuDelegate.ptr, paramInt);
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public boolean remove(MenuItemDelegate paramMenuItemDelegate, int paramInt) {
/*  97 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuItemDelegate;
/*  98 */     _remove(this.ptr, (macMenuDelegate == null) ? 0L : macMenuDelegate.ptr, paramInt);
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setTitle(String paramString) {
/* 104 */     _setTitle(this.ptr, paramString);
/* 105 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setShortcut(int paramInt1, int paramInt2) {
/* 110 */     _setShortcut(this.ptr, (char)paramInt1, paramInt2);
/* 111 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setPixels(Pixels paramPixels) {
/* 116 */     _setPixels(this.ptr, paramPixels);
/* 117 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setEnabled(boolean paramBoolean) {
/* 122 */     _setEnabled(this.ptr, paramBoolean);
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setChecked(boolean paramBoolean) {
/* 128 */     _setChecked(this.ptr, paramBoolean);
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setCallback(MenuItem.Callback paramCallback) {
/* 134 */     _setCallback(this.ptr, paramCallback);
/* 135 */     return true;
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native long _createMenu(String paramString, boolean paramBoolean);
/*     */   
/*     */   private native long _createMenuItem(String paramString, char paramChar, int paramInt, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2, MenuItem.Callback paramCallback);
/*     */   
/*     */   private native void _insert(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   private native void _remove(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   private native void _setTitle(long paramLong, String paramString);
/*     */   
/*     */   private native void _setShortcut(long paramLong, char paramChar, int paramInt);
/*     */   
/*     */   private native void _setPixels(long paramLong, Pixels paramPixels);
/*     */   
/*     */   private native void _setEnabled(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private native void _setChecked(long paramLong, boolean paramBoolean);
/*     */   
/*     */   private native void _setCallback(long paramLong, MenuItem.Callback paramCallback);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacMenuDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */