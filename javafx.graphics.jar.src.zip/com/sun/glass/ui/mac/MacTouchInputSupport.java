/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.TouchInputSupport;
/*     */ import com.sun.glass.ui.View;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MacTouchInputSupport
/*     */   extends TouchInputSupport
/*     */ {
/*  38 */   private final Map<Long, WeakReference<View>> touchIdToView = new HashMap<>();
/*     */   
/*     */   private int curModifiers;
/*     */   
/*     */   private boolean curIsDirect;
/*     */   
/*     */   private List<TouchPoint> curTouchPoints;
/*     */   
/*     */   private static class TouchPoint
/*     */   {
/*     */     final int state;
/*     */     final long id;
/*     */     final int x;
/*     */     final int y;
/*     */     final int xAbs;
/*     */     final int yAbs;
/*     */     
/*     */     TouchPoint(int param1Int1, long param1Long, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
/*  56 */       this.state = param1Int1;
/*  57 */       this.id = param1Long;
/*  58 */       this.x = param1Int2;
/*  59 */       this.y = param1Int3;
/*  60 */       this.xAbs = param1Int4;
/*  61 */       this.yAbs = param1Int5;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   MacTouchInputSupport(TouchInputSupport.TouchCountListener paramTouchCountListener, boolean paramBoolean) {
/*  67 */     super(paramTouchCountListener, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyBeginTouchEvent(View paramView, int paramInt1, boolean paramBoolean, int paramInt2) {
/*  73 */     this.curModifiers = paramInt1;
/*  74 */     this.curIsDirect = paramBoolean;
/*  75 */     this.curTouchPoints = new ArrayList<>(paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void notifyEndTouchEvent(View paramView) {
/*  80 */     if (this.curTouchPoints.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  85 */       super.notifyBeginTouchEvent(paramView, this.curModifiers, this.curIsDirect, this.curTouchPoints
/*  86 */           .size());
/*     */       
/*  88 */       for (TouchPoint touchPoint : this.curTouchPoints) {
/*  89 */         super.notifyNextTouchEvent(paramView, touchPoint.state, touchPoint.id, touchPoint.x, touchPoint.y, touchPoint.xAbs, touchPoint.yAbs);
/*     */       }
/*     */ 
/*     */       
/*  93 */       super.notifyEndTouchEvent(paramView);
/*     */     } finally {
/*     */       
/*  96 */       this.curTouchPoints = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyNextTouchEvent(View paramView, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 104 */     View view = null;
/* 105 */     if (paramInt1 == 811) {
/* 106 */       view = paramView;
/* 107 */       this.touchIdToView.put(Long.valueOf(paramLong), new WeakReference<>(paramView));
/*     */     } else {
/* 109 */       view = ((WeakReference<View>)this.touchIdToView.get(Long.valueOf(paramLong))).get();
/* 110 */       if (paramInt1 == 813) {
/* 111 */         this.touchIdToView.remove(Long.valueOf(paramLong));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (view == paramView) {
/* 120 */       this.curTouchPoints.add(new TouchPoint(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5));
/*     */     } else {
/* 122 */       if (view != null && view.isClosed())
/*     */       {
/*     */         
/* 125 */         view = null;
/*     */       }
/*     */       
/* 128 */       super.notifyBeginTouchEvent(view, this.curModifiers, this.curIsDirect, 1);
/*     */       
/* 130 */       super.notifyNextTouchEvent(view, paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */       
/* 132 */       super.notifyEndTouchEvent(view);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacTouchInputSupport.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */