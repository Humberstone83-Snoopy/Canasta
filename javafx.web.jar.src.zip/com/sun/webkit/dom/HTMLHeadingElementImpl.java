/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLHeadingElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLHeadingElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLHeadingElement
/*    */ {
/*    */   HTMLHeadingElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLHeadingElement getImpl(long paramLong) {
/* 36 */     return (HTMLHeadingElement)create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAlign() {
/* 42 */     return getAlignImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAlign(String paramString) {
/* 47 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLHeadingElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */