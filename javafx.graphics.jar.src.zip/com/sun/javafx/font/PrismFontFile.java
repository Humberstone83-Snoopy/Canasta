/*      */ package com.sun.javafx.font;
/*      */ 
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class PrismFontFile
/*      */   implements FontResource, FontConstants
/*      */ {
/*   45 */   private int fontInstallationType = -1;
/*      */ 
/*      */   
/*      */   String familyName;
/*      */ 
/*      */   
/*      */   String fullName;
/*      */ 
/*      */   
/*      */   String psName;
/*      */ 
/*      */   
/*      */   String localeFamilyName;
/*      */ 
/*      */   
/*      */   String localeFullName;
/*      */ 
/*      */   
/*      */   String styleName;
/*      */ 
/*      */   
/*      */   String localeStyleName;
/*      */ 
/*      */   
/*      */   String filename;
/*      */ 
/*      */   
/*      */   int filesize;
/*      */ 
/*      */   
/*      */   FontFileReader filereader;
/*      */ 
/*      */   
/*   78 */   int numGlyphs = -1;
/*      */   
/*      */   short indexToLocFormat;
/*      */   
/*      */   int fontIndex;
/*      */   
/*      */   boolean isCFF;
/*      */   
/*      */   boolean isEmbedded = false;
/*      */   
/*      */   boolean isCopy = false;
/*      */   boolean isTracked = false;
/*      */   boolean isDecoded = false;
/*      */   boolean isRegistered = true;
/*   92 */   Map<FontStrikeDesc, WeakReference<PrismFontStrike>> strikeMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FileRefCounter refCounter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HashMap<Integer, int[]> bbCache;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WeakReference<PrismFontFile> createFileDisposer(PrismFontFactory paramPrismFontFactory, FileRefCounter paramFileRefCounter) {
/*  108 */     FileDisposer fileDisposer = new FileDisposer(this.filename, this.isTracked, paramFileRefCounter);
/*  109 */     WeakReference<PrismFontFile> weakReference = Disposer.addRecord(this, fileDisposer);
/*  110 */     fileDisposer.setFactory(paramPrismFontFactory, weakReference);
/*  111 */     return weakReference;
/*      */   }
/*      */   
/*      */   void setIsDecoded(boolean paramBoolean) {
/*  115 */     this.isDecoded = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void disposeOnShutdown() {
/*  121 */     if (this.isCopy || this.isDecoded) {
/*  122 */       AccessController.doPrivileged(() -> {
/*      */             try {
/*      */               if (decFileRefCount() > 0) {
/*      */                 return null;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               boolean bool = (new File(this.filename)).delete();
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               if (!bool && PrismFontFactory.debugFonts) {
/*      */                 System.err.println("Temp file not deleted : " + this.filename);
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               this.isCopy = this.isDecoded = false;
/*  143 */             } catch (Exception exception) {}
/*      */             
/*      */             return null;
/*      */           });
/*      */       
/*  148 */       if (PrismFontFactory.debugFonts) {
/*  149 */         System.err.println("Temp file deleted: " + this.filename);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getDefaultAAMode() {
/*  155 */     return 0;
/*      */   }
/*      */   
/*      */   public boolean isInstalledFont() {
/*  159 */     if (this.fontInstallationType == -1) {
/*  160 */       PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  161 */       this.fontInstallationType = prismFontFactory.isInstalledFont(this.filename) ? 1 : 0;
/*      */     } 
/*  163 */     return (this.fontInstallationType > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class FileRefCounter
/*      */   {
/*  171 */     private int refCnt = 1;
/*      */     
/*      */     synchronized int getRefCount() {
/*  174 */       return this.refCnt;
/*      */     }
/*      */     
/*      */     synchronized int increment() {
/*  178 */       return ++this.refCnt;
/*      */     }
/*      */     
/*      */     synchronized int decrement() {
/*  182 */       return (this.refCnt == 0) ? 0 : --this.refCnt;
/*      */     }
/*      */   }
/*      */   
/*  186 */   protected PrismFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception { this.refCounter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  354 */     this.bbCache = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  430 */     this.directoryCount = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     this.mapper = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1148 */     this.advanceWidths = null; this.filename = paramString2; this.isRegistered = paramBoolean1; this.isEmbedded = paramBoolean2; this.isCopy = paramBoolean3; this.isTracked = paramBoolean4; init(paramString1, paramInt); }
/*      */   FileRefCounter getFileRefCounter() { return this.refCounter; }
/*      */   FileRefCounter createFileRefCounter() { this.refCounter = new FileRefCounter(); return this.refCounter; }
/*      */   void setAndIncFileRefCounter(FileRefCounter paramFileRefCounter) { this.refCounter = paramFileRefCounter; this.refCounter.increment(); }
/*      */   int decFileRefCount() { if (this.refCounter == null)
/*      */       return 0;  return this.refCounter.decrement(); }
/*      */   static class FileDisposer implements DisposerRecord {
/*      */     String fileName;
/*      */     boolean isTracked;
/*      */     PrismFontFile.FileRefCounter refCounter;
/*      */     PrismFontFactory factory;
/*      */     WeakReference<PrismFontFile> refKey;
/*      */     public FileDisposer(String param1String, boolean param1Boolean, PrismFontFile.FileRefCounter param1FileRefCounter) { this.fileName = param1String; this.isTracked = param1Boolean; this.refCounter = param1FileRefCounter; }
/*      */     public void setFactory(PrismFontFactory param1PrismFontFactory, WeakReference<PrismFontFile> param1WeakReference) { this.factory = param1PrismFontFactory; this.refKey = param1WeakReference; }
/*      */     public synchronized void dispose() { if (this.fileName != null) { AccessController.doPrivileged(() -> { try { if (this.refCounter != null && this.refCounter.decrement() > 0)
/*      */                   return null;  File file = new File(this.fileName); int i = (int)file.length(); file.delete(); if (this.isTracked)
/*      */                   FontFileWriter.FontTracker.getTracker().subBytes(i);  if (this.factory != null && this.refKey != null) { Object object = this.refKey.get(); if (object == null) { this.factory.removeTmpFont(this.refKey); this.factory = null; this.refKey = null; }  }  if (PrismFontFactory.debugFonts)
/*      */                   System.err.println("FileDisposer=" + this.fileName);  } catch (Exception exception) { if (PrismFontFactory.debugFonts)
/*      */                   exception.printStackTrace();  }  return null; }); this.fileName = null; }  } }
/*      */   public String getFileName() { return this.filename; }
/*      */   protected int getFileSize() { return this.filesize; }
/*      */   protected int getFontIndex() { return this.fontIndex; }
/*      */   public String getFullName() { return this.fullName; }
/*      */   public String getPSName() { if (this.psName == null)
/*      */       this.psName = this.fullName;  return this.psName; }
/*      */   public String getFamilyName() { return this.familyName; }
/*      */   public String getStyleName() { return this.styleName; }
/*      */   public String getLocaleFullName() { return this.localeFullName; } public String getLocaleFamilyName() { return this.localeFamilyName; } public String getLocaleStyleName() { return this.localeStyleName; } public int getFeatures() { return -1; } public Map getStrikeMap() { return this.strikeMap; } public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt) { FontStrikeDesc fontStrikeDesc = new FontStrikeDesc(paramFloat, paramBaseTransform, paramInt); WeakReference<PrismFontStrike> weakReference = this.strikeMap.get(fontStrikeDesc); PrismFontStrike prismFontStrike = null; if (weakReference != null)
/*      */       prismFontStrike = weakReference.get();  if (prismFontStrike == null) { prismFontStrike = createStrike(paramFloat, paramBaseTransform, paramInt, fontStrikeDesc); DisposerRecord disposerRecord = prismFontStrike.getDisposer(); if (disposerRecord != null) { weakReference = Disposer.addRecord(prismFontStrike, disposerRecord); }
/*      */       else { weakReference = new WeakReference<>(prismFontStrike); }
/*      */        this.strikeMap.put(fontStrikeDesc, weakReference); }
/* 1179 */      return prismFontStrike; } static final int[] EMPTY_BOUNDS = new int[4]; private Object peer; int directoryCount; int numTables; DirectoryEntry[] tableDirectory; private static final int fsSelectionItalicBit = 1; private static final int fsSelectionBoldBit = 32; private static final int MACSTYLE_BOLD_BIT = 1; private static final int MACSTYLE_ITALIC_BIT = 2; private boolean isBold; private boolean isItalic; private float upem; private float ascent; private float descent; private float linegap; private int numHMetrics; public static final int MAC_PLATFORM_ID = 1; public static final int MACROMAN_SPECIFIC_ID = 0; public static final int MACROMAN_ENGLISH_LANG = 0; public float getAdvance(int paramInt, float paramFloat) { if (paramInt == 65535) {
/* 1180 */       return 0.0F;
/*      */     }
/*      */     
/* 1183 */     if (this.advanceWidths == null && this.numHMetrics > 0) {
/* 1184 */       synchronized (this) {
/* 1185 */         FontFileReader.Buffer buffer = readTable(1752003704);
/* 1186 */         if (buffer == null) {
/* 1187 */           this.numHMetrics = -1;
/* 1188 */           return 0.0F;
/*      */         } 
/* 1190 */         char[] arrayOfChar = new char[this.numHMetrics];
/* 1191 */         for (byte b = 0; b < this.numHMetrics; b++) {
/* 1192 */           arrayOfChar[b] = buffer.getChar(b * 4);
/*      */         }
/* 1194 */         this.advanceWidths = arrayOfChar;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1199 */     if (this.numHMetrics > 0) {
/*      */       char c;
/* 1201 */       if (paramInt < this.numHMetrics) {
/* 1202 */         c = this.advanceWidths[paramInt];
/*      */       } else {
/* 1204 */         c = this.advanceWidths[this.numHMetrics - 1];
/*      */       } 
/* 1206 */       return (c & Character.MAX_VALUE) * paramFloat / this.upem;
/*      */     } 
/* 1208 */     return 0.0F; }
/*      */   public static final int MS_PLATFORM_ID = 3;
/*      */   public static final short MS_ENGLISH_LOCALE_ID = 1033;
/*      */   public static final int FAMILY_NAME_ID = 1;
/*      */   public static final int STYLE_NAME_ID = 2; public static final int FULL_NAME_ID = 4; public static final int PS_NAME_ID = 6; private static Map<String, Short> lcidMap; public float[] getGlyphBoundingBox(int paramInt, float paramFloat, float[] paramArrayOffloat) { if (paramArrayOffloat == null || paramArrayOffloat.length < 4) paramArrayOffloat = new float[4];  if (paramInt >= getNumGlyphs()) { paramArrayOffloat[3] = 0.0F; paramArrayOffloat[2] = 0.0F; paramArrayOffloat[1] = 0.0F; paramArrayOffloat[0] = 0.0F; return paramArrayOffloat; }  if (this.bbCache == null) this.bbCache = (HashMap)new HashMap<>();  int[] arrayOfInt = this.bbCache.get(Integer.valueOf(paramInt)); if (arrayOfInt == null) { arrayOfInt = createGlyphBoundingBox(paramInt); if (arrayOfInt == null) arrayOfInt = EMPTY_BOUNDS;  this.bbCache.put(Integer.valueOf(paramInt), arrayOfInt); }  float f = paramFloat / getUnitsPerEm(); paramArrayOffloat[0] = arrayOfInt[0] * f; paramArrayOffloat[1] = arrayOfInt[1] * f; paramArrayOffloat[2] = arrayOfInt[2] * f; paramArrayOffloat[3] = arrayOfInt[3] * f; return paramArrayOffloat; } int getNumGlyphs() { if (this.numGlyphs == -1) { FontFileReader.Buffer buffer = readTable(1835104368); this.numGlyphs = buffer.getChar(4); }  return this.numGlyphs; } protected boolean isCFF() { return this.isCFF; } public Object getPeer() { return this.peer; } public void setPeer(Object paramObject) { this.peer = paramObject; } synchronized FontFileReader.Buffer readTable(int paramInt) { FontFileReader.Buffer buffer = null; boolean bool = false; try { bool = this.filereader.openFile(); DirectoryEntry directoryEntry = getDirectoryEntry(paramInt); if (directoryEntry != null) buffer = this.filereader.readBlock(directoryEntry.offset, directoryEntry.length);  } catch (Exception exception) { if (PrismFontFactory.debugFonts) exception.printStackTrace();  } finally { if (bool) try { this.filereader.closeFile(); } catch (Exception exception) {}  }  return buffer; } public int getFontCount() { return this.directoryCount; } static class DirectoryEntry {
/* 1213 */     int tag; int offset; int length; } DirectoryEntry getDirectoryEntry(int paramInt) { for (byte b = 0; b < this.numTables; b++) { if ((this.tableDirectory[b]).tag == paramInt) return this.tableDirectory[b];  }  return null; } private void init(String paramString, int paramInt) throws Exception { this.filereader = new FontFileReader(this.filename); WoffDecoder woffDecoder = null; try { if (!this.filereader.openFile()) throw new FileNotFoundException("Unable to create FontResource for file " + this.filename);  FontFileReader.Buffer buffer1 = this.filereader.readBlock(0, 12); int i = buffer1.getInt(); if (i == 2001684038) { woffDecoder = new WoffDecoder(); File file = woffDecoder.openFile(); woffDecoder.decode(this.filereader); woffDecoder.closeFile(); this.filereader.closeFile(); this.filereader = new FontFileReader(file.getPath()); if (!this.filereader.openFile()) throw new FileNotFoundException("Unable to create FontResource for file " + this.filename);  buffer1 = this.filereader.readBlock(0, 12); i = buffer1.getInt(); }  this.filesize = (int)this.filereader.getLength(); int j = 0; if (i == 1953784678) { buffer1.getInt(); this.directoryCount = buffer1.getInt(); if (paramInt >= this.directoryCount) throw new Exception("Bad collection index");  this.fontIndex = paramInt; buffer1 = this.filereader.readBlock(12 + 4 * paramInt, 4); j = buffer1.getInt(); buffer1 = this.filereader.readBlock(j, 4); i = buffer1.getInt(); }  switch (i) { case 65536: case 1953658213: break;case 1330926671: this.isCFF = true; break;default: throw new Exception("Unsupported sfnt " + this.filename); }  buffer1 = this.filereader.readBlock(j + 4, 2); this.numTables = buffer1.getShort(); int k = j + 12; FontFileReader.Buffer buffer2 = this.filereader.readBlock(k, this.numTables * 16); this.tableDirectory = new DirectoryEntry[this.numTables]; for (byte b = 0; b < this.numTables; b++) { DirectoryEntry directoryEntry1 = new DirectoryEntry(); directoryEntry1.tag = buffer2.getInt(); buffer2.skip(4); directoryEntry1.offset = buffer2.getInt(); directoryEntry1.length = buffer2.getInt(); if (directoryEntry1.offset + directoryEntry1.length > this.filesize) throw new Exception("bad table, tag=" + directoryEntry1.tag);  }  DirectoryEntry directoryEntry = getDirectoryEntry(1751474532); FontFileReader.Buffer buffer3 = this.filereader.readBlock(directoryEntry.offset, directoryEntry.length); this.upem = (buffer3.getShort(18) & 0xFFFF); if (16.0F > this.upem || this.upem > 16384.0F) this.upem = 2048.0F;  this.indexToLocFormat = buffer3.getShort(50); if (this.indexToLocFormat < 0 || this.indexToLocFormat > 1) throw new Exception("Bad indexToLocFormat");  FontFileReader.Buffer buffer4 = readTable(1751672161); if (buffer4 == null) { this.numHMetrics = -1; } else { this.ascent = -(buffer4.getShort(4)); this.descent = -(buffer4.getShort(6)); this.linegap = buffer4.getShort(8); this.numHMetrics = buffer4.getChar(34) & Character.MAX_VALUE; }  getNumGlyphs(); setStyle(); checkCMAP(); initNames(); if (this.familyName == null || this.fullName == null) { String str = (paramString != null) ? paramString : ""; if (this.fullName == null) this.fullName = (this.familyName != null) ? this.familyName : str;  if (this.familyName == null) this.familyName = (this.fullName != null) ? this.fullName : str;  throw new Exception("Font name not found."); }  if (woffDecoder != null) { this.isDecoded = true; this.filename = this.filereader.getFilename(); PrismFontFactory.getFontFactory().addDecodedFont(this); }  } catch (Exception exception) { if (woffDecoder != null) woffDecoder.deleteFile();  throw exception; } finally { this.filereader.closeFile(); }  } private void setStyle() { DirectoryEntry directoryEntry = getDirectoryEntry(1330851634); if (directoryEntry != null) { FontFileReader.Buffer buffer = this.filereader.readBlock(directoryEntry.offset, directoryEntry.length); int i = buffer.getChar(62) & Character.MAX_VALUE; this.isItalic = ((i & 0x1) != 0); this.isBold = ((i & 0x20) != 0); } else { DirectoryEntry directoryEntry1 = getDirectoryEntry(1751474532); FontFileReader.Buffer buffer = this.filereader.readBlock(directoryEntry1.offset, directoryEntry1.length); short s = buffer.getShort(44); this.isItalic = ((s & 0x2) != 0); this.isBold = ((s & 0x1) != 0); }  } public boolean isBold() { return this.isBold; } public boolean isItalic() { return this.isItalic; } public boolean isDecoded() { return this.isDecoded; } public boolean isRegistered() { return this.isRegistered; } public boolean isEmbeddedFont() { return this.isEmbedded; } public int getUnitsPerEm() { return (int)this.upem; } public short getIndexToLocFormat() { return this.indexToLocFormat; } public int getNumHMetrics() { return this.numHMetrics; } void initNames() throws Exception { byte[] arrayOfByte = new byte[256]; DirectoryEntry directoryEntry = getDirectoryEntry(1851878757); FontFileReader.Buffer buffer = this.filereader.readBlock(directoryEntry.offset, directoryEntry.length); buffer.skip(2); short s = buffer.getShort(); int i = buffer.getShort() & 0xFFFF; for (byte b = 0; b < s; b++) { short s1 = buffer.getShort(); if (s1 != 3 && s1 != 1) { buffer.skip(10); } else { short s2 = buffer.getShort(); if ((s1 == 3 && s2 > 1) || (s1 == 1 && s2 != 0)) { buffer.skip(8); } else { short s3 = buffer.getShort(); if (s1 == 1 && s3 != 0) { buffer.skip(6); } else { short s4 = buffer.getShort(); int j = buffer.getShort() & 0xFFFF; int k = (buffer.getShort() & 0xFFFF) + i; String str = null; switch (s4) { case 1: if (this.familyName == null || s3 == 1033 || s3 == nameLocaleID) { String str1; buffer.get(k, arrayOfByte, 0, j); if (s1 == 1) { str1 = "US-ASCII"; } else { str1 = "UTF-16BE"; }  str = new String(arrayOfByte, 0, j, str1); if (this.familyName == null || s3 == 1033) this.familyName = str;  if (s3 == nameLocaleID) this.localeFamilyName = str;  }  break;case 4: if (this.fullName == null || s3 == 1033 || s3 == nameLocaleID) { String str1; buffer.get(k, arrayOfByte, 0, j); if (s1 == 1) { str1 = "US-ASCII"; } else { str1 = "UTF-16BE"; }  str = new String(arrayOfByte, 0, j, str1); if (this.fullName == null || s3 == 1033) this.fullName = str;  if (s3 == nameLocaleID) this.localeFullName = str;  }  break;case 6: if (this.psName == null) { String str1; buffer.get(k, arrayOfByte, 0, j); if (s1 == 1) { str1 = "US-ASCII"; } else { str1 = "UTF-16BE"; }  this.psName = new String(arrayOfByte, 0, j, str1); }  break;case 2: if (this.styleName == null || s3 == 1033 || s3 == nameLocaleID) { String str1; buffer.get(k, arrayOfByte, 0, j); if (s1 == 1) { str1 = "US-ASCII"; } else { str1 = "UTF-16BE"; }  str = new String(arrayOfByte, 0, j, str1); if (this.styleName == null || s3 == 1033) this.styleName = str;  if (s3 == nameLocaleID) this.localeStyleName = str;  }  break; }  if (this.localeFamilyName == null) this.localeFamilyName = this.familyName;  if (this.localeFullName == null) this.localeFullName = this.fullName;  if (this.localeStyleName == null) this.localeStyleName = this.styleName;  }  }  }  }  } private void checkCMAP() throws Exception { DirectoryEntry directoryEntry = getDirectoryEntry(1668112752); if (directoryEntry != null) { if (directoryEntry.length < 4) throw new Exception("Invalid cmap table length");  FontFileReader.Buffer buffer1 = this.filereader.readBlock(directoryEntry.offset, 4); short s1 = buffer1.getShort(); short s2 = buffer1.getShort(); int i = s2 * 8; if (s2 <= 0 || directoryEntry.length < i + 4) throw new Exception("Invalid cmap subtables count");  FontFileReader.Buffer buffer2 = this.filereader.readBlock(directoryEntry.offset + 4, i); for (byte b = 0; b < s2; b++) { short s3 = buffer2.getShort(); short s4 = buffer2.getShort(); int j = buffer2.getInt(); if (j < 0 || j >= directoryEntry.length) throw new Exception("Invalid cmap subtable offset");  }  }  } private static void addLCIDMapEntry(Map<String, Short> paramMap, String paramString, short paramShort) { paramMap.put(paramString, Short.valueOf(paramShort)); } private static synchronized void createLCIDMap() { if (lcidMap != null) return;  HashMap<Object, Object> hashMap = new HashMap<>(200); addLCIDMapEntry((Map)hashMap, "ar", (short)1025); addLCIDMapEntry((Map)hashMap, "bg", (short)1026); addLCIDMapEntry((Map)hashMap, "ca", (short)1027); addLCIDMapEntry((Map)hashMap, "zh", (short)1028); addLCIDMapEntry((Map)hashMap, "cs", (short)1029); addLCIDMapEntry((Map)hashMap, "da", (short)1030); addLCIDMapEntry((Map)hashMap, "de", (short)1031); addLCIDMapEntry((Map)hashMap, "el", (short)1032); addLCIDMapEntry((Map)hashMap, "es", (short)1034); addLCIDMapEntry((Map)hashMap, "fi", (short)1035); addLCIDMapEntry((Map)hashMap, "fr", (short)1036); addLCIDMapEntry((Map)hashMap, "iw", (short)1037); addLCIDMapEntry((Map)hashMap, "hu", (short)1038); addLCIDMapEntry((Map)hashMap, "is", (short)1039); addLCIDMapEntry((Map)hashMap, "it", (short)1040); addLCIDMapEntry((Map)hashMap, "ja", (short)1041); addLCIDMapEntry((Map)hashMap, "ko", (short)1042); addLCIDMapEntry((Map)hashMap, "nl", (short)1043); addLCIDMapEntry((Map)hashMap, "no", (short)1044); addLCIDMapEntry((Map)hashMap, "pl", (short)1045); addLCIDMapEntry((Map)hashMap, "pt", (short)1046); addLCIDMapEntry((Map)hashMap, "rm", (short)1047); addLCIDMapEntry((Map)hashMap, "ro", (short)1048); addLCIDMapEntry((Map)hashMap, "ru", (short)1049); addLCIDMapEntry((Map)hashMap, "hr", (short)1050); addLCIDMapEntry((Map)hashMap, "sk", (short)1051); addLCIDMapEntry((Map)hashMap, "sq", (short)1052); addLCIDMapEntry((Map)hashMap, "sv", (short)1053); addLCIDMapEntry((Map)hashMap, "th", (short)1054); addLCIDMapEntry((Map)hashMap, "tr", (short)1055); addLCIDMapEntry((Map)hashMap, "ur", (short)1056); addLCIDMapEntry((Map)hashMap, "in", (short)1057); addLCIDMapEntry((Map)hashMap, "uk", (short)1058); addLCIDMapEntry((Map)hashMap, "be", (short)1059); addLCIDMapEntry((Map)hashMap, "sl", (short)1060); addLCIDMapEntry((Map)hashMap, "et", (short)1061); addLCIDMapEntry((Map)hashMap, "lv", (short)1062); addLCIDMapEntry((Map)hashMap, "lt", (short)1063); addLCIDMapEntry((Map)hashMap, "fa", (short)1065); addLCIDMapEntry((Map)hashMap, "vi", (short)1066); addLCIDMapEntry((Map)hashMap, "hy", (short)1067); addLCIDMapEntry((Map)hashMap, "eu", (short)1069); addLCIDMapEntry((Map)hashMap, "mk", (short)1071); addLCIDMapEntry((Map)hashMap, "tn", (short)1074); addLCIDMapEntry((Map)hashMap, "xh", (short)1076); addLCIDMapEntry((Map)hashMap, "zu", (short)1077); addLCIDMapEntry((Map)hashMap, "af", (short)1078); addLCIDMapEntry((Map)hashMap, "ka", (short)1079); addLCIDMapEntry((Map)hashMap, "fo", (short)1080); addLCIDMapEntry((Map)hashMap, "hi", (short)1081); addLCIDMapEntry((Map)hashMap, "mt", (short)1082); addLCIDMapEntry((Map)hashMap, "se", (short)1083); addLCIDMapEntry((Map)hashMap, "gd", (short)1084); addLCIDMapEntry((Map)hashMap, "ms", (short)1086); addLCIDMapEntry((Map)hashMap, "kk", (short)1087); addLCIDMapEntry((Map)hashMap, "ky", (short)1088); addLCIDMapEntry((Map)hashMap, "sw", (short)1089); addLCIDMapEntry((Map)hashMap, "tt", (short)1092); addLCIDMapEntry((Map)hashMap, "bn", (short)1093); addLCIDMapEntry((Map)hashMap, "pa", (short)1094); addLCIDMapEntry((Map)hashMap, "gu", (short)1095); addLCIDMapEntry((Map)hashMap, "ta", (short)1097); addLCIDMapEntry((Map)hashMap, "te", (short)1098); addLCIDMapEntry((Map)hashMap, "kn", (short)1099); addLCIDMapEntry((Map)hashMap, "ml", (short)1100); addLCIDMapEntry((Map)hashMap, "mr", (short)1102); addLCIDMapEntry((Map)hashMap, "sa", (short)1103); addLCIDMapEntry((Map)hashMap, "mn", (short)1104); addLCIDMapEntry((Map)hashMap, "cy", (short)1106); addLCIDMapEntry((Map)hashMap, "gl", (short)1110); addLCIDMapEntry((Map)hashMap, "dv", (short)1125); addLCIDMapEntry((Map)hashMap, "qu", (short)1131); addLCIDMapEntry((Map)hashMap, "mi", (short)1153); addLCIDMapEntry((Map)hashMap, "ar_IQ", (short)2049); addLCIDMapEntry((Map)hashMap, "zh_CN", (short)2052); addLCIDMapEntry((Map)hashMap, "de_CH", (short)2055); addLCIDMapEntry((Map)hashMap, "en_GB", (short)2057); addLCIDMapEntry((Map)hashMap, "es_MX", (short)2058); addLCIDMapEntry((Map)hashMap, "fr_BE", (short)2060); addLCIDMapEntry((Map)hashMap, "it_CH", (short)2064); addLCIDMapEntry((Map)hashMap, "nl_BE", (short)2067); addLCIDMapEntry((Map)hashMap, "no_NO_NY", (short)2068); addLCIDMapEntry((Map)hashMap, "pt_PT", (short)2070); addLCIDMapEntry((Map)hashMap, "ro_MD", (short)2072); addLCIDMapEntry((Map)hashMap, "ru_MD", (short)2073); addLCIDMapEntry((Map)hashMap, "sr_CS", (short)2074); addLCIDMapEntry((Map)hashMap, "sv_FI", (short)2077); addLCIDMapEntry((Map)hashMap, "az_AZ", (short)2092); addLCIDMapEntry((Map)hashMap, "se_SE", (short)2107); addLCIDMapEntry((Map)hashMap, "ga_IE", (short)2108); addLCIDMapEntry((Map)hashMap, "ms_BN", (short)2110); addLCIDMapEntry((Map)hashMap, "uz_UZ", (short)2115); addLCIDMapEntry((Map)hashMap, "qu_EC", (short)2155); addLCIDMapEntry((Map)hashMap, "ar_EG", (short)3073); addLCIDMapEntry((Map)hashMap, "zh_HK", (short)3076); addLCIDMapEntry((Map)hashMap, "de_AT", (short)3079); addLCIDMapEntry((Map)hashMap, "en_AU", (short)3081); addLCIDMapEntry((Map)hashMap, "fr_CA", (short)3084); addLCIDMapEntry((Map)hashMap, "sr_CS", (short)3098); addLCIDMapEntry((Map)hashMap, "se_FI", (short)3131); addLCIDMapEntry((Map)hashMap, "qu_PE", (short)3179); addLCIDMapEntry((Map)hashMap, "ar_LY", (short)4097); addLCIDMapEntry((Map)hashMap, "zh_SG", (short)4100); addLCIDMapEntry((Map)hashMap, "de_LU", (short)4103); addLCIDMapEntry((Map)hashMap, "en_CA", (short)4105); addLCIDMapEntry((Map)hashMap, "es_GT", (short)4106); addLCIDMapEntry((Map)hashMap, "fr_CH", (short)4108); addLCIDMapEntry((Map)hashMap, "hr_BA", (short)4122); addLCIDMapEntry((Map)hashMap, "ar_DZ", (short)5121); addLCIDMapEntry((Map)hashMap, "zh_MO", (short)5124); addLCIDMapEntry((Map)hashMap, "de_LI", (short)5127); addLCIDMapEntry((Map)hashMap, "en_NZ", (short)5129); addLCIDMapEntry((Map)hashMap, "es_CR", (short)5130); addLCIDMapEntry((Map)hashMap, "fr_LU", (short)5132); addLCIDMapEntry((Map)hashMap, "bs_BA", (short)5146); addLCIDMapEntry((Map)hashMap, "ar_MA", (short)6145); addLCIDMapEntry((Map)hashMap, "en_IE", (short)6153); addLCIDMapEntry((Map)hashMap, "es_PA", (short)6154); addLCIDMapEntry((Map)hashMap, "fr_MC", (short)6156); addLCIDMapEntry((Map)hashMap, "sr_BA", (short)6170); addLCIDMapEntry((Map)hashMap, "ar_TN", (short)7169); addLCIDMapEntry((Map)hashMap, "en_ZA", (short)7177); addLCIDMapEntry((Map)hashMap, "es_DO", (short)7178); addLCIDMapEntry((Map)hashMap, "sr_BA", (short)7194); addLCIDMapEntry((Map)hashMap, "ar_OM", (short)8193); addLCIDMapEntry((Map)hashMap, "en_JM", (short)8201); addLCIDMapEntry((Map)hashMap, "es_VE", (short)8202); addLCIDMapEntry((Map)hashMap, "ar_YE", (short)9217); addLCIDMapEntry((Map)hashMap, "es_CO", (short)9226); addLCIDMapEntry((Map)hashMap, "ar_SY", (short)10241); addLCIDMapEntry((Map)hashMap, "en_BZ", (short)10249); addLCIDMapEntry((Map)hashMap, "es_PE", (short)10250); addLCIDMapEntry((Map)hashMap, "ar_JO", (short)11265); addLCIDMapEntry((Map)hashMap, "en_TT", (short)11273); addLCIDMapEntry((Map)hashMap, "es_AR", (short)11274); addLCIDMapEntry((Map)hashMap, "ar_LB", (short)12289); addLCIDMapEntry((Map)hashMap, "en_ZW", (short)12297); addLCIDMapEntry((Map)hashMap, "es_EC", (short)12298); addLCIDMapEntry((Map)hashMap, "ar_KW", (short)13313); addLCIDMapEntry((Map)hashMap, "en_PH", (short)13321); addLCIDMapEntry((Map)hashMap, "es_CL", (short)13322); addLCIDMapEntry((Map)hashMap, "ar_AE", (short)14337); addLCIDMapEntry((Map)hashMap, "es_UY", (short)14346); addLCIDMapEntry((Map)hashMap, "ar_BH", (short)15361); addLCIDMapEntry((Map)hashMap, "es_PY", (short)15370); addLCIDMapEntry((Map)hashMap, "ar_QA", (short)16385); addLCIDMapEntry((Map)hashMap, "es_BO", (short)16394); addLCIDMapEntry((Map)hashMap, "es_SV", (short)17418); addLCIDMapEntry((Map)hashMap, "es_HN", (short)18442); addLCIDMapEntry((Map)hashMap, "es_NI", (short)19466); addLCIDMapEntry((Map)hashMap, "es_PR", (short)20490); lcidMap = (Map)hashMap; } private static short getLCIDFromLocale(Locale paramLocale) { if (paramLocale.equals(Locale.US) || paramLocale.getLanguage().equals("en")) return 1033;  if (lcidMap == null) createLCIDMap();  String str = paramLocale.toString(); while (!str.isEmpty()) { Short short_ = lcidMap.get(str); if (short_ != null) return short_.shortValue();  int i = str.lastIndexOf('_'); if (i < 1) return 1033;  str = str.substring(0, i); }  return 1033; } static short nameLocaleID = getSystemLCID(); private OpenTypeGlyphMapper mapper; char[] advanceWidths; private float[] styleMetrics; private static short getSystemLCID() { if (PrismFontFactory.isWindows) return PrismFontFactory.getSystemLCID();  return getLCIDFromLocale(Locale.getDefault()); } public CharToGlyphMapper getGlyphMapper() { if (this.mapper == null) this.mapper = new OpenTypeGlyphMapper(this);  return this.mapper; } public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform) { return getStrike(paramFloat, paramBaseTransform, getDefaultAAMode()); } public PrismMetrics getFontMetrics(float paramFloat) { return new PrismMetrics(this.ascent * paramFloat / this.upem, this.descent * paramFloat / this.upem, this.linegap * paramFloat / this.upem, this, paramFloat); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   float[] getStyleMetrics(float paramFloat) {
/* 1221 */     if (this.styleMetrics == null) {
/* 1222 */       float[] arrayOfFloat1 = new float[9];
/*      */       
/* 1224 */       FontFileReader.Buffer buffer1 = readTable(1330851634);
/* 1225 */       byte b1 = (buffer1 != null) ? buffer1.capacity() : 0;
/*      */       
/* 1227 */       if (b1 >= 30) {
/* 1228 */         arrayOfFloat1[5] = buffer1.getShort(26) / this.upem;
/* 1229 */         arrayOfFloat1[6] = -buffer1.getShort(28) / this.upem;
/*      */       } else {
/* 1231 */         arrayOfFloat1[5] = 0.05F;
/* 1232 */         arrayOfFloat1[6] = -0.4F;
/*      */       } 
/* 1234 */       if (b1 >= 74) {
/*      */         
/* 1236 */         arrayOfFloat1[2] = -buffer1.getShort(68) / this.upem;
/* 1237 */         arrayOfFloat1[3] = -buffer1.getShort(70) / this.upem;
/* 1238 */         arrayOfFloat1[4] = buffer1.getShort(72) / this.upem;
/*      */       } else {
/* 1240 */         arrayOfFloat1[2] = this.ascent / this.upem;
/* 1241 */         arrayOfFloat1[3] = this.descent / this.upem;
/* 1242 */         arrayOfFloat1[4] = this.linegap / this.upem;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1247 */       if (b1 >= 90) {
/* 1248 */         arrayOfFloat1[0] = buffer1.getShort(86) / this.upem;
/* 1249 */         arrayOfFloat1[1] = buffer1.getShort(88);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1254 */         if ((arrayOfFloat1[1] / this.ascent) < 0.5D) {
/* 1255 */           arrayOfFloat1[1] = 0.0F;
/*      */         } else {
/* 1257 */           arrayOfFloat1[1] = arrayOfFloat1[1] / this.upem;
/*      */         } 
/*      */       } 
/*      */       
/* 1261 */       if (arrayOfFloat1[0] == 0.0F || arrayOfFloat1[1] == 0.0F) {
/* 1262 */         FontStrike fontStrike = getStrike(paramFloat, BaseTransform.IDENTITY_TRANSFORM);
/* 1263 */         CharToGlyphMapper charToGlyphMapper = getGlyphMapper();
/* 1264 */         int i = charToGlyphMapper.getMissingGlyphCode();
/*      */         
/* 1266 */         if (arrayOfFloat1[0] == 0.0F) {
/* 1267 */           int j = charToGlyphMapper.charToGlyph('x');
/* 1268 */           if (j != i) {
/* 1269 */             RectBounds rectBounds = fontStrike.getGlyph(j).getBBox();
/* 1270 */             arrayOfFloat1[0] = rectBounds.getHeight() / paramFloat;
/*      */           } else {
/* 1272 */             arrayOfFloat1[0] = -this.ascent * 0.6F / this.upem;
/*      */           } 
/*      */         } 
/* 1275 */         if (arrayOfFloat1[1] == 0.0F) {
/* 1276 */           int j = charToGlyphMapper.charToGlyph('H');
/* 1277 */           if (j != i) {
/* 1278 */             RectBounds rectBounds = fontStrike.getGlyph(j).getBBox();
/* 1279 */             arrayOfFloat1[1] = rectBounds.getHeight() / paramFloat;
/*      */           } else {
/* 1281 */             arrayOfFloat1[1] = -this.ascent * 0.9F / this.upem;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1286 */       FontFileReader.Buffer buffer2 = readTable(1886352244);
/* 1287 */       if (buffer2 == null || buffer2.capacity() < 12) {
/* 1288 */         arrayOfFloat1[8] = 0.1F;
/* 1289 */         arrayOfFloat1[7] = 0.05F;
/*      */       } else {
/* 1291 */         arrayOfFloat1[8] = -buffer2.getShort(8) / this.upem;
/* 1292 */         arrayOfFloat1[7] = buffer2.getShort(10) / this.upem;
/*      */       } 
/* 1294 */       this.styleMetrics = arrayOfFloat1;
/*      */     } 
/*      */     
/* 1297 */     float[] arrayOfFloat = new float[9];
/* 1298 */     for (byte b = 0; b < 9; b++) {
/* 1299 */       arrayOfFloat[b] = this.styleMetrics[b] * paramFloat;
/*      */     }
/*      */     
/* 1302 */     return arrayOfFloat;
/*      */   }
/*      */   
/*      */   byte[] getTableBytes(int paramInt) {
/* 1306 */     FontFileReader.Buffer buffer = readTable(paramInt);
/* 1307 */     byte[] arrayOfByte = null;
/* 1308 */     if (buffer != null) {
/* 1309 */       arrayOfByte = new byte[buffer.capacity()];
/* 1310 */       buffer.get(0, arrayOfByte, 0, buffer.capacity());
/*      */     } 
/* 1312 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 1317 */     if (paramObject == null) {
/* 1318 */       return false;
/*      */     }
/* 1320 */     if (!(paramObject instanceof PrismFontFile)) {
/* 1321 */       return false;
/*      */     }
/* 1323 */     PrismFontFile prismFontFile = (PrismFontFile)paramObject;
/* 1324 */     return (this.filename.equals(prismFontFile.filename) && this.fullName.equals(prismFontFile.fullName));
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1329 */     return this.filename.hashCode() + 71 * this.fullName.hashCode();
/*      */   }
/*      */   
/*      */   protected abstract PrismFontStrike createStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc);
/*      */   
/*      */   protected abstract int[] createGlyphBoundingBox(int paramInt);
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismFontFile.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */