/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ import org.w3c.dom.html.HTMLObjectElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLObjectElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLObjectElement
/*     */ {
/*     */   HTMLObjectElementImpl(long paramLong) {
/*  34 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLObjectElement getImpl(long paramLong) {
/*  38 */     return (HTMLObjectElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   public HTMLFormElement getForm() {
/*  44 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */   static native String getCodeImpl(long paramLong);
/*     */   
/*     */   public String getCode() {
/*  49 */     return getCodeImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCode(String paramString) {
/*  54 */     setCodeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCodeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAlign() {
/*  59 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  64 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getArchive() {
/*  69 */     return getArchiveImpl(getPeer());
/*     */   }
/*     */   static native String getArchiveImpl(long paramLong);
/*     */   
/*     */   public void setArchive(String paramString) {
/*  74 */     setArchiveImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setArchiveImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBorder() {
/*  79 */     return getBorderImpl(getPeer());
/*     */   }
/*     */   static native String getBorderImpl(long paramLong);
/*     */   
/*     */   public void setBorder(String paramString) {
/*  84 */     setBorderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBorderImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCodeBase() {
/*  89 */     return getCodeBaseImpl(getPeer());
/*     */   }
/*     */   static native String getCodeBaseImpl(long paramLong);
/*     */   
/*     */   public void setCodeBase(String paramString) {
/*  94 */     setCodeBaseImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCodeBaseImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCodeType() {
/*  99 */     return getCodeTypeImpl(getPeer());
/*     */   }
/*     */   static native String getCodeTypeImpl(long paramLong);
/*     */   
/*     */   public void setCodeType(String paramString) {
/* 104 */     setCodeTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCodeTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getData() {
/* 109 */     return getDataImpl(getPeer());
/*     */   }
/*     */   static native String getDataImpl(long paramLong);
/*     */   
/*     */   public void setData(String paramString) {
/* 114 */     setDataImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDataImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getDeclare() {
/* 119 */     return getDeclareImpl(getPeer());
/*     */   }
/*     */   static native boolean getDeclareImpl(long paramLong);
/*     */   
/*     */   public void setDeclare(boolean paramBoolean) {
/* 124 */     setDeclareImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDeclareImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public String getHeight() {
/* 129 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native String getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(String paramString) {
/* 134 */     setHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHspace() {
/* 139 */     return "" + getHspaceImpl(getPeer());
/*     */   }
/*     */   static native int getHspaceImpl(long paramLong);
/*     */   
/*     */   public void setHspace(String paramString) {
/* 144 */     setHspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setHspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getName() {
/* 149 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 154 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getStandby() {
/* 159 */     return getStandbyImpl(getPeer());
/*     */   }
/*     */   static native String getStandbyImpl(long paramLong);
/*     */   
/*     */   public void setStandby(String paramString) {
/* 164 */     setStandbyImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setStandbyImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 169 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 174 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getUseMap() {
/* 179 */     return getUseMapImpl(getPeer());
/*     */   }
/*     */   static native String getUseMapImpl(long paramLong);
/*     */   
/*     */   public void setUseMap(String paramString) {
/* 184 */     setUseMapImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setUseMapImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVspace() {
/* 189 */     return "" + getVspaceImpl(getPeer());
/*     */   }
/*     */   static native int getVspaceImpl(long paramLong);
/*     */   
/*     */   public void setVspace(String paramString) {
/* 194 */     setVspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setVspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getWidth() {
/* 199 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native String getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 204 */     setWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setWidthImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getWillValidate() {
/* 209 */     return getWillValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getWillValidateImpl(long paramLong);
/*     */   
/*     */   public String getValidationMessage() {
/* 214 */     return getValidationMessageImpl(getPeer());
/*     */   }
/*     */   static native String getValidationMessageImpl(long paramLong);
/*     */   
/*     */   public Document getContentDocument() {
/* 219 */     return DocumentImpl.getImpl(getContentDocumentImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   static native long getContentDocumentImpl(long paramLong);
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 227 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */   
/*     */   public void setCustomValidity(String paramString) {
/* 234 */     setCustomValidityImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLObjectElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */