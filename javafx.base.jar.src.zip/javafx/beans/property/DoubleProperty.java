/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.BidirectionalBinding;
/*     */ import com.sun.javafx.binding.Logging;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ import javafx.beans.value.WritableDoubleValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DoubleProperty
/*     */   extends ReadOnlyDoubleProperty
/*     */   implements Property<Number>, WritableDoubleValue
/*     */ {
/*     */   public void setValue(Number paramNumber) {
/*  75 */     if (paramNumber == null) {
/*  76 */       Logging.getLogger().fine("Attempt to set double property to null, using default value instead.", new NullPointerException());
/*  77 */       set(0.0D);
/*     */     } else {
/*  79 */       set(paramNumber.doubleValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<Number> paramProperty) {
/*  88 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<Number> paramProperty) {
/*  96 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 105 */     Object object = getBean();
/* 106 */     String str = getName();
/* 107 */     StringBuilder stringBuilder = new StringBuilder("DoubleProperty [");
/*     */     
/* 109 */     if (object != null) {
/* 110 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 112 */     if (str != null && !str.equals("")) {
/* 113 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 115 */     stringBuilder.append("value: ").append(get()).append("]");
/* 116 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DoubleProperty doubleProperty(final Property<Double> property) {
/* 155 */     if (property == null) {
/* 156 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/* 158 */     return new DoublePropertyBase()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 166 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 171 */           return property.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 177 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(param1Property, this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 182 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectProperty<Double> asObject() {
/* 209 */     return new ObjectPropertyBase<Double>()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 217 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 222 */           return DoubleProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 228 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbindNumber(this, DoubleProperty.this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 233 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\DoubleProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */