/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.javafx.logging.PlatformLogger;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LocalizedStrings
/*    */ {
/* 34 */   private static final PlatformLogger log = PlatformLogger.getLogger(LocalizedStrings.class.getName());
/*    */ 
/*    */   
/* 37 */   private static final ResourceBundle BUNDLE = ResourceBundle.getBundle("com.sun.webkit.LocalizedStrings", 
/* 38 */       Locale.getDefault());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getLocalizedProperty(String paramString) {
/* 44 */     log.fine("Get property: " + paramString);
/* 45 */     String str = BUNDLE.getString(paramString);
/* 46 */     if (str != null && str.trim().length() > 0) {
/* 47 */       log.fine("Property value: " + str);
/* 48 */       return str.trim();
/*    */     } 
/* 50 */     log.fine("Unknown property value");
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\LocalizedStrings.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */