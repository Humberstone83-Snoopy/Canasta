/*    */ package com.sun.media.jfxmedia.events;
/*    */ 
/*    */ import com.sun.media.jfxmedia.effects.AudioSpectrum;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AudioSpectrumEvent
/*    */   extends PlayerEvent
/*    */ {
/*    */   private AudioSpectrum source;
/*    */   private double timestamp;
/*    */   private double duration;
/*    */   
/*    */   public AudioSpectrumEvent(AudioSpectrum paramAudioSpectrum, double paramDouble1, double paramDouble2) {
/* 36 */     this.source = paramAudioSpectrum;
/* 37 */     this.timestamp = paramDouble1;
/* 38 */     this.duration = paramDouble2;
/*    */   }
/*    */   
/*    */   public final AudioSpectrum getSource() {
/* 42 */     return this.source;
/*    */   }
/*    */   
/*    */   public final double getTimestamp() {
/* 46 */     return this.timestamp;
/*    */   }
/*    */   
/*    */   public final double getDuration() {
/* 50 */     return this.duration;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\events\AudioSpectrumEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */