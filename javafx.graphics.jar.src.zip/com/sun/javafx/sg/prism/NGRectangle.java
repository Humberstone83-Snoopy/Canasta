/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.RectangularShape;
/*     */ import com.sun.javafx.geom.RoundRectangle2D;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.prism.BasicStroke;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.paint.Color;
/*     */ import com.sun.prism.shape.ShapeRep;
/*     */ import com.sun.scenario.effect.Effect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGRectangle
/*     */   extends NGShape
/*     */ {
/*  47 */   private RoundRectangle2D rrect = new RoundRectangle2D();
/*     */   static final float HALF_MINUS_HALF_SQRT_HALF = 0.14700001F;
/*     */   
/*     */   public void updateRectangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  51 */     this.rrect.x = paramFloat1;
/*  52 */     this.rrect.y = paramFloat2;
/*  53 */     this.rrect.width = paramFloat3;
/*  54 */     this.rrect.height = paramFloat4;
/*  55 */     this.rrect.arcWidth = paramFloat5;
/*  56 */     this.rrect.arcHeight = paramFloat6;
/*  57 */     geometryChanged();
/*     */   }
/*     */   
/*     */   protected boolean supportsOpaqueRegions() {
/*  61 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean hasOpaqueRegion() {
/*  65 */     return (super.hasOpaqueRegion() && this.rrect.width > 1.0F && this.rrect.height > 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/*  75 */     float f1 = this.rrect.x;
/*  76 */     float f2 = this.rrect.y;
/*  77 */     float f3 = this.rrect.width;
/*  78 */     float f4 = this.rrect.height;
/*  79 */     float f5 = this.rrect.arcWidth;
/*  80 */     float f6 = this.rrect.arcHeight;
/*     */     
/*  82 */     if (f5 <= 0.0F || f6 <= 0.0F)
/*     */     {
/*     */ 
/*     */       
/*  86 */       return (RectBounds)paramRectBounds.deriveWithNewBounds(f1, f2, 0.0F, f1 + f3, f2 + f4, 0.0F);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  91 */     float f7 = Math.min(f3, f5) * 0.14700001F;
/*  92 */     float f8 = Math.min(f4, f6) * 0.14700001F;
/*  93 */     return (RectBounds)paramRectBounds.deriveWithNewBounds(f1 + f7, f2 + f8, 0.0F, f1 + f3 - f7, f2 + f4 - f8, 0.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isRounded() {
/* 100 */     return (this.rrect.arcWidth > 0.0F && this.rrect.arcHeight > 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderEffect(Graphics paramGraphics) {
/* 105 */     if (!(paramGraphics instanceof com.sun.prism.RectShadowGraphics) || !renderEffectDirectly(paramGraphics)) {
/* 106 */       super.renderEffect(paramGraphics);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean renderEffectDirectly(Graphics paramGraphics) {
/* 111 */     if (this.mode != NGShape.Mode.FILL || isRounded())
/*     */     {
/* 113 */       return false;
/*     */     }
/* 115 */     float f = paramGraphics.getExtraAlpha();
/* 116 */     if (this.fillPaint instanceof Color) {
/* 117 */       f *= ((Color)this.fillPaint).getAlpha();
/*     */     } else {
/*     */       
/* 120 */       return false;
/*     */     } 
/* 122 */     Effect effect = getEffect();
/* 123 */     if (EffectUtil.renderEffectForRectangularNode(this, paramGraphics, effect, f, true, this.rrect.x, this.rrect.y, this.rrect.width, this.rrect.height))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 128 */       return true;
/*     */     }
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Shape getShape() {
/* 135 */     return this.rrect;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ShapeRep createShapeRep(Graphics paramGraphics) {
/* 140 */     return paramGraphics.getResourceFactory().createRoundRectRep();
/*     */   }
/*     */   
/* 143 */   private static final double SQRT_2 = Math.sqrt(2.0D);
/*     */   private static boolean hasRightAngleMiterAndNoDashes(BasicStroke paramBasicStroke) {
/* 145 */     return (paramBasicStroke.getLineJoin() == 0 && paramBasicStroke
/* 146 */       .getMiterLimit() >= SQRT_2 && paramBasicStroke
/* 147 */       .getDashArray() == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean rectContains(float paramFloat1, float paramFloat2, NGShape paramNGShape, RectangularShape paramRectangularShape) {
/* 154 */     double d1 = paramRectangularShape.getWidth();
/* 155 */     double d2 = paramRectangularShape.getHeight();
/* 156 */     if (d1 < 0.0D || d2 < 0.0D) {
/* 157 */       return false;
/*     */     }
/* 159 */     NGShape.Mode mode = paramNGShape.mode;
/* 160 */     if (mode == NGShape.Mode.EMPTY) {
/* 161 */       return false;
/*     */     }
/* 163 */     double d3 = paramRectangularShape.getX();
/* 164 */     double d4 = paramRectangularShape.getY();
/* 165 */     if (mode == NGShape.Mode.FILL)
/*     */     {
/* 167 */       return (paramFloat1 >= d3 && paramFloat2 >= d4 && paramFloat1 < d3 + d1 && paramFloat2 < d4 + d2);
/*     */     }
/*     */     
/* 170 */     float f1 = -1.0F;
/* 171 */     float f2 = -1.0F;
/* 172 */     boolean bool = false;
/* 173 */     BasicStroke basicStroke = paramNGShape.drawStroke;
/* 174 */     int i = basicStroke.getType();
/* 175 */     if (i == 1) {
/* 176 */       if (mode == NGShape.Mode.STROKE_FILL) {
/* 177 */         f1 = 0.0F;
/*     */       }
/* 179 */       else if (basicStroke.getDashArray() == null) {
/* 180 */         f1 = 0.0F;
/* 181 */         f2 = basicStroke.getLineWidth();
/*     */       } else {
/* 183 */         bool = true;
/*     */       }
/*     */     
/* 186 */     } else if (i == 2) {
/* 187 */       if (hasRightAngleMiterAndNoDashes(basicStroke)) {
/* 188 */         f1 = basicStroke.getLineWidth();
/* 189 */         if (mode == NGShape.Mode.STROKE) {
/* 190 */           f2 = 0.0F;
/*     */         }
/*     */       } else {
/* 193 */         if (mode == NGShape.Mode.STROKE_FILL) {
/* 194 */           f1 = 0.0F;
/*     */         }
/* 196 */         bool = true;
/*     */       } 
/* 198 */     } else if (i == 0) {
/* 199 */       if (hasRightAngleMiterAndNoDashes(basicStroke)) {
/* 200 */         f1 = basicStroke.getLineWidth() / 2.0F;
/* 201 */         if (mode == NGShape.Mode.STROKE) {
/* 202 */           f2 = f1;
/*     */         }
/*     */       } else {
/* 205 */         if (mode == NGShape.Mode.STROKE_FILL) {
/* 206 */           f1 = 0.0F;
/*     */         }
/* 208 */         bool = true;
/*     */       } 
/*     */     } else {
/*     */       
/* 212 */       if (mode == NGShape.Mode.STROKE_FILL) {
/* 213 */         f1 = 0.0F;
/*     */       }
/* 215 */       bool = true;
/*     */     } 
/* 217 */     if (f1 >= 0.0F && 
/* 218 */       paramFloat1 >= d3 - f1 && paramFloat2 >= d4 - f1 && paramFloat1 < d3 + d1 + f1 && paramFloat2 < d4 + d2 + f1) {
/*     */ 
/*     */       
/* 221 */       if (f2 >= 0.0F && f2 < d1 / 2.0D && f2 < d2 / 2.0D && paramFloat1 >= d3 + f2 && paramFloat2 >= d4 + f2 && paramFloat1 < d3 + d1 - f2 && paramFloat2 < d4 + d2 - f2)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         return false;
/*     */       }
/* 231 */       return true;
/*     */     } 
/*     */     
/* 234 */     if (bool) {
/* 235 */       return paramNGShape.getStrokeShape().contains(paramFloat1, paramFloat2);
/*     */     }
/* 237 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isRectClip(BaseTransform paramBaseTransform, boolean paramBoolean) {
/* 256 */     if (this.mode != NGShape.Mode.FILL || getClipNode() != null || (getEffect() != null && getEffect().reducesOpaquePixels()) || 
/* 257 */       getOpacity() < 1.0F || (!paramBoolean && isRounded()) || !this.fillPaint.isOpaque())
/*     */     {
/* 259 */       return false;
/*     */     }
/*     */     
/* 262 */     BaseTransform baseTransform = getTransform();
/* 263 */     if (!baseTransform.isIdentity())
/*     */     {
/*     */       
/* 266 */       if (!paramBaseTransform.isIdentity()) {
/* 267 */         TEMP_TRANSFORM.setTransform(paramBaseTransform);
/* 268 */         TEMP_TRANSFORM.concatenate(baseTransform);
/* 269 */         paramBaseTransform = TEMP_TRANSFORM;
/*     */       } else {
/* 271 */         paramBaseTransform = baseTransform;
/*     */       } 
/*     */     }
/*     */     
/* 275 */     long l = paramBaseTransform.getType();
/* 276 */     return ((l & 0xFFFFFFFFFFFFFFF0L) == 0L);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGRectangle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */