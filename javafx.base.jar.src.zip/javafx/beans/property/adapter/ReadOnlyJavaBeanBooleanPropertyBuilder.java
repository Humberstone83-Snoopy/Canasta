/*     */ package javafx.beans.property.adapter;
/*     */ 
/*     */ import com.sun.javafx.property.adapter.ReadOnlyJavaBeanPropertyBuilderHelper;
/*     */ import com.sun.javafx.property.adapter.ReadOnlyPropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadOnlyJavaBeanBooleanPropertyBuilder
/*     */ {
/*  61 */   private final ReadOnlyJavaBeanPropertyBuilderHelper helper = new ReadOnlyJavaBeanPropertyBuilderHelper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyJavaBeanBooleanPropertyBuilder create() {
/*  69 */     return new ReadOnlyJavaBeanBooleanPropertyBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanProperty build() throws NoSuchMethodException {
/*  82 */     ReadOnlyPropertyDescriptor readOnlyPropertyDescriptor = this.helper.getDescriptor();
/*  83 */     if (!boolean.class.equals(readOnlyPropertyDescriptor.getType()) && !Boolean.class.equals(readOnlyPropertyDescriptor.getType())) {
/*  84 */       throw new IllegalArgumentException("Not a boolean property");
/*     */     }
/*  86 */     return new ReadOnlyJavaBeanBooleanProperty(readOnlyPropertyDescriptor, this.helper.getBean());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanPropertyBuilder name(String paramString) {
/*  96 */     this.helper.name(paramString);
/*  97 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanPropertyBuilder bean(Object paramObject) {
/* 107 */     this.helper.bean(paramObject);
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanPropertyBuilder beanClass(Class<?> paramClass) {
/* 120 */     this.helper.beanClass(paramClass);
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanPropertyBuilder getter(String paramString) {
/* 132 */     this.helper.getterName(paramString);
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyJavaBeanBooleanPropertyBuilder getter(Method paramMethod) {
/* 144 */     this.helper.getter(paramMethod);
/* 145 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\adapter\ReadOnlyJavaBeanBooleanPropertyBuilder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */