/*     */ package com.sun.media.jfxmediaimpl.platform;
/*     */ 
/*     */ import com.sun.media.jfxmedia.Media;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.MetadataParser;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import com.sun.media.jfxmediaimpl.HostUtils;
/*     */ import com.sun.media.jfxmediaimpl.platform.gstreamer.GSTPlatform;
/*     */ import com.sun.media.jfxmediaimpl.platform.ios.IOSPlatform;
/*     */ import com.sun.media.jfxmediaimpl.platform.java.JavaPlatform;
/*     */ import com.sun.media.jfxmediaimpl.platform.osx.OSXPlatform;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PlatformManager
/*     */ {
/*     */   private static String enabledPlatforms;
/*     */   private final List<Platform> platforms;
/*     */   
/*     */   static {
/*  50 */     AccessController.doPrivileged(() -> {
/*     */           getPlatformSettings();
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private static void getPlatformSettings() {
/*  58 */     enabledPlatforms = System.getProperty("jfxmedia.platforms", "").toLowerCase();
/*     */   }
/*     */   
/*     */   private static boolean isPlatformEnabled(String paramString) {
/*  62 */     if (null == enabledPlatforms || enabledPlatforms.length() == 0)
/*     */     {
/*  64 */       return true;
/*     */     }
/*  66 */     return (enabledPlatforms.indexOf(paramString.toLowerCase()) != -1);
/*     */   }
/*     */   
/*     */   private static final class PlatformManagerInitializer {
/*  70 */     private static final PlatformManager globalInstance = new PlatformManager();
/*     */   }
/*     */   
/*     */   public static PlatformManager getManager() {
/*  74 */     return PlatformManagerInitializer.globalInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private PlatformManager() {
/*  80 */     this.platforms = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     if (isPlatformEnabled("JavaPlatform")) {
/*  94 */       Platform platform = JavaPlatform.getPlatformInstance();
/*  95 */       if (null != platform) {
/*  96 */         this.platforms.add(platform);
/*     */       }
/*     */     } 
/*     */     
/* 100 */     if (!HostUtils.isIOS() && isPlatformEnabled("GSTPlatform")) {
/* 101 */       Platform platform = GSTPlatform.getPlatformInstance();
/* 102 */       if (null != platform) {
/* 103 */         this.platforms.add(platform);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 108 */     if (HostUtils.isMacOSX() && isPlatformEnabled("OSXPlatform")) {
/* 109 */       Platform platform = OSXPlatform.getPlatformInstance();
/* 110 */       if (null != platform) {
/* 111 */         this.platforms.add(platform);
/*     */       }
/*     */     } 
/*     */     
/* 115 */     if (HostUtils.isIOS() && isPlatformEnabled("IOSPlatform")) {
/* 116 */       Platform platform = IOSPlatform.getPlatformInstance();
/* 117 */       if (null != platform) {
/* 118 */         this.platforms.add(platform);
/*     */       }
/*     */     } 
/*     */     
/* 122 */     if (Logger.canLog(1)) {
/* 123 */       StringBuilder stringBuilder = new StringBuilder("Enabled JFXMedia platforms: ");
/* 124 */       for (Platform platform : this.platforms) {
/* 125 */         stringBuilder.append("\n   - ");
/* 126 */         stringBuilder.append(platform.getClass().getName());
/*     */       } 
/* 128 */       Logger.logMsg(1, stringBuilder.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void loadPlatforms() {
/* 134 */     Iterator<Platform> iterator = this.platforms.iterator();
/* 135 */     while (iterator.hasNext()) {
/* 136 */       Platform platform = iterator.next();
/* 137 */       if (!platform.loadPlatform()) {
/* 138 */         if (Logger.canLog(1)) {
/* 139 */           Logger.logMsg(1, "Failed to load platform: " + platform);
/*     */         }
/*     */         
/* 142 */         iterator.remove();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<String> getSupportedContentTypes() {
/* 148 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 150 */     if (!this.platforms.isEmpty()) {
/* 151 */       for (Platform platform : this.platforms) {
/* 152 */         if (Logger.canLog(1)) {
/* 153 */           Logger.logMsg(1, "Getting content types from platform: " + platform);
/*     */         }
/* 155 */         String[] arrayOfString = platform.getSupportedContentTypes();
/* 156 */         if (arrayOfString != null) {
/* 157 */           for (String str : arrayOfString) {
/* 158 */             if (!arrayList.contains(str)) {
/* 159 */               arrayList.add(str);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 166 */     return arrayList;
/*     */   }
/*     */   
/*     */   public List<String> getSupportedProtocols() {
/* 170 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 172 */     if (!this.platforms.isEmpty()) {
/* 173 */       for (Platform platform : this.platforms) {
/* 174 */         String[] arrayOfString = platform.getSupportedProtocols();
/* 175 */         if (arrayOfString != null) {
/* 176 */           for (String str : arrayOfString) {
/* 177 */             if (!arrayList.contains(str)) {
/* 178 */               arrayList.add(str);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 185 */     return arrayList;
/*     */   }
/*     */   
/*     */   public MetadataParser createMetadataParser(Locator paramLocator) {
/* 189 */     for (Platform platform : this.platforms) {
/* 190 */       MetadataParser metadataParser = platform.createMetadataParser(paramLocator);
/* 191 */       if (metadataParser != null) {
/* 192 */         return metadataParser;
/*     */       }
/*     */     } 
/*     */     
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Media createMedia(Locator paramLocator) {
/* 201 */     String str1 = paramLocator.getContentType();
/* 202 */     String str2 = paramLocator.getProtocol();
/*     */     
/* 204 */     for (Platform platform : this.platforms) {
/* 205 */       if (platform.canPlayContentType(str1) && platform.canPlayProtocol(str2)) {
/* 206 */         Media media = platform.createMedia(paramLocator);
/* 207 */         if (null != media) {
/* 208 */           return media;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 213 */     return null;
/*     */   }
/*     */   
/*     */   public MediaPlayer createMediaPlayer(Locator paramLocator) {
/* 217 */     String str1 = paramLocator.getContentType();
/* 218 */     String str2 = paramLocator.getProtocol();
/*     */     
/* 220 */     for (Platform platform : this.platforms) {
/* 221 */       if (platform.canPlayContentType(str1) && platform.canPlayProtocol(str2)) {
/* 222 */         MediaPlayer mediaPlayer = platform.createMediaPlayer(paramLocator);
/* 223 */         if (null != mediaPlayer) {
/* 224 */           return mediaPlayer;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 229 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\PlatformManager.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */