package com.sun.glass.ui.delegate;

import com.sun.glass.ui.MenuItem;
import com.sun.glass.ui.Pixels;

public interface MenuItemDelegate {
  boolean createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean setTitle(String paramString);
  
  boolean setCallback(MenuItem.Callback paramCallback);
  
  boolean setShortcut(int paramInt1, int paramInt2);
  
  boolean setPixels(Pixels paramPixels);
  
  boolean setEnabled(boolean paramBoolean);
  
  boolean setChecked(boolean paramBoolean);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\delegate\MenuItemDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */