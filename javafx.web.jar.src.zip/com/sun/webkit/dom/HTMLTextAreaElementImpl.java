/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.html.HTMLFormElement;
/*     */ import org.w3c.dom.html.HTMLTextAreaElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTextAreaElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLTextAreaElement
/*     */ {
/*     */   HTMLTextAreaElementImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLTextAreaElement getImpl(long paramLong) {
/*  39 */     return (HTMLTextAreaElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native boolean getAutofocusImpl(long paramLong);
/*     */   
/*     */   public boolean getAutofocus() {
/*  45 */     return getAutofocusImpl(getPeer());
/*     */   }
/*     */   static native void setAutofocusImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public void setAutofocus(boolean paramBoolean) {
/*  50 */     setAutofocusImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDirName() {
/*  55 */     return getDirNameImpl(getPeer());
/*     */   }
/*     */   static native String getDirNameImpl(long paramLong);
/*     */   
/*     */   public void setDirName(String paramString) {
/*  60 */     setDirNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDirNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getDisabled() {
/*  65 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  70 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public HTMLFormElement getForm() {
/*  75 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*     */   }
/*     */   static native long getFormImpl(long paramLong);
/*     */   
/*     */   public int getMaxLength() {
/*  80 */     return getMaxLengthImpl(getPeer());
/*     */   }
/*     */   static native int getMaxLengthImpl(long paramLong);
/*     */   
/*     */   public void setMaxLength(int paramInt) throws DOMException {
/*  85 */     setMaxLengthImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setMaxLengthImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getName() {
/*  90 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/*  95 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPlaceholder() {
/* 100 */     return getPlaceholderImpl(getPeer());
/*     */   }
/*     */   static native String getPlaceholderImpl(long paramLong);
/*     */   
/*     */   public void setPlaceholder(String paramString) {
/* 105 */     setPlaceholderImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPlaceholderImpl(long paramLong, String paramString);
/*     */   
/*     */   public boolean getReadOnly() {
/* 110 */     return getReadOnlyImpl(getPeer());
/*     */   }
/*     */   static native boolean getReadOnlyImpl(long paramLong);
/*     */   
/*     */   public void setReadOnly(boolean paramBoolean) {
/* 115 */     setReadOnlyImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setReadOnlyImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public boolean getRequired() {
/* 120 */     return getRequiredImpl(getPeer());
/*     */   }
/*     */   static native boolean getRequiredImpl(long paramLong);
/*     */   
/*     */   public void setRequired(boolean paramBoolean) {
/* 125 */     setRequiredImpl(getPeer(), paramBoolean);
/*     */   }
/*     */   static native void setRequiredImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public int getRows() {
/* 130 */     return getRowsImpl(getPeer());
/*     */   }
/*     */   static native int getRowsImpl(long paramLong);
/*     */   
/*     */   public void setRows(int paramInt) {
/* 135 */     setRowsImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setRowsImpl(long paramLong, int paramInt);
/*     */   
/*     */   public int getCols() {
/* 140 */     return getColsImpl(getPeer());
/*     */   }
/*     */   static native int getColsImpl(long paramLong);
/*     */   
/*     */   public void setCols(int paramInt) {
/* 145 */     setColsImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setColsImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getWrap() {
/* 150 */     return getWrapImpl(getPeer());
/*     */   }
/*     */   static native String getWrapImpl(long paramLong);
/*     */   
/*     */   public void setWrap(String paramString) {
/* 155 */     setWrapImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setWrapImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 160 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public String getDefaultValue() {
/* 165 */     return getDefaultValueImpl(getPeer());
/*     */   }
/*     */   static native String getDefaultValueImpl(long paramLong);
/*     */   
/*     */   public void setDefaultValue(String paramString) {
/* 170 */     setDefaultValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setDefaultValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getValue() {
/* 175 */     return getValueImpl(getPeer());
/*     */   }
/*     */   static native String getValueImpl(long paramLong);
/*     */   
/*     */   public void setValue(String paramString) {
/* 180 */     setValueImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setValueImpl(long paramLong, String paramString);
/*     */   
/*     */   public int getTextLength() {
/* 185 */     return getTextLengthImpl(getPeer());
/*     */   }
/*     */   static native int getTextLengthImpl(long paramLong);
/*     */   
/*     */   public boolean getWillValidate() {
/* 190 */     return getWillValidateImpl(getPeer());
/*     */   }
/*     */   static native boolean getWillValidateImpl(long paramLong);
/*     */   
/*     */   public String getValidationMessage() {
/* 195 */     return getValidationMessageImpl(getPeer());
/*     */   }
/*     */   static native String getValidationMessageImpl(long paramLong);
/*     */   
/*     */   public NodeList getLabels() {
/* 200 */     return NodeListImpl.getImpl(getLabelsImpl(getPeer()));
/*     */   }
/*     */   static native long getLabelsImpl(long paramLong);
/*     */   
/*     */   public int getSelectionStart() {
/* 205 */     return getSelectionStartImpl(getPeer());
/*     */   }
/*     */   static native int getSelectionStartImpl(long paramLong);
/*     */   
/*     */   public void setSelectionStart(int paramInt) {
/* 210 */     setSelectionStartImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setSelectionStartImpl(long paramLong, int paramInt);
/*     */   
/*     */   public int getSelectionEnd() {
/* 215 */     return getSelectionEndImpl(getPeer());
/*     */   }
/*     */   static native int getSelectionEndImpl(long paramLong);
/*     */   
/*     */   public void setSelectionEnd(int paramInt) {
/* 220 */     setSelectionEndImpl(getPeer(), paramInt);
/*     */   }
/*     */   static native void setSelectionEndImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getSelectionDirection() {
/* 225 */     return getSelectionDirectionImpl(getPeer());
/*     */   }
/*     */   static native String getSelectionDirectionImpl(long paramLong);
/*     */   
/*     */   public void setSelectionDirection(String paramString) {
/* 230 */     setSelectionDirectionImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSelectionDirectionImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAccessKey() {
/* 235 */     return getAccessKeyImpl(getPeer());
/*     */   }
/*     */   static native String getAccessKeyImpl(long paramLong);
/*     */   
/*     */   public void setAccessKey(String paramString) {
/* 240 */     setAccessKeyImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getAutocomplete() {
/* 245 */     return getAutocompleteImpl(getPeer());
/*     */   }
/*     */   static native String getAutocompleteImpl(long paramLong);
/*     */   
/*     */   public void setAutocomplete(String paramString) {
/* 250 */     setAutocompleteImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setAutocompleteImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public boolean checkValidity() {
/* 258 */     return checkValidityImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native boolean checkValidityImpl(long paramLong);
/*     */   
/*     */   public void setCustomValidity(String paramString) {
/* 265 */     setCustomValidityImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setCustomValidityImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public void select() {
/* 274 */     selectImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   static native void selectImpl(long paramLong);
/*     */   
/*     */   public void setRangeText(String paramString) throws DOMException {
/* 281 */     setRangeTextImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setRangeTextImpl(long paramLong, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRangeTextEx(String paramString1, int paramInt1, int paramInt2, String paramString2) throws DOMException {
/* 293 */     setRangeTextExImpl(getPeer(), paramString1, paramInt1, paramInt2, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native void setRangeTextExImpl(long paramLong, String paramString1, int paramInt1, int paramInt2, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectionRange(int paramInt1, int paramInt2, String paramString) {
/* 310 */     setSelectionRangeImpl(getPeer(), paramInt1, paramInt2, paramString);
/*     */   }
/*     */   
/*     */   static native void setSelectionRangeImpl(long paramLong, int paramInt1, int paramInt2, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTextAreaElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */