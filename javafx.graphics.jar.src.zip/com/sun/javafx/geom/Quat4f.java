/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Quat4f
/*     */ {
/*     */   static final double EPS2 = 1.0E-30D;
/*     */   public float x;
/*     */   public float y;
/*     */   public float z;
/*     */   public float w;
/*     */   
/*     */   public Quat4f() {
/*  58 */     this.x = 0.0F;
/*  59 */     this.y = 0.0F;
/*  60 */     this.z = 0.0F;
/*  61 */     this.w = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Quat4f(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  73 */     float f = (float)(1.0D / Math.sqrt((paramFloat1 * paramFloat1 + paramFloat2 * paramFloat2 + paramFloat3 * paramFloat3 + paramFloat4 * paramFloat4)));
/*  74 */     this.x = paramFloat1 * f;
/*  75 */     this.y = paramFloat2 * f;
/*  76 */     this.z = paramFloat3 * f;
/*  77 */     this.w = paramFloat4 * f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Quat4f(float[] paramArrayOffloat) {
/*  87 */     float f = (float)(1.0D / Math.sqrt((paramArrayOffloat[0] * paramArrayOffloat[0] + paramArrayOffloat[1] * paramArrayOffloat[1] + paramArrayOffloat[2] * paramArrayOffloat[2] + paramArrayOffloat[3] * paramArrayOffloat[3])));
/*  88 */     this.x = paramArrayOffloat[0] * f;
/*  89 */     this.y = paramArrayOffloat[1] * f;
/*  90 */     this.z = paramArrayOffloat[2] * f;
/*  91 */     this.w = paramArrayOffloat[3] * f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Quat4f(Quat4f paramQuat4f) {
/* 100 */     this.x = paramQuat4f.x;
/* 101 */     this.y = paramQuat4f.y;
/* 102 */     this.z = paramQuat4f.z;
/* 103 */     this.w = paramQuat4f.w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void normalize() {
/* 112 */     float f = this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
/*     */     
/* 114 */     if (f > 0.0F) {
/* 115 */       f = 1.0F / (float)Math.sqrt(f);
/* 116 */       this.x *= f;
/* 117 */       this.y *= f;
/* 118 */       this.z *= f;
/* 119 */       this.w *= f;
/*     */     } else {
/* 121 */       this.x = 0.0F;
/* 122 */       this.y = 0.0F;
/* 123 */       this.z = 0.0F;
/* 124 */       this.w = 0.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(Matrix3f paramMatrix3f) {
/* 134 */     float f = 0.25F * (paramMatrix3f.m00 + paramMatrix3f.m11 + paramMatrix3f.m22 + 1.0F);
/*     */     
/* 136 */     if (f >= 0.0F) {
/* 137 */       if (f >= 1.0E-30D) {
/* 138 */         this.w = (float)Math.sqrt(f);
/* 139 */         f = 0.25F / this.w;
/* 140 */         this.x = (paramMatrix3f.m21 - paramMatrix3f.m12) * f;
/* 141 */         this.y = (paramMatrix3f.m02 - paramMatrix3f.m20) * f;
/* 142 */         this.z = (paramMatrix3f.m10 - paramMatrix3f.m01) * f;
/*     */         return;
/*     */       } 
/*     */     } else {
/* 146 */       this.w = 0.0F;
/* 147 */       this.x = 0.0F;
/* 148 */       this.y = 0.0F;
/* 149 */       this.z = 1.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 153 */     this.w = 0.0F;
/* 154 */     f = -0.5F * (paramMatrix3f.m11 + paramMatrix3f.m22);
/* 155 */     if (f >= 0.0F) {
/* 156 */       if (f >= 1.0E-30D) {
/* 157 */         this.x = (float)Math.sqrt(f);
/* 158 */         f = 0.5F / this.x;
/* 159 */         this.y = paramMatrix3f.m10 * f;
/* 160 */         this.z = paramMatrix3f.m20 * f;
/*     */         return;
/*     */       } 
/*     */     } else {
/* 164 */       this.x = 0.0F;
/* 165 */       this.y = 0.0F;
/* 166 */       this.z = 1.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 170 */     this.x = 0.0F;
/* 171 */     f = 0.5F * (1.0F - paramMatrix3f.m22);
/* 172 */     if (f >= 1.0E-30D) {
/* 173 */       this.y = (float)Math.sqrt(f);
/* 174 */       this.z = paramMatrix3f.m21 / 2.0F * this.y;
/*     */       
/*     */       return;
/*     */     } 
/* 178 */     this.y = 0.0F;
/* 179 */     this.z = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(float[][] paramArrayOffloat) {
/* 188 */     float f = 0.25F * (paramArrayOffloat[0][0] + paramArrayOffloat[1][1] + paramArrayOffloat[2][2] + 1.0F);
/*     */     
/* 190 */     if (f >= 0.0F) {
/* 191 */       if (f >= 1.0E-30D) {
/* 192 */         this.w = (float)Math.sqrt(f);
/* 193 */         f = 0.25F / this.w;
/* 194 */         this.x = (paramArrayOffloat[2][1] - paramArrayOffloat[1][2]) * f;
/* 195 */         this.y = (paramArrayOffloat[0][2] - paramArrayOffloat[2][0]) * f;
/* 196 */         this.z = (paramArrayOffloat[1][0] - paramArrayOffloat[0][1]) * f;
/*     */         return;
/*     */       } 
/*     */     } else {
/* 200 */       this.w = 0.0F;
/* 201 */       this.x = 0.0F;
/* 202 */       this.y = 0.0F;
/* 203 */       this.z = 1.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 207 */     this.w = 0.0F;
/* 208 */     f = -0.5F * (paramArrayOffloat[1][1] + paramArrayOffloat[2][2]);
/* 209 */     if (f >= 0.0F) {
/* 210 */       if (f >= 1.0E-30D) {
/* 211 */         this.x = (float)Math.sqrt(f);
/* 212 */         f = 0.5F / this.x;
/* 213 */         this.y = paramArrayOffloat[1][0] * f;
/* 214 */         this.z = paramArrayOffloat[2][0] * f;
/*     */         return;
/*     */       } 
/*     */     } else {
/* 218 */       this.x = 0.0F;
/* 219 */       this.y = 0.0F;
/* 220 */       this.z = 1.0F;
/*     */       
/*     */       return;
/*     */     } 
/* 224 */     this.x = 0.0F;
/* 225 */     f = 0.5F * (1.0F - paramArrayOffloat[2][2]);
/* 226 */     if (f >= 1.0E-30D) {
/* 227 */       this.y = (float)Math.sqrt(f);
/* 228 */       this.z = paramArrayOffloat[2][1] / 2.0F * this.y;
/*     */       
/*     */       return;
/*     */     } 
/* 232 */     this.y = 0.0F;
/* 233 */     this.z = 1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scale(float paramFloat) {
/* 243 */     this.x *= paramFloat;
/* 244 */     this.y *= paramFloat;
/* 245 */     this.z *= paramFloat;
/* 246 */     this.w *= paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 257 */     return "Quat4f[" + this.x + ", " + this.y + ", " + this.z + ", " + this.w + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Quat4f.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */