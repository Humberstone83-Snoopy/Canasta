/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ArcIterator
/*     */   implements PathIterator
/*     */ {
/*     */   double x;
/*     */   double y;
/*     */   double w;
/*     */   double h;
/*     */   double angStRad;
/*     */   double increment;
/*     */   double cv;
/*     */   BaseTransform transform;
/*     */   int index;
/*     */   int arcSegs;
/*     */   int lineSegs;
/*     */   
/*     */   ArcIterator(Arc2D paramArc2D, BaseTransform paramBaseTransform) {
/*  46 */     this.w = (paramArc2D.width / 2.0F);
/*  47 */     this.h = (paramArc2D.height / 2.0F);
/*  48 */     this.x = paramArc2D.x + this.w;
/*  49 */     this.y = paramArc2D.y + this.h;
/*  50 */     this.angStRad = -Math.toRadians(paramArc2D.start);
/*  51 */     this.transform = paramBaseTransform;
/*  52 */     double d = -paramArc2D.extent;
/*  53 */     if (d >= 360.0D || d <= -360.0D) {
/*  54 */       this.arcSegs = 4;
/*  55 */       this.increment = 1.5707963267948966D;
/*     */       
/*  57 */       this.cv = 0.5522847498307933D;
/*  58 */       if (d < 0.0D) {
/*  59 */         this.increment = -this.increment;
/*  60 */         this.cv = -this.cv;
/*     */       } 
/*     */     } else {
/*  63 */       this.arcSegs = (int)Math.ceil(Math.abs(d) / 90.0D);
/*  64 */       this.increment = Math.toRadians(d / this.arcSegs);
/*  65 */       this.cv = btan(this.increment);
/*  66 */       if (this.cv == 0.0D) {
/*  67 */         this.arcSegs = 0;
/*     */       }
/*     */     } 
/*  70 */     switch (paramArc2D.getArcType()) {
/*     */       case 0:
/*  72 */         this.lineSegs = 0;
/*     */         break;
/*     */       case 1:
/*  75 */         this.lineSegs = 1;
/*     */         break;
/*     */       case 2:
/*  78 */         this.lineSegs = 2;
/*     */         break;
/*     */     } 
/*  81 */     if (this.w < 0.0D || this.h < 0.0D) {
/*  82 */       this.arcSegs = this.lineSegs = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/*  93 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/* 101 */     return (this.index > this.arcSegs + this.lineSegs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/* 110 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double btan(double paramDouble) {
/* 191 */     paramDouble /= 2.0D;
/* 192 */     return 1.3333333333333333D * Math.sin(paramDouble) / (1.0D + Math.cos(paramDouble));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/* 214 */     if (isDone()) {
/* 215 */       throw new NoSuchElementException("arc iterator out of bounds");
/*     */     }
/* 217 */     double d1 = this.angStRad;
/* 218 */     if (this.index == 0) {
/* 219 */       paramArrayOffloat[0] = (float)(this.x + Math.cos(d1) * this.w);
/* 220 */       paramArrayOffloat[1] = (float)(this.y + Math.sin(d1) * this.h);
/* 221 */       if (this.transform != null) {
/* 222 */         this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 1);
/*     */       }
/* 224 */       return 0;
/*     */     } 
/* 226 */     if (this.index > this.arcSegs) {
/* 227 */       if (this.index == this.arcSegs + this.lineSegs) {
/* 228 */         return 4;
/*     */       }
/* 230 */       paramArrayOffloat[0] = (float)this.x;
/* 231 */       paramArrayOffloat[1] = (float)this.y;
/* 232 */       if (this.transform != null) {
/* 233 */         this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 1);
/*     */       }
/* 235 */       return 1;
/*     */     } 
/* 237 */     d1 += this.increment * (this.index - 1);
/* 238 */     double d2 = Math.cos(d1);
/* 239 */     double d3 = Math.sin(d1);
/* 240 */     paramArrayOffloat[0] = (float)(this.x + (d2 - this.cv * d3) * this.w);
/* 241 */     paramArrayOffloat[1] = (float)(this.y + (d3 + this.cv * d2) * this.h);
/* 242 */     d1 += this.increment;
/* 243 */     d2 = Math.cos(d1);
/* 244 */     d3 = Math.sin(d1);
/* 245 */     paramArrayOffloat[2] = (float)(this.x + (d2 + this.cv * d3) * this.w);
/* 246 */     paramArrayOffloat[3] = (float)(this.y + (d3 - this.cv * d2) * this.h);
/* 247 */     paramArrayOffloat[4] = (float)(this.x + d2 * this.w);
/* 248 */     paramArrayOffloat[5] = (float)(this.y + d3 * this.h);
/* 249 */     if (this.transform != null) {
/* 250 */       this.transform.transform(paramArrayOffloat, 0, paramArrayOffloat, 0, 3);
/*     */     }
/* 252 */     return 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\ArcIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */