/*      */ package com.sun.javafx.geom;
/*      */ 
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CubicCurve2D
/*      */   extends Shape
/*      */ {
/*      */   public float x1;
/*      */   public float y1;
/*      */   public float ctrlx1;
/*      */   public float ctrly1;
/*      */   public float ctrlx2;
/*      */   public float ctrly2;
/*      */   public float x2;
/*      */   public float y2;
/*      */   private static final int BELOW = -2;
/*      */   private static final int LOWEDGE = -1;
/*      */   private static final int INSIDE = 0;
/*      */   private static final int HIGHEDGE = 1;
/*      */   private static final int ABOVE = 2;
/*      */   
/*      */   public CubicCurve2D() {}
/*      */   
/*      */   public CubicCurve2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  124 */     setCurve(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  153 */     this.x1 = paramFloat1;
/*  154 */     this.y1 = paramFloat2;
/*  155 */     this.ctrlx1 = paramFloat3;
/*  156 */     this.ctrly1 = paramFloat4;
/*  157 */     this.ctrlx2 = paramFloat5;
/*  158 */     this.ctrly2 = paramFloat6;
/*  159 */     this.x2 = paramFloat7;
/*  160 */     this.y2 = paramFloat8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RectBounds getBounds() {
/*  167 */     float f1 = Math.min(Math.min(this.x1, this.x2), 
/*  168 */         Math.min(this.ctrlx1, this.ctrlx2));
/*  169 */     float f2 = Math.min(Math.min(this.y1, this.y2), 
/*  170 */         Math.min(this.ctrly1, this.ctrly2));
/*  171 */     float f3 = Math.max(Math.max(this.x1, this.x2), 
/*  172 */         Math.max(this.ctrlx1, this.ctrlx2));
/*  173 */     float f4 = Math.max(Math.max(this.y1, this.y2), 
/*  174 */         Math.max(this.ctrly1, this.ctrly2));
/*  175 */     return new RectBounds(f1, f2, f3, f4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D eval(float paramFloat) {
/*  188 */     Point2D point2D = new Point2D();
/*  189 */     eval(paramFloat, point2D);
/*  190 */     return point2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void eval(float paramFloat, Point2D paramPoint2D) {
/*  203 */     paramPoint2D.setLocation(calcX(paramFloat), calcY(paramFloat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D evalDt(float paramFloat) {
/*  218 */     Point2D point2D = new Point2D();
/*  219 */     evalDt(paramFloat, point2D);
/*  220 */     return point2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void evalDt(float paramFloat, Point2D paramPoint2D) {
/*  235 */     float f1 = paramFloat;
/*  236 */     float f2 = 1.0F - f1;
/*  237 */     float f3 = 3.0F * ((this.ctrlx1 - this.x1) * f2 * f2 + 2.0F * (this.ctrlx2 - this.ctrlx1) * f2 * f1 + (this.x2 - this.ctrlx2) * f1 * f1);
/*      */ 
/*      */     
/*  240 */     float f4 = 3.0F * ((this.ctrly1 - this.y1) * f2 * f2 + 2.0F * (this.ctrly2 - this.ctrly1) * f2 * f1 + (this.y2 - this.ctrly2) * f1 * f1);
/*      */ 
/*      */     
/*  243 */     paramPoint2D.setLocation(f3, f4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurve(float[] paramArrayOffloat, int paramInt) {
/*  256 */     setCurve(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5], paramArrayOffloat[paramInt + 6], paramArrayOffloat[paramInt + 7]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurve(Point2D paramPoint2D1, Point2D paramPoint2D2, Point2D paramPoint2D3, Point2D paramPoint2D4) {
/*  275 */     setCurve(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y, paramPoint2D3.x, paramPoint2D3.y, paramPoint2D4.x, paramPoint2D4.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurve(Point2D[] paramArrayOfPoint2D, int paramInt) {
/*  288 */     setCurve((paramArrayOfPoint2D[paramInt + 0]).x, (paramArrayOfPoint2D[paramInt + 0]).y, (paramArrayOfPoint2D[paramInt + 1]).x, (paramArrayOfPoint2D[paramInt + 1]).y, (paramArrayOfPoint2D[paramInt + 2]).x, (paramArrayOfPoint2D[paramInt + 2]).y, (paramArrayOfPoint2D[paramInt + 3]).x, (paramArrayOfPoint2D[paramInt + 3]).y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCurve(CubicCurve2D paramCubicCurve2D) {
/*  300 */     setCurve(paramCubicCurve2D.x1, paramCubicCurve2D.y1, paramCubicCurve2D.ctrlx1, paramCubicCurve2D.ctrly1, paramCubicCurve2D.ctrlx2, paramCubicCurve2D.ctrly2, paramCubicCurve2D.x2, paramCubicCurve2D.y2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float getFlatnessSq(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  331 */     return Math.max(Line2D.ptSegDistSq(paramFloat1, paramFloat2, paramFloat7, paramFloat8, paramFloat3, paramFloat4), 
/*  332 */         Line2D.ptSegDistSq(paramFloat1, paramFloat2, paramFloat7, paramFloat8, paramFloat5, paramFloat6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float getFlatness(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  364 */     return (float)Math.sqrt(getFlatnessSq(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float getFlatnessSq(float[] paramArrayOffloat, int paramInt) {
/*  381 */     return getFlatnessSq(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5], paramArrayOffloat[paramInt + 6], paramArrayOffloat[paramInt + 7]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float getFlatness(float[] paramArrayOffloat, int paramInt) {
/*  400 */     return getFlatness(paramArrayOffloat[paramInt + 0], paramArrayOffloat[paramInt + 1], paramArrayOffloat[paramInt + 2], paramArrayOffloat[paramInt + 3], paramArrayOffloat[paramInt + 4], paramArrayOffloat[paramInt + 5], paramArrayOffloat[paramInt + 6], paramArrayOffloat[paramInt + 7]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFlatnessSq() {
/*  413 */     return getFlatnessSq(this.x1, this.y1, this.ctrlx1, this.ctrly1, this.ctrlx2, this.ctrly2, this.x2, this.y2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFlatness() {
/*  423 */     return getFlatness(this.x1, this.y1, this.ctrlx1, this.ctrly1, this.ctrlx2, this.ctrly2, this.x2, this.y2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void subdivide(float paramFloat, CubicCurve2D paramCubicCurve2D1, CubicCurve2D paramCubicCurve2D2) {
/*  439 */     if (paramCubicCurve2D1 == null && paramCubicCurve2D2 == null)
/*      */       return; 
/*  441 */     float f1 = calcX(paramFloat);
/*  442 */     float f2 = calcY(paramFloat);
/*      */     
/*  444 */     float f3 = this.x1;
/*  445 */     float f4 = this.y1;
/*  446 */     float f5 = this.ctrlx1;
/*  447 */     float f6 = this.ctrly1;
/*  448 */     float f7 = this.ctrlx2;
/*  449 */     float f8 = this.ctrly2;
/*  450 */     float f9 = this.x2;
/*  451 */     float f10 = this.y2;
/*  452 */     float f11 = 1.0F - paramFloat;
/*  453 */     float f12 = f11 * f5 + paramFloat * f7;
/*  454 */     float f13 = f11 * f6 + paramFloat * f8;
/*      */     
/*  456 */     if (paramCubicCurve2D1 != null) {
/*  457 */       float f14 = f3;
/*  458 */       float f15 = f4;
/*  459 */       float f16 = f11 * f3 + paramFloat * f5;
/*  460 */       float f17 = f11 * f4 + paramFloat * f6;
/*  461 */       float f18 = f11 * f16 + paramFloat * f12;
/*  462 */       float f19 = f11 * f17 + paramFloat * f13;
/*  463 */       float f20 = f1;
/*  464 */       float f21 = f2;
/*  465 */       paramCubicCurve2D1.setCurve(f14, f15, f16, f17, f18, f19, f20, f21);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  471 */     if (paramCubicCurve2D2 != null) {
/*  472 */       float f14 = f1;
/*  473 */       float f15 = f2;
/*  474 */       float f16 = f11 * f7 + paramFloat * f9;
/*  475 */       float f17 = f11 * f8 + paramFloat * f10;
/*  476 */       float f18 = f11 * f12 + paramFloat * f16;
/*  477 */       float f19 = f11 * f13 + paramFloat * f17;
/*  478 */       float f20 = f9;
/*  479 */       float f21 = f10;
/*  480 */       paramCubicCurve2D2.setCurve(f14, f15, f18, f19, f16, f17, f20, f21);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void subdivide(CubicCurve2D paramCubicCurve2D1, CubicCurve2D paramCubicCurve2D2) {
/*  498 */     subdivide(this, paramCubicCurve2D1, paramCubicCurve2D2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void subdivide(CubicCurve2D paramCubicCurve2D1, CubicCurve2D paramCubicCurve2D2, CubicCurve2D paramCubicCurve2D3) {
/*  516 */     float f1 = paramCubicCurve2D1.x1;
/*  517 */     float f2 = paramCubicCurve2D1.y1;
/*  518 */     float f3 = paramCubicCurve2D1.ctrlx1;
/*  519 */     float f4 = paramCubicCurve2D1.ctrly1;
/*  520 */     float f5 = paramCubicCurve2D1.ctrlx2;
/*  521 */     float f6 = paramCubicCurve2D1.ctrly2;
/*  522 */     float f7 = paramCubicCurve2D1.x2;
/*  523 */     float f8 = paramCubicCurve2D1.y2;
/*  524 */     float f9 = (f3 + f5) / 2.0F;
/*  525 */     float f10 = (f4 + f6) / 2.0F;
/*  526 */     f3 = (f1 + f3) / 2.0F;
/*  527 */     f4 = (f2 + f4) / 2.0F;
/*  528 */     f5 = (f7 + f5) / 2.0F;
/*  529 */     f6 = (f8 + f6) / 2.0F;
/*  530 */     float f11 = (f3 + f9) / 2.0F;
/*  531 */     float f12 = (f4 + f10) / 2.0F;
/*  532 */     float f13 = (f5 + f9) / 2.0F;
/*  533 */     float f14 = (f6 + f10) / 2.0F;
/*  534 */     f9 = (f11 + f13) / 2.0F;
/*  535 */     f10 = (f12 + f14) / 2.0F;
/*  536 */     if (paramCubicCurve2D2 != null) {
/*  537 */       paramCubicCurve2D2.setCurve(f1, f2, f3, f4, f11, f12, f9, f10);
/*      */     }
/*      */     
/*  540 */     if (paramCubicCurve2D3 != null) {
/*  541 */       paramCubicCurve2D3.setCurve(f9, f10, f13, f14, f5, f6, f7, f8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void subdivide(float[] paramArrayOffloat1, int paramInt1, float[] paramArrayOffloat2, int paramInt2, float[] paramArrayOffloat3, int paramInt3) {
/*  576 */     float f1 = paramArrayOffloat1[paramInt1 + 0];
/*  577 */     float f2 = paramArrayOffloat1[paramInt1 + 1];
/*  578 */     float f3 = paramArrayOffloat1[paramInt1 + 2];
/*  579 */     float f4 = paramArrayOffloat1[paramInt1 + 3];
/*  580 */     float f5 = paramArrayOffloat1[paramInt1 + 4];
/*  581 */     float f6 = paramArrayOffloat1[paramInt1 + 5];
/*  582 */     float f7 = paramArrayOffloat1[paramInt1 + 6];
/*  583 */     float f8 = paramArrayOffloat1[paramInt1 + 7];
/*  584 */     if (paramArrayOffloat2 != null) {
/*  585 */       paramArrayOffloat2[paramInt2 + 0] = f1;
/*  586 */       paramArrayOffloat2[paramInt2 + 1] = f2;
/*      */     } 
/*  588 */     if (paramArrayOffloat3 != null) {
/*  589 */       paramArrayOffloat3[paramInt3 + 6] = f7;
/*  590 */       paramArrayOffloat3[paramInt3 + 7] = f8;
/*      */     } 
/*  592 */     f1 = (f1 + f3) / 2.0F;
/*  593 */     f2 = (f2 + f4) / 2.0F;
/*  594 */     f7 = (f7 + f5) / 2.0F;
/*  595 */     f8 = (f8 + f6) / 2.0F;
/*  596 */     float f9 = (f3 + f5) / 2.0F;
/*  597 */     float f10 = (f4 + f6) / 2.0F;
/*  598 */     f3 = (f1 + f9) / 2.0F;
/*  599 */     f4 = (f2 + f10) / 2.0F;
/*  600 */     f5 = (f7 + f9) / 2.0F;
/*  601 */     f6 = (f8 + f10) / 2.0F;
/*  602 */     f9 = (f3 + f5) / 2.0F;
/*  603 */     f10 = (f4 + f6) / 2.0F;
/*  604 */     if (paramArrayOffloat2 != null) {
/*  605 */       paramArrayOffloat2[paramInt2 + 2] = f1;
/*  606 */       paramArrayOffloat2[paramInt2 + 3] = f2;
/*  607 */       paramArrayOffloat2[paramInt2 + 4] = f3;
/*  608 */       paramArrayOffloat2[paramInt2 + 5] = f4;
/*  609 */       paramArrayOffloat2[paramInt2 + 6] = f9;
/*  610 */       paramArrayOffloat2[paramInt2 + 7] = f10;
/*      */     } 
/*  612 */     if (paramArrayOffloat3 != null) {
/*  613 */       paramArrayOffloat3[paramInt3 + 0] = f9;
/*  614 */       paramArrayOffloat3[paramInt3 + 1] = f10;
/*  615 */       paramArrayOffloat3[paramInt3 + 2] = f5;
/*  616 */       paramArrayOffloat3[paramInt3 + 3] = f6;
/*  617 */       paramArrayOffloat3[paramInt3 + 4] = f7;
/*  618 */       paramArrayOffloat3[paramInt3 + 5] = f8;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int solveCubic(float[] paramArrayOffloat) {
/*  638 */     return solveCubic(paramArrayOffloat, paramArrayOffloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int solveCubic(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/*  659 */     float f1 = paramArrayOffloat1[3];
/*  660 */     if (f1 == 0.0F)
/*      */     {
/*  662 */       return QuadCurve2D.solveQuadratic(paramArrayOffloat1, paramArrayOffloat2);
/*      */     }
/*  664 */     float f2 = paramArrayOffloat1[2] / f1;
/*  665 */     float f3 = paramArrayOffloat1[1] / f1;
/*  666 */     float f4 = paramArrayOffloat1[0] / f1;
/*  667 */     byte b = 0;
/*  668 */     float f5 = (f2 * f2 - 3.0F * f3) / 9.0F;
/*  669 */     float f6 = (2.0F * f2 * f2 * f2 - 9.0F * f2 * f3 + 27.0F * f4) / 54.0F;
/*  670 */     float f7 = f6 * f6;
/*  671 */     float f8 = f5 * f5 * f5;
/*  672 */     f2 /= 3.0F;
/*  673 */     if (f7 < f8) {
/*  674 */       float f = (float)Math.acos(f6 / Math.sqrt(f8));
/*  675 */       f5 = (float)(-2.0D * Math.sqrt(f5));
/*  676 */       if (paramArrayOffloat2 == paramArrayOffloat1) {
/*      */ 
/*      */ 
/*      */         
/*  680 */         paramArrayOffloat1 = new float[4];
/*  681 */         System.arraycopy(paramArrayOffloat2, 0, paramArrayOffloat1, 0, 4);
/*      */       } 
/*  683 */       paramArrayOffloat2[b++] = (float)(f5 * Math.cos((f / 3.0F)) - f2);
/*  684 */       paramArrayOffloat2[b++] = (float)(f5 * Math.cos((f + 6.283185307179586D) / 3.0D) - f2);
/*  685 */       paramArrayOffloat2[b++] = (float)(f5 * Math.cos((f - 6.283185307179586D) / 3.0D) - f2);
/*  686 */       fixRoots(paramArrayOffloat2, paramArrayOffloat1);
/*      */     } else {
/*  688 */       boolean bool = (f6 < 0.0F) ? true : false;
/*  689 */       float f9 = (float)Math.sqrt((f7 - f8));
/*  690 */       if (bool) {
/*  691 */         f6 = -f6;
/*      */       }
/*  693 */       float f10 = (float)Math.pow((f6 + f9), 0.3333333432674408D);
/*  694 */       if (!bool) {
/*  695 */         f10 = -f10;
/*      */       }
/*  697 */       float f11 = (f10 == 0.0F) ? 0.0F : (f5 / f10);
/*  698 */       paramArrayOffloat2[b++] = f10 + f11 - f2;
/*      */     } 
/*  700 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void fixRoots(float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/*  739 */     for (byte b = 0; b < 3; b++) {
/*  740 */       float f = paramArrayOffloat1[b];
/*  741 */       if (Math.abs(f) < 1.0E-5F) {
/*  742 */         paramArrayOffloat1[b] = findZero(f, 0.0F, paramArrayOffloat2);
/*  743 */       } else if (Math.abs(f - 1.0F) < 1.0E-5F) {
/*  744 */         paramArrayOffloat1[b] = findZero(f, 1.0F, paramArrayOffloat2);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static float solveEqn(float[] paramArrayOffloat, int paramInt, float paramFloat) {
/*  750 */     float f = paramArrayOffloat[paramInt];
/*  751 */     while (--paramInt >= 0) {
/*  752 */       f = f * paramFloat + paramArrayOffloat[paramInt];
/*      */     }
/*  754 */     return f;
/*      */   }
/*      */   
/*      */   private static float findZero(float paramFloat1, float paramFloat2, float[] paramArrayOffloat) {
/*  758 */     float[] arrayOfFloat = { paramArrayOffloat[1], 2.0F * paramArrayOffloat[2], 3.0F * paramArrayOffloat[3] };
/*      */     
/*  760 */     float f1 = 0.0F;
/*  761 */     float f2 = paramFloat1;
/*      */     while (true) {
/*  763 */       float f3 = solveEqn(arrayOfFloat, 2, paramFloat1);
/*  764 */       if (f3 == 0.0F)
/*      */       {
/*  766 */         return paramFloat1;
/*      */       }
/*  768 */       float f4 = solveEqn(paramArrayOffloat, 3, paramFloat1);
/*  769 */       if (f4 == 0.0F)
/*      */       {
/*  771 */         return paramFloat1;
/*      */       }
/*      */       
/*  774 */       float f5 = -(f4 / f3);
/*      */       
/*  776 */       if (f1 == 0.0F) {
/*  777 */         f1 = f5;
/*      */       }
/*  779 */       if (paramFloat1 < paramFloat2) {
/*  780 */         if (f5 < 0.0F) return paramFloat1; 
/*  781 */       } else if (paramFloat1 > paramFloat2) {
/*  782 */         if (f5 > 0.0F) return paramFloat1; 
/*      */       } else {
/*  784 */         return (f5 > 0.0F) ? (
/*  785 */           paramFloat2 + Float.MIN_VALUE) : (
/*  786 */           paramFloat2 - Float.MIN_VALUE);
/*      */       } 
/*  788 */       float f6 = paramFloat1 + f5;
/*  789 */       if (paramFloat1 == f6)
/*      */       {
/*  791 */         return paramFloat1;
/*      */       }
/*  793 */       if (f5 * f1 < 0.0F) {
/*      */ 
/*      */ 
/*      */         
/*  797 */         int i = (f2 < paramFloat1) ? getTag(paramFloat2, f2, paramFloat1) : getTag(paramFloat2, paramFloat1, f2);
/*  798 */         if (i != 0)
/*      */         {
/*  800 */           return (f2 + paramFloat1) / 2.0F;
/*      */         }
/*      */ 
/*      */         
/*  804 */         paramFloat1 = paramFloat2; continue;
/*      */       } 
/*  806 */       paramFloat1 = f6;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(float paramFloat1, float paramFloat2) {
/*  815 */     if (paramFloat1 * 0.0F + paramFloat2 * 0.0F != 0.0F)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  821 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  827 */     int i = Shape.pointCrossingsForLine(paramFloat1, paramFloat2, this.x1, this.y1, this.x2, this.y2) + Shape.pointCrossingsForCubic(paramFloat1, paramFloat2, this.x1, this.y1, this.ctrlx1, this.ctrly1, this.ctrlx2, this.ctrly2, this.x2, this.y2, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  832 */     return ((i & 0x1) == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Point2D paramPoint2D) {
/*  839 */     return contains(paramPoint2D.x, paramPoint2D.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void fillEqn(float[] paramArrayOffloat, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
/*  865 */     paramArrayOffloat[0] = paramFloat2 - paramFloat1;
/*  866 */     paramArrayOffloat[1] = (paramFloat3 - paramFloat2) * 3.0F;
/*  867 */     paramArrayOffloat[2] = (paramFloat4 - paramFloat3 - paramFloat3 + paramFloat2) * 3.0F;
/*  868 */     paramArrayOffloat[3] = paramFloat5 + (paramFloat3 - paramFloat4) * 3.0F - paramFloat2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int evalCubic(float[] paramArrayOffloat1, int paramInt, boolean paramBoolean1, boolean paramBoolean2, float[] paramArrayOffloat2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  886 */     byte b1 = 0;
/*  887 */     for (byte b2 = 0; b2 < paramInt; b2++) {
/*  888 */       float f = paramArrayOffloat1[b2];
/*  889 */       if ((paramBoolean1 ? (f >= 0.0F) : (f > 0.0F)) && (paramBoolean2 ? (f <= 1.0F) : (f < 1.0F)) && (paramArrayOffloat2 == null || paramArrayOffloat2[1] + (2.0F * paramArrayOffloat2[2] + 3.0F * paramArrayOffloat2[3] * f) * f != 0.0F)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  894 */         float f1 = 1.0F - f;
/*  895 */         paramArrayOffloat1[b1++] = paramFloat1 * f1 * f1 * f1 + 3.0F * paramFloat2 * f * f1 * f1 + 3.0F * paramFloat3 * f * f * f1 + paramFloat4 * f * f * f;
/*      */       } 
/*      */     } 
/*  898 */     return b1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getTag(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  914 */     if (paramFloat1 <= paramFloat2) {
/*  915 */       return (paramFloat1 < paramFloat2) ? -2 : -1;
/*      */     }
/*  917 */     if (paramFloat1 >= paramFloat3) {
/*  918 */       return (paramFloat1 > paramFloat3) ? 2 : 1;
/*      */     }
/*  920 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean inwards(int paramInt1, int paramInt2, int paramInt3) {
/*  931 */     switch (paramInt1)
/*      */     
/*      */     { 
/*      */       default:
/*  935 */         return false;
/*      */       case -1:
/*  937 */         return (paramInt2 >= 0 || paramInt3 >= 0);
/*      */       case 0:
/*  939 */         return true;
/*      */       case 1:
/*  941 */         break; }  return (paramInt2 <= 0 || paramInt3 <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*      */     int i5;
/*  950 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/*  951 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  958 */     float f1 = this.x1;
/*  959 */     float f2 = this.y1;
/*  960 */     int i = getTag(f1, paramFloat1, paramFloat1 + paramFloat3);
/*  961 */     int j = getTag(f2, paramFloat2, paramFloat2 + paramFloat4);
/*  962 */     if (i == 0 && j == 0) {
/*  963 */       return true;
/*      */     }
/*  965 */     float f3 = this.x2;
/*  966 */     float f4 = this.y2;
/*  967 */     int k = getTag(f3, paramFloat1, paramFloat1 + paramFloat3);
/*  968 */     int m = getTag(f4, paramFloat2, paramFloat2 + paramFloat4);
/*  969 */     if (k == 0 && m == 0) {
/*  970 */       return true;
/*      */     }
/*      */     
/*  973 */     float f5 = this.ctrlx1;
/*  974 */     float f6 = this.ctrly1;
/*  975 */     float f7 = this.ctrlx2;
/*  976 */     float f8 = this.ctrly2;
/*  977 */     int n = getTag(f5, paramFloat1, paramFloat1 + paramFloat3);
/*  978 */     int i1 = getTag(f6, paramFloat2, paramFloat2 + paramFloat4);
/*  979 */     int i2 = getTag(f7, paramFloat1, paramFloat1 + paramFloat3);
/*  980 */     int i3 = getTag(f8, paramFloat2, paramFloat2 + paramFloat4);
/*      */ 
/*      */ 
/*      */     
/*  984 */     if (i < 0 && k < 0 && n < 0 && i2 < 0)
/*      */     {
/*      */       
/*  987 */       return false;
/*      */     }
/*  989 */     if (j < 0 && m < 0 && i1 < 0 && i3 < 0)
/*      */     {
/*      */       
/*  992 */       return false;
/*      */     }
/*  994 */     if (i > 0 && k > 0 && n > 0 && i2 > 0)
/*      */     {
/*      */       
/*  997 */       return false;
/*      */     }
/*  999 */     if (j > 0 && m > 0 && i1 > 0 && i3 > 0)
/*      */     {
/*      */       
/* 1002 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1010 */     if (inwards(i, k, n) && 
/* 1011 */       inwards(j, m, i1))
/*      */     {
/*      */       
/* 1014 */       return true;
/*      */     }
/* 1016 */     if (inwards(k, i, i2) && 
/* 1017 */       inwards(m, j, i3))
/*      */     {
/*      */       
/* 1020 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1024 */     boolean bool1 = (i * k <= 0) ? true : false;
/* 1025 */     boolean bool2 = (j * m <= 0) ? true : false;
/* 1026 */     if (i == 0 && k == 0 && bool2) {
/* 1027 */       return true;
/*      */     }
/* 1029 */     if (j == 0 && m == 0 && bool1) {
/* 1030 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1039 */     float[] arrayOfFloat1 = new float[4];
/* 1040 */     float[] arrayOfFloat2 = new float[4];
/* 1041 */     if (!bool2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1047 */       fillEqn(arrayOfFloat1, (j < 0) ? paramFloat2 : (paramFloat2 + paramFloat4), f2, f6, f8, f4);
/* 1048 */       int i7 = solveCubic(arrayOfFloat1, arrayOfFloat2);
/* 1049 */       i7 = evalCubic(arrayOfFloat2, i7, true, true, null, f1, f5, f7, f3);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1054 */       return (i7 == 2 && 
/* 1055 */         getTag(arrayOfFloat2[0], paramFloat1, paramFloat1 + paramFloat3) * getTag(arrayOfFloat2[1], paramFloat1, paramFloat1 + paramFloat3) <= 0);
/*      */     } 
/*      */ 
/*      */     
/* 1059 */     if (!bool1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1065 */       fillEqn(arrayOfFloat1, (i < 0) ? paramFloat1 : (paramFloat1 + paramFloat3), f1, f5, f7, f3);
/* 1066 */       int i7 = solveCubic(arrayOfFloat1, arrayOfFloat2);
/* 1067 */       i7 = evalCubic(arrayOfFloat2, i7, true, true, null, f2, f6, f8, f4);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1072 */       return (i7 == 2 && 
/* 1073 */         getTag(arrayOfFloat2[0], paramFloat2, paramFloat2 + paramFloat4) * getTag(arrayOfFloat2[1], paramFloat2, paramFloat2 + paramFloat4) <= 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1079 */     float f9 = f3 - f1;
/* 1080 */     float f10 = f4 - f2;
/* 1081 */     float f11 = f4 * f1 - f3 * f2;
/*      */     
/* 1083 */     if (j == 0) {
/* 1084 */       i4 = i;
/*      */     } else {
/* 1086 */       i4 = getTag((f11 + f9 * ((j < 0) ? paramFloat2 : (paramFloat2 + paramFloat4))) / f10, paramFloat1, paramFloat1 + paramFloat3);
/*      */     } 
/* 1088 */     if (m == 0) {
/* 1089 */       i5 = k;
/*      */     } else {
/* 1091 */       i5 = getTag((f11 + f9 * ((m < 0) ? paramFloat2 : (paramFloat2 + paramFloat4))) / f10, paramFloat1, paramFloat1 + paramFloat3);
/*      */     } 
/*      */ 
/*      */     
/* 1095 */     if (i4 * i5 <= 0) {
/* 1096 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1126 */     int i4 = (i4 * i <= 0) ? j : m;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1136 */     fillEqn(arrayOfFloat1, (i5 < 0) ? paramFloat1 : (paramFloat1 + paramFloat3), f1, f5, f7, f3);
/* 1137 */     int i6 = solveCubic(arrayOfFloat1, arrayOfFloat2);
/* 1138 */     i6 = evalCubic(arrayOfFloat2, i6, true, true, null, f2, f6, f8, f4);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1143 */     int[] arrayOfInt = new int[i6 + 1];
/* 1144 */     for (byte b = 0; b < i6; b++) {
/* 1145 */       arrayOfInt[b] = getTag(arrayOfFloat2[b], paramFloat2, paramFloat2 + paramFloat4);
/*      */     }
/* 1147 */     arrayOfInt[i6] = i4;
/* 1148 */     Arrays.sort(arrayOfInt);
/* 1149 */     return ((i6 >= 1 && arrayOfInt[0] * arrayOfInt[1] <= 0) || (i6 >= 3 && arrayOfInt[2] * arrayOfInt[3] <= 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 1157 */     if (paramFloat3 <= 0.0F || paramFloat4 <= 0.0F) {
/* 1158 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1163 */     if (!contains(paramFloat1, paramFloat2) || 
/* 1164 */       !contains(paramFloat1 + paramFloat3, paramFloat2) || 
/* 1165 */       !contains(paramFloat1 + paramFloat3, paramFloat2 + paramFloat4) || 
/* 1166 */       !contains(paramFloat1, paramFloat2 + paramFloat4)) {
/* 1167 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1172 */     return !Shape.intersectsLine(paramFloat1, paramFloat2, paramFloat3, paramFloat4, this.x1, this.y1, this.x2, this.y2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PathIterator getPathIterator(BaseTransform paramBaseTransform) {
/* 1191 */     return new CubicIterator(this, paramBaseTransform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PathIterator getPathIterator(BaseTransform paramBaseTransform, float paramFloat) {
/* 1213 */     return new FlatteningPathIterator(getPathIterator(paramBaseTransform), paramFloat);
/*      */   }
/*      */ 
/*      */   
/*      */   public CubicCurve2D copy() {
/* 1218 */     return new CubicCurve2D(this.x1, this.y1, this.ctrlx1, this.ctrly1, this.ctrlx2, this.ctrly2, this.x2, this.y2);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1223 */     int i = Float.floatToIntBits(this.x1);
/* 1224 */     i += Float.floatToIntBits(this.y1) * 37;
/* 1225 */     i += Float.floatToIntBits(this.x2) * 43;
/* 1226 */     i += Float.floatToIntBits(this.y2) * 47;
/* 1227 */     i += Float.floatToIntBits(this.ctrlx1) * 53;
/* 1228 */     i += Float.floatToIntBits(this.ctrly1) * 59;
/* 1229 */     i += Float.floatToIntBits(this.ctrlx2) * 61;
/* 1230 */     i += Float.floatToIntBits(this.ctrly2) * 101;
/* 1231 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 1236 */     if (paramObject == this) {
/* 1237 */       return true;
/*      */     }
/* 1239 */     if (paramObject instanceof CubicCurve2D) {
/* 1240 */       CubicCurve2D cubicCurve2D = (CubicCurve2D)paramObject;
/* 1241 */       return (this.x1 == cubicCurve2D.x1 && this.y1 == cubicCurve2D.y1 && this.x2 == cubicCurve2D.x2 && this.y2 == cubicCurve2D.y2 && this.ctrlx1 == cubicCurve2D.ctrlx1 && this.ctrly1 == cubicCurve2D.ctrly1 && this.ctrlx2 == cubicCurve2D.ctrlx2 && this.ctrly2 == cubicCurve2D.ctrly2);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1246 */     return false;
/*      */   }
/*      */   
/*      */   private float calcX(float paramFloat) {
/* 1250 */     float f = 1.0F - paramFloat;
/* 1251 */     return f * f * f * this.x1 + 3.0F * (paramFloat * f * f * this.ctrlx1 + paramFloat * paramFloat * f * this.ctrlx2) + paramFloat * paramFloat * paramFloat * this.x2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float calcY(float paramFloat) {
/* 1258 */     float f = 1.0F - paramFloat;
/* 1259 */     return f * f * f * this.y1 + 3.0F * (paramFloat * f * f * this.ctrly1 + paramFloat * paramFloat * f * this.ctrly2) + paramFloat * paramFloat * paramFloat * this.y2;
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\CubicCurve2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */