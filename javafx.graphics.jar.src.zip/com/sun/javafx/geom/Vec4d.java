/*    */ package com.sun.javafx.geom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Vec4d
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   public double w;
/*    */   
/*    */   public Vec4d() {}
/*    */   
/*    */   public Vec4d(Vec4d paramVec4d) {
/* 56 */     this.x = paramVec4d.x;
/* 57 */     this.y = paramVec4d.y;
/* 58 */     this.z = paramVec4d.z;
/* 59 */     this.w = paramVec4d.w;
/*    */   }
/*    */   
/*    */   public Vec4d(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 63 */     this.x = paramDouble1;
/* 64 */     this.y = paramDouble2;
/* 65 */     this.z = paramDouble3;
/* 66 */     this.w = paramDouble4;
/*    */   }
/*    */   
/*    */   public void set(Vec4d paramVec4d) {
/* 70 */     this.x = paramVec4d.x;
/* 71 */     this.y = paramVec4d.y;
/* 72 */     this.z = paramVec4d.z;
/* 73 */     this.w = paramVec4d.w;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec4d.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */