/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WindowsFontMap
/*     */ {
/*     */   static HashMap<String, FamilyDescription> platformFontMap;
/*     */   
/*     */   static class FamilyDescription
/*     */   {
/*     */     public String familyName;
/*     */     public String plainFullName;
/*     */     public String boldFullName;
/*     */     public String italicFullName;
/*     */     public String boldItalicFullName;
/*     */     public String plainFileName;
/*     */     public String boldFileName;
/*     */     public String italicFileName;
/*     */     public String boldItalicFileName;
/*     */   }
/*     */   
/*     */   static HashMap<String, FamilyDescription> populateHardcodedFileNameMap() {
/*  51 */     HashMap<Object, Object> hashMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/*  55 */     FamilyDescription familyDescription = new FamilyDescription();
/*  56 */     familyDescription.familyName = "Segoe UI";
/*  57 */     familyDescription.plainFullName = "Segoe UI";
/*  58 */     familyDescription.plainFileName = "segoeui.ttf";
/*  59 */     familyDescription.boldFullName = "Segoe UI Bold";
/*  60 */     familyDescription.boldFileName = "segoeuib.ttf";
/*  61 */     familyDescription.italicFullName = "Segoe UI Italic";
/*  62 */     familyDescription.italicFileName = "segoeuii.ttf";
/*  63 */     familyDescription.boldItalicFullName = "Segoe UI Bold Italic";
/*  64 */     familyDescription.boldItalicFileName = "segoeuiz.ttf";
/*  65 */     hashMap.put("segoe", familyDescription);
/*     */     
/*  67 */     familyDescription = new FamilyDescription();
/*  68 */     familyDescription.familyName = "Tahoma";
/*  69 */     familyDescription.plainFullName = "Tahoma";
/*  70 */     familyDescription.plainFileName = "tahoma.ttf";
/*  71 */     familyDescription.boldFullName = "Tahoma Bold";
/*  72 */     familyDescription.boldFileName = "tahomabd.ttf";
/*  73 */     hashMap.put("tahoma", familyDescription);
/*     */     
/*  75 */     familyDescription = new FamilyDescription();
/*  76 */     familyDescription.familyName = "Verdana";
/*  77 */     familyDescription.plainFullName = "Verdana";
/*  78 */     familyDescription.plainFileName = "verdana.TTF";
/*  79 */     familyDescription.boldFullName = "Verdana Bold";
/*  80 */     familyDescription.boldFileName = "verdanab.TTF";
/*  81 */     familyDescription.italicFullName = "Verdana Italic";
/*  82 */     familyDescription.italicFileName = "verdanai.TTF";
/*  83 */     familyDescription.boldItalicFullName = "Verdana Bold Italic";
/*  84 */     familyDescription.boldItalicFileName = "verdanaz.TTF";
/*  85 */     hashMap.put("verdana", familyDescription);
/*     */     
/*  87 */     familyDescription = new FamilyDescription();
/*  88 */     familyDescription.familyName = "Arial";
/*  89 */     familyDescription.plainFullName = "Arial";
/*  90 */     familyDescription.plainFileName = "ARIAL.TTF";
/*  91 */     familyDescription.boldFullName = "Arial Bold";
/*  92 */     familyDescription.boldFileName = "ARIALBD.TTF";
/*  93 */     familyDescription.italicFullName = "Arial Italic";
/*  94 */     familyDescription.italicFileName = "ARIALI.TTF";
/*  95 */     familyDescription.boldItalicFullName = "Arial Bold Italic";
/*  96 */     familyDescription.boldItalicFileName = "ARIALBI.TTF";
/*  97 */     hashMap.put("arial", familyDescription);
/*     */     
/*  99 */     familyDescription = new FamilyDescription();
/* 100 */     familyDescription.familyName = "Times New Roman";
/* 101 */     familyDescription.plainFullName = "Times New Roman";
/* 102 */     familyDescription.plainFileName = "times.ttf";
/* 103 */     familyDescription.boldFullName = "Times New Roman Bold";
/* 104 */     familyDescription.boldFileName = "timesbd.ttf";
/* 105 */     familyDescription.italicFullName = "Times New Roman Italic";
/* 106 */     familyDescription.italicFileName = "timesi.ttf";
/* 107 */     familyDescription.boldItalicFullName = "Times New Roman Bold Italic";
/* 108 */     familyDescription.boldItalicFileName = "timesbi.ttf";
/* 109 */     hashMap.put("times", familyDescription);
/*     */ 
/*     */     
/* 112 */     familyDescription = new FamilyDescription();
/* 113 */     familyDescription.familyName = "Courier New";
/* 114 */     familyDescription.plainFullName = "Courier New";
/* 115 */     familyDescription.plainFileName = "cour.ttf";
/* 116 */     familyDescription.boldFullName = "Courier New Bold";
/* 117 */     familyDescription.boldFileName = "courbd.ttf";
/* 118 */     familyDescription.italicFullName = "Courier New Italic";
/* 119 */     familyDescription.italicFileName = "couri.ttf";
/* 120 */     familyDescription.boldItalicFullName = "Courier New Bold Italic";
/* 121 */     familyDescription.boldItalicFileName = "courbi.ttf";
/* 122 */     hashMap.put("courier", familyDescription);
/*     */     
/* 124 */     return (HashMap)hashMap;
/*     */   }
/*     */   
/*     */   static String getPathName(String paramString) {
/* 128 */     return PrismFontFactory.getPathNameWindows(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String findFontFile(String paramString, int paramInt) {
/* 138 */     if (platformFontMap == null) {
/* 139 */       platformFontMap = populateHardcodedFileNameMap();
/*     */     }
/*     */     
/* 142 */     if (platformFontMap == null || platformFontMap.size() == 0) {
/* 143 */       return null;
/*     */     }
/*     */     
/* 146 */     int i = paramString.indexOf(' ');
/* 147 */     String str1 = paramString;
/* 148 */     if (i > 0) {
/* 149 */       str1 = paramString.substring(0, i);
/*     */     }
/*     */     
/* 152 */     FamilyDescription familyDescription = platformFontMap.get(str1);
/* 153 */     if (familyDescription == null) {
/* 154 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     String str2 = null;
/*     */     
/* 168 */     if (paramInt < 0) {
/* 169 */       if (paramString.equalsIgnoreCase(familyDescription.plainFullName)) {
/* 170 */         str2 = familyDescription.plainFileName;
/* 171 */       } else if (paramString.equalsIgnoreCase(familyDescription.boldFullName)) {
/* 172 */         str2 = familyDescription.boldFileName;
/* 173 */       } else if (paramString.equalsIgnoreCase(familyDescription.italicFullName)) {
/* 174 */         str2 = familyDescription.italicFileName;
/* 175 */       } else if (paramString.equalsIgnoreCase(familyDescription.boldItalicFullName)) {
/* 176 */         str2 = familyDescription.boldItalicFileName;
/*     */       } 
/* 178 */       if (str2 != null) {
/* 179 */         return getPathName(str2);
/*     */       }
/* 181 */       return null;
/*     */     } 
/* 183 */     if (!paramString.equalsIgnoreCase(familyDescription.familyName)) {
/* 184 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 189 */     switch (paramInt) {
/*     */       case 0:
/* 191 */         str2 = familyDescription.plainFileName;
/*     */         break;
/*     */       case 1:
/* 194 */         str2 = familyDescription.boldFileName;
/* 195 */         if (str2 == null) {
/* 196 */           str2 = familyDescription.plainFileName;
/*     */         }
/*     */         break;
/*     */       case 2:
/* 200 */         str2 = familyDescription.italicFileName;
/* 201 */         if (str2 == null) {
/* 202 */           str2 = familyDescription.plainFileName;
/*     */         }
/*     */         break;
/*     */       case 3:
/* 206 */         str2 = familyDescription.boldItalicFileName;
/* 207 */         if (str2 == null) {
/* 208 */           str2 = familyDescription.italicFileName;
/*     */         }
/* 210 */         if (str2 == null) {
/* 211 */           str2 = familyDescription.boldFileName;
/*     */         }
/* 213 */         if (str2 == null) {
/* 214 */           str2 = familyDescription.plainFileName;
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 219 */     if (str2 != null) {
/* 220 */       return getPathName(str2);
/*     */     }
/* 222 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\WindowsFontMap.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */