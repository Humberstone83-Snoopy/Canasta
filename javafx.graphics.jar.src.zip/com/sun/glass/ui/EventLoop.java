/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EventLoop
/*     */ {
/*  35 */   private static final Deque<EventLoop> stack = new ArrayDeque<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum State
/*     */   {
/*  44 */     IDLE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     ACTIVE,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     LEAVING;
/*     */   }
/*     */   
/*  57 */   private State state = State.IDLE;
/*     */   private Object returnValue;
/*     */   
/*     */   EventLoop() {
/*  61 */     Application.checkEventThread();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public State getState() {
/*  70 */     Application.checkEventThread();
/*  71 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object enter() {
/*  99 */     Application.checkEventThread();
/* 100 */     if (!this.state.equals(State.IDLE)) {
/* 101 */       throw new IllegalStateException("The event loop object isn't idle");
/*     */     }
/*     */     
/* 104 */     this.state = State.ACTIVE;
/* 105 */     stack.push(this);
/*     */     try {
/* 107 */       Object object = Application.enterNestedEventLoop();
/* 108 */       assert object == this : "Internal inconsistency - wrong EventLoop";
/* 109 */       assert stack.peek() == this : "Internal inconsistency - corrupted event loops stack";
/* 110 */       assert this.state.equals(State.LEAVING) : "The event loop isn't leaving";
/*     */       
/* 112 */       return this.returnValue;
/*     */     } finally {
/* 114 */       this.returnValue = null;
/* 115 */       this.state = State.IDLE;
/* 116 */       stack.pop();
/*     */       
/* 118 */       if (!stack.isEmpty() && ((EventLoop)stack.peek()).state.equals(State.LEAVING)) {
/* 119 */         Application.invokeLater(() -> {
/*     */               EventLoop eventLoop = stack.peek();
/*     */               if (eventLoop != null && eventLoop.state.equals(State.LEAVING)) {
/*     */                 Application.leaveNestedEventLoop(eventLoop);
/*     */               }
/*     */             });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void leave(Object paramObject) {
/* 157 */     Application.checkEventThread();
/* 158 */     if (!this.state.equals(State.ACTIVE)) {
/* 159 */       throw new IllegalStateException("The event loop object isn't active");
/*     */     }
/*     */     
/* 162 */     this.state = State.LEAVING;
/* 163 */     this.returnValue = paramObject;
/*     */     
/* 165 */     if (stack.peek() == this)
/* 166 */       Application.leaveNestedEventLoop(this); 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\EventLoop.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */