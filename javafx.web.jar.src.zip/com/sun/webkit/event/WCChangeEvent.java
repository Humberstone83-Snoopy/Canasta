/*    */ package com.sun.webkit.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCChangeEvent
/*    */ {
/*    */   private final Object source;
/*    */   
/*    */   public WCChangeEvent(Object paramObject) {
/* 32 */     if (paramObject == null) {
/* 33 */       throw new IllegalArgumentException("null source");
/*    */     }
/* 35 */     this.source = paramObject;
/*    */   }
/*    */   
/*    */   public Object getSource() {
/* 39 */     return this.source;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     return getClass().getName() + "[source=" + getClass().getName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\event\WCChangeEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */