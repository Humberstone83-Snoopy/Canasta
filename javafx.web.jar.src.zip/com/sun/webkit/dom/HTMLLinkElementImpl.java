/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLLinkElement;
/*     */ import org.w3c.dom.stylesheets.StyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLLinkElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLLinkElement
/*     */ {
/*     */   HTMLLinkElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLLinkElement getImpl(long paramLong) {
/*  37 */     return (HTMLLinkElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native boolean getDisabledImpl(long paramLong);
/*     */   
/*     */   public boolean getDisabled() {
/*  43 */     return getDisabledImpl(getPeer());
/*     */   }
/*     */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   public void setDisabled(boolean paramBoolean) {
/*  48 */     setDisabledImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharset() {
/*  53 */     return getCharsetImpl(getPeer());
/*     */   }
/*     */   static native String getCharsetImpl(long paramLong);
/*     */   
/*     */   public void setCharset(String paramString) {
/*  58 */     setCharsetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCharsetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHref() {
/*  63 */     return getHrefImpl(getPeer());
/*     */   }
/*     */   static native String getHrefImpl(long paramLong);
/*     */   
/*     */   public void setHref(String paramString) {
/*  68 */     setHrefImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHrefImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHreflang() {
/*  73 */     return getHreflangImpl(getPeer());
/*     */   }
/*     */   static native String getHreflangImpl(long paramLong);
/*     */   
/*     */   public void setHreflang(String paramString) {
/*  78 */     setHreflangImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHreflangImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getMedia() {
/*  83 */     return getMediaImpl(getPeer());
/*     */   }
/*     */   static native String getMediaImpl(long paramLong);
/*     */   
/*     */   public void setMedia(String paramString) {
/*  88 */     setMediaImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setMediaImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRel() {
/*  93 */     return getRelImpl(getPeer());
/*     */   }
/*     */   static native String getRelImpl(long paramLong);
/*     */   
/*     */   public void setRel(String paramString) {
/*  98 */     setRelImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRelImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRev() {
/* 103 */     return getRevImpl(getPeer());
/*     */   }
/*     */   static native String getRevImpl(long paramLong);
/*     */   
/*     */   public void setRev(String paramString) {
/* 108 */     setRevImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRevImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getTarget() {
/* 113 */     return getTargetImpl(getPeer());
/*     */   }
/*     */   static native String getTargetImpl(long paramLong);
/*     */   
/*     */   public void setTarget(String paramString) {
/* 118 */     setTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 123 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 128 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public StyleSheet getSheet() {
/* 133 */     return StyleSheetImpl.getImpl(getSheetImpl(getPeer()));
/*     */   }
/*     */   
/*     */   static native long getSheetImpl(long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLLinkElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */