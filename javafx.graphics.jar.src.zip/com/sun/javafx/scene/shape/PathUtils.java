/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import java.util.Collection;
/*    */ import javafx.scene.shape.PathElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PathUtils
/*    */ {
/*    */   public static Path2D configShape(Collection<PathElement> paramCollection, boolean paramBoolean) {
/* 44 */     Path2D path2D = new Path2D(paramBoolean ? 0 : 1, paramCollection.size());
/* 45 */     for (PathElement pathElement : paramCollection) {
/* 46 */       PathElementHelper.addTo(pathElement, path2D);
/*    */     }
/* 48 */     return path2D;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\PathUtils.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */