/*    */ package com.sun.webkit.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCFocusEvent
/*    */ {
/*    */   public static final int WINDOW_ACTIVATED = 0;
/*    */   public static final int WINDOW_DEACTIVATED = 1;
/*    */   public static final int FOCUS_GAINED = 2;
/*    */   public static final int FOCUS_LOST = 3;
/*    */   public static final int UNKNOWN = -1;
/*    */   public static final int FORWARD = 0;
/*    */   public static final int BACKWARD = 1;
/*    */   private final int id;
/*    */   private final int direction;
/*    */   
/*    */   public WCFocusEvent(int paramInt1, int paramInt2) {
/* 47 */     this.id = paramInt1;
/* 48 */     this.direction = paramInt2;
/*    */   }
/*    */   public int getID() {
/* 51 */     return this.id;
/*    */   } public int getDirection() {
/* 53 */     return this.direction;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     return "WCFocusEvent(" + this.id + ", " + this.direction + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\event\WCFocusEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */