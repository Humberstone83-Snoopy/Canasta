/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.geom.BaseBounds;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.shape.Circle;
/*    */ import javafx.scene.shape.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CircleHelper
/*    */   extends ShapeHelper
/*    */ {
/* 45 */   private static final CircleHelper theInstance = new CircleHelper(); static {
/* 46 */     Utils.forceInit(Circle.class);
/*    */   }
/*    */   private static CircleAccessor circleAccessor;
/*    */   private static CircleHelper getInstance() {
/* 50 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Circle paramCircle) {
/* 54 */     setHelper(paramCircle, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 59 */     return circleAccessor.doCreatePeer(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updatePeerImpl(Node paramNode) {
/* 64 */     super.updatePeerImpl(paramNode);
/* 65 */     circleAccessor.doUpdatePeer(paramNode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/* 71 */     return circleAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Shape configShapeImpl(Shape paramShape) {
/* 76 */     return circleAccessor.doConfigShape(paramShape);
/*    */   }
/*    */   
/*    */   public static void setCircleAccessor(CircleAccessor paramCircleAccessor) {
/* 80 */     if (circleAccessor != null) {
/* 81 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 84 */     circleAccessor = paramCircleAccessor;
/*    */   }
/*    */   
/*    */   public static interface CircleAccessor {
/*    */     NGNode doCreatePeer(Node param1Node);
/*    */     
/*    */     void doUpdatePeer(Node param1Node);
/*    */     
/*    */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*    */     
/*    */     Shape doConfigShape(Shape param1Shape);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\CircleHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */