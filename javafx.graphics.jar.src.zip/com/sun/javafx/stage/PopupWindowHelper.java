/*    */ package com.sun.javafx.stage;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.scene.Node;
/*    */ import javafx.stage.PopupWindow;
/*    */ import javafx.stage.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PopupWindowHelper
/*    */   extends WindowHelper
/*    */ {
/* 42 */   private static final PopupWindowHelper theInstance = new PopupWindowHelper(); static {
/* 43 */     Utils.forceInit(PopupWindow.class);
/*    */   }
/*    */   private static PopupWindowAccessor popupWindowAccessor;
/*    */   private static WindowHelper getInstance() {
/* 47 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(PopupWindow paramPopupWindow) {
/* 51 */     setHelper(paramPopupWindow, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void visibleChangingImpl(Window paramWindow, boolean paramBoolean) {
/* 56 */     super.visibleChangingImpl(paramWindow, paramBoolean);
/* 57 */     popupWindowAccessor.doVisibleChanging(paramWindow, paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void visibleChangedImpl(Window paramWindow, boolean paramBoolean) {
/* 62 */     super.visibleChangedImpl(paramWindow, paramBoolean);
/* 63 */     popupWindowAccessor.doVisibleChanged(paramWindow, paramBoolean);
/*    */   }
/*    */   
/*    */   public static ObservableList<Node> getContent(PopupWindow paramPopupWindow) {
/* 67 */     return popupWindowAccessor.getContent(paramPopupWindow);
/*    */   }
/*    */   
/*    */   public static void setPopupWindowAccessor(PopupWindowAccessor paramPopupWindowAccessor) {
/* 71 */     if (popupWindowAccessor != null) {
/* 72 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 75 */     popupWindowAccessor = paramPopupWindowAccessor;
/*    */   }
/*    */   
/*    */   public static interface PopupWindowAccessor {
/*    */     ObservableList<Node> getContent(PopupWindow param1PopupWindow);
/*    */     
/*    */     void doVisibleChanging(Window param1Window, boolean param1Boolean);
/*    */     
/*    */     void doVisibleChanged(Window param1Window, boolean param1Boolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\stage\PopupWindowHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */