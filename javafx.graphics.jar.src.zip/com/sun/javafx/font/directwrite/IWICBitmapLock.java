/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IWICBitmapLock
/*    */   extends IUnknown
/*    */ {
/*    */   IWICBitmapLock(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   byte[] GetDataPointer() {
/* 34 */     return OS.GetDataPointer(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStride() {
/* 38 */     return OS.GetStride(this.ptr);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IWICBitmapLock.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */