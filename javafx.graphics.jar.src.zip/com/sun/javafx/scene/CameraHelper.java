/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.geometry.Point2D;
/*     */ import javafx.geometry.Point3D;
/*     */ import javafx.scene.Camera;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CameraHelper
/*     */   extends NodeHelper
/*     */ {
/*  46 */   private static final CameraHelper theInstance = new CameraHelper(); static {
/*  47 */     Utils.forceInit(Camera.class);
/*     */   }
/*     */   private static CameraAccessor cameraAccessor;
/*     */   private static CameraHelper getInstance() {
/*  51 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(Camera paramCamera) {
/*  55 */     setHelper(paramCamera, getInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  60 */     throw new UnsupportedOperationException("Applications should not extend the Camera class directly.");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  65 */     super.updatePeerImpl(paramNode);
/*  66 */     cameraAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void markDirtyImpl(Node paramNode, DirtyBits paramDirtyBits) {
/*  71 */     super.markDirtyImpl(paramNode, paramDirtyBits);
/*  72 */     cameraAccessor.doMarkDirty(paramNode, paramDirtyBits);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  78 */     return cameraAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  83 */     return cameraAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public static Point2D project(Camera paramCamera, Point3D paramPoint3D) {
/*  87 */     return cameraAccessor.project(paramCamera, paramPoint3D);
/*     */   }
/*     */   
/*     */   public static Point2D pickNodeXYPlane(Camera paramCamera, Node paramNode, double paramDouble1, double paramDouble2) {
/*  91 */     return cameraAccessor.pickNodeXYPlane(paramCamera, paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public static Point3D pickProjectPlane(Camera paramCamera, double paramDouble1, double paramDouble2) {
/*  95 */     return cameraAccessor.pickProjectPlane(paramCamera, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public static void setCameraAccessor(CameraAccessor paramCameraAccessor) {
/*  99 */     if (cameraAccessor != null) {
/* 100 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 103 */     cameraAccessor = paramCameraAccessor;
/*     */   }
/*     */   
/*     */   public static interface CameraAccessor {
/*     */     void doMarkDirty(Node param1Node, DirtyBits param1DirtyBits);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     Point2D project(Camera param1Camera, Point3D param1Point3D);
/*     */     
/*     */     Point2D pickNodeXYPlane(Camera param1Camera, Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     Point3D pickProjectPlane(Camera param1Camera, double param1Double1, double param1Double2);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\CameraHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */