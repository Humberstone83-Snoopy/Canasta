package javafx.beans.property.adapter;

import javafx.beans.property.ReadOnlyProperty;

public interface ReadOnlyJavaBeanProperty<T> extends ReadOnlyProperty<T> {
  void fireValueChangedEvent();
  
  void dispose();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\adapter\ReadOnlyJavaBeanProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */