/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.webkit.network.about.Handler;
/*     */ import com.sun.webkit.network.data.Handler;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.NetPermission;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.Permission;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class URLs
/*     */ {
/*     */   private static final Map<String, URLStreamHandler> handlerMap;
/*     */   
/*     */   static {
/*  50 */     HashMap<Object, Object> hashMap = new HashMap<>(2);
/*     */     
/*  52 */     hashMap.put("about", new Handler());
/*  53 */     hashMap.put("data", new Handler());
/*  54 */     handlerMap = Collections.unmodifiableMap(hashMap);
/*     */   }
/*     */   
/*  57 */   private static final Permission streamHandlerPermission = new NetPermission("specifyStreamHandler");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URLs() {
/*  64 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL newURL(String paramString) throws MalformedURLException {
/*  77 */     return newURL(null, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL newURL(URL paramURL, String paramString) throws MalformedURLException {
/*     */     try {
/*  95 */       return new URL(paramURL, paramString);
/*  96 */     } catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */       
/*  99 */       int i = paramString.indexOf(':');
/*     */ 
/*     */       
/* 102 */       URLStreamHandler uRLStreamHandler = (i != -1) ? handlerMap.get(paramString.substring(0, i).toLowerCase()) : null;
/*     */       
/* 104 */       if (uRLStreamHandler == null) throw malformedURLException;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 109 */         return AccessController.<URL>doPrivileged(() -> {
/*     */               try {
/*     */                 return new URL(paramURL, paramString, paramURLStreamHandler);
/* 112 */               } catch (MalformedURLException malformedURLException) {
/*     */                 
/*     */                 throw new RuntimeException(malformedURLException);
/*     */               } 
/*     */             }(AccessControlContext)null, new Permission[] { streamHandlerPermission });
/* 117 */       } catch (RuntimeException runtimeException) {
/* 118 */         if (runtimeException.getCause() instanceof MalformedURLException) {
/* 119 */           throw (MalformedURLException)runtimeException.getCause();
/*     */         }
/* 121 */         throw runtimeException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\URLs.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */