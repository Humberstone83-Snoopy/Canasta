/*    */ package com.sun.javafx.scene.shape;
/*    */ 
/*    */ import com.sun.javafx.collections.ObservableIntegerArrayImpl;
/*    */ import javafx.scene.shape.ObservableFaceArray;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObservableFaceArrayImpl
/*    */   extends ObservableIntegerArrayImpl
/*    */   implements ObservableFaceArray
/*    */ {
/*    */   public ObservableFaceArrayImpl() {}
/*    */   
/*    */   public ObservableFaceArrayImpl(int... paramVarArgs) {
/* 43 */     super(paramVarArgs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ObservableFaceArrayImpl(ObservableFaceArray paramObservableFaceArray) {
/* 51 */     super(paramObservableFaceArray);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\shape\ObservableFaceArrayImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */