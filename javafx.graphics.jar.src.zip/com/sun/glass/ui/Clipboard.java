/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clipboard
/*     */ {
/*     */   public static final String TEXT_TYPE = "text/plain";
/*     */   public static final String HTML_TYPE = "text/html";
/*     */   public static final String RTF_TYPE = "text/rtf";
/*     */   public static final String URI_TYPE = "text/uri-list";
/*     */   public static final String FILE_LIST_TYPE = "application/x-java-file-list";
/*     */   public static final String RAW_IMAGE_TYPE = "application/x-java-rawimage";
/*     */   public static final String DRAG_IMAGE = "application/x-java-drag-image";
/*     */   public static final String DRAG_IMAGE_OFFSET = "application/x-java-drag-image-offset";
/*     */   public static final String IE_URL_SHORTCUT_FILENAME = "text/ie-shortcut-filename";
/*     */   public static final int ACTION_NONE = 0;
/*     */   public static final int ACTION_COPY = 1;
/*     */   public static final int ACTION_MOVE = 2;
/*     */   public static final int ACTION_REFERENCE = 1073741824;
/*     */   public static final int ACTION_COPY_OR_MOVE = 3;
/*     */   public static final int ACTION_ANY = 1342177279;
/*     */   public static final String DND = "DND";
/*     */   public static final String SYSTEM = "SYSTEM";
/*     */   public static final String SELECTION = "SELECTION";
/*  69 */   private static final Map<String, Clipboard> clipboards = new HashMap<>();
/*  70 */   private static final ClipboardDelegate delegate = PlatformFactory.getPlatformFactory().createClipboardDelegate();
/*     */   
/*  72 */   private final HashSet<ClipboardAssistance> assistants = new HashSet<>();
/*     */   private final String name;
/*  74 */   private final Object localDataProtector = new Object();
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> localSharedData;
/*     */   
/*     */   private ClipboardAssistance dataSource;
/*     */   
/*  81 */   protected int supportedActions = 1;
/*     */   
/*     */   protected Clipboard(String paramString) {
/*  84 */     Application.checkEventThread();
/*  85 */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public void add(ClipboardAssistance paramClipboardAssistance) {
/*  89 */     Application.checkEventThread();
/*  90 */     synchronized (this.assistants) {
/*  91 */       this.assistants.add(paramClipboardAssistance);
/*     */     } 
/*     */   }
/*     */   public void remove(ClipboardAssistance paramClipboardAssistance) {
/*     */     boolean bool;
/*  96 */     Application.checkEventThread();
/*  97 */     synchronized (this.localDataProtector) {
/*  98 */       if (paramClipboardAssistance == this.dataSource) {
/*  99 */         this.dataSource = null;
/*     */       }
/*     */     } 
/*     */     
/* 103 */     synchronized (this.assistants) {
/* 104 */       this.assistants.remove(paramClipboardAssistance);
/* 105 */       bool = this.assistants.isEmpty();
/*     */     } 
/*     */     
/* 108 */     if (bool) {
/* 109 */       synchronized (clipboards) {
/* 110 */         clipboards.remove(this.name);
/*     */       } 
/* 112 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSharedData(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt) {
/* 121 */     Application.checkEventThread();
/* 122 */     synchronized (this.localDataProtector) {
/* 123 */       this.localSharedData = (HashMap<String, Object>)paramHashMap.clone();
/* 124 */       this.supportedActions = paramInt;
/* 125 */       this.dataSource = paramClipboardAssistance;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush(ClipboardAssistance paramClipboardAssistance, HashMap<String, Object> paramHashMap, int paramInt) {
/* 139 */     Application.checkEventThread();
/* 140 */     setSharedData(paramClipboardAssistance, paramHashMap, paramInt);
/* 141 */     contentChanged();
/*     */   }
/*     */   
/*     */   public int getSupportedSourceActions() {
/* 145 */     Application.checkEventThread();
/* 146 */     return this.supportedActions;
/*     */   }
/*     */   
/*     */   public void setTargetAction(int paramInt) {
/* 150 */     Application.checkEventThread();
/* 151 */     actionPerformed(paramInt);
/*     */   }
/*     */   public void contentChanged() {
/*     */     HashSet hashSet;
/* 155 */     Application.checkEventThread();
/*     */     
/* 157 */     synchronized (this.assistants) {
/* 158 */       hashSet = (HashSet)this.assistants.clone();
/*     */     } 
/* 160 */     for (ClipboardAssistance clipboardAssistance : hashSet) {
/* 161 */       clipboardAssistance.contentChanged();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void actionPerformed(int paramInt) {
/* 171 */     Application.checkEventThread();
/* 172 */     synchronized (this.localDataProtector) {
/* 173 */       if (null != this.dataSource) {
/* 174 */         this.dataSource.actionPerformed(paramInt);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getData(String paramString) {
/* 181 */     Application.checkEventThread();
/* 182 */     synchronized (this.localDataProtector) {
/* 183 */       if (this.localSharedData == null) {
/* 184 */         return null;
/*     */       }
/* 186 */       Object object = this.localSharedData.get(paramString);
/* 187 */       return (object instanceof DelayedCallback) ? (
/* 188 */         (DelayedCallback)object).providedData() : 
/* 189 */         object;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String[] getMimeTypes() {
/* 194 */     Application.checkEventThread();
/* 195 */     synchronized (this.localDataProtector) {
/* 196 */       if (this.localSharedData == null) {
/* 197 */         return null;
/*     */       }
/* 199 */       Set<String> set = this.localSharedData.keySet();
/* 200 */       String[] arrayOfString = new String[set.size()];
/* 201 */       byte b = 0;
/* 202 */       for (String str : set) {
/* 203 */         arrayOfString[b++] = str;
/*     */       }
/* 205 */       return arrayOfString;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Clipboard get(String paramString) {
/* 213 */     Application.checkEventThread();
/*     */     
/* 215 */     synchronized (clipboards) {
/* 216 */       if (!clipboards.keySet().contains(paramString)) {
/* 217 */         Clipboard clipboard = delegate.createClipboard(paramString);
/* 218 */         if (clipboard == null) {
/* 219 */           clipboard = new Clipboard(paramString);
/*     */         }
/* 221 */         clipboards.put(paramString, clipboard);
/*     */       } 
/* 223 */       return clipboards.get(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Pixels getPixelsForRawImage(byte[] paramArrayOfbyte) {
/* 228 */     Application.checkEventThread();
/* 229 */     ByteBuffer byteBuffer1 = ByteBuffer.wrap(paramArrayOfbyte, 0, 8);
/* 230 */     int i = byteBuffer1.getInt();
/* 231 */     int j = byteBuffer1.getInt();
/*     */     
/* 233 */     ByteBuffer byteBuffer2 = ByteBuffer.wrap(paramArrayOfbyte, 8, paramArrayOfbyte.length - 8);
/* 234 */     return Application.GetApplication().createPixels(i, j, byteBuffer2.slice());
/*     */   }
/*     */   
/*     */   public String toString() {
/* 238 */     return "Clipboard: " + this.name + "@" + hashCode();
/*     */   }
/*     */   
/*     */   protected void close() {
/* 242 */     Application.checkEventThread();
/* 243 */     synchronized (this.localDataProtector) {
/* 244 */       this.dataSource = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getName() {
/* 249 */     Application.checkEventThread();
/* 250 */     return this.name;
/*     */   }
/*     */   
/*     */   public static String getActionString(int paramInt) {
/* 254 */     Application.checkEventThread();
/* 255 */     StringBuilder stringBuilder = new StringBuilder("");
/* 256 */     int[] arrayOfInt = { 1, 2, 1073741824 };
/*     */ 
/*     */ 
/*     */     
/* 260 */     String[] arrayOfString = { "copy", "move", "link" };
/*     */ 
/*     */ 
/*     */     
/* 264 */     for (byte b = 0; b < 3; b++) {
/* 265 */       if ((arrayOfInt[b] & paramInt) > 0) {
/* 266 */         if (stringBuilder.length() > 0) {
/* 267 */           stringBuilder.append(",");
/*     */         }
/* 269 */         stringBuilder.append(arrayOfString[b]);
/*     */       } 
/*     */     } 
/* 272 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Clipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */