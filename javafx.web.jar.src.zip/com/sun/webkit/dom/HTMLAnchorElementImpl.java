/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.html.HTMLAnchorElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLAnchorElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLAnchorElement
/*     */ {
/*     */   HTMLAnchorElementImpl(long paramLong) {
/*  33 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLAnchorElement getImpl(long paramLong) {
/*  37 */     return (HTMLAnchorElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getCharsetImpl(long paramLong);
/*     */   
/*     */   public String getCharset() {
/*  43 */     return getCharsetImpl(getPeer());
/*     */   }
/*     */   static native void setCharsetImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setCharset(String paramString) {
/*  48 */     setCharsetImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCoords() {
/*  53 */     return getCoordsImpl(getPeer());
/*     */   }
/*     */   static native String getCoordsImpl(long paramLong);
/*     */   
/*     */   public void setCoords(String paramString) {
/*  58 */     setCoordsImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCoordsImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHreflang() {
/*  63 */     return getHreflangImpl(getPeer());
/*     */   }
/*     */   static native String getHreflangImpl(long paramLong);
/*     */   
/*     */   public void setHreflang(String paramString) {
/*  68 */     setHreflangImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHreflangImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getName() {
/*  73 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/*  78 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPing() {
/*  83 */     return getPingImpl(getPeer());
/*     */   }
/*     */   static native String getPingImpl(long paramLong);
/*     */   
/*     */   public void setPing(String paramString) {
/*  88 */     setPingImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPingImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRel() {
/*  93 */     return getRelImpl(getPeer());
/*     */   }
/*     */   static native String getRelImpl(long paramLong);
/*     */   
/*     */   public void setRel(String paramString) {
/*  98 */     setRelImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRelImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getRev() {
/* 103 */     return getRevImpl(getPeer());
/*     */   }
/*     */   static native String getRevImpl(long paramLong);
/*     */   
/*     */   public void setRev(String paramString) {
/* 108 */     setRevImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setRevImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getShape() {
/* 113 */     return getShapeImpl(getPeer());
/*     */   }
/*     */   static native String getShapeImpl(long paramLong);
/*     */   
/*     */   public void setShape(String paramString) {
/* 118 */     setShapeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setShapeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getTarget() {
/* 123 */     return getTargetImpl(getPeer());
/*     */   }
/*     */   static native String getTargetImpl(long paramLong);
/*     */   
/*     */   public void setTarget(String paramString) {
/* 128 */     setTargetImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTargetImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getType() {
/* 133 */     return getTypeImpl(getPeer());
/*     */   }
/*     */   static native String getTypeImpl(long paramLong);
/*     */   
/*     */   public void setType(String paramString) {
/* 138 */     setTypeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTypeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getText() {
/* 143 */     return getTextImpl(getPeer());
/*     */   }
/*     */   static native String getTextImpl(long paramLong);
/*     */   
/*     */   public void setText(String paramString) throws DOMException {
/* 148 */     setTextImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setTextImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHref() {
/* 153 */     return getHrefImpl(getPeer());
/*     */   }
/*     */   static native String getHrefImpl(long paramLong);
/*     */   
/*     */   public void setHref(String paramString) {
/* 158 */     setHrefImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHrefImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getOrigin() {
/* 163 */     return getOriginImpl(getPeer());
/*     */   }
/*     */   static native String getOriginImpl(long paramLong);
/*     */   
/*     */   public String getProtocol() {
/* 168 */     return getProtocolImpl(getPeer());
/*     */   }
/*     */   static native String getProtocolImpl(long paramLong);
/*     */   
/*     */   public void setProtocol(String paramString) {
/* 173 */     setProtocolImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setProtocolImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getUsername() {
/* 178 */     return getUsernameImpl(getPeer());
/*     */   }
/*     */   static native String getUsernameImpl(long paramLong);
/*     */   
/*     */   public void setUsername(String paramString) {
/* 183 */     setUsernameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setUsernameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPassword() {
/* 188 */     return getPasswordImpl(getPeer());
/*     */   }
/*     */   static native String getPasswordImpl(long paramLong);
/*     */   
/*     */   public void setPassword(String paramString) {
/* 193 */     setPasswordImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPasswordImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHost() {
/* 198 */     return getHostImpl(getPeer());
/*     */   }
/*     */   static native String getHostImpl(long paramLong);
/*     */   
/*     */   public void setHost(String paramString) {
/* 203 */     setHostImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHostImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHostname() {
/* 208 */     return getHostnameImpl(getPeer());
/*     */   }
/*     */   static native String getHostnameImpl(long paramLong);
/*     */   
/*     */   public void setHostname(String paramString) {
/* 213 */     setHostnameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHostnameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPort() {
/* 218 */     return getPortImpl(getPeer());
/*     */   }
/*     */   static native String getPortImpl(long paramLong);
/*     */   
/*     */   public void setPort(String paramString) {
/* 223 */     setPortImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPortImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getPathname() {
/* 228 */     return getPathnameImpl(getPeer());
/*     */   }
/*     */   static native String getPathnameImpl(long paramLong);
/*     */   
/*     */   public void setPathname(String paramString) {
/* 233 */     setPathnameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setPathnameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getSearch() {
/* 238 */     return getSearchImpl(getPeer());
/*     */   }
/*     */   static native String getSearchImpl(long paramLong);
/*     */   
/*     */   public void setSearch(String paramString) {
/* 243 */     setSearchImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setSearchImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHash() {
/* 248 */     return getHashImpl(getPeer());
/*     */   }
/*     */   static native String getHashImpl(long paramLong);
/*     */   
/*     */   public void setHash(String paramString) {
/* 253 */     setHashImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setHashImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLAnchorElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */