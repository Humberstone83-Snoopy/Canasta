/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.prism.Graphics;
/*     */ import com.sun.prism.Image;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.Texture;
/*     */ import com.sun.prism.image.CachingCompoundImage;
/*     */ import com.sun.prism.image.CompoundCoords;
/*     */ import com.sun.prism.image.Coords;
/*     */ import com.sun.prism.image.ViewPort;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGImageView
/*     */   extends NGNode
/*     */ {
/*     */   private Image image;
/*     */   private CachingCompoundImage compoundImage;
/*     */   private CompoundCoords compoundCoords;
/*     */   private float x;
/*     */   private float y;
/*     */   private float w;
/*     */   private float h;
/*     */   private Coords coords;
/*     */   private ViewPort reqviewport;
/*     */   private ViewPort imgviewport;
/*     */   private boolean renderable = false;
/*     */   private boolean coordsOK = false;
/*     */   static final int MAX_SIZE_OVERRIDE = 0;
/*     */   
/*     */   private void invalidate() {
/*  58 */     this.coordsOK = false;
/*  59 */     this.coords = null;
/*  60 */     this.compoundCoords = null;
/*  61 */     this.imgviewport = null;
/*  62 */     geometryChanged();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setViewport(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  67 */     if (paramFloat3 > 0.0F && paramFloat4 > 0.0F) {
/*  68 */       this.reqviewport = new ViewPort(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */     } else {
/*  70 */       this.reqviewport = null;
/*     */     } 
/*     */     
/*  73 */     this.w = paramFloat5;
/*  74 */     this.h = paramFloat6;
/*     */     
/*  76 */     invalidate();
/*     */   }
/*     */   
/*     */   private void calculatePositionAndClipping() {
/*  80 */     this.renderable = false;
/*  81 */     this.coordsOK = true;
/*     */     
/*  83 */     if (this.reqviewport == null || this.image == null) {
/*  84 */       this.renderable = (this.image != null);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     float f1 = this.image.getWidth();
/*  89 */     float f2 = this.image.getHeight();
/*  90 */     if (f1 == 0.0F || f2 == 0.0F)
/*  91 */       return;  this.imgviewport = this.reqviewport.getScaledVersion(this.image.getPixelScale());
/*     */     
/*  93 */     this.coords = this.imgviewport.getClippedCoords(f1, f2, this.w, this.h);
/*  94 */     this.renderable = (this.coords != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doRender(Graphics paramGraphics) {
/*  99 */     if (!this.coordsOK) {
/* 100 */       calculatePositionAndClipping();
/*     */     }
/* 102 */     if (this.renderable) {
/* 103 */       super.doRender(paramGraphics);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxSizeWrapper(ResourceFactory paramResourceFactory) {
/* 110 */     return paramResourceFactory.getMaximumTextureSize();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void renderContent(Graphics paramGraphics) {
/* 115 */     int i = this.image.getWidth();
/* 116 */     int j = this.image.getHeight();
/*     */     
/* 118 */     ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/* 119 */     int k = maxSizeWrapper(resourceFactory);
/* 120 */     if (i <= k && j <= k) {
/* 121 */       Texture texture = resourceFactory.getCachedTexture(this.image, Texture.WrapMode.CLAMP_TO_EDGE);
/* 122 */       if (this.coords == null) {
/* 123 */         paramGraphics.drawTexture(texture, this.x, this.y, this.x + this.w, this.y + this.h, 0.0F, 0.0F, i, j);
/*     */       } else {
/* 125 */         this.coords.draw(texture, paramGraphics, this.x, this.y);
/*     */       } 
/* 127 */       texture.unlock();
/*     */     } else {
/* 129 */       if (this.compoundImage == null) this.compoundImage = new CachingCompoundImage(this.image, k);
/*     */ 
/*     */       
/* 132 */       if (this.coords == null) this.coords = new Coords(this.w, this.h, new ViewPort(0.0F, 0.0F, i, j)); 
/* 133 */       if (this.compoundCoords == null) this.compoundCoords = new CompoundCoords(this.compoundImage, this.coords); 
/* 134 */       this.compoundCoords.draw(paramGraphics, this.compoundImage, this.x, this.y);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasOverlappingContents() {
/* 140 */     return false;
/*     */   }
/*     */   
/*     */   public void setImage(Object paramObject) {
/* 144 */     Image image = (Image)paramObject;
/*     */     
/* 146 */     if (this.image == image) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 151 */     boolean bool = (image == null || this.image == null || this.image.getPixelScale() != image.getPixelScale() || this.image.getHeight() != image.getHeight() || this.image.getWidth() != image.getWidth()) ? true : false;
/*     */     
/* 153 */     this.image = image;
/* 154 */     this.compoundImage = null;
/*     */     
/* 156 */     if (bool) invalidate(); 
/*     */   }
/*     */   
/*     */   public void setX(float paramFloat) {
/* 160 */     if (this.x != paramFloat) {
/* 161 */       this.x = paramFloat;
/* 162 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setY(float paramFloat) {
/* 167 */     if (this.y != paramFloat) {
/* 168 */       this.y = paramFloat;
/* 169 */       geometryChanged();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSmooth(boolean paramBoolean) {}
/*     */   
/*     */   protected boolean supportsOpaqueRegions() {
/* 177 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasOpaqueRegion() {
/* 184 */     assert this.image == null || (this.image.getWidth() >= 1 && this.image.getHeight() >= 1);
/* 185 */     return (super.hasOpaqueRegion() && this.w >= 1.0F && this.h >= 1.0F && this.image != null && this.image.isOpaque());
/*     */   }
/*     */ 
/*     */   
/*     */   protected RectBounds computeOpaqueRegion(RectBounds paramRectBounds) {
/* 190 */     return (RectBounds)paramRectBounds.deriveWithNewBounds(this.x, this.y, 0.0F, this.x + this.w, this.y + this.h, 0.0F);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGImageView.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */