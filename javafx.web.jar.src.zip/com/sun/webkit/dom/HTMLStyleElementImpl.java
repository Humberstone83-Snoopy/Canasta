/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLStyleElement;
/*    */ import org.w3c.dom.stylesheets.StyleSheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLStyleElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLStyleElement
/*    */ {
/*    */   HTMLStyleElementImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLStyleElement getImpl(long paramLong) {
/* 37 */     return (HTMLStyleElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native boolean getDisabledImpl(long paramLong);
/*    */   
/*    */   public boolean getDisabled() {
/* 43 */     return getDisabledImpl(getPeer());
/*    */   }
/*    */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public void setDisabled(boolean paramBoolean) {
/* 48 */     setDisabledImpl(getPeer(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMedia() {
/* 53 */     return getMediaImpl(getPeer());
/*    */   }
/*    */   static native String getMediaImpl(long paramLong);
/*    */   
/*    */   public void setMedia(String paramString) {
/* 58 */     setMediaImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setMediaImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getType() {
/* 63 */     return getTypeImpl(getPeer());
/*    */   }
/*    */   static native String getTypeImpl(long paramLong);
/*    */   
/*    */   public void setType(String paramString) {
/* 68 */     setTypeImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setTypeImpl(long paramLong, String paramString);
/*    */   
/*    */   public StyleSheet getSheet() {
/* 73 */     return StyleSheetImpl.getImpl(getSheetImpl(getPeer()));
/*    */   }
/*    */   
/*    */   static native long getSheetImpl(long paramLong);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLStyleElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */