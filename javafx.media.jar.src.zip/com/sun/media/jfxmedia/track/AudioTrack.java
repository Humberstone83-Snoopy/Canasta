/*     */ package com.sun.media.jfxmedia.track;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioTrack
/*     */   extends Track
/*     */ {
/*     */   public static final int UNKNOWN = 0;
/*     */   public static final int FRONT_LEFT = 1;
/*     */   public static final int FRONT_RIGHT = 2;
/*     */   public static final int FRONT_CENTER = 4;
/*     */   public static final int REAR_LEFT = 8;
/*     */   public static final int REAR_RIGHT = 16;
/*     */   public static final int REAR_CENTER = 32;
/*     */   private int numChannels;
/*     */   private int channelMask;
/*     */   private float encodedSampleRate;
/*     */   
/*     */   public AudioTrack(boolean paramBoolean, long paramLong, String paramString, Locale paramLocale, Track.Encoding paramEncoding, int paramInt1, int paramInt2, float paramFloat) {
/*  97 */     super(paramBoolean, paramLong, paramString, paramLocale, paramEncoding);
/*     */     
/*  99 */     if (paramInt1 < 1) {
/* 100 */       throw new IllegalArgumentException("numChannels < 1!");
/*     */     }
/*     */     
/* 103 */     if (paramFloat <= 0.0F) {
/* 104 */       throw new IllegalArgumentException("encodedSampleRate <= 0.0");
/*     */     }
/*     */     
/* 107 */     this.numChannels = paramInt1;
/* 108 */     this.channelMask = paramInt2;
/* 109 */     this.encodedSampleRate = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumChannels() {
/* 118 */     return this.numChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChannelMask() {
/* 127 */     return this.channelMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getEncodedSampleRate() {
/* 136 */     return this.encodedSampleRate;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 142 */     return "AudioTrack {\n    name: " + getName() + "\n    encoding: " + 
/* 143 */       getEncodingType() + "\n    language: " + 
/* 144 */       getLocale() + "\n    numChannels: " + this.numChannels + "\n    channelMask: " + this.channelMask + "\n    encodedSampleRate: " + this.encodedSampleRate + "\n}";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\track\AudioTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */