/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatteningPathIterator
/*     */   implements PathIterator
/*     */ {
/*     */   static final int GROW_SIZE = 24;
/*     */   PathIterator src;
/*     */   float squareflat;
/*     */   int limit;
/*  49 */   volatile float[] hold = new float[14];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float curx;
/*     */ 
/*     */ 
/*     */   
/*     */   float cury;
/*     */ 
/*     */ 
/*     */   
/*     */   float movx;
/*     */ 
/*     */ 
/*     */   
/*     */   float movy;
/*     */ 
/*     */ 
/*     */   
/*     */   int holdType;
/*     */ 
/*     */ 
/*     */   
/*     */   int holdEnd;
/*     */ 
/*     */ 
/*     */   
/*     */   int holdIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   int[] levels;
/*     */ 
/*     */ 
/*     */   
/*     */   int levelIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean done;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlatteningPathIterator(PathIterator paramPathIterator, float paramFloat) {
/*  96 */     this(paramPathIterator, paramFloat, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlatteningPathIterator(PathIterator paramPathIterator, float paramFloat, int paramInt) {
/* 119 */     if (paramFloat < 0.0F) {
/* 120 */       throw new IllegalArgumentException("flatness must be >= 0");
/*     */     }
/* 122 */     if (paramInt < 0) {
/* 123 */       throw new IllegalArgumentException("limit must be >= 0");
/*     */     }
/* 125 */     this.src = paramPathIterator;
/* 126 */     this.squareflat = paramFloat * paramFloat;
/* 127 */     this.limit = paramInt;
/* 128 */     this.levels = new int[paramInt + 1];
/*     */     
/* 130 */     next(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getFlatness() {
/* 138 */     return (float)Math.sqrt(this.squareflat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecursionLimit() {
/* 147 */     return this.limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWindingRule() {
/* 159 */     return this.src.getWindingRule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/* 168 */     return this.done;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureHoldCapacity(int paramInt) {
/* 176 */     if (this.holdIndex - paramInt < 0) {
/* 177 */       int i = this.hold.length - this.holdIndex;
/* 178 */       int j = this.hold.length + 24;
/* 179 */       float[] arrayOfFloat = new float[j];
/* 180 */       System.arraycopy(this.hold, this.holdIndex, arrayOfFloat, this.holdIndex + 24, i);
/*     */ 
/*     */       
/* 183 */       this.hold = arrayOfFloat;
/* 184 */       this.holdIndex += 24;
/* 185 */       this.holdEnd += 24;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void next() {
/* 195 */     next(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void next(boolean paramBoolean) {
/*     */     int i;
/* 201 */     if (this.holdIndex >= this.holdEnd) {
/* 202 */       if (paramBoolean) {
/* 203 */         this.src.next();
/*     */       }
/* 205 */       if (this.src.isDone()) {
/* 206 */         this.done = true;
/*     */         return;
/*     */       } 
/* 209 */       this.holdType = this.src.currentSegment(this.hold);
/* 210 */       this.levelIndex = 0;
/* 211 */       this.levels[0] = 0;
/*     */     } 
/*     */     
/* 214 */     switch (this.holdType) {
/*     */       case 0:
/*     */       case 1:
/* 217 */         this.curx = this.hold[0];
/* 218 */         this.cury = this.hold[1];
/* 219 */         if (this.holdType == 0) {
/* 220 */           this.movx = this.curx;
/* 221 */           this.movy = this.cury;
/*     */         } 
/* 223 */         this.holdIndex = 0;
/* 224 */         this.holdEnd = 0;
/*     */         break;
/*     */       case 4:
/* 227 */         this.curx = this.movx;
/* 228 */         this.cury = this.movy;
/* 229 */         this.holdIndex = 0;
/* 230 */         this.holdEnd = 0;
/*     */         break;
/*     */       case 2:
/* 233 */         if (this.holdIndex >= this.holdEnd) {
/*     */           
/* 235 */           this.holdIndex = this.hold.length - 6;
/* 236 */           this.holdEnd = this.hold.length - 2;
/* 237 */           this.hold[this.holdIndex + 0] = this.curx;
/* 238 */           this.hold[this.holdIndex + 1] = this.cury;
/* 239 */           this.hold[this.holdIndex + 2] = this.hold[0];
/* 240 */           this.hold[this.holdIndex + 3] = this.hold[1];
/* 241 */           this.hold[this.holdIndex + 4] = this.curx = this.hold[2];
/* 242 */           this.hold[this.holdIndex + 5] = this.cury = this.hold[3];
/*     */         } 
/*     */         
/* 245 */         i = this.levels[this.levelIndex];
/* 246 */         while (i < this.limit && 
/* 247 */           QuadCurve2D.getFlatnessSq(this.hold, this.holdIndex) >= this.squareflat) {
/*     */ 
/*     */ 
/*     */           
/* 251 */           ensureHoldCapacity(4);
/* 252 */           QuadCurve2D.subdivide(this.hold, this.holdIndex, this.hold, this.holdIndex - 4, this.hold, this.holdIndex);
/*     */ 
/*     */           
/* 255 */           this.holdIndex -= 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 263 */           i++;
/* 264 */           this.levels[this.levelIndex] = i;
/* 265 */           this.levelIndex++;
/* 266 */           this.levels[this.levelIndex] = i;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 274 */         this.holdIndex += 4;
/* 275 */         this.levelIndex--;
/*     */         break;
/*     */       case 3:
/* 278 */         if (this.holdIndex >= this.holdEnd) {
/*     */           
/* 280 */           this.holdIndex = this.hold.length - 8;
/* 281 */           this.holdEnd = this.hold.length - 2;
/* 282 */           this.hold[this.holdIndex + 0] = this.curx;
/* 283 */           this.hold[this.holdIndex + 1] = this.cury;
/* 284 */           this.hold[this.holdIndex + 2] = this.hold[0];
/* 285 */           this.hold[this.holdIndex + 3] = this.hold[1];
/* 286 */           this.hold[this.holdIndex + 4] = this.hold[2];
/* 287 */           this.hold[this.holdIndex + 5] = this.hold[3];
/* 288 */           this.hold[this.holdIndex + 6] = this.curx = this.hold[4];
/* 289 */           this.hold[this.holdIndex + 7] = this.cury = this.hold[5];
/*     */         } 
/*     */         
/* 292 */         i = this.levels[this.levelIndex];
/* 293 */         while (i < this.limit && 
/* 294 */           CubicCurve2D.getFlatnessSq(this.hold, this.holdIndex) >= this.squareflat) {
/*     */ 
/*     */ 
/*     */           
/* 298 */           ensureHoldCapacity(6);
/* 299 */           CubicCurve2D.subdivide(this.hold, this.holdIndex, this.hold, this.holdIndex - 6, this.hold, this.holdIndex);
/*     */ 
/*     */           
/* 302 */           this.holdIndex -= 6;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 310 */           i++;
/* 311 */           this.levels[this.levelIndex] = i;
/* 312 */           this.levelIndex++;
/* 313 */           this.levels[this.levelIndex] = i;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 321 */         this.holdIndex += 6;
/* 322 */         this.levelIndex--;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int currentSegment(float[] paramArrayOffloat) {
/* 348 */     if (isDone()) {
/* 349 */       throw new NoSuchElementException("flattening iterator out of bounds");
/*     */     }
/* 351 */     int i = this.holdType;
/* 352 */     if (i != 4) {
/* 353 */       paramArrayOffloat[0] = this.hold[this.holdIndex + 0];
/* 354 */       paramArrayOffloat[1] = this.hold[this.holdIndex + 1];
/* 355 */       if (i != 0) {
/* 356 */         i = 1;
/*     */       }
/*     */     } 
/* 359 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\FlatteningPathIterator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */