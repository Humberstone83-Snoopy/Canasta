/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MacMenuBarDelegate
/*    */   implements MenuBarDelegate
/*    */ {
/*    */   long ptr;
/*    */   
/*    */   private native long _createMenuBar();
/*    */   
/*    */   private native void _insert(long paramLong1, long paramLong2, int paramInt);
/*    */   
/*    */   public boolean createMenuBar() {
/* 37 */     this.ptr = _createMenuBar();
/* 38 */     return (this.ptr != 0L);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean insert(MenuDelegate paramMenuDelegate, int paramInt) {
/* 43 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuDelegate;
/* 44 */     _insert(this.ptr, macMenuDelegate.ptr, paramInt);
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean remove(MenuDelegate paramMenuDelegate, int paramInt) {
/* 50 */     MacMenuDelegate macMenuDelegate = (MacMenuDelegate)paramMenuDelegate;
/* 51 */     _remove(this.ptr, macMenuDelegate.ptr, paramInt);
/* 52 */     return true;
/*    */   }
/*    */   private native void _remove(long paramLong1, long paramLong2, int paramInt);
/*    */   public long getNativeMenu() {
/* 56 */     return this.ptr;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacMenuBarDelegate.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */