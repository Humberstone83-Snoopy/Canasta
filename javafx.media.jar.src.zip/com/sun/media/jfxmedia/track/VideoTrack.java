/*     */ package com.sun.media.jfxmedia.track;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VideoTrack
/*     */   extends Track
/*     */ {
/*     */   private VideoResolution frameSize;
/*     */   private float encodedFrameRate;
/*     */   private boolean hasAlphaChannel;
/*     */   
/*     */   public VideoTrack(boolean paramBoolean1, long paramLong, String paramString, Locale paramLocale, Track.Encoding paramEncoding, VideoResolution paramVideoResolution, float paramFloat, boolean paramBoolean2) {
/*  63 */     super(paramBoolean1, paramLong, paramString, paramLocale, paramEncoding);
/*     */     
/*  65 */     if (paramVideoResolution == null) {
/*  66 */       throw new IllegalArgumentException("frameSize == null!");
/*     */     }
/*  68 */     if (paramVideoResolution.width <= 0) {
/*  69 */       throw new IllegalArgumentException("frameSize.width <= 0!");
/*     */     }
/*  71 */     if (paramVideoResolution.height <= 0) {
/*  72 */       throw new IllegalArgumentException("frameSize.height <= 0!");
/*     */     }
/*     */     
/*  75 */     if (paramFloat < 0.0F) {
/*  76 */       throw new IllegalArgumentException("encodedFrameRate < 0.0!");
/*     */     }
/*     */     
/*  79 */     this.frameSize = paramVideoResolution;
/*  80 */     this.encodedFrameRate = paramFloat;
/*  81 */     this.hasAlphaChannel = paramBoolean2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAlphaChannel() {
/*  90 */     return this.hasAlphaChannel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getEncodedFrameRate() {
/* 100 */     return this.encodedFrameRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VideoResolution getFrameSize() {
/* 109 */     return this.frameSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 116 */     return "VideoTrack {\n    name: " + getName() + "\n    encoding: " + 
/* 117 */       getEncodingType() + "\n    frameSize: " + this.frameSize + "\n    encodedFrameRate: " + this.encodedFrameRate + "\n    hasAlphaChannel: " + this.hasAlphaChannel + "\n}";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\track\VideoTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */