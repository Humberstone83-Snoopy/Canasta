/*     */ package com.sun.javafx.reflect;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.AllPermission;
/*     */ import java.security.CodeSource;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.SecureClassLoader;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodUtil
/*     */   extends SecureClassLoader
/*     */ {
/*     */   private static final String MISC_PKG = "com.sun.javafx.reflect.";
/*     */   private static final String TRAMPOLINE = "com.sun.javafx.reflect.Trampoline";
/*  86 */   private static final Method bounce = getTrampoline();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethod(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass) throws NoSuchMethodException {
/*  94 */     ReflectUtil.checkPackageAccess(paramClass);
/*  95 */     return paramClass.getMethod(paramString, paramArrayOfClass);
/*     */   }
/*     */   
/*     */   public static Method[] getMethods(Class<?> paramClass) {
/*  99 */     ReflectUtil.checkPackageAccess(paramClass);
/* 100 */     return paramClass.getMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Method[] getPublicMethods(Class<?> paramClass) {
/* 112 */     if (System.getSecurityManager() == null) {
/* 113 */       return paramClass.getMethods();
/*     */     }
/* 115 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 116 */     while (paramClass != null) {
/* 117 */       boolean bool = getInternalPublicMethods(paramClass, (Map)hashMap);
/* 118 */       if (bool) {
/*     */         break;
/*     */       }
/* 121 */       getInterfaceMethods(paramClass, (Map)hashMap);
/* 122 */       paramClass = paramClass.getSuperclass();
/*     */     } 
/* 124 */     return (Method[])hashMap.values().toArray((Object[])new Method[hashMap.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void getInterfaceMethods(Class<?> paramClass, Map<Signature, Method> paramMap) {
/* 132 */     Class[] arrayOfClass = paramClass.getInterfaces();
/* 133 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 134 */       Class<?> clazz = arrayOfClass[b];
/* 135 */       boolean bool = getInternalPublicMethods(clazz, paramMap);
/* 136 */       if (!bool) {
/* 137 */         getInterfaceMethods(clazz, paramMap);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean getInternalPublicMethods(Class<?> paramClass, Map<Signature, Method> paramMap) {
/* 148 */     Method[] arrayOfMethod = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 155 */       if (!Modifier.isPublic(paramClass.getModifiers())) {
/* 156 */         return false;
/*     */       }
/* 158 */       if (!ReflectUtil.isPackageAccessible(paramClass)) {
/* 159 */         return false;
/*     */       }
/*     */       
/* 162 */       arrayOfMethod = paramClass.getMethods();
/* 163 */     } catch (SecurityException securityException) {
/* 164 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     boolean bool = true; byte b;
/* 174 */     for (b = 0; b < arrayOfMethod.length; b++) {
/* 175 */       Class<?> clazz = arrayOfMethod[b].getDeclaringClass();
/* 176 */       if (!Modifier.isPublic(clazz.getModifiers())) {
/* 177 */         bool = false;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 182 */     if (bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 187 */       for (b = 0; b < arrayOfMethod.length; b++) {
/* 188 */         addMethod(paramMap, arrayOfMethod[b]);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 195 */       for (b = 0; b < arrayOfMethod.length; b++) {
/* 196 */         Class<?> clazz = arrayOfMethod[b].getDeclaringClass();
/* 197 */         if (paramClass.equals(clazz)) {
/* 198 */           addMethod(paramMap, arrayOfMethod[b]);
/*     */         }
/*     */       } 
/*     */     } 
/* 202 */     return bool;
/*     */   }
/*     */   
/*     */   private static void addMethod(Map<Signature, Method> paramMap, Method paramMethod) {
/* 206 */     Signature signature = new Signature(paramMethod);
/* 207 */     if (!paramMap.containsKey(signature)) {
/* 208 */       paramMap.put(signature, paramMethod);
/* 209 */     } else if (!paramMethod.getDeclaringClass().isInterface()) {
/*     */ 
/*     */ 
/*     */       
/* 213 */       Method method = paramMap.get(signature);
/* 214 */       if (method.getDeclaringClass().isInterface()) {
/* 215 */         paramMap.put(signature, paramMethod);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Signature
/*     */   {
/*     */     private final String methodName;
/*     */     
/*     */     private final Class<?>[] argClasses;
/*     */     
/*     */     private final int hashCode;
/*     */     
/*     */     Signature(Method param1Method) {
/* 230 */       this.methodName = param1Method.getName();
/* 231 */       this.argClasses = param1Method.getParameterTypes();
/* 232 */       this.hashCode = this.methodName.hashCode() + Arrays.hashCode((Object[])this.argClasses);
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 236 */       return this.hashCode;
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 240 */       if (this == param1Object) {
/* 241 */         return true;
/*     */       }
/* 243 */       Signature signature = (Signature)param1Object;
/* 244 */       if (!this.methodName.equals(signature.methodName)) {
/* 245 */         return false;
/*     */       }
/* 247 */       if (this.argClasses.length != signature.argClasses.length) {
/* 248 */         return false;
/*     */       }
/* 250 */       for (byte b = 0; b < this.argClasses.length; b++) {
/* 251 */         if (this.argClasses[b] != signature.argClasses[b]) {
/* 252 */           return false;
/*     */         }
/*     */       } 
/* 255 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Module getTrampolineModule() {
/* 264 */     return bounce.getDeclaringClass().getModule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object invoke(Method paramMethod, Object paramObject, Object[] paramArrayOfObject) throws InvocationTargetException, IllegalAccessException {
/*     */     try {
/* 273 */       return bounce.invoke((Object)null, new Object[] { paramMethod, paramObject, paramArrayOfObject });
/* 274 */     } catch (InvocationTargetException invocationTargetException) {
/* 275 */       Throwable throwable = invocationTargetException.getCause();
/*     */       
/* 277 */       if (throwable instanceof InvocationTargetException)
/* 278 */         throw (InvocationTargetException)throwable; 
/* 279 */       if (throwable instanceof IllegalAccessException)
/* 280 */         throw (IllegalAccessException)throwable; 
/* 281 */       if (throwable instanceof RuntimeException)
/* 282 */         throw (RuntimeException)throwable; 
/* 283 */       if (throwable instanceof Error) {
/* 284 */         throw (Error)throwable;
/*     */       }
/* 286 */       throw new Error("Unexpected invocation error", throwable);
/*     */     }
/* 288 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 290 */       throw new Error("Unexpected invocation error", illegalAccessException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Method getTrampoline() {
/*     */     try {
/* 296 */       return AccessController.<Method>doPrivileged(new PrivilegedExceptionAction<Method>()
/*     */           {
/*     */             public Method run() throws Exception {
/* 299 */               Class clazz = MethodUtil.getTrampolineClass();
/* 300 */               Class[] arrayOfClass = { Method.class, Object.class, Object[].class };
/*     */ 
/*     */               
/* 303 */               Method method = clazz.getDeclaredMethod("invoke", arrayOfClass);
/* 304 */               method.setAccessible(true);
/* 305 */               return method;
/*     */             }
/*     */           });
/* 308 */     } catch (Exception exception) {
/* 309 */       throw new InternalError("bouncer cannot be found", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized Class<?> loadClass(String paramString, boolean paramBoolean) throws ClassNotFoundException {
/* 318 */     ReflectUtil.checkPackageAccess(paramString);
/* 319 */     Class<?> clazz = findLoadedClass(paramString);
/* 320 */     if (clazz == null) {
/*     */       try {
/* 322 */         clazz = findClass(paramString);
/* 323 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */       
/* 326 */       if (clazz == null) {
/* 327 */         clazz = getParent().loadClass(paramString);
/*     */       }
/*     */     } 
/* 330 */     if (paramBoolean) {
/* 331 */       resolveClass(clazz);
/*     */     }
/* 333 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> findClass(String paramString) throws ClassNotFoundException {
/* 340 */     if (!paramString.startsWith("com.sun.javafx.reflect.")) {
/* 341 */       throw new ClassNotFoundException(paramString);
/*     */     }
/* 343 */     String str = paramString.replace('.', '/').concat(".class");
/*     */     try {
/* 345 */       InputStream inputStream = MethodUtil.class.getModule().getResourceAsStream(str);
/* 346 */       if (inputStream != null)
/* 347 */       { InputStream inputStream1 = inputStream; 
/* 348 */         try { byte[] arrayOfByte = inputStream.readAllBytes();
/* 349 */           Class<?> clazz = defineClass(paramString, arrayOfByte);
/* 350 */           if (inputStream1 != null) inputStream1.close();  return clazz; } catch (Throwable throwable) { if (inputStream1 != null)
/*     */             try { inputStream1.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } 
/* 352 */     } catch (IOException iOException) {
/* 353 */       throw new ClassNotFoundException(paramString, iOException);
/*     */     } 
/*     */     
/* 356 */     throw new ClassNotFoundException(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> defineClass(String paramString, byte[] paramArrayOfbyte) throws IOException {
/* 364 */     CodeSource codeSource = new CodeSource(null, (Certificate[])null);
/* 365 */     if (!paramString.equals("com.sun.javafx.reflect.Trampoline")) {
/* 366 */       throw new IOException("MethodUtil: bad name " + paramString);
/*     */     }
/* 368 */     return defineClass(paramString, paramArrayOfbyte, 0, paramArrayOfbyte.length, codeSource);
/*     */   }
/*     */ 
/*     */   
/*     */   protected PermissionCollection getPermissions(CodeSource paramCodeSource) {
/* 373 */     PermissionCollection permissionCollection = super.getPermissions(paramCodeSource);
/* 374 */     permissionCollection.add(new AllPermission());
/* 375 */     return permissionCollection;
/*     */   }
/*     */   
/*     */   private static Class<?> getTrampolineClass() {
/*     */     try {
/* 380 */       return Class.forName("com.sun.javafx.reflect.Trampoline", true, new MethodUtil());
/* 381 */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       
/* 383 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\reflect\MethodUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */