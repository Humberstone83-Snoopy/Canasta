package com.sun.javafx.collections;

import java.util.Comparator;
import java.util.List;

public interface SortableList<E> extends List<E> {
  void sort();
  
  void sort(Comparator<? super E> paramComparator);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\collections\SortableList.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */