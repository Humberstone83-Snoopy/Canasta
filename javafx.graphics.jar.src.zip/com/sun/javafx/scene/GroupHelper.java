/*    */ package com.sun.javafx.scene;
/*    */ 
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.geometry.Bounds;
/*    */ import javafx.scene.Group;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupHelper
/*    */   extends ParentHelper
/*    */ {
/* 43 */   private static final GroupHelper theInstance = new GroupHelper(); static {
/* 44 */     Utils.forceInit(Group.class);
/*    */   }
/*    */   private static GroupAccessor groupAccessor;
/*    */   private static GroupHelper getInstance() {
/* 48 */     return theInstance;
/*    */   }
/*    */   
/*    */   public static void initHelper(Group paramGroup) {
/* 52 */     setHelper(paramGroup, getInstance());
/*    */   }
/*    */ 
/*    */   
/*    */   protected NGNode createPeerImpl(Node paramNode) {
/* 57 */     return super.createPeerImpl(paramNode);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Bounds computeLayoutBoundsImpl(Node paramNode) {
/* 62 */     groupAccessor.doComputeLayoutBounds(paramNode);
/* 63 */     return super.computeLayoutBoundsImpl(paramNode);
/*    */   }
/*    */   
/*    */   public static void setGroupAccessor(GroupAccessor paramGroupAccessor) {
/* 67 */     if (groupAccessor != null) {
/* 68 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 71 */     groupAccessor = paramGroupAccessor;
/*    */   }
/*    */   
/*    */   public static interface GroupAccessor {
/*    */     Bounds doComputeLayoutBounds(Node param1Node);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\GroupHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */