/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLFormElement;
/*    */ import org.w3c.dom.html.HTMLLegendElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLLegendElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLLegendElement
/*    */ {
/*    */   HTMLLegendElementImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLLegendElement getImpl(long paramLong) {
/* 37 */     return (HTMLLegendElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getFormImpl(long paramLong);
/*    */   
/*    */   public HTMLFormElement getForm() {
/* 43 */     return HTMLFormElementImpl.getImpl(getFormImpl(getPeer()));
/*    */   }
/*    */   static native String getAlignImpl(long paramLong);
/*    */   
/*    */   public String getAlign() {
/* 48 */     return getAlignImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAlign(String paramString) {
/* 53 */     setAlignImpl(getPeer(), paramString);
/*    */   }
/*    */   static native void setAlignImpl(long paramLong, String paramString);
/*    */   
/*    */   public String getAccessKey() {
/* 58 */     return getAccessKeyImpl(getPeer());
/*    */   }
/*    */   static native String getAccessKeyImpl(long paramLong);
/*    */   
/*    */   public void setAccessKey(String paramString) {
/* 63 */     setAccessKeyImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setAccessKeyImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLLegendElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */