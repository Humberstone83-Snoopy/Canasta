/*    */ package javafx.scene.media;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AudioTrack
/*    */   extends Track
/*    */ {
/*    */   @Deprecated
/*    */   public final String getLanguage() {
/* 49 */     Locale locale = getLocale();
/* 50 */     return (null == locale) ? null : locale.getLanguage();
/*    */   }
/*    */   
/*    */   AudioTrack(long paramLong, Map<String, Object> paramMap) {
/* 54 */     super(paramLong, paramMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\AudioTrack.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */