/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.PickRay;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.input.PickResultChooser;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.scene.Camera;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.SubScene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubSceneHelper
/*     */   extends NodeHelper
/*     */ {
/*  47 */   private static final SubSceneHelper theInstance = new SubSceneHelper(); static {
/*  48 */     Utils.forceInit(SubScene.class);
/*     */   }
/*     */   private static SubSceneAccessor subSceneAccessor;
/*     */   private static SubSceneHelper getInstance() {
/*  52 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(SubScene paramSubScene) {
/*  56 */     setHelper(paramSubScene, getInstance());
/*     */   }
/*     */   
/*     */   public static void superProcessCSS(Node paramNode) {
/*  60 */     ((SubSceneHelper)getHelper(paramNode)).superProcessCSSImpl(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  65 */     return subSceneAccessor.doCreatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  70 */     super.updatePeerImpl(paramNode);
/*  71 */     subSceneAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  77 */     return subSceneAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  82 */     return subSceneAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   void superProcessCSSImpl(Node paramNode) {
/*  86 */     super.processCSSImpl(paramNode);
/*     */   }
/*     */   
/*     */   protected void processCSSImpl(Node paramNode) {
/*  90 */     subSceneAccessor.doProcessCSS(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pickNodeLocalImpl(Node paramNode, PickRay paramPickRay, PickResultChooser paramPickResultChooser) {
/*  96 */     subSceneAccessor.doPickNodeLocal(paramNode, paramPickRay, paramPickResultChooser);
/*     */   }
/*     */   
/*     */   public static boolean isDepthBuffer(SubScene paramSubScene) {
/* 100 */     return subSceneAccessor.isDepthBuffer(paramSubScene);
/*     */   }
/*     */   
/*     */   public static Camera getEffectiveCamera(SubScene paramSubScene) {
/* 104 */     return subSceneAccessor.getEffectiveCamera(paramSubScene);
/*     */   }
/*     */   
/*     */   public static void setSubSceneAccessor(SubSceneAccessor paramSubSceneAccessor) {
/* 108 */     if (subSceneAccessor != null) {
/* 109 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 112 */     subSceneAccessor = paramSubSceneAccessor;
/*     */   }
/*     */   
/*     */   public static interface SubSceneAccessor {
/*     */     NGNode doCreatePeer(Node param1Node);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     void doProcessCSS(Node param1Node);
/*     */     
/*     */     void doPickNodeLocal(Node param1Node, PickRay param1PickRay, PickResultChooser param1PickResultChooser);
/*     */     
/*     */     boolean isDepthBuffer(SubScene param1SubScene);
/*     */     
/*     */     Camera getEffectiveCamera(SubScene param1SubScene);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\SubSceneHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */