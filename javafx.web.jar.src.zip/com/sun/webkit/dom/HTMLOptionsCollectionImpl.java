/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.html.HTMLOptionElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLOptionsCollectionImpl
/*    */   extends HTMLCollectionImpl
/*    */ {
/*    */   HTMLOptionsCollectionImpl(long paramLong) {
/* 34 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLOptionsCollectionImpl getImpl(long paramLong) {
/* 38 */     return (HTMLOptionsCollectionImpl)create(paramLong);
/*    */   }
/*    */   
/*    */   static native int getSelectedIndexImpl(long paramLong);
/*    */   
/*    */   public int getSelectedIndex() {
/* 44 */     return getSelectedIndexImpl(getPeer());
/*    */   }
/*    */   static native void setSelectedIndexImpl(long paramLong, int paramInt);
/*    */   
/*    */   public void setSelectedIndex(int paramInt) {
/* 49 */     setSelectedIndexImpl(getPeer(), paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 54 */     return getLengthImpl(getPeer());
/*    */   }
/*    */   static native int getLengthImpl(long paramLong);
/*    */   
/*    */   public void setLength(int paramInt) throws DOMException {
/* 59 */     setLengthImpl(getPeer(), paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   static native void setLengthImpl(long paramLong, int paramInt);
/*    */ 
/*    */   
/*    */   public Node namedItem(String paramString) {
/* 67 */     return NodeImpl.getImpl(namedItemImpl(getPeer(), paramString));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native long namedItemImpl(long paramLong, String paramString);
/*    */ 
/*    */ 
/*    */   
/*    */   public void add(HTMLOptionElement paramHTMLOptionElement, int paramInt) throws DOMException {
/* 77 */     addImpl(getPeer(), 
/* 78 */         HTMLOptionElementImpl.getPeer(paramHTMLOptionElement), paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static native void addImpl(long paramLong1, long paramLong2, int paramInt);
/*    */ 
/*    */ 
/*    */   
/*    */   public Node item(int paramInt) {
/* 88 */     return NodeImpl.getImpl(itemImpl(getPeer(), paramInt));
/*    */   }
/*    */   
/*    */   static native long itemImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLOptionsCollectionImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */