/*     */ package com.sun.javafx.font.freetype;
/*     */ 
/*     */ import com.sun.javafx.font.CompositeFontResource;
/*     */ import com.sun.javafx.font.FontResource;
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PangoGlyphLayout
/*     */   extends GlyphLayout
/*     */ {
/*  41 */   private static final long fontmap = OSPango.pango_ft2_font_map_new();
/*     */ 
/*     */   
/*     */   private int getSlot(PGFont paramPGFont, PangoGlyphString paramPangoGlyphString) {
/*  45 */     CompositeFontResource compositeFontResource = (CompositeFontResource)paramPGFont.getFontResource();
/*  46 */     long l1 = paramPangoGlyphString.font;
/*  47 */     long l2 = OSPango.pango_font_describe(l1);
/*  48 */     String str1 = OSPango.pango_font_description_get_family(l2);
/*  49 */     int i = OSPango.pango_font_description_get_style(l2);
/*  50 */     int j = OSPango.pango_font_description_get_weight(l2);
/*  51 */     OSPango.pango_font_description_free(l2);
/*  52 */     boolean bool1 = (j == 700) ? true : false;
/*  53 */     boolean bool2 = (i != 0) ? true : false;
/*     */     
/*  55 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  56 */     PGFont pGFont = prismFontFactory.createFont(str1, bool1, bool2, paramPGFont
/*  57 */         .getSize());
/*  58 */     String str2 = pGFont.getFullName();
/*  59 */     String str3 = compositeFontResource.getSlotResource(0).getFullName();
/*     */     
/*  61 */     int k = 0;
/*  62 */     if (!str2.equalsIgnoreCase(str3)) {
/*  63 */       k = compositeFontResource.getSlotForFont(str2);
/*  64 */       if (PrismFontFactory.debugFonts) {
/*  65 */         System.err.println("\tFallback font= " + str2 + " slot=" + (k >> 24));
/*     */       }
/*     */     } 
/*  68 */     return k;
/*     */   }
/*     */   
/*     */   private boolean check(long paramLong1, String paramString, long paramLong2, long paramLong3, long paramLong4) {
/*  72 */     if (paramLong1 != 0L) return false; 
/*  73 */     if (paramString != null && PrismFontFactory.debugFonts) {
/*  74 */       System.err.println(paramString);
/*     */     }
/*     */     
/*  77 */     if (paramLong4 != 0L) OSPango.pango_attr_list_unref(paramLong4); 
/*  78 */     if (paramLong3 != 0L) OSPango.pango_font_description_free(paramLong3); 
/*  79 */     if (paramLong2 != 0L) OSPango.g_object_unref(paramLong2); 
/*  80 */     return true;
/*     */   }
/*     */   
/*  83 */   private long str = 0L;
/*     */ 
/*     */   
/*     */   public void layout(TextRun paramTextRun, PGFont paramPGFont, FontStrike paramFontStrike, char[] paramArrayOfchar) {
/*  87 */     FontResource fontResource = paramPGFont.getFontResource();
/*  88 */     boolean bool = fontResource instanceof CompositeFontResource;
/*  89 */     if (bool) {
/*  90 */       fontResource = ((CompositeFontResource)fontResource).getSlotResource(0);
/*     */     }
/*  92 */     if (check(fontmap, "Failed allocating PangoFontMap.", 0L, 0L, 0L)) {
/*     */       return;
/*     */     }
/*  95 */     long l1 = OSPango.pango_font_map_create_context(fontmap);
/*  96 */     if (check(l1, "Failed allocating PangoContext.", 0L, 0L, 0L)) {
/*     */       return;
/*     */     }
/*  99 */     boolean bool1 = ((paramTextRun.getLevel() & 0x1) != 0) ? true : false;
/* 100 */     if (bool1) {
/* 101 */       OSPango.pango_context_set_base_dir(l1, 1);
/*     */     }
/* 103 */     float f = paramPGFont.getSize();
/* 104 */     boolean bool2 = fontResource.isItalic() ? true : false;
/* 105 */     char c = fontResource.isBold() ? 'ʼ' : 'Ɛ';
/* 106 */     long l2 = OSPango.pango_font_description_new();
/* 107 */     if (check(l2, "Failed allocating FontDescription.", l1, 0L, 0L)) {
/*     */       return;
/*     */     }
/* 110 */     OSPango.pango_font_description_set_family(l2, fontResource.getFamilyName());
/* 111 */     OSPango.pango_font_description_set_absolute_size(l2, (f * 1024.0F));
/* 112 */     OSPango.pango_font_description_set_stretch(l2, 4);
/* 113 */     OSPango.pango_font_description_set_style(l2, bool2);
/* 114 */     OSPango.pango_font_description_set_weight(l2, c);
/* 115 */     long l3 = OSPango.pango_attr_list_new();
/* 116 */     if (check(l3, "Failed allocating PangoAttributeList.", l1, l2, 0L)) {
/*     */       return;
/*     */     }
/* 119 */     long l4 = OSPango.pango_attr_font_desc_new(l2);
/* 120 */     if (check(l4, "Failed allocating PangoAttribute.", l1, l2, l3)) {
/*     */       return;
/*     */     }
/* 123 */     OSPango.pango_attr_list_insert(l3, l4);
/* 124 */     if (!bool) {
/* 125 */       l4 = OSPango.pango_attr_fallback_new(false);
/* 126 */       OSPango.pango_attr_list_insert(l3, l4);
/*     */     } 
/*     */     
/* 129 */     if (this.str == 0L) {
/* 130 */       this.str = OSPango.g_utf16_to_utf8(paramArrayOfchar);
/* 131 */       if (check(this.str, "Failed allocating UTF-8 buffer.", l1, l2, l3)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 137 */     long l5 = OSPango.g_utf8_offset_to_pointer(this.str, paramTextRun.getStart());
/* 138 */     long l6 = OSPango.g_utf8_offset_to_pointer(this.str, paramTextRun.getEnd());
/* 139 */     long l7 = OSPango.pango_itemize(l1, this.str, (int)(l5 - this.str), (int)(l6 - l5), l3, 0L);
/*     */     
/* 141 */     if (l7 != 0L) {
/*     */       
/* 143 */       int i = OSPango.g_list_length(l7);
/* 144 */       PangoGlyphString[] arrayOfPangoGlyphString = new PangoGlyphString[i]; int j;
/* 145 */       for (j = 0; j < i; j++) {
/* 146 */         long l = OSPango.g_list_nth_data(l7, j);
/* 147 */         if (l != 0L) {
/* 148 */           arrayOfPangoGlyphString[j] = OSPango.pango_shape(this.str, l);
/* 149 */           OSPango.pango_item_free(l);
/*     */         } 
/*     */       } 
/* 152 */       OSPango.g_list_free(l7);
/*     */       
/* 154 */       j = 0;
/* 155 */       for (PangoGlyphString pangoGlyphString : arrayOfPangoGlyphString) {
/* 156 */         if (pangoGlyphString != null) {
/* 157 */           j += pangoGlyphString.num_glyphs;
/*     */         }
/*     */       } 
/* 160 */       int[] arrayOfInt1 = new int[j];
/* 161 */       float[] arrayOfFloat = new float[j * 2 + 2];
/* 162 */       int[] arrayOfInt2 = new int[j];
/* 163 */       int k = 0;
/* 164 */       int m = bool1 ? paramTextRun.getLength() : 0;
/* 165 */       int n = 0;
/* 166 */       for (PangoGlyphString pangoGlyphString : arrayOfPangoGlyphString) {
/* 167 */         if (pangoGlyphString != null) {
/* 168 */           byte b1 = bool ? getSlot(paramPGFont, pangoGlyphString) : 0;
/* 169 */           if (bool1) m -= pangoGlyphString.num_chars; 
/* 170 */           for (byte b2 = 0; b2 < pangoGlyphString.num_glyphs; b2++) {
/* 171 */             int i1 = k + b2;
/* 172 */             if (b1 != -1) {
/* 173 */               int i2 = pangoGlyphString.glyphs[b2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 179 */               if (0 <= i2 && i2 <= 16777215) {
/* 180 */                 arrayOfInt1[i1] = b1 << 24 | i2;
/*     */               }
/*     */             } 
/* 183 */             if (f != 0.0F) {
/* 184 */               n += pangoGlyphString.widths[b2];
/* 185 */               arrayOfFloat[2 + (i1 << 1)] = n / 1024.0F;
/*     */             } 
/* 187 */             arrayOfInt2[i1] = pangoGlyphString.log_clusters[b2] + m;
/*     */           } 
/* 189 */           if (!bool1) m += pangoGlyphString.num_chars; 
/* 190 */           k += pangoGlyphString.num_glyphs;
/*     */         } 
/*     */       } 
/* 193 */       paramTextRun.shape(j, arrayOfInt1, arrayOfFloat, arrayOfInt2);
/*     */     } 
/*     */     
/* 196 */     check(0L, null, l1, l2, l3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 201 */     super.dispose();
/* 202 */     if (this.str != 0L) {
/* 203 */       OSPango.g_free(this.str);
/* 204 */       this.str = 0L;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\freetype\PangoGlyphLayout.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */