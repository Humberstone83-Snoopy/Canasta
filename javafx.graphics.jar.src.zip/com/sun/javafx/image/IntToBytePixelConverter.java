package com.sun.javafx.image;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public interface IntToBytePixelConverter extends PixelConverter<IntBuffer, ByteBuffer> {
  void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\IntToBytePixelConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */