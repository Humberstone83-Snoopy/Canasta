package com.sun.javafx.scene.text;

public interface TextLayoutFactory {
  TextLayout createLayout();
  
  TextLayout getLayout();
  
  void disposeLayout(TextLayout paramTextLayout);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\text\TextLayoutFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */