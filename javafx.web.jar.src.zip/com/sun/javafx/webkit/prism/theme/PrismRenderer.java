/*    */ package com.sun.javafx.webkit.prism.theme;
/*    */ 
/*    */ import com.sun.javafx.scene.NodeHelper;
/*    */ import com.sun.javafx.scene.SceneHelper;
/*    */ import com.sun.javafx.sg.prism.NGNode;
/*    */ import com.sun.javafx.webkit.theme.Renderer;
/*    */ import com.sun.prism.Graphics;
/*    */ import com.sun.webkit.graphics.WCGraphicsContext;
/*    */ import javafx.scene.control.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrismRenderer
/*    */   extends Renderer
/*    */ {
/*    */   protected void render(Control paramControl, WCGraphicsContext paramWCGraphicsContext) {
/* 41 */     SceneHelper.setAllowPGAccess(true);
/*    */     
/* 43 */     NGNode nGNode = NodeHelper.getPeer(paramControl);
/* 44 */     SceneHelper.setAllowPGAccess(false);
/*    */     
/* 46 */     nGNode.render((Graphics)paramWCGraphicsContext.getPlatformGraphics());
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\theme\PrismRenderer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */