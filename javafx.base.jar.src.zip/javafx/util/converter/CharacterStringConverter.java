/*    */ package javafx.util.converter;
/*    */ 
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharacterStringConverter
/*    */   extends StringConverter<Character>
/*    */ {
/*    */   public Character fromString(String paramString) {
/* 39 */     if (paramString == null) {
/* 40 */       return null;
/*    */     }
/*    */     
/* 43 */     paramString = paramString.trim();
/*    */     
/* 45 */     if (paramString.length() < 1) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     return Character.valueOf(paramString.charAt(0));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString(Character paramCharacter) {
/* 55 */     if (paramCharacter == null) {
/* 56 */       return "";
/*    */     }
/*    */     
/* 59 */     return paramCharacter.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javaf\\util\converter\CharacterStringConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */