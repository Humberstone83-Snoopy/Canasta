/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontFace
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFontFace(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   DWRITE_GLYPH_METRICS GetDesignGlyphMetrics(short paramShort, boolean paramBoolean) {
/* 39 */     return OS.GetDesignGlyphMetrics(this.ptr, paramShort, paramBoolean);
/*    */   }
/*    */   
/*    */   Path2D GetGlyphRunOutline(float paramFloat, short paramShort, boolean paramBoolean) {
/* 43 */     return OS.GetGlyphRunOutline(this.ptr, paramFloat, paramShort, paramBoolean);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\IDWriteFontFace.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */