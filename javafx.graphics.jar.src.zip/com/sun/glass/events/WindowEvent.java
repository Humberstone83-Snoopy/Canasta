/*    */ package com.sun.glass.events;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WindowEvent
/*    */ {
/*    */   public static final int RESIZE = 511;
/*    */   public static final int MOVE = 512;
/*    */   public static final int RESCALE = 513;
/*    */   public static final int CLOSE = 521;
/*    */   public static final int DESTROY = 522;
/*    */   public static final int MINIMIZE = 531;
/*    */   public static final int MAXIMIZE = 532;
/*    */   public static final int RESTORE = 533;
/*    */   public static final int _FOCUS_MIN = 541;
/*    */   public static final int FOCUS_LOST = 541;
/*    */   public static final int FOCUS_GAINED = 542;
/*    */   public static final int FOCUS_GAINED_FORWARD = 543;
/*    */   public static final int FOCUS_GAINED_BACKWARD = 544;
/*    */   public static final int _FOCUS_MAX = 544;
/*    */   public static final int FOCUS_DISABLED = 545;
/*    */   public static final int FOCUS_UNGRAB = 546;
/*    */   
/*    */   public static String getEventName(int paramInt) {
/* 52 */     switch (paramInt) {
/*    */       case 511:
/* 54 */         return "RESIZE";
/*    */       case 512:
/* 56 */         return "MOVE";
/*    */       case 513:
/* 58 */         return "RESCALE";
/*    */       case 521:
/* 60 */         return "CLOSE";
/*    */       case 522:
/* 62 */         return "DESTROY";
/*    */       case 531:
/* 64 */         return "MINIMIZE";
/*    */       case 532:
/* 66 */         return "MAXIMIZE";
/*    */       case 533:
/* 68 */         return "RESTORE";
/*    */       case 541:
/* 70 */         return "FOCUS_LOST";
/*    */       case 542:
/* 72 */         return "FOCUS_GAINED";
/*    */       case 543:
/* 74 */         return "FOCUS_GAINED_FORWARD";
/*    */       case 544:
/* 76 */         return "FOCUS_GAINED_BACKWARD";
/*    */       case 545:
/* 78 */         return "FOCUS_DISABLED";
/*    */       case 546:
/* 80 */         return "FOCUS_UNGRAB";
/*    */     } 
/* 82 */     return "UNKNOWN";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glass\events\WindowEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */