/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLCollection;
/*    */ import org.w3c.dom.html.HTMLMapElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLMapElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLMapElement
/*    */ {
/*    */   HTMLMapElementImpl(long paramLong) {
/* 33 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLMapElement getImpl(long paramLong) {
/* 37 */     return (HTMLMapElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native long getAreasImpl(long paramLong);
/*    */   
/*    */   public HTMLCollection getAreas() {
/* 43 */     return HTMLCollectionImpl.getImpl(getAreasImpl(getPeer()));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 48 */     return getNameImpl(getPeer());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setName(String paramString) {
/* 53 */     setNameImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native String getNameImpl(long paramLong);
/*    */   
/*    */   static native void setNameImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLMapElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */