/*     */ package javafx.beans.property;
/*     */ 
/*     */ import com.sun.javafx.binding.BidirectionalBinding;
/*     */ import com.sun.javafx.binding.Logging;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import javafx.beans.binding.Bindings;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ import javafx.beans.value.WritableBooleanValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BooleanProperty
/*     */   extends ReadOnlyBooleanProperty
/*     */   implements Property<Boolean>, WritableBooleanValue
/*     */ {
/*     */   public void setValue(Boolean paramBoolean) {
/*  77 */     if (paramBoolean == null) {
/*  78 */       Logging.getLogger().fine("Attempt to set boolean property to null, using default value instead.", new NullPointerException());
/*  79 */       set(false);
/*     */     } else {
/*  81 */       set(paramBoolean.booleanValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindBidirectional(Property<Boolean> paramProperty) {
/*  90 */     Bindings.bindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbindBidirectional(Property<Boolean> paramProperty) {
/*  98 */     Bindings.unbindBidirectional(this, paramProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 107 */     Object object = getBean();
/* 108 */     String str = getName();
/* 109 */     StringBuilder stringBuilder = new StringBuilder("BooleanProperty [");
/*     */     
/* 111 */     if (object != null) {
/* 112 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/* 114 */     if (str != null && !str.equals("")) {
/* 115 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/* 117 */     stringBuilder.append("value: ").append(get()).append("]");
/* 118 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BooleanProperty booleanProperty(final Property<Boolean> property) {
/* 140 */     if (property == null) {
/* 141 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/* 143 */     return (property instanceof BooleanProperty) ? (BooleanProperty)property : new BooleanPropertyBase()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 151 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 156 */           return property.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 162 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbind(param1Property, this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 167 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectProperty<Boolean> asObject() {
/* 184 */     return new ObjectPropertyBase<Boolean>()
/*     */       {
/*     */         private final AccessControlContext acc;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 192 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 197 */           return BooleanProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         protected void finalize() throws Throwable {
/*     */           try {
/* 203 */             AccessController.doPrivileged(() -> { BidirectionalBinding.unbind(this, BooleanProperty.this); return null; }this.acc);
/*     */           
/*     */           }
/*     */           finally {
/*     */             
/* 208 */             super.finalize();
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\BooleanProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */