/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Combinator
/*    */ {
/* 30 */   CHILD { public String toString() {
/* 31 */       return ">";
/*    */     } },
/* 33 */   DESCENDANT { public String toString() {
/* 34 */       return " ";
/*    */     } }
/*    */   ;
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\Combinator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */