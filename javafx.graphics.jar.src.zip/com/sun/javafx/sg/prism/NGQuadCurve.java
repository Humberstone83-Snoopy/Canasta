/*    */ package com.sun.javafx.sg.prism;
/*    */ 
/*    */ import com.sun.javafx.geom.QuadCurve2D;
/*    */ import com.sun.javafx.geom.Shape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NGQuadCurve
/*    */   extends NGShape
/*    */ {
/* 35 */   private QuadCurve2D curve = new QuadCurve2D();
/*    */   public final Shape getShape() {
/* 37 */     return this.curve;
/*    */   } public void updateQuadCurve(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 39 */     this.curve.x1 = paramFloat1;
/* 40 */     this.curve.y1 = paramFloat2;
/* 41 */     this.curve.x2 = paramFloat3;
/* 42 */     this.curve.y2 = paramFloat4;
/* 43 */     this.curve.ctrlx = paramFloat5;
/* 44 */     this.curve.ctrly = paramFloat6;
/* 45 */     geometryChanged();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGQuadCurve.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */