/*     */ package com.sun.javafx.scene;
/*     */ 
/*     */ import com.sun.glass.ui.Accessible;
/*     */ import com.sun.javafx.tk.TKScene;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import javafx.scene.Camera;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.stage.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SceneHelper
/*     */ {
/*     */   private static SceneAccessor sceneAccessor;
/*     */   
/*     */   static {
/*  47 */     Utils.forceInit(Scene.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void enableInputMethodEvents(Scene paramScene, boolean paramBoolean) {
/*  54 */     sceneAccessor.enableInputMethodEvents(paramScene, paramBoolean);
/*     */   }
/*     */   
/*     */   public static void processKeyEvent(Scene paramScene, KeyEvent paramKeyEvent) {
/*  58 */     sceneAccessor.processKeyEvent(paramScene, paramKeyEvent);
/*     */   }
/*     */   
/*     */   public static void processMouseEvent(Scene paramScene, MouseEvent paramMouseEvent) {
/*  62 */     sceneAccessor.processMouseEvent(paramScene, paramMouseEvent);
/*     */   }
/*     */   
/*     */   public static void preferredSize(Scene paramScene) {
/*  66 */     sceneAccessor.preferredSize(paramScene);
/*     */   }
/*     */   
/*     */   public static void disposePeer(Scene paramScene) {
/*  70 */     sceneAccessor.disposePeer(paramScene);
/*     */   }
/*     */   
/*     */   public static void initPeer(Scene paramScene) {
/*  74 */     sceneAccessor.initPeer(paramScene);
/*     */   }
/*     */   
/*     */   public static void setWindow(Scene paramScene, Window paramWindow) {
/*  78 */     sceneAccessor.setWindow(paramScene, paramWindow);
/*     */   }
/*     */   
/*     */   public static TKScene getPeer(Scene paramScene) {
/*  82 */     return sceneAccessor.getPeer(paramScene);
/*     */   }
/*     */   
/*     */   public static void setAllowPGAccess(boolean paramBoolean) {
/*  86 */     sceneAccessor.setAllowPGAccess(paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void parentEffectiveOrientationInvalidated(Scene paramScene) {
/*  91 */     sceneAccessor.parentEffectiveOrientationInvalidated(paramScene);
/*     */   }
/*     */   
/*     */   public static Camera getEffectiveCamera(Scene paramScene) {
/*  95 */     return sceneAccessor.getEffectiveCamera(paramScene);
/*     */   }
/*     */   
/*     */   public static Scene createPopupScene(Parent paramParent) {
/*  99 */     return sceneAccessor.createPopupScene(paramParent);
/*     */   }
/*     */   
/*     */   public static Accessible getAccessible(Scene paramScene) {
/* 103 */     return sceneAccessor.getAccessible(paramScene);
/*     */   }
/*     */   
/*     */   public static void setSceneAccessor(SceneAccessor paramSceneAccessor) {
/* 107 */     if (sceneAccessor != null) {
/* 108 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 111 */     sceneAccessor = paramSceneAccessor;
/*     */   }
/*     */   
/*     */   public static SceneAccessor getSceneAccessor() {
/* 115 */     if (sceneAccessor == null) throw new IllegalStateException(); 
/* 116 */     return sceneAccessor;
/*     */   }
/*     */   
/*     */   public static interface SceneAccessor {
/*     */     void enableInputMethodEvents(Scene param1Scene, boolean param1Boolean);
/*     */     
/*     */     void processKeyEvent(Scene param1Scene, KeyEvent param1KeyEvent);
/*     */     
/*     */     void processMouseEvent(Scene param1Scene, MouseEvent param1MouseEvent);
/*     */     
/*     */     void preferredSize(Scene param1Scene);
/*     */     
/*     */     void disposePeer(Scene param1Scene);
/*     */     
/*     */     void initPeer(Scene param1Scene);
/*     */     
/*     */     void setWindow(Scene param1Scene, Window param1Window);
/*     */     
/*     */     TKScene getPeer(Scene param1Scene);
/*     */     
/*     */     void setAllowPGAccess(boolean param1Boolean);
/*     */     
/*     */     void parentEffectiveOrientationInvalidated(Scene param1Scene);
/*     */     
/*     */     Camera getEffectiveCamera(Scene param1Scene);
/*     */     
/*     */     Scene createPopupScene(Parent param1Parent);
/*     */     
/*     */     void setTransientFocusContainer(Scene param1Scene, Node param1Node);
/*     */     
/*     */     Accessible getAccessible(Scene param1Scene);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\SceneHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */