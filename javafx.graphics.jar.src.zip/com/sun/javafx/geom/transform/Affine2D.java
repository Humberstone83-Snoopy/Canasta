/*      */ package com.sun.javafx.geom.transform;
/*      */ 
/*      */ import com.sun.javafx.geom.Point2D;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Affine2D
/*      */   extends AffineBase
/*      */ {
/*      */   private static final long BASE_HASH;
/*      */   
/*      */   private Affine2D(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, int paramInt) {
/*  119 */     this.mxx = paramDouble1;
/*  120 */     this.myx = paramDouble2;
/*  121 */     this.mxy = paramDouble3;
/*  122 */     this.myy = paramDouble4;
/*  123 */     this.mxt = paramDouble5;
/*  124 */     this.myt = paramDouble6;
/*  125 */     this.state = paramInt;
/*  126 */     this.type = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine2D() {
/*  134 */     this.mxx = this.myy = 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine2D(BaseTransform paramBaseTransform) {
/*  146 */     setTransform(paramBaseTransform);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine2D(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  165 */     this.mxx = paramFloat1;
/*  166 */     this.myx = paramFloat2;
/*  167 */     this.mxy = paramFloat3;
/*  168 */     this.myy = paramFloat4;
/*  169 */     this.mxt = paramFloat5;
/*  170 */     this.myt = paramFloat6;
/*  171 */     updateState2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine2D(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  190 */     this.mxx = paramDouble1;
/*  191 */     this.myx = paramDouble2;
/*  192 */     this.mxy = paramDouble3;
/*  193 */     this.myy = paramDouble4;
/*  194 */     this.mxt = paramDouble5;
/*  195 */     this.myt = paramDouble6;
/*  196 */     updateState2D();
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform.Degree getDegree() {
/*  201 */     return BaseTransform.Degree.AFFINE_2D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reset3Delements() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  234 */     translate(paramDouble2, paramDouble3);
/*  235 */     rotate(paramDouble1);
/*  236 */     translate(-paramDouble2, -paramDouble3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double paramDouble1, double paramDouble2) {
/*  257 */     if (paramDouble2 == 0.0D) {
/*  258 */       if (paramDouble1 < 0.0D) {
/*  259 */         rotate180();
/*      */       
/*      */       }
/*      */     }
/*  263 */     else if (paramDouble1 == 0.0D) {
/*  264 */       if (paramDouble2 > 0.0D) {
/*  265 */         rotate90();
/*      */       } else {
/*  267 */         rotate270();
/*      */       } 
/*      */     } else {
/*  270 */       double d1 = Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2);
/*  271 */       double d2 = paramDouble2 / d1;
/*  272 */       double d3 = paramDouble1 / d1;
/*      */       
/*  274 */       double d4 = this.mxx;
/*  275 */       double d5 = this.mxy;
/*  276 */       this.mxx = d3 * d4 + d2 * d5;
/*  277 */       this.mxy = -d2 * d4 + d3 * d5;
/*  278 */       d4 = this.myx;
/*  279 */       d5 = this.myy;
/*  280 */       this.myx = d3 * d4 + d2 * d5;
/*  281 */       this.myy = -d2 * d4 + d3 * d5;
/*  282 */       updateState2D();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rotate(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  311 */     translate(paramDouble3, paramDouble4);
/*  312 */     rotate(paramDouble1, paramDouble2);
/*  313 */     translate(-paramDouble3, -paramDouble4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void quadrantRotate(int paramInt) {
/*  328 */     switch (paramInt & 0x3) {
/*      */ 
/*      */       
/*      */       case 1:
/*  332 */         rotate90();
/*      */         break;
/*      */       case 2:
/*  335 */         rotate180();
/*      */         break;
/*      */       case 3:
/*  338 */         rotate270();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void quadrantRotate(int paramInt, double paramDouble1, double paramDouble2) {
/*  361 */     switch (paramInt & 0x3) {
/*      */       case 0:
/*      */         return;
/*      */       case 1:
/*  365 */         this.mxt += paramDouble1 * (this.mxx - this.mxy) + paramDouble2 * (this.mxy + this.mxx);
/*  366 */         this.myt += paramDouble1 * (this.myx - this.myy) + paramDouble2 * (this.myy + this.myx);
/*  367 */         rotate90();
/*      */         break;
/*      */       case 2:
/*  370 */         this.mxt += paramDouble1 * (this.mxx + this.mxx) + paramDouble2 * (this.mxy + this.mxy);
/*  371 */         this.myt += paramDouble1 * (this.myx + this.myx) + paramDouble2 * (this.myy + this.myy);
/*  372 */         rotate180();
/*      */         break;
/*      */       case 3:
/*  375 */         this.mxt += paramDouble1 * (this.mxx + this.mxy) + paramDouble2 * (this.mxy - this.mxx);
/*  376 */         this.myt += paramDouble1 * (this.myx + this.myy) + paramDouble2 * (this.myy - this.myx);
/*  377 */         rotate270();
/*      */         break;
/*      */     } 
/*  380 */     if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  381 */       this.state &= 0xFFFFFFFE;
/*  382 */       if (this.type != -1) {
/*  383 */         this.type &= 0xFFFFFFFE;
/*      */       }
/*      */     } else {
/*  386 */       this.state |= 0x1;
/*  387 */       this.type |= 0x1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToTranslation(double paramDouble1, double paramDouble2) {
/*  405 */     this.mxx = 1.0D;
/*  406 */     this.myx = 0.0D;
/*  407 */     this.mxy = 0.0D;
/*  408 */     this.myy = 1.0D;
/*  409 */     this.mxt = paramDouble1;
/*  410 */     this.myt = paramDouble2;
/*  411 */     if (paramDouble1 != 0.0D || paramDouble2 != 0.0D) {
/*  412 */       this.state = 1;
/*  413 */       this.type = 1;
/*      */     } else {
/*  415 */       this.state = 0;
/*  416 */       this.type = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToRotation(double paramDouble) {
/*  436 */     double d2, d1 = Math.sin(paramDouble);
/*      */     
/*  438 */     if (d1 == 1.0D || d1 == -1.0D) {
/*  439 */       d2 = 0.0D;
/*  440 */       this.state = 4;
/*  441 */       this.type = 8;
/*      */     } else {
/*  443 */       d2 = Math.cos(paramDouble);
/*  444 */       if (d2 == -1.0D) {
/*  445 */         d1 = 0.0D;
/*  446 */         this.state = 2;
/*  447 */         this.type = 8;
/*  448 */       } else if (d2 == 1.0D) {
/*  449 */         d1 = 0.0D;
/*  450 */         this.state = 0;
/*  451 */         this.type = 0;
/*      */       } else {
/*  453 */         this.state = 6;
/*  454 */         this.type = 16;
/*      */       } 
/*      */     } 
/*  457 */     this.mxx = d2;
/*  458 */     this.myx = d1;
/*  459 */     this.mxy = -d1;
/*  460 */     this.myy = d2;
/*  461 */     this.mxt = 0.0D;
/*  462 */     this.myt = 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToRotation(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  496 */     setToRotation(paramDouble1);
/*  497 */     double d1 = this.myx;
/*  498 */     double d2 = 1.0D - this.mxx;
/*  499 */     this.mxt = paramDouble2 * d2 + paramDouble3 * d1;
/*  500 */     this.myt = paramDouble3 * d2 - paramDouble2 * d1;
/*  501 */     if (this.mxt != 0.0D || this.myt != 0.0D) {
/*  502 */       this.state |= 0x1;
/*  503 */       this.type |= 0x1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToRotation(double paramDouble1, double paramDouble2) {
/*      */     double d1, d2;
/*  526 */     if (paramDouble2 == 0.0D) {
/*  527 */       d1 = 0.0D;
/*  528 */       if (paramDouble1 < 0.0D) {
/*  529 */         d2 = -1.0D;
/*  530 */         this.state = 2;
/*  531 */         this.type = 8;
/*      */       } else {
/*  533 */         d2 = 1.0D;
/*  534 */         this.state = 0;
/*  535 */         this.type = 0;
/*      */       } 
/*  537 */     } else if (paramDouble1 == 0.0D) {
/*  538 */       d2 = 0.0D;
/*  539 */       d1 = (paramDouble2 > 0.0D) ? 1.0D : -1.0D;
/*  540 */       this.state = 4;
/*  541 */       this.type = 8;
/*      */     } else {
/*  543 */       double d = Math.sqrt(paramDouble1 * paramDouble1 + paramDouble2 * paramDouble2);
/*  544 */       d2 = paramDouble1 / d;
/*  545 */       d1 = paramDouble2 / d;
/*  546 */       this.state = 6;
/*  547 */       this.type = 16;
/*      */     } 
/*  549 */     this.mxx = d2;
/*  550 */     this.myx = d1;
/*  551 */     this.mxy = -d1;
/*  552 */     this.myy = d2;
/*  553 */     this.mxt = 0.0D;
/*  554 */     this.myt = 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  581 */     setToRotation(paramDouble1, paramDouble2);
/*  582 */     double d1 = this.myx;
/*  583 */     double d2 = 1.0D - this.mxx;
/*  584 */     this.mxt = paramDouble3 * d2 + paramDouble4 * d1;
/*  585 */     this.myt = paramDouble4 * d2 - paramDouble3 * d1;
/*  586 */     if (this.mxt != 0.0D || this.myt != 0.0D) {
/*  587 */       this.state |= 0x1;
/*  588 */       this.type |= 0x1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToQuadrantRotation(int paramInt) {
/*  604 */     switch (paramInt & 0x3) {
/*      */       case 0:
/*  606 */         this.mxx = 1.0D;
/*  607 */         this.myx = 0.0D;
/*  608 */         this.mxy = 0.0D;
/*  609 */         this.myy = 1.0D;
/*  610 */         this.mxt = 0.0D;
/*  611 */         this.myt = 0.0D;
/*  612 */         this.state = 0;
/*  613 */         this.type = 0;
/*      */         break;
/*      */       case 1:
/*  616 */         this.mxx = 0.0D;
/*  617 */         this.myx = 1.0D;
/*  618 */         this.mxy = -1.0D;
/*  619 */         this.myy = 0.0D;
/*  620 */         this.mxt = 0.0D;
/*  621 */         this.myt = 0.0D;
/*  622 */         this.state = 4;
/*  623 */         this.type = 8;
/*      */         break;
/*      */       case 2:
/*  626 */         this.mxx = -1.0D;
/*  627 */         this.myx = 0.0D;
/*  628 */         this.mxy = 0.0D;
/*  629 */         this.myy = -1.0D;
/*  630 */         this.mxt = 0.0D;
/*  631 */         this.myt = 0.0D;
/*  632 */         this.state = 2;
/*  633 */         this.type = 8;
/*      */         break;
/*      */       case 3:
/*  636 */         this.mxx = 0.0D;
/*  637 */         this.myx = -1.0D;
/*  638 */         this.mxy = 1.0D;
/*  639 */         this.myy = 0.0D;
/*  640 */         this.mxt = 0.0D;
/*  641 */         this.myt = 0.0D;
/*  642 */         this.state = 4;
/*  643 */         this.type = 8;
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToQuadrantRotation(int paramInt, double paramDouble1, double paramDouble2) {
/*  666 */     switch (paramInt & 0x3) {
/*      */       case 0:
/*  668 */         this.mxx = 1.0D;
/*  669 */         this.myx = 0.0D;
/*  670 */         this.mxy = 0.0D;
/*  671 */         this.myy = 1.0D;
/*  672 */         this.mxt = 0.0D;
/*  673 */         this.myt = 0.0D;
/*  674 */         this.state = 0;
/*  675 */         this.type = 0;
/*      */         break;
/*      */       case 1:
/*  678 */         this.mxx = 0.0D;
/*  679 */         this.myx = 1.0D;
/*  680 */         this.mxy = -1.0D;
/*  681 */         this.myy = 0.0D;
/*  682 */         this.mxt = paramDouble1 + paramDouble2;
/*  683 */         this.myt = paramDouble2 - paramDouble1;
/*  684 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  685 */           this.state = 4;
/*  686 */           this.type = 8; break;
/*      */         } 
/*  688 */         this.state = 5;
/*  689 */         this.type = 9;
/*      */         break;
/*      */       
/*      */       case 2:
/*  693 */         this.mxx = -1.0D;
/*  694 */         this.myx = 0.0D;
/*  695 */         this.mxy = 0.0D;
/*  696 */         this.myy = -1.0D;
/*  697 */         this.mxt = paramDouble1 + paramDouble1;
/*  698 */         this.myt = paramDouble2 + paramDouble2;
/*  699 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  700 */           this.state = 2;
/*  701 */           this.type = 8; break;
/*      */         } 
/*  703 */         this.state = 3;
/*  704 */         this.type = 9;
/*      */         break;
/*      */       
/*      */       case 3:
/*  708 */         this.mxx = 0.0D;
/*  709 */         this.myx = -1.0D;
/*  710 */         this.mxy = 1.0D;
/*  711 */         this.myy = 0.0D;
/*  712 */         this.mxt = paramDouble1 - paramDouble2;
/*  713 */         this.myt = paramDouble2 + paramDouble1;
/*  714 */         if (this.mxt == 0.0D && this.myt == 0.0D) {
/*  715 */           this.state = 4;
/*  716 */           this.type = 8; break;
/*      */         } 
/*  718 */         this.state = 5;
/*  719 */         this.type = 9;
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setToScale(double paramDouble1, double paramDouble2) {
/*  739 */     this.mxx = paramDouble1;
/*  740 */     this.myx = 0.0D;
/*  741 */     this.mxy = 0.0D;
/*  742 */     this.myy = paramDouble2;
/*  743 */     this.mxt = 0.0D;
/*  744 */     this.myt = 0.0D;
/*  745 */     if (paramDouble1 != 1.0D || paramDouble2 != 1.0D) {
/*  746 */       this.state = 2;
/*  747 */       this.type = -1;
/*      */     } else {
/*  749 */       this.state = 0;
/*  750 */       this.type = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransform(BaseTransform paramBaseTransform) {
/*  761 */     switch (paramBaseTransform.getDegree()) {
/*      */       case IDENTITY:
/*  763 */         setToIdentity();
/*      */         return;
/*      */       case TRANSLATE_2D:
/*  766 */         setToTranslation(paramBaseTransform.getMxt(), paramBaseTransform.getMyt());
/*      */         return;
/*      */       default:
/*  769 */         if (paramBaseTransform.getType() > 127) {
/*  770 */           System.out.println("" + paramBaseTransform + " is " + paramBaseTransform);
/*  771 */           System.out.print("  " + paramBaseTransform.getMxx());
/*  772 */           System.out.print(", " + paramBaseTransform.getMxy());
/*  773 */           System.out.print(", " + paramBaseTransform.getMxz());
/*  774 */           System.out.print(", " + paramBaseTransform.getMxt());
/*  775 */           System.out.println();
/*  776 */           System.out.print("  " + paramBaseTransform.getMyx());
/*  777 */           System.out.print(", " + paramBaseTransform.getMyy());
/*  778 */           System.out.print(", " + paramBaseTransform.getMyz());
/*  779 */           System.out.print(", " + paramBaseTransform.getMyt());
/*  780 */           System.out.println();
/*  781 */           System.out.print("  " + paramBaseTransform.getMzx());
/*  782 */           System.out.print(", " + paramBaseTransform.getMzy());
/*  783 */           System.out.print(", " + paramBaseTransform.getMzz());
/*  784 */           System.out.print(", " + paramBaseTransform.getMzt());
/*  785 */           System.out.println();
/*      */ 
/*      */           
/*  788 */           degreeError(BaseTransform.Degree.AFFINE_2D);
/*      */         }  break;
/*      */       case AFFINE_2D:
/*      */         break;
/*  792 */     }  this.mxx = paramBaseTransform.getMxx();
/*  793 */     this.myx = paramBaseTransform.getMyx();
/*  794 */     this.mxy = paramBaseTransform.getMxy();
/*  795 */     this.myy = paramBaseTransform.getMyy();
/*  796 */     this.mxt = paramBaseTransform.getMxt();
/*  797 */     this.myt = paramBaseTransform.getMyt();
/*  798 */     if (paramBaseTransform instanceof AffineBase) {
/*  799 */       this.state = ((AffineBase)paramBaseTransform).state;
/*  800 */       this.type = ((AffineBase)paramBaseTransform).type;
/*      */     } else {
/*  802 */       updateState2D();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void preConcatenate(BaseTransform paramBaseTransform) {
/*      */     double d1, d2;
/*  832 */     switch (paramBaseTransform.getDegree()) {
/*      */       case IDENTITY:
/*      */         return;
/*      */       case TRANSLATE_2D:
/*  836 */         translate(paramBaseTransform.getMxt(), paramBaseTransform.getMyt());
/*      */         return;
/*      */       case AFFINE_2D:
/*      */         break;
/*      */       default:
/*  841 */         degreeError(BaseTransform.Degree.AFFINE_2D);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  846 */     int i = this.state;
/*  847 */     Affine2D affine2D = (Affine2D)paramBaseTransform;
/*  848 */     int j = affine2D.state;
/*  849 */     switch (j << 4 | i) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 16:
/*      */       case 18:
/*      */       case 20:
/*      */       case 22:
/*  866 */         this.mxt = affine2D.mxt;
/*  867 */         this.myt = affine2D.myt;
/*  868 */         this.state = i | 0x1;
/*  869 */         this.type |= 0x1;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 17:
/*      */       case 19:
/*      */       case 21:
/*      */       case 23:
/*  877 */         this.mxt += affine2D.mxt;
/*  878 */         this.myt += affine2D.myt;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 32:
/*      */       case 33:
/*  884 */         this.state = i | 0x2;
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*  893 */         d3 = affine2D.mxx;
/*  894 */         d6 = affine2D.myy;
/*  895 */         if ((i & 0x4) != 0) {
/*  896 */           this.mxy *= d3;
/*  897 */           this.myx *= d6;
/*  898 */           if ((i & 0x2) != 0) {
/*  899 */             this.mxx *= d3;
/*  900 */             this.myy *= d6;
/*      */           } 
/*      */         } else {
/*  903 */           this.mxx *= d3;
/*  904 */           this.myy *= d6;
/*      */         } 
/*  906 */         if ((i & 0x1) != 0) {
/*  907 */           this.mxt *= d3;
/*  908 */           this.myt *= d6;
/*      */         } 
/*  910 */         this.type = -1;
/*      */         return;
/*      */       case 68:
/*      */       case 69:
/*  914 */         i |= 0x2;
/*      */       
/*      */       case 64:
/*      */       case 65:
/*      */       case 66:
/*      */       case 67:
/*  920 */         this.state = i ^ 0x4;
/*      */ 
/*      */       
/*      */       case 70:
/*      */       case 71:
/*  925 */         d4 = affine2D.mxy;
/*  926 */         d5 = affine2D.myx;
/*      */         
/*  928 */         d1 = this.mxx;
/*  929 */         this.mxx = this.myx * d4;
/*  930 */         this.myx = d1 * d5;
/*      */         
/*  932 */         d1 = this.mxy;
/*  933 */         this.mxy = this.myy * d4;
/*  934 */         this.myy = d1 * d5;
/*      */         
/*  936 */         d1 = this.mxt;
/*  937 */         this.mxt = this.myt * d4;
/*  938 */         this.myt = d1 * d5;
/*  939 */         this.type = -1;
/*      */         return;
/*      */     } 
/*      */ 
/*      */     
/*  944 */     double d3 = affine2D.mxx, d4 = affine2D.mxy, d7 = affine2D.mxt;
/*  945 */     double d5 = affine2D.myx, d6 = affine2D.myy, d8 = affine2D.myt;
/*  946 */     switch (i) {
/*      */       default:
/*  948 */         stateError();
/*      */       
/*      */       case 7:
/*  951 */         d1 = this.mxt;
/*  952 */         d2 = this.myt;
/*  953 */         d7 += d1 * d3 + d2 * d4;
/*  954 */         d8 += d1 * d5 + d2 * d6;
/*      */ 
/*      */       
/*      */       case 6:
/*  958 */         this.mxt = d7;
/*  959 */         this.myt = d8;
/*      */         
/*  961 */         d1 = this.mxx;
/*  962 */         d2 = this.myx;
/*  963 */         this.mxx = d1 * d3 + d2 * d4;
/*  964 */         this.myx = d1 * d5 + d2 * d6;
/*      */         
/*  966 */         d1 = this.mxy;
/*  967 */         d2 = this.myy;
/*  968 */         this.mxy = d1 * d3 + d2 * d4;
/*  969 */         this.myy = d1 * d5 + d2 * d6;
/*      */         break;
/*      */       
/*      */       case 5:
/*  973 */         d1 = this.mxt;
/*  974 */         d2 = this.myt;
/*  975 */         d7 += d1 * d3 + d2 * d4;
/*  976 */         d8 += d1 * d5 + d2 * d6;
/*      */ 
/*      */       
/*      */       case 4:
/*  980 */         this.mxt = d7;
/*  981 */         this.myt = d8;
/*      */         
/*  983 */         d1 = this.myx;
/*  984 */         this.mxx = d1 * d4;
/*  985 */         this.myx = d1 * d6;
/*      */         
/*  987 */         d1 = this.mxy;
/*  988 */         this.mxy = d1 * d3;
/*  989 */         this.myy = d1 * d5;
/*      */         break;
/*      */       
/*      */       case 3:
/*  993 */         d1 = this.mxt;
/*  994 */         d2 = this.myt;
/*  995 */         d7 += d1 * d3 + d2 * d4;
/*  996 */         d8 += d1 * d5 + d2 * d6;
/*      */ 
/*      */       
/*      */       case 2:
/* 1000 */         this.mxt = d7;
/* 1001 */         this.myt = d8;
/*      */         
/* 1003 */         d1 = this.mxx;
/* 1004 */         this.mxx = d1 * d3;
/* 1005 */         this.myx = d1 * d5;
/*      */         
/* 1007 */         d1 = this.myy;
/* 1008 */         this.mxy = d1 * d4;
/* 1009 */         this.myy = d1 * d6;
/*      */         break;
/*      */       
/*      */       case 1:
/* 1013 */         d1 = this.mxt;
/* 1014 */         d2 = this.myt;
/* 1015 */         d7 += d1 * d3 + d2 * d4;
/* 1016 */         d8 += d1 * d5 + d2 * d6;
/*      */ 
/*      */       
/*      */       case 0:
/* 1020 */         this.mxt = d7;
/* 1021 */         this.myt = d8;
/*      */         
/* 1023 */         this.mxx = d3;
/* 1024 */         this.myx = d5;
/*      */         
/* 1026 */         this.mxy = d4;
/* 1027 */         this.myy = d6;
/*      */         
/* 1029 */         this.state = i | j;
/* 1030 */         this.type = -1;
/*      */         return;
/*      */     } 
/* 1033 */     updateState2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Affine2D createInverse() throws NoninvertibleTransformException {
/*      */     double d;
/* 1061 */     switch (this.state) {
/*      */       default:
/* 1063 */         stateError();
/*      */       
/*      */       case 7:
/* 1066 */         d = this.mxx * this.myy - this.mxy * this.myx;
/* 1067 */         if (d == 0.0D || Math.abs(d) <= Double.MIN_VALUE) {
/* 1068 */           throw new NoninvertibleTransformException("Determinant is " + d);
/*      */         }
/*      */         
/* 1071 */         return new Affine2D(this.myy / d, -this.myx / d, -this.mxy / d, this.mxx / d, (this.mxy * this.myt - this.myy * this.mxt) / d, (this.myx * this.mxt - this.mxx * this.myt) / d, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/* 1079 */         d = this.mxx * this.myy - this.mxy * this.myx;
/* 1080 */         if (d == 0.0D || Math.abs(d) <= Double.MIN_VALUE) {
/* 1081 */           throw new NoninvertibleTransformException("Determinant is " + d);
/*      */         }
/*      */         
/* 1084 */         return new Affine2D(this.myy / d, -this.myx / d, -this.mxy / d, this.mxx / d, 0.0D, 0.0D, 6);
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 1089 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1090 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1092 */         return new Affine2D(0.0D, 1.0D / this.mxy, 1.0D / this.myx, 0.0D, -this.myt / this.myx, -this.mxt / this.mxy, 5);
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 1097 */         if (this.mxy == 0.0D || this.myx == 0.0D) {
/* 1098 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1100 */         return new Affine2D(0.0D, 1.0D / this.mxy, 1.0D / this.myx, 0.0D, 0.0D, 0.0D, 4);
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1105 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1106 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1108 */         return new Affine2D(1.0D / this.mxx, 0.0D, 0.0D, 1.0D / this.myy, -this.mxt / this.mxx, -this.myt / this.myy, 3);
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/* 1113 */         if (this.mxx == 0.0D || this.myy == 0.0D) {
/* 1114 */           throw new NoninvertibleTransformException("Determinant is 0");
/*      */         }
/* 1116 */         return new Affine2D(1.0D / this.mxx, 0.0D, 0.0D, 1.0D / this.myy, 0.0D, 0.0D, 2);
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/* 1121 */         return new Affine2D(1.0D, 0.0D, 0.0D, 1.0D, -this.mxt, -this.myt, 1);
/*      */       
/*      */       case 0:
/*      */         break;
/*      */     } 
/* 1126 */     return new Affine2D();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void transform(Point2D[] paramArrayOfPoint2D1, int paramInt1, Point2D[] paramArrayOfPoint2D2, int paramInt2, int paramInt3) {
/* 1165 */     int i = this.state;
/* 1166 */     while (--paramInt3 >= 0) {
/*      */       
/* 1168 */       Point2D point2D1 = paramArrayOfPoint2D1[paramInt1++];
/* 1169 */       double d1 = point2D1.x;
/* 1170 */       double d2 = point2D1.y;
/* 1171 */       Point2D point2D2 = paramArrayOfPoint2D2[paramInt2++];
/* 1172 */       if (point2D2 == null) {
/* 1173 */         point2D2 = new Point2D();
/* 1174 */         paramArrayOfPoint2D2[paramInt2 - 1] = point2D2;
/*      */       } 
/* 1176 */       switch (i) {
/*      */         default:
/* 1178 */           stateError();
/*      */         
/*      */         case 7:
/* 1181 */           point2D2.setLocation((float)(d1 * this.mxx + d2 * this.mxy + this.mxt), (float)(d1 * this.myx + d2 * this.myy + this.myt));
/*      */           continue;
/*      */         
/*      */         case 6:
/* 1185 */           point2D2.setLocation((float)(d1 * this.mxx + d2 * this.mxy), (float)(d1 * this.myx + d2 * this.myy));
/*      */           continue;
/*      */         
/*      */         case 5:
/* 1189 */           point2D2.setLocation((float)(d2 * this.mxy + this.mxt), (float)(d1 * this.myx + this.myt));
/*      */           continue;
/*      */         
/*      */         case 4:
/* 1193 */           point2D2.setLocation((float)(d2 * this.mxy), (float)(d1 * this.myx));
/*      */           continue;
/*      */         case 3:
/* 1196 */           point2D2.setLocation((float)(d1 * this.mxx + this.mxt), (float)(d2 * this.myy + this.myt));
/*      */           continue;
/*      */         case 2:
/* 1199 */           point2D2.setLocation((float)(d1 * this.mxx), (float)(d2 * this.myy));
/*      */           continue;
/*      */         case 1:
/* 1202 */           point2D2.setLocation((float)(d1 + this.mxt), (float)(d2 + this.myt)); continue;
/*      */         case 0:
/*      */           break;
/* 1205 */       }  point2D2.setLocation((float)d1, (float)d2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Point2D deltaTransform(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 1238 */     if (paramPoint2D2 == null) {
/* 1239 */       paramPoint2D2 = new Point2D();
/*      */     }
/*      */     
/* 1242 */     double d1 = paramPoint2D1.x;
/* 1243 */     double d2 = paramPoint2D1.y;
/* 1244 */     switch (this.state)
/*      */     { default:
/* 1246 */         stateError();
/*      */       
/*      */       case 6:
/*      */       case 7:
/* 1250 */         paramPoint2D2.setLocation((float)(d1 * this.mxx + d2 * this.mxy), (float)(d1 * this.myx + d2 * this.myy));
/* 1251 */         return paramPoint2D2;
/*      */       case 4:
/*      */       case 5:
/* 1254 */         paramPoint2D2.setLocation((float)(d2 * this.mxy), (float)(d1 * this.myx));
/* 1255 */         return paramPoint2D2;
/*      */       case 2:
/*      */       case 3:
/* 1258 */         paramPoint2D2.setLocation((float)(d1 * this.mxx), (float)(d2 * this.myy));
/* 1259 */         return paramPoint2D2;
/*      */       case 0:
/*      */       case 1:
/* 1262 */         break; }  paramPoint2D2.setLocation((float)d1, (float)d2);
/* 1263 */     return paramPoint2D2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double _matround(double paramDouble) {
/* 1272 */     return Math.rint(paramDouble * 1.0E15D) / 1.0E15D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1284 */     return "Affine2D[[" + _matround(this.mxx) + ", " + 
/* 1285 */       _matround(this.mxy) + ", " + 
/* 1286 */       _matround(this.mxt) + "], [" + 
/* 1287 */       _matround(this.myx) + ", " + 
/* 1288 */       _matround(this.myy) + ", " + 
/* 1289 */       _matround(this.myt) + "]]";
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean is2D() {
/* 1294 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 1302 */     setTransform(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 1310 */     if (paramDouble3 != 0.0D || paramDouble7 != 0.0D || paramDouble9 != 0.0D || paramDouble10 != 0.0D || paramDouble11 != 1.0D || paramDouble12 != 0.0D)
/*      */     {
/*      */ 
/*      */       
/* 1314 */       degreeError(BaseTransform.Degree.AFFINE_2D);
/*      */     }
/* 1316 */     setTransform(paramDouble1, paramDouble5, paramDouble2, paramDouble6, paramDouble4, paramDouble8);
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2) {
/* 1321 */     translate(paramDouble1, paramDouble2);
/* 1322 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithTranslation(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 1327 */     if (paramDouble3 == 0.0D) {
/* 1328 */       translate(paramDouble1, paramDouble2);
/* 1329 */       return this;
/*      */     } 
/* 1331 */     Affine3D affine3D = new Affine3D(this);
/* 1332 */     affine3D.translate(paramDouble1, paramDouble2, paramDouble3);
/* 1333 */     return affine3D;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithScale(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 1338 */     if (paramDouble3 == 1.0D) {
/* 1339 */       scale(paramDouble1, paramDouble2);
/* 1340 */       return this;
/*      */     } 
/* 1342 */     Affine3D affine3D = new Affine3D(this);
/* 1343 */     affine3D.scale(paramDouble1, paramDouble2, paramDouble3);
/* 1344 */     return affine3D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithRotation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 1351 */     if (paramDouble1 == 0.0D) {
/* 1352 */       return this;
/*      */     }
/* 1354 */     if (almostZero(paramDouble2) && almostZero(paramDouble3)) {
/* 1355 */       if (paramDouble4 > 0.0D) {
/* 1356 */         rotate(paramDouble1);
/* 1357 */       } else if (paramDouble4 < 0.0D) {
/* 1358 */         rotate(-paramDouble1);
/*      */       } 
/* 1360 */       return this;
/*      */     } 
/* 1362 */     Affine3D affine3D = new Affine3D(this);
/* 1363 */     affine3D.rotate(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/* 1364 */     return affine3D;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithPreTranslation(double paramDouble1, double paramDouble2) {
/* 1369 */     this.mxt += paramDouble1;
/* 1370 */     this.myt += paramDouble2;
/* 1371 */     if (this.mxt != 0.0D || this.myt != 0.0D) {
/* 1372 */       this.state |= 0x1;
/*      */       
/* 1374 */       this.type |= 0x1;
/*      */     } else {
/*      */       
/* 1377 */       this.state &= 0xFFFFFFFE;
/* 1378 */       if (this.type != -1) {
/* 1379 */         this.type &= 0xFFFFFFFE;
/*      */       }
/*      */     } 
/* 1382 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 1391 */     BaseTransform baseTransform = getInstance(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */ 
/*      */     
/* 1394 */     concatenate(baseTransform);
/* 1395 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithConcatenation(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12) {
/* 1403 */     if (paramDouble3 == 0.0D && paramDouble7 == 0.0D && paramDouble9 == 0.0D && paramDouble10 == 0.0D && paramDouble11 == 1.0D && paramDouble12 == 0.0D) {
/*      */ 
/*      */       
/* 1406 */       concatenate(paramDouble1, paramDouble2, paramDouble4, paramDouble5, paramDouble6, paramDouble8);
/*      */ 
/*      */       
/* 1409 */       return this;
/*      */     } 
/*      */     
/* 1412 */     Affine3D affine3D = new Affine3D(this);
/* 1413 */     affine3D.concatenate(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12);
/*      */ 
/*      */     
/* 1416 */     return affine3D;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithConcatenation(BaseTransform paramBaseTransform) {
/* 1421 */     if (paramBaseTransform.is2D()) {
/* 1422 */       concatenate(paramBaseTransform);
/* 1423 */       return this;
/*      */     } 
/* 1425 */     Affine3D affine3D = new Affine3D(this);
/* 1426 */     affine3D.concatenate(paramBaseTransform);
/* 1427 */     return affine3D;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithPreConcatenation(BaseTransform paramBaseTransform) {
/* 1432 */     if (paramBaseTransform.is2D()) {
/* 1433 */       preConcatenate(paramBaseTransform);
/* 1434 */       return this;
/*      */     } 
/* 1436 */     Affine3D affine3D = new Affine3D(this);
/* 1437 */     affine3D.preConcatenate(paramBaseTransform);
/* 1438 */     return affine3D;
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform deriveWithNewTransform(BaseTransform paramBaseTransform) {
/* 1443 */     if (paramBaseTransform.is2D()) {
/* 1444 */       setTransform(paramBaseTransform);
/* 1445 */       return this;
/*      */     } 
/* 1447 */     return getInstance(paramBaseTransform);
/*      */   }
/*      */ 
/*      */   
/*      */   public BaseTransform copy() {
/* 1452 */     return new Affine2D(this);
/*      */   }
/*      */ 
/*      */   
/*      */   static {
/* 1457 */     long l = 0L;
/* 1458 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzz());
/* 1459 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzy());
/* 1460 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMzx());
/* 1461 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMyz());
/* 1462 */     l = l * 31L + Double.doubleToLongBits(IDENTITY_TRANSFORM.getMxz());
/* 1463 */     BASE_HASH = l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1476 */     if (isIdentity()) return 0; 
/* 1477 */     long l = BASE_HASH;
/* 1478 */     l = l * 31L + Double.doubleToLongBits(getMyy());
/* 1479 */     l = l * 31L + Double.doubleToLongBits(getMyx());
/* 1480 */     l = l * 31L + Double.doubleToLongBits(getMxy());
/* 1481 */     l = l * 31L + Double.doubleToLongBits(getMxx());
/* 1482 */     l = l * 31L + Double.doubleToLongBits(0.0D);
/* 1483 */     l = l * 31L + Double.doubleToLongBits(getMyt());
/* 1484 */     l = l * 31L + Double.doubleToLongBits(getMxt());
/* 1485 */     return (int)l ^ (int)(l >> 32L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 1499 */     if (paramObject instanceof BaseTransform) {
/* 1500 */       BaseTransform baseTransform = (BaseTransform)paramObject;
/* 1501 */       return (baseTransform.getType() <= 127 && baseTransform
/* 1502 */         .getMxx() == this.mxx && baseTransform
/* 1503 */         .getMxy() == this.mxy && baseTransform
/* 1504 */         .getMxt() == this.mxt && baseTransform
/* 1505 */         .getMyx() == this.myx && baseTransform
/* 1506 */         .getMyy() == this.myy && baseTransform
/* 1507 */         .getMyt() == this.myt);
/*      */     } 
/* 1509 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\transform\Affine2D.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */