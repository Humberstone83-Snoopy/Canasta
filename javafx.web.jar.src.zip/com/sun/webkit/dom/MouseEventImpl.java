/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.events.EventTarget;
/*     */ import org.w3c.dom.events.MouseEvent;
/*     */ import org.w3c.dom.views.AbstractView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MouseEventImpl
/*     */   extends UIEventImpl
/*     */   implements MouseEvent
/*     */ {
/*     */   MouseEventImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static MouseEvent getImpl(long paramLong) {
/*  39 */     return (MouseEvent)create(paramLong);
/*     */   }
/*     */   
/*     */   static native int getScreenXImpl(long paramLong);
/*     */   
/*     */   public int getScreenX() {
/*  45 */     return getScreenXImpl(getPeer());
/*     */   }
/*     */   static native int getScreenYImpl(long paramLong);
/*     */   
/*     */   public int getScreenY() {
/*  50 */     return getScreenYImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getClientX() {
/*  55 */     return getClientXImpl(getPeer());
/*     */   }
/*     */   static native int getClientXImpl(long paramLong);
/*     */   
/*     */   public int getClientY() {
/*  60 */     return getClientYImpl(getPeer());
/*     */   }
/*     */   static native int getClientYImpl(long paramLong);
/*     */   
/*     */   public boolean getCtrlKey() {
/*  65 */     return getCtrlKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getCtrlKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getShiftKey() {
/*  70 */     return getShiftKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getShiftKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getAltKey() {
/*  75 */     return getAltKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getAltKeyImpl(long paramLong);
/*     */   
/*     */   public boolean getMetaKey() {
/*  80 */     return getMetaKeyImpl(getPeer());
/*     */   }
/*     */   static native boolean getMetaKeyImpl(long paramLong);
/*     */   
/*     */   public short getButton() {
/*  85 */     return getButtonImpl(getPeer());
/*     */   }
/*     */   static native short getButtonImpl(long paramLong);
/*     */   
/*     */   public EventTarget getRelatedTarget() {
/*  90 */     return (EventTarget)NodeImpl.getImpl(getRelatedTargetImpl(getPeer()));
/*     */   }
/*     */   static native long getRelatedTargetImpl(long paramLong);
/*     */   
/*     */   public int getOffsetX() {
/*  95 */     return getOffsetXImpl(getPeer());
/*     */   }
/*     */   static native int getOffsetXImpl(long paramLong);
/*     */   
/*     */   public int getOffsetY() {
/* 100 */     return getOffsetYImpl(getPeer());
/*     */   }
/*     */   static native int getOffsetYImpl(long paramLong);
/*     */   
/*     */   public int getX() {
/* 105 */     return getXImpl(getPeer());
/*     */   }
/*     */   static native int getXImpl(long paramLong);
/*     */   
/*     */   public int getY() {
/* 110 */     return getYImpl(getPeer());
/*     */   }
/*     */   static native int getYImpl(long paramLong);
/*     */   
/*     */   public Node getFromElement() {
/* 115 */     return NodeImpl.getImpl(getFromElementImpl(getPeer()));
/*     */   }
/*     */   static native long getFromElementImpl(long paramLong);
/*     */   
/*     */   public Node getToElement() {
/* 120 */     return NodeImpl.getImpl(getToElementImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static native long getToElementImpl(long paramLong);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initMouseEvent(String paramString, boolean paramBoolean1, boolean paramBoolean2, AbstractView paramAbstractView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, short paramShort, EventTarget paramEventTarget) {
/* 142 */     initMouseEventImpl(getPeer(), paramString, paramBoolean1, paramBoolean2, 
/*     */ 
/*     */ 
/*     */         
/* 146 */         DOMWindowImpl.getPeer(paramAbstractView), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramBoolean3, paramBoolean4, paramBoolean5, paramBoolean6, paramShort, 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 157 */         NodeImpl.getPeer((NodeImpl)paramEventTarget));
/*     */   }
/*     */   
/*     */   static native void initMouseEventImpl(long paramLong1, String paramString, boolean paramBoolean1, boolean paramBoolean2, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, short paramShort, long paramLong3);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\MouseEventImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */