/*      */ package javafx.scene.web;
/*      */ 
/*      */ import com.sun.javafx.application.PlatformImpl;
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.scene.control.skin.FXVK;
/*      */ import com.sun.javafx.scene.traversal.Algorithm;
/*      */ import com.sun.javafx.scene.traversal.Direction;
/*      */ import com.sun.javafx.scene.traversal.ParentTraversalEngine;
/*      */ import com.sun.javafx.scene.traversal.TraversalContext;
/*      */ import com.sun.javafx.scene.web.behavior.HTMLEditorBehavior;
/*      */ import com.sun.javafx.webkit.Accessor;
/*      */ import com.sun.webkit.WebPage;
/*      */ import java.security.AccessController;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ResourceBundle;
/*      */ import javafx.application.ConditionalFeature;
/*      */ import javafx.application.Platform;
/*      */ import javafx.beans.value.ObservableValue;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.StyleableProperty;
/*      */ import javafx.event.ActionEvent;
/*      */ import javafx.geometry.NodeOrientation;
/*      */ import javafx.geometry.Orientation;
/*      */ import javafx.print.PrinterJob;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.control.Button;
/*      */ import javafx.scene.control.ColorPicker;
/*      */ import javafx.scene.control.ComboBox;
/*      */ import javafx.scene.control.ListCell;
/*      */ import javafx.scene.control.ListView;
/*      */ import javafx.scene.control.Separator;
/*      */ import javafx.scene.control.SkinBase;
/*      */ import javafx.scene.control.ToggleButton;
/*      */ import javafx.scene.control.ToggleGroup;
/*      */ import javafx.scene.control.ToolBar;
/*      */ import javafx.scene.control.Tooltip;
/*      */ import javafx.scene.image.Image;
/*      */ import javafx.scene.image.ImageView;
/*      */ import javafx.scene.input.KeyCode;
/*      */ import javafx.scene.input.KeyEvent;
/*      */ import javafx.scene.input.MouseEvent;
/*      */ import javafx.scene.layout.ColumnConstraints;
/*      */ import javafx.scene.layout.GridPane;
/*      */ import javafx.scene.layout.Priority;
/*      */ import javafx.scene.paint.Color;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.util.Callback;
/*      */ import org.w3c.dom.html.HTMLDocument;
/*      */ import org.w3c.dom.html.HTMLElement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HTMLEditorSkin
/*      */   extends SkinBase<HTMLEditor>
/*      */ {
/*      */   private GridPane gridPane;
/*      */   private ToolBar toolbar1;
/*      */   private ToolBar toolbar2;
/*      */   private Button cutButton;
/*      */   private Button copyButton;
/*      */   private Button pasteButton;
/*      */   private Button insertHorizontalRuleButton;
/*      */   private ToggleGroup alignmentToggleGroup;
/*      */   private ToggleButton alignLeftButton;
/*      */   private ToggleButton alignCenterButton;
/*      */   private ToggleButton alignRightButton;
/*      */   private ToggleButton alignJustifyButton;
/*      */   private ToggleButton bulletsButton;
/*      */   private ToggleButton numbersButton;
/*      */   private Button indentButton;
/*      */   private Button outdentButton;
/*      */   private ComboBox<String> formatComboBox;
/*      */   private Map<String, String> formatStyleMap;
/*      */   private Map<String, String> styleFormatMap;
/*      */   private ComboBox<String> fontFamilyComboBox;
/*      */   private ComboBox<String> fontSizeComboBox;
/*      */   private Map<String, String> fontSizeMap;
/*      */   private Map<String, String> sizeFontMap;
/*      */   private ToggleButton boldButton;
/*      */   private ToggleButton italicButton;
/*      */   private ToggleButton underlineButton;
/*      */   private ToggleButton strikethroughButton;
/*      */   private ColorPicker fgColorButton;
/*      */   private ColorPicker bgColorButton;
/*      */   private WebView webView;
/*      */   private WebPage webPage;
/*      */   private ParentTraversalEngine engine;
/*      */   private boolean resetToolbarState = false;
/*  155 */   private String cachedHTMLText = "<html><head></head><body contenteditable=\"true\"></body></html>";
/*      */   
/*      */   private ResourceBundle resources;
/*      */   private boolean enableAtomicityCheck = false;
/*  159 */   private int atomicityCount = 0;
/*      */ 
/*      */   
/*      */   private boolean isFirstRun = true;
/*      */ 
/*      */   
/*      */   private static final int FONT_FAMILY_MENUBUTTON_WIDTH = 150;
/*      */ 
/*      */   
/*      */   private static final int FONT_FAMILY_MENU_WIDTH = 100;
/*      */ 
/*      */   
/*      */   private static final int FONT_SIZE_MENUBUTTON_WIDTH = 80;
/*      */ 
/*      */   
/*  174 */   private static final Color DEFAULT_BG_COLOR = Color.WHITE;
/*  175 */   private static final Color DEFAULT_FG_COLOR = Color.BLACK;
/*      */   
/*      */   private static final String FORMAT_PARAGRAPH = "<p>";
/*      */   
/*      */   private static final String FORMAT_HEADING_1 = "<h1>";
/*      */   
/*      */   private static final String FORMAT_HEADING_2 = "<h2>";
/*      */   
/*      */   private static final String FORMAT_HEADING_3 = "<h3>";
/*      */   private static final String FORMAT_HEADING_4 = "<h4>";
/*      */   private static final String FORMAT_HEADING_5 = "<h5>";
/*      */   private static final String FORMAT_HEADING_6 = "<h6>";
/*      */   private static final String SIZE_XX_SMALL = "1";
/*      */   private static final String SIZE_X_SMALL = "2";
/*      */   private static final String SIZE_SMALL = "3";
/*      */   private static final String SIZE_MEDIUM = "4";
/*      */   private static final String SIZE_LARGE = "5";
/*      */   private static final String SIZE_X_LARGE = "6";
/*      */   private static final String SIZE_XX_LARGE = "7";
/*  194 */   private static final String[][] DEFAULT_FORMAT_MAPPINGS = new String[][] { { "<p>", "", "3" }, { "<h1>", Command.BOLD
/*      */         
/*  196 */         .getCommand(), "6" }, { "<h2>", Command.BOLD
/*  197 */         .getCommand(), "5" }, { "<h3>", Command.BOLD
/*  198 */         .getCommand(), "4" }, { "<h4>", Command.BOLD
/*  199 */         .getCommand(), "3" }, { "<h5>", Command.BOLD
/*  200 */         .getCommand(), "2" }, { "<h6>", Command.BOLD
/*  201 */         .getCommand(), "1" } };
/*      */ 
/*      */   
/*  204 */   private static PseudoClass CONTAINS_FOCUS_PSEUDOCLASS_STATE = PseudoClass.getPseudoClass("contains-focus");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ListChangeListener<Node> itemsListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HTMLEditorSkin(HTMLEditor paramHTMLEditor) {
/*  251 */     super(paramHTMLEditor); this.itemsListener = (paramChange -> { while (paramChange.next()) { if (paramChange.getRemovedSize() > 0)
/*      */             for (Node node : paramChange.getList()) { if (node instanceof WebView)
/*      */                 this.webPage.dispose();  }   } 
/*  254 */       }); HTMLEditorBehavior hTMLEditorBehavior = new HTMLEditorBehavior(paramHTMLEditor);
/*      */ 
/*      */     
/*  257 */     getChildren().clear();
/*      */     
/*  259 */     this.gridPane = new GridPane();
/*  260 */     this.gridPane.getStyleClass().add("grid");
/*  261 */     getChildren().addAll(new Node[] { this.gridPane });
/*      */     
/*  263 */     this.toolbar1 = new ToolBar();
/*  264 */     this.toolbar1.getStyleClass().add("top-toolbar");
/*  265 */     this.gridPane.add(this.toolbar1, 0, 0);
/*      */     
/*  267 */     this.toolbar2 = new ToolBar();
/*  268 */     this.toolbar2.getStyleClass().add("bottom-toolbar");
/*  269 */     this.gridPane.add(this.toolbar2, 0, 1);
/*      */ 
/*      */ 
/*      */     
/*  273 */     this.webView = new WebView();
/*  274 */     this.gridPane.add(this.webView, 0, 2);
/*      */     
/*  276 */     ColumnConstraints columnConstraints = new ColumnConstraints();
/*  277 */     columnConstraints.setHgrow(Priority.ALWAYS);
/*  278 */     this.gridPane.getColumnConstraints().add(columnConstraints);
/*      */     
/*  280 */     this.webPage = Accessor.getPageFor(this.webView.getEngine());
/*      */     
/*  282 */     this.webView.addEventHandler(MouseEvent.MOUSE_RELEASED, paramMouseEvent -> Platform.runLater(new Runnable()
/*      */           {
/*      */             public void run() {
/*  285 */               HTMLEditorSkin.this.enableAtomicityCheck = true;
/*  286 */               HTMLEditorSkin.this.updateToolbarState(true);
/*  287 */               HTMLEditorSkin.this.enableAtomicityCheck = false;
/*      */             }
/*      */           }));
/*      */ 
/*      */ 
/*      */     
/*  293 */     this.webView.addEventHandler(KeyEvent.KEY_PRESSED, paramKeyEvent -> {
/*      */           applyTextFormatting();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           if (paramKeyEvent.getCode() == KeyCode.CONTROL || paramKeyEvent.getCode() == KeyCode.META) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           if (paramKeyEvent.getCode() == KeyCode.TAB && !paramKeyEvent.isControlDown()) {
/*      */             if (!paramKeyEvent.isShiftDown()) {
/*      */               if (getCommandState(Command.BULLETS.getCommand()) || getCommandState(Command.NUMBERS.getCommand())) {
/*      */                 executeCommand(Command.INDENT.getCommand(), (String)null);
/*      */               } else {
/*      */                 executeCommand(Command.INSERT_TAB.getCommand(), (String)null);
/*      */               } 
/*      */             } else if (getCommandState(Command.BULLETS.getCommand()) || getCommandState(Command.NUMBERS.getCommand())) {
/*      */               executeCommand(Command.OUTDENT.getCommand(), (String)null);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           if ((this.fgColorButton != null && this.fgColorButton.isShowing()) || (this.bgColorButton != null && this.bgColorButton.isShowing())) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           Platform.runLater(());
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  364 */     this.webView.addEventHandler(KeyEvent.KEY_RELEASED, paramKeyEvent -> {
/*      */           if (paramKeyEvent.getCode() == KeyCode.CONTROL || paramKeyEvent.getCode() == KeyCode.META) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           if ((this.fgColorButton != null && this.fgColorButton.isShowing()) || (this.bgColorButton != null && this.bgColorButton.isShowing())) {
/*      */             return;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           Platform.runLater(());
/*      */         });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  399 */     getSkinnable().focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> Platform.runLater(new Runnable()
/*      */           {
/*      */             public void run() {
/*  402 */               if (newValue.booleanValue()) {
/*  403 */                 HTMLEditorSkin.this.webView.requestFocus();
/*      */               }
/*      */             }
/*      */           }));
/*      */ 
/*      */     
/*  409 */     this.webView.focusedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */           pseudoClassStateChanged(CONTAINS_FOCUS_PSEUDOCLASS_STATE, paramBoolean2.booleanValue());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           Platform.runLater(new Runnable()
/*      */               {
/*      */                 public void run()
/*      */                 {
/*  423 */                   HTMLEditorSkin.this.updateToolbarState(true);
/*      */                   
/*  425 */                   if (PlatformImpl.isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)) {
/*  426 */                     Scene scene = HTMLEditorSkin.this.getSkinnable().getScene();
/*  427 */                     if (newValue.booleanValue()) {
/*  428 */                       FXVK.attach(HTMLEditorSkin.this.webView);
/*  429 */                     } else if (scene == null || scene
/*  430 */                       .getWindow() == null || 
/*  431 */                       !scene.getWindow().isFocused() || 
/*  432 */                       !(scene.getFocusOwner() instanceof javafx.scene.control.TextInputControl)) {
/*      */                       
/*  434 */                       FXVK.detach();
/*      */                     } 
/*      */                   } 
/*      */                 }
/*      */               });
/*      */         });
/*      */     
/*  441 */     this.webView.getEngine().getLoadWorker().workDoneProperty().addListener((paramObservableValue, paramNumber1, paramNumber2) -> {
/*      */           Platform.runLater(());
/*      */ 
/*      */ 
/*      */           
/*      */           double d = this.webView.getEngine().getLoadWorker().getTotalWork();
/*      */ 
/*      */           
/*      */           if (paramNumber2.doubleValue() == d) {
/*      */             this.cachedHTMLText = null;
/*      */ 
/*      */             
/*      */             Platform.runLater(());
/*      */           } 
/*      */         });
/*      */ 
/*      */     
/*  458 */     enableToolbar(true);
/*  459 */     setHTMLText(this.cachedHTMLText);
/*      */     
/*  461 */     this.engine = new ParentTraversalEngine(getSkinnable(), new Algorithm()
/*      */         {
/*      */           public Node select(Node param1Node, Direction param1Direction, TraversalContext param1TraversalContext) {
/*  464 */             return HTMLEditorSkin.this.cutButton;
/*      */           }
/*      */ 
/*      */           
/*      */           public Node selectFirst(TraversalContext param1TraversalContext) {
/*  469 */             return HTMLEditorSkin.this.cutButton;
/*      */           }
/*      */ 
/*      */           
/*      */           public Node selectLast(TraversalContext param1TraversalContext) {
/*  474 */             return HTMLEditorSkin.this.cutButton;
/*      */           }
/*      */         });
/*  477 */     ParentHelper.setTraversalEngine(getSkinnable(), this.engine);
/*  478 */     this.webView.setFocusTraversable(true);
/*  479 */     this.gridPane.getChildren().addListener(this.itemsListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void performCommand(Command paramCommand) {
/*  502 */     switch (paramCommand) { case BOLD:
/*  503 */         this.boldButton.fire(); break;
/*  504 */       case ITALIC: this.italicButton.setSelected(!this.italicButton.isSelected()); break;
/*  505 */       case UNDERLINE: this.underlineButton.setSelected(!this.underlineButton.isSelected());
/*      */         break; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void layoutChildren(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  513 */     if (this.isFirstRun) {
/*  514 */       populateToolbars();
/*  515 */       this.isFirstRun = false;
/*      */     } 
/*  517 */     super.layoutChildren(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*  518 */     double d = Math.max(this.toolbar1.prefWidth(-1.0D), this.toolbar2.prefWidth(-1.0D));
/*  519 */     this.toolbar1.setMinWidth(d);
/*  520 */     this.toolbar1.setPrefWidth(d);
/*  521 */     this.toolbar2.setMinWidth(d);
/*  522 */     this.toolbar2.setPrefWidth(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final String getHTMLText() {
/*  536 */     return (this.cachedHTMLText != null) ? this.cachedHTMLText : this.webPage.getHtml(this.webPage.getMainFrame());
/*      */   }
/*      */   
/*      */   final void setHTMLText(String paramString) {
/*  540 */     this.cachedHTMLText = paramString;
/*  541 */     this.webPage.load(this.webPage.getMainFrame(), paramString, "text/html");
/*      */     
/*  543 */     Platform.runLater(() -> updateToolbarState(true));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void populateToolbars() {
/*  549 */     this.resources = ResourceBundle.getBundle(HTMLEditorSkin.class.getName());
/*      */ 
/*      */     
/*  552 */     this.cutButton = addButton(this.toolbar1, this.resources.getString("cutIcon"), this.resources.getString("cut"), Command.CUT.getCommand(), "html-editor-cut");
/*  553 */     this.copyButton = addButton(this.toolbar1, this.resources.getString("copyIcon"), this.resources.getString("copy"), Command.COPY.getCommand(), "html-editor-copy");
/*  554 */     this.pasteButton = addButton(this.toolbar1, this.resources.getString("pasteIcon"), this.resources.getString("paste"), Command.PASTE.getCommand(), "html-editor-paste");
/*      */     
/*  556 */     this.toolbar1.getItems().add(new Separator(Orientation.VERTICAL));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     this.alignmentToggleGroup = new ToggleGroup();
/*  563 */     this.alignLeftButton = addToggleButton(this.toolbar1, this.alignmentToggleGroup, this.resources
/*  564 */         .getString("alignLeftIcon"), this.resources.getString("alignLeft"), Command.ALIGN_LEFT.getCommand(), "html-editor-align-left");
/*  565 */     this.alignCenterButton = addToggleButton(this.toolbar1, this.alignmentToggleGroup, this.resources
/*  566 */         .getString("alignCenterIcon"), this.resources.getString("alignCenter"), Command.ALIGN_CENTER.getCommand(), "html-editor-align-center");
/*  567 */     this.alignRightButton = addToggleButton(this.toolbar1, this.alignmentToggleGroup, this.resources
/*  568 */         .getString("alignRightIcon"), this.resources.getString("alignRight"), Command.ALIGN_RIGHT.getCommand(), "html-editor-align-right");
/*  569 */     this.alignJustifyButton = addToggleButton(this.toolbar1, this.alignmentToggleGroup, this.resources
/*  570 */         .getString("alignJustifyIcon"), this.resources.getString("alignJustify"), Command.ALIGN_JUSTIFY.getCommand(), "html-editor-align-justify");
/*      */     
/*  572 */     this.toolbar1.getItems().add(new Separator(Orientation.VERTICAL));
/*      */     
/*  574 */     this.outdentButton = addButton(this.toolbar1, this.resources.getString("outdentIcon"), this.resources.getString("outdent"), Command.OUTDENT.getCommand(), "html-editor-outdent");
/*  575 */     if (this.outdentButton.getGraphic() != null) this.outdentButton.getGraphic().setNodeOrientation(NodeOrientation.INHERIT); 
/*  576 */     this.indentButton = addButton(this.toolbar1, this.resources.getString("indentIcon"), this.resources.getString("indent"), Command.INDENT.getCommand(), "html-editor-indent");
/*  577 */     if (this.indentButton.getGraphic() != null) this.indentButton.getGraphic().setNodeOrientation(NodeOrientation.INHERIT);
/*      */     
/*  579 */     this.toolbar1.getItems().add(new Separator(Orientation.VERTICAL));
/*      */     
/*  581 */     ToggleGroup toggleGroup = new ToggleGroup();
/*  582 */     this.bulletsButton = addToggleButton(this.toolbar1, toggleGroup, this.resources
/*  583 */         .getString("bulletsIcon"), this.resources.getString("bullets"), Command.BULLETS.getCommand(), "html-editor-bullets");
/*  584 */     if (this.bulletsButton.getGraphic() != null) this.bulletsButton.getGraphic().setNodeOrientation(NodeOrientation.INHERIT); 
/*  585 */     this.numbersButton = addToggleButton(this.toolbar1, toggleGroup, this.resources
/*  586 */         .getString("numbersIcon"), this.resources.getString("numbers"), Command.NUMBERS.getCommand(), "html-editor-numbers");
/*      */     
/*  588 */     this.toolbar1.getItems().add(new Separator(Orientation.VERTICAL));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  593 */     this.formatComboBox = new ComboBox<>();
/*  594 */     this.formatComboBox.getStyleClass().add("font-menu-button");
/*  595 */     this.formatComboBox.setFocusTraversable(false);
/*  596 */     this.formatComboBox.setMinWidth(Double.NEGATIVE_INFINITY);
/*  597 */     this.toolbar2.getItems().add(this.formatComboBox);
/*      */     
/*  599 */     this.formatStyleMap = new HashMap<>();
/*  600 */     this.styleFormatMap = new HashMap<>();
/*      */     
/*  602 */     createFormatMenuItem("<p>", this.resources.getString("paragraph"));
/*  603 */     Platform.runLater(() -> this.formatComboBox.setValue(this.resources.getString("paragraph")));
/*      */ 
/*      */     
/*  606 */     createFormatMenuItem("<h1>", this.resources.getString("heading1"));
/*  607 */     createFormatMenuItem("<h2>", this.resources.getString("heading2"));
/*  608 */     createFormatMenuItem("<h3>", this.resources.getString("heading3"));
/*  609 */     createFormatMenuItem("<h4>", this.resources.getString("heading4"));
/*  610 */     createFormatMenuItem("<h5>", this.resources.getString("heading5"));
/*  611 */     createFormatMenuItem("<h6>", this.resources.getString("heading6"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  627 */     this.formatComboBox.setTooltip(new Tooltip(this.resources.getString("format")));
/*      */     
/*  629 */     this.formatComboBox.valueProperty().addListener((paramObservableValue, paramString1, paramString2) -> {
/*      */           if (paramString2 == null) {
/*      */             this.formatComboBox.setValue((String)null);
/*      */           } else {
/*      */             String str = this.formatStyleMap.get(paramString2);
/*      */             
/*      */             executeCommand(Command.FORMAT.getCommand(), str);
/*      */             
/*      */             updateToolbarState(false);
/*      */             
/*      */             for (byte b = 0; b < DEFAULT_FORMAT_MAPPINGS.length; b++) {
/*      */               String[] arrayOfString = DEFAULT_FORMAT_MAPPINGS[b];
/*      */               if (arrayOfString[0].equalsIgnoreCase(str)) {
/*      */                 executeCommand(Command.FONT_SIZE.getCommand(), arrayOfString[2]);
/*      */                 updateToolbarState(false);
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         });
/*  649 */     this.fontFamilyComboBox = new ComboBox<>();
/*  650 */     this.fontFamilyComboBox.getStyleClass().add("font-menu-button");
/*  651 */     this.fontFamilyComboBox.setMinWidth(150.0D);
/*  652 */     this.fontFamilyComboBox.setPrefWidth(150.0D);
/*  653 */     this.fontFamilyComboBox.setMaxWidth(150.0D);
/*  654 */     this.fontFamilyComboBox.setFocusTraversable(false);
/*  655 */     this.fontFamilyComboBox.setTooltip(new Tooltip(this.resources.getString("fontFamily")));
/*  656 */     this.toolbar2.getItems().add(this.fontFamilyComboBox);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  662 */     this.fontFamilyComboBox.getProperties().put("comboBoxRowsToMeasureWidth", Integer.valueOf(0));
/*      */     
/*  664 */     this.fontFamilyComboBox.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
/*      */           public ListCell<String> call(ListView<String> param1ListView) {
/*  666 */             ListCell<String> listCell = new ListCell<String>() {
/*      */                 public void updateItem(String param2String, boolean param2Boolean) {
/*  668 */                   super.updateItem(param2String, param2Boolean);
/*  669 */                   if (param2String != null) {
/*  670 */                     setText(param2String);
/*  671 */                     setFont(new Font(param2String, 12.0D));
/*      */                   } 
/*      */                 }
/*      */               };
/*  675 */             listCell.setMinWidth(100.0D);
/*  676 */             listCell.setPrefWidth(100.0D);
/*  677 */             listCell.setMaxWidth(100.0D);
/*  678 */             return listCell;
/*      */           }
/*      */         });
/*      */     
/*  682 */     Platform.runLater(() -> {
/*      */           ObservableList<String> observableList = FXCollections.observableArrayList(Font.getFamilies());
/*      */           
/*      */           observableList.add(0, "");
/*      */           for (String str : observableList) {
/*      */             this.fontFamilyComboBox.setValue("");
/*      */             this.fontFamilyComboBox.setItems(observableList);
/*      */           } 
/*      */         });
/*  691 */     this.fontFamilyComboBox.valueProperty().addListener((paramObservableValue, paramString1, paramString2) -> executeCommand(Command.FONT_FAMILY.getCommand(), "".equals(paramString2) ? "''" : paramString2));
/*      */ 
/*      */ 
/*      */     
/*  695 */     this.fontSizeComboBox = new ComboBox<>();
/*  696 */     this.fontSizeComboBox.getStyleClass().add("font-menu-button");
/*  697 */     this.fontSizeComboBox.setFocusTraversable(false);
/*  698 */     this.toolbar2.getItems().add(this.fontSizeComboBox);
/*      */     
/*  700 */     this.fontSizeMap = new HashMap<>();
/*  701 */     this.sizeFontMap = new HashMap<>();
/*      */     
/*  703 */     createFontSizeMenuItem("1", this.resources.getString("extraExtraSmall"));
/*  704 */     createFontSizeMenuItem("2", this.resources.getString("extraSmall"));
/*  705 */     createFontSizeMenuItem("3", this.resources.getString("small"));
/*  706 */     Platform.runLater(() -> this.fontSizeComboBox.setValue(this.resources.getString("small")));
/*      */ 
/*      */     
/*  709 */     createFontSizeMenuItem("4", this.resources.getString("medium"));
/*  710 */     createFontSizeMenuItem("5", this.resources.getString("large"));
/*  711 */     createFontSizeMenuItem("6", this.resources.getString("extraLarge"));
/*  712 */     createFontSizeMenuItem("7", this.resources.getString("extraExtraLarge"));
/*  713 */     this.fontSizeComboBox.setTooltip(new Tooltip(this.resources.getString("fontSize")));
/*      */     
/*  715 */     this.fontSizeComboBox.setCellFactory(new Callback<ListView<String>, ListCell<String>>() {
/*      */           public ListCell<String> call(ListView<String> param1ListView) {
/*  717 */             return new ListCell<String>() {
/*      */                 public void updateItem(String param2String, boolean param2Boolean) {
/*  719 */                   super.updateItem(param2String, param2Boolean);
/*  720 */                   if (param2String != null) {
/*  721 */                     setText(param2String);
/*      */                     
/*  723 */                     String str = param2String.replaceFirst("[^0-9.].*$", "");
/*  724 */                     setFont(new Font(HTMLEditorSkin.this.fontFamilyComboBox.getValue(), Double.valueOf(str).doubleValue()));
/*      */                   } 
/*      */                 }
/*      */               };
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  733 */     this.fontSizeComboBox.valueProperty().addListener((paramObservableValue, paramString1, paramString2) -> {
/*      */           String str = getCommandValue(Command.FONT_SIZE.getCommand());
/*      */           
/*      */           if (!paramString2.equals(str)) {
/*      */             executeCommand(Command.FONT_SIZE.getCommand(), this.fontSizeMap.get(paramString2));
/*      */           }
/*      */         });
/*  740 */     this.toolbar2.getItems().add(new Separator(Orientation.VERTICAL));
/*      */     
/*  742 */     this.boldButton = addToggleButton(this.toolbar2, (ToggleGroup)null, this.resources
/*  743 */         .getString("boldIcon"), this.resources.getString("bold"), Command.BOLD.getCommand(), "html-editor-bold");
/*  744 */     this.boldButton.setOnAction(paramActionEvent -> {
/*      */           if ("<p>".equals(this.formatStyleMap.get(this.formatComboBox.getValue()))) {
/*      */             executeCommand(Command.BOLD.getCommand(), this.boldButton.selectedProperty().getValue().toString());
/*      */           }
/*      */         });
/*      */ 
/*      */ 
/*      */     
/*  752 */     this.italicButton = addToggleButton(this.toolbar2, (ToggleGroup)null, this.resources
/*  753 */         .getString("italicIcon"), this.resources.getString("italic"), Command.ITALIC.getCommand(), "html-editor-italic");
/*  754 */     this.underlineButton = addToggleButton(this.toolbar2, (ToggleGroup)null, this.resources
/*  755 */         .getString("underlineIcon"), this.resources.getString("underline"), Command.UNDERLINE.getCommand(), "html-editor-underline");
/*  756 */     this.strikethroughButton = addToggleButton(this.toolbar2, (ToggleGroup)null, this.resources
/*  757 */         .getString("strikethroughIcon"), this.resources.getString("strikethrough"), Command.STRIKETHROUGH.getCommand(), "html-editor-strike");
/*      */     
/*  759 */     this.toolbar2.getItems().add(new Separator(Orientation.VERTICAL));
/*      */     
/*  761 */     this.insertHorizontalRuleButton = addButton(this.toolbar2, this.resources.getString("insertHorizontalRuleIcon"), this.resources
/*  762 */         .getString("insertHorizontalRule"), Command.INSERT_HORIZONTAL_RULE.getCommand(), "html-editor-hr");
/*      */     
/*  764 */     this.insertHorizontalRuleButton.setOnAction(paramActionEvent -> {
/*      */           executeCommand(Command.INSERT_NEW_LINE.getCommand(), (String)null);
/*      */           
/*      */           executeCommand(Command.INSERT_HORIZONTAL_RULE.getCommand(), (String)null);
/*      */           updateToolbarState(false);
/*      */         });
/*  770 */     this.fgColorButton = new ColorPicker();
/*  771 */     this.fgColorButton.getStyleClass().add("html-editor-foreground");
/*  772 */     this.fgColorButton.setFocusTraversable(false);
/*  773 */     this.toolbar1.getItems().add(this.fgColorButton);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  781 */     this.fgColorButton.setValue(DEFAULT_FG_COLOR);
/*  782 */     this.fgColorButton.setTooltip(new Tooltip(this.resources.getString("foregroundColor")));
/*  783 */     this.fgColorButton.setOnAction(paramActionEvent -> {
/*      */           Color color = this.fgColorButton.getValue();
/*      */           
/*      */           if (color != null) {
/*      */             executeCommand(Command.FOREGROUND_COLOR.getCommand(), colorValueToRGBA(color));
/*      */             this.fgColorButton.hide();
/*      */           } 
/*      */         });
/*  791 */     this.bgColorButton = new ColorPicker();
/*  792 */     this.bgColorButton.getStyleClass().add("html-editor-background");
/*  793 */     this.bgColorButton.setFocusTraversable(false);
/*  794 */     this.toolbar1.getItems().add(this.bgColorButton);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  802 */     this.bgColorButton.setValue(DEFAULT_BG_COLOR);
/*  803 */     this.bgColorButton.setTooltip(new Tooltip(this.resources.getString("backgroundColor")));
/*      */     
/*  805 */     this.bgColorButton.setOnAction(paramActionEvent -> {
/*      */           Color color = this.bgColorButton.getValue();
/*      */           if (color != null) {
/*      */             executeCommand(Command.BACKGROUND_COLOR.getCommand(), colorValueToRGBA(color));
/*      */             this.bgColorButton.hide();
/*      */           } 
/*      */         });
/*      */   }
/*      */   
/*      */   private String colorValueToRGBA(Color paramColor) {
/*  815 */     return String.format((Locale)null, "rgba(%d, %d, %d, %.5f)", new Object[] {
/*  816 */           Long.valueOf(Math.round(paramColor.getRed() * 255.0D)), 
/*  817 */           Long.valueOf(Math.round(paramColor.getGreen() * 255.0D)), 
/*  818 */           Long.valueOf(Math.round(paramColor.getBlue() * 255.0D)), 
/*  819 */           Double.valueOf(paramColor.getOpacity())
/*      */         });
/*      */   }
/*      */   
/*      */   private Button addButton(ToolBar paramToolBar, String paramString1, String paramString2, String paramString3, String paramString4) {
/*  824 */     Button button = new Button();
/*  825 */     button.setFocusTraversable(false);
/*  826 */     button.getStyleClass().add(paramString4);
/*  827 */     paramToolBar.getItems().add(button);
/*      */     
/*  829 */     Image image = AccessController.<Image>doPrivileged(() -> new Image(HTMLEditorSkin.class.getResource(paramString).toString()));
/*      */     
/*  831 */     ((StyleableProperty)button.graphicProperty()).applyStyle(null, new ImageView(image));
/*  832 */     button.setTooltip(new Tooltip(paramString2));
/*      */     
/*  834 */     button.setOnAction(paramActionEvent -> {
/*      */           executeCommand(paramString, (String)null);
/*      */           
/*      */           updateToolbarState(false);
/*      */         });
/*  839 */     return button;
/*      */   }
/*      */ 
/*      */   
/*      */   private ToggleButton addToggleButton(ToolBar paramToolBar, ToggleGroup paramToggleGroup, String paramString1, String paramString2, String paramString3, String paramString4) {
/*  844 */     ToggleButton toggleButton = new ToggleButton();
/*  845 */     toggleButton.setUserData(paramString3);
/*  846 */     toggleButton.setFocusTraversable(false);
/*  847 */     toggleButton.getStyleClass().add(paramString4);
/*  848 */     paramToolBar.getItems().add(toggleButton);
/*  849 */     if (paramToggleGroup != null) {
/*  850 */       toggleButton.setToggleGroup(paramToggleGroup);
/*      */     }
/*      */     
/*  853 */     Image image = AccessController.<Image>doPrivileged(() -> new Image(HTMLEditorSkin.class.getResource(paramString).toString()));
/*  854 */     ((StyleableProperty)toggleButton.graphicProperty()).applyStyle(null, new ImageView(image));
/*      */ 
/*      */     
/*  857 */     toggleButton.setTooltip(new Tooltip(paramString2));
/*      */     
/*  859 */     if (!Command.BOLD.getCommand().equals(paramString3)) {
/*  860 */       toggleButton.selectedProperty().addListener((paramObservableValue, paramBoolean1, paramBoolean2) -> {
/*      */             if (getCommandState(paramString) != paramBoolean2.booleanValue()) {
/*      */               executeCommand(paramString, (String)null);
/*      */             }
/*      */           });
/*      */     }
/*  866 */     return toggleButton;
/*      */   }
/*      */   
/*      */   private void createFormatMenuItem(String paramString1, String paramString2) {
/*  870 */     this.formatComboBox.getItems().add(paramString2);
/*  871 */     this.formatStyleMap.put(paramString2, paramString1);
/*  872 */     this.styleFormatMap.put(paramString1, paramString2);
/*      */   }
/*      */   
/*      */   private void createFontSizeMenuItem(String paramString1, String paramString2) {
/*  876 */     this.fontSizeComboBox.getItems().add(paramString2);
/*  877 */     this.fontSizeMap.put(paramString2, paramString1);
/*  878 */     this.sizeFontMap.put(paramString1, paramString2);
/*      */   }
/*      */   
/*      */   private void updateNodeOrientation() {
/*  882 */     NodeOrientation nodeOrientation = getSkinnable().getEffectiveNodeOrientation();
/*      */     
/*  884 */     HTMLDocument hTMLDocument = (HTMLDocument)this.webPage.getDocument(this.webPage.getMainFrame());
/*  885 */     HTMLElement hTMLElement = (HTMLElement)hTMLDocument.getDocumentElement();
/*  886 */     if (hTMLElement.getAttribute("dir") == null) {
/*  887 */       hTMLElement.setAttribute("dir", (nodeOrientation == NodeOrientation.RIGHT_TO_LEFT) ? "rtl" : "ltr");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateToolbarState(boolean paramBoolean) {
/*  893 */     if (!this.webView.isFocused()) {
/*      */       return;
/*      */     }
/*      */     
/*  897 */     this.atomicityCount++;
/*      */ 
/*      */     
/*  900 */     this.copyButton.setDisable(!isCommandEnabled(Command.CUT.getCommand()));
/*  901 */     this.cutButton.setDisable(!isCommandEnabled(Command.COPY.getCommand()));
/*  902 */     this.pasteButton.setDisable(!isCommandEnabled(Command.PASTE.getCommand()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  910 */     this.insertHorizontalRuleButton.setDisable(!isCommandEnabled(Command.INSERT_HORIZONTAL_RULE.getCommand()));
/*      */     
/*  912 */     if (paramBoolean) {
/*  913 */       this.alignLeftButton.setDisable(!isCommandEnabled(Command.ALIGN_LEFT.getCommand()));
/*  914 */       this.alignLeftButton.setSelected(getCommandState(Command.ALIGN_LEFT.getCommand()));
/*  915 */       this.alignCenterButton.setDisable(!isCommandEnabled(Command.ALIGN_CENTER.getCommand()));
/*  916 */       this.alignCenterButton.setSelected(getCommandState(Command.ALIGN_CENTER.getCommand()));
/*  917 */       this.alignRightButton.setDisable(!isCommandEnabled(Command.ALIGN_RIGHT.getCommand()));
/*  918 */       this.alignRightButton.setSelected(getCommandState(Command.ALIGN_RIGHT.getCommand()));
/*  919 */       this.alignJustifyButton.setDisable(!isCommandEnabled(Command.ALIGN_JUSTIFY.getCommand()));
/*  920 */       this.alignJustifyButton.setSelected(getCommandState(Command.ALIGN_JUSTIFY.getCommand()));
/*      */     }
/*  922 */     else if (this.alignmentToggleGroup.getSelectedToggle() != null) {
/*  923 */       String str = this.alignmentToggleGroup.getSelectedToggle().getUserData().toString();
/*  924 */       if (isCommandEnabled(str) && !getCommandState(str)) {
/*  925 */         executeCommand(str, (String)null);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  930 */     if (this.alignmentToggleGroup.getSelectedToggle() == null && this.webPage
/*  931 */       .getClientSelectedText().isEmpty()) {
/*  932 */       this.alignmentToggleGroup.selectToggle(this.alignLeftButton);
/*      */     }
/*      */     
/*  935 */     this.bulletsButton.setDisable(!isCommandEnabled(Command.BULLETS.getCommand()));
/*  936 */     this.bulletsButton.setSelected(getCommandState(Command.BULLETS.getCommand()));
/*  937 */     this.numbersButton.setDisable(!isCommandEnabled(Command.NUMBERS.getCommand()));
/*  938 */     this.numbersButton.setSelected(getCommandState(Command.NUMBERS.getCommand()));
/*      */     
/*  940 */     this.indentButton.setDisable(!isCommandEnabled(Command.INDENT.getCommand()));
/*  941 */     this.outdentButton.setDisable(!isCommandEnabled(Command.OUTDENT.getCommand()));
/*      */     
/*  943 */     this.formatComboBox.setDisable(!isCommandEnabled(Command.FORMAT.getCommand()));
/*      */ 
/*      */     
/*  946 */     String str1 = getCommandValue(Command.FORMAT.getCommand());
/*  947 */     if (str1 != null) {
/*  948 */       String str6 = "<" + str1 + ">";
/*  949 */       String str7 = this.styleFormatMap.get(str6);
/*  950 */       String str8 = this.formatComboBox.getValue();
/*      */ 
/*      */ 
/*      */       
/*  954 */       if (this.resetToolbarState || str6.equals("<>") || str6.equalsIgnoreCase("<div>") || str6.equalsIgnoreCase("<blockquote>")) {
/*  955 */         this.formatComboBox.setValue(this.resources.getString("paragraph"));
/*  956 */       } else if (str8 != null && !str8.equalsIgnoreCase(str7)) {
/*  957 */         this.formatComboBox.setValue(str7);
/*      */       } 
/*      */     } 
/*      */     
/*  961 */     this.fontFamilyComboBox.setDisable(!isCommandEnabled(Command.FONT_FAMILY.getCommand()));
/*  962 */     String str2 = getCommandValue(Command.FONT_FAMILY.getCommand());
/*  963 */     if (str2 != null) {
/*  964 */       String str = str2;
/*      */ 
/*      */ 
/*      */       
/*  968 */       if (str.startsWith("'")) {
/*  969 */         str = str.substring(1);
/*      */       }
/*  971 */       if (str.endsWith("'")) {
/*  972 */         str = str.substring(0, str.length() - 1);
/*      */       }
/*      */       
/*  975 */       Object object = this.fontFamilyComboBox.getValue();
/*  976 */       if (object instanceof String && 
/*  977 */         !object.equals(str)) {
/*      */         
/*  979 */         ObservableList<String> observableList = this.fontFamilyComboBox.getItems();
/*  980 */         String str6 = null;
/*  981 */         for (String str7 : observableList) {
/*      */           
/*  983 */           if (str7.equals(str)) {
/*  984 */             str6 = str7;
/*      */             
/*      */             break;
/*      */           } 
/*      */           
/*  989 */           if (str7.equals("") && str.equals("Dialog")) {
/*  990 */             str6 = str7;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*  995 */         if (str6 != null) {
/*  996 */           this.fontFamilyComboBox.setValue(str6);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1002 */     this.fontSizeComboBox.setDisable(!isCommandEnabled(Command.FONT_SIZE.getCommand()));
/* 1003 */     String str3 = getCommandValue(Command.FONT_SIZE.getCommand());
/*      */ 
/*      */     
/* 1006 */     if (this.resetToolbarState && str3 == null) {
/* 1007 */       this.fontSizeComboBox.setValue(this.sizeFontMap.get("3"));
/*      */     }
/* 1009 */     else if (str3 != null) {
/* 1010 */       if (!((String)this.fontSizeComboBox.getValue()).equals(this.sizeFontMap.get(str3))) {
/* 1011 */         this.fontSizeComboBox.setValue(this.sizeFontMap.get(str3));
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1019 */     else if (this.fontSizeComboBox.getValue() == null || !((String)this.fontSizeComboBox.getValue()).equals(this.sizeFontMap.get("3"))) {
/* 1020 */       this.fontSizeComboBox.setValue(this.sizeFontMap.get("3"));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1025 */     this.boldButton.setDisable(!isCommandEnabled(Command.BOLD.getCommand()));
/* 1026 */     this.boldButton.setSelected(getCommandState(Command.BOLD.getCommand()));
/* 1027 */     this.italicButton.setDisable(!isCommandEnabled(Command.ITALIC.getCommand()));
/* 1028 */     this.italicButton.setSelected(getCommandState(Command.ITALIC.getCommand()));
/* 1029 */     this.underlineButton.setDisable(!isCommandEnabled(Command.UNDERLINE.getCommand()));
/* 1030 */     this.underlineButton.setSelected(getCommandState(Command.UNDERLINE.getCommand()));
/* 1031 */     this.strikethroughButton.setDisable(!isCommandEnabled(Command.STRIKETHROUGH.getCommand()));
/* 1032 */     this.strikethroughButton.setSelected(getCommandState(Command.STRIKETHROUGH.getCommand()));
/*      */     
/* 1034 */     this.fgColorButton.setDisable(!isCommandEnabled(Command.FOREGROUND_COLOR.getCommand()));
/* 1035 */     String str4 = getCommandValue(Command.FOREGROUND_COLOR.getCommand());
/* 1036 */     if (str4 != null) {
/* 1037 */       this.fgColorButton.setValue(getColor(str4));
/*      */     }
/*      */     
/* 1040 */     this.bgColorButton.setDisable(!isCommandEnabled(Command.BACKGROUND_COLOR.getCommand()));
/* 1041 */     String str5 = getCommandValue(Command.BACKGROUND_COLOR.getCommand());
/* 1042 */     if (str5 != null) {
/* 1043 */       this.bgColorButton.setValue(getColor(str5));
/*      */     }
/*      */     
/* 1046 */     this.atomicityCount = (this.atomicityCount == 0) ? 0 : --this.atomicityCount;
/*      */   }
/*      */   
/*      */   private void enableToolbar(boolean paramBoolean) {
/* 1050 */     Platform.runLater(() -> {
/*      */           if (this.copyButton == null) {
/*      */             return;
/*      */           }
/*      */           if (paramBoolean) {
/*      */             this.copyButton.setDisable(!isCommandEnabled(Command.COPY.getCommand()));
/*      */             this.cutButton.setDisable(!isCommandEnabled(Command.CUT.getCommand()));
/*      */             this.pasteButton.setDisable(!isCommandEnabled(Command.PASTE.getCommand()));
/*      */           } else {
/*      */             this.copyButton.setDisable(true);
/*      */             this.cutButton.setDisable(true);
/*      */             this.pasteButton.setDisable(true);
/*      */           } 
/*      */           this.insertHorizontalRuleButton.setDisable(!paramBoolean);
/*      */           this.alignLeftButton.setDisable(!paramBoolean);
/*      */           this.alignCenterButton.setDisable(!paramBoolean);
/*      */           this.alignRightButton.setDisable(!paramBoolean);
/*      */           this.alignJustifyButton.setDisable(!paramBoolean);
/*      */           this.bulletsButton.setDisable(!paramBoolean);
/*      */           this.numbersButton.setDisable(!paramBoolean);
/*      */           this.indentButton.setDisable(!paramBoolean);
/*      */           this.outdentButton.setDisable(!paramBoolean);
/*      */           this.formatComboBox.setDisable(!paramBoolean);
/*      */           this.fontFamilyComboBox.setDisable(!paramBoolean);
/*      */           this.fontSizeComboBox.setDisable(!paramBoolean);
/*      */           this.boldButton.setDisable(!paramBoolean);
/*      */           this.italicButton.setDisable(!paramBoolean);
/*      */           this.underlineButton.setDisable(!paramBoolean);
/*      */           this.strikethroughButton.setDisable(!paramBoolean);
/*      */           this.fgColorButton.setDisable(!paramBoolean);
/*      */           this.bgColorButton.setDisable(!paramBoolean);
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean executeCommand(String paramString1, String paramString2) {
/* 1095 */     if (!this.enableAtomicityCheck || (this.enableAtomicityCheck && this.atomicityCount == 0)) {
/* 1096 */       return this.webPage.executeCommand(paramString1, paramString2);
/*      */     }
/* 1098 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isCommandEnabled(String paramString) {
/* 1102 */     return this.webPage.queryCommandEnabled(paramString);
/*      */   }
/*      */   
/*      */   private void setContentEditable(boolean paramBoolean) {
/* 1106 */     HTMLDocument hTMLDocument = (HTMLDocument)this.webPage.getDocument(this.webPage.getMainFrame());
/* 1107 */     HTMLElement hTMLElement1 = (HTMLElement)hTMLDocument.getDocumentElement();
/* 1108 */     HTMLElement hTMLElement2 = (HTMLElement)hTMLElement1.getElementsByTagName("body").item(0);
/* 1109 */     hTMLElement2.setAttribute("contenteditable", Boolean.toString(paramBoolean));
/*      */   }
/*      */   
/*      */   private boolean getCommandState(String paramString) {
/* 1113 */     return this.webPage.queryCommandState(paramString);
/*      */   }
/*      */   
/*      */   private String getCommandValue(String paramString) {
/* 1117 */     return this.webPage.queryCommandValue(paramString);
/*      */   }
/*      */   
/*      */   private Color getColor(String paramString) {
/* 1121 */     Color color = Color.web(paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1126 */     if (color.equals(Color.TRANSPARENT)) {
/* 1127 */       color = Color.WHITE;
/*      */     }
/* 1129 */     return color;
/*      */   }
/*      */   
/*      */   private void applyTextFormatting() {
/* 1133 */     if (getCommandState(Command.BULLETS.getCommand()) || getCommandState(Command.NUMBERS.getCommand())) {
/*      */       return;
/*      */     }
/*      */     
/* 1137 */     if (this.webPage.getClientCommittedTextLength() == 0) {
/* 1138 */       String str1 = this.formatStyleMap.get(this.formatComboBox.getValue());
/* 1139 */       String str2 = ((String)this.fontFamilyComboBox.getValue()).toString();
/*      */       
/* 1141 */       executeCommand(Command.FORMAT.getCommand(), str1);
/* 1142 */       executeCommand(Command.FONT_FAMILY.getCommand(), str2);
/*      */     } 
/*      */   }
/*      */   
/*      */   void print(PrinterJob paramPrinterJob) {
/* 1147 */     this.webView.getEngine().print(paramPrinterJob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Command
/*      */   {
/* 1162 */     CUT("cut"),
/* 1163 */     COPY("copy"),
/* 1164 */     PASTE("paste"),
/*      */     
/* 1166 */     UNDO("undo"),
/* 1167 */     REDO("redo"),
/*      */     
/* 1169 */     INSERT_HORIZONTAL_RULE("inserthorizontalrule"),
/*      */     
/* 1171 */     ALIGN_LEFT("justifyleft"),
/* 1172 */     ALIGN_CENTER("justifycenter"),
/* 1173 */     ALIGN_RIGHT("justifyright"),
/* 1174 */     ALIGN_JUSTIFY("justifyfull"),
/*      */     
/* 1176 */     BULLETS("insertUnorderedList"),
/* 1177 */     NUMBERS("insertOrderedList"),
/*      */     
/* 1179 */     INDENT("indent"),
/* 1180 */     OUTDENT("outdent"),
/*      */     
/* 1182 */     FORMAT("formatblock"),
/* 1183 */     FONT_FAMILY("fontname"),
/* 1184 */     FONT_SIZE("fontsize"),
/*      */     
/* 1186 */     BOLD("bold"),
/* 1187 */     ITALIC("italic"),
/* 1188 */     UNDERLINE("underline"),
/* 1189 */     STRIKETHROUGH("strikethrough"),
/*      */     
/* 1191 */     FOREGROUND_COLOR("forecolor"),
/* 1192 */     BACKGROUND_COLOR("backcolor"),
/* 1193 */     STYLEWITHCSS("styleWithCSS"),
/*      */     
/* 1195 */     INSERT_NEW_LINE("insertnewline"),
/* 1196 */     INSERT_TAB("inserttab");
/*      */     
/*      */     private final String command;
/*      */     
/*      */     Command(String param1String1) {
/* 1201 */       this.command = param1String1;
/*      */     }
/*      */     
/*      */     public String getCommand() {
/* 1205 */       return this.command;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\javafx\scene\web\HTMLEditorSkin.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */