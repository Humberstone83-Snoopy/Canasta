/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.html.HTMLCollection;
/*     */ import org.w3c.dom.html.HTMLElement;
/*     */ import org.w3c.dom.html.HTMLTableRowElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTableRowElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLTableRowElement
/*     */ {
/*     */   HTMLTableRowElementImpl(long paramLong) {
/*  35 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLTableRowElement getImpl(long paramLong) {
/*  39 */     return (HTMLTableRowElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native int getRowIndexImpl(long paramLong);
/*     */   
/*     */   public int getRowIndex() {
/*  45 */     return getRowIndexImpl(getPeer());
/*     */   }
/*     */   static native int getSectionRowIndexImpl(long paramLong);
/*     */   
/*     */   public int getSectionRowIndex() {
/*  50 */     return getSectionRowIndexImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public HTMLCollection getCells() {
/*  55 */     return HTMLCollectionImpl.getImpl(getCellsImpl(getPeer()));
/*     */   }
/*     */   static native long getCellsImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  60 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  65 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getBgColor() {
/*  70 */     return getBgColorImpl(getPeer());
/*     */   }
/*     */   static native String getBgColorImpl(long paramLong);
/*     */   
/*     */   public void setBgColor(String paramString) {
/*  75 */     setBgColorImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setBgColorImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCh() {
/*  80 */     return getChImpl(getPeer());
/*     */   }
/*     */   static native String getChImpl(long paramLong);
/*     */   
/*     */   public void setCh(String paramString) {
/*  85 */     setChImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getChOff() {
/*  90 */     return getChOffImpl(getPeer());
/*     */   }
/*     */   static native String getChOffImpl(long paramLong);
/*     */   
/*     */   public void setChOff(String paramString) {
/*  95 */     setChOffImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setChOffImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVAlign() {
/* 100 */     return getVAlignImpl(getPeer());
/*     */   }
/*     */   static native String getVAlignImpl(long paramLong);
/*     */   
/*     */   public void setVAlign(String paramString) {
/* 105 */     setVAlignImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   static native void setVAlignImpl(long paramLong, String paramString);
/*     */ 
/*     */   
/*     */   public HTMLElement insertCell(int paramInt) throws DOMException {
/* 113 */     return HTMLElementImpl.getImpl(insertCellImpl(getPeer(), paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static native long insertCellImpl(long paramLong, int paramInt);
/*     */ 
/*     */   
/*     */   public void deleteCell(int paramInt) throws DOMException {
/* 122 */     deleteCellImpl(getPeer(), paramInt);
/*     */   }
/*     */   
/*     */   static native void deleteCellImpl(long paramLong, int paramInt);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLTableRowElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */