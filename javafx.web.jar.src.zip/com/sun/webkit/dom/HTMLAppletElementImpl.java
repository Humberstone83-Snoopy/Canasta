/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import org.w3c.dom.html.HTMLAppletElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLAppletElementImpl
/*     */   extends HTMLElementImpl
/*     */   implements HTMLAppletElement
/*     */ {
/*     */   HTMLAppletElementImpl(long paramLong) {
/*  32 */     super(paramLong);
/*     */   }
/*     */   
/*     */   static HTMLAppletElement getImpl(long paramLong) {
/*  36 */     return (HTMLAppletElement)create(paramLong);
/*     */   }
/*     */   
/*     */   static native String getAlignImpl(long paramLong);
/*     */   
/*     */   public String getAlign() {
/*  42 */     return getAlignImpl(getPeer());
/*     */   }
/*     */   static native void setAlignImpl(long paramLong, String paramString);
/*     */   
/*     */   public void setAlign(String paramString) {
/*  47 */     setAlignImpl(getPeer(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAlt() {
/*  52 */     return getAltImpl(getPeer());
/*     */   }
/*     */   static native String getAltImpl(long paramLong);
/*     */   
/*     */   public void setAlt(String paramString) {
/*  57 */     setAltImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setAltImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getArchive() {
/*  62 */     return getArchiveImpl(getPeer());
/*     */   }
/*     */   static native String getArchiveImpl(long paramLong);
/*     */   
/*     */   public void setArchive(String paramString) {
/*  67 */     setArchiveImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setArchiveImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCode() {
/*  72 */     return getCodeImpl(getPeer());
/*     */   }
/*     */   static native String getCodeImpl(long paramLong);
/*     */   
/*     */   public void setCode(String paramString) {
/*  77 */     setCodeImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCodeImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getCodeBase() {
/*  82 */     return getCodeBaseImpl(getPeer());
/*     */   }
/*     */   static native String getCodeBaseImpl(long paramLong);
/*     */   
/*     */   public void setCodeBase(String paramString) {
/*  87 */     setCodeBaseImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setCodeBaseImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHeight() {
/*  92 */     return getHeightImpl(getPeer());
/*     */   }
/*     */   static native String getHeightImpl(long paramLong);
/*     */   
/*     */   public void setHeight(String paramString) {
/*  97 */     setHeightImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setHeightImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getHspace() {
/* 102 */     return "" + getHspaceImpl(getPeer());
/*     */   }
/*     */   static native int getHspaceImpl(long paramLong);
/*     */   
/*     */   public void setHspace(String paramString) {
/* 107 */     setHspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setHspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getName() {
/* 112 */     return getNameImpl(getPeer());
/*     */   }
/*     */   static native String getNameImpl(long paramLong);
/*     */   
/*     */   public void setName(String paramString) {
/* 117 */     setNameImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setNameImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getObject() {
/* 122 */     return getObjectImpl(getPeer());
/*     */   }
/*     */   static native String getObjectImpl(long paramLong);
/*     */   
/*     */   public void setObject(String paramString) {
/* 127 */     setObjectImpl(getPeer(), paramString);
/*     */   }
/*     */   static native void setObjectImpl(long paramLong, String paramString);
/*     */   
/*     */   public String getVspace() {
/* 132 */     return "" + getVspaceImpl(getPeer());
/*     */   }
/*     */   static native int getVspaceImpl(long paramLong);
/*     */   
/*     */   public void setVspace(String paramString) {
/* 137 */     setVspaceImpl(getPeer(), Integer.parseInt(paramString));
/*     */   }
/*     */   static native void setVspaceImpl(long paramLong, int paramInt);
/*     */   
/*     */   public String getWidth() {
/* 142 */     return getWidthImpl(getPeer());
/*     */   }
/*     */   static native String getWidthImpl(long paramLong);
/*     */   
/*     */   public void setWidth(String paramString) {
/* 147 */     setWidthImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   static native void setWidthImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLAppletElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */