/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.StringFormatter;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.value.ObservableSetValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.collections.SetChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetExpression<E>
/*     */   implements ObservableSetValue<E>
/*     */ {
/*  60 */   private static final ObservableSet EMPTY_SET = new EmptyObservableSet();
/*     */   
/*     */   private static class EmptyObservableSet<E>
/*     */     extends AbstractSet<E> implements ObservableSet<E> {
/*  64 */     private static final Iterator iterator = new Iterator()
/*     */       {
/*     */         public boolean hasNext() {
/*  67 */           return false;
/*     */         }
/*     */ 
/*     */         
/*     */         public Object next() {
/*  72 */           throw new NoSuchElementException();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/*  77 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */     
/*     */     private EmptyObservableSet() {}
/*     */     
/*     */     public Iterator<E> iterator() {
/*  84 */       return iterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/*  89 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addListener(SetChangeListener<? super E> param1SetChangeListener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeListener(SetChangeListener<? super E> param1SetChangeListener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addListener(InvalidationListener param1InvalidationListener) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeListener(InvalidationListener param1InvalidationListener) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableSet<E> getValue() {
/* 115 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> SetExpression<E> setExpression(final ObservableSetValue<E> value) {
/* 135 */     if (value == null) {
/* 136 */       throw new NullPointerException("Set must be specified.");
/*     */     }
/* 138 */     return (value instanceof SetExpression) ? (SetExpression<E>)value : 
/* 139 */       new SetBinding<E>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 146 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected ObservableSet<E> computeValue() {
/* 151 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<?> getDependencies() {
/* 156 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 166 */     return size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(ObservableSet<?> paramObservableSet) {
/* 192 */     return Bindings.equal(this, paramObservableSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(ObservableSet<?> paramObservableSet) {
/* 206 */     return Bindings.notEqual(this, paramObservableSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNull() {
/* 215 */     return Bindings.isNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotNull() {
/* 224 */     return Bindings.isNotNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBinding asString() {
/* 236 */     return (StringBinding)StringFormatter.convert(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 241 */     ObservableSet<E> observableSet = get();
/* 242 */     return (observableSet == null) ? EMPTY_SET.size() : observableSet.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 247 */     ObservableSet<E> observableSet = get();
/* 248 */     return (observableSet == null) ? EMPTY_SET.isEmpty() : observableSet.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 253 */     ObservableSet<E> observableSet = get();
/* 254 */     return (observableSet == null) ? EMPTY_SET.contains(paramObject) : observableSet.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 259 */     ObservableSet<E> observableSet = get();
/* 260 */     return (observableSet == null) ? EMPTY_SET.iterator() : observableSet.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 265 */     ObservableSet<E> observableSet = get();
/* 266 */     return (observableSet == null) ? EMPTY_SET.toArray() : observableSet.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 271 */     ObservableSet<E> observableSet = get();
/* 272 */     return (observableSet == null) ? (T[])EMPTY_SET.toArray((Object[])paramArrayOfT) : (T[])observableSet.toArray((Object[])paramArrayOfT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E paramE) {
/* 277 */     ObservableSet<E> observableSet = get();
/* 278 */     return (observableSet == null) ? EMPTY_SET.add(paramE) : observableSet.add(paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 283 */     ObservableSet<E> observableSet = get();
/* 284 */     return (observableSet == null) ? EMPTY_SET.remove(paramObject) : observableSet.remove(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 289 */     ObservableSet<E> observableSet = get();
/* 290 */     return (observableSet == null) ? EMPTY_SET.contains(paramCollection) : observableSet.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 295 */     ObservableSet<E> observableSet = get();
/* 296 */     return (observableSet == null) ? EMPTY_SET.addAll(paramCollection) : observableSet.addAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 301 */     ObservableSet<E> observableSet = get();
/* 302 */     return (observableSet == null) ? EMPTY_SET.removeAll(paramCollection) : observableSet.removeAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 307 */     ObservableSet<E> observableSet = get();
/* 308 */     return (observableSet == null) ? EMPTY_SET.retainAll(paramCollection) : observableSet.retainAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 313 */     ObservableSet<E> observableSet = get();
/* 314 */     if (observableSet == null) {
/* 315 */       EMPTY_SET.clear();
/*     */     } else {
/* 317 */       observableSet.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract ReadOnlyIntegerProperty sizeProperty();
/*     */   
/*     */   public abstract ReadOnlyBooleanProperty emptyProperty();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\SetExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */