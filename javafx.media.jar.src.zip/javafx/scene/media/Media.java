/*     */ package javafx.scene.media;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.MediaManager;
/*     */ import com.sun.media.jfxmedia.MetadataParser;
/*     */ import com.sun.media.jfxmedia.events.MetadataListener;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.track.Track;
/*     */ import com.sun.media.jfxmedia.track.VideoTrack;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.application.Platform;
/*     */ import javafx.beans.NamedArg;
/*     */ import javafx.beans.property.ObjectProperty;
/*     */ import javafx.beans.property.ObjectPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerWrapper;
/*     */ import javafx.beans.property.ReadOnlyObjectProperty;
/*     */ import javafx.beans.property.ReadOnlyObjectWrapper;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.scene.image.Image;
/*     */ import javafx.util.Duration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Media
/*     */ {
/*     */   private ReadOnlyObjectWrapper<MediaException> error;
/*     */   private ObjectProperty<Runnable> onError;
/*     */   
/*     */   private void setError(MediaException paramMediaException) {
/*  90 */     if (getError() == null) {
/*  91 */       errorPropertyImpl().set(paramMediaException);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MediaException getError() {
/* 100 */     return (this.error == null) ? null : this.error.get();
/*     */   }
/*     */   
/*     */   public ReadOnlyObjectProperty<MediaException> errorProperty() {
/* 104 */     return errorPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyObjectWrapper<MediaException> errorPropertyImpl() {
/* 108 */     if (this.error == null) {
/* 109 */       this.error = new ReadOnlyObjectWrapper<MediaException>()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 113 */             if (Media.this.getOnError() != null) {
/* 114 */               Platform.runLater(Media.this.getOnError());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 120 */             return Media.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 125 */             return "error";
/*     */           }
/*     */         };
/*     */     }
/* 129 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOnError(Runnable paramRunnable) {
/* 143 */     onErrorProperty().set(paramRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Runnable getOnError() {
/* 151 */     return (this.onError == null) ? null : this.onError.get();
/*     */   }
/*     */   
/*     */   public ObjectProperty<Runnable> onErrorProperty() {
/* 155 */     if (this.onError == null) {
/* 156 */       this.onError = new ObjectPropertyBase<Runnable>()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           protected void invalidated()
/*     */           {
/* 165 */             if (get() != null && Media.this.getError() != null) {
/* 166 */               Platform.runLater(get());
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 172 */             return Media.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 177 */             return "onError";
/*     */           }
/*     */         };
/*     */     }
/* 181 */     return this.onError;
/*     */   }
/*     */   
/* 184 */   private MetadataListener metadataListener = new _MetadataListener();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObservableMap<String, Object> metadata;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableMap<String, Object> getMetadata() {
/* 203 */     return this.metadata;
/*     */   }
/*     */   
/* 206 */   private final ObservableMap<String, Object> metadataBacking = FXCollections.observableMap(new HashMap<>());
/*     */   
/*     */   private ReadOnlyIntegerWrapper width;
/*     */   
/*     */   private ReadOnlyIntegerWrapper height;
/*     */   
/*     */   private ReadOnlyObjectWrapper<Duration> duration;
/*     */   
/*     */   private ObservableList<Track> tracks;
/*     */ 
/*     */   
/*     */   final void setWidth(int paramInt) {
/* 218 */     widthPropertyImpl().set(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getWidth() {
/* 226 */     return (this.width == null) ? 0 : this.width.get();
/*     */   }
/*     */   
/*     */   public ReadOnlyIntegerProperty widthProperty() {
/* 230 */     return widthPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyIntegerWrapper widthPropertyImpl() {
/* 234 */     if (this.width == null) {
/* 235 */       this.width = new ReadOnlyIntegerWrapper(this, "width");
/*     */     }
/* 237 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setHeight(int paramInt) {
/* 250 */     heightPropertyImpl().set(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getHeight() {
/* 258 */     return (this.height == null) ? 0 : this.height.get();
/*     */   }
/*     */   
/*     */   public ReadOnlyIntegerProperty heightProperty() {
/* 262 */     return heightPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyIntegerWrapper heightPropertyImpl() {
/* 266 */     if (this.height == null) {
/* 267 */       this.height = new ReadOnlyIntegerWrapper(this, "height");
/*     */     }
/* 269 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setDuration(Duration paramDuration) {
/* 278 */     durationPropertyImpl().set(paramDuration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Duration getDuration() {
/* 286 */     return (this.duration == null || this.duration.get() == null) ? Duration.UNKNOWN : this.duration.get();
/*     */   }
/*     */   
/*     */   public ReadOnlyObjectProperty<Duration> durationProperty() {
/* 290 */     return durationPropertyImpl().getReadOnlyProperty();
/*     */   }
/*     */   
/*     */   private ReadOnlyObjectWrapper<Duration> durationPropertyImpl() {
/* 294 */     if (this.duration == null) {
/* 295 */       this.duration = new ReadOnlyObjectWrapper<>(this, "duration");
/*     */     }
/* 297 */     return this.duration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<Track> getTracks() {
/* 314 */     return this.tracks;
/*     */   }
/* 316 */   private final ObservableList<Track> tracksBacking = FXCollections.observableArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 323 */   private ObservableMap<String, Duration> markers = FXCollections.observableMap(new HashMap<>());
/*     */ 
/*     */   
/*     */   private final String source;
/*     */   
/*     */   private final Locator jfxLocator;
/*     */   
/*     */   private MetadataParser jfxParser;
/*     */ 
/*     */   
/*     */   public final ObservableMap<String, Duration> getMarkers() {
/* 334 */     return this.markers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Media(@NamedArg("source") String paramString) {
/* 378 */     this.source = paramString;
/*     */     
/* 380 */     URI uRI = null;
/*     */     
/*     */     try {
/* 383 */       uRI = new URI(paramString);
/* 384 */     } catch (URISyntaxException uRISyntaxException) {
/* 385 */       throw new IllegalArgumentException(uRISyntaxException);
/*     */     } 
/*     */     
/* 388 */     this.metadata = FXCollections.unmodifiableObservableMap(this.metadataBacking);
/* 389 */     this.tracks = FXCollections.unmodifiableObservableList(this.tracksBacking);
/*     */     
/* 391 */     Locator locator = null;
/*     */     try {
/* 393 */       locator = new Locator(uRI);
/* 394 */       this.jfxLocator = locator;
/* 395 */       if (locator.canBlock()) {
/* 396 */         InitLocator initLocator = new InitLocator();
/* 397 */         Thread thread = new Thread(initLocator);
/* 398 */         thread.setDaemon(true);
/* 399 */         thread.start();
/*     */       } else {
/* 401 */         locator.init();
/* 402 */         runMetadataParser();
/*     */       } 
/* 404 */     } catch (URISyntaxException uRISyntaxException) {
/* 405 */       throw new IllegalArgumentException(uRISyntaxException);
/* 406 */     } catch (FileNotFoundException fileNotFoundException) {
/* 407 */       throw new MediaException(MediaException.Type.MEDIA_UNAVAILABLE, fileNotFoundException.getMessage());
/* 408 */     } catch (IOException iOException) {
/* 409 */       throw new MediaException(MediaException.Type.MEDIA_INACCESSIBLE, iOException.getMessage());
/* 410 */     } catch (MediaException mediaException) {
/* 411 */       throw new MediaException(MediaException.Type.MEDIA_UNSUPPORTED, mediaException.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runMetadataParser() {
/*     */     try {
/* 417 */       this.jfxParser = MediaManager.getMetadataParser(this.jfxLocator);
/* 418 */       this.jfxParser.addListener(this.metadataListener);
/* 419 */       this.jfxParser.startParser();
/* 420 */     } catch (Exception exception) {
/* 421 */       this.jfxParser = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSource() {
/* 435 */     return this.source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Locator retrieveJfxLocator() {
/* 443 */     return this.jfxLocator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Track getTrackWithID(long paramLong) {
/* 449 */     for (Track track : this.tracksBacking) {
/* 450 */       if (track.getTrackID() == paramLong) {
/* 451 */         return track;
/*     */       }
/*     */     } 
/* 454 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void _updateMedia(com.sun.media.jfxmedia.Media paramMedia) {
/*     */     try {
/* 461 */       List<Track> list = paramMedia.getTracks();
/*     */       
/* 463 */       if (list != null) {
/* 464 */         for (Track track : list) {
/* 465 */           long l = track.getTrackID();
/* 466 */           if (getTrackWithID(l) == null) {
/* 467 */             SubtitleTrack subtitleTrack; VideoTrack videoTrack = null;
/* 468 */             HashMap<Object, Object> hashMap = new HashMap<>();
/* 469 */             if (null != track.getName())
/*     */             {
/* 471 */               hashMap.put("name", track.getName());
/*     */             }
/* 473 */             if (null != track.getLocale()) {
/* 474 */               hashMap.put("locale", track.getLocale());
/*     */             }
/* 476 */             hashMap.put("encoding", track.getEncodingType().toString());
/* 477 */             hashMap.put("enabled", Boolean.valueOf(track.isEnabled()));
/*     */             
/* 479 */             if (track instanceof VideoTrack) {
/* 480 */               VideoTrack videoTrack1 = (VideoTrack)track;
/*     */ 
/*     */               
/* 483 */               int i = videoTrack1.getFrameSize().getWidth();
/* 484 */               int j = videoTrack1.getFrameSize().getHeight();
/*     */ 
/*     */               
/* 487 */               setWidth(i);
/* 488 */               setHeight(j);
/*     */               
/* 490 */               hashMap.put("video width", Integer.valueOf(i));
/* 491 */               hashMap.put("video height", Integer.valueOf(j));
/*     */               
/* 493 */               videoTrack = new VideoTrack(track.getTrackID(), (Map)hashMap);
/* 494 */             } else if (track instanceof com.sun.media.jfxmedia.track.AudioTrack) {
/* 495 */               AudioTrack audioTrack = new AudioTrack(track.getTrackID(), (Map)hashMap);
/* 496 */             } else if (track instanceof com.sun.media.jfxmedia.track.SubtitleTrack) {
/* 497 */               subtitleTrack = new SubtitleTrack(l, (Map)hashMap);
/*     */             } 
/*     */             
/* 500 */             if (null != subtitleTrack) {
/* 501 */               this.tracksBacking.add(subtitleTrack);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/* 506 */     } catch (Exception exception) {
/*     */       
/* 508 */       setError(new MediaException(MediaException.Type.UNKNOWN, exception));
/*     */     } 
/*     */   }
/*     */   
/*     */   void _setError(MediaException.Type paramType, String paramString) {
/* 513 */     setError(new MediaException(paramType, paramString));
/*     */   }
/*     */   
/*     */   private synchronized void updateMetadata(Map<String, Object> paramMap) {
/* 517 */     if (paramMap != null)
/* 518 */       for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
/* 519 */         String str = (String)entry.getKey();
/* 520 */         Object object = entry.getValue();
/* 521 */         if (str.equals("image") && object instanceof byte[]) {
/* 522 */           byte[] arrayOfByte = (byte[])object;
/* 523 */           Image image = new Image(new ByteArrayInputStream(arrayOfByte));
/* 524 */           if (!image.isError())
/* 525 */             this.metadataBacking.put("image", image);  continue;
/*     */         } 
/* 527 */         if (str.equals("duration") && object instanceof Long) {
/* 528 */           Duration duration = new Duration(((Long)object).longValue());
/* 529 */           if (duration != null)
/* 530 */             this.metadataBacking.put("duration", duration); 
/*     */           continue;
/*     */         } 
/* 533 */         this.metadataBacking.put(str, object);
/*     */       }  
/*     */   }
/*     */   
/*     */   private class _MetadataListener
/*     */     implements MetadataListener
/*     */   {
/*     */     private _MetadataListener() {}
/*     */     
/*     */     public void onMetadata(Map<String, Object> param1Map) {
/* 543 */       Platform.runLater(() -> {
/*     */             Media.this.updateMetadata(param1Map);
/*     */             Media.this.jfxParser.removeListener(Media.this.metadataListener);
/*     */             Media.this.jfxParser.stopParser();
/*     */             Media.this.jfxParser = null;
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   private class InitLocator implements Runnable {
/*     */     private InitLocator() {}
/*     */     
/*     */     public void run() {
/*     */       try {
/* 557 */         Media.this.jfxLocator.init();
/* 558 */         Media.this.runMetadataParser();
/* 559 */       } catch (URISyntaxException uRISyntaxException) {
/* 560 */         Media.this._setError(MediaException.Type.OPERATION_UNSUPPORTED, uRISyntaxException.getMessage());
/* 561 */       } catch (FileNotFoundException fileNotFoundException) {
/* 562 */         Media.this._setError(MediaException.Type.MEDIA_UNAVAILABLE, fileNotFoundException.getMessage());
/* 563 */       } catch (IOException iOException) {
/* 564 */         Media.this._setError(MediaException.Type.MEDIA_INACCESSIBLE, iOException.getMessage());
/* 565 */       } catch (MediaException mediaException) {
/* 566 */         Media.this._setError(MediaException.Type.MEDIA_UNSUPPORTED, mediaException.getMessage());
/* 567 */       } catch (Exception exception) {
/* 568 */         Media.this._setError(MediaException.Type.UNKNOWN, exception.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\Media.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */