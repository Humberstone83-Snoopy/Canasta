/*     */ package com.sun.media.jfxmediaimpl;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaManager;
/*     */ import com.sun.media.jfxmedia.MediaPlayer;
/*     */ import com.sun.media.jfxmedia.events.MediaErrorListener;
/*     */ import com.sun.media.jfxmedia.events.PlayerStateEvent;
/*     */ import com.sun.media.jfxmedia.events.PlayerStateListener;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NativeMediaAudioClipPlayer
/*     */   implements PlayerStateListener, MediaErrorListener
/*     */ {
/*     */   private MediaPlayer mediaPlayer;
/*     */   private int playCount;
/*     */   private int loopCount;
/*     */   private boolean playing;
/*     */   private boolean ready;
/*     */   private NativeMediaAudioClip sourceClip;
/*     */   private double volume;
/*     */   private double balance;
/*     */   private double pan;
/*     */   private double rate;
/*     */   private int priority;
/*  63 */   private final ReentrantLock playerStateLock = new ReentrantLock();
/*     */   
/*     */   private static final int MAX_PLAYER_COUNT = 16;
/*     */   
/*  67 */   private static final List<NativeMediaAudioClipPlayer> activePlayers = new ArrayList<>(16);
/*     */   
/*  69 */   private static final ReentrantLock playerListLock = new ReentrantLock();
/*     */   
/*     */   public static int getPlayerLimit() {
/*  72 */     return 16;
/*     */   }
/*     */   
/*     */   public static int getPlayerCount() {
/*  76 */     return activePlayers.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Enthreaderator
/*     */   {
/*  84 */     private static final Thread schedulerThread = new Thread(() -> NativeMediaAudioClipPlayer.clipScheduler());
/*     */     
/*     */     static {
/*  87 */       schedulerThread.setDaemon(true);
/*  88 */       schedulerThread.start();
/*     */     }
/*     */     
/*     */     public static Thread getSchedulerThread() {
/*  92 */       return schedulerThread;
/*     */     }
/*     */   }
/*     */   
/*  96 */   private static final LinkedBlockingQueue<SchedulerEntry> schedule = new LinkedBlockingQueue<>();
/*     */ 
/*     */   
/*     */   private static void clipScheduler() {
/*     */     while (true) {
/* 101 */       SchedulerEntry schedulerEntry = null;
/*     */       try {
/* 103 */         schedulerEntry = schedule.take();
/* 104 */       } catch (InterruptedException interruptedException) {}
/*     */       
/* 106 */       if (null != schedulerEntry) {
/* 107 */         if (schedulerEntry.getCommand() == 0) {
/* 108 */           NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer = schedulerEntry.getPlayer();
/* 109 */           if (null != nativeMediaAudioClipPlayer)
/*     */           {
/* 111 */             if (addPlayer(nativeMediaAudioClipPlayer)) {
/* 112 */               nativeMediaAudioClipPlayer.play();
/*     */             } else {
/* 114 */               nativeMediaAudioClipPlayer.sourceClip.playFinished();
/*     */             } 
/*     */           }
/* 117 */         } else if (schedulerEntry.getCommand() == 1) {
/*     */ 
/*     */           
/* 120 */           URI uRI = schedulerEntry.getClipURI();
/*     */           
/* 122 */           playerListLock.lock();
/*     */           
/*     */           try {
/* 125 */             NativeMediaAudioClipPlayer[] arrayOfNativeMediaAudioClipPlayer = new NativeMediaAudioClipPlayer[16];
/* 126 */             arrayOfNativeMediaAudioClipPlayer = activePlayers.<NativeMediaAudioClipPlayer>toArray(arrayOfNativeMediaAudioClipPlayer);
/* 127 */             if (null != arrayOfNativeMediaAudioClipPlayer) {
/* 128 */               for (byte b = 0; b < arrayOfNativeMediaAudioClipPlayer.length; b++) {
/* 129 */                 if (null != arrayOfNativeMediaAudioClipPlayer[b] && (null == uRI || arrayOfNativeMediaAudioClipPlayer[b]
/* 130 */                   .source().getURI().equals(uRI)))
/*     */                 {
/* 132 */                   arrayOfNativeMediaAudioClipPlayer[b].invalidate();
/*     */                 }
/*     */               } 
/*     */             }
/*     */           } finally {
/* 137 */             playerListLock.unlock();
/*     */           } 
/*     */ 
/*     */           
/* 141 */           boolean bool = (null == uRI) ? true : false;
/* 142 */           for (SchedulerEntry schedulerEntry1 : schedule) {
/* 143 */             NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer = schedulerEntry1.getPlayer();
/* 144 */             if (bool || (null != nativeMediaAudioClipPlayer && nativeMediaAudioClipPlayer.sourceClip
/* 145 */               .getLocator().getURI().equals(uRI))) {
/*     */ 
/*     */               
/* 148 */               schedule.remove(schedulerEntry1);
/* 149 */               nativeMediaAudioClipPlayer.sourceClip.playFinished();
/*     */             } 
/*     */           } 
/* 152 */         } else if (schedulerEntry.getCommand() == 2) {
/* 153 */           schedulerEntry.getMediaPlayer().dispose();
/*     */         } 
/*     */ 
/*     */         
/* 157 */         schedulerEntry.signal();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void playClip(NativeMediaAudioClip paramNativeMediaAudioClip, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2) {
/* 168 */     Enthreaderator.getSchedulerThread();
/*     */ 
/*     */ 
/*     */     
/* 172 */     NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer = new NativeMediaAudioClipPlayer(paramNativeMediaAudioClip, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt1, paramInt2);
/* 173 */     SchedulerEntry schedulerEntry = new SchedulerEntry(nativeMediaAudioClipPlayer);
/* 174 */     boolean bool = schedule.contains(schedulerEntry);
/* 175 */     if (bool || !schedule.offer(schedulerEntry)) {
/*     */ 
/*     */       
/* 178 */       if (Logger.canLog(1) && !bool) {
/* 179 */         Logger.logMsg(1, "AudioClip could not be scheduled for playback!");
/*     */       }
/* 181 */       paramNativeMediaAudioClip.playFinished();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean addPlayer(NativeMediaAudioClipPlayer paramNativeMediaAudioClipPlayer) {
/* 188 */     playerListLock.lock();
/*     */     try {
/* 190 */       int i = paramNativeMediaAudioClipPlayer.priority();
/* 191 */       while (activePlayers.size() >= 16) {
/*     */         
/* 193 */         NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer = null;
/* 194 */         for (NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer1 : activePlayers) {
/* 195 */           if (nativeMediaAudioClipPlayer1.priority() <= i && (nativeMediaAudioClipPlayer == null || (nativeMediaAudioClipPlayer
/* 196 */             .isReady() && nativeMediaAudioClipPlayer1.priority() < nativeMediaAudioClipPlayer.priority())))
/*     */           {
/*     */             
/* 199 */             nativeMediaAudioClipPlayer = nativeMediaAudioClipPlayer1;
/*     */           }
/*     */         } 
/* 202 */         if (null != nativeMediaAudioClipPlayer) {
/*     */           
/* 204 */           nativeMediaAudioClipPlayer.invalidate();
/*     */           continue;
/*     */         } 
/* 207 */         return false;
/*     */       } 
/*     */       
/* 210 */       activePlayers.add(paramNativeMediaAudioClipPlayer);
/*     */     } finally {
/* 212 */       playerListLock.unlock();
/*     */     } 
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void stopPlayers(Locator paramLocator) {
/* 219 */     URI uRI = (paramLocator != null) ? paramLocator.getURI() : null;
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (null != Enthreaderator.getSchedulerThread()) {
/*     */ 
/*     */ 
/*     */       
/* 227 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/* 228 */       SchedulerEntry schedulerEntry = new SchedulerEntry(uRI, countDownLatch);
/* 229 */       if (schedule.offer(schedulerEntry)) {
/*     */         
/*     */         try {
/*     */           
/* 233 */           countDownLatch.await(5L, TimeUnit.SECONDS);
/* 234 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private NativeMediaAudioClipPlayer(NativeMediaAudioClip paramNativeMediaAudioClip, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2) {
/* 242 */     this.sourceClip = paramNativeMediaAudioClip;
/* 243 */     this.volume = paramDouble1;
/* 244 */     this.balance = paramDouble2;
/* 245 */     this.pan = paramDouble4;
/* 246 */     this.rate = paramDouble3;
/* 247 */     this.loopCount = paramInt1;
/* 248 */     this.priority = paramInt2;
/* 249 */     this.ready = false;
/*     */   }
/*     */   
/*     */   private Locator source() {
/* 253 */     return this.sourceClip.getLocator();
/*     */   }
/*     */   
/*     */   public double volume() {
/* 257 */     return this.volume;
/*     */   }
/*     */   
/*     */   public void setVolume(double paramDouble) {
/* 261 */     this.volume = paramDouble;
/*     */   }
/*     */   
/*     */   public double balance() {
/* 265 */     return this.balance;
/*     */   }
/*     */   
/*     */   public void setBalance(double paramDouble) {
/* 269 */     this.balance = paramDouble;
/*     */   }
/*     */   
/*     */   public double pan() {
/* 273 */     return this.pan;
/*     */   }
/*     */   
/*     */   public void setPan(double paramDouble) {
/* 277 */     this.pan = paramDouble;
/*     */   }
/*     */   
/*     */   public double playbackRate() {
/* 281 */     return this.rate;
/*     */   }
/*     */   
/*     */   public void setPlaybackRate(double paramDouble) {
/* 285 */     this.rate = paramDouble;
/*     */   }
/*     */   
/*     */   public int priority() {
/* 289 */     return this.priority;
/*     */   }
/*     */   
/*     */   public void setPriority(int paramInt) {
/* 293 */     this.priority = paramInt;
/*     */   }
/*     */   
/*     */   public int loopCount() {
/* 297 */     return this.loopCount;
/*     */   }
/*     */   
/*     */   public void setLoopCount(int paramInt) {
/* 301 */     this.loopCount = paramInt;
/*     */   }
/*     */   
/*     */   public boolean isPlaying() {
/* 305 */     return this.playing;
/*     */   }
/*     */   
/*     */   private boolean isReady() {
/* 309 */     return this.ready;
/*     */   }
/*     */   
/*     */   public synchronized void play() {
/* 313 */     this.playerStateLock.lock();
/*     */     try {
/* 315 */       this.playing = true;
/* 316 */       this.playCount = 0;
/*     */       
/* 318 */       if (null == this.mediaPlayer) {
/* 319 */         this.mediaPlayer = MediaManager.getPlayer(source());
/* 320 */         this.mediaPlayer.addMediaPlayerListener(this);
/* 321 */         this.mediaPlayer.addMediaErrorListener(this);
/*     */       } else {
/* 323 */         this.mediaPlayer.play();
/*     */       } 
/*     */     } finally {
/* 326 */       this.playerStateLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/* 331 */     invalidate();
/*     */   }
/*     */   
/*     */   public synchronized void invalidate() {
/* 335 */     this.playerStateLock.lock();
/* 336 */     playerListLock.lock();
/*     */     
/*     */     try {
/* 339 */       this.playing = false;
/* 340 */       this.playCount = 0;
/* 341 */       this.ready = false;
/*     */       
/* 343 */       activePlayers.remove(this);
/* 344 */       this.sourceClip.playFinished();
/*     */       
/* 346 */       if (null != this.mediaPlayer) {
/* 347 */         this.mediaPlayer.removeMediaPlayerListener(this);
/* 348 */         this.mediaPlayer.setMute(true);
/* 349 */         SchedulerEntry schedulerEntry = new SchedulerEntry(this.mediaPlayer);
/* 350 */         if (!schedule.offer(schedulerEntry)) {
/* 351 */           this.mediaPlayer.dispose();
/*     */         }
/* 353 */         this.mediaPlayer = null;
/*     */       }
/*     */     
/* 356 */     } catch (Throwable throwable) {
/*     */ 
/*     */     
/*     */     } finally {
/* 360 */       playerListLock.unlock();
/* 361 */       this.playerStateLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onReady(PlayerStateEvent paramPlayerStateEvent) {
/* 366 */     this.playerStateLock.lock();
/*     */     try {
/* 368 */       this.ready = true;
/* 369 */       if (this.playing) {
/* 370 */         this.mediaPlayer.setVolume((float)this.volume);
/* 371 */         this.mediaPlayer.setBalance((float)this.balance);
/* 372 */         this.mediaPlayer.setRate((float)this.rate);
/* 373 */         this.mediaPlayer.play();
/*     */       } 
/*     */     } finally {
/* 376 */       this.playerStateLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onPlaying(PlayerStateEvent paramPlayerStateEvent) {}
/*     */ 
/*     */   
/*     */   public void onPause(PlayerStateEvent paramPlayerStateEvent) {}
/*     */   
/*     */   public void onStop(PlayerStateEvent paramPlayerStateEvent) {
/* 387 */     invalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStall(PlayerStateEvent paramPlayerStateEvent) {}
/*     */   
/*     */   public void onFinish(PlayerStateEvent paramPlayerStateEvent) {
/* 394 */     this.playerStateLock.lock();
/*     */     try {
/* 396 */       if (this.playing) {
/* 397 */         if (this.loopCount != -1) {
/* 398 */           this.playCount++;
/* 399 */           if (this.playCount <= this.loopCount) {
/* 400 */             this.mediaPlayer.seek(0.0D);
/*     */           } else {
/* 402 */             invalidate();
/*     */           } 
/*     */         } else {
/* 405 */           this.mediaPlayer.seek(0.0D);
/*     */         } 
/*     */       }
/*     */     } finally {
/* 409 */       this.playerStateLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onHalt(PlayerStateEvent paramPlayerStateEvent) {
/* 414 */     invalidate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onWarning(Object paramObject, String paramString) {}
/*     */   
/*     */   public void onError(Object paramObject, int paramInt, String paramString) {
/* 421 */     if (Logger.canLog(4)) {
/* 422 */       Logger.logMsg(4, "Error with AudioClip player: code " + paramInt + " : " + paramString);
/*     */     }
/* 424 */     invalidate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 433 */     if (paramObject == this) {
/* 434 */       return true;
/*     */     }
/*     */     
/* 437 */     if (paramObject instanceof NativeMediaAudioClipPlayer) {
/* 438 */       NativeMediaAudioClipPlayer nativeMediaAudioClipPlayer = (NativeMediaAudioClipPlayer)paramObject;
/* 439 */       URI uRI1 = this.sourceClip.getLocator().getURI();
/* 440 */       URI uRI2 = nativeMediaAudioClipPlayer.sourceClip.getLocator().getURI();
/*     */       
/* 442 */       return (uRI1.equals(uRI2) && this.priority == nativeMediaAudioClipPlayer.priority && this.loopCount == nativeMediaAudioClipPlayer.loopCount && 
/*     */ 
/*     */         
/* 445 */         Double.compare(this.volume, nativeMediaAudioClipPlayer.volume) == 0 && 
/* 446 */         Double.compare(this.balance, nativeMediaAudioClipPlayer.balance) == 0 && 
/* 447 */         Double.compare(this.rate, nativeMediaAudioClipPlayer.rate) == 0 && 
/* 448 */         Double.compare(this.pan, nativeMediaAudioClipPlayer.pan) == 0);
/*     */     } 
/* 450 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SchedulerEntry
/*     */   {
/*     */     private final int command;
/*     */     private final NativeMediaAudioClipPlayer player;
/*     */     private final URI clipURI;
/*     */     private final CountDownLatch commandSignal;
/*     */     private final MediaPlayer mediaPlayer;
/*     */     
/*     */     public SchedulerEntry(NativeMediaAudioClipPlayer param1NativeMediaAudioClipPlayer) {
/* 463 */       this.command = 0;
/* 464 */       this.player = param1NativeMediaAudioClipPlayer;
/* 465 */       this.clipURI = null;
/* 466 */       this.commandSignal = null;
/* 467 */       this.mediaPlayer = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public SchedulerEntry(URI param1URI, CountDownLatch param1CountDownLatch) {
/* 472 */       this.command = 1;
/* 473 */       this.player = null;
/* 474 */       this.clipURI = param1URI;
/* 475 */       this.commandSignal = param1CountDownLatch;
/* 476 */       this.mediaPlayer = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public SchedulerEntry(MediaPlayer param1MediaPlayer) {
/* 481 */       this.command = 2;
/* 482 */       this.player = null;
/* 483 */       this.clipURI = null;
/* 484 */       this.commandSignal = null;
/* 485 */       this.mediaPlayer = param1MediaPlayer;
/*     */     }
/*     */     
/*     */     public int getCommand() {
/* 489 */       return this.command;
/*     */     }
/*     */     
/*     */     public NativeMediaAudioClipPlayer getPlayer() {
/* 493 */       return this.player;
/*     */     }
/*     */     
/*     */     public URI getClipURI() {
/* 497 */       return this.clipURI;
/*     */     }
/*     */     
/*     */     public MediaPlayer getMediaPlayer() {
/* 501 */       return this.mediaPlayer;
/*     */     }
/*     */     
/*     */     public void signal() {
/* 505 */       if (null != this.commandSignal) {
/* 506 */         this.commandSignal.countDown();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 513 */       if (param1Object instanceof SchedulerEntry && 
/* 514 */         null != this.player) {
/* 515 */         return this.player.equals(((SchedulerEntry)param1Object).getPlayer());
/*     */       }
/*     */       
/* 518 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\NativeMediaAudioClipPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */