/*     */ package com.sun.javafx.scene.traversal;
/*     */ 
/*     */ import java.util.List;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContainerTabOrder
/*     */   implements Algorithm
/*     */ {
/*     */   public Node select(Node paramNode, Direction paramDirection, TraversalContext paramTraversalContext) {
/*     */     List<Node> list;
/*     */     int i;
/*  40 */     switch (paramDirection) {
/*     */       case NEXT:
/*     */       case NEXT_IN_LINE:
/*  43 */         return TabOrderHelper.findNextFocusablePeer(paramNode, paramTraversalContext.getRoot(), (paramDirection == Direction.NEXT));
/*     */       case PREVIOUS:
/*  45 */         return TabOrderHelper.findPreviousFocusablePeer(paramNode, paramTraversalContext.getRoot());
/*     */       case UP:
/*     */       case DOWN:
/*     */       case LEFT:
/*     */       case RIGHT:
/*  50 */         list = paramTraversalContext.getAllTargetNodes();
/*     */         
/*  52 */         i = trav2D(paramTraversalContext.getSceneLayoutBounds(paramNode), paramDirection, list, paramTraversalContext);
/*  53 */         if (i != -1)
/*  54 */           return list.get(i); 
/*     */         break;
/*     */     } 
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectFirst(TraversalContext paramTraversalContext) {
/*  62 */     return TabOrderHelper.getFirstTargetNode(paramTraversalContext.getRoot());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node selectLast(TraversalContext paramTraversalContext) {
/*  67 */     return TabOrderHelper.getLastTargetNode(paramTraversalContext.getRoot());
/*     */   }
/*     */ 
/*     */   
/*     */   private int trav2D(Bounds paramBounds, Direction paramDirection, List<Node> paramList, TraversalContext paramTraversalContext) {
/*  72 */     Bounds bounds = null;
/*  73 */     double d = 0.0D;
/*  74 */     byte b = -1;
/*     */     
/*  76 */     for (byte b1 = 0; b1 < paramList.size(); b1++) {
/*  77 */       double d2; Bounds bounds1 = paramTraversalContext.getSceneLayoutBounds(paramList.get(b1));
/*  78 */       double d1 = outDistance(paramDirection, paramBounds, bounds1);
/*     */ 
/*     */       
/*  81 */       if (isOnAxis(paramDirection, paramBounds, bounds1)) {
/*  82 */         d2 = d1 + centerSideDistance(paramDirection, paramBounds, bounds1) / 100.0D;
/*     */       } else {
/*     */         
/*  85 */         double d3 = cornerSideDistance(paramDirection, paramBounds, bounds1);
/*  86 */         d2 = 100000.0D + d1 * d1 + 9.0D * d3 * d3;
/*     */       } 
/*     */       
/*  89 */       if (d1 >= 0.0D)
/*     */       {
/*     */ 
/*     */         
/*  93 */         if (bounds == null || d2 < d) {
/*  94 */           bounds = bounds1;
/*  95 */           d = d2;
/*  96 */           b = b1;
/*     */         } 
/*     */       }
/*     */     } 
/* 100 */     return b;
/*     */   }
/*     */   private boolean isOnAxis(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/*     */     double d3;
/*     */     double d4;
/* 107 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 108 */       d1 = paramBounds1.getMinX();
/* 109 */       d2 = paramBounds1.getMaxX();
/* 110 */       d3 = paramBounds2.getMinX();
/* 111 */       d4 = paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/* 114 */       d1 = paramBounds1.getMinY();
/* 115 */       d2 = paramBounds1.getMaxY();
/* 116 */       d3 = paramBounds2.getMinY();
/* 117 */       d4 = paramBounds2.getMaxY();
/*     */     } 
/*     */     
/* 120 */     return (d3 <= d2 && d4 >= d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double outDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/* 131 */     if (paramDirection == Direction.UP) {
/* 132 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     }
/* 134 */     else if (paramDirection == Direction.DOWN) {
/* 135 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/* 137 */     else if (paramDirection == Direction.LEFT) {
/* 138 */       d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */     } else {
/*     */       
/* 141 */       d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */     } 
/*     */     
/* 144 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double centerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d1;
/*     */     double d2;
/* 156 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/* 157 */       d1 = paramBounds1.getMinX() + paramBounds1.getWidth() / 2.0D;
/* 158 */       d2 = paramBounds2.getMinX() + paramBounds2.getWidth() / 2.0D;
/*     */     } else {
/*     */       
/* 161 */       d1 = paramBounds1.getMinY() + paramBounds1.getHeight() / 2.0D;
/* 162 */       d2 = paramBounds2.getMinY() + paramBounds2.getHeight() / 2.0D;
/*     */     } 
/*     */     
/* 165 */     return Math.abs(d2 - d1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double cornerSideDistance(Direction paramDirection, Bounds paramBounds1, Bounds paramBounds2) {
/*     */     double d;
/* 177 */     if (paramDirection == Direction.UP || paramDirection == Direction.DOWN) {
/*     */       
/* 179 */       if (paramBounds2.getMinX() > paramBounds1.getMaxX())
/*     */       {
/* 181 */         d = paramBounds2.getMinX() - paramBounds1.getMaxX();
/*     */       }
/*     */       else
/*     */       {
/* 185 */         d = paramBounds1.getMinX() - paramBounds2.getMaxX();
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 190 */     else if (paramBounds2.getMinY() > paramBounds1.getMaxY()) {
/*     */       
/* 192 */       d = paramBounds2.getMinY() - paramBounds1.getMaxY();
/*     */     }
/*     */     else {
/*     */       
/* 196 */       d = paramBounds1.getMinY() - paramBounds2.getMaxY();
/*     */     } 
/*     */     
/* 199 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\traversal\ContainerTabOrder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */