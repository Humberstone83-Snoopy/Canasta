/*     */ package com.sun.javafx.iio;
/*     */ 
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageFrame
/*     */ {
/*     */   private ImageStorage.ImageType imageType;
/*     */   private ByteBuffer imageData;
/*     */   private int width;
/*     */   private int height;
/*     */   private int stride;
/*     */   private float pixelScale;
/*     */   private byte[][] palette;
/*     */   private ImageMetadata metadata;
/*     */   
/*     */   public ImageFrame(ImageStorage.ImageType paramImageType, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, byte[][] paramArrayOfbyte, ImageMetadata paramImageMetadata) {
/*  63 */     this(paramImageType, paramByteBuffer, paramInt1, paramInt2, paramInt3, paramArrayOfbyte, 1.0F, paramImageMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ImageFrame(ImageStorage.ImageType paramImageType, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, byte[][] paramArrayOfbyte, float paramFloat, ImageMetadata paramImageMetadata) {
/*  88 */     this.imageType = paramImageType;
/*  89 */     this.imageData = paramByteBuffer;
/*  90 */     this.width = paramInt1;
/*  91 */     this.height = paramInt2;
/*  92 */     this.stride = paramInt3;
/*  93 */     this.palette = paramArrayOfbyte;
/*  94 */     this.pixelScale = paramFloat;
/*  95 */     this.metadata = paramImageMetadata;
/*     */   }
/*     */   
/*     */   public ImageStorage.ImageType getImageType() {
/*  99 */     return this.imageType;
/*     */   }
/*     */   
/*     */   public Buffer getImageData() {
/* 103 */     return this.imageData;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 107 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 111 */     return this.height;
/*     */   }
/*     */   
/*     */   public int getStride() {
/* 115 */     return this.stride;
/*     */   }
/*     */   
/*     */   public byte[][] getPalette() {
/* 119 */     return this.palette;
/*     */   }
/*     */   
/*     */   public void setPixelScale(float paramFloat) {
/* 123 */     this.pixelScale = paramFloat;
/*     */   }
/*     */   
/*     */   public float getPixelScale() {
/* 127 */     return this.pixelScale;
/*     */   }
/*     */   
/*     */   public ImageMetadata getMetadata() {
/* 131 */     return this.metadata;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageFrame.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */