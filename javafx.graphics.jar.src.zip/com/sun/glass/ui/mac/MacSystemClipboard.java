/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.SystemClipboard;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.nio.file.FileSystems;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MacSystemClipboard
/*     */   extends SystemClipboard
/*     */ {
/*     */   static final String FILE_SCHEME = "file";
/*     */   private static final String BAD_URI_MSG = "bad URI in com.sun.glass.ui.mac.MacSystemClipboard for file: ";
/*     */   private static final String BAD_URL_MSG = "bad URL in com.sun.glass.ui.mac.MacSystemClipboard for file: ";
/*     */   static final boolean SUPPORT_10_5_API = true;
/*     */   static final boolean SUPPORT_10_5_API_FORCE = false;
/*     */   static final boolean SUPPORT_10_6_API = false;
/*  58 */   long seed = 0L;
/*     */   final MacPasteboard pasteboard;
/*     */   
/*     */   public MacSystemClipboard(String paramString) {
/*  62 */     super(paramString);
/*  63 */     switch (paramString) {
/*     */       case "DND":
/*  65 */         this.pasteboard = new MacPasteboard(2);
/*     */         return;
/*     */       case "SYSTEM":
/*  68 */         this.pasteboard = new MacPasteboard(1);
/*     */         return;
/*     */     } 
/*  71 */     this.pasteboard = new MacPasteboard(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOwner() {
/*  78 */     return (this.seed == this.pasteboard.getSeed());
/*     */   }
/*     */ 
/*     */   
/*     */   protected int supportedSourceActionsFromSystem() {
/*  83 */     return this.pasteboard.getAllowedOperation();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pushTargetActionToSystem(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void pushToSystem(HashMap<String, Object> paramHashMap, int paramInt) {
/*  93 */     HashMap<Object, Object> hashMap = null;
/*  94 */     HashMap[] arrayOfHashMap = null;
/*     */     
/*  96 */     for (String str : paramHashMap.keySet()) {
/*  97 */       Object object = paramHashMap.get(str);
/*  98 */       if (object != null) {
/*  99 */         List<HashMap<String, Object>> list; Pixels pixels; String[] arrayOfString; StringBuilder stringBuilder; byte b; switch (str) {
/*     */           
/*     */           case "text/uri-list":
/* 102 */             list = putToItemList(((String)object).split("\n"), true);
/* 103 */             if (!list.isEmpty()) {
/* 104 */               arrayOfHashMap = new HashMap[list.size()];
/* 105 */               list.toArray(arrayOfHashMap);
/*     */             } 
/*     */             continue;
/*     */ 
/*     */           
/*     */           case "application/x-java-rawimage":
/*     */           case "application/x-java-drag-image":
/* 112 */             list = null;
/* 113 */             if (object instanceof Pixels) {
/* 114 */               pixels = (Pixels)object;
/* 115 */             } else if (object instanceof ByteBuffer) {
/*     */               try {
/* 117 */                 ByteBuffer byteBuffer = (ByteBuffer)object;
/* 118 */                 byteBuffer.rewind();
/* 119 */                 pixels = Application.GetApplication().createPixels(byteBuffer.getInt(), byteBuffer.getInt(), byteBuffer.slice());
/* 120 */               } catch (Exception exception) {}
/*     */             
/*     */             }
/* 123 */             else if (object instanceof IntBuffer) {
/*     */               try {
/* 125 */                 IntBuffer intBuffer = (IntBuffer)object;
/* 126 */                 intBuffer.rewind();
/* 127 */                 pixels = Application.GetApplication().createPixels(intBuffer.get(), intBuffer.get(), intBuffer.slice());
/* 128 */               } catch (Exception exception) {}
/*     */             }
/*     */             else {
/*     */               
/* 132 */               throw new RuntimeException(object.getClass().getName() + " cannot be converted to Pixels");
/*     */             } 
/* 134 */             if (pixels != null) {
/* 135 */               if (hashMap == null) {
/* 136 */                 hashMap = new HashMap<>();
/*     */               }
/* 138 */               hashMap.put(FormatEncoder.mimeToUtf(str), pixels);
/*     */             } 
/*     */             continue;
/*     */ 
/*     */           
/*     */           case "text/plain":
/*     */           case "text/html":
/*     */           case "text/rtf":
/* 146 */             if (object instanceof String) {
/* 147 */               String str1 = (String)object;
/* 148 */               if (hashMap == null) {
/* 149 */                 hashMap = new HashMap<>();
/*     */               }
/* 151 */               hashMap.put(FormatEncoder.mimeToUtf(str), str1);
/*     */               
/*     */               continue;
/*     */             } 
/*     */             
/* 156 */             System.err.println("DelayedCallback not implemented yet: RT-14593");
/* 157 */             Thread.dumpStack();
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case "application/x-java-file-list":
/* 165 */             arrayOfString = (String[])object;
/* 166 */             if (paramHashMap.get("text/uri-list") == null) {
/*     */               
/* 168 */               List<HashMap<String, Object>> list1 = putToItemList(arrayOfString, true);
/* 169 */               if (!list1.isEmpty()) {
/* 170 */                 arrayOfHashMap = new HashMap[list1.size()];
/* 171 */                 list1.toArray(arrayOfHashMap);
/*     */               } 
/*     */               continue;
/*     */             } 
/* 175 */             if (hashMap == null) {
/* 176 */               hashMap = new HashMap<>();
/*     */             }
/* 178 */             stringBuilder = null;
/* 179 */             for (b = 0; b < arrayOfString.length; b++) {
/* 180 */               String str1 = arrayOfString[b];
/* 181 */               String str2 = FileSystems.getDefault().getPath(str1, new String[0]).toUri().toASCIIString();
/* 182 */               if (stringBuilder == null) {
/* 183 */                 stringBuilder = new StringBuilder();
/*     */               }
/* 185 */               stringBuilder.append(str2);
/* 186 */               if (b < arrayOfString.length - 1) {
/* 187 */                 stringBuilder.append("\n");
/*     */               }
/*     */             } 
/* 190 */             if (stringBuilder == null || 
/* 191 */               hashMap.get("public.utf8-plain-text") != null)
/* 192 */               continue;  hashMap.remove("public.utf8-plain-text");
/* 193 */             hashMap.put("public.utf8-plain-text", stringBuilder.toString());
/*     */             continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 203 */         if (hashMap == null) {
/* 204 */           hashMap = new HashMap<>();
/*     */         }
/* 206 */         hashMap.put(FormatEncoder.mimeToUtf(str), serialize(object));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     if (hashMap != null) {
/* 214 */       if (arrayOfHashMap == null || arrayOfHashMap.length == 0) {
/* 215 */         arrayOfHashMap = new HashMap[1];
/* 216 */         arrayOfHashMap[0] = hashMap;
/*     */       } else {
/* 218 */         arrayOfHashMap[0].putAll(hashMap);
/*     */       } 
/*     */     }
/*     */     
/* 222 */     if (arrayOfHashMap != null) {
/* 223 */       this.seed = this.pasteboard.putItems((HashMap<String, Object>[])arrayOfHashMap, paramInt);
/*     */     }
/*     */   }
/*     */   
/*     */   protected Object popFromSystem(String paramString) {
/*     */     byte b2;
/* 229 */     String arrayOfString1[], arrayOfString[][] = this.pasteboard.getUTFs();
/*     */     
/* 231 */     if (arrayOfString == null) {
/* 232 */       return null;
/*     */     }
/* 234 */     switch (paramString) {
/*     */       
/*     */       case "application/x-java-rawimage":
/* 237 */         arrayList = new ArrayList();
/* 238 */         for (b2 = 0; b2 < arrayOfString.length; b2++) {
/* 239 */           byte[] arrayOfByte = this.pasteboard.getItemAsRawImage(b2);
/* 240 */           if (arrayOfByte != null) {
/* 241 */             Pixels pixels = getPixelsForRawImage(arrayOfByte);
/* 242 */             arrayList.add(pixels);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 248 */         return getObjectFromList(arrayList);
/*     */ 
/*     */       
/*     */       case "text/plain":
/*     */       case "text/html":
/*     */       case "text/rtf":
/*     */       case "text/uri-list":
/* 255 */         arrayList = new ArrayList<>();
/* 256 */         for (b2 = 0; b2 < arrayOfString.length; b2++) {
/* 257 */           String str = this.pasteboard.getItemStringForUTF(b2, FormatEncoder.mimeToUtf(paramString));
/* 258 */           if (str != null) {
/* 259 */             arrayList.add(str);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         
/* 265 */         return getObjectFromList(arrayList);
/*     */ 
/*     */ 
/*     */       
/*     */       case "application/x-java-file-list":
/* 270 */         arrayList = new ArrayList<>();
/* 271 */         for (b2 = 0; b2 < arrayOfString.length; b2++) {
/* 272 */           String str = this.pasteboard.getItemStringForUTF(b2, "public.file-url");
/* 273 */           if (str != null) {
/* 274 */             arrayList.add(_convertFileReferencePath(str));
/*     */           }
/*     */         } 
/* 277 */         arrayOfString1 = null;
/* 278 */         if (arrayList.size() > 0) {
/* 279 */           arrayOfString1 = new String[arrayList.size()];
/* 280 */           arrayList.toArray(arrayOfString1);
/*     */         } 
/* 282 */         return arrayOfString1;
/*     */     } 
/*     */ 
/*     */     
/* 286 */     ArrayList<Pixels> arrayList = new ArrayList<>();
/* 287 */     for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 288 */       byte[] arrayOfByte = this.pasteboard.getItemBytesForUTF(b1, FormatEncoder.mimeToUtf(paramString));
/* 289 */       if (arrayOfByte != null) {
/*     */ 
/*     */         
/* 292 */         ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte);
/* 293 */         arrayList.add(byteBuffer);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 299 */     return getObjectFromList(arrayList);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getObjectFromList(List<?> paramList) {
/* 305 */     if (paramList.size() > 0)
/*     */     {
/* 307 */       return paramList.get(0);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] mimesFromSystem() {
/* 317 */     String[][] arrayOfString = this.pasteboard.getUTFs();
/* 318 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 320 */     if (arrayOfString != null) {
/* 321 */       for (String[] arrayOfString2 : arrayOfString) {
/* 322 */         if (arrayOfString2 != null) {
/* 323 */           for (String str1 : arrayOfString2) {
/* 324 */             String str2 = FormatEncoder.utfToMime(str1);
/* 325 */             if (str2 != null && !arrayList.contains(str2)) {
/* 326 */               arrayList.add(str2);
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 332 */     String[] arrayOfString1 = new String[arrayList.size()];
/* 333 */     arrayList.toArray(arrayOfString1);
/* 334 */     return arrayOfString1;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 338 */     return "Mac OS X " + this.pasteboard.getName() + " Clipboard";
/*     */   }
/*     */   
/*     */   private static class FormatEncoder
/*     */   {
/*     */     private static final String DYNAMIC_UTI_PREFIX = "dyn.";
/* 344 */     private static final Map<String, String> utm = new HashMap<>();
/* 345 */     private static final Map<String, String> mtu = new HashMap<>();
/*     */     
/*     */     static {
/* 348 */       utm.put("public.utf8-plain-text", "text/plain");
/* 349 */       utm.put("public.html", "text/html");
/* 350 */       utm.put("public.rtf", "text/rtf");
/* 351 */       utm.put("public.url", "text/uri-list");
/* 352 */       utm.put("public.file-url", "application/x-java-file-list");
/* 353 */       utm.put("public.tiff", "application/x-java-rawimage");
/* 354 */       utm.put("public.png", "application/x-java-rawimage");
/* 355 */       utm.put("application.x-java-rawimage", "application/x-java-rawimage");
/* 356 */       utm.put("application.x-java-drag-image", "application/x-java-drag-image");
/* 357 */       utm.put("application.x-java-drag-image-offset", "application/x-java-drag-image-offset");
/*     */       
/* 359 */       mtu.put("text/plain", "public.utf8-plain-text");
/* 360 */       mtu.put("text/html", "public.html");
/* 361 */       mtu.put("text/rtf", "public.rtf");
/* 362 */       mtu.put("text/uri-list", "public.url");
/* 363 */       mtu.put("application/x-java-file-list", "public.file-url");
/* 364 */       mtu.put("application/x-java-rawimage", "application.x-java-rawimage");
/* 365 */       mtu.put("application/x-java-drag-image", "application.x-java-drag-image");
/* 366 */       mtu.put("application/x-java-drag-image-offset", "application.x-java-drag-image-offset");
/*     */     }
/*     */     
/*     */     public static synchronized String mimeToUtf(String param1String) {
/* 370 */       if (mtu.containsKey(param1String)) {
/* 371 */         return mtu.get(param1String);
/*     */       }
/* 373 */       String str = _convertMIMEtoUTI(param1String);
/* 374 */       mtu.put(param1String, str);
/* 375 */       utm.put(str, param1String);
/* 376 */       return str;
/*     */     }
/*     */     
/*     */     public static synchronized String utfToMime(String param1String) {
/* 380 */       if (utm.containsKey(param1String)) {
/* 381 */         return utm.get(param1String);
/*     */       }
/* 383 */       if (param1String.startsWith("dyn.")) {
/* 384 */         String str = _convertUTItoMIME(param1String);
/* 385 */         mtu.put(str, param1String);
/* 386 */         utm.put(param1String, str);
/* 387 */         return str;
/*     */       } 
/*     */       
/* 390 */       return null;
/*     */     }
/*     */     
/*     */     private static native String _convertMIMEtoUTI(String param1String);
/*     */     
/*     */     private static native String _convertUTItoMIME(String param1String); }
/*     */   
/*     */   private URI createUri(String paramString1, String paramString2) {
/* 398 */     URI uRI = null;
/*     */     try {
/* 400 */       uRI = new URI(paramString1);
/* 401 */     } catch (URISyntaxException uRISyntaxException) {
/* 402 */       System.err.println(paramString2 + paramString2);
/* 403 */       Thread.dumpStack();
/*     */     } 
/* 405 */     return uRI;
/*     */   }
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> getItemFromURIString(String paramString) {
/* 410 */     String str1, str2 = null;
/* 411 */     if (paramString.indexOf(':') == -1) {
/*     */       
/* 413 */       str1 = "public.file-url";
/* 414 */       str2 = FileSystems.getDefault().getPath(paramString, new String[0]).toUri().toASCIIString();
/*     */     }
/*     */     else {
/*     */       
/* 418 */       str1 = "public.url";
/* 419 */       URI uRI = createUri(paramString, "bad URI in com.sun.glass.ui.mac.MacSystemClipboard for file: ");
/* 420 */       if (uRI != null) {
/* 421 */         str2 = uRI.toASCIIString();
/*     */       }
/*     */     } 
/* 424 */     if (str2 != null) {
/* 425 */       HashMap<Object, Object> hashMap = new HashMap<>();
/* 426 */       hashMap.put(str1, str2);
/* 427 */       return (HashMap)hashMap;
/*     */     } 
/* 429 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<HashMap<String, Object>> putToItemList(String[] paramArrayOfString, boolean paramBoolean) {
/* 435 */     ArrayList<HashMap<String, Object>> arrayList = new ArrayList();
/* 436 */     for (String str : paramArrayOfString) {
/* 437 */       if (!paramBoolean || !str.startsWith("#")) {
/*     */         
/* 439 */         HashMap<String, Object> hashMap = getItemFromURIString(str);
/* 440 */         if (hashMap != null) {
/* 441 */           arrayList.add(hashMap);
/*     */         }
/*     */       } 
/*     */     } 
/* 445 */     return arrayList;
/*     */   }
/*     */   
/*     */   private static native String _convertFileReferencePath(String paramString);
/*     */   
/*     */   private byte[] serialize(Object paramObject) {
/* 451 */     if (paramObject instanceof String) {
/* 452 */       String str = (String)paramObject;
/* 453 */       return str.getBytes();
/* 454 */     }  if (paramObject instanceof ByteBuffer) {
/* 455 */       ByteBuffer byteBuffer = (ByteBuffer)paramObject;
/* 456 */       return byteBuffer.array();
/*     */     } 
/* 458 */     throw new RuntimeException("can not handle " + paramObject);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacSystemClipboard.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */