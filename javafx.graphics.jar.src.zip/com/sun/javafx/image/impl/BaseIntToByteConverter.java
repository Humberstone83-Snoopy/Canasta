/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.IntPixelGetter;
/*     */ import com.sun.javafx.image.IntToBytePixelConverter;
/*     */ import com.sun.javafx.image.PixelGetter;
/*     */ import com.sun.javafx.image.PixelSetter;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseIntToByteConverter
/*     */   implements IntToBytePixelConverter
/*     */ {
/*     */   protected final IntPixelGetter getter;
/*     */   protected final BytePixelSetter setter;
/*     */   protected final int nDstElems;
/*     */   
/*     */   BaseIntToByteConverter(IntPixelGetter paramIntPixelGetter, BytePixelSetter paramBytePixelSetter) {
/*  42 */     this.getter = paramIntPixelGetter;
/*  43 */     this.setter = paramBytePixelSetter;
/*  44 */     this.nDstElems = paramBytePixelSetter.getNumElements();
/*     */   }
/*     */ 
/*     */   
/*     */   public final IntPixelGetter getGetter() {
/*  49 */     return this.getter;
/*     */   }
/*     */ 
/*     */   
/*     */   public final BytePixelSetter getSetter() {
/*  54 */     return this.setter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  70 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  71 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/*  74 */       paramInt5 *= paramInt6;
/*  75 */       paramInt6 = 1;
/*     */     } 
/*  77 */     doConvert(paramArrayOfint, paramInt1, paramInt2, paramArrayOfbyte, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  87 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/*  88 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/*  91 */       paramInt5 *= paramInt6;
/*  92 */       paramInt6 = 1;
/*     */     } 
/*  94 */     if (paramIntBuffer.hasArray() && paramByteBuffer.hasArray()) {
/*  95 */       paramInt1 += paramIntBuffer.arrayOffset();
/*  96 */       paramInt3 += paramByteBuffer.arrayOffset();
/*  97 */       doConvert(paramIntBuffer.array(), paramInt1, paramInt2, paramByteBuffer
/*  98 */           .array(), paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } else {
/*     */       
/* 101 */       doConvert(paramIntBuffer, paramInt1, paramInt2, paramByteBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 112 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 113 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/* 116 */       paramInt5 *= paramInt6;
/* 117 */       paramInt6 = 1;
/*     */     } 
/* 119 */     if (paramIntBuffer.hasArray()) {
/* 120 */       int[] arrayOfInt = paramIntBuffer.array();
/* 121 */       paramInt1 += paramIntBuffer.arrayOffset();
/* 122 */       doConvert(arrayOfInt, paramInt1, paramInt2, paramArrayOfbyte, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 126 */       ByteBuffer byteBuffer = ByteBuffer.wrap(paramArrayOfbyte);
/* 127 */       doConvert(paramIntBuffer, paramInt1, paramInt2, byteBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 138 */     if (paramInt5 <= 0 || paramInt6 <= 0)
/* 139 */       return;  if (paramInt2 == paramInt5 && paramInt4 == paramInt5 * this.nDstElems) {
/*     */ 
/*     */       
/* 142 */       paramInt5 *= paramInt6;
/* 143 */       paramInt6 = 1;
/*     */     } 
/* 145 */     if (paramByteBuffer.hasArray()) {
/* 146 */       byte[] arrayOfByte = paramByteBuffer.array();
/* 147 */       paramInt3 += paramByteBuffer.arrayOffset();
/* 148 */       doConvert(paramArrayOfint, paramInt1, paramInt2, arrayOfByte, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     }
/*     */     else {
/*     */       
/* 152 */       IntBuffer intBuffer = IntBuffer.wrap(paramArrayOfint);
/* 153 */       doConvert(intBuffer, paramInt1, paramInt2, paramByteBuffer, paramInt3, paramInt4, paramInt5, paramInt6);
/*     */     } 
/*     */   }
/*     */   
/*     */   abstract void doConvert(int[] paramArrayOfint, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */   
/*     */   abstract void doConvert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\BaseIntToByteConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */