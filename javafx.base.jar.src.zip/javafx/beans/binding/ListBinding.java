/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.BindingHelperObserver;
/*     */ import com.sun.javafx.binding.ListExpressionHelper;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListBinding<E>
/*     */   extends ListExpression<E>
/*     */   implements Binding<ObservableList<E>>
/*     */ {
/*  67 */   private final ListChangeListener<E> listChangeListener = new ListChangeListener<E>()
/*     */     {
/*     */       public void onChanged(ListChangeListener.Change<? extends E> param1Change) {
/*  70 */         ListBinding.this.invalidateProperties();
/*  71 */         ListBinding.this.onInvalidating();
/*  72 */         ListExpressionHelper.fireValueChangedEvent(ListBinding.this.helper, param1Change);
/*     */       }
/*     */     };
/*     */   
/*     */   private ObservableList<E> value;
/*     */   private boolean valid = false;
/*     */   private BindingHelperObserver observer;
/*  79 */   private ListExpressionHelper<E> helper = null;
/*     */   
/*     */   private SizeProperty size0;
/*     */   
/*     */   private EmptyProperty empty0;
/*     */   
/*     */   public ReadOnlyIntegerProperty sizeProperty() {
/*  86 */     if (this.size0 == null) {
/*  87 */       this.size0 = new SizeProperty();
/*     */     }
/*  89 */     return this.size0;
/*     */   }
/*     */   
/*     */   private class SizeProperty
/*     */     extends ReadOnlyIntegerPropertyBase {
/*     */     public int get() {
/*  95 */       return ListBinding.this.size();
/*     */     }
/*     */     private SizeProperty() {}
/*     */     
/*     */     public Object getBean() {
/* 100 */       return ListBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 105 */       return "size";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 109 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadOnlyBooleanProperty emptyProperty() {
/* 115 */     if (this.empty0 == null) {
/* 116 */       this.empty0 = new EmptyProperty();
/*     */     }
/* 118 */     return this.empty0;
/*     */   }
/*     */   
/*     */   private class EmptyProperty extends ReadOnlyBooleanPropertyBase {
/*     */     private EmptyProperty() {}
/*     */     
/*     */     public boolean get() {
/* 125 */       return ListBinding.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean() {
/* 130 */       return ListBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 135 */       return "empty";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 139 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 145 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 150 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ChangeListener<? super ObservableList<E>> paramChangeListener) {
/* 155 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener) {
/* 160 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ListChangeListener<? super E> paramListChangeListener) {
/* 165 */     this.helper = ListExpressionHelper.addListener(this.helper, this, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ListChangeListener<? super E> paramListChangeListener) {
/* 170 */     this.helper = ListExpressionHelper.removeListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void bind(Observable... paramVarArgs) {
/* 181 */     if (paramVarArgs != null && paramVarArgs.length > 0) {
/* 182 */       if (this.observer == null) {
/* 183 */         this.observer = new BindingHelperObserver(this);
/*     */       }
/* 185 */       for (Observable observable : paramVarArgs) {
/* 186 */         if (observable != null) {
/* 187 */           observable.addListener(this.observer);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unbind(Observable... paramVarArgs) {
/* 200 */     if (this.observer != null) {
/* 201 */       for (Observable observable : paramVarArgs) {
/* 202 */         if (observable != null) {
/* 203 */           observable.removeListener(this.observer);
/*     */         }
/*     */       } 
/* 206 */       this.observer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<?> getDependencies() {
/* 225 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<E> get() {
/* 238 */     if (!this.valid) {
/* 239 */       this.value = computeValue();
/* 240 */       this.valid = true;
/* 241 */       if (this.value != null) {
/* 242 */         this.value.addListener(this.listChangeListener);
/*     */       }
/*     */     } 
/* 245 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInvalidating() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateProperties() {
/* 257 */     if (this.size0 != null) {
/* 258 */       this.size0.fireValueChangedEvent();
/*     */     }
/* 260 */     if (this.empty0 != null) {
/* 261 */       this.empty0.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void invalidate() {
/* 267 */     if (this.valid) {
/* 268 */       if (this.value != null) {
/* 269 */         this.value.removeListener(this.listChangeListener);
/*     */       }
/* 271 */       this.valid = false;
/* 272 */       invalidateProperties();
/* 273 */       onInvalidating();
/* 274 */       ListExpressionHelper.fireValueChangedEvent(this.helper);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isValid() {
/* 280 */     return this.valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 299 */     return this.valid ? ("ListBinding [value: " + get() + "]") : 
/* 300 */       "ListBinding [invalid]";
/*     */   }
/*     */   
/*     */   protected abstract ObservableList<E> computeValue();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\ListBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */