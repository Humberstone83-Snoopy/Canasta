/*     */ package com.sun.media.jfxmediaimpl.platform.gstreamer;
/*     */ 
/*     */ import com.sun.media.jfxmedia.MediaError;
/*     */ import com.sun.media.jfxmedia.MediaException;
/*     */ import com.sun.media.jfxmedia.control.MediaPlayerOverlay;
/*     */ import com.sun.media.jfxmedia.effects.AudioEqualizer;
/*     */ import com.sun.media.jfxmedia.effects.AudioSpectrum;
/*     */ import com.sun.media.jfxmedia.locator.Locator;
/*     */ import com.sun.media.jfxmediaimpl.NativeMediaPlayer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class GSTMediaPlayer
/*     */   extends NativeMediaPlayer
/*     */ {
/*  40 */   private GSTMedia gstMedia = null;
/*  41 */   private float mutedVolume = 1.0F;
/*     */   private boolean muteEnabled = false;
/*     */   private AudioEqualizer audioEqualizer;
/*     */   private AudioSpectrum audioSpectrum;
/*     */   
/*     */   private GSTMediaPlayer(GSTMedia paramGSTMedia) {
/*  47 */     super(paramGSTMedia);
/*  48 */     init();
/*  49 */     this.gstMedia = paramGSTMedia;
/*     */     
/*  51 */     int i = gstInitPlayer(this.gstMedia.getNativeMediaRef());
/*  52 */     if (0 != i) {
/*  53 */       dispose();
/*  54 */       throwMediaErrorException(i, (String)null);
/*     */     } 
/*     */     
/*  57 */     long l = this.gstMedia.getNativeMediaRef();
/*  58 */     this.audioSpectrum = createNativeAudioSpectrum(gstGetAudioSpectrum(l));
/*  59 */     this.audioEqualizer = createNativeAudioEqualizer(gstGetAudioEqualizer(l));
/*     */   }
/*     */   
/*     */   GSTMediaPlayer(Locator paramLocator) {
/*  63 */     this(new GSTMedia(paramLocator));
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioEqualizer getEqualizer() {
/*  68 */     return this.audioEqualizer;
/*     */   }
/*     */ 
/*     */   
/*     */   public AudioSpectrum getAudioSpectrum() {
/*  73 */     return this.audioSpectrum;
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaPlayerOverlay getMediaPlayerOverlay() {
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwMediaErrorException(int paramInt, String paramString) throws MediaException {
/*  85 */     MediaError mediaError = MediaError.getFromCode(paramInt);
/*  86 */     throw new MediaException(paramString, null, mediaError);
/*     */   }
/*     */ 
/*     */   
/*     */   protected long playerGetAudioSyncDelay() throws MediaException {
/*  91 */     long[] arrayOfLong = new long[1];
/*  92 */     int i = gstGetAudioSyncDelay(this.gstMedia.getNativeMediaRef(), arrayOfLong);
/*  93 */     if (0 != i) {
/*  94 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*  96 */     return arrayOfLong[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetAudioSyncDelay(long paramLong) throws MediaException {
/* 101 */     int i = gstSetAudioSyncDelay(this.gstMedia.getNativeMediaRef(), paramLong);
/* 102 */     if (0 != i) {
/* 103 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerPlay() throws MediaException {
/* 109 */     int i = gstPlay(this.gstMedia.getNativeMediaRef());
/* 110 */     if (0 != i) {
/* 111 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerStop() throws MediaException {
/* 117 */     int i = gstStop(this.gstMedia.getNativeMediaRef());
/* 118 */     if (0 != i) {
/* 119 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerPause() throws MediaException {
/* 125 */     int i = gstPause(this.gstMedia.getNativeMediaRef());
/* 126 */     if (0 != i) {
/* 127 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerFinish() throws MediaException {
/* 133 */     int i = gstFinish(this.gstMedia.getNativeMediaRef());
/* 134 */     if (0 != i) {
/* 135 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetRate() throws MediaException {
/* 141 */     float[] arrayOfFloat = new float[1];
/* 142 */     int i = gstGetRate(this.gstMedia.getNativeMediaRef(), arrayOfFloat);
/* 143 */     if (0 != i) {
/* 144 */       throwMediaErrorException(i, (String)null);
/*     */     }
/* 146 */     return arrayOfFloat[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetRate(float paramFloat) throws MediaException {
/* 151 */     int i = gstSetRate(this.gstMedia.getNativeMediaRef(), paramFloat);
/* 152 */     if (0 != i) {
/* 153 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double playerGetPresentationTime() throws MediaException {
/* 159 */     double[] arrayOfDouble = new double[1];
/* 160 */     int i = gstGetPresentationTime(this.gstMedia.getNativeMediaRef(), arrayOfDouble);
/* 161 */     if (0 != i) {
/* 162 */       throwMediaErrorException(i, (String)null);
/*     */     }
/* 164 */     return arrayOfDouble[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean playerGetMute() throws MediaException {
/* 169 */     return this.muteEnabled;
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void playerSetMute(boolean paramBoolean) throws MediaException {
/* 174 */     if (paramBoolean != this.muteEnabled) {
/* 175 */       if (paramBoolean) {
/*     */         
/* 177 */         float f = getVolume();
/*     */ 
/*     */         
/* 180 */         playerSetVolume(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 185 */         this.muteEnabled = true;
/*     */ 
/*     */         
/* 188 */         this.mutedVolume = f;
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 194 */         this.muteEnabled = false;
/*     */ 
/*     */         
/* 197 */         playerSetVolume(this.mutedVolume);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetVolume() throws MediaException {
/* 204 */     synchronized (this) {
/* 205 */       if (this.muteEnabled)
/* 206 */         return this.mutedVolume; 
/*     */     } 
/* 208 */     float[] arrayOfFloat = new float[1];
/* 209 */     int i = gstGetVolume(this.gstMedia.getNativeMediaRef(), arrayOfFloat);
/* 210 */     if (0 != i) {
/* 211 */       throwMediaErrorException(i, (String)null);
/*     */     }
/* 213 */     return arrayOfFloat[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void playerSetVolume(float paramFloat) throws MediaException {
/* 218 */     if (!this.muteEnabled) {
/* 219 */       int i = gstSetVolume(this.gstMedia.getNativeMediaRef(), paramFloat);
/* 220 */       if (0 != i) {
/* 221 */         throwMediaErrorException(i, (String)null);
/*     */       } else {
/* 223 */         this.mutedVolume = paramFloat;
/*     */       } 
/*     */     } else {
/* 226 */       this.mutedVolume = paramFloat;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected float playerGetBalance() throws MediaException {
/* 232 */     float[] arrayOfFloat = new float[1];
/* 233 */     int i = gstGetBalance(this.gstMedia.getNativeMediaRef(), arrayOfFloat);
/* 234 */     if (0 != i) {
/* 235 */       throwMediaErrorException(i, (String)null);
/*     */     }
/* 237 */     return arrayOfFloat[0];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void playerSetBalance(float paramFloat) throws MediaException {
/* 242 */     int i = gstSetBalance(this.gstMedia.getNativeMediaRef(), paramFloat);
/* 243 */     if (0 != i) {
/* 244 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected double playerGetDuration() throws MediaException {
/* 250 */     double[] arrayOfDouble = new double[1];
/* 251 */     int i = gstGetDuration(this.gstMedia.getNativeMediaRef(), arrayOfDouble);
/* 252 */     if (0 != i) {
/* 253 */       throwMediaErrorException(i, (String)null);
/*     */     }
/* 255 */     if (arrayOfDouble[0] == -1.0D) {
/* 256 */       return Double.POSITIVE_INFINITY;
/*     */     }
/* 258 */     return arrayOfDouble[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void playerSeek(double paramDouble) throws MediaException {
/* 264 */     int i = gstSeek(this.gstMedia.getNativeMediaRef(), paramDouble);
/* 265 */     if (0 != i) {
/* 266 */       throwMediaErrorException(i, (String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void playerInit() throws MediaException {}
/*     */ 
/*     */   
/*     */   protected void playerDispose() {
/* 276 */     this.audioEqualizer = null;
/* 277 */     this.audioSpectrum = null;
/* 278 */     this.gstMedia = null;
/*     */   }
/*     */   
/*     */   private native int gstInitPlayer(long paramLong);
/*     */   
/*     */   private native long gstGetAudioEqualizer(long paramLong);
/*     */   
/*     */   private native long gstGetAudioSpectrum(long paramLong);
/*     */   
/*     */   private native int gstGetAudioSyncDelay(long paramLong, long[] paramArrayOflong);
/*     */   
/*     */   private native int gstSetAudioSyncDelay(long paramLong1, long paramLong2);
/*     */   
/*     */   private native int gstPlay(long paramLong);
/*     */   
/*     */   private native int gstPause(long paramLong);
/*     */   
/*     */   private native int gstStop(long paramLong);
/*     */   
/*     */   private native int gstFinish(long paramLong);
/*     */   
/*     */   private native int gstGetRate(long paramLong, float[] paramArrayOffloat);
/*     */   
/*     */   private native int gstSetRate(long paramLong, float paramFloat);
/*     */   
/*     */   private native int gstGetPresentationTime(long paramLong, double[] paramArrayOfdouble);
/*     */   
/*     */   private native int gstGetVolume(long paramLong, float[] paramArrayOffloat);
/*     */   
/*     */   private native int gstSetVolume(long paramLong, float paramFloat);
/*     */   
/*     */   private native int gstGetBalance(long paramLong, float[] paramArrayOffloat);
/*     */   
/*     */   private native int gstSetBalance(long paramLong, float paramFloat);
/*     */   
/*     */   private native int gstGetDuration(long paramLong, double[] paramArrayOfdouble);
/*     */   
/*     */   private native int gstSeek(long paramLong, double paramDouble);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmediaimpl\platform\gstreamer\GSTMediaPlayer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */