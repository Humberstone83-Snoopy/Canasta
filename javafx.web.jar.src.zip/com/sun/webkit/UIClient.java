package com.sun.webkit;

import com.sun.webkit.graphics.WCImage;
import com.sun.webkit.graphics.WCRectangle;

public interface UIClient {
  WebPage createPage(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4);
  
  void closePage();
  
  void showView();
  
  WCRectangle getViewBounds();
  
  void setViewBounds(WCRectangle paramWCRectangle);
  
  void setStatusbarText(String paramString);
  
  void alert(String paramString);
  
  boolean confirm(String paramString);
  
  String prompt(String paramString1, String paramString2);
  
  boolean canRunBeforeUnloadConfirmPanel();
  
  boolean runBeforeUnloadConfirmPanel(String paramString);
  
  String[] chooseFile(String paramString1, boolean paramBoolean, String paramString2);
  
  void print();
  
  void startDrag(WCImage paramWCImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String[] paramArrayOfString, Object[] paramArrayOfObject, boolean paramBoolean);
  
  void confirmStartDrag();
  
  boolean isDragConfirmed();
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\UIClient.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */