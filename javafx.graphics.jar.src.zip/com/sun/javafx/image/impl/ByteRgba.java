/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteRgba
/*     */ {
/*  39 */   public static final BytePixelGetter getter = Accessor.instance;
/*  40 */   public static final BytePixelSetter setter = Accessor.instance;
/*  41 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   private static ByteToBytePixelConverter ToByteRgbaObj;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteRgbaConverter() {
/*  45 */     if (ToByteRgbaObj == null) {
/*  46 */       ToByteRgbaObj = BaseByteToByteConverter.create(accessor);
/*     */     }
/*  48 */     return ToByteRgbaObj;
/*     */   }
/*     */   private static ByteToBytePixelConverter ToByteBgraObj;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  53 */     if (ToByteBgraObj == null)
/*     */     {
/*  55 */       ToByteBgraObj = BaseByteToByteConverter.createReorderer(getter, ByteBgra.setter, 2, 1, 0, 3);
/*     */     }
/*     */     
/*  58 */     return ToByteBgraObj;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Accessor
/*     */     implements BytePixelAccessor
/*     */   {
/*  66 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  71 */       return AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  76 */       return 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  81 */       return param1ArrayOfbyte[param1Int + 2] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int] & 0xFF) << 16 | param1ArrayOfbyte[param1Int + 3] << 24;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  89 */       return PixelUtils.NonPretoPre(getArgb(param1ArrayOfbyte, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  94 */       return param1ByteBuffer.get(param1Int + 2) & 0xFF | (param1ByteBuffer
/*  95 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/*  96 */         .get(param1Int) & 0xFF) << 16 | param1ByteBuffer
/*  97 */         .get(param1Int + 3) << 24;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 102 */       return PixelUtils.NonPretoPre(getArgb(param1ByteBuffer, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 107 */       param1ArrayOfbyte[param1Int1] = (byte)(param1Int2 >> 16);
/* 108 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)(param1Int2 >> 8);
/* 109 */       param1ArrayOfbyte[param1Int1 + 2] = (byte)param1Int2;
/* 110 */       param1ArrayOfbyte[param1Int1 + 3] = (byte)(param1Int2 >> 24);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 115 */       setArgb(param1ArrayOfbyte, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 120 */       param1ByteBuffer.put(param1Int1, (byte)(param1Int2 >> 16));
/* 121 */       param1ByteBuffer.put(param1Int1 + 1, (byte)(param1Int2 >> 8));
/* 122 */       param1ByteBuffer.put(param1Int1 + 2, (byte)param1Int2);
/* 123 */       param1ByteBuffer.put(param1Int1 + 3, (byte)(param1Int2 >> 24));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 128 */       setArgb(param1ByteBuffer, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgraPreConv extends BaseByteToByteConverter {
/* 133 */     static final ByteToBytePixelConverter instance = new ToByteBgraPreConv();
/*     */ 
/*     */     
/*     */     private ToByteBgraPreConv() {
/* 137 */       super(ByteRgba.getter, ByteBgraPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 145 */       param1Int2 -= param1Int5 * 4;
/* 146 */       param1Int4 -= param1Int5 * 4;
/* 147 */       while (--param1Int6 >= 0) {
/* 148 */         for (byte b = 0; b < param1Int5; b++) {
/* 149 */           byte b1 = param1ArrayOfbyte1[param1Int1++];
/* 150 */           byte b2 = param1ArrayOfbyte1[param1Int1++];
/* 151 */           byte b3 = param1ArrayOfbyte1[param1Int1++];
/* 152 */           int i = param1ArrayOfbyte1[param1Int1++] & 0xFF;
/* 153 */           if (i < 255) {
/* 154 */             if (i == 0) {
/* 155 */               b3 = b2 = b1 = 0;
/*     */             } else {
/* 157 */               b3 = (byte)(((b3 & 0xFF) * i + 127) / 255);
/* 158 */               b2 = (byte)(((b2 & 0xFF) * i + 127) / 255);
/* 159 */               b1 = (byte)(((b1 & 0xFF) * i + 127) / 255);
/*     */             } 
/*     */           }
/* 162 */           param1ArrayOfbyte2[param1Int3++] = b3;
/* 163 */           param1ArrayOfbyte2[param1Int3++] = b2;
/* 164 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 165 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/*     */         } 
/* 167 */         param1Int1 += param1Int2;
/* 168 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 177 */       param1Int2 -= param1Int5 * 4;
/* 178 */       param1Int4 -= param1Int5 * 4;
/* 179 */       while (--param1Int6 >= 0) {
/* 180 */         for (byte b = 0; b < param1Int5; b++) {
/* 181 */           byte b1 = param1ByteBuffer1.get(param1Int1);
/* 182 */           byte b2 = param1ByteBuffer1.get(param1Int1 + 1);
/* 183 */           byte b3 = param1ByteBuffer1.get(param1Int1 + 2);
/* 184 */           int i = param1ByteBuffer1.get(param1Int1 + 3) & 0xFF;
/* 185 */           param1Int1 += 4;
/* 186 */           if (i < 255) {
/* 187 */             if (i == 0) {
/* 188 */               b3 = b2 = b1 = 0;
/*     */             } else {
/* 190 */               b3 = (byte)(((b3 & 0xFF) * i + 127) / 255);
/* 191 */               b2 = (byte)(((b2 & 0xFF) * i + 127) / 255);
/* 192 */               b1 = (byte)(((b1 & 0xFF) * i + 127) / 255);
/*     */             } 
/*     */           }
/* 195 */           param1ByteBuffer2.put(param1Int3, b3);
/* 196 */           param1ByteBuffer2.put(param1Int3 + 1, b2);
/* 197 */           param1ByteBuffer2.put(param1Int3 + 2, b1);
/* 198 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)i);
/* 199 */           param1Int3 += 4;
/*     */         } 
/* 201 */         param1Int1 += param1Int2;
/* 202 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntArgbSameConv extends BaseByteToIntConverter {
/* 208 */     static final ByteToIntPixelConverter nonpremul = new ToIntArgbSameConv(false);
/* 209 */     static final ByteToIntPixelConverter premul = new ToIntArgbSameConv(true);
/*     */     
/*     */     private ToIntArgbSameConv(boolean param1Boolean) {
/* 212 */       super(param1Boolean ? ByteBgraPre.getter : ByteRgba.getter, 
/* 213 */           param1Boolean ? IntArgbPre.setter : IntArgb.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 221 */       param1Int2 -= param1Int5 * 4;
/* 222 */       param1Int4 -= param1Int5;
/* 223 */       while (--param1Int6 >= 0) {
/* 224 */         for (byte b = 0; b < param1Int5; b++) {
/* 225 */           param1ArrayOfint[param1Int3++] = param1ArrayOfbyte[param1Int1++] & 0xFF | (param1ArrayOfbyte[param1Int1++] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int1++] & 0xFF) << 16 | param1ArrayOfbyte[param1Int1++] << 24;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 231 */         param1Int1 += param1Int2;
/* 232 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 241 */       param1Int2 -= param1Int5 * 4;
/* 242 */       while (--param1Int6 >= 0) {
/* 243 */         for (byte b = 0; b < param1Int5; b++) {
/* 244 */           param1IntBuffer.put(param1Int3 + b, param1ByteBuffer
/* 245 */               .get(param1Int1) & 0xFF | (param1ByteBuffer
/* 246 */               .get(param1Int1 + 1) & 0xFF) << 8 | (param1ByteBuffer
/* 247 */               .get(param1Int1 + 2) & 0xFF) << 16 | param1ByteBuffer
/* 248 */               .get(param1Int1 + 3) << 24);
/* 249 */           param1Int1 += 4;
/*     */         } 
/* 251 */         param1Int1 += param1Int2;
/* 252 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntArgbPreConv extends BaseByteToIntConverter {
/* 258 */     public static final ByteToIntPixelConverter instance = new ToIntArgbPreConv();
/*     */ 
/*     */     
/*     */     private ToIntArgbPreConv() {
/* 262 */       super(ByteRgba.getter, IntArgbPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 270 */       param1Int2 -= param1Int5 * 4;
/* 271 */       param1Int4 -= param1Int5;
/* 272 */       while (--param1Int6 >= 0) {
/* 273 */         for (byte b = 0; b < param1Int5; b++) {
/* 274 */           int i = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 275 */           int j = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 276 */           int k = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 277 */           int m = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 278 */           if (m < 255) {
/* 279 */             if (m == 0) {
/* 280 */               i = j = k = 0;
/*     */             } else {
/* 282 */               i = (i * m + 127) / 255;
/* 283 */               j = (j * m + 127) / 255;
/* 284 */               k = (k * m + 127) / 255;
/*     */             } 
/*     */           }
/* 287 */           param1ArrayOfint[param1Int3++] = m << 24 | k << 16 | j << 8 | i;
/*     */         } 
/*     */         
/* 290 */         param1Int3 += param1Int4;
/* 291 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 300 */       param1Int2 -= param1Int5 * 4;
/* 301 */       while (--param1Int6 >= 0) {
/* 302 */         for (byte b = 0; b < param1Int5; b++) {
/* 303 */           int i = param1ByteBuffer.get(param1Int1) & 0xFF;
/* 304 */           int j = param1ByteBuffer.get(param1Int1 + 1) & 0xFF;
/* 305 */           int k = param1ByteBuffer.get(param1Int1 + 2) & 0xFF;
/* 306 */           int m = param1ByteBuffer.get(param1Int1 + 3) & 0xFF;
/* 307 */           param1Int1 += 4;
/* 308 */           if (m < 255) {
/* 309 */             if (m == 0) {
/* 310 */               i = j = k = 0;
/*     */             } else {
/* 312 */               i = (i * m + 127) / 255;
/* 313 */               j = (j * m + 127) / 255;
/* 314 */               k = (k * m + 127) / 255;
/*     */             } 
/*     */           }
/* 317 */           param1IntBuffer.put(param1Int3 + b, m << 24 | k << 16 | j << 8 | i);
/*     */         } 
/* 319 */         param1Int3 += param1Int4;
/* 320 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteRgba.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */