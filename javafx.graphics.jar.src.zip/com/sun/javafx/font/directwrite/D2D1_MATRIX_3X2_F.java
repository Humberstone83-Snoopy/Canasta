/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class D2D1_MATRIX_3X2_F
/*    */ {
/*    */   float _11;
/*    */   float _12;
/*    */   float _21;
/*    */   float _22;
/*    */   float _31;
/*    */   float _32;
/*    */   
/*    */   D2D1_MATRIX_3X2_F() {}
/*    */   
/*    */   D2D1_MATRIX_3X2_F(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 33 */     this._11 = paramFloat1;
/* 34 */     this._12 = paramFloat2;
/* 35 */     this._21 = paramFloat3;
/* 36 */     this._22 = paramFloat4;
/* 37 */     this._31 = paramFloat5;
/* 38 */     this._32 = paramFloat6;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\D2D1_MATRIX_3X2_F.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */