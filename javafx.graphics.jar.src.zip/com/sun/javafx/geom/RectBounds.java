/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RectBounds
/*     */   extends BaseBounds
/*     */ {
/*     */   private float minX;
/*     */   private float maxX;
/*     */   private float minY;
/*     */   private float maxY;
/*     */   
/*     */   public RectBounds() {
/*  47 */     this.minX = this.minY = 0.0F;
/*  48 */     this.maxX = this.maxY = -1.0F;
/*     */   }
/*     */   
/*     */   public BaseBounds copy() {
/*  52 */     return new RectBounds(this.minX, this.minY, this.maxX, this.maxY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  59 */     setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds(RectBounds paramRectBounds) {
/*  66 */     setBounds(paramRectBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds(Rectangle paramRectangle) {
/*  73 */     setBounds(paramRectangle.x, paramRectangle.y, (paramRectangle.x + paramRectangle.width), (paramRectangle.y + paramRectangle.height));
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds.BoundsType getBoundsType() {
/*  78 */     return BaseBounds.BoundsType.RECTANGLE;
/*     */   }
/*     */   
/*     */   public boolean is2D() {
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getWidth() {
/*  90 */     return this.maxX - this.minX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getHeight() {
/*  98 */     return this.maxY - this.minY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDepth() {
/* 107 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float getMinX() {
/* 111 */     return this.minX;
/*     */   }
/*     */   
/*     */   public void setMinX(float paramFloat) {
/* 115 */     this.minX = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMinY() {
/* 119 */     return this.minY;
/*     */   }
/*     */   
/*     */   public void setMinY(float paramFloat) {
/* 123 */     this.minY = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMinZ() {
/* 127 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public float getMaxX() {
/* 131 */     return this.maxX;
/*     */   }
/*     */   
/*     */   public void setMaxX(float paramFloat) {
/* 135 */     this.maxX = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxY() {
/* 139 */     return this.maxY;
/*     */   }
/*     */   
/*     */   public void setMaxY(float paramFloat) {
/* 143 */     this.maxY = paramFloat;
/*     */   }
/*     */   
/*     */   public float getMaxZ() {
/* 147 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public Vec2f getMin(Vec2f paramVec2f) {
/* 151 */     if (paramVec2f == null) {
/* 152 */       paramVec2f = new Vec2f();
/*     */     }
/* 154 */     paramVec2f.x = this.minX;
/* 155 */     paramVec2f.y = this.minY;
/* 156 */     return paramVec2f;
/*     */   }
/*     */   
/*     */   public Vec2f getMax(Vec2f paramVec2f) {
/* 160 */     if (paramVec2f == null) {
/* 161 */       paramVec2f = new Vec2f();
/*     */     }
/* 163 */     paramVec2f.x = this.maxX;
/* 164 */     paramVec2f.y = this.maxY;
/* 165 */     return paramVec2f;
/*     */   }
/*     */   
/*     */   public Vec3f getMin(Vec3f paramVec3f) {
/* 169 */     if (paramVec3f == null) {
/* 170 */       paramVec3f = new Vec3f();
/*     */     }
/* 172 */     paramVec3f.x = this.minX;
/* 173 */     paramVec3f.y = this.minY;
/* 174 */     paramVec3f.z = 0.0F;
/* 175 */     return paramVec3f;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3f getMax(Vec3f paramVec3f) {
/* 180 */     if (paramVec3f == null) {
/* 181 */       paramVec3f = new Vec3f();
/*     */     }
/* 183 */     paramVec3f.x = this.maxX;
/* 184 */     paramVec3f.y = this.maxY;
/* 185 */     paramVec3f.z = 0.0F;
/* 186 */     return paramVec3f;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithUnion(BaseBounds paramBaseBounds) {
/* 191 */     if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE)
/* 192 */     { RectBounds rectBounds = (RectBounds)paramBaseBounds;
/* 193 */       unionWith(rectBounds); }
/* 194 */     else { if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.BOX) {
/* 195 */         BoxBounds boxBounds = new BoxBounds((BoxBounds)paramBaseBounds);
/* 196 */         boxBounds.unionWith(this);
/* 197 */         return boxBounds;
/*     */       } 
/* 199 */       throw new UnsupportedOperationException("Unknown BoundsType"); }
/*     */     
/* 201 */     return this;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(Rectangle paramRectangle) {
/* 205 */     if (paramRectangle.width < 0 || paramRectangle.height < 0) return makeEmpty(); 
/* 206 */     setBounds(paramRectangle.x, paramRectangle.y, (paramRectangle.x + paramRectangle.width), (paramRectangle.y + paramRectangle.height));
/*     */     
/* 208 */     return this;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(BaseBounds paramBaseBounds) {
/* 212 */     if (paramBaseBounds.isEmpty()) return makeEmpty(); 
/* 213 */     if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.RECTANGLE)
/* 214 */     { RectBounds rectBounds = (RectBounds)paramBaseBounds;
/* 215 */       this.minX = rectBounds.getMinX();
/* 216 */       this.minY = rectBounds.getMinY();
/* 217 */       this.maxX = rectBounds.getMaxX();
/* 218 */       this.maxY = rectBounds.getMaxY(); }
/* 219 */     else { if (paramBaseBounds.getBoundsType() == BaseBounds.BoundsType.BOX) {
/* 220 */         return new BoxBounds((BoxBounds)paramBaseBounds);
/*     */       }
/* 222 */       throw new UnsupportedOperationException("Unknown BoundsType"); }
/*     */     
/* 224 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithNewBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 229 */     if (paramFloat4 < paramFloat1 || paramFloat5 < paramFloat2 || paramFloat6 < paramFloat3) return makeEmpty(); 
/* 230 */     if (paramFloat3 == 0.0F && paramFloat6 == 0.0F) {
/* 231 */       this.minX = paramFloat1;
/* 232 */       this.minY = paramFloat2;
/* 233 */       this.maxX = paramFloat4;
/* 234 */       this.maxY = paramFloat5;
/* 235 */       return this;
/*     */     } 
/* 237 */     return new BoxBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseBounds deriveWithNewBoundsAndSort(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 242 */     if (paramFloat3 == 0.0F && paramFloat6 == 0.0F) {
/* 243 */       setBoundsAndSort(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 244 */       return this;
/*     */     } 
/*     */     
/* 247 */     BoxBounds boxBounds = new BoxBounds();
/* 248 */     boxBounds.setBoundsAndSort(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/* 249 */     return boxBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBounds(RectBounds paramRectBounds) {
/* 257 */     this.minX = paramRectBounds.getMinX();
/* 258 */     this.minY = paramRectBounds.getMinY();
/* 259 */     this.maxX = paramRectBounds.getMaxX();
/* 260 */     this.maxY = paramRectBounds.getMaxY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 267 */     this.minX = paramFloat1;
/* 268 */     this.minY = paramFloat2;
/* 269 */     this.maxX = paramFloat3;
/* 270 */     this.maxY = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBoundsAndSort(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 278 */     setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/* 279 */     sortMinMax();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoundsAndSort(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 284 */     if (paramFloat3 != 0.0F || paramFloat6 != 0.0F) {
/* 285 */       throw new UnsupportedOperationException("Unknown BoundsType");
/*     */     }
/* 287 */     setBounds(paramFloat1, paramFloat2, paramFloat4, paramFloat5);
/* 288 */     sortMinMax();
/*     */   }
/*     */   
/*     */   public void setBoundsAndSort(Point2D paramPoint2D1, Point2D paramPoint2D2) {
/* 292 */     setBoundsAndSort(paramPoint2D1.x, paramPoint2D1.y, paramPoint2D2.x, paramPoint2D2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds flattenInto(RectBounds paramRectBounds) {
/* 302 */     if (paramRectBounds == null) paramRectBounds = new RectBounds();
/*     */     
/* 304 */     if (isEmpty()) return paramRectBounds.makeEmpty();
/*     */     
/* 306 */     paramRectBounds.setBounds(this.minX, this.minY, this.maxX, this.maxY);
/* 307 */     return paramRectBounds;
/*     */   }
/*     */ 
/*     */   
/*     */   public void unionWith(RectBounds paramRectBounds) {
/* 312 */     if (paramRectBounds.isEmpty())
/* 313 */       return;  if (isEmpty()) {
/* 314 */       setBounds(paramRectBounds);
/*     */       
/*     */       return;
/*     */     } 
/* 318 */     this.minX = Math.min(this.minX, paramRectBounds.getMinX());
/* 319 */     this.minY = Math.min(this.minY, paramRectBounds.getMinY());
/* 320 */     this.maxX = Math.max(this.maxX, paramRectBounds.getMaxX());
/* 321 */     this.maxY = Math.max(this.maxY, paramRectBounds.getMaxY());
/*     */   }
/*     */ 
/*     */   
/*     */   public void unionWith(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 326 */     if (paramFloat3 < paramFloat1 || paramFloat4 < paramFloat2)
/* 327 */       return;  if (isEmpty()) {
/* 328 */       setBounds(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
/*     */       
/*     */       return;
/*     */     } 
/* 332 */     this.minX = Math.min(this.minX, paramFloat1);
/* 333 */     this.minY = Math.min(this.minY, paramFloat2);
/* 334 */     this.maxX = Math.max(this.maxX, paramFloat3);
/* 335 */     this.maxY = Math.max(this.maxY, paramFloat4);
/*     */   }
/*     */   
/*     */   public void add(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 339 */     if (paramFloat3 != 0.0F) {
/* 340 */       throw new UnsupportedOperationException("Unknown BoundsType");
/*     */     }
/* 342 */     unionWith(paramFloat1, paramFloat2, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   public void add(float paramFloat1, float paramFloat2) {
/* 346 */     unionWith(paramFloat1, paramFloat2, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   public void add(Point2D paramPoint2D) {
/* 350 */     add(paramPoint2D.x, paramPoint2D.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void intersectWith(BaseBounds paramBaseBounds) {
/* 355 */     if (isEmpty())
/* 356 */       return;  if (paramBaseBounds.isEmpty()) {
/* 357 */       makeEmpty();
/*     */       
/*     */       return;
/*     */     } 
/* 361 */     this.minX = Math.max(this.minX, paramBaseBounds.getMinX());
/* 362 */     this.minY = Math.max(this.minY, paramBaseBounds.getMinY());
/* 363 */     this.maxX = Math.min(this.maxX, paramBaseBounds.getMaxX());
/* 364 */     this.maxY = Math.min(this.maxY, paramBaseBounds.getMaxY());
/*     */   }
/*     */   
/*     */   public void intersectWith(Rectangle paramRectangle) {
/* 368 */     float f1 = paramRectangle.x;
/* 369 */     float f2 = paramRectangle.y;
/* 370 */     intersectWith(f1, f2, f1 + paramRectangle.width, f2 + paramRectangle.height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void intersectWith(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 375 */     if (isEmpty())
/* 376 */       return;  if (paramFloat3 < paramFloat1 || paramFloat4 < paramFloat2) {
/* 377 */       makeEmpty();
/*     */       
/*     */       return;
/*     */     } 
/* 381 */     this.minX = Math.max(this.minX, paramFloat1);
/* 382 */     this.minY = Math.max(this.minY, paramFloat2);
/* 383 */     this.maxX = Math.min(this.maxX, paramFloat3);
/* 384 */     this.maxY = Math.min(this.maxY, paramFloat4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void intersectWith(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 390 */     if (isEmpty())
/* 391 */       return;  if (paramFloat4 < paramFloat1 || paramFloat5 < paramFloat2 || paramFloat6 < paramFloat3) {
/* 392 */       makeEmpty();
/*     */       
/*     */       return;
/*     */     } 
/* 396 */     this.minX = Math.max(this.minX, paramFloat1);
/* 397 */     this.minY = Math.max(this.minY, paramFloat2);
/* 398 */     this.maxX = Math.min(this.maxX, paramFloat4);
/* 399 */     this.maxY = Math.min(this.maxY, paramFloat5);
/*     */   }
/*     */   
/*     */   public boolean contains(Point2D paramPoint2D) {
/* 403 */     if (paramPoint2D == null || isEmpty()) return false; 
/* 404 */     return (paramPoint2D.x >= this.minX && paramPoint2D.x <= this.maxX && paramPoint2D.y >= this.minY && paramPoint2D.y <= this.maxY);
/*     */   }
/*     */   
/*     */   public boolean contains(float paramFloat1, float paramFloat2) {
/* 408 */     if (isEmpty()) return false; 
/* 409 */     return (paramFloat1 >= this.minX && paramFloat1 <= this.maxX && paramFloat2 >= this.minY && paramFloat2 <= this.maxY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(RectBounds paramRectBounds) {
/* 421 */     if (isEmpty() || paramRectBounds.isEmpty()) return false; 
/* 422 */     return (this.minX <= paramRectBounds.minX && this.maxX >= paramRectBounds.maxX && this.minY <= paramRectBounds.minY && this.maxY >= paramRectBounds.maxY);
/*     */   }
/*     */   
/*     */   public boolean intersects(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 426 */     if (isEmpty()) return false; 
/* 427 */     return (paramFloat1 + paramFloat3 >= this.minX && paramFloat2 + paramFloat4 >= this.minY && paramFloat1 <= this.maxX && paramFloat2 <= this.maxY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(BaseBounds paramBaseBounds) {
/* 434 */     if (paramBaseBounds == null || paramBaseBounds.isEmpty() || isEmpty()) {
/* 435 */       return false;
/*     */     }
/* 437 */     return (paramBaseBounds.getMaxX() >= this.minX && paramBaseBounds
/* 438 */       .getMaxY() >= this.minY && paramBaseBounds
/* 439 */       .getMaxZ() >= getMinZ() && paramBaseBounds
/* 440 */       .getMinX() <= this.maxX && paramBaseBounds
/* 441 */       .getMinY() <= this.maxY && paramBaseBounds
/* 442 */       .getMinZ() <= getMaxZ());
/*     */   }
/*     */   
/*     */   public boolean disjoint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 446 */     if (isEmpty()) return true; 
/* 447 */     return (paramFloat1 + paramFloat3 < this.minX || paramFloat2 + paramFloat4 < this.minY || paramFloat1 > this.maxX || paramFloat2 > this.maxY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean disjoint(RectBounds paramRectBounds) {
/* 454 */     if (paramRectBounds == null || paramRectBounds.isEmpty() || isEmpty()) {
/* 455 */       return true;
/*     */     }
/* 457 */     return (paramRectBounds.getMaxX() < this.minX || paramRectBounds
/* 458 */       .getMaxY() < this.minY || paramRectBounds
/* 459 */       .getMinX() > this.maxX || paramRectBounds
/* 460 */       .getMinY() > this.maxY);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 465 */     return (this.maxX < this.minX || this.maxY < this.minY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void roundOut() {
/* 474 */     this.minX = (float)Math.floor(this.minX);
/* 475 */     this.minY = (float)Math.floor(this.minY);
/* 476 */     this.maxX = (float)Math.ceil(this.maxX);
/* 477 */     this.maxY = (float)Math.ceil(this.maxY);
/*     */   }
/*     */   
/*     */   public void grow(float paramFloat1, float paramFloat2) {
/* 481 */     this.minX -= paramFloat1;
/* 482 */     this.maxX += paramFloat1;
/* 483 */     this.minY -= paramFloat2;
/* 484 */     this.maxY += paramFloat2;
/*     */   }
/*     */   
/*     */   public BaseBounds deriveWithPadding(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 488 */     if (paramFloat3 == 0.0F) {
/* 489 */       grow(paramFloat1, paramFloat2);
/* 490 */       return this;
/*     */     } 
/* 492 */     BoxBounds boxBounds = new BoxBounds(this.minX, this.minY, 0.0F, this.maxX, this.maxY, 0.0F);
/* 493 */     boxBounds.grow(paramFloat1, paramFloat2, paramFloat3);
/* 494 */     return boxBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectBounds makeEmpty() {
/* 501 */     this.minX = this.minY = 0.0F;
/* 502 */     this.maxX = this.maxY = -1.0F;
/* 503 */     return this;
/*     */   }
/*     */   
/*     */   protected void sortMinMax() {
/* 507 */     if (this.minX > this.maxX) {
/* 508 */       float f = this.maxX;
/* 509 */       this.maxX = this.minX;
/* 510 */       this.minX = f;
/*     */     } 
/* 512 */     if (this.minY > this.maxY) {
/* 513 */       float f = this.maxY;
/* 514 */       this.maxY = this.minY;
/* 515 */       this.minY = f;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void translate(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 520 */     setMinX(getMinX() + paramFloat1);
/* 521 */     setMinY(getMinY() + paramFloat2);
/* 522 */     setMaxX(getMaxX() + paramFloat1);
/* 523 */     setMaxY(getMaxY() + paramFloat2);
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 527 */     if (paramObject == null) return false; 
/* 528 */     if (getClass() != paramObject.getClass()) return false;
/*     */     
/* 530 */     RectBounds rectBounds = (RectBounds)paramObject;
/* 531 */     if (this.minX != rectBounds.getMinX()) return false; 
/* 532 */     if (this.minY != rectBounds.getMinY()) return false; 
/* 533 */     if (this.maxX != rectBounds.getMaxX()) return false; 
/* 534 */     if (this.maxY != rectBounds.getMaxY()) return false; 
/* 535 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 539 */     int i = 7;
/* 540 */     i = 79 * i + Float.floatToIntBits(this.minX);
/* 541 */     i = 79 * i + Float.floatToIntBits(this.minY);
/* 542 */     i = 79 * i + Float.floatToIntBits(this.maxX);
/* 543 */     i = 79 * i + Float.floatToIntBits(this.maxY);
/* 544 */     return i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 548 */     return "RectBounds { minX:" + this.minX + ", minY:" + this.minY + ", maxX:" + this.maxX + ", maxY:" + this.maxY + "} (w:" + this.maxX - this.minX + ", h:" + this.maxY - this.minY + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\RectBounds.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */