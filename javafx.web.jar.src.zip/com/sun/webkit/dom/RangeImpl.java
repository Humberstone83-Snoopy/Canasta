/*     */ package com.sun.webkit.dom;
/*     */ 
/*     */ import com.sun.webkit.Disposer;
/*     */ import com.sun.webkit.DisposerRecord;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.ranges.Range;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RangeImpl
/*     */   implements Range
/*     */ {
/*     */   private final long peer;
/*     */   public static final int START_TO_START = 0;
/*     */   public static final int START_TO_END = 1;
/*     */   public static final int END_TO_END = 2;
/*     */   public static final int END_TO_START = 3;
/*     */   public static final int NODE_BEFORE = 0;
/*     */   public static final int NODE_AFTER = 1;
/*     */   public static final int NODE_BEFORE_AND_AFTER = 2;
/*     */   public static final int NODE_INSIDE = 3;
/*     */   
/*     */   private static class SelfDisposer
/*     */     implements DisposerRecord
/*     */   {
/*     */     private final long peer;
/*     */     
/*     */     SelfDisposer(long param1Long) {
/*  39 */       this.peer = param1Long;
/*     */     }
/*     */     public void dispose() {
/*  42 */       RangeImpl.dispose(this.peer);
/*     */     }
/*     */   }
/*     */   
/*     */   RangeImpl(long paramLong) {
/*  47 */     this.peer = paramLong;
/*  48 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*     */   }
/*     */   
/*     */   static Range create(long paramLong) {
/*  52 */     if (paramLong == 0L) return null; 
/*  53 */     return new RangeImpl(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   long getPeer() {
/*  59 */     return this.peer;
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*  63 */     return (paramObject instanceof RangeImpl && this.peer == ((RangeImpl)paramObject).peer);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  67 */     long l = this.peer;
/*  68 */     return (int)(l ^ l >> 17L);
/*     */   }
/*     */   
/*     */   static long getPeer(Range paramRange) {
/*  72 */     return (paramRange == null) ? 0L : ((RangeImpl)paramRange).getPeer();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Range getImpl(long paramLong) {
/*  78 */     return create(paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getStartContainer() {
/*  94 */     return NodeImpl.getImpl(getStartContainerImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStartOffset() {
/*  99 */     return getStartOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getEndContainer() {
/* 104 */     return NodeImpl.getImpl(getEndContainerImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEndOffset() {
/* 109 */     return getEndOffsetImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getCollapsed() {
/* 114 */     return getCollapsedImpl(getPeer());
/*     */   }
/*     */ 
/*     */   
/*     */   public Node getCommonAncestorContainer() {
/* 119 */     return NodeImpl.getImpl(getCommonAncestorContainerImpl(getPeer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 124 */     return getTextImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStart(Node paramNode, int paramInt) throws DOMException {
/* 133 */     setStartImpl(getPeer(), 
/* 134 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnd(Node paramNode, int paramInt) throws DOMException {
/* 145 */     setEndImpl(getPeer(), 
/* 146 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartBefore(Node paramNode) throws DOMException {
/* 156 */     setStartBeforeImpl(getPeer(), 
/* 157 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartAfter(Node paramNode) throws DOMException {
/* 165 */     setStartAfterImpl(getPeer(), 
/* 166 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndBefore(Node paramNode) throws DOMException {
/* 174 */     setEndBeforeImpl(getPeer(), 
/* 175 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndAfter(Node paramNode) throws DOMException {
/* 183 */     setEndAfterImpl(getPeer(), 
/* 184 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collapse(boolean paramBoolean) {
/* 192 */     collapseImpl(getPeer(), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectNode(Node paramNode) throws DOMException {
/* 201 */     selectNodeImpl(getPeer(), 
/* 202 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectNodeContents(Node paramNode) throws DOMException {
/* 210 */     selectNodeContentsImpl(getPeer(), 
/* 211 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short compareBoundaryPoints(short paramShort, Range paramRange) throws DOMException {
/* 220 */     return compareBoundaryPointsImpl(getPeer(), paramShort, 
/*     */         
/* 222 */         getPeer(paramRange));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteContents() throws DOMException {
/* 231 */     deleteContentsImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFragment extractContents() throws DOMException {
/* 238 */     return DocumentFragmentImpl.getImpl(extractContentsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFragment cloneContents() throws DOMException {
/* 245 */     return DocumentFragmentImpl.getImpl(cloneContentsImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertNode(Node paramNode) throws DOMException {
/* 252 */     insertNodeImpl(getPeer(), 
/* 253 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void surroundContents(Node paramNode) throws DOMException {
/* 261 */     surroundContentsImpl(getPeer(), 
/* 262 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range cloneRange() {
/* 270 */     return getImpl(cloneRangeImpl(getPeer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 277 */     return toStringImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detach() {
/* 284 */     detachImpl(getPeer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocumentFragment createContextualFragment(String paramString) throws DOMException {
/* 291 */     return DocumentFragmentImpl.getImpl(createContextualFragmentImpl(getPeer(), paramString));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short compareNode(Node paramNode) throws DOMException {
/* 300 */     return compareNodeImpl(getPeer(), 
/* 301 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short comparePoint(Node paramNode, int paramInt) throws DOMException {
/* 310 */     return comparePointImpl(getPeer(), 
/* 311 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersectsNode(Node paramNode) throws DOMException {
/* 321 */     return intersectsNodeImpl(getPeer(), 
/* 322 */         NodeImpl.getPeer(paramNode));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPointInRange(Node paramNode, int paramInt) throws DOMException {
/* 331 */     return isPointInRangeImpl(getPeer(), 
/* 332 */         NodeImpl.getPeer(paramNode), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expand(String paramString) throws DOMException {
/* 342 */     expandImpl(getPeer(), paramString);
/*     */   }
/*     */   
/*     */   private static native void dispose(long paramLong);
/*     */   
/*     */   static native long getStartContainerImpl(long paramLong);
/*     */   
/*     */   static native int getStartOffsetImpl(long paramLong);
/*     */   
/*     */   static native long getEndContainerImpl(long paramLong);
/*     */   
/*     */   static native int getEndOffsetImpl(long paramLong);
/*     */   
/*     */   static native boolean getCollapsedImpl(long paramLong);
/*     */   
/*     */   static native long getCommonAncestorContainerImpl(long paramLong);
/*     */   
/*     */   static native String getTextImpl(long paramLong);
/*     */   
/*     */   static native void setStartImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native void setEndImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native void setStartBeforeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void setStartAfterImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void setEndBeforeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void setEndAfterImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void collapseImpl(long paramLong, boolean paramBoolean);
/*     */   
/*     */   static native void selectNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void selectNodeContentsImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native short compareBoundaryPointsImpl(long paramLong1, short paramShort, long paramLong2);
/*     */   
/*     */   static native void deleteContentsImpl(long paramLong);
/*     */   
/*     */   static native long extractContentsImpl(long paramLong);
/*     */   
/*     */   static native long cloneContentsImpl(long paramLong);
/*     */   
/*     */   static native void insertNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native void surroundContentsImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native long cloneRangeImpl(long paramLong);
/*     */   
/*     */   static native String toStringImpl(long paramLong);
/*     */   
/*     */   static native void detachImpl(long paramLong);
/*     */   
/*     */   static native long createContextualFragmentImpl(long paramLong, String paramString);
/*     */   
/*     */   static native short compareNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native short comparePointImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native boolean intersectsNodeImpl(long paramLong1, long paramLong2);
/*     */   
/*     */   static native boolean isPointInRangeImpl(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   static native void expandImpl(long paramLong, String paramString);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\RangeImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */