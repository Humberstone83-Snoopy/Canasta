/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PrismCompositeFontResource
/*     */   implements CompositeFontResource
/*     */ {
/*     */   private FontResource primaryResource;
/*     */   private FallbackResource fallbackResource;
/*     */   CompositeGlyphMapper mapper;
/*     */   
/*     */   PrismCompositeFontResource(FontResource paramFontResource, String paramString) {
/*  47 */     if (!(paramFontResource instanceof PrismFontFile)) {
/*  48 */       Thread.dumpStack();
/*  49 */       throw new IllegalStateException("wrong resource type");
/*     */     } 
/*  51 */     if (paramString != null) {
/*  52 */       PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  53 */       prismFontFactory.compResourceMap.put(paramString, this);
/*     */     } 
/*  55 */     this.primaryResource = paramFontResource;
/*  56 */     int i = paramFontResource.getDefaultAAMode();
/*  57 */     boolean bool1 = paramFontResource.isBold();
/*  58 */     boolean bool2 = paramFontResource.isItalic();
/*  59 */     this
/*  60 */       .fallbackResource = FallbackResource.getFallbackResource(bool1, bool2, i);
/*     */   }
/*     */   
/*     */   public int getNumSlots() {
/*  64 */     return this.fallbackResource.getNumSlots() + 1;
/*     */   }
/*     */   
/*     */   public int getSlotForFont(String paramString) {
/*  68 */     if (this.primaryResource.getFullName().equalsIgnoreCase(paramString)) {
/*  69 */       return 0;
/*     */     }
/*  71 */     return this.fallbackResource.getSlotForFont(paramString) + 1;
/*     */   }
/*     */   
/*     */   public FontResource getSlotResource(int paramInt) {
/*  75 */     if (paramInt == 0) {
/*  76 */       return this.primaryResource;
/*     */     }
/*  78 */     FontResource fontResource = this.fallbackResource.getSlotResource(paramInt - 1);
/*  79 */     if (fontResource != null) {
/*  80 */       return fontResource;
/*     */     }
/*  82 */     return this.primaryResource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName() {
/*  88 */     return this.primaryResource.getFullName();
/*     */   }
/*     */   
/*     */   public String getPSName() {
/*  92 */     return this.primaryResource.getPSName();
/*     */   }
/*     */   
/*     */   public String getFamilyName() {
/*  96 */     return this.primaryResource.getFamilyName();
/*     */   }
/*     */   
/*     */   public String getStyleName() {
/* 100 */     return this.primaryResource.getStyleName();
/*     */   }
/*     */   
/*     */   public String getLocaleFullName() {
/* 104 */     return this.primaryResource.getLocaleFullName();
/*     */   }
/*     */   
/*     */   public String getLocaleFamilyName() {
/* 108 */     return this.primaryResource.getLocaleFamilyName();
/*     */   }
/*     */   
/*     */   public String getLocaleStyleName() {
/* 112 */     return this.primaryResource.getLocaleStyleName();
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 116 */     return this.primaryResource.getFileName();
/*     */   }
/*     */   
/*     */   public int getFeatures() {
/* 120 */     return this.primaryResource.getFeatures();
/*     */   }
/*     */   
/*     */   public Object getPeer() {
/* 124 */     return this.primaryResource.getPeer();
/*     */   }
/*     */   
/*     */   public void setPeer(Object paramObject) {
/* 128 */     throw new UnsupportedOperationException("Not supported");
/*     */   }
/*     */   
/*     */   public boolean isEmbeddedFont() {
/* 132 */     return this.primaryResource.isEmbeddedFont();
/*     */   }
/*     */   
/*     */   public boolean isBold() {
/* 136 */     return this.primaryResource.isBold();
/*     */   }
/*     */   
/*     */   public boolean isItalic() {
/* 140 */     return this.primaryResource.isItalic();
/*     */   }
/*     */ 
/*     */   
/*     */   public CharToGlyphMapper getGlyphMapper() {
/* 145 */     if (this.mapper == null) {
/* 146 */       this.mapper = new CompositeGlyphMapper(this);
/*     */     }
/* 148 */     return this.mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getGlyphBoundingBox(int paramInt, float paramFloat, float[] paramArrayOffloat) {
/* 153 */     int i = paramInt >>> 24;
/* 154 */     int j = paramInt & 0xFFFFFF;
/* 155 */     FontResource fontResource = getSlotResource(i);
/* 156 */     return fontResource.getGlyphBoundingBox(j, paramFloat, paramArrayOffloat);
/*     */   }
/*     */   
/*     */   public float getAdvance(int paramInt, float paramFloat) {
/* 160 */     int i = paramInt >>> 24;
/* 161 */     int j = paramInt & 0xFFFFFF;
/* 162 */     FontResource fontResource = getSlotResource(i);
/* 163 */     return fontResource.getAdvance(j, paramFloat);
/*     */   }
/*     */   
/* 166 */   Map<FontStrikeDesc, WeakReference<FontStrike>> strikeMap = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public Map<FontStrikeDesc, WeakReference<FontStrike>> getStrikeMap() {
/* 170 */     return this.strikeMap;
/*     */   }
/*     */   
/*     */   public int getDefaultAAMode() {
/* 174 */     return getSlotResource(0).getDefaultAAMode();
/*     */   }
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform) {
/* 178 */     return getStrike(paramFloat, paramBaseTransform, getDefaultAAMode());
/*     */   }
/*     */ 
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt) {
/* 183 */     FontStrikeDesc fontStrikeDesc = new FontStrikeDesc(paramFloat, paramBaseTransform, paramInt);
/* 184 */     WeakReference<CompositeStrike> weakReference = (WeakReference)this.strikeMap.get(fontStrikeDesc);
/* 185 */     CompositeStrike compositeStrike = null;
/* 186 */     if (weakReference != null) {
/* 187 */       compositeStrike = weakReference.get();
/*     */     }
/* 189 */     if (compositeStrike == null) {
/* 190 */       compositeStrike = new CompositeStrike(this, paramFloat, paramBaseTransform, paramInt, fontStrikeDesc);
/* 191 */       if (compositeStrike.disposer != null) {
/* 192 */         weakReference = Disposer.addRecord(compositeStrike, compositeStrike.disposer);
/*     */       } else {
/* 194 */         weakReference = new WeakReference<>(compositeStrike);
/*     */       } 
/* 196 */       this.strikeMap.put(fontStrikeDesc, weakReference);
/*     */     } 
/* 198 */     return compositeStrike;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 203 */     if (paramObject == null) {
/* 204 */       return false;
/*     */     }
/* 206 */     if (!(paramObject instanceof PrismCompositeFontResource)) {
/* 207 */       return false;
/*     */     }
/* 209 */     PrismCompositeFontResource prismCompositeFontResource = (PrismCompositeFontResource)paramObject;
/* 210 */     return this.primaryResource.equals(prismCompositeFontResource.primaryResource);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 215 */     return this.primaryResource.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\PrismCompositeFontResource.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */