/*     */ package com.sun.javafx.runtime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionInfo
/*     */ {
/*     */   private static final String BUILD_TIMESTAMP = "2019-01-16-090633";
/*     */   private static final String HUDSON_JOB_NAME = ".";
/*     */   private static final String HUDSON_BUILD_NUMBER = "10";
/*     */   private static final String PROMOTED_BUILD_NUMBER = "1";
/*     */   private static final String RELEASE_VERSION = "11.0.2";
/*     */   private static final String RELEASE_SUFFIX = "";
/*     */   private static final String VERSION;
/*     */   private static final String RUNTIME_VERSION;
/*     */   
/*     */   static {
/* 133 */     String str = "11.0.2";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     str = str;
/* 139 */     VERSION = str;
/*     */ 
/*     */     
/* 142 */     str = str + "+1";
/* 143 */     if (getHudsonJobName().length() == 0)
/*     */     {
/* 145 */       str = str + "-2019-01-16-090633";
/*     */     }
/* 147 */     RUNTIME_VERSION = str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setupSystemProperties() {
/* 158 */     if (System.getProperty("javafx.version") == null) {
/* 159 */       System.setProperty("javafx.version", getVersion());
/* 160 */       System.setProperty("javafx.runtime.version", getRuntimeVersion());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBuildTimestamp() {
/* 169 */     return "2019-01-16-090633";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getHudsonJobName() {
/* 178 */     if (".".equals("not_hudson")) {
/* 179 */       return "";
/*     */     }
/* 181 */     return ".";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getHudsonBuildNumber() {
/* 189 */     return "10";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getReleaseMilestone() {
/* 200 */     String str = "";
/* 201 */     if (str.startsWith("-")) {
/* 202 */       str = str.substring(1);
/*     */     }
/* 204 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVersion() {
/* 212 */     return VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getRuntimeVersion() {
/* 220 */     return RUNTIME_VERSION;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\runtime\VersionInfo.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */