/*    */ package com.sun.glass.ui.mac;
/*    */ 
/*    */ import com.sun.glass.ui.Cursor;
/*    */ import com.sun.glass.ui.Pixels;
/*    */ import com.sun.glass.ui.Size;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MacCursor
/*    */   extends Cursor
/*    */ {
/*    */   static {
/* 38 */     _initIDs();
/*    */   }
/*    */   
/*    */   protected MacCursor(int paramInt) {
/* 42 */     super(paramInt);
/*    */   }
/*    */   
/*    */   protected MacCursor(int paramInt1, int paramInt2, Pixels paramPixels) {
/* 46 */     super(paramInt1, paramInt2, paramPixels);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   void set() {
/* 52 */     int i = getType();
/* 53 */     isCursorNONE = (i == -1);
/*    */ 
/*    */     
/* 56 */     setVisible(isVisible);
/*    */     
/* 58 */     switch (i) {
/*    */       case -1:
/*    */         return;
/*    */       case 0:
/* 62 */         _setCustom(getNativeCursor());
/*    */     } 
/*    */     
/* 65 */     _set(i);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isNSCursorVisible = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isCursorNONE = false;
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isVisible = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void setVisible_impl(boolean paramBoolean) {
/* 87 */     isVisible = paramBoolean;
/* 88 */     boolean bool = (paramBoolean && !isCursorNONE);
/* 89 */     if (isNSCursorVisible == bool) {
/*    */       return;
/*    */     }
/* 92 */     isNSCursorVisible = bool;
/* 93 */     _setVisible(bool);
/*    */   }
/*    */ 
/*    */   
/*    */   static Size getBestSize_impl(int paramInt1, int paramInt2) {
/* 98 */     return _getBestSize(paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   private static native void _initIDs();
/*    */   
/*    */   protected native long _createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
/*    */   
/*    */   private native void _set(int paramInt);
/*    */   
/*    */   private native void _setCustom(long paramLong);
/*    */   
/*    */   private static native void _setVisible(boolean paramBoolean);
/*    */   
/*    */   private static native Size _getBestSize(int paramInt1, int paramInt2);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacCursor.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */