/*     */ package com.sun.javafx.sg.prism;
/*     */ 
/*     */ import com.sun.prism.Image;
/*     */ import com.sun.prism.Material;
/*     */ import com.sun.prism.PhongMaterial;
/*     */ import com.sun.prism.ResourceFactory;
/*     */ import com.sun.prism.TextureMap;
/*     */ import com.sun.prism.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NGPhongMaterial
/*     */ {
/*  40 */   private static final Image WHITE_1X1 = Image.fromIntArgbPreData(new int[] { -1 }, 1, 1);
/*     */   
/*     */   private PhongMaterial material;
/*     */   private Color diffuseColor;
/*     */   private boolean diffuseColorDirty = true;
/*  45 */   private TextureMap diffuseMap = new TextureMap(PhongMaterial.MapType.DIFFUSE);
/*     */   
/*     */   private Color specularColor;
/*     */   private boolean specularColorDirty = true;
/*     */   private float specularPower;
/*     */   private boolean specularPowerDirty = true;
/*  51 */   private TextureMap specularMap = new TextureMap(PhongMaterial.MapType.SPECULAR);
/*     */   
/*  53 */   private TextureMap bumpMap = new TextureMap(PhongMaterial.MapType.BUMP);
/*     */   
/*  55 */   private TextureMap selfIllumMap = new TextureMap(PhongMaterial.MapType.SELF_ILLUM);
/*     */   
/*     */   Material createMaterial(ResourceFactory paramResourceFactory) {
/*  58 */     if (this.material == null) {
/*  59 */       this.material = paramResourceFactory.createPhongMaterial();
/*     */     }
/*  61 */     validate(paramResourceFactory);
/*  62 */     return this.material;
/*     */   }
/*     */ 
/*     */   
/*     */   private void validate(ResourceFactory paramResourceFactory) {
/*  67 */     if (this.diffuseColorDirty) {
/*  68 */       if (this.diffuseColor != null) {
/*  69 */         this.material.setDiffuseColor(this.diffuseColor
/*  70 */             .getRed(), this.diffuseColor.getGreen(), this.diffuseColor
/*  71 */             .getBlue(), this.diffuseColor.getAlpha());
/*     */       } else {
/*  73 */         this.material.setDiffuseColor(0.0F, 0.0F, 0.0F, 0.0F);
/*     */       } 
/*  75 */       this.diffuseColorDirty = false;
/*     */     } 
/*     */     
/*  78 */     if (this.diffuseMap.isDirty()) {
/*  79 */       if (this.diffuseMap.getImage() == null) {
/*  80 */         this.diffuseMap.setImage(WHITE_1X1);
/*     */       }
/*  82 */       this.material.setTextureMap(this.diffuseMap);
/*     */     } 
/*  84 */     if (this.bumpMap.isDirty()) {
/*  85 */       this.material.setTextureMap(this.bumpMap);
/*     */     }
/*  87 */     if (this.selfIllumMap.isDirty()) {
/*  88 */       this.material.setTextureMap(this.selfIllumMap);
/*     */     }
/*  90 */     if (this.specularMap.isDirty()) {
/*  91 */       this.material.setTextureMap(this.specularMap);
/*     */     }
/*  93 */     if (this.specularColorDirty || this.specularPowerDirty) {
/*  94 */       if (this.specularColor != null) {
/*  95 */         float f1 = this.specularColor.getRed();
/*  96 */         float f2 = this.specularColor.getGreen();
/*  97 */         float f3 = this.specularColor.getBlue();
/*  98 */         this.material.setSpecularColor(true, f1, f2, f3, this.specularPower);
/*     */       } else {
/* 100 */         this.material.setSpecularColor(false, 1.0F, 1.0F, 1.0F, this.specularPower);
/*     */       } 
/* 102 */       this.specularColorDirty = false;
/* 103 */       this.specularPowerDirty = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setDiffuseColor(Object paramObject) {
/* 108 */     this.diffuseColor = (Color)paramObject;
/* 109 */     this.diffuseColorDirty = true;
/*     */   }
/*     */   
/*     */   public void setSpecularColor(Object paramObject) {
/* 113 */     this.specularColor = (Color)paramObject;
/* 114 */     this.specularColorDirty = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSpecularPower(float paramFloat) {
/* 119 */     if (paramFloat < 0.001F) {
/* 120 */       paramFloat = 0.001F;
/*     */     }
/* 122 */     this.specularPower = paramFloat;
/* 123 */     this.specularPowerDirty = true;
/*     */   }
/*     */   
/*     */   public void setDiffuseMap(Object paramObject) {
/* 127 */     this.diffuseMap.setImage((Image)paramObject);
/* 128 */     this.diffuseMap.setDirty(true);
/*     */   }
/*     */   
/*     */   public void setSpecularMap(Object paramObject) {
/* 132 */     this.specularMap.setImage((Image)paramObject);
/* 133 */     this.specularMap.setDirty(true);
/*     */   }
/*     */   
/*     */   public void setBumpMap(Object paramObject) {
/* 137 */     this.bumpMap.setImage((Image)paramObject);
/* 138 */     this.bumpMap.setDirty(true);
/*     */   }
/*     */   
/*     */   public void setSelfIllumMap(Object paramObject) {
/* 142 */     this.selfIllumMap.setImage((Image)paramObject);
/* 143 */     this.selfIllumMap.setDirty(true);
/*     */   }
/*     */ 
/*     */   
/*     */   Color test_getDiffuseColor() {
/* 148 */     return this.diffuseColor;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGPhongMaterial.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */