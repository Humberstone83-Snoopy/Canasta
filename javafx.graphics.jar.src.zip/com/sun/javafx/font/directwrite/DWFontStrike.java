/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.DisposerRecord;
/*     */ import com.sun.javafx.font.FontStrikeDesc;
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontStrike;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DWFontStrike
/*     */   extends PrismFontStrike<DWFontFile>
/*     */ {
/*     */   DWRITE_MATRIX matrix;
/*     */   static final boolean SUBPIXEL_ON;
/*     */   static final boolean SUBPIXEL_Y;
/*     */   static final boolean SUBPIXEL_NATIVE;
/*     */   
/*     */   static {
/*  45 */     int i = PrismFontFactory.getFontFactory().getSubPixelMode();
/*  46 */     SUBPIXEL_ON = ((i & 0x1) != 0);
/*  47 */     SUBPIXEL_Y = ((i & 0x2) != 0);
/*  48 */     SUBPIXEL_NATIVE = ((i & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   DWFontStrike(DWFontFile paramDWFontFile, float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/*  53 */     super(paramDWFontFile, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/*  54 */     float f = PrismFontFactory.getFontSizeLimit();
/*  55 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  56 */       this.drawShapes = (paramFloat > f);
/*     */     } else {
/*  58 */       BaseTransform baseTransform = getTransform();
/*  59 */       this.matrix = new DWRITE_MATRIX();
/*  60 */       this.matrix.m11 = (float)baseTransform.getMxx();
/*  61 */       this.matrix.m12 = (float)baseTransform.getMyx();
/*  62 */       this.matrix.m21 = (float)baseTransform.getMxy();
/*  63 */       this.matrix.m22 = (float)baseTransform.getMyy();
/*     */       
/*  65 */       if (Math.abs(this.matrix.m11 * paramFloat) > f || 
/*  66 */         Math.abs(this.matrix.m12 * paramFloat) > f || 
/*  67 */         Math.abs(this.matrix.m21 * paramFloat) > f || 
/*  68 */         Math.abs(this.matrix.m22 * paramFloat) > f)
/*     */       {
/*  70 */         this.drawShapes = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected DisposerRecord createDisposer(FontStrikeDesc paramFontStrikeDesc) {
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQuantizedPosition(Point2D paramPoint2D) {
/*  81 */     if (SUBPIXEL_ON && (this.matrix == null || SUBPIXEL_NATIVE))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  86 */       if (getAAMode() == 0 || SUBPIXEL_NATIVE) {
/*  87 */         float f = paramPoint2D.x;
/*  88 */         paramPoint2D.x = (int)paramPoint2D.x;
/*  89 */         f -= paramPoint2D.x;
/*  90 */         byte b = 0;
/*  91 */         if (f >= 0.66F) {
/*  92 */           b = 2;
/*  93 */         } else if (f >= 0.33F) {
/*  94 */           b = 1;
/*     */         } 
/*  96 */         if (SUBPIXEL_Y) {
/*  97 */           f = paramPoint2D.y;
/*  98 */           paramPoint2D.y = (int)paramPoint2D.y;
/*  99 */           f -= paramPoint2D.y;
/* 100 */           if (f >= 0.66F) {
/* 101 */             b += 6;
/* 102 */           } else if (f >= 0.33F) {
/* 103 */             b += 3;
/*     */           } 
/*     */         } else {
/* 106 */           paramPoint2D.y = Math.round(paramPoint2D.y);
/*     */         } 
/* 108 */         return b;
/*     */       } 
/*     */     }
/* 111 */     return super.getQuantizedPosition(paramPoint2D);
/*     */   }
/*     */   
/*     */   IDWriteFontFace getFontFace() {
/* 115 */     DWFontFile dWFontFile = getFontResource();
/* 116 */     return dWFontFile.getFontFace();
/*     */   }
/*     */   
/*     */   RectBounds getBBox(int paramInt) {
/* 120 */     DWFontFile dWFontFile = getFontResource();
/* 121 */     return dWFontFile.getBBox(paramInt, getSize());
/*     */   }
/*     */   
/*     */   int getUpem() {
/* 125 */     return getFontResource().getUnitsPerEm();
/*     */   }
/*     */   
/*     */   protected Path2D createGlyphOutline(int paramInt) {
/* 129 */     DWFontFile dWFontFile = getFontResource();
/* 130 */     return dWFontFile.getGlyphOutline(paramInt, getSize());
/*     */   }
/*     */   
/*     */   protected Glyph createGlyph(int paramInt) {
/* 134 */     return new DWGlyph(this, paramInt, this.drawShapes);
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\directwrite\DWFontStrike.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */