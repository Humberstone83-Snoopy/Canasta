/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Disposer
/*     */   implements Runnable
/*     */ {
/*  47 */   private static final ReferenceQueue queue = new ReferenceQueue();
/*  48 */   private static final Hashtable records = new Hashtable<>();
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static Disposer disposerInstance = new Disposer();
/*     */   static {
/*  54 */     ThreadGroup threadGroup = Thread.currentThread().getThreadGroup();
/*  55 */     AccessController.doPrivileged(new PrivilegedAction()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public Object run()
/*     */           {
/*  62 */             ThreadGroup threadGroup1 = Thread.currentThread().getThreadGroup();
/*  63 */             ThreadGroup threadGroup2 = threadGroup1;
/*  64 */             while (threadGroup2 != null) {
/*  65 */               threadGroup1 = threadGroup2; threadGroup2 = threadGroup1.getParent();
/*     */             } 
/*  67 */             Thread thread = new Thread(threadGroup1, Disposer.disposerInstance, "Prism Font Disposer");
/*  68 */             thread.setContextClassLoader(null);
/*  69 */             thread.setDaemon(true);
/*  70 */             thread.setPriority(10);
/*  71 */             thread.start();
/*  72 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WeakReference addRecord(Object paramObject, DisposerRecord paramDisposerRecord) {
/*  85 */     WeakReference weakReference = new WeakReference(paramObject, queue);
/*  86 */     records.put(weakReference, paramDisposerRecord);
/*  87 */     return weakReference;
/*     */   }
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*     */         while (true)
/*  93 */         { Reference reference = queue.remove();
/*  94 */           reference.clear();
/*  95 */           DisposerRecord disposerRecord = (DisposerRecord)records.remove(reference);
/*  96 */           disposerRecord.dispose();
/*  97 */           reference = null;
/*  98 */           disposerRecord = null; }  break;
/*  99 */       } catch (Exception exception) {
/* 100 */         System.out.println("Exception while removing reference: " + exception);
/* 101 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\Disposer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */