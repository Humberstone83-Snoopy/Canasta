/*    */ package com.sun.javafx.binding;
/*    */ 
/*    */ import com.sun.javafx.logging.PlatformLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Logging
/*    */ {
/*    */   public static ErrorLogger getLogger() {
/* 33 */     return ErrorLogger.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class ErrorLogger
/*    */     extends PlatformLogger
/*    */   {
/*    */     ErrorLogger() {
/* 42 */       super(System.getLogger("javafx.beans"));
/*    */     }
/*    */     
/* 45 */     private static final ErrorLogger INSTANCE = new ErrorLogger();
/*    */     private ErrorLogRecord errorLogRecord;
/*    */     
/*    */     public static class ErrorLogRecord {
/*    */       private final PlatformLogger.Level level;
/*    */       
/*    */       public ErrorLogRecord(PlatformLogger.Level param2Level, Throwable param2Throwable) {
/* 52 */         this.level = param2Level;
/* 53 */         this.thrown = param2Throwable;
/*    */       }
/*    */       private final Throwable thrown;
/*    */       public Throwable getThrown() {
/* 57 */         return this.thrown;
/*    */       }
/*    */       
/*    */       public PlatformLogger.Level getLevel() {
/* 61 */         return this.level;
/*    */       }
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     public ErrorLogRecord getErrorLogRecord() {
/* 68 */       return this.errorLogRecord;
/*    */     }
/*    */     
/*    */     public void setErrorLogRecord(ErrorLogRecord param1ErrorLogRecord) {
/* 72 */       this.errorLogRecord = param1ErrorLogRecord;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void warning(String param1String, Throwable param1Throwable) {
/* 86 */       super.warning(param1String, param1Throwable);
/* 87 */       this.errorLogRecord = new ErrorLogRecord(PlatformLogger.Level.WARNING, param1Throwable);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public void fine(String param1String, Throwable param1Throwable) {
/* 98 */       super.fine(param1String, param1Throwable);
/* 99 */       this.errorLogRecord = new ErrorLogRecord(PlatformLogger.Level.FINE, param1Throwable);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\binding\Logging.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */