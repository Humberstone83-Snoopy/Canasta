/*     */ package javafx.beans.property;
/*     */ 
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.WeakInvalidationListener;
/*     */ import javafx.beans.binding.FloatExpression;
/*     */ import javafx.beans.binding.ObjectExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReadOnlyFloatProperty
/*     */   extends FloatExpression
/*     */   implements ReadOnlyProperty<Number>
/*     */ {
/*     */   public String toString() {
/*  57 */     Object object = getBean();
/*  58 */     String str = getName();
/*  59 */     StringBuilder stringBuilder = new StringBuilder("ReadOnlyFloatProperty [");
/*     */     
/*  61 */     if (object != null) {
/*  62 */       stringBuilder.append("bean: ").append(object).append(", ");
/*     */     }
/*  64 */     if (str != null && !str.equals("")) {
/*  65 */       stringBuilder.append("name: ").append(str).append(", ");
/*     */     }
/*  67 */     stringBuilder.append("value: ").append(get()).append("]");
/*  68 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Number> ReadOnlyFloatProperty readOnlyFloatProperty(final ReadOnlyProperty<T> property) {
/*  91 */     if (property == null) {
/*  92 */       throw new NullPointerException("Property cannot be null");
/*     */     }
/*     */     
/*  95 */     return (property instanceof ReadOnlyFloatProperty) ? (ReadOnlyFloatProperty)property : 
/*  96 */       new ReadOnlyFloatPropertyBase()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public float get() {
/* 111 */           this.valid = true;
/* 112 */           Number number = property.getValue();
/* 113 */           return (number == null) ? 0.0F : number.floatValue();
/*     */         }
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 118 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 123 */           return property.getName();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyObjectProperty<Float> asObject() {
/* 139 */     return new ReadOnlyObjectPropertyBase<Float>()
/*     */       {
/*     */         private boolean valid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final InvalidationListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object getBean() {
/* 155 */           return null;
/*     */         }
/*     */ 
/*     */         
/*     */         public String getName() {
/* 160 */           return ReadOnlyFloatProperty.this.getName();
/*     */         }
/*     */ 
/*     */         
/*     */         public Float get() {
/* 165 */           this.valid = true;
/* 166 */           return ReadOnlyFloatProperty.this.getValue();
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\property\ReadOnlyFloatProperty.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */