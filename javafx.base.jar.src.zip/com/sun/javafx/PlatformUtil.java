/*     */ package com.sun.javafx;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformUtil
/*     */ {
/*  45 */   private static final String os = System.getProperty("os.name");
/*  46 */   private static final String version = System.getProperty("os.version");
/*     */   
/*     */   private static final boolean embedded;
/*     */   
/*     */   private static final String embeddedType;
/*     */   
/*     */   private static final boolean useEGL;
/*     */   
/*     */   private static final boolean doEGLCompositing;
/*  55 */   private static String javafxPlatform = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.platform")); static {
/*  56 */     loadProperties();
/*  57 */     embedded = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("com.sun.javafx.isEmbedded")))).booleanValue();
/*  58 */     embeddedType = AccessController.<String>doPrivileged(() -> System.getProperty("embedded"));
/*  59 */     useEGL = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("use.egl")))).booleanValue();
/*  60 */     if (useEGL) {
/*  61 */       doEGLCompositing = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("doNativeComposite")))).booleanValue();
/*     */     } else {
/*  63 */       doEGLCompositing = false;
/*     */     } 
/*     */     
/*  66 */     ANDROID = ("android".equals(javafxPlatform) || "Dalvik".equals(System.getProperty("java.vm.name")));
/*  67 */     WINDOWS = os.startsWith("Windows");
/*  68 */     WINDOWS_VISTA_OR_LATER = (WINDOWS && versionNumberGreaterThanOrEqualTo(6.0F));
/*  69 */     WINDOWS_7_OR_LATER = (WINDOWS && versionNumberGreaterThanOrEqualTo(6.1F));
/*  70 */     MAC = os.startsWith("Mac");
/*  71 */     LINUX = (os.startsWith("Linux") && !ANDROID);
/*  72 */     SOLARIS = os.startsWith("SunOS");
/*  73 */     IOS = os.startsWith("iOS");
/*     */   }
/*     */   private static final boolean ANDROID;
/*     */   private static final boolean WINDOWS;
/*     */   private static final boolean WINDOWS_VISTA_OR_LATER;
/*     */   private static final boolean WINDOWS_7_OR_LATER;
/*     */   private static final boolean MAC;
/*     */   private static final boolean LINUX;
/*     */   private static final boolean SOLARIS;
/*     */   private static final boolean IOS;
/*     */   
/*     */   private static boolean versionNumberGreaterThanOrEqualTo(float paramFloat) {
/*     */     try {
/*  86 */       return (Float.parseFloat(version) >= paramFloat);
/*  87 */     } catch (Exception exception) {
/*  88 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWindows() {
/*  96 */     return WINDOWS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWinVistaOrLater() {
/* 103 */     return WINDOWS_VISTA_OR_LATER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWin7OrLater() {
/* 110 */     return WINDOWS_7_OR_LATER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isMac() {
/* 117 */     return MAC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLinux() {
/* 124 */     return LINUX;
/*     */   }
/*     */   
/*     */   public static boolean useEGL() {
/* 128 */     return useEGL;
/*     */   }
/*     */   
/*     */   public static boolean useEGLWindowComposition() {
/* 132 */     return doEGLCompositing;
/*     */   }
/*     */   
/*     */   public static boolean useGLES2() {
/* 136 */     String str = "false";
/*     */     
/* 138 */     str = AccessController.<String>doPrivileged(() -> System.getProperty("use.gles2"));
/* 139 */     if ("true".equals(str)) {
/* 140 */       return true;
/*     */     }
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSolaris() {
/* 149 */     return SOLARIS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUnix() {
/* 156 */     return (LINUX || SOLARIS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmbedded() {
/* 163 */     return embedded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEmbeddedType() {
/* 170 */     return embeddedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIOS() {
/* 177 */     return IOS;
/*     */   }
/*     */   
/*     */   private static void loadPropertiesFromFile(File paramFile) {
/* 181 */     Properties properties = new Properties();
/*     */     try {
/* 183 */       FileInputStream fileInputStream = new FileInputStream(paramFile);
/* 184 */       properties.load(fileInputStream);
/* 185 */       fileInputStream.close();
/* 186 */     } catch (IOException iOException) {
/* 187 */       iOException.printStackTrace();
/*     */     } 
/* 189 */     if (javafxPlatform == null) {
/* 190 */       javafxPlatform = properties.getProperty("javafx.platform");
/*     */     }
/* 192 */     String str = javafxPlatform + ".";
/* 193 */     int i = str.length();
/* 194 */     boolean bool = false;
/* 195 */     for (String str1 : properties.keySet()) {
/* 196 */       String str2 = str1;
/* 197 */       if (str2.startsWith(str)) {
/* 198 */         bool = true;
/* 199 */         String str3 = str2.substring(i);
/* 200 */         if (System.getProperty(str3) == null) {
/* 201 */           String str4 = properties.getProperty(str2);
/* 202 */           System.setProperty(str3, str4);
/*     */         } 
/*     */       } 
/*     */     } 
/* 206 */     if (!bool) {
/* 207 */       System.err.println("Warning: No settings found for javafx.platform='" + javafxPlatform + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File getRTDir() {
/*     */     try {
/* 218 */       String str1 = "PlatformUtil.class";
/* 219 */       Class<PlatformUtil> clazz = PlatformUtil.class;
/* 220 */       URL uRL = clazz.getResource(str1);
/* 221 */       if (uRL == null) return null; 
/* 222 */       String str2 = uRL.toString();
/* 223 */       if (!str2.startsWith("jar:file:") || str2
/* 224 */         .indexOf('!') == -1) {
/* 225 */         return null;
/*     */       }
/*     */       
/* 228 */       String str3 = str2.substring(4, str2
/* 229 */           .lastIndexOf('!'));
/*     */       
/* 231 */       int i = Math.max(str3
/* 232 */           .lastIndexOf('/'), str3.lastIndexOf('\\'));
/* 233 */       return (new File((new URL(str3.substring(0, i + 1))).getPath()))
/* 234 */         .getParentFile();
/* 235 */     } catch (MalformedURLException malformedURLException) {
/* 236 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void loadProperties() {
/* 241 */     String str1 = System.getProperty("java.vm.name");
/* 242 */     String str2 = System.getProperty("os.arch");
/*     */     
/* 244 */     if (javafxPlatform == null && (str2 == null || 
/* 245 */       !str2.equals("arm")) && (str1 == null || str1
/* 246 */       .indexOf("Embedded") <= 0)) {
/*     */       return;
/*     */     }
/* 249 */     AccessController.doPrivileged(() -> {
/*     */           File file1 = getRTDir();
/*     */           String str1 = "javafx.platform.properties";
/*     */           File file2 = new File(file1, "javafx.platform.properties");
/*     */           if (file2.exists()) {
/*     */             loadPropertiesFromFile(file2);
/*     */             return null;
/*     */           } 
/*     */           String str2 = System.getProperty("java.home");
/*     */           File file3 = new File(str2, "lib" + File.separator + "javafx.platform.properties");
/*     */           if (file3.exists()) {
/*     */             loadPropertiesFromFile(file3);
/*     */             return null;
/*     */           } 
/*     */           String str3 = System.getProperty("javafx.runtime.path");
/*     */           File file4 = new File(str3, File.separator + "javafx.platform.properties");
/*     */           if (file4.exists()) {
/*     */             loadPropertiesFromFile(file4);
/*     */             return null;
/*     */           } 
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAndroid() {
/* 280 */     return ANDROID;
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\com\sun\javafx\PlatformUtil.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */