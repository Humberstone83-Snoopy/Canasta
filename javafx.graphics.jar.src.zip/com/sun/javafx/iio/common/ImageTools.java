/*     */ package com.sun.javafx.iio.common;
/*     */ 
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Rectangle;
/*     */ import com.sun.javafx.iio.ImageFrame;
/*     */ import com.sun.javafx.iio.ImageMetadata;
/*     */ import com.sun.javafx.iio.ImageStorage;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageTools
/*     */ {
/*     */   public static final int PROGRESS_INTERVAL = 5;
/*     */   
/*     */   public static int readFully(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  72 */     if (paramInt2 < 0) {
/*  73 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  75 */     int i = paramInt2;
/*     */     
/*  77 */     if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfbyte.length || paramInt1 + paramInt2 < 0) {
/*  78 */       throw new IndexOutOfBoundsException("off < 0 || len < 0 || off + len > b.length!");
/*     */     }
/*     */     
/*  81 */     while (paramInt2 > 0) {
/*  82 */       int j = paramInputStream.read(paramArrayOfbyte, paramInt1, paramInt2);
/*  83 */       if (j == -1) {
/*  84 */         throw new EOFException();
/*     */       }
/*  86 */       paramInt1 += j;
/*  87 */       paramInt2 -= j;
/*     */     } 
/*     */     
/*  90 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readFully(InputStream paramInputStream, byte[] paramArrayOfbyte) throws IOException {
/* 108 */     return readFully(paramInputStream, paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void skipFully(InputStream paramInputStream, long paramLong) throws IOException {
/* 120 */     while (paramLong > 0L) {
/* 121 */       long l = paramInputStream.skip(paramLong);
/* 122 */       if (l <= 0L) {
/*     */         
/* 124 */         if (paramInputStream.read() == -1) {
/* 125 */           throw new EOFException();
/*     */         }
/* 127 */         paramLong--; continue;
/*     */       } 
/* 129 */       paramLong -= l;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageStorage.ImageType getConvertedType(ImageStorage.ImageType paramImageType) {
/* 170 */     ImageStorage.ImageType imageType = paramImageType;
/* 171 */     switch (paramImageType) {
/*     */       case GRAY:
/* 173 */         imageType = ImageStorage.ImageType.GRAY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 193 */         return imageType;case GRAY_ALPHA: case GRAY_ALPHA_PRE: case PALETTE_ALPHA: case PALETTE_ALPHA_PRE: case PALETTE_TRANS: case RGBA: imageType = ImageStorage.ImageType.RGBA_PRE; return imageType;case PALETTE: case RGB: imageType = ImageStorage.ImageType.RGB; return imageType;case RGBA_PRE: imageType = ImageStorage.ImageType.RGBA_PRE; return imageType;
/*     */     } 
/*     */     throw new IllegalArgumentException("Unsupported ImageType " + paramImageType);
/*     */   } public static byte[] createImageArray(ImageStorage.ImageType paramImageType, int paramInt1, int paramInt2) {
/* 197 */     byte b = 0;
/* 198 */     switch (paramImageType) {
/*     */       case GRAY:
/*     */       case PALETTE_ALPHA:
/*     */       case PALETTE_ALPHA_PRE:
/*     */       case PALETTE:
/* 203 */         b = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 219 */         return new byte[paramInt1 * paramInt2 * b];case GRAY_ALPHA: case GRAY_ALPHA_PRE: b = 2; return new byte[paramInt1 * paramInt2 * b];case RGB: b = 3; return new byte[paramInt1 * paramInt2 * b];case RGBA: case RGBA_PRE: b = 4; return new byte[paramInt1 * paramInt2 * b];
/*     */     } 
/*     */     throw new IllegalArgumentException("Unsupported ImageType " + paramImageType);
/*     */   } public static ImageFrame convertImageFrame(ImageFrame paramImageFrame) {
/*     */     ImageFrame imageFrame;
/* 224 */     ImageStorage.ImageType imageType1 = paramImageFrame.getImageType();
/* 225 */     ImageStorage.ImageType imageType2 = getConvertedType(imageType1);
/* 226 */     if (imageType2 == imageType1) {
/* 227 */       imageFrame = paramImageFrame;
/*     */     } else {
/* 229 */       byte[] arrayOfByte1 = null;
/* 230 */       Buffer buffer = paramImageFrame.getImageData();
/* 231 */       if (!(buffer instanceof ByteBuffer)) {
/* 232 */         throw new IllegalArgumentException("!(frame.getImageData() instanceof ByteBuffer)");
/*     */       }
/* 234 */       ByteBuffer byteBuffer1 = (ByteBuffer)buffer;
/* 235 */       if (byteBuffer1.hasArray()) {
/* 236 */         arrayOfByte1 = byteBuffer1.array();
/*     */       } else {
/* 238 */         arrayOfByte1 = new byte[byteBuffer1.capacity()];
/* 239 */         byteBuffer1.get(arrayOfByte1);
/*     */       } 
/* 241 */       int i = paramImageFrame.getWidth();
/* 242 */       int j = paramImageFrame.getHeight();
/* 243 */       int k = paramImageFrame.getStride();
/* 244 */       byte[] arrayOfByte2 = createImageArray(imageType2, i, j);
/* 245 */       ByteBuffer byteBuffer2 = ByteBuffer.wrap(arrayOfByte2);
/* 246 */       int m = arrayOfByte2.length / j;
/* 247 */       byte[][] arrayOfByte = paramImageFrame.getPalette();
/* 248 */       ImageMetadata imageMetadata1 = paramImageFrame.getMetadata();
/* 249 */       boolean bool = (imageMetadata1.transparentIndex != null) ? imageMetadata1.transparentIndex.intValue() : false;
/* 250 */       convert(i, j, imageType1, arrayOfByte1, 0, k, arrayOfByte2, 0, m, arrayOfByte, bool, false);
/*     */ 
/*     */       
/* 253 */       ImageMetadata imageMetadata2 = new ImageMetadata(imageMetadata1.gamma, imageMetadata1.blackIsZero, null, imageMetadata1.backgroundColor, null, imageMetadata1.delayTime, imageMetadata1.loopCount, imageMetadata1.imageWidth, imageMetadata1.imageHeight, imageMetadata1.imageLeftPosition, imageMetadata1.imageTopPosition, imageMetadata1.disposalMethod);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 260 */       imageFrame = new ImageFrame(imageType2, byteBuffer2, i, j, m, null, imageMetadata2);
/*     */     } 
/*     */     
/* 263 */     return imageFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] convert(int paramInt1, int paramInt2, ImageStorage.ImageType paramImageType, byte[] paramArrayOfbyte1, int paramInt3, int paramInt4, byte[] paramArrayOfbyte2, int paramInt5, int paramInt6, byte[][] paramArrayOfbyte, int paramInt7, boolean paramBoolean) {
/* 273 */     if (paramImageType == ImageStorage.ImageType.GRAY || paramImageType == ImageStorage.ImageType.RGB || paramImageType == ImageStorage.ImageType.RGBA_PRE) {
/*     */ 
/*     */       
/* 276 */       if (paramArrayOfbyte1 != paramArrayOfbyte2) {
/* 277 */         int i = paramInt1;
/* 278 */         if (paramImageType == ImageStorage.ImageType.RGB) {
/* 279 */           i *= 3;
/* 280 */         } else if (paramImageType == ImageStorage.ImageType.RGBA_PRE) {
/* 281 */           i *= 4;
/*     */         } 
/* 283 */         if (paramInt2 == 1) {
/* 284 */           System.arraycopy(paramArrayOfbyte1, paramInt3, paramArrayOfbyte2, paramInt5, i);
/*     */         } else {
/* 286 */           int j = paramInt3;
/* 287 */           int k = paramInt5;
/* 288 */           for (byte b = 0; b < paramInt2; b++) {
/* 289 */             System.arraycopy(paramArrayOfbyte1, j, paramArrayOfbyte2, k, i);
/* 290 */             j += paramInt4;
/* 291 */             k += paramInt6;
/*     */           } 
/*     */         } 
/*     */       } 
/* 295 */     } else if (paramImageType == ImageStorage.ImageType.GRAY_ALPHA || paramImageType == ImageStorage.ImageType.GRAY_ALPHA_PRE) {
/* 296 */       int i = paramInt3;
/* 297 */       int j = paramInt5;
/* 298 */       if (paramImageType == ImageStorage.ImageType.GRAY_ALPHA) {
/* 299 */         for (byte b = 0; b < paramInt2; b++) {
/* 300 */           int k = i;
/* 301 */           int m = j;
/* 302 */           for (byte b1 = 0; b1 < paramInt1; b1++) {
/*     */             
/* 304 */             byte b2 = paramArrayOfbyte1[k++];
/* 305 */             int n = paramArrayOfbyte1[k++] & 0xFF;
/* 306 */             float f = n / 255.0F;
/* 307 */             b2 = (byte)(int)(f * (b2 & 0xFF));
/* 308 */             paramArrayOfbyte2[m++] = b2;
/* 309 */             paramArrayOfbyte2[m++] = b2;
/* 310 */             paramArrayOfbyte2[m++] = b2;
/* 311 */             paramArrayOfbyte2[m++] = (byte)n;
/*     */           } 
/* 313 */           i += paramInt4;
/* 314 */           j += paramInt6;
/*     */         } 
/*     */       } else {
/* 317 */         for (byte b = 0; b < paramInt2; b++) {
/* 318 */           int k = i;
/* 319 */           int m = j;
/* 320 */           for (byte b1 = 0; b1 < paramInt1; b1++) {
/*     */             
/* 322 */             byte b2 = paramArrayOfbyte1[k++];
/* 323 */             paramArrayOfbyte2[m++] = b2;
/* 324 */             paramArrayOfbyte2[m++] = b2;
/* 325 */             paramArrayOfbyte2[m++] = b2;
/* 326 */             paramArrayOfbyte2[m++] = paramArrayOfbyte1[k++];
/*     */           } 
/* 328 */           i += paramInt4;
/* 329 */           j += paramInt6;
/*     */         } 
/*     */       } 
/* 332 */     } else if (paramImageType == ImageStorage.ImageType.PALETTE) {
/* 333 */       int i = paramInt3;
/* 334 */       int j = paramInt5;
/* 335 */       byte[] arrayOfByte1 = paramArrayOfbyte[0];
/* 336 */       byte[] arrayOfByte2 = paramArrayOfbyte[1];
/* 337 */       byte[] arrayOfByte3 = paramArrayOfbyte[2];
/* 338 */       int k = i;
/* 339 */       int m = j;
/*     */ 
/*     */       
/* 342 */       for (byte b = 0; b < paramInt1; b++) {
/* 343 */         int n = paramArrayOfbyte1[k++] & 0xFF;
/*     */         
/* 345 */         paramArrayOfbyte2[m++] = arrayOfByte1[n];
/* 346 */         paramArrayOfbyte2[m++] = arrayOfByte2[n];
/* 347 */         paramArrayOfbyte2[m++] = arrayOfByte3[n];
/*     */         
/* 349 */         j += paramInt6;
/*     */       } 
/* 351 */     } else if (paramImageType == ImageStorage.ImageType.PALETTE_ALPHA) {
/* 352 */       int i = paramInt3;
/* 353 */       int j = paramInt5;
/* 354 */       byte[] arrayOfByte1 = paramArrayOfbyte[0];
/* 355 */       byte[] arrayOfByte2 = paramArrayOfbyte[1];
/* 356 */       byte[] arrayOfByte3 = paramArrayOfbyte[2];
/* 357 */       byte[] arrayOfByte4 = paramArrayOfbyte[3];
/* 358 */       int k = i;
/* 359 */       int m = j;
/* 360 */       for (byte b = 0; b < paramInt1; b++) {
/* 361 */         int n = paramArrayOfbyte1[k++] & 0xFF;
/* 362 */         byte b1 = arrayOfByte1[n];
/* 363 */         byte b2 = arrayOfByte2[n];
/* 364 */         byte b3 = arrayOfByte3[n];
/* 365 */         int i1 = arrayOfByte4[n] & 0xFF;
/* 366 */         float f = i1 / 255.0F;
/* 367 */         paramArrayOfbyte2[m++] = (byte)(int)(f * (b1 & 0xFF));
/* 368 */         paramArrayOfbyte2[m++] = (byte)(int)(f * (b2 & 0xFF));
/* 369 */         paramArrayOfbyte2[m++] = (byte)(int)(f * (b3 & 0xFF));
/* 370 */         paramArrayOfbyte2[m++] = (byte)i1;
/*     */       } 
/* 372 */       i += paramInt4;
/* 373 */       j += paramInt6;
/* 374 */     } else if (paramImageType == ImageStorage.ImageType.PALETTE_ALPHA_PRE) {
/* 375 */       int i = paramInt3;
/* 376 */       int j = paramInt5;
/* 377 */       byte[] arrayOfByte1 = paramArrayOfbyte[0];
/* 378 */       byte[] arrayOfByte2 = paramArrayOfbyte[1];
/* 379 */       byte[] arrayOfByte3 = paramArrayOfbyte[2];
/* 380 */       byte[] arrayOfByte4 = paramArrayOfbyte[3];
/* 381 */       for (byte b = 0; b < paramInt2; b++) {
/* 382 */         int k = i;
/* 383 */         int m = j;
/* 384 */         for (byte b1 = 0; b1 < paramInt1; b1++) {
/* 385 */           int n = paramArrayOfbyte1[k++] & 0xFF;
/* 386 */           paramArrayOfbyte2[m++] = arrayOfByte1[n];
/* 387 */           paramArrayOfbyte2[m++] = arrayOfByte2[n];
/* 388 */           paramArrayOfbyte2[m++] = arrayOfByte3[n];
/* 389 */           paramArrayOfbyte2[m++] = arrayOfByte4[n];
/*     */         } 
/* 391 */         i += paramInt4;
/* 392 */         j += paramInt6;
/*     */       } 
/* 394 */     } else if (paramImageType == ImageStorage.ImageType.PALETTE_TRANS) {
/* 395 */       int i = paramInt3;
/* 396 */       int j = paramInt5;
/* 397 */       for (byte b = 0; b < paramInt2; b++) {
/* 398 */         int k = i;
/* 399 */         int m = j;
/* 400 */         byte[] arrayOfByte1 = paramArrayOfbyte[0];
/* 401 */         byte[] arrayOfByte2 = paramArrayOfbyte[1];
/* 402 */         byte[] arrayOfByte3 = paramArrayOfbyte[2];
/* 403 */         for (byte b1 = 0; b1 < paramInt1; b1++) {
/* 404 */           int n = paramArrayOfbyte1[k++] & 0xFF;
/* 405 */           if (n == paramInt7) {
/* 406 */             if (paramBoolean) {
/* 407 */               m += 4;
/*     */             } else {
/* 409 */               paramArrayOfbyte2[m++] = 0;
/* 410 */               paramArrayOfbyte2[m++] = 0;
/* 411 */               paramArrayOfbyte2[m++] = 0;
/* 412 */               paramArrayOfbyte2[m++] = 0;
/*     */             } 
/*     */           } else {
/* 415 */             paramArrayOfbyte2[m++] = arrayOfByte1[n];
/* 416 */             paramArrayOfbyte2[m++] = arrayOfByte2[n];
/* 417 */             paramArrayOfbyte2[m++] = arrayOfByte3[n];
/* 418 */             paramArrayOfbyte2[m++] = -1;
/*     */           } 
/*     */         } 
/* 421 */         i += paramInt4;
/* 422 */         j += paramInt6;
/*     */       } 
/* 424 */     } else if (paramImageType == ImageStorage.ImageType.RGBA) {
/* 425 */       int i = paramInt3;
/* 426 */       int j = paramInt5;
/* 427 */       for (byte b = 0; b < paramInt2; b++) {
/* 428 */         int k = i;
/* 429 */         int m = j;
/* 430 */         for (byte b1 = 0; b1 < paramInt1; b1++) {
/*     */           
/* 432 */           byte b2 = paramArrayOfbyte1[k++];
/* 433 */           byte b3 = paramArrayOfbyte1[k++];
/* 434 */           byte b4 = paramArrayOfbyte1[k++];
/* 435 */           int n = paramArrayOfbyte1[k++] & 0xFF;
/* 436 */           float f = n / 255.0F;
/* 437 */           paramArrayOfbyte2[m++] = (byte)(int)(f * (b2 & 0xFF));
/* 438 */           paramArrayOfbyte2[m++] = (byte)(int)(f * (b3 & 0xFF));
/* 439 */           paramArrayOfbyte2[m++] = (byte)(int)(f * (b4 & 0xFF));
/* 440 */           paramArrayOfbyte2[m++] = (byte)n;
/*     */         } 
/*     */         
/* 443 */         i += paramInt4;
/* 444 */         j += paramInt6;
/*     */       } 
/*     */     } else {
/* 447 */       throw new UnsupportedOperationException("Unsupported ImageType " + paramImageType);
/*     */     } 
/*     */ 
/*     */     
/* 451 */     return paramArrayOfbyte2;
/*     */   }
/*     */   
/*     */   public static String getScaledImageName(String paramString) {
/* 455 */     StringBuilder stringBuilder = new StringBuilder();
/* 456 */     int i = paramString.lastIndexOf('/');
/* 457 */     String str = (i < 0) ? paramString : paramString.substring(i + 1);
/* 458 */     int j = str.lastIndexOf(".");
/* 459 */     if (j < 0) {
/* 460 */       j = str.length();
/*     */     }
/* 462 */     if (i >= 0) {
/* 463 */       stringBuilder.append(paramString.substring(0, i + 1));
/*     */     }
/* 465 */     stringBuilder.append(str.substring(0, j));
/* 466 */     stringBuilder.append("@2x");
/* 467 */     stringBuilder.append(str.substring(j));
/* 468 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   public static InputStream createInputStream(String paramString) throws IOException {
/* 472 */     InputStream inputStream = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 477 */       File file = new File(paramString);
/* 478 */       if (file.exists()) {
/* 479 */         inputStream = new FileInputStream(file);
/*     */       }
/* 481 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 484 */     if (inputStream == null) {
/* 485 */       URL uRL = new URL(paramString);
/* 486 */       inputStream = uRL.openStream();
/*     */     } 
/* 488 */     return inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void computeUpdatedPixels(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int[] paramArrayOfint, int paramInt10) {
/* 532 */     boolean bool = false;
/* 533 */     int i = -1;
/* 534 */     int j = -1;
/* 535 */     int k = -1;
/*     */     
/* 537 */     for (byte b = 0; b < paramInt8; b++) {
/* 538 */       int m = paramInt7 + b * paramInt9;
/* 539 */       if (m >= paramInt1)
/*     */       {
/*     */         
/* 542 */         if ((m - paramInt1) % paramInt6 == 0) {
/*     */ 
/*     */           
/* 545 */           if (m >= paramInt1 + paramInt2) {
/*     */             break;
/*     */           }
/*     */           
/* 549 */           int n = paramInt3 + (m - paramInt1) / paramInt6;
/*     */           
/* 551 */           if (n >= paramInt4) {
/*     */ 
/*     */             
/* 554 */             if (n > paramInt5) {
/*     */               break;
/*     */             }
/*     */             
/* 558 */             if (!bool) {
/* 559 */               i = n;
/* 560 */               bool = true;
/* 561 */             } else if (j == -1) {
/* 562 */               j = n;
/*     */             } 
/* 564 */             k = n;
/*     */           } 
/*     */         }  } 
/* 567 */     }  paramArrayOfint[paramInt10] = i;
/*     */ 
/*     */     
/* 570 */     if (!bool) {
/* 571 */       paramArrayOfint[paramInt10 + 2] = 0;
/*     */     } else {
/* 573 */       paramArrayOfint[paramInt10 + 2] = k - i + 1;
/*     */     } 
/*     */ 
/*     */     
/* 577 */     paramArrayOfint[paramInt10 + 4] = Math.max(j - i, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] computeUpdatedPixels(Rectangle paramRectangle, Point2D paramPoint2D, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12) {
/* 637 */     int[] arrayOfInt = new int[6];
/* 638 */     computeUpdatedPixels(paramRectangle.x, paramRectangle.width, (int)(paramPoint2D.x + 0.5F), paramInt1, paramInt3, paramInt5, paramInt7, paramInt9, paramInt11, arrayOfInt, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 643 */     computeUpdatedPixels(paramRectangle.y, paramRectangle.height, (int)(paramPoint2D.y + 0.5F), paramInt2, paramInt4, paramInt6, paramInt8, paramInt10, paramInt12, arrayOfInt, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 648 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] computeDimensions(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 654 */     int i = (paramInt3 < 0) ? 0 : paramInt3;
/* 655 */     int j = (paramInt4 < 0) ? 0 : paramInt4;
/*     */     
/* 657 */     if (!i && !j) {
/*     */       
/* 659 */       i = paramInt1;
/* 660 */       j = paramInt2;
/* 661 */     } else if (i != paramInt1 || j != paramInt2) {
/* 662 */       if (paramBoolean) {
/*     */         
/* 664 */         if (i == 0) {
/* 665 */           i = (int)(paramInt1 * j / paramInt2);
/* 666 */         } else if (j == 0) {
/* 667 */           j = (int)(paramInt2 * i / paramInt1);
/*     */         } else {
/* 669 */           float f = Math.min(i / paramInt1, j / paramInt2);
/* 670 */           i = (int)(paramInt1 * f);
/* 671 */           j = (int)(paramInt2 * f);
/*     */         } 
/*     */       } else {
/*     */         
/* 675 */         if (j == 0) {
/* 676 */           j = paramInt2;
/*     */         }
/* 678 */         if (i == 0) {
/* 679 */           i = paramInt1;
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 685 */       if (i == 0) {
/* 686 */         i = 1;
/*     */       }
/* 688 */       if (j == 0) {
/* 689 */         j = 1;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 694 */     return new int[] { i, j };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageFrame scaleImageFrame(ImageFrame paramImageFrame, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 700 */     int i = ImageStorage.getNumBands(paramImageFrame.getImageType());
/* 701 */     ByteBuffer byteBuffer = scaleImage((ByteBuffer)paramImageFrame.getImageData(), paramImageFrame
/* 702 */         .getWidth(), paramImageFrame.getHeight(), i, paramInt1, paramInt2, paramBoolean);
/*     */     
/* 704 */     return new ImageFrame(paramImageFrame.getImageType(), byteBuffer, paramInt1, paramInt2, paramInt1 * i, null, paramImageFrame
/* 705 */         .getMetadata());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteBuffer scaleImage(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean) {
/* 712 */     PushbroomScaler pushbroomScaler = ScalerFactory.createScaler(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramBoolean);
/*     */ 
/*     */ 
/*     */     
/* 716 */     int i = paramInt1 * paramInt3;
/* 717 */     if (paramByteBuffer.hasArray()) {
/* 718 */       byte[] arrayOfByte = paramByteBuffer.array();
/* 719 */       for (int j = 0; j != paramInt2; j++) {
/* 720 */         pushbroomScaler.putSourceScanline(arrayOfByte, j * i);
/*     */       }
/*     */     } else {
/* 723 */       byte[] arrayOfByte = new byte[i];
/* 724 */       for (int j = 0; j != paramInt2; j++) {
/* 725 */         paramByteBuffer.get(arrayOfByte);
/* 726 */         pushbroomScaler.putSourceScanline(arrayOfByte, 0);
/*     */       } 
/*     */     } 
/*     */     
/* 730 */     return pushbroomScaler.getDestination();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\common\ImageTools.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */