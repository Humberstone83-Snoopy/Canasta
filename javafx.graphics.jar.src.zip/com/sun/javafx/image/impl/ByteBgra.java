/*     */ package com.sun.javafx.image.impl;
/*     */ 
/*     */ import com.sun.javafx.image.AlphaType;
/*     */ import com.sun.javafx.image.BytePixelAccessor;
/*     */ import com.sun.javafx.image.BytePixelGetter;
/*     */ import com.sun.javafx.image.BytePixelSetter;
/*     */ import com.sun.javafx.image.ByteToBytePixelConverter;
/*     */ import com.sun.javafx.image.ByteToIntPixelConverter;
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteBgra
/*     */ {
/*  39 */   public static final BytePixelGetter getter = Accessor.instance;
/*  40 */   public static final BytePixelSetter setter = Accessor.instance;
/*  41 */   public static final BytePixelAccessor accessor = Accessor.instance;
/*     */   private static ByteToBytePixelConverter ToByteBgraConv;
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraConverter() {
/*  45 */     if (ToByteBgraConv == null) {
/*  46 */       ToByteBgraConv = BaseByteToByteConverter.create(accessor);
/*     */     }
/*  48 */     return ToByteBgraConv;
/*     */   }
/*     */   
/*     */   public static ByteToBytePixelConverter ToByteBgraPreConverter() {
/*  52 */     return ToByteBgraPreConv.instance;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbConverter() {
/*  56 */     return ToIntArgbSameConv.nonpremul;
/*     */   }
/*     */   
/*     */   public static ByteToIntPixelConverter ToIntArgbPreConverter() {
/*  60 */     return ToIntArgbPreConv.instance;
/*     */   }
/*     */   
/*     */   static class Accessor implements BytePixelAccessor {
/*  64 */     static final BytePixelAccessor instance = new Accessor();
/*     */ 
/*     */ 
/*     */     
/*     */     public AlphaType getAlphaType() {
/*  69 */       return AlphaType.NONPREMULTIPLIED;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getNumElements() {
/*  74 */       return 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(byte[] param1ArrayOfbyte, int param1Int) {
/*  79 */       return param1ArrayOfbyte[param1Int] & 0xFF | (param1ArrayOfbyte[param1Int + 1] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int + 2] & 0xFF) << 16 | param1ArrayOfbyte[param1Int + 3] << 24;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getArgbPre(byte[] param1ArrayOfbyte, int param1Int) {
/*  87 */       return PixelUtils.NonPretoPre(getArgb(param1ArrayOfbyte, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgb(ByteBuffer param1ByteBuffer, int param1Int) {
/*  92 */       return param1ByteBuffer.get(param1Int) & 0xFF | (param1ByteBuffer
/*  93 */         .get(param1Int + 1) & 0xFF) << 8 | (param1ByteBuffer
/*  94 */         .get(param1Int + 2) & 0xFF) << 16 | param1ByteBuffer
/*  95 */         .get(param1Int + 3) << 24;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getArgbPre(ByteBuffer param1ByteBuffer, int param1Int) {
/* 100 */       return PixelUtils.NonPretoPre(getArgb(param1ByteBuffer, param1Int));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 105 */       param1ArrayOfbyte[param1Int1] = (byte)param1Int2;
/* 106 */       param1ArrayOfbyte[param1Int1 + 1] = (byte)(param1Int2 >> 8);
/* 107 */       param1ArrayOfbyte[param1Int1 + 2] = (byte)(param1Int2 >> 16);
/* 108 */       param1ArrayOfbyte[param1Int1 + 3] = (byte)(param1Int2 >> 24);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {
/* 113 */       setArgb(param1ArrayOfbyte, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgb(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 118 */       param1ByteBuffer.put(param1Int1, (byte)param1Int2);
/* 119 */       param1ByteBuffer.put(param1Int1 + 1, (byte)(param1Int2 >> 8));
/* 120 */       param1ByteBuffer.put(param1Int1 + 2, (byte)(param1Int2 >> 16));
/* 121 */       param1ByteBuffer.put(param1Int1 + 3, (byte)(param1Int2 >> 24));
/*     */     }
/*     */ 
/*     */     
/*     */     public void setArgbPre(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2) {
/* 126 */       setArgb(param1ByteBuffer, param1Int1, PixelUtils.PretoNonPre(param1Int2));
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToByteBgraPreConv extends BaseByteToByteConverter {
/* 131 */     static final ByteToBytePixelConverter instance = new ToByteBgraPreConv();
/*     */ 
/*     */     
/*     */     private ToByteBgraPreConv() {
/* 135 */       super(ByteBgra.getter, ByteBgraPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte1, int param1Int1, int param1Int2, byte[] param1ArrayOfbyte2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 143 */       param1Int2 -= param1Int5 * 4;
/* 144 */       param1Int4 -= param1Int5 * 4;
/* 145 */       while (--param1Int6 >= 0) {
/* 146 */         for (byte b = 0; b < param1Int5; b++) {
/* 147 */           byte b1 = param1ArrayOfbyte1[param1Int1++];
/* 148 */           byte b2 = param1ArrayOfbyte1[param1Int1++];
/* 149 */           byte b3 = param1ArrayOfbyte1[param1Int1++];
/* 150 */           int i = param1ArrayOfbyte1[param1Int1++] & 0xFF;
/* 151 */           if (i < 255) {
/* 152 */             if (i == 0) {
/* 153 */               b1 = b2 = b3 = 0;
/*     */             } else {
/* 155 */               b1 = (byte)(((b1 & 0xFF) * i + 127) / 255);
/* 156 */               b2 = (byte)(((b2 & 0xFF) * i + 127) / 255);
/* 157 */               b3 = (byte)(((b3 & 0xFF) * i + 127) / 255);
/*     */             } 
/*     */           }
/* 160 */           param1ArrayOfbyte2[param1Int3++] = b1;
/* 161 */           param1ArrayOfbyte2[param1Int3++] = b2;
/* 162 */           param1ArrayOfbyte2[param1Int3++] = b3;
/* 163 */           param1ArrayOfbyte2[param1Int3++] = (byte)i;
/*     */         } 
/* 165 */         param1Int1 += param1Int2;
/* 166 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer1, int param1Int1, int param1Int2, ByteBuffer param1ByteBuffer2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 175 */       param1Int2 -= param1Int5 * 4;
/* 176 */       param1Int4 -= param1Int5 * 4;
/* 177 */       while (--param1Int6 >= 0) {
/* 178 */         for (byte b = 0; b < param1Int5; b++) {
/* 179 */           byte b1 = param1ByteBuffer1.get(param1Int1);
/* 180 */           byte b2 = param1ByteBuffer1.get(param1Int1 + 1);
/* 181 */           byte b3 = param1ByteBuffer1.get(param1Int1 + 2);
/* 182 */           int i = param1ByteBuffer1.get(param1Int1 + 3) & 0xFF;
/* 183 */           param1Int1 += 4;
/* 184 */           if (i < 255) {
/* 185 */             if (i == 0) {
/* 186 */               b1 = b2 = b3 = 0;
/*     */             } else {
/* 188 */               b1 = (byte)(((b1 & 0xFF) * i + 127) / 255);
/* 189 */               b2 = (byte)(((b2 & 0xFF) * i + 127) / 255);
/* 190 */               b3 = (byte)(((b3 & 0xFF) * i + 127) / 255);
/*     */             } 
/*     */           }
/* 193 */           param1ByteBuffer2.put(param1Int3, b1);
/* 194 */           param1ByteBuffer2.put(param1Int3 + 1, b2);
/* 195 */           param1ByteBuffer2.put(param1Int3 + 2, b3);
/* 196 */           param1ByteBuffer2.put(param1Int3 + 3, (byte)i);
/* 197 */           param1Int3 += 4;
/*     */         } 
/* 199 */         param1Int1 += param1Int2;
/* 200 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntArgbSameConv extends BaseByteToIntConverter {
/* 206 */     static final ByteToIntPixelConverter nonpremul = new ToIntArgbSameConv(false);
/* 207 */     static final ByteToIntPixelConverter premul = new ToIntArgbSameConv(true);
/*     */     
/*     */     private ToIntArgbSameConv(boolean param1Boolean) {
/* 210 */       super(param1Boolean ? ByteBgraPre.getter : ByteBgra.getter, 
/* 211 */           param1Boolean ? IntArgbPre.setter : IntArgb.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 219 */       param1Int2 -= param1Int5 * 4;
/* 220 */       param1Int4 -= param1Int5;
/* 221 */       while (--param1Int6 >= 0) {
/* 222 */         for (byte b = 0; b < param1Int5; b++) {
/* 223 */           param1ArrayOfint[param1Int3++] = param1ArrayOfbyte[param1Int1++] & 0xFF | (param1ArrayOfbyte[param1Int1++] & 0xFF) << 8 | (param1ArrayOfbyte[param1Int1++] & 0xFF) << 16 | param1ArrayOfbyte[param1Int1++] << 24;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         param1Int1 += param1Int2;
/* 230 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 239 */       param1Int2 -= param1Int5 * 4;
/* 240 */       while (--param1Int6 >= 0) {
/* 241 */         for (byte b = 0; b < param1Int5; b++) {
/* 242 */           param1IntBuffer.put(param1Int3 + b, param1ByteBuffer
/* 243 */               .get(param1Int1) & 0xFF | (param1ByteBuffer
/* 244 */               .get(param1Int1 + 1) & 0xFF) << 8 | (param1ByteBuffer
/* 245 */               .get(param1Int1 + 2) & 0xFF) << 16 | param1ByteBuffer
/* 246 */               .get(param1Int1 + 3) << 24);
/* 247 */           param1Int1 += 4;
/*     */         } 
/* 249 */         param1Int1 += param1Int2;
/* 250 */         param1Int3 += param1Int4;
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class ToIntArgbPreConv extends BaseByteToIntConverter {
/* 256 */     public static final ByteToIntPixelConverter instance = new ToIntArgbPreConv();
/*     */ 
/*     */     
/*     */     private ToIntArgbPreConv() {
/* 260 */       super(ByteBgra.getter, IntArgbPre.setter);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2, int[] param1ArrayOfint, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 268 */       param1Int2 -= param1Int5 * 4;
/* 269 */       param1Int4 -= param1Int5;
/* 270 */       while (--param1Int6 >= 0) {
/* 271 */         for (byte b = 0; b < param1Int5; b++) {
/* 272 */           int i = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 273 */           int j = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 274 */           int k = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 275 */           int m = param1ArrayOfbyte[param1Int1++] & 0xFF;
/* 276 */           if (m < 255) {
/* 277 */             if (m == 0) {
/* 278 */               i = j = k = 0;
/*     */             } else {
/* 280 */               i = (i * m + 127) / 255;
/* 281 */               j = (j * m + 127) / 255;
/* 282 */               k = (k * m + 127) / 255;
/*     */             } 
/*     */           }
/* 285 */           param1ArrayOfint[param1Int3++] = m << 24 | k << 16 | j << 8 | i;
/*     */         } 
/*     */         
/* 288 */         param1Int3 += param1Int4;
/* 289 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void doConvert(ByteBuffer param1ByteBuffer, int param1Int1, int param1Int2, IntBuffer param1IntBuffer, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 298 */       param1Int2 -= param1Int5 * 4;
/* 299 */       while (--param1Int6 >= 0) {
/* 300 */         for (byte b = 0; b < param1Int5; b++) {
/* 301 */           int i = param1ByteBuffer.get(param1Int1) & 0xFF;
/* 302 */           int j = param1ByteBuffer.get(param1Int1 + 1) & 0xFF;
/* 303 */           int k = param1ByteBuffer.get(param1Int1 + 2) & 0xFF;
/* 304 */           int m = param1ByteBuffer.get(param1Int1 + 3) & 0xFF;
/* 305 */           param1Int1 += 4;
/* 306 */           if (m < 255) {
/* 307 */             if (m == 0) {
/* 308 */               i = j = k = 0;
/*     */             } else {
/* 310 */               i = (i * m + 127) / 255;
/* 311 */               j = (j * m + 127) / 255;
/* 312 */               k = (k * m + 127) / 255;
/*     */             } 
/*     */           }
/* 315 */           param1IntBuffer.put(param1Int3 + b, m << 24 | k << 16 | j << 8 | i);
/*     */         } 
/* 317 */         param1Int3 += param1Int4;
/* 318 */         param1Int1 += param1Int2;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\impl\ByteBgra.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */