/*    */ package com.sun.javafx.scene.input;
/*    */ 
/*    */ import com.sun.javafx.util.Utils;
/*    */ import javafx.scene.input.Clipboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClipboardHelper
/*    */ {
/*    */   private static ClipboardAccessor clipboardAccessor;
/*    */   
/*    */   static {
/* 39 */     Utils.forceInit(Clipboard.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean contentPut(Clipboard paramClipboard) {
/* 46 */     return clipboardAccessor.contentPut(paramClipboard);
/*    */   }
/*    */   
/*    */   public static void setClipboardAccessor(ClipboardAccessor paramClipboardAccessor) {
/* 50 */     if (clipboardAccessor != null) {
/* 51 */       throw new IllegalStateException();
/*    */     }
/*    */     
/* 54 */     clipboardAccessor = paramClipboardAccessor;
/*    */   }
/*    */   
/*    */   public static interface ClipboardAccessor {
/*    */     boolean contentPut(Clipboard param1Clipboard);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\input\ClipboardHelper.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */