/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import com.sun.webkit.Disposer;
/*    */ import com.sun.webkit.DisposerRecord;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NodeListImpl
/*    */   implements NodeList
/*    */ {
/*    */   private final long peer;
/*    */   
/*    */   private static class SelfDisposer
/*    */     implements DisposerRecord
/*    */   {
/*    */     private final long peer;
/*    */     
/*    */     SelfDisposer(long param1Long) {
/* 37 */       this.peer = param1Long;
/*    */     }
/*    */     public void dispose() {
/* 40 */       NodeListImpl.dispose(this.peer);
/*    */     }
/*    */   }
/*    */   
/*    */   NodeListImpl(long paramLong) {
/* 45 */     this.peer = paramLong;
/* 46 */     Disposer.addRecord(this, new SelfDisposer(paramLong));
/*    */   }
/*    */   
/*    */   static NodeList create(long paramLong) {
/* 50 */     if (paramLong == 0L) return null; 
/* 51 */     return new NodeListImpl(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   long getPeer() {
/* 57 */     return this.peer;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 61 */     return (paramObject instanceof NodeListImpl && this.peer == ((NodeListImpl)paramObject).peer);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 65 */     long l = this.peer;
/* 66 */     return (int)(l ^ l >> 17L);
/*    */   }
/*    */   
/*    */   static long getPeer(NodeList paramNodeList) {
/* 70 */     return (paramNodeList == null) ? 0L : ((NodeListImpl)paramNodeList).getPeer();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static NodeList getImpl(long paramLong) {
/* 76 */     return create(paramLong);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 82 */     return getLengthImpl(getPeer());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node item(int paramInt) {
/* 90 */     return NodeImpl.getImpl(itemImpl(getPeer(), paramInt));
/*    */   }
/*    */   
/*    */   private static native void dispose(long paramLong);
/*    */   
/*    */   static native int getLengthImpl(long paramLong);
/*    */   
/*    */   static native long itemImpl(long paramLong, int paramInt);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\NodeListImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */