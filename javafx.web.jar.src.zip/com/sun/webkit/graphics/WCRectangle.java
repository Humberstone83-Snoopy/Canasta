/*     */ package com.sun.webkit.graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WCRectangle
/*     */ {
/*     */   float x;
/*     */   float y;
/*     */   float w;
/*     */   float h;
/*     */   
/*     */   public WCRectangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  35 */     this.x = paramFloat1;
/*  36 */     this.y = paramFloat2;
/*  37 */     this.w = paramFloat3;
/*  38 */     this.h = paramFloat4;
/*     */   }
/*     */   
/*     */   public WCRectangle(WCRectangle paramWCRectangle) {
/*  42 */     this.x = paramWCRectangle.x;
/*  43 */     this.y = paramWCRectangle.y;
/*  44 */     this.w = paramWCRectangle.w;
/*  45 */     this.h = paramWCRectangle.h;
/*     */   }
/*     */ 
/*     */   
/*     */   public WCRectangle() {}
/*     */   
/*     */   public float getX() {
/*  52 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getIntX() {
/*  56 */     return (int)this.x;
/*     */   }
/*     */   
/*     */   public float getY() {
/*  60 */     return this.y;
/*     */   }
/*     */   
/*     */   public int getIntY() {
/*  64 */     return (int)this.y;
/*     */   }
/*     */   
/*     */   public float getWidth() {
/*  68 */     return this.w;
/*     */   }
/*     */   
/*     */   public int getIntWidth() {
/*  72 */     return (int)this.w;
/*     */   }
/*     */   
/*     */   public float getHeight() {
/*  76 */     return this.h;
/*     */   }
/*     */   
/*     */   public int getIntHeight() {
/*  80 */     return (int)this.h;
/*     */   }
/*     */   
/*     */   public boolean contains(WCRectangle paramWCRectangle) {
/*  84 */     return (this.x <= paramWCRectangle.x && this.x + this.w >= paramWCRectangle.x + paramWCRectangle.w && this.y <= paramWCRectangle.y && this.y + this.h >= paramWCRectangle.y + paramWCRectangle.h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WCRectangle intersection(WCRectangle paramWCRectangle) {
/*  98 */     float f1 = this.x;
/*  99 */     float f2 = this.y;
/* 100 */     float f3 = paramWCRectangle.x;
/* 101 */     float f4 = paramWCRectangle.y;
/* 102 */     float f5 = f1; f5 += this.w;
/* 103 */     float f6 = f2; f6 += this.h;
/* 104 */     float f7 = f3; f7 += paramWCRectangle.w;
/* 105 */     float f8 = f4; f8 += paramWCRectangle.h;
/* 106 */     if (f1 < f3) f1 = f3; 
/* 107 */     if (f2 < f4) f2 = f4; 
/* 108 */     if (f5 > f7) f5 = f7; 
/* 109 */     if (f6 > f8) f6 = f8; 
/* 110 */     f5 -= f1;
/* 111 */     f6 -= f2;
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (f5 < Float.MIN_VALUE) f5 = Float.MIN_VALUE; 
/* 116 */     if (f6 < Float.MIN_VALUE) f6 = Float.MIN_VALUE; 
/* 117 */     return new WCRectangle(f1, f2, f5, f6);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void translate(float paramFloat1, float paramFloat2) {
/* 130 */     float f1 = this.x;
/* 131 */     float f2 = f1 + paramFloat1;
/* 132 */     if (paramFloat1 < 0.0F) {
/*     */       
/* 134 */       if (f2 > f1)
/*     */       {
/*     */         
/* 137 */         if (this.w >= 0.0F)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 145 */           this.w += f2 - Float.MIN_VALUE;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         f2 = Float.MIN_VALUE;
/*     */       }
/*     */     
/*     */     }
/* 155 */     else if (f2 < f1) {
/*     */       
/* 157 */       if (this.w >= 0.0F) {
/*     */ 
/*     */         
/* 160 */         this.w += f2 - Float.MAX_VALUE;
/*     */ 
/*     */         
/* 163 */         if (this.w < 0.0F) this.w = Float.MAX_VALUE; 
/*     */       } 
/* 165 */       f2 = Float.MAX_VALUE;
/*     */     } 
/*     */     
/* 168 */     this.x = f2;
/*     */     
/* 170 */     f1 = this.y;
/* 171 */     f2 = f1 + paramFloat2;
/* 172 */     if (paramFloat2 < 0.0F) {
/*     */       
/* 174 */       if (f2 > f1)
/*     */       {
/* 176 */         if (this.h >= 0.0F) {
/* 177 */           this.h += f2 - Float.MIN_VALUE;
/*     */         }
/*     */         
/* 180 */         f2 = Float.MIN_VALUE;
/*     */       }
/*     */     
/*     */     }
/* 184 */     else if (f2 < f1) {
/*     */       
/* 186 */       if (this.h >= 0.0F) {
/* 187 */         this.h += f2 - Float.MAX_VALUE;
/* 188 */         if (this.h < 0.0F) this.h = Float.MAX_VALUE; 
/*     */       } 
/* 190 */       f2 = Float.MAX_VALUE;
/*     */     } 
/*     */     
/* 193 */     this.y = f2;
/*     */   }
/*     */   
/*     */   public WCRectangle createUnion(WCRectangle paramWCRectangle) {
/* 197 */     WCRectangle wCRectangle = new WCRectangle();
/* 198 */     union(this, paramWCRectangle, wCRectangle);
/* 199 */     return wCRectangle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void union(WCRectangle paramWCRectangle1, WCRectangle paramWCRectangle2, WCRectangle paramWCRectangle3) {
/* 206 */     float f1 = Math.min(paramWCRectangle1.getMinX(), paramWCRectangle2.getMinX());
/* 207 */     float f2 = Math.min(paramWCRectangle1.getMinY(), paramWCRectangle2.getMinY());
/* 208 */     float f3 = Math.max(paramWCRectangle1.getMaxX(), paramWCRectangle2.getMaxX());
/* 209 */     float f4 = Math.max(paramWCRectangle1.getMaxY(), paramWCRectangle2.getMaxY());
/* 210 */     paramWCRectangle3.setFrameFromDiagonal(f1, f2, f3, f4);
/*     */   }
/*     */   
/*     */   public void setFrameFromDiagonal(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 214 */     if (paramFloat3 < paramFloat1) {
/* 215 */       float f = paramFloat1;
/* 216 */       paramFloat1 = paramFloat3;
/* 217 */       paramFloat3 = f;
/*     */     } 
/* 219 */     if (paramFloat4 < paramFloat2) {
/* 220 */       float f = paramFloat2;
/* 221 */       paramFloat2 = paramFloat4;
/* 222 */       paramFloat4 = f;
/*     */     } 
/* 224 */     setFrame(paramFloat1, paramFloat2, paramFloat3 - paramFloat1, paramFloat4 - paramFloat2);
/*     */   }
/*     */   
/*     */   public void setFrame(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 228 */     this.x = paramFloat1;
/* 229 */     this.y = paramFloat2;
/* 230 */     this.w = paramFloat3;
/* 231 */     this.h = paramFloat4;
/*     */   }
/*     */   
/*     */   public float getMinX() {
/* 235 */     return getX();
/*     */   }
/*     */   
/*     */   public float getMaxX() {
/* 239 */     return getX() + getWidth();
/*     */   }
/*     */   
/*     */   public float getMinY() {
/* 243 */     return getY();
/*     */   }
/*     */   
/*     */   public float getMaxY() {
/* 247 */     return getY() + getHeight();
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 251 */     return (this.w <= 0.0F || this.h <= 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 256 */     if (paramObject instanceof WCRectangle) {
/* 257 */       WCRectangle wCRectangle = (WCRectangle)paramObject;
/* 258 */       return (this.x == wCRectangle.x && this.y == wCRectangle.y && this.w == wCRectangle.w && this.h == wCRectangle.h);
/*     */     } 
/* 260 */     return super.equals(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 265 */     return "WCRectangle{x:" + this.x + " y:" + this.y + " w:" + this.w + " h:" + this.h + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\graphics\WCRectangle.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */