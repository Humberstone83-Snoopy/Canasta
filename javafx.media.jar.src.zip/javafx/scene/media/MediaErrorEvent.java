/*    */ package javafx.scene.media;
/*    */ 
/*    */ import javafx.event.Event;
/*    */ import javafx.event.EventTarget;
/*    */ import javafx.event.EventType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MediaErrorEvent
/*    */   extends Event
/*    */ {
/*    */   private static final long serialVersionUID = 20121107L;
/* 43 */   public static final EventType<MediaErrorEvent> MEDIA_ERROR = (EventType)new EventType<>(Event.ANY, "Media Error Event");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private MediaException error;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MediaErrorEvent(Object paramObject, EventTarget paramEventTarget, MediaException paramMediaException) {
/* 62 */     super(paramObject, paramEventTarget, (EventType)MEDIA_ERROR);
/*    */     
/* 64 */     if (paramMediaException == null) {
/* 65 */       throw new IllegalArgumentException("error == null!");
/*    */     }
/*    */     
/* 68 */     this.error = paramMediaException;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaException getMediaError() {
/* 77 */     return this.error;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     return super.toString() + ": source " + super.toString() + "; target " + getSource() + "; error " + 
/* 86 */       getTarget();
/*    */   }
/*    */ 
/*    */   
/*    */   public MediaErrorEvent copyFor(Object paramObject, EventTarget paramEventTarget) {
/* 91 */     return (MediaErrorEvent)super.copyFor(paramObject, paramEventTarget);
/*    */   }
/*    */ 
/*    */   
/*    */   public EventType<MediaErrorEvent> getEventType() {
/* 96 */     return (EventType)super.getEventType();
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\MediaErrorEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */