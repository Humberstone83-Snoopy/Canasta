package com.sun.javafx.iio;

public interface ImageLoadListener {
  void imageLoadProgress(ImageLoader paramImageLoader, float paramFloat);
  
  void imageLoadWarning(ImageLoader paramImageLoader, String paramString);
  
  void imageLoadMetaData(ImageLoader paramImageLoader, ImageMetadata paramImageMetadata);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\ImageLoadListener.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */