/*      */ package com.sun.javafx.sg.prism;
/*      */ 
/*      */ import com.sun.javafx.font.PGFont;
/*      */ import com.sun.javafx.geom.Arc2D;
/*      */ import com.sun.javafx.geom.BaseBounds;
/*      */ import com.sun.javafx.geom.DirtyRegionContainer;
/*      */ import com.sun.javafx.geom.DirtyRegionPool;
/*      */ import com.sun.javafx.geom.Path2D;
/*      */ import com.sun.javafx.geom.PathIterator;
/*      */ import com.sun.javafx.geom.RectBounds;
/*      */ import com.sun.javafx.geom.Rectangle;
/*      */ import com.sun.javafx.geom.RoundRectangle2D;
/*      */ import com.sun.javafx.geom.Shape;
/*      */ import com.sun.javafx.geom.transform.Affine2D;
/*      */ import com.sun.javafx.geom.transform.BaseTransform;
/*      */ import com.sun.javafx.geom.transform.NoninvertibleTransformException;
/*      */ import com.sun.javafx.scene.text.FontHelper;
/*      */ import com.sun.javafx.text.PrismTextLayout;
/*      */ import com.sun.javafx.tk.RenderJob;
/*      */ import com.sun.javafx.tk.ScreenConfigurationAccessor;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.prism.BasicStroke;
/*      */ import com.sun.prism.CompositeMode;
/*      */ import com.sun.prism.Graphics;
/*      */ import com.sun.prism.GraphicsPipeline;
/*      */ import com.sun.prism.Image;
/*      */ import com.sun.prism.MaskTextureGraphics;
/*      */ import com.sun.prism.RTTexture;
/*      */ import com.sun.prism.ResourceFactory;
/*      */ import com.sun.prism.Texture;
/*      */ import com.sun.prism.paint.Color;
/*      */ import com.sun.prism.paint.Paint;
/*      */ import com.sun.scenario.effect.Blend;
/*      */ import com.sun.scenario.effect.Effect;
/*      */ import com.sun.scenario.effect.FilterContext;
/*      */ import com.sun.scenario.effect.Filterable;
/*      */ import com.sun.scenario.effect.ImageData;
/*      */ import com.sun.scenario.effect.impl.prism.PrDrawable;
/*      */ import com.sun.scenario.effect.impl.prism.PrFilterContext;
/*      */ import com.sun.scenario.effect.impl.prism.PrTexture;
/*      */ import java.nio.IntBuffer;
/*      */ import java.util.LinkedList;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.FutureTask;
/*      */ import javafx.geometry.VPos;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.scene.text.FontSmoothingType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NGCanvas
/*      */   extends NGNode
/*      */ {
/*      */   public static final byte ATTR_BASE = 0;
/*      */   public static final byte GLOBAL_ALPHA = 0;
/*      */   public static final byte COMP_MODE = 1;
/*      */   public static final byte FILL_PAINT = 2;
/*      */   public static final byte STROKE_PAINT = 3;
/*      */   public static final byte LINE_WIDTH = 4;
/*      */   public static final byte LINE_CAP = 5;
/*      */   public static final byte LINE_JOIN = 6;
/*      */   public static final byte MITER_LIMIT = 7;
/*      */   public static final byte FONT = 8;
/*      */   public static final byte TEXT_ALIGN = 9;
/*      */   public static final byte TEXT_BASELINE = 10;
/*      */   public static final byte TRANSFORM = 11;
/*      */   public static final byte EFFECT = 12;
/*      */   public static final byte PUSH_CLIP = 13;
/*      */   public static final byte POP_CLIP = 14;
/*      */   public static final byte ARC_TYPE = 15;
/*      */   public static final byte FILL_RULE = 16;
/*      */   public static final byte DASH_ARRAY = 17;
/*      */   public static final byte DASH_OFFSET = 18;
/*      */   public static final byte FONT_SMOOTH = 19;
/*      */   public static final byte OP_BASE = 20;
/*      */   public static final byte FILL_RECT = 20;
/*      */   public static final byte STROKE_RECT = 21;
/*      */   public static final byte CLEAR_RECT = 22;
/*      */   public static final byte STROKE_LINE = 23;
/*      */   public static final byte FILL_OVAL = 24;
/*      */   public static final byte STROKE_OVAL = 25;
/*      */   public static final byte FILL_ROUND_RECT = 26;
/*      */   public static final byte STROKE_ROUND_RECT = 27;
/*      */   public static final byte FILL_ARC = 28;
/*      */   public static final byte STROKE_ARC = 29;
/*      */   public static final byte FILL_TEXT = 30;
/*      */   public static final byte STROKE_TEXT = 31;
/*      */   public static final byte PATH_BASE = 40;
/*      */   public static final byte PATHSTART = 40;
/*      */   public static final byte MOVETO = 41;
/*      */   public static final byte LINETO = 42;
/*      */   public static final byte QUADTO = 43;
/*      */   public static final byte CUBICTO = 44;
/*      */   public static final byte CLOSEPATH = 45;
/*      */   public static final byte PATHEND = 46;
/*      */   public static final byte FILL_PATH = 47;
/*      */   public static final byte STROKE_PATH = 48;
/*      */   public static final byte IMG_BASE = 50;
/*      */   public static final byte DRAW_IMAGE = 50;
/*      */   public static final byte DRAW_SUBIMAGE = 51;
/*      */   public static final byte PUT_ARGB = 52;
/*      */   public static final byte PUT_ARGBPRE_BUF = 53;
/*      */   public static final byte FX_BASE = 60;
/*      */   public static final byte FX_APPLY_EFFECT = 60;
/*      */   public static final byte UTIL_BASE = 70;
/*      */   public static final byte RESET = 70;
/*      */   public static final byte SET_DIMS = 71;
/*      */   public static final byte CAP_BUTT = 0;
/*      */   public static final byte CAP_ROUND = 1;
/*      */   public static final byte CAP_SQUARE = 2;
/*      */   public static final byte JOIN_MITER = 0;
/*      */   public static final byte JOIN_ROUND = 1;
/*      */   public static final byte JOIN_BEVEL = 2;
/*      */   public static final byte ARC_OPEN = 0;
/*      */   public static final byte ARC_CHORD = 1;
/*      */   public static final byte ARC_PIE = 2;
/*  152 */   public static final byte SMOOTH_GRAY = (byte)FontSmoothingType.GRAY.ordinal();
/*  153 */   public static final byte SMOOTH_LCD = (byte)FontSmoothingType.LCD.ordinal();
/*      */   
/*      */   public static final byte ALIGN_LEFT = 0;
/*      */   
/*      */   public static final byte ALIGN_CENTER = 1;
/*      */   public static final byte ALIGN_RIGHT = 2;
/*      */   public static final byte ALIGN_JUSTIFY = 3;
/*      */   public static final byte BASE_TOP = 0;
/*      */   public static final byte BASE_MIDDLE = 1;
/*      */   public static final byte BASE_ALPHABETIC = 2;
/*      */   public static final byte BASE_BOTTOM = 3;
/*      */   public static final byte FILL_RULE_NON_ZERO = 0;
/*      */   public static final byte FILL_RULE_EVEN_ODD = 1;
/*      */   
/*      */   enum InitType
/*      */   {
/*  169 */     CLEAR,
/*  170 */     FILL_WHITE,
/*  171 */     PRESERVE_UPPER_LEFT;
/*      */   }
/*      */   
/*      */   static class RenderBuf {
/*      */     final NGCanvas.InitType init_type;
/*      */     RTTexture tex;
/*      */     Graphics g;
/*      */     NGCanvas.EffectInput input;
/*  179 */     private NGCanvas.PixelData savedPixelData = null;
/*      */     
/*      */     public RenderBuf(NGCanvas.InitType param1InitType) {
/*  182 */       this.init_type = param1InitType;
/*      */     }
/*      */     
/*      */     public void dispose() {
/*  186 */       if (this.tex != null) this.tex.dispose();
/*      */       
/*  188 */       this.tex = null;
/*  189 */       this.g = null;
/*  190 */       this.input = null;
/*      */     }
/*      */     public boolean validate(Graphics param1Graphics, int param1Int1, int param1Int2) {
/*      */       int i;
/*      */       int j;
/*      */       boolean bool;
/*  196 */       if (this.tex == null) {
/*  197 */         i = j = 0;
/*  198 */         bool = true;
/*      */       } else {
/*  200 */         i = this.tex.getContentWidth();
/*  201 */         j = this.tex.getContentHeight();
/*  202 */         this.tex.lock();
/*  203 */         bool = (this.tex.isSurfaceLost() || i < param1Int1 || j < param1Int2) ? true : false;
/*      */       } 
/*  205 */       if (bool) {
/*  206 */         RTTexture rTTexture1 = this.tex;
/*      */ 
/*      */         
/*  209 */         ResourceFactory resourceFactory = (param1Graphics == null) ? GraphicsPipeline.getDefaultResourceFactory() : param1Graphics.getResourceFactory();
/*      */         
/*  211 */         RTTexture rTTexture2 = resourceFactory.createRTTexture(param1Int1, param1Int2, Texture.WrapMode.CLAMP_TO_ZERO);
/*  212 */         this.tex = rTTexture2;
/*  213 */         this.g = rTTexture2.createGraphics();
/*  214 */         this.input = new NGCanvas.EffectInput(rTTexture2);
/*  215 */         if (rTTexture1 != null) {
/*  216 */           if (this.init_type == NGCanvas.InitType.PRESERVE_UPPER_LEFT) {
/*  217 */             this.g.setCompositeMode(CompositeMode.SRC);
/*  218 */             if (rTTexture1.isSurfaceLost()) {
/*  219 */               if (this.savedPixelData != null) {
/*  220 */                 this.savedPixelData.restore(this.g, i, j);
/*      */               }
/*      */             } else {
/*  223 */               this.g.drawTexture(rTTexture1, 0.0F, 0.0F, i, j);
/*      */             } 
/*  225 */             this.g.setCompositeMode(CompositeMode.SRC_OVER);
/*      */           } 
/*  227 */           rTTexture1.unlock();
/*  228 */           rTTexture1.dispose();
/*      */         } 
/*  230 */         if (this.init_type == NGCanvas.InitType.FILL_WHITE) {
/*  231 */           this.g.clear(Color.WHITE);
/*      */         }
/*  233 */         return true;
/*      */       } 
/*  235 */       if (this.g == null) {
/*  236 */         this.g = this.tex.createGraphics();
/*  237 */         if (this.g == null) {
/*  238 */           this.tex.dispose();
/*      */ 
/*      */           
/*  241 */           ResourceFactory resourceFactory = (param1Graphics == null) ? GraphicsPipeline.getDefaultResourceFactory() : param1Graphics.getResourceFactory();
/*  242 */           this.tex = resourceFactory.createRTTexture(param1Int1, param1Int2, Texture.WrapMode.CLAMP_TO_ZERO);
/*  243 */           this.g = this.tex.createGraphics();
/*  244 */           this.input = new NGCanvas.EffectInput(this.tex);
/*  245 */           if (this.savedPixelData != null) {
/*  246 */             this.g.setCompositeMode(CompositeMode.SRC);
/*  247 */             this.savedPixelData.restore(this.g, param1Int1, param1Int2);
/*  248 */             this.g.setCompositeMode(CompositeMode.SRC_OVER);
/*  249 */           } else if (this.init_type == NGCanvas.InitType.FILL_WHITE) {
/*  250 */             this.g.clear(Color.WHITE);
/*      */           } 
/*  252 */           return true;
/*      */         } 
/*      */       } 
/*      */       
/*  256 */       if (this.init_type == NGCanvas.InitType.CLEAR) {
/*  257 */         this.g.clear();
/*      */       }
/*  259 */       return false;
/*      */     }
/*      */     
/*      */     private void save(int param1Int1, int param1Int2) {
/*  263 */       if (this.tex.isVolatile()) {
/*  264 */         if (this.savedPixelData == null) {
/*  265 */           this.savedPixelData = new NGCanvas.PixelData(param1Int1, param1Int2);
/*      */         }
/*  267 */         this.savedPixelData.save(this.tex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class PixelData
/*      */   {
/*  275 */     private IntBuffer pixels = null; private boolean validPixels = false;
/*      */     private int cw;
/*      */     private int ch;
/*      */     
/*      */     private PixelData(int param1Int1, int param1Int2) {
/*  280 */       this.cw = param1Int1;
/*  281 */       this.ch = param1Int2;
/*  282 */       this.pixels = IntBuffer.allocate(param1Int1 * param1Int2);
/*      */     }
/*      */     
/*      */     private void save(RTTexture param1RTTexture) {
/*  286 */       int i = param1RTTexture.getContentWidth();
/*  287 */       int j = param1RTTexture.getContentHeight();
/*  288 */       if (this.cw < i || this.ch < j) {
/*  289 */         this.cw = i;
/*  290 */         this.ch = j;
/*  291 */         this.pixels = IntBuffer.allocate(this.cw * this.ch);
/*      */       } 
/*  293 */       this.pixels.rewind();
/*  294 */       param1RTTexture.readPixels(this.pixels);
/*  295 */       this.validPixels = true;
/*      */     }
/*      */     
/*      */     private void restore(Graphics param1Graphics, int param1Int1, int param1Int2) {
/*  299 */       if (this.validPixels) {
/*  300 */         Image image = Image.fromIntArgbPreData(this.pixels, param1Int1, param1Int2);
/*  301 */         ResourceFactory resourceFactory = param1Graphics.getResourceFactory();
/*      */         
/*  303 */         Texture texture = resourceFactory.createTexture(image, Texture.Usage.DEFAULT, Texture.WrapMode.CLAMP_TO_EDGE);
/*      */ 
/*      */         
/*  306 */         param1Graphics.drawTexture(texture, 0.0F, 0.0F, param1Int1, param1Int2);
/*  307 */         texture.dispose();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*  312 */   private static Blend BLENDER = new MyBlend(Blend.Mode.SRC_OVER, null, null);
/*      */   private GrowableDataBuffer thebuf;
/*      */   private final float highestPixelScale;
/*      */   private int tw;
/*      */   private int th;
/*      */   private int cw;
/*      */   private int ch;
/*      */   private RenderBuf cv;
/*      */   private RenderBuf temp;
/*      */   private RenderBuf clip;
/*      */   private float globalAlpha;
/*      */   private Blend.Mode blendmode;
/*      */   private Paint fillPaint;
/*      */   private Paint strokePaint;
/*      */   private float linewidth;
/*      */   private int linecap;
/*      */   private int linejoin;
/*      */   private float miterlimit;
/*      */   private double[] dashes;
/*      */   private float dashOffset;
/*      */   private BasicStroke stroke;
/*      */   private Path2D path;
/*      */   private NGText ngtext;
/*      */   private PrismTextLayout textLayout;
/*      */   private PGFont pgfont;
/*      */   private int smoothing;
/*      */   private int align;
/*      */   private int baseline;
/*      */   private Affine2D transform;
/*      */   private Affine2D inverseTransform;
/*      */   private boolean inversedirty;
/*      */   private LinkedList<Path2D> clipStack;
/*      */   private int clipsRendered;
/*      */   private boolean clipIsRect;
/*      */   private Rectangle clipRect;
/*      */   private Effect effect;
/*      */   private int arctype;
/*  349 */   static float[] TEMP_COORDS = new float[6];
/*  350 */   private static Arc2D TEMP_ARC = new Arc2D();
/*  351 */   private static RectBounds TEMP_RECTBOUNDS = new RectBounds();
/*      */   
/*      */   public NGCanvas() {
/*  354 */     Toolkit toolkit = Toolkit.getToolkit();
/*  355 */     ScreenConfigurationAccessor screenConfigurationAccessor = toolkit.getScreenConfigurationAccessor();
/*  356 */     float f = 1.0F;
/*  357 */     for (Object object : toolkit.getScreens()) {
/*  358 */       f = Math.max(screenConfigurationAccessor.getRecommendedOutputScaleX(object), f);
/*  359 */       f = Math.max(screenConfigurationAccessor.getRecommendedOutputScaleY(object), f);
/*      */     } 
/*  361 */     this.highestPixelScale = (float)Math.ceil(f);
/*      */     
/*  363 */     this.cv = new RenderBuf(InitType.PRESERVE_UPPER_LEFT);
/*  364 */     this.temp = new RenderBuf(InitType.CLEAR);
/*  365 */     this.clip = new RenderBuf(InitType.FILL_WHITE);
/*      */     
/*  367 */     this.path = new Path2D();
/*  368 */     this.ngtext = new NGText();
/*  369 */     this.textLayout = new PrismTextLayout();
/*  370 */     this.transform = new Affine2D();
/*  371 */     this.clipStack = new LinkedList<>();
/*  372 */     initAttributes();
/*      */   }
/*      */   
/*      */   private void initAttributes() {
/*  376 */     this.globalAlpha = 1.0F;
/*  377 */     this.blendmode = Blend.Mode.SRC_OVER;
/*  378 */     this.fillPaint = Color.BLACK;
/*  379 */     this.strokePaint = Color.BLACK;
/*  380 */     this.linewidth = 1.0F;
/*  381 */     this.linecap = 2;
/*  382 */     this.linejoin = 0;
/*  383 */     this.miterlimit = 10.0F;
/*  384 */     this.dashes = null;
/*  385 */     this.dashOffset = 0.0F;
/*  386 */     this.stroke = null;
/*  387 */     this.path.setWindingRule(1);
/*      */ 
/*      */     
/*  390 */     this.pgfont = (PGFont)FontHelper.getNativeFont(Font.getDefault());
/*  391 */     this.smoothing = SMOOTH_GRAY;
/*  392 */     this.align = 0;
/*  393 */     this.baseline = VPos.BASELINE.ordinal();
/*  394 */     this.transform.setToScale(this.highestPixelScale, this.highestPixelScale);
/*  395 */     this.clipStack.clear();
/*  396 */     resetClip(false);
/*      */   }
/*      */   
/*  399 */   static final Affine2D TEMP_PATH_TX = new Affine2D();
/*  400 */   static final int[] numCoords = new int[] { 2, 2, 4, 6, 0 };
/*  401 */   Shape untransformedPath = new Shape()
/*      */     {
/*      */       public RectBounds getBounds()
/*      */       {
/*  405 */         if (NGCanvas.this.transform.isTranslateOrIdentity()) {
/*  406 */           RectBounds rectBounds = NGCanvas.this.path.getBounds();
/*  407 */           if (NGCanvas.this.transform.isIdentity()) {
/*  408 */             return rectBounds;
/*      */           }
/*  410 */           float f5 = (float)NGCanvas.this.transform.getMxt();
/*  411 */           float f6 = (float)NGCanvas.this.transform.getMyt();
/*  412 */           return new RectBounds(rectBounds.getMinX() - f5, rectBounds.getMinY() - f6, rectBounds
/*  413 */               .getMaxX() - f5, rectBounds.getMaxY() - f6);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  422 */         float f1 = Float.POSITIVE_INFINITY;
/*  423 */         float f2 = Float.POSITIVE_INFINITY;
/*  424 */         float f3 = Float.NEGATIVE_INFINITY;
/*  425 */         float f4 = Float.NEGATIVE_INFINITY;
/*  426 */         PathIterator pathIterator = NGCanvas.this.path.getPathIterator(NGCanvas.this.getInverseTransform());
/*  427 */         while (!pathIterator.isDone()) {
/*  428 */           int i = NGCanvas.numCoords[pathIterator.currentSegment(NGCanvas.TEMP_COORDS)];
/*  429 */           for (byte b = 0; b < i; b += 2) {
/*  430 */             if (f1 > NGCanvas.TEMP_COORDS[b + 0]) f1 = NGCanvas.TEMP_COORDS[b + 0]; 
/*  431 */             if (f3 < NGCanvas.TEMP_COORDS[b + 0]) f3 = NGCanvas.TEMP_COORDS[b + 0]; 
/*  432 */             if (f2 > NGCanvas.TEMP_COORDS[b + 1]) f2 = NGCanvas.TEMP_COORDS[b + 1]; 
/*  433 */             if (f4 < NGCanvas.TEMP_COORDS[b + 1]) f4 = NGCanvas.TEMP_COORDS[b + 1]; 
/*      */           } 
/*  435 */           pathIterator.next();
/*      */         } 
/*  437 */         return new RectBounds(f1, f2, f3, f4);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(float param1Float1, float param1Float2) {
/*  442 */         NGCanvas.TEMP_COORDS[0] = param1Float1;
/*  443 */         NGCanvas.TEMP_COORDS[1] = param1Float2;
/*  444 */         NGCanvas.this.transform.transform(NGCanvas.TEMP_COORDS, 0, NGCanvas.TEMP_COORDS, 0, 1);
/*  445 */         param1Float1 = NGCanvas.TEMP_COORDS[0];
/*  446 */         param1Float2 = NGCanvas.TEMP_COORDS[1];
/*  447 */         return NGCanvas.this.path.contains(param1Float1, param1Float2);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean intersects(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/*  452 */         if (NGCanvas.this.transform.isTranslateOrIdentity()) {
/*  453 */           param1Float1 = (float)(param1Float1 + NGCanvas.this.transform.getMxt());
/*  454 */           param1Float2 = (float)(param1Float2 + NGCanvas.this.transform.getMyt());
/*  455 */           return NGCanvas.this.path.intersects(param1Float1, param1Float2, param1Float3, param1Float4);
/*      */         } 
/*  457 */         PathIterator pathIterator = NGCanvas.this.path.getPathIterator(NGCanvas.this.getInverseTransform());
/*  458 */         int i = Shape.rectCrossingsForPath(pathIterator, param1Float1, param1Float2, param1Float1 + param1Float3, param1Float2 + param1Float4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  464 */         return (i != 0);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/*  469 */         if (NGCanvas.this.transform.isTranslateOrIdentity()) {
/*  470 */           param1Float1 = (float)(param1Float1 + NGCanvas.this.transform.getMxt());
/*  471 */           param1Float2 = (float)(param1Float2 + NGCanvas.this.transform.getMyt());
/*  472 */           return NGCanvas.this.path.contains(param1Float1, param1Float2, param1Float3, param1Float4);
/*      */         } 
/*  474 */         PathIterator pathIterator = NGCanvas.this.path.getPathIterator(NGCanvas.this.getInverseTransform());
/*  475 */         int i = Shape.rectCrossingsForPath(pathIterator, param1Float1, param1Float2, param1Float1 + param1Float3, param1Float2 + param1Float4);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  480 */         return (i != Integer.MIN_VALUE && i != 0);
/*      */       }
/*      */       
/*      */       public BaseTransform getCombinedTransform(BaseTransform param1BaseTransform) {
/*  484 */         if (NGCanvas.this.transform.isIdentity()) return param1BaseTransform; 
/*  485 */         if (NGCanvas.this.transform.equals(param1BaseTransform)) return null; 
/*  486 */         Affine2D affine2D = NGCanvas.this.getInverseTransform();
/*  487 */         if (param1BaseTransform == null || param1BaseTransform.isIdentity()) return affine2D; 
/*  488 */         NGCanvas.TEMP_PATH_TX.setTransform(param1BaseTransform);
/*  489 */         NGCanvas.TEMP_PATH_TX.concatenate(affine2D);
/*  490 */         return NGCanvas.TEMP_PATH_TX;
/*      */       }
/*      */ 
/*      */       
/*      */       public PathIterator getPathIterator(BaseTransform param1BaseTransform) {
/*  495 */         return NGCanvas.this.path.getPathIterator(getCombinedTransform(param1BaseTransform));
/*      */       }
/*      */ 
/*      */       
/*      */       public PathIterator getPathIterator(BaseTransform param1BaseTransform, float param1Float) {
/*  500 */         return NGCanvas.this.path.getPathIterator(getCombinedTransform(param1BaseTransform), param1Float);
/*      */       }
/*      */ 
/*      */       
/*      */       public Shape copy() {
/*  505 */         throw new UnsupportedOperationException("Not supported yet.");
/*      */       }
/*      */     };
/*      */   private static final float CLIPRECT_TOLERANCE = 0.00390625F;
/*      */   private Affine2D getInverseTransform() {
/*  510 */     if (this.inverseTransform == null) {
/*  511 */       this.inverseTransform = new Affine2D();
/*  512 */       this.inversedirty = true;
/*      */     } 
/*  514 */     if (this.inversedirty) {
/*  515 */       this.inverseTransform.setTransform(this.transform);
/*      */       try {
/*  517 */         this.inverseTransform.invert();
/*  518 */       } catch (NoninvertibleTransformException noninvertibleTransformException) {
/*  519 */         this.inverseTransform.setToScale(0.0D, 0.0D);
/*      */       } 
/*  521 */       this.inversedirty = false;
/*      */     } 
/*  523 */     return this.inverseTransform;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean hasOverlappingContents() {
/*  528 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void shapebounds(Shape paramShape, RectBounds paramRectBounds, BaseTransform paramBaseTransform) {
/*  534 */     TEMP_COORDS[1] = Float.POSITIVE_INFINITY; TEMP_COORDS[0] = Float.POSITIVE_INFINITY;
/*  535 */     TEMP_COORDS[3] = Float.NEGATIVE_INFINITY; TEMP_COORDS[2] = Float.NEGATIVE_INFINITY;
/*  536 */     Shape.accumulate(TEMP_COORDS, paramShape, paramBaseTransform);
/*  537 */     paramRectBounds.setBounds(TEMP_COORDS[0], TEMP_COORDS[1], TEMP_COORDS[2], TEMP_COORDS[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void strokebounds(BasicStroke paramBasicStroke, Shape paramShape, RectBounds paramRectBounds, BaseTransform paramBaseTransform) {
/*  544 */     TEMP_COORDS[1] = Float.POSITIVE_INFINITY; TEMP_COORDS[0] = Float.POSITIVE_INFINITY;
/*  545 */     TEMP_COORDS[3] = Float.NEGATIVE_INFINITY; TEMP_COORDS[2] = Float.NEGATIVE_INFINITY;
/*  546 */     paramBasicStroke.accumulateShapeBounds(TEMP_COORDS, paramShape, paramBaseTransform);
/*  547 */     paramRectBounds.setBounds(TEMP_COORDS[0], TEMP_COORDS[1], TEMP_COORDS[2], TEMP_COORDS[3]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void runOnRenderThread(Runnable paramRunnable) {
/*  553 */     if (Thread.currentThread().getName().startsWith("QuantumRenderer")) {
/*  554 */       paramRunnable.run();
/*      */     } else {
/*  556 */       FutureTask futureTask = new FutureTask(paramRunnable, null);
/*  557 */       Toolkit.getToolkit().addRenderJob(new RenderJob(futureTask));
/*      */       
/*      */       try {
/*  560 */         futureTask.get();
/*  561 */       } catch (ExecutionException executionException) {
/*  562 */         throw new AssertionError(executionException);
/*  563 */       } catch (InterruptedException interruptedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean printedCanvas(Graphics paramGraphics) {
/*  570 */     RTTexture rTTexture1 = this.cv.tex;
/*  571 */     if (!(paramGraphics instanceof com.sun.prism.PrinterGraphics) || rTTexture1 == null) {
/*  572 */       return false;
/*      */     }
/*  574 */     ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/*  575 */     boolean bool = resourceFactory.isCompatibleTexture(rTTexture1);
/*  576 */     if (bool) {
/*  577 */       return false;
/*      */     }
/*      */     
/*  580 */     int i = rTTexture1.getContentWidth();
/*  581 */     int j = rTTexture1.getContentHeight();
/*      */     
/*  583 */     RTTexture rTTexture2 = resourceFactory.createRTTexture(i, j, Texture.WrapMode.CLAMP_TO_ZERO);
/*  584 */     Graphics graphics = rTTexture2.createGraphics();
/*  585 */     graphics.setCompositeMode(CompositeMode.SRC);
/*  586 */     if (this.cv.savedPixelData == null) {
/*  587 */       PixelData pixelData = new PixelData(this.cw, this.ch);
/*  588 */       runOnRenderThread(() -> {
/*      */             paramPixelData.save(paramRTTexture);
/*      */             paramPixelData.restore(paramGraphics, paramInt1, paramInt2);
/*      */           });
/*      */     } else {
/*  593 */       this.cv.savedPixelData.restore(graphics, i, j);
/*      */     } 
/*  595 */     paramGraphics.drawTexture(rTTexture2, 0.0F, 0.0F, i, j);
/*  596 */     rTTexture2.unlock();
/*  597 */     rTTexture2.dispose();
/*  598 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void renderContent(Graphics paramGraphics) {
/*  603 */     if (printedCanvas(paramGraphics))
/*  604 */       return;  initCanvas(paramGraphics);
/*  605 */     if (this.cv.tex != null) {
/*  606 */       if (this.thebuf != null) {
/*  607 */         renderStream(this.thebuf);
/*  608 */         GrowableDataBuffer.returnBuffer(this.thebuf);
/*  609 */         this.thebuf = null;
/*      */       } 
/*  611 */       float f1 = this.tw / this.highestPixelScale;
/*  612 */       float f2 = this.th / this.highestPixelScale;
/*  613 */       paramGraphics.drawTexture(this.cv.tex, 0.0F, 0.0F, f1, f2, 0.0F, 0.0F, this.tw, this.th);
/*      */ 
/*      */ 
/*      */       
/*  617 */       this.cv.save(this.tw, this.th);
/*      */     } 
/*  619 */     this.cv.g = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void renderForcedContent(Graphics paramGraphics) {
/*  624 */     if (this.thebuf != null) {
/*  625 */       initCanvas(paramGraphics);
/*  626 */       if (this.cv.tex != null) {
/*  627 */         renderStream(this.thebuf);
/*  628 */         GrowableDataBuffer.returnBuffer(this.thebuf);
/*  629 */         this.thebuf = null;
/*  630 */         this.cv.save(this.tw, this.th);
/*      */       } 
/*  632 */       this.cv.g = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initCanvas(Graphics paramGraphics) {
/*  637 */     if (this.tw <= 0 || this.th <= 0) {
/*  638 */       this.cv.dispose();
/*      */       return;
/*      */     } 
/*  641 */     if (this.cv.validate(paramGraphics, this.tw, this.th)) {
/*      */ 
/*      */       
/*  644 */       this.cv.tex.contentsUseful();
/*  645 */       this.cv.tex.makePermanent();
/*  646 */       this.cv.tex.lock();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void clearCanvas(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  651 */     this.cv.g.setCompositeMode(CompositeMode.CLEAR);
/*  652 */     this.cv.g.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*  653 */     this.cv.g.fillQuad(paramInt1, paramInt2, (paramInt1 + paramInt3), (paramInt2 + paramInt4));
/*  654 */     this.cv.g.setCompositeMode(CompositeMode.SRC_OVER);
/*      */   }
/*      */   
/*      */   private void resetClip(boolean paramBoolean) {
/*  658 */     if (paramBoolean) this.clip.dispose(); 
/*  659 */     this.clipsRendered = 0;
/*  660 */     this.clipIsRect = true;
/*  661 */     this.clipRect = null;
/*      */   }
/*      */ 
/*      */   
/*  665 */   private static final Rectangle TEMP_RECT = new Rectangle();
/*      */   private boolean initClip() {
/*      */     boolean bool;
/*  668 */     if (this.clipIsRect) {
/*  669 */       bool = false;
/*      */     } else {
/*  671 */       bool = true;
/*  672 */       if (this.clip.validate(this.cv.g, this.tw, this.th)) {
/*  673 */         this.clip.tex.contentsUseful();
/*      */         
/*  675 */         resetClip(false);
/*      */       } 
/*      */     } 
/*  678 */     int i = this.clipStack.size();
/*  679 */     while (this.clipsRendered < i) {
/*  680 */       Path2D path2D = this.clipStack.get(this.clipsRendered++);
/*  681 */       if (this.clipIsRect) {
/*  682 */         if (path2D.checkAndGetIntRect(TEMP_RECT, 0.00390625F)) {
/*  683 */           if (this.clipRect == null) {
/*  684 */             this.clipRect = new Rectangle(TEMP_RECT); continue;
/*      */           } 
/*  686 */           this.clipRect.intersectWith(TEMP_RECT);
/*      */           
/*      */           continue;
/*      */         } 
/*  690 */         this.clipIsRect = false;
/*  691 */         if (!bool) {
/*  692 */           bool = true;
/*  693 */           if (this.clip.validate(this.cv.g, this.tw, this.th)) {
/*  694 */             this.clip.tex.contentsUseful();
/*      */           }
/*      */         } 
/*      */         
/*  698 */         if (this.clipRect != null) {
/*  699 */           renderClip(new RoundRectangle2D(this.clipRect.x, this.clipRect.y, this.clipRect.width, this.clipRect.height, 0.0F, 0.0F));
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  704 */       shapebounds(path2D, TEMP_RECTBOUNDS, BaseTransform.IDENTITY_TRANSFORM);
/*  705 */       TEMP_RECT.setBounds(TEMP_RECTBOUNDS);
/*  706 */       if (this.clipRect == null) {
/*  707 */         this.clipRect = new Rectangle(TEMP_RECT);
/*      */       } else {
/*  709 */         this.clipRect.intersectWith(TEMP_RECT);
/*      */       } 
/*  711 */       renderClip(path2D);
/*      */     } 
/*  713 */     if (bool && this.clipIsRect) {
/*  714 */       this.clip.tex.unlock();
/*      */     }
/*  716 */     return !this.clipIsRect;
/*      */   }
/*      */   
/*      */   private void renderClip(Shape paramShape) {
/*  720 */     this.temp.validate(this.cv.g, this.tw, this.th);
/*  721 */     this.temp.g.setPaint(Color.WHITE);
/*  722 */     this.temp.g.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*  723 */     this.temp.g.fill(paramShape);
/*  724 */     blendAthruBintoC(this.temp, Blend.Mode.SRC_IN, this.clip, null, CompositeMode.SRC, this.clip);
/*  725 */     this.temp.tex.unlock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle applyEffectOnAintoC(Effect paramEffect1, Effect paramEffect2, BaseTransform paramBaseTransform, Rectangle paramRectangle, CompositeMode paramCompositeMode, RenderBuf paramRenderBuf) {
/*  736 */     PrFilterContext prFilterContext = PrFilterContext.getInstance(paramRenderBuf.tex.getAssociatedScreen());
/*      */     
/*  738 */     ImageData imageData = paramEffect2.filter(prFilterContext, paramBaseTransform, paramRectangle, null, paramEffect1);
/*  739 */     Rectangle rectangle1 = imageData.getUntransformedBounds();
/*  740 */     Filterable filterable = imageData.getUntransformedImage();
/*  741 */     Texture texture = (Texture)((PrTexture<Object>)filterable).getTextureObject();
/*  742 */     paramRenderBuf.g.setTransform(imageData.getTransform());
/*  743 */     paramRenderBuf.g.setCompositeMode(paramCompositeMode);
/*  744 */     paramRenderBuf.g.drawTexture(texture, rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height);
/*  745 */     paramRenderBuf.g.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*  746 */     paramRenderBuf.g.setCompositeMode(CompositeMode.SRC_OVER);
/*  747 */     Rectangle rectangle2 = imageData.getTransformedBounds(paramRectangle);
/*  748 */     imageData.unref();
/*  749 */     return rectangle2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void blendAthruBintoC(RenderBuf paramRenderBuf1, Blend.Mode paramMode, RenderBuf paramRenderBuf2, RectBounds paramRectBounds, CompositeMode paramCompositeMode, RenderBuf paramRenderBuf3) {
/*      */     Rectangle rectangle;
/*  759 */     BLENDER.setTopInput(paramRenderBuf1.input);
/*  760 */     BLENDER.setBottomInput(paramRenderBuf2.input);
/*  761 */     BLENDER.setMode(paramMode);
/*      */     
/*  763 */     if (paramRectBounds != null) {
/*  764 */       rectangle = new Rectangle(paramRectBounds);
/*      */     } else {
/*  766 */       rectangle = null;
/*      */     } 
/*  768 */     applyEffectOnAintoC(null, BLENDER, BaseTransform.IDENTITY_TRANSFORM, rectangle, paramCompositeMode, paramRenderBuf3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setupFill(Graphics paramGraphics) {
/*  774 */     paramGraphics.setPaint(this.fillPaint);
/*      */   }
/*      */   
/*      */   private BasicStroke getStroke() {
/*  778 */     if (this.stroke == null) {
/*  779 */       this.stroke = new BasicStroke(this.linewidth, this.linecap, this.linejoin, this.miterlimit, this.dashes, this.dashOffset);
/*      */     }
/*      */     
/*  782 */     return this.stroke;
/*      */   }
/*      */   
/*      */   private void setupStroke(Graphics paramGraphics) {
/*  786 */     paramGraphics.setStroke(getStroke());
/*  787 */     paramGraphics.setPaint(this.strokePaint);
/*      */   }
/*      */   
/*  790 */   private static final int[] prcaps = new int[] { 0, 1, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  795 */   private static final int[] prjoins = new int[] { 0, 1, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  800 */   private static final int[] prbases = new int[] { VPos.TOP
/*  801 */       .ordinal(), VPos.CENTER
/*  802 */       .ordinal(), VPos.BASELINE
/*  803 */       .ordinal(), VPos.BOTTOM
/*  804 */       .ordinal() };
/*      */   
/*  806 */   private static final Affine2D TEMP_TX = new Affine2D();
/*      */   private void renderStream(GrowableDataBuffer paramGrowableDataBuffer) {
/*  808 */     while (paramGrowableDataBuffer.hasValues()) {
/*  809 */       int i, j, k, m; Path2D path2D; byte b2; float f1; double d1; Effect effect; RenderBuf renderBuf1; float f2; RenderBuf renderBuf2; boolean bool; int n; double d2; BaseTransform baseTransform; boolean bool1; Graphics graphics1; int i1; float f3; byte[] arrayOfByte; double d3; float f4; Image image; float f5; Graphics graphics2; double d4; float f6; ResourceFactory resourceFactory; Texture texture; double d5; float f7, f8; double d6; byte b1 = paramGrowableDataBuffer.getByte();
/*  810 */       switch (b1) {
/*      */         case 70:
/*  812 */           initAttributes();
/*      */ 
/*      */           
/*  815 */           this.cw = this.tw;
/*  816 */           this.ch = this.th;
/*  817 */           clearCanvas(0, 0, this.tw, this.th);
/*      */           continue;
/*      */         case 71:
/*  820 */           i = (int)Math.ceil((paramGrowableDataBuffer.getFloat() * this.highestPixelScale));
/*  821 */           j = (int)Math.ceil((paramGrowableDataBuffer.getFloat() * this.highestPixelScale));
/*  822 */           k = Math.min(i, this.cw);
/*  823 */           m = Math.min(j, this.ch);
/*  824 */           if (k < this.tw)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  829 */             clearCanvas(k, 0, this.tw - k, this.th);
/*      */           }
/*  831 */           if (m < this.th)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/*  836 */             clearCanvas(0, m, this.tw, this.th - m);
/*      */           }
/*  838 */           this.cw = i;
/*  839 */           this.ch = j;
/*      */           continue;
/*      */         case 40:
/*  842 */           this.path.reset();
/*      */           continue;
/*      */         case 41:
/*  845 */           this.path.moveTo(paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer.getFloat());
/*      */           continue;
/*      */         case 42:
/*  848 */           this.path.lineTo(paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer.getFloat());
/*      */           continue;
/*      */         case 43:
/*  851 */           this.path.quadTo(paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer
/*  852 */               .getFloat(), paramGrowableDataBuffer.getFloat());
/*      */           continue;
/*      */         case 44:
/*  855 */           this.path.curveTo(paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer
/*  856 */               .getFloat(), paramGrowableDataBuffer.getFloat(), paramGrowableDataBuffer
/*  857 */               .getFloat(), paramGrowableDataBuffer.getFloat());
/*      */           continue;
/*      */         case 45:
/*  860 */           this.path.closePath();
/*      */           continue;
/*      */         case 46:
/*  863 */           if (this.highestPixelScale != 1.0F) {
/*  864 */             TEMP_TX.setToScale(this.highestPixelScale, this.highestPixelScale);
/*  865 */             this.path.transform(TEMP_TX);
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 13:
/*  870 */           path2D = (Path2D)paramGrowableDataBuffer.getObject();
/*  871 */           if (this.highestPixelScale != 1.0F) {
/*  872 */             TEMP_TX.setToScale(this.highestPixelScale, this.highestPixelScale);
/*  873 */             path2D.transform(TEMP_TX);
/*      */           } 
/*  875 */           this.clipStack.addLast(path2D);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 14:
/*  880 */           resetClip(true);
/*  881 */           this.clipStack.removeLast();
/*      */           continue;
/*      */         
/*      */         case 15:
/*  885 */           b2 = paramGrowableDataBuffer.getByte();
/*  886 */           switch (b2) { case 0:
/*  887 */               this.arctype = 0; continue;
/*  888 */             case 1: this.arctype = 1; continue;
/*  889 */             case 2: this.arctype = 2;
/*      */               continue; }
/*      */ 
/*      */           
/*      */           continue;
/*      */         case 52:
/*  895 */           f1 = paramGrowableDataBuffer.getInt();
/*  896 */           f2 = paramGrowableDataBuffer.getInt();
/*  897 */           n = paramGrowableDataBuffer.getInt();
/*  898 */           graphics1 = this.cv.g;
/*  899 */           graphics1.setExtraAlpha(1.0F);
/*  900 */           graphics1.setCompositeMode(CompositeMode.SRC);
/*  901 */           graphics1.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*  902 */           f1 *= this.highestPixelScale;
/*  903 */           f2 *= this.highestPixelScale;
/*  904 */           f3 = (n >>> 24) / 255.0F;
/*  905 */           f4 = (n >> 16 & 0xFF) / 255.0F;
/*  906 */           f5 = (n >> 8 & 0xFF) / 255.0F;
/*  907 */           f6 = (n & 0xFF) / 255.0F;
/*  908 */           graphics1.setPaint(new Color(f4, f5, f6, f3));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  913 */           graphics1.fillQuad(f1, f2, f1 + this.highestPixelScale, f2 + this.highestPixelScale);
/*  914 */           graphics1.setCompositeMode(CompositeMode.SRC_OVER);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 53:
/*  919 */           f1 = paramGrowableDataBuffer.getInt();
/*  920 */           f2 = paramGrowableDataBuffer.getInt();
/*  921 */           n = paramGrowableDataBuffer.getInt();
/*  922 */           i1 = paramGrowableDataBuffer.getInt();
/*  923 */           arrayOfByte = (byte[])paramGrowableDataBuffer.getObject();
/*  924 */           image = Image.fromByteBgraPreData(arrayOfByte, n, i1);
/*  925 */           graphics2 = this.cv.g;
/*  926 */           resourceFactory = graphics2.getResourceFactory();
/*      */           
/*  928 */           texture = resourceFactory.getCachedTexture(image, Texture.WrapMode.CLAMP_TO_EDGE);
/*  929 */           graphics2.setTransform(BaseTransform.IDENTITY_TRANSFORM);
/*  930 */           graphics2.setCompositeMode(CompositeMode.SRC);
/*  931 */           f7 = f1 + n;
/*  932 */           f8 = f2 + i1;
/*  933 */           f1 *= this.highestPixelScale;
/*  934 */           f2 *= this.highestPixelScale;
/*  935 */           f7 *= this.highestPixelScale;
/*  936 */           f8 *= this.highestPixelScale;
/*  937 */           graphics2.drawTexture(texture, f1, f2, f7, f8, 0.0F, 0.0F, n, i1);
/*      */ 
/*      */           
/*  940 */           texture.contentsNotUseful();
/*  941 */           texture.unlock();
/*  942 */           graphics2.setCompositeMode(CompositeMode.SRC_OVER);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 11:
/*  947 */           d1 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  948 */           d2 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  949 */           d3 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  950 */           d4 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  951 */           d5 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  952 */           d6 = paramGrowableDataBuffer.getDouble() * this.highestPixelScale;
/*  953 */           this.transform.setTransform(d1, d4, d2, d5, d3, d6);
/*  954 */           this.inversedirty = true;
/*      */           continue;
/*      */         
/*      */         case 0:
/*  958 */           this.globalAlpha = paramGrowableDataBuffer.getFloat();
/*      */           continue;
/*      */         case 16:
/*  961 */           if (paramGrowableDataBuffer.getByte() == 0) {
/*  962 */             this.path.setWindingRule(1); continue;
/*      */           } 
/*  964 */           this.path.setWindingRule(0);
/*      */           continue;
/*      */         
/*      */         case 1:
/*  968 */           this.blendmode = (Blend.Mode)paramGrowableDataBuffer.getObject();
/*      */           continue;
/*      */         case 2:
/*  971 */           this.fillPaint = (Paint)paramGrowableDataBuffer.getObject();
/*      */           continue;
/*      */         case 3:
/*  974 */           this.strokePaint = (Paint)paramGrowableDataBuffer.getObject();
/*      */           continue;
/*      */         case 4:
/*  977 */           this.linewidth = paramGrowableDataBuffer.getFloat();
/*  978 */           this.stroke = null;
/*      */           continue;
/*      */         case 5:
/*  981 */           this.linecap = prcaps[paramGrowableDataBuffer.getUByte()];
/*  982 */           this.stroke = null;
/*      */           continue;
/*      */         case 6:
/*  985 */           this.linejoin = prjoins[paramGrowableDataBuffer.getUByte()];
/*  986 */           this.stroke = null;
/*      */           continue;
/*      */         case 7:
/*  989 */           this.miterlimit = paramGrowableDataBuffer.getFloat();
/*  990 */           this.stroke = null;
/*      */           continue;
/*      */         case 17:
/*  993 */           this.dashes = (double[])paramGrowableDataBuffer.getObject();
/*  994 */           this.stroke = null;
/*      */           continue;
/*      */         case 18:
/*  997 */           this.dashOffset = paramGrowableDataBuffer.getFloat();
/*  998 */           this.stroke = null;
/*      */           continue;
/*      */         case 8:
/* 1001 */           this.pgfont = (PGFont)paramGrowableDataBuffer.getObject();
/*      */           continue;
/*      */         case 19:
/* 1004 */           this.smoothing = paramGrowableDataBuffer.getUByte();
/*      */           continue;
/*      */         case 9:
/* 1007 */           this.align = paramGrowableDataBuffer.getUByte();
/*      */           continue;
/*      */         case 10:
/* 1010 */           this.baseline = prbases[paramGrowableDataBuffer.getUByte()];
/*      */           continue;
/*      */         
/*      */         case 60:
/* 1014 */           effect = (Effect)paramGrowableDataBuffer.getObject();
/* 1015 */           renderBuf2 = this.clipStack.isEmpty() ? this.cv : this.temp;
/*      */           
/* 1017 */           if (this.highestPixelScale != 1.0F) {
/* 1018 */             TEMP_TX.setToScale(this.highestPixelScale, this.highestPixelScale);
/* 1019 */             baseTransform = TEMP_TX;
/* 1020 */             this.cv.input.setPixelScale(this.highestPixelScale);
/*      */           } else {
/* 1022 */             baseTransform = BaseTransform.IDENTITY_TRANSFORM;
/*      */           } 
/* 1024 */           applyEffectOnAintoC(this.cv.input, effect, baseTransform, null, CompositeMode.SRC, renderBuf2);
/*      */ 
/*      */           
/* 1027 */           this.cv.input.setPixelScale(1.0F);
/* 1028 */           if (renderBuf2 != this.cv) {
/* 1029 */             blendAthruBintoC(renderBuf2, Blend.Mode.SRC_IN, this.clip, null, CompositeMode.SRC, this.cv);
/*      */           }
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 12:
/* 1035 */           this.effect = (Effect)paramGrowableDataBuffer.getObject();
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 47:
/*      */         case 48:
/*      */         case 50:
/*      */         case 51:
/* 1056 */           bool1 = initClip();
/* 1057 */           if (bool1) {
/* 1058 */             this.temp.validate(this.cv.g, this.tw, this.th);
/* 1059 */             bool = true;
/* 1060 */             renderBuf1 = this.temp;
/* 1061 */           } else if (this.blendmode != Blend.Mode.SRC_OVER) {
/* 1062 */             this.temp.validate(this.cv.g, this.tw, this.th);
/* 1063 */             bool = true;
/* 1064 */             renderBuf1 = this.temp;
/*      */           } else {
/* 1066 */             bool = false;
/* 1067 */             renderBuf1 = this.cv;
/*      */           } 
/* 1069 */           if (this.effect != null) {
/* 1070 */             paramGrowableDataBuffer.save();
/* 1071 */             handleRenderOp(b1, paramGrowableDataBuffer, null, TEMP_RECTBOUNDS);
/* 1072 */             RenderInput renderInput = new RenderInput(b1, paramGrowableDataBuffer, this.transform, TEMP_RECTBOUNDS);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1081 */             Rectangle rectangle = applyEffectOnAintoC(renderInput, this.effect, this.transform, this.clipRect, CompositeMode.SRC_OVER, renderBuf1);
/*      */ 
/*      */             
/* 1084 */             if (renderBuf1 != this.cv) {
/* 1085 */               TEMP_RECTBOUNDS.setBounds(rectangle.x, rectangle.y, (rectangle.x + rectangle.width), (rectangle.y + rectangle.height));
/*      */             }
/*      */           }
/*      */           else {
/*      */             
/* 1090 */             Graphics graphics = renderBuf1.g;
/* 1091 */             graphics.setExtraAlpha(this.globalAlpha);
/* 1092 */             graphics.setTransform(this.transform);
/* 1093 */             graphics.setClipRect(this.clipRect);
/*      */ 
/*      */ 
/*      */             
/* 1097 */             RectBounds rectBounds = (renderBuf1 != this.cv) ? TEMP_RECTBOUNDS : null;
/* 1098 */             handleRenderOp(b1, paramGrowableDataBuffer, graphics, rectBounds);
/* 1099 */             graphics.setClipRect(null);
/*      */           } 
/* 1101 */           if (bool1) {
/*      */             CompositeMode compositeMode;
/* 1103 */             if (this.blendmode == Blend.Mode.SRC_OVER) {
/*      */ 
/*      */ 
/*      */               
/* 1107 */               renderBuf1 = this.cv;
/* 1108 */               compositeMode = CompositeMode.SRC_OVER;
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */ 
/*      */               
/* 1117 */               compositeMode = CompositeMode.SRC;
/*      */             } 
/* 1119 */             if (this.clipRect != null) {
/* 1120 */               TEMP_RECTBOUNDS.intersectWith(this.clipRect);
/*      */             }
/* 1122 */             if (!TEMP_RECTBOUNDS.isEmpty()) {
/* 1123 */               if (renderBuf1 == this.cv && this.cv.g instanceof MaskTextureGraphics) {
/* 1124 */                 MaskTextureGraphics maskTextureGraphics = (MaskTextureGraphics)this.cv.g;
/* 1125 */                 int i2 = (int)Math.floor(TEMP_RECTBOUNDS.getMinX());
/* 1126 */                 int i3 = (int)Math.floor(TEMP_RECTBOUNDS.getMinY());
/* 1127 */                 int i4 = (int)Math.ceil(TEMP_RECTBOUNDS.getMaxX()) - i2;
/* 1128 */                 int i5 = (int)Math.ceil(TEMP_RECTBOUNDS.getMaxY()) - i3;
/* 1129 */                 maskTextureGraphics.drawPixelsMasked(this.temp.tex, this.clip.tex, i2, i3, i4, i5, i2, i3, i2, i3);
/*      */               }
/*      */               else {
/*      */                 
/* 1133 */                 blendAthruBintoC(this.temp, Blend.Mode.SRC_IN, this.clip, TEMP_RECTBOUNDS, compositeMode, renderBuf1);
/*      */               } 
/*      */             }
/*      */           } 
/*      */           
/* 1138 */           if (this.blendmode != Blend.Mode.SRC_OVER) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1143 */             if (this.clipRect != null) {
/* 1144 */               TEMP_RECTBOUNDS.intersectWith(this.clipRect);
/*      */             }
/* 1146 */             blendAthruBintoC(this.temp, this.blendmode, this.cv, TEMP_RECTBOUNDS, CompositeMode.SRC, this.cv);
/*      */           } 
/*      */           
/* 1149 */           if (bool1) {
/* 1150 */             this.clip.tex.unlock();
/*      */           }
/* 1152 */           if (bool) {
/* 1153 */             this.temp.tex.unlock();
/*      */           }
/*      */           continue;
/*      */       } 
/*      */       
/* 1158 */       throw new InternalError("Unrecognized PGCanvas token: " + b1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleRenderOp(int paramInt, GrowableDataBuffer paramGrowableDataBuffer, Graphics paramGraphics, RectBounds paramRectBounds) {
/*      */     float f1, f2, f3, f4;
/*      */     boolean bool;
/*      */     float f5;
/*      */     Image image;
/*      */     String str;
/*      */     float f6;
/*      */     char c;
/*      */     float f7, f8, f9;
/*      */     BaseBounds baseBounds;
/*      */     float f10, f11, f12, f13, f14;
/* 1176 */     boolean bool1 = false;
/* 1177 */     boolean bool2 = false;
/* 1178 */     switch (paramInt) {
/*      */       
/*      */       case 47:
/* 1181 */         if (paramRectBounds != null) {
/* 1182 */           shapebounds(this.path, paramRectBounds, BaseTransform.IDENTITY_TRANSFORM);
/*      */         }
/* 1184 */         if (paramGraphics != null) {
/* 1185 */           setupFill(paramGraphics);
/* 1186 */           paramGraphics.fill(this.untransformedPath);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 48:
/* 1192 */         if (paramRectBounds != null) {
/* 1193 */           strokebounds(getStroke(), this.untransformedPath, paramRectBounds, this.transform);
/*      */         }
/* 1195 */         if (paramGraphics != null) {
/* 1196 */           setupStroke(paramGraphics);
/* 1197 */           paramGraphics.draw(this.untransformedPath);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 23:
/* 1203 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1204 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1205 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1206 */         f4 = paramGrowableDataBuffer.getFloat();
/* 1207 */         if (paramRectBounds != null) {
/* 1208 */           paramRectBounds.setBoundsAndSort(f1, f2, f3, f4);
/* 1209 */           bool1 = true;
/* 1210 */           bool2 = true;
/*      */         } 
/* 1212 */         if (paramGraphics != null) {
/* 1213 */           setupStroke(paramGraphics);
/* 1214 */           paramGraphics.drawLine(f1, f2, f3, f4);
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 21:
/*      */       case 25:
/* 1220 */         bool1 = true;
/*      */       
/*      */       case 20:
/*      */       case 22:
/*      */       case 24:
/* 1225 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1226 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1227 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1228 */         f4 = paramGrowableDataBuffer.getFloat();
/* 1229 */         if (paramRectBounds != null) {
/* 1230 */           paramRectBounds.setBounds(f1, f2, f1 + f3, f2 + f4);
/* 1231 */           bool2 = true;
/*      */         } 
/* 1233 */         if (paramGraphics != null) {
/* 1234 */           switch (paramInt) {
/*      */             case 20:
/* 1236 */               setupFill(paramGraphics);
/* 1237 */               paramGraphics.fillRect(f1, f2, f3, f4);
/*      */               break;
/*      */             case 24:
/* 1240 */               setupFill(paramGraphics);
/* 1241 */               paramGraphics.fillEllipse(f1, f2, f3, f4);
/*      */               break;
/*      */             case 21:
/* 1244 */               setupStroke(paramGraphics);
/* 1245 */               paramGraphics.drawRect(f1, f2, f3, f4);
/*      */               break;
/*      */             case 25:
/* 1248 */               setupStroke(paramGraphics);
/* 1249 */               paramGraphics.drawEllipse(f1, f2, f3, f4);
/*      */               break;
/*      */             case 22:
/* 1252 */               paramGraphics.setCompositeMode(CompositeMode.CLEAR);
/* 1253 */               paramGraphics.fillRect(f1, f2, f3, f4);
/* 1254 */               paramGraphics.setCompositeMode(CompositeMode.SRC_OVER);
/*      */               break;
/*      */           } 
/*      */         
/*      */         }
/*      */         break;
/*      */       case 27:
/* 1261 */         bool1 = true;
/*      */       
/*      */       case 26:
/* 1264 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1265 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1266 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1267 */         f4 = paramGrowableDataBuffer.getFloat();
/* 1268 */         f5 = paramGrowableDataBuffer.getFloat();
/* 1269 */         f6 = paramGrowableDataBuffer.getFloat();
/* 1270 */         if (paramRectBounds != null) {
/* 1271 */           paramRectBounds.setBounds(f1, f2, f1 + f3, f2 + f4);
/* 1272 */           bool2 = true;
/*      */         } 
/* 1274 */         if (paramGraphics != null) {
/* 1275 */           if (paramInt == 26) {
/* 1276 */             setupFill(paramGraphics);
/* 1277 */             paramGraphics.fillRoundRect(f1, f2, f3, f4, f5, f6); break;
/*      */           } 
/* 1279 */           setupStroke(paramGraphics);
/* 1280 */           paramGraphics.drawRoundRect(f1, f2, f3, f4, f5, f6);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 28:
/*      */       case 29:
/* 1288 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1289 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1290 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1291 */         f4 = paramGrowableDataBuffer.getFloat();
/* 1292 */         f5 = paramGrowableDataBuffer.getFloat();
/* 1293 */         f6 = paramGrowableDataBuffer.getFloat();
/* 1294 */         TEMP_ARC.setArc(f1, f2, f3, f4, f5, f6, this.arctype);
/* 1295 */         if (paramInt == 28) {
/* 1296 */           if (paramRectBounds != null) {
/* 1297 */             shapebounds(TEMP_ARC, paramRectBounds, this.transform);
/*      */           }
/* 1299 */           if (paramGraphics != null) {
/* 1300 */             setupFill(paramGraphics);
/* 1301 */             paramGraphics.fill(TEMP_ARC);
/*      */           }  break;
/*      */         } 
/* 1304 */         if (paramRectBounds != null) {
/* 1305 */           strokebounds(getStroke(), TEMP_ARC, paramRectBounds, this.transform);
/*      */         }
/* 1307 */         if (paramGraphics != null) {
/* 1308 */           setupStroke(paramGraphics);
/* 1309 */           paramGraphics.draw(TEMP_ARC);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 50:
/*      */       case 51:
/* 1317 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1318 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1319 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1320 */         f4 = paramGrowableDataBuffer.getFloat();
/* 1321 */         image = (Image)paramGrowableDataBuffer.getObject();
/*      */         
/* 1323 */         if (paramInt == 50) {
/* 1324 */           f6 = f7 = 0.0F;
/* 1325 */           f8 = image.getWidth();
/* 1326 */           f9 = image.getHeight();
/*      */         } else {
/* 1328 */           f6 = paramGrowableDataBuffer.getFloat();
/* 1329 */           f7 = paramGrowableDataBuffer.getFloat();
/* 1330 */           f8 = paramGrowableDataBuffer.getFloat();
/* 1331 */           f9 = paramGrowableDataBuffer.getFloat();
/* 1332 */           float f = image.getPixelScale();
/* 1333 */           if (f != 1.0F) {
/* 1334 */             f6 *= f;
/* 1335 */             f7 *= f;
/* 1336 */             f8 *= f;
/* 1337 */             f9 *= f;
/*      */           } 
/*      */         } 
/* 1340 */         if (paramRectBounds != null) {
/* 1341 */           paramRectBounds.setBounds(f1, f2, f1 + f3, f2 + f4);
/* 1342 */           bool2 = true;
/*      */         } 
/* 1344 */         if (paramGraphics != null) {
/* 1345 */           ResourceFactory resourceFactory = paramGraphics.getResourceFactory();
/*      */           
/* 1347 */           Texture texture = resourceFactory.getCachedTexture(image, Texture.WrapMode.CLAMP_TO_EDGE);
/* 1348 */           paramGraphics.drawTexture(texture, f1, f2, f1 + f3, f2 + f4, f6, f7, f6 + f8, f7 + f9);
/*      */ 
/*      */           
/* 1351 */           texture.unlock();
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30:
/*      */       case 31:
/* 1358 */         f1 = paramGrowableDataBuffer.getFloat();
/* 1359 */         f2 = paramGrowableDataBuffer.getFloat();
/* 1360 */         f3 = paramGrowableDataBuffer.getFloat();
/* 1361 */         bool = paramGrowableDataBuffer.getBoolean();
/* 1362 */         str = (String)paramGrowableDataBuffer.getObject();
/*      */         
/* 1364 */         c = bool ? 'ࠀ' : 'Ѐ';
/*      */         
/* 1366 */         this.textLayout.setContent(str, this.pgfont);
/* 1367 */         this.textLayout.setAlignment(this.align);
/* 1368 */         this.textLayout.setDirection(c);
/* 1369 */         f7 = 0.0F; f8 = 0.0F;
/* 1370 */         baseBounds = this.textLayout.getBounds();
/* 1371 */         f10 = baseBounds.getWidth();
/* 1372 */         f11 = baseBounds.getHeight();
/* 1373 */         switch (this.align) { case 2:
/* 1374 */             f7 = f10; break;
/* 1375 */           case 1: f7 = f10 / 2.0F; break; }
/*      */         
/* 1377 */         switch (this.baseline) { case 2:
/* 1378 */             f8 = -baseBounds.getMinY(); break;
/* 1379 */           case 1: f8 = f11 / 2.0F; break;
/* 1380 */           case 3: f8 = f11; break; }
/*      */         
/* 1382 */         f12 = 1.0F;
/* 1383 */         f13 = 0.0F;
/* 1384 */         f14 = f2 - f8;
/* 1385 */         if (f3 > 0.0D && f10 > f3) {
/* 1386 */           float f = f3 / f10;
/* 1387 */           if (bool) {
/* 1388 */             f13 = -((f1 + f3) / f - f7);
/* 1389 */             f12 = -f;
/*      */           } else {
/* 1391 */             f13 = f1 / f - f7;
/* 1392 */             f12 = f;
/*      */           }
/*      */         
/* 1395 */         } else if (bool) {
/* 1396 */           f13 = -(f1 - f7 + f10);
/* 1397 */           f12 = -1.0F;
/*      */         } else {
/* 1399 */           f13 = f1 - f7;
/*      */         } 
/*      */         
/* 1402 */         if (paramRectBounds != null) {
/* 1403 */           computeTextLayoutBounds(paramRectBounds, this.transform, f12, f13, f14, paramInt);
/*      */         }
/* 1405 */         if (paramGraphics != null) {
/* 1406 */           if (f12 != 1.0F) {
/* 1407 */             paramGraphics.scale(f12, 1.0F);
/*      */           }
/* 1409 */           this.ngtext.setLayoutLocation(-f13, -f14);
/* 1410 */           if (paramInt == 30) {
/* 1411 */             this.ngtext.setMode(NGShape.Mode.FILL);
/* 1412 */             this.ngtext.setFillPaint(this.fillPaint);
/* 1413 */             if (this.fillPaint.isProportional() || this.smoothing == SMOOTH_LCD) {
/* 1414 */               RectBounds rectBounds = new RectBounds();
/* 1415 */               computeTextLayoutBounds(rectBounds, BaseTransform.IDENTITY_TRANSFORM, 1.0F, f13, f14, paramInt);
/*      */               
/* 1417 */               this.ngtext.setContentBounds(rectBounds);
/*      */             } 
/*      */           } else {
/*      */             
/* 1421 */             if (this.strokePaint.isProportional()) {
/* 1422 */               RectBounds rectBounds = new RectBounds();
/* 1423 */               computeTextLayoutBounds(rectBounds, BaseTransform.IDENTITY_TRANSFORM, 1.0F, f13, f14, paramInt);
/*      */               
/* 1425 */               this.ngtext.setContentBounds(rectBounds);
/*      */             } 
/* 1427 */             this.ngtext.setMode(NGShape.Mode.STROKE);
/* 1428 */             this.ngtext.setDrawStroke(getStroke());
/* 1429 */             this.ngtext.setDrawPaint(this.strokePaint);
/*      */           } 
/* 1431 */           this.ngtext.setFont(this.pgfont);
/* 1432 */           this.ngtext.setFontSmoothingType(this.smoothing);
/* 1433 */           this.ngtext.setGlyphs((Object[])this.textLayout.getRuns());
/* 1434 */           this.ngtext.renderContent(paramGraphics);
/*      */         } 
/*      */         break;
/*      */       
/*      */       default:
/* 1439 */         throw new InternalError("Unrecognized PGCanvas rendering token: " + paramInt);
/*      */     } 
/* 1441 */     if (paramRectBounds != null) {
/* 1442 */       if (bool1) {
/* 1443 */         BasicStroke basicStroke = getStroke();
/* 1444 */         if (basicStroke.getType() != 1) {
/* 1445 */           f2 = basicStroke.getLineWidth();
/* 1446 */           if (basicStroke.getType() == 0) {
/* 1447 */             f2 /= 2.0F;
/*      */           }
/* 1449 */           paramRectBounds.grow(f2, f2);
/*      */         } 
/*      */       } 
/* 1452 */       if (bool2) {
/* 1453 */         txBounds(paramRectBounds, this.transform);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void computeTextLayoutBounds(RectBounds paramRectBounds, BaseTransform paramBaseTransform, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt) {
/* 1462 */     this.textLayout.getBounds(null, paramRectBounds);
/* 1463 */     TEMP_TX.setTransform(paramBaseTransform);
/* 1464 */     TEMP_TX.scale(paramFloat1, 1.0D);
/* 1465 */     TEMP_TX.translate(paramFloat2, paramFloat3);
/* 1466 */     TEMP_TX.transform(paramRectBounds, paramRectBounds);
/* 1467 */     if (paramInt == 31) {
/* 1468 */       boolean bool = true;
/* 1469 */       Shape shape = this.textLayout.getShape(bool, null);
/* 1470 */       RectBounds rectBounds = new RectBounds();
/* 1471 */       strokebounds(getStroke(), shape, rectBounds, TEMP_TX);
/* 1472 */       paramRectBounds.unionWith(rectBounds);
/*      */     } 
/*      */   }
/*      */   static void txBounds(RectBounds paramRectBounds, BaseTransform paramBaseTransform) {
/*      */     float f1, f2;
/* 1477 */     switch (paramBaseTransform.getType()) {
/*      */       case 0:
/*      */         return;
/*      */       case 1:
/* 1481 */         f1 = (float)paramBaseTransform.getMxt();
/* 1482 */         f2 = (float)paramBaseTransform.getMyt();
/* 1483 */         paramRectBounds.setBounds(paramRectBounds.getMinX() + f1, paramRectBounds.getMinY() + f2, paramRectBounds
/* 1484 */             .getMaxX() + f1, paramRectBounds.getMaxY() + f2);
/*      */     } 
/*      */     
/* 1487 */     BaseBounds baseBounds = paramBaseTransform.transform(paramRectBounds, paramRectBounds);
/* 1488 */     if (baseBounds != paramRectBounds) {
/* 1489 */       paramRectBounds.setBounds(baseBounds.getMinX(), baseBounds.getMinY(), baseBounds
/* 1490 */           .getMaxX(), baseBounds.getMaxY());
/*      */     }
/*      */   }
/*      */   
/*      */   static void inverseTxBounds(RectBounds paramRectBounds, BaseTransform paramBaseTransform) {
/*      */     float f1;
/*      */     float f2;
/* 1497 */     switch (paramBaseTransform.getType()) {
/*      */       case 0:
/*      */         return;
/*      */       case 1:
/* 1501 */         f1 = (float)paramBaseTransform.getMxt();
/* 1502 */         f2 = (float)paramBaseTransform.getMyt();
/* 1503 */         paramRectBounds.setBounds(paramRectBounds.getMinX() - f1, paramRectBounds.getMinY() - f2, paramRectBounds
/* 1504 */             .getMaxX() - f1, paramRectBounds.getMaxY() - f2);
/*      */     } 
/*      */     
/*      */     try {
/* 1508 */       BaseBounds baseBounds = paramBaseTransform.inverseTransform(paramRectBounds, paramRectBounds);
/* 1509 */       if (baseBounds != paramRectBounds) {
/* 1510 */         paramRectBounds.setBounds(baseBounds.getMinX(), baseBounds.getMinY(), baseBounds
/* 1511 */             .getMaxX(), baseBounds.getMaxY());
/*      */       }
/* 1513 */     } catch (NoninvertibleTransformException noninvertibleTransformException) {
/* 1514 */       paramRectBounds.makeEmpty();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBounds(float paramFloat1, float paramFloat2) {
/* 1521 */     this.tw = (int)Math.ceil((paramFloat1 * this.highestPixelScale));
/* 1522 */     this.th = (int)Math.ceil((paramFloat2 * this.highestPixelScale));
/* 1523 */     geometryChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean updateRendering(GrowableDataBuffer paramGrowableDataBuffer) {
/*      */     GrowableDataBuffer growableDataBuffer;
/* 1532 */     if (paramGrowableDataBuffer.isEmpty()) {
/* 1533 */       GrowableDataBuffer.returnBuffer(paramGrowableDataBuffer);
/* 1534 */       return (this.thebuf != null);
/*      */     } 
/* 1536 */     boolean bool = (paramGrowableDataBuffer.peekByte(0) == 70) ? true : false;
/*      */     
/* 1538 */     if (bool || this.thebuf == null) {
/* 1539 */       growableDataBuffer = this.thebuf;
/* 1540 */       this.thebuf = paramGrowableDataBuffer;
/*      */     } else {
/* 1542 */       this.thebuf.append(paramGrowableDataBuffer);
/* 1543 */       growableDataBuffer = paramGrowableDataBuffer;
/*      */     } 
/* 1545 */     geometryChanged();
/* 1546 */     if (growableDataBuffer != null) {
/* 1547 */       GrowableDataBuffer.returnBuffer(growableDataBuffer);
/* 1548 */       return true;
/*      */     } 
/* 1550 */     return false;
/*      */   }
/*      */   class RenderInput extends Effect { float x; float y;
/*      */     float w;
/*      */     float h;
/*      */     int token;
/*      */     GrowableDataBuffer buf;
/* 1557 */     Affine2D savedBoundsTx = new Affine2D();
/*      */ 
/*      */ 
/*      */     
/*      */     public RenderInput(int param1Int, GrowableDataBuffer param1GrowableDataBuffer, BaseTransform param1BaseTransform, RectBounds param1RectBounds) {
/* 1562 */       this.token = param1Int;
/* 1563 */       this.buf = param1GrowableDataBuffer;
/* 1564 */       this.savedBoundsTx.setTransform(param1BaseTransform);
/* 1565 */       this.x = param1RectBounds.getMinX();
/* 1566 */       this.y = param1RectBounds.getMinY();
/* 1567 */       this.w = param1RectBounds.getWidth();
/* 1568 */       this.h = param1RectBounds.getHeight();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageData filter(FilterContext param1FilterContext, BaseTransform param1BaseTransform, Rectangle param1Rectangle, Object param1Object, Effect param1Effect) {
/* 1576 */       BaseBounds baseBounds = getBounds(param1BaseTransform, param1Effect);
/* 1577 */       if (param1Rectangle != null) {
/* 1578 */         baseBounds.intersectWith(param1Rectangle);
/*      */       }
/* 1580 */       Rectangle rectangle = new Rectangle(baseBounds);
/* 1581 */       if (rectangle.width < 1) rectangle.width = 1; 
/* 1582 */       if (rectangle.height < 1) rectangle.height = 1; 
/* 1583 */       PrDrawable prDrawable = (PrDrawable)Effect.getCompatibleImage(param1FilterContext, rectangle.width, rectangle.height);
/* 1584 */       if (prDrawable != null) {
/* 1585 */         Graphics graphics = prDrawable.createGraphics();
/* 1586 */         graphics.setExtraAlpha(NGCanvas.this.globalAlpha);
/* 1587 */         graphics.translate(-rectangle.x, -rectangle.y);
/* 1588 */         if (param1BaseTransform != null) {
/* 1589 */           graphics.transform(param1BaseTransform);
/*      */         }
/* 1591 */         this.buf.restore();
/* 1592 */         NGCanvas.this.handleRenderOp(this.token, this.buf, graphics, null);
/*      */       } 
/* 1594 */       return new ImageData(param1FilterContext, prDrawable, rectangle);
/*      */     }
/*      */ 
/*      */     
/*      */     public Effect.AccelType getAccelType(FilterContext param1FilterContext) {
/* 1599 */       throw new UnsupportedOperationException("Not supported yet.");
/*      */     }
/*      */ 
/*      */     
/*      */     public BaseBounds getBounds(BaseTransform param1BaseTransform, Effect param1Effect) {
/* 1604 */       RectBounds rectBounds = new RectBounds(this.x, this.y, this.x + this.w, this.y + this.h);
/* 1605 */       if (!param1BaseTransform.equals(this.savedBoundsTx)) {
/* 1606 */         NGCanvas.inverseTxBounds(rectBounds, this.savedBoundsTx);
/* 1607 */         NGCanvas.txBounds(rectBounds, param1BaseTransform);
/*      */       } 
/* 1609 */       return rectBounds;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean reducesOpaquePixels() {
/* 1614 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public DirtyRegionContainer getDirtyRegions(Effect param1Effect, DirtyRegionPool param1DirtyRegionPool) {
/* 1619 */       return null;
/*      */     } }
/*      */ 
/*      */   
/*      */   static class MyBlend
/*      */     extends Blend {
/*      */     public MyBlend(Blend.Mode param1Mode, Effect param1Effect1, Effect param1Effect2) {
/* 1626 */       super(param1Mode, param1Effect1, param1Effect2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Rectangle getResultBounds(BaseTransform param1BaseTransform, Rectangle param1Rectangle, ImageData... param1VarArgs) {
/* 1637 */       Rectangle rectangle = super.getResultBounds(param1BaseTransform, param1Rectangle, param1VarArgs);
/* 1638 */       rectangle.intersectWith(param1Rectangle);
/* 1639 */       return rectangle;
/*      */     }
/*      */   }
/*      */   
/*      */   static class EffectInput extends Effect {
/*      */     RTTexture tex;
/*      */     float pixelscale;
/*      */     
/*      */     EffectInput(RTTexture param1RTTexture) {
/* 1648 */       this.tex = param1RTTexture;
/* 1649 */       this.pixelscale = 1.0F;
/*      */     }
/*      */     
/*      */     public void setPixelScale(float param1Float) {
/* 1653 */       this.pixelscale = param1Float;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ImageData filter(FilterContext param1FilterContext, BaseTransform param1BaseTransform, Rectangle param1Rectangle, Object param1Object, Effect param1Effect) {
/* 1661 */       PrDrawable prDrawable = PrDrawable.create(param1FilterContext, this.tex);
/* 1662 */       Rectangle rectangle = new Rectangle(this.tex.getContentWidth(), this.tex.getContentHeight());
/* 1663 */       prDrawable.lock();
/* 1664 */       ImageData imageData = new ImageData(param1FilterContext, prDrawable, rectangle);
/* 1665 */       imageData.setReusable(true);
/* 1666 */       if (this.pixelscale != 1.0F || !param1BaseTransform.isIdentity()) {
/* 1667 */         Affine2D affine2D = new Affine2D();
/* 1668 */         affine2D.scale((1.0F / this.pixelscale), (1.0F / this.pixelscale));
/* 1669 */         affine2D.concatenate(param1BaseTransform);
/* 1670 */         imageData = imageData.transform(affine2D);
/*      */       } 
/* 1672 */       return imageData;
/*      */     }
/*      */ 
/*      */     
/*      */     public Effect.AccelType getAccelType(FilterContext param1FilterContext) {
/* 1677 */       throw new UnsupportedOperationException("Not supported yet.");
/*      */     }
/*      */ 
/*      */     
/*      */     public BaseBounds getBounds(BaseTransform param1BaseTransform, Effect param1Effect) {
/* 1682 */       Rectangle rectangle = new Rectangle(this.tex.getContentWidth(), this.tex.getContentHeight());
/* 1683 */       return transformBounds(param1BaseTransform, new RectBounds(rectangle));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean reducesOpaquePixels() {
/* 1688 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public DirtyRegionContainer getDirtyRegions(Effect param1Effect, DirtyRegionPool param1DirtyRegionPool) {
/* 1693 */       return null;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\sg\prism\NGCanvas.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */