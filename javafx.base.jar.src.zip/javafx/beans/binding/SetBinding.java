/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.BindingHelperObserver;
/*     */ import com.sun.javafx.binding.SetExpressionHelper;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyBooleanPropertyBase;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerPropertyBase;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.collections.SetChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SetBinding<E>
/*     */   extends SetExpression<E>
/*     */   implements Binding<ObservableSet<E>>
/*     */ {
/*  68 */   private final SetChangeListener<E> setChangeListener = new SetChangeListener<E>()
/*     */     {
/*     */       public void onChanged(SetChangeListener.Change<? extends E> param1Change) {
/*  71 */         SetBinding.this.invalidateProperties();
/*  72 */         SetBinding.this.onInvalidating();
/*  73 */         SetExpressionHelper.fireValueChangedEvent(SetBinding.this.helper, param1Change);
/*     */       }
/*     */     };
/*     */   
/*     */   private ObservableSet<E> value;
/*     */   private boolean valid = false;
/*     */   private BindingHelperObserver observer;
/*  80 */   private SetExpressionHelper<E> helper = null;
/*     */   
/*     */   private SizeProperty size0;
/*     */   
/*     */   private EmptyProperty empty0;
/*     */   
/*     */   public ReadOnlyIntegerProperty sizeProperty() {
/*  87 */     if (this.size0 == null) {
/*  88 */       this.size0 = new SizeProperty();
/*     */     }
/*  90 */     return this.size0;
/*     */   }
/*     */   
/*     */   private class SizeProperty
/*     */     extends ReadOnlyIntegerPropertyBase {
/*     */     public int get() {
/*  96 */       return SetBinding.this.size();
/*     */     }
/*     */     private SizeProperty() {}
/*     */     
/*     */     public Object getBean() {
/* 101 */       return SetBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 106 */       return "size";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 110 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadOnlyBooleanProperty emptyProperty() {
/* 116 */     if (this.empty0 == null) {
/* 117 */       this.empty0 = new EmptyProperty();
/*     */     }
/* 119 */     return this.empty0;
/*     */   }
/*     */   
/*     */   private class EmptyProperty extends ReadOnlyBooleanPropertyBase {
/*     */     private EmptyProperty() {}
/*     */     
/*     */     public boolean get() {
/* 126 */       return SetBinding.this.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getBean() {
/* 131 */       return SetBinding.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 136 */       return "empty";
/*     */     }
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 140 */       super.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 146 */     this.helper = SetExpressionHelper.addListener(this.helper, this, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 151 */     this.helper = SetExpressionHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(ChangeListener<? super ObservableSet<E>> paramChangeListener) {
/* 156 */     this.helper = SetExpressionHelper.addListener(this.helper, this, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ChangeListener<? super ObservableSet<E>> paramChangeListener) {
/* 161 */     this.helper = SetExpressionHelper.removeListener(this.helper, paramChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(SetChangeListener<? super E> paramSetChangeListener) {
/* 166 */     this.helper = SetExpressionHelper.addListener(this.helper, this, paramSetChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(SetChangeListener<? super E> paramSetChangeListener) {
/* 171 */     this.helper = SetExpressionHelper.removeListener(this.helper, paramSetChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void bind(Observable... paramVarArgs) {
/* 182 */     if (paramVarArgs != null && paramVarArgs.length > 0) {
/* 183 */       if (this.observer == null) {
/* 184 */         this.observer = new BindingHelperObserver(this);
/*     */       }
/* 186 */       for (Observable observable : paramVarArgs) {
/* 187 */         if (observable != null) {
/* 188 */           observable.addListener(this.observer);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void unbind(Observable... paramVarArgs) {
/* 201 */     if (this.observer != null) {
/* 202 */       for (Observable observable : paramVarArgs) {
/* 203 */         if (observable != null) {
/* 204 */           observable.removeListener(this.observer);
/*     */         }
/*     */       } 
/* 207 */       this.observer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableList<?> getDependencies() {
/* 226 */     return FXCollections.emptyObservableList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableSet<E> get() {
/* 239 */     if (!this.valid) {
/* 240 */       this.value = computeValue();
/* 241 */       this.valid = true;
/* 242 */       if (this.value != null) {
/* 243 */         this.value.addListener(this.setChangeListener);
/*     */       }
/*     */     } 
/* 246 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onInvalidating() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateProperties() {
/* 258 */     if (this.size0 != null) {
/* 259 */       this.size0.fireValueChangedEvent();
/*     */     }
/* 261 */     if (this.empty0 != null) {
/* 262 */       this.empty0.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final void invalidate() {
/* 268 */     if (this.valid) {
/* 269 */       if (this.value != null) {
/* 270 */         this.value.removeListener(this.setChangeListener);
/*     */       }
/* 272 */       this.valid = false;
/* 273 */       invalidateProperties();
/* 274 */       onInvalidating();
/* 275 */       SetExpressionHelper.fireValueChangedEvent(this.helper);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isValid() {
/* 281 */     return this.valid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 300 */     return this.valid ? ("SetBinding [value: " + get() + "]") : 
/* 301 */       "SetBinding [invalid]";
/*     */   }
/*     */   
/*     */   protected abstract ObservableSet<E> computeValue();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\SetBinding.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */