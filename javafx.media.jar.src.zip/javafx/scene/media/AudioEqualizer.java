/*     */ package javafx.scene.media;
/*     */ 
/*     */ import com.sun.javafx.collections.VetoableListDecorator;
/*     */ import com.sun.media.jfxmedia.effects.EqualizerBand;
/*     */ import com.sun.media.jfxmedia.logging.Logger;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.BooleanPropertyBase;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AudioEqualizer
/*     */ {
/*     */   public static final int MAX_NUM_BANDS = 64;
/*  56 */   private com.sun.media.jfxmedia.effects.AudioEqualizer jfxEqualizer = null;
/*     */   private final ObservableList<EqualizerBand> bands;
/*  58 */   private final Object disposeLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BooleanProperty enabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObservableList<EqualizerBand> getBands() {
/*  97 */     return this.bands;
/*     */   }
/*     */   
/*     */   AudioEqualizer() {
/* 101 */     this.bands = new Bands();
/*     */ 
/*     */     
/* 104 */     this.bands.addAll(new EqualizerBand[] { new EqualizerBand(32.0D, 19.0D, 0.0D), new EqualizerBand(64.0D, 39.0D, 0.0D), new EqualizerBand(125.0D, 78.0D, 0.0D), new EqualizerBand(250.0D, 156.0D, 0.0D), new EqualizerBand(500.0D, 312.0D, 0.0D), new EqualizerBand(1000.0D, 625.0D, 0.0D), new EqualizerBand(2000.0D, 1250.0D, 0.0D), new EqualizerBand(4000.0D, 2500.0D, 0.0D), new EqualizerBand(8000.0D, 5000.0D, 0.0D), new EqualizerBand(16000.0D, 10000.0D, 0.0D) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAudioEqualizer(com.sun.media.jfxmedia.effects.AudioEqualizer paramAudioEqualizer) {
/* 122 */     synchronized (this.disposeLock) {
/* 123 */       if (this.jfxEqualizer == paramAudioEqualizer) {
/*     */         return;
/*     */       }
/*     */       
/* 127 */       if (this.jfxEqualizer != null && paramAudioEqualizer == null) {
/* 128 */         this.jfxEqualizer.setEnabled(false);
/* 129 */         for (EqualizerBand equalizerBand : this.bands) {
/* 130 */           equalizerBand.setJfxBand(null);
/*     */         }
/* 132 */         this.jfxEqualizer = null;
/*     */         
/*     */         return;
/*     */       } 
/* 136 */       this.jfxEqualizer = paramAudioEqualizer;
/*     */ 
/*     */       
/* 139 */       paramAudioEqualizer.setEnabled(isEnabled());
/*     */       
/* 141 */       for (EqualizerBand equalizerBand : this.bands) {
/* 142 */         if (equalizerBand.getCenterFrequency() > 0.0D && equalizerBand.getBandwidth() > 0.0D) {
/*     */           
/* 144 */           EqualizerBand equalizerBand1 = paramAudioEqualizer.addBand(equalizerBand.getCenterFrequency(), equalizerBand
/* 145 */               .getBandwidth(), equalizerBand
/* 146 */               .getGain());
/*     */ 
/*     */           
/* 149 */           equalizerBand.setJfxBand(equalizerBand1); continue;
/*     */         } 
/* 151 */         Logger.logMsg(4, "Center frequency [" + equalizerBand.getCenterFrequency() + "] and bandwidth [" + equalizerBand
/* 152 */             .getBandwidth() + "] must be greater than 0.");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEnabled(boolean paramBoolean) {
/* 161 */     enabledProperty().set(paramBoolean);
/*     */   }
/*     */   
/*     */   public final boolean isEnabled() {
/* 165 */     return (this.enabled == null) ? false : this.enabled.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanProperty enabledProperty() {
/* 178 */     if (this.enabled == null) {
/* 179 */       this.enabled = new BooleanPropertyBase()
/*     */         {
/*     */           protected void invalidated()
/*     */           {
/* 183 */             synchronized (AudioEqualizer.this.disposeLock) {
/* 184 */               if (AudioEqualizer.this.jfxEqualizer != null) {
/* 185 */                 AudioEqualizer.this.jfxEqualizer.setEnabled(AudioEqualizer.this.enabled.get());
/*     */               }
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public Object getBean() {
/* 192 */             return AudioEqualizer.this;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/* 197 */             return "enabled";
/*     */           }
/*     */         };
/*     */     }
/* 201 */     return this.enabled;
/*     */   }
/*     */   
/*     */   private class Bands
/*     */     extends VetoableListDecorator<EqualizerBand> {
/*     */     public Bands() {
/* 207 */       super(FXCollections.observableArrayList());
/*     */     }
/*     */ 
/*     */     
/*     */     protected void onProposedChange(List<EqualizerBand> param1List, int[] param1ArrayOfint) {
/* 212 */       synchronized (AudioEqualizer.this.disposeLock) {
/* 213 */         if (AudioEqualizer.this.jfxEqualizer != null) {
/* 214 */           for (byte b = 0; b < param1ArrayOfint.length; b += 2) {
/* 215 */             for (EqualizerBand equalizerBand : subList(param1ArrayOfint[b], param1ArrayOfint[b + 1])) {
/* 216 */               AudioEqualizer.this.jfxEqualizer.removeBand(equalizerBand.getCenterFrequency());
/*     */             }
/*     */           } 
/*     */           
/* 220 */           for (EqualizerBand equalizerBand : param1List) {
/* 221 */             if (equalizerBand.getCenterFrequency() > 0.0D && equalizerBand.getBandwidth() > 0.0D) {
/*     */               
/* 223 */               EqualizerBand equalizerBand1 = AudioEqualizer.this.jfxEqualizer.addBand(equalizerBand.getCenterFrequency(), equalizerBand
/* 224 */                   .getBandwidth(), equalizerBand
/* 225 */                   .getGain());
/* 226 */               equalizerBand.setJfxBand(equalizerBand1); continue;
/*     */             } 
/* 228 */             Logger.logMsg(4, "Center frequency [" + equalizerBand.getCenterFrequency() + "] and bandwidth [" + equalizerBand
/* 229 */                 .getBandwidth() + "] must be greater than 0.");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\javafx\scene\media\AudioEqualizer.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */