/*     */ package com.sun.media.jfxmedia;
/*     */ 
/*     */ import com.sun.media.jfxmediaimpl.AudioClipProvider;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AudioClip
/*     */ {
/*  99 */   protected int clipPriority = 0;
/* 100 */   protected int loopCount = 0;
/* 101 */   protected double clipVolume = 1.0D;
/* 102 */   protected double clipBalance = 0.0D;
/* 103 */   protected double clipRate = 1.0D;
/* 104 */   protected double clipPan = 0.0D;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_S8 = 0;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_U8 = 1;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_S16BE = 2;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_U16BE = 3;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_S16LE = 4;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_U16LE = 5;
/*     */ 
/*     */   
/*     */   public static final int SAMPLE_FORMAT_S24BE = 6;
/*     */   
/*     */   public static final int SAMPLE_FORMAT_U24BE = 7;
/*     */   
/*     */   public static final int SAMPLE_FORMAT_S24LE = 8;
/*     */   
/*     */   public static final int SAMPLE_FORMAT_U24LE = 9;
/*     */ 
/*     */   
/*     */   public static AudioClip load(URI paramURI) throws URISyntaxException, FileNotFoundException, IOException {
/* 135 */     return AudioClipProvider.getProvider().load(paramURI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AudioClip create(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws IllegalArgumentException {
/* 160 */     return AudioClipProvider.getProvider().create(paramArrayOfbyte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stopAllClips() {
/* 167 */     AudioClipProvider.getProvider().stopAllClips();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AudioClip createSegment(double paramDouble1, double paramDouble2) throws IllegalArgumentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AudioClip createSegment(int paramInt1, int paramInt2) throws IllegalArgumentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AudioClip resample(int paramInt1, int paramInt2, int paramInt3) throws IllegalArgumentException, IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AudioClip append(AudioClip paramAudioClip) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AudioClip flatten();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int priority() {
/* 259 */     return this.clipPriority;
/*     */   }
/*     */   public void setPriority(int paramInt) {
/* 262 */     this.clipPriority = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int loopCount() {
/* 273 */     return this.loopCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoopCount(int paramInt) {
/* 288 */     this.loopCount = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double volume() {
/* 297 */     return this.clipVolume;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVolume(double paramDouble) {
/* 307 */     this.clipVolume = paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double balance() {
/* 316 */     return this.clipBalance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBalance(double paramDouble) {
/* 326 */     this.clipBalance = paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double playbackRate() {
/* 338 */     return this.clipRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPlaybackRate(double paramDouble) {
/* 355 */     this.clipRate = paramDouble;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double pan() {
/* 364 */     return this.clipPan;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPan(double paramDouble) {
/* 378 */     this.clipPan = paramDouble;
/*     */   }
/*     */   
/*     */   public abstract boolean isPlaying();
/*     */   
/*     */   public abstract void play();
/*     */   
/*     */   public abstract void play(double paramDouble);
/*     */   
/*     */   public abstract void play(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract void stop();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.media.jar!\com\sun\media\jfxmedia\AudioClip.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */