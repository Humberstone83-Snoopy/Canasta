/*     */ package com.sun.webkit.network;
/*     */ 
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.IDN;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PublicSuffixes
/*     */ {
/*  46 */   private static final PlatformLogger logger = PlatformLogger.getLogger(PublicSuffixes.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum Rule
/*     */   {
/*  53 */     SIMPLE_RULE,
/*  54 */     WILDCARD_RULE,
/*  55 */     EXCEPTION_RULE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private static final Map<String, Rule> RULES = loadRules("effective_tld_names.dat");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PublicSuffixes() {
/*  70 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isPublicSuffix(String paramString) {
/*  78 */     if (paramString.length() == 0) {
/*  79 */       return false;
/*     */     }
/*  81 */     Rule rule = RULES.get(paramString);
/*  82 */     if (rule == Rule.EXCEPTION_RULE)
/*  83 */       return false; 
/*  84 */     if (rule == Rule.SIMPLE_RULE || rule == Rule.WILDCARD_RULE) {
/*  85 */       return true;
/*     */     }
/*  87 */     int i = paramString.indexOf('.') + 1;
/*  88 */     if (i == 0) {
/*  89 */       i = paramString.length();
/*     */     }
/*  91 */     String str = paramString.substring(i);
/*  92 */     return (RULES.get(str) == Rule.WILDCARD_RULE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Rule> loadRules(String paramString) {
/* 100 */     logger.finest("resourceName: [{0}]", new Object[] { paramString });
/* 101 */     Map<String, Rule> map = null;
/*     */     
/* 103 */     InputStream inputStream = PublicSuffixes.class.getResourceAsStream(paramString);
/* 104 */     if (inputStream != null) {
/* 105 */       BufferedReader bufferedReader = null;
/*     */       try {
/* 107 */         bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
/* 108 */         map = loadRules(bufferedReader);
/* 109 */       } catch (IOException iOException) {
/* 110 */         logger.warning("Unexpected error", iOException);
/*     */       } finally {
/*     */         try {
/* 113 */           if (bufferedReader != null) {
/* 114 */             bufferedReader.close();
/*     */           }
/* 116 */         } catch (IOException iOException) {
/* 117 */           logger.warning("Unexpected error", iOException);
/*     */         } 
/*     */       } 
/*     */     } else {
/* 121 */       logger.warning("Resource not found: [{0}]", new Object[] { paramString });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     map = (map != null) ? Collections.<String, Rule>unmodifiableMap(map) : Collections.<String, Rule>emptyMap();
/* 128 */     if (logger.isLoggable(PlatformLogger.Level.FINEST)) {
/* 129 */       logger.finest("result: {0}", new Object[] { toLogString(map) });
/*     */     }
/* 131 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Rule> loadRules(BufferedReader paramBufferedReader) throws IOException {
/* 140 */     LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
/*     */     String str;
/* 142 */     while ((str = paramBufferedReader.readLine()) != null) {
/* 143 */       Rule rule; str = str.split("\\s+", 2)[0];
/* 144 */       if (str.length() == 0) {
/*     */         continue;
/*     */       }
/* 147 */       if (str.startsWith("//")) {
/*     */         continue;
/*     */       }
/*     */       
/* 151 */       if (str.startsWith("!")) {
/* 152 */         str = str.substring(1);
/* 153 */         rule = Rule.EXCEPTION_RULE;
/* 154 */       } else if (str.startsWith("*.")) {
/* 155 */         str = str.substring(2);
/* 156 */         rule = Rule.WILDCARD_RULE;
/*     */       } else {
/* 158 */         rule = Rule.SIMPLE_RULE;
/*     */       } 
/*     */       try {
/* 161 */         str = IDN.toASCII(str, 1);
/* 162 */       } catch (Exception exception) {
/* 163 */         logger.warning(String.format("Error parsing rule: [%s]", new Object[] { str }), exception);
/*     */         continue;
/*     */       } 
/* 166 */       linkedHashMap.put(str, rule);
/*     */     } 
/* 168 */     return (Map)linkedHashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String toLogString(Map<String, Rule> paramMap) {
/* 176 */     if (paramMap.isEmpty()) {
/* 177 */       return "{}";
/*     */     }
/* 179 */     StringBuilder stringBuilder = new StringBuilder();
/* 180 */     for (Map.Entry<String, Rule> entry : paramMap.entrySet()) {
/* 181 */       stringBuilder.append(String.format("%n    ", new Object[0]));
/* 182 */       stringBuilder.append((String)entry.getKey());
/* 183 */       stringBuilder.append(": ");
/* 184 */       stringBuilder.append(entry.getValue());
/*     */     } 
/* 186 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\PublicSuffixes.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */