/*    */ package com.sun.javafx.iio.png;
/*    */ 
/*    */ import com.sun.javafx.iio.ImageFormatDescription;
/*    */ import com.sun.javafx.iio.ImageLoader;
/*    */ import com.sun.javafx.iio.ImageLoaderFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PNGImageLoaderFactory
/*    */   implements ImageLoaderFactory
/*    */ {
/* 36 */   private static final PNGImageLoaderFactory theInstance = new PNGImageLoaderFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final ImageLoaderFactory getInstance() {
/* 42 */     return theInstance;
/*    */   }
/*    */   
/*    */   public ImageFormatDescription getFormatDescription() {
/* 46 */     return PNGDescriptor.getInstance();
/*    */   }
/*    */   
/*    */   public ImageLoader createImageLoader(InputStream paramInputStream) throws IOException {
/* 50 */     return new PNGImageLoader2(paramInputStream);
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\iio\png\PNGImageLoaderFactory.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */