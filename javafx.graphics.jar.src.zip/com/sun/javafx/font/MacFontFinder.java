/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MacFontFinder
/*     */ {
/*     */   private static final int SystemFontType = 2;
/*     */   private static final int MonospacedFontType = 1;
/*     */   
/*     */   static {
/*  39 */     AccessController.doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_font");
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemFont() {
/*  51 */     return getFont(2);
/*     */   }
/*     */   
/*     */   public static String getMonospacedFont() {
/*  55 */     return getFont(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean populateFontFileNameMap(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale) {
/*  66 */     if (paramHashMap1 == null || paramHashMap2 == null || paramHashMap == null)
/*     */     {
/*     */       
/*  69 */       return false;
/*     */     }
/*  71 */     if (paramLocale == null) {
/*  72 */       paramLocale = Locale.ENGLISH;
/*     */     }
/*  74 */     String[] arrayOfString = getFontData();
/*  75 */     if (arrayOfString == null) return false;
/*     */     
/*  77 */     byte b = 0;
/*  78 */     while (b < arrayOfString.length) {
/*  79 */       String str1 = arrayOfString[b++];
/*  80 */       String str2 = arrayOfString[b++];
/*  81 */       String str3 = arrayOfString[b++];
/*     */       
/*  83 */       if (PrismFontFactory.debugFonts) {
/*  84 */         System.err.println("[MacFontFinder] Name=" + str1);
/*  85 */         System.err.println("\tFamily=" + str2);
/*  86 */         System.err.println("\tFile=" + str3);
/*     */       } 
/*     */       
/*  89 */       if (str1 == null || str2 == null || str3 == null) {
/*     */         continue;
/*     */       }
/*  92 */       String str4 = str1.toLowerCase(paramLocale);
/*  93 */       String str5 = str2.toLowerCase(paramLocale);
/*  94 */       paramHashMap1.put(str4, str3);
/*  95 */       paramHashMap2.put(str4, str2);
/*  96 */       ArrayList<String> arrayList = paramHashMap.get(str5);
/*  97 */       if (arrayList == null) {
/*  98 */         arrayList = new ArrayList();
/*  99 */         paramHashMap.put(str5, arrayList);
/*     */       } 
/* 101 */       arrayList.add(str1);
/*     */     } 
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   private static native String getFont(int paramInt);
/*     */   
/*     */   static native float getSystemFontSize();
/*     */   
/*     */   private static native String[] getFontData();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\font\MacFontFinder.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */