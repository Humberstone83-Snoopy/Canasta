/*    */ package com.sun.webkit;
/*    */ 
/*    */ import com.sun.javafx.logging.PlatformLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EventLoop
/*    */ {
/* 33 */   private static final PlatformLogger logger = PlatformLogger.getLogger(EventLoop.class.getName());
/*    */   
/*    */   private static EventLoop instance;
/*    */ 
/*    */   
/*    */   public static void setEventLoop(EventLoop paramEventLoop) {
/* 39 */     instance = paramEventLoop;
/*    */   }
/*    */   
/*    */   private static void fwkCycle() {
/* 43 */     logger.fine("Executing event loop cycle");
/* 44 */     instance.cycle();
/*    */   }
/*    */   
/*    */   protected abstract void cycle();
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\EventLoop.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */