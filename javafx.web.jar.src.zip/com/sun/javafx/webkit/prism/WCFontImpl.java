/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.font.CharToGlyphMapper;
/*     */ import com.sun.javafx.font.FontFactory;
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.javafx.scene.text.GlyphList;
/*     */ import com.sun.javafx.scene.text.TextLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ import com.sun.prism.GraphicsPipeline;
/*     */ import com.sun.webkit.graphics.WCFont;
/*     */ import com.sun.webkit.graphics.WCGlyphBuffer;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCFontImpl
/*     */   extends WCFont
/*     */ {
/*  49 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCFontImpl.class.getName());
/*     */   
/*  51 */   private static final HashMap<String, String> FONT_MAP = new HashMap<>();
/*     */   
/*     */   static WCFont getFont(String paramString, boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
/*  54 */     FontFactory fontFactory = GraphicsPipeline.getPipeline().getFontFactory();
/*  55 */     synchronized (FONT_MAP) {
/*  56 */       if (FONT_MAP.isEmpty()) {
/*  57 */         FONT_MAP.put("serif", "Serif");
/*  58 */         FONT_MAP.put("dialog", "SansSerif");
/*  59 */         FONT_MAP.put("helvetica", "SansSerif");
/*  60 */         FONT_MAP.put("sansserif", "SansSerif");
/*  61 */         FONT_MAP.put("sans-serif", "SansSerif");
/*  62 */         FONT_MAP.put("monospace", "Monospaced");
/*  63 */         FONT_MAP.put("monospaced", "Monospaced");
/*  64 */         for (String str1 : fontFactory.getFontFamilyNames()) {
/*  65 */           FONT_MAP.put(str1.toLowerCase(), str1);
/*     */         }
/*     */       } 
/*     */     } 
/*  69 */     String str = FONT_MAP.get(paramString.toLowerCase());
/*  70 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  71 */       StringBuilder stringBuilder = new StringBuilder("WCFontImpl.get(");
/*  72 */       stringBuilder.append(paramString).append(", ").append(paramFloat);
/*  73 */       if (paramBoolean1) {
/*  74 */         stringBuilder.append(", bold");
/*     */       }
/*  76 */       if (paramBoolean2) {
/*  77 */         stringBuilder.append(", italic");
/*     */       }
/*  79 */       log.fine(stringBuilder.append(") = ").append(str).toString());
/*     */     } 
/*  81 */     return (str != null) ? 
/*  82 */       new WCFontImpl(fontFactory.createFont(str, paramBoolean1, paramBoolean2, paramFloat)) : 
/*  83 */       null;
/*     */   }
/*     */   private final PGFont font;
/*     */   private FontStrike strike;
/*     */   
/*     */   WCFontImpl(PGFont paramPGFont) {
/*  89 */     this.font = paramPGFont;
/*     */   }
/*     */   
/*     */   public WCFont deriveFont(float paramFloat) {
/*  93 */     FontFactory fontFactory = GraphicsPipeline.getPipeline().getFontFactory();
/*  94 */     return new WCFontImpl(fontFactory
/*  95 */         .deriveFont(this.font, this.font
/*  96 */           .getFontResource().isBold(), this.font
/*  97 */           .getFontResource().isItalic(), paramFloat));
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOffsetForPosition(String paramString, float paramFloat) {
/* 102 */     TextLayout textLayout = TextUtilities.createLayout(paramString, this.font);
/* 103 */     GlyphList[] arrayOfGlyphList = textLayout.getRuns();
/* 104 */     TextRun textRun = (TextRun)arrayOfGlyphList[0];
/* 105 */     int i = textRun.getOffsetAtX(paramFloat, null);
/* 106 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 107 */       log.fine(String.format("str='%s' (length=%d), x=%.2f => %d", new Object[] { paramString, 
/* 108 */               Integer.valueOf(paramString.length()), Float.valueOf(paramFloat), Integer.valueOf(i) }));
/*     */     }
/* 110 */     return i;
/*     */   }
/*     */   
/*     */   public WCGlyphBuffer getGlyphsAndAdvances(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 114 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 115 */       log.fine(String.format("str='%s' (length=%d), from=%d, to=%d, rtl=%b", new Object[] { paramString, 
/*     */               
/* 117 */               Integer.valueOf(paramString.length()), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }));
/*     */     }
/* 119 */     TextLayout textLayout = TextUtilities.createLayout(paramString
/* 120 */         .substring(paramInt1, paramInt2), getPlatformFont());
/* 121 */     int i = 0;
/* 122 */     GlyphList[] arrayOfGlyphList = textLayout.getRuns();
/* 123 */     for (GlyphList glyphList : arrayOfGlyphList) {
/* 124 */       i += glyphList.getGlyphCount();
/*     */     }
/*     */     
/* 127 */     int[] arrayOfInt = new int[i];
/* 128 */     float[] arrayOfFloat = new float[i];
/* 129 */     i = 0;
/* 130 */     for (GlyphList glyphList : textLayout.getRuns()) {
/* 131 */       int j = glyphList.getGlyphCount();
/* 132 */       for (byte b = 0; b < j; b++) {
/* 133 */         arrayOfInt[i] = glyphList.getGlyphCode(b);
/* 134 */         arrayOfFloat[i] = glyphList.getPosX(b + 1) - glyphList.getPosX(b);
/* 135 */         i++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 140 */     float f = 0.0F;
/* 141 */     if (paramBoolean) {
/* 142 */       f += TextUtilities.getLayoutWidth(paramString.substring(paramInt1), getPlatformFont()) - textLayout
/* 143 */         .getBounds().getWidth();
/*     */     } else {
/* 145 */       f += TextUtilities.getLayoutWidth(paramString.substring(0, paramInt1), getPlatformFont());
/*     */     } 
/* 147 */     return new WCGlyphBuffer(arrayOfInt, arrayOfFloat, f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private FontStrike getFontStrike() {
/* 153 */     if (this.strike == null) {
/* 154 */       this.strike = this.font.getStrike(BaseTransform.IDENTITY_TRANSFORM, 1);
/*     */     }
/* 156 */     return this.strike;
/*     */   }
/*     */   
/*     */   public double getGlyphWidth(int paramInt) {
/* 160 */     return getFontStrike().getFontResource().getAdvance(paramInt, this.font.getSize());
/*     */   }
/*     */   
/*     */   public float[] getGlyphBoundingBox(int paramInt) {
/* 164 */     float[] arrayOfFloat = new float[4];
/* 165 */     arrayOfFloat = getFontStrike().getFontResource().getGlyphBoundingBox(paramInt, this.font.getSize(), arrayOfFloat);
/* 166 */     return new float[] { arrayOfFloat[0], -arrayOfFloat[3], arrayOfFloat[2], arrayOfFloat[3] - arrayOfFloat[1] };
/*     */   }
/*     */   
/*     */   public float getXHeight() {
/* 170 */     return getFontStrike().getMetrics().getXHeight();
/*     */   }
/*     */   
/*     */   public int[] getGlyphCodes(char[] paramArrayOfchar) {
/* 174 */     int[] arrayOfInt = new int[paramArrayOfchar.length];
/* 175 */     CharToGlyphMapper charToGlyphMapper = getFontStrike().getFontResource().getGlyphMapper();
/* 176 */     charToGlyphMapper.charsToGlyphs(paramArrayOfchar.length, paramArrayOfchar, arrayOfInt);
/* 177 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   public double getStringWidth(String paramString) {
/* 181 */     double d = TextUtilities.getLayoutWidth(paramString, this.font);
/* 182 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 183 */       log.fine(String.format("str='%s' (length=%d) => %.1f", new Object[] { paramString, 
/* 184 */               Integer.valueOf(paramString.length()), Double.valueOf(d) }));
/*     */     }
/* 186 */     return d;
/*     */   }
/*     */   
/*     */   public double[] getStringBounds(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 190 */     float f = TextUtilities.getLayoutWidth(paramString.substring(0, paramInt1), this.font);
/* 191 */     BaseBounds baseBounds = TextUtilities.getLayoutBounds(paramString.substring(0, paramInt2), this.font);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     double[] arrayOfDouble = { f, 0.0D, (baseBounds.getWidth() - f), baseBounds.getHeight() };
/*     */     
/* 198 */     if (paramBoolean) {
/* 199 */       float f1 = TextUtilities.getLayoutWidth(paramString, this.font);
/* 200 */       arrayOfDouble[0] = (f1 - baseBounds.getWidth());
/*     */     } 
/* 202 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 203 */       log.fine(String.format("str='%s' (length=%d) [%d, %d], rtl=%b => [%.1f, %.1f + %.1f x %.1f]", new Object[] { paramString, 
/*     */               
/* 205 */               Integer.valueOf(paramString.length()), Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean), 
/* 206 */               Double.valueOf(arrayOfDouble[0]), Double.valueOf(arrayOfDouble[1]), Double.valueOf(arrayOfDouble[2]), Double.valueOf(arrayOfDouble[3]) }));
/*     */     }
/* 208 */     return arrayOfDouble;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAscent() {
/* 213 */     float f = -getFontStrike().getMetrics().getAscent();
/* 214 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/* 215 */       log.finer("getAscent({0}, {1}) = {2}", new Object[] { this.font
/* 216 */             .getName(), Float.valueOf(this.font.getSize()), 
/* 217 */             Float.valueOf(f) });
/*     */     }
/* 219 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getDescent() {
/* 224 */     float f = getFontStrike().getMetrics().getDescent();
/* 225 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/* 226 */       log.finer("getDescent({0}, {1}) = {2}", new Object[] { this.font
/* 227 */             .getName(), Float.valueOf(this.font.getSize()), 
/* 228 */             Float.valueOf(f) });
/*     */     }
/* 230 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getLineSpacing() {
/* 235 */     float f = getFontStrike().getMetrics().getLineHeight();
/* 236 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/* 237 */       log.finer("getLineSpacing({0}, {1}) = {2}", new Object[] { this.font
/* 238 */             .getName(), Float.valueOf(this.font.getSize()), 
/* 239 */             Float.valueOf(f) });
/*     */     }
/* 241 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getLineGap() {
/* 246 */     float f = getFontStrike().getMetrics().getLineGap();
/* 247 */     if (log.isLoggable(PlatformLogger.Level.FINER)) {
/* 248 */       log.finer("getLineGap({0}, {1}) = {2}", new Object[] { this.font
/* 249 */             .getName(), Float.valueOf(this.font.getSize()), 
/* 250 */             Float.valueOf(f) });
/*     */     }
/* 252 */     return f;
/*     */   }
/*     */   
/*     */   public boolean hasUniformLineMetrics() {
/* 256 */     return false;
/*     */   }
/*     */   
/*     */   public Object getPlatformFont() {
/* 260 */     return this.font;
/*     */   }
/*     */   
/*     */   public float getCapHeight() {
/* 264 */     return getFontStrike().getMetrics().getCapHeight();
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCFontImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */