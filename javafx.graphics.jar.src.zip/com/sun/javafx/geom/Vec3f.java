/*     */ package com.sun.javafx.geom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Vec3f
/*     */ {
/*     */   public float x;
/*     */   public float y;
/*     */   public float z;
/*     */   
/*     */   public Vec3f() {}
/*     */   
/*     */   public Vec3f(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  51 */     this.x = paramFloat1;
/*  52 */     this.y = paramFloat2;
/*  53 */     this.z = paramFloat3;
/*     */   }
/*     */   
/*     */   public Vec3f(Vec3f paramVec3f) {
/*  57 */     this.x = paramVec3f.x;
/*  58 */     this.y = paramVec3f.y;
/*  59 */     this.z = paramVec3f.z;
/*     */   }
/*     */   
/*     */   public void set(Vec3f paramVec3f) {
/*  63 */     this.x = paramVec3f.x;
/*  64 */     this.y = paramVec3f.y;
/*  65 */     this.z = paramVec3f.z;
/*     */   }
/*     */   
/*     */   public void set(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  69 */     this.x = paramFloat1;
/*  70 */     this.y = paramFloat2;
/*  71 */     this.z = paramFloat3;
/*     */   }
/*     */   
/*     */   public final void mul(float paramFloat) {
/*  75 */     this.x *= paramFloat;
/*  76 */     this.y *= paramFloat;
/*  77 */     this.z *= paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sub(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/*  87 */     paramVec3f1.x -= paramVec3f2.x;
/*  88 */     paramVec3f1.y -= paramVec3f2.y;
/*  89 */     paramVec3f1.z -= paramVec3f2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sub(Vec3f paramVec3f) {
/*  98 */     this.x -= paramVec3f.x;
/*  99 */     this.y -= paramVec3f.y;
/* 100 */     this.z -= paramVec3f.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/* 110 */     paramVec3f1.x += paramVec3f2.x;
/* 111 */     paramVec3f1.y += paramVec3f2.y;
/* 112 */     paramVec3f1.z += paramVec3f2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Vec3f paramVec3f) {
/* 121 */     this.x += paramVec3f.x;
/* 122 */     this.y += paramVec3f.y;
/* 123 */     this.z += paramVec3f.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float length() {
/* 131 */     return (float)Math.sqrt((this.x * this.x + this.y * this.y + this.z * this.z));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void normalize() {
/* 138 */     float f = 1.0F / length();
/* 139 */     this.x *= f;
/* 140 */     this.y *= f;
/* 141 */     this.z *= f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cross(Vec3f paramVec3f1, Vec3f paramVec3f2) {
/* 153 */     float f1 = paramVec3f1.y * paramVec3f2.z - paramVec3f1.z * paramVec3f2.y;
/* 154 */     float f2 = paramVec3f2.x * paramVec3f1.z - paramVec3f2.z * paramVec3f1.x;
/* 155 */     this.z = paramVec3f1.x * paramVec3f2.y - paramVec3f1.y * paramVec3f2.x;
/* 156 */     this.x = f1;
/* 157 */     this.y = f2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float dot(Vec3f paramVec3f) {
/* 166 */     return this.x * paramVec3f.x + this.y * paramVec3f.y + this.z * paramVec3f.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 175 */     int i = 7;
/* 176 */     i = 31 * i + Float.floatToIntBits(this.x);
/* 177 */     i = 31 * i + Float.floatToIntBits(this.y);
/* 178 */     i = 31 * i + Float.floatToIntBits(this.z);
/* 179 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 194 */     if (paramObject == this) {
/* 195 */       return true;
/*     */     }
/* 197 */     if (paramObject instanceof Vec3f) {
/* 198 */       Vec3f vec3f = (Vec3f)paramObject;
/* 199 */       return (this.x == vec3f.x && this.y == vec3f.y && this.z == vec3f.z);
/*     */     } 
/* 201 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 211 */     return "Vec3f[" + this.x + ", " + this.y + ", " + this.z + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\geom\Vec3f.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */