/*      */ package com.sun.webkit.dom;
/*      */ 
/*      */ import com.sun.webkit.Disposer;
/*      */ import netscape.javascript.JSException;
/*      */ import org.w3c.dom.DOMException;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.css.CSSStyleDeclaration;
/*      */ import org.w3c.dom.events.Event;
/*      */ import org.w3c.dom.events.EventListener;
/*      */ import org.w3c.dom.events.EventTarget;
/*      */ import org.w3c.dom.views.AbstractView;
/*      */ import org.w3c.dom.views.DocumentView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DOMWindowImpl
/*      */   extends JSObject
/*      */   implements AbstractView, EventTarget
/*      */ {
/*   46 */   private static SelfDisposer[] hashTable = new SelfDisposer[64];
/*      */   private static int hashCount;
/*      */   
/*      */   private static int hashPeer(long paramLong) {
/*   50 */     return (int)(paramLong ^ 0xFFFFFFFFFFFFFFFFL ^ paramLong >> 7L) & hashTable.length - 1;
/*      */   }
/*      */   
/*      */   private static AbstractView getCachedImpl(long paramLong) {
/*   54 */     if (paramLong == 0L)
/*   55 */       return null; 
/*   56 */     int i = hashPeer(paramLong);
/*   57 */     SelfDisposer selfDisposer1 = hashTable[i];
/*   58 */     SelfDisposer selfDisposer2 = null;
/*   59 */     for (SelfDisposer selfDisposer3 = selfDisposer1; selfDisposer3 != null; ) {
/*   60 */       SelfDisposer selfDisposer = selfDisposer3.next;
/*   61 */       if (selfDisposer3.peer == paramLong) {
/*   62 */         DOMWindowImpl dOMWindowImpl1 = (DOMWindowImpl)selfDisposer3.get();
/*   63 */         if (dOMWindowImpl1 != null) {
/*      */           
/*   65 */           dispose(paramLong);
/*   66 */           return dOMWindowImpl1;
/*      */         } 
/*   68 */         if (selfDisposer2 != null) {
/*   69 */           selfDisposer2.next = selfDisposer; break;
/*      */         } 
/*   71 */         hashTable[i] = selfDisposer;
/*      */         break;
/*      */       } 
/*   74 */       selfDisposer2 = selfDisposer3;
/*   75 */       selfDisposer3 = selfDisposer;
/*      */     } 
/*   77 */     DOMWindowImpl dOMWindowImpl = (DOMWindowImpl)createInterface(paramLong);
/*   78 */     SelfDisposer selfDisposer4 = new SelfDisposer(dOMWindowImpl, paramLong);
/*   79 */     Disposer.addRecord(selfDisposer4);
/*   80 */     selfDisposer4.next = selfDisposer1;
/*   81 */     hashTable[i] = selfDisposer4;
/*   82 */     if (3 * hashCount >= 2 * hashTable.length)
/*   83 */       rehash(); 
/*   84 */     hashCount++;
/*   85 */     return dOMWindowImpl;
/*      */   }
/*      */   
/*      */   static int test_getHashCount() {
/*   89 */     return hashCount;
/*      */   }
/*      */   
/*      */   private static void rehash() {
/*   93 */     SelfDisposer[] arrayOfSelfDisposer1 = hashTable;
/*   94 */     int i = arrayOfSelfDisposer1.length;
/*   95 */     SelfDisposer[] arrayOfSelfDisposer2 = new SelfDisposer[2 * i];
/*   96 */     hashTable = arrayOfSelfDisposer2;
/*   97 */     for (int j = i; --j >= 0; ) {
/*   98 */       SelfDisposer selfDisposer = arrayOfSelfDisposer1[j];
/*   99 */       while (selfDisposer != null) {
/*  100 */         SelfDisposer selfDisposer1 = selfDisposer.next;
/*  101 */         int k = hashPeer(selfDisposer.peer);
/*  102 */         selfDisposer.next = arrayOfSelfDisposer2[k];
/*  103 */         arrayOfSelfDisposer2[k] = selfDisposer;
/*  104 */         selfDisposer = selfDisposer1;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final class SelfDisposer extends Disposer.WeakDisposerRecord { private final long peer;
/*      */     SelfDisposer next;
/*      */     
/*      */     SelfDisposer(Object param1Object, long param1Long) {
/*  113 */       super(param1Object);
/*  114 */       this.peer = param1Long;
/*      */     }
/*      */     
/*      */     public void dispose() {
/*  118 */       int i = DOMWindowImpl.hashPeer(this.peer);
/*  119 */       SelfDisposer selfDisposer1 = DOMWindowImpl.hashTable[i];
/*  120 */       SelfDisposer selfDisposer2 = null;
/*  121 */       for (SelfDisposer selfDisposer3 = selfDisposer1; selfDisposer3 != null; ) {
/*  122 */         SelfDisposer selfDisposer = selfDisposer3.next;
/*  123 */         if (selfDisposer3.peer == this.peer) {
/*  124 */           selfDisposer3.clear();
/*  125 */           if (selfDisposer2 != null) {
/*  126 */             selfDisposer2.next = selfDisposer;
/*      */           } else {
/*  128 */             DOMWindowImpl.hashTable[i] = selfDisposer;
/*      */           }  DOMWindowImpl.hashCount--;
/*      */           break;
/*      */         } 
/*  132 */         selfDisposer2 = selfDisposer3;
/*  133 */         selfDisposer3 = selfDisposer;
/*      */       } 
/*  135 */       DOMWindowImpl.dispose(this.peer);
/*      */     } }
/*      */ 
/*      */   
/*      */   DOMWindowImpl(long paramLong) {
/*  140 */     super(paramLong, 2);
/*      */   }
/*      */   
/*      */   static AbstractView createInterface(long paramLong) {
/*  144 */     if (paramLong == 0L) return null; 
/*  145 */     return new DOMWindowImpl(paramLong);
/*      */   }
/*      */   
/*      */   static AbstractView create(long paramLong) {
/*  149 */     return getCachedImpl(paramLong);
/*      */   }
/*      */   
/*      */   static long getPeer(AbstractView paramAbstractView) {
/*  153 */     return (paramAbstractView == null) ? 0L : ((DOMWindowImpl)paramAbstractView).getPeer();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static AbstractView getImpl(long paramLong) {
/*  159 */     return create(paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Element getFrameElement() {
/*  165 */     return ElementImpl.getImpl(getFrameElementImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getOffscreenBuffering() {
/*  170 */     return getOffscreenBufferingImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOuterHeight() {
/*  175 */     return getOuterHeightImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOuterWidth() {
/*  180 */     return getOuterWidthImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInnerHeight() {
/*  185 */     return getInnerHeightImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInnerWidth() {
/*  190 */     return getInnerWidthImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScreenX() {
/*  195 */     return getScreenXImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScreenY() {
/*  200 */     return getScreenYImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScreenLeft() {
/*  205 */     return getScreenLeftImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScreenTop() {
/*  210 */     return getScreenTopImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScrollX() {
/*  215 */     return getScrollXImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getScrollY() {
/*  220 */     return getScrollYImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPageXOffset() {
/*  225 */     return getPageXOffsetImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPageYOffset() {
/*  230 */     return getPageYOffsetImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getClosed() {
/*  235 */     return getClosedImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLength() {
/*  240 */     return getLengthImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public String getName() {
/*  245 */     return getNameImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setName(String paramString) {
/*  250 */     setNameImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStatus() {
/*  255 */     return getStatusImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setStatus(String paramString) {
/*  260 */     setStatusImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDefaultStatus() {
/*  265 */     return getDefaultStatusImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDefaultStatus(String paramString) {
/*  270 */     setDefaultStatusImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getSelf() {
/*  275 */     return getImpl(getSelfImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getWindow() {
/*  280 */     return getImpl(getWindowImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getFrames() {
/*  285 */     return getImpl(getFramesImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getOpener() {
/*  290 */     return getImpl(getOpenerImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getParent() {
/*  295 */     return getImpl(getParentImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public AbstractView getTop() {
/*  300 */     return getImpl(getTopImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public Document getDocumentEx() {
/*  305 */     return DocumentImpl.getImpl(getDocumentExImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDevicePixelRatio() {
/*  310 */     return getDevicePixelRatioImpl(getPeer());
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnanimationend() {
/*  315 */     return EventListenerImpl.getImpl(getOnanimationendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnanimationend(EventListener paramEventListener) {
/*  320 */     setOnanimationendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnanimationiteration() {
/*  325 */     return EventListenerImpl.getImpl(getOnanimationiterationImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnanimationiteration(EventListener paramEventListener) {
/*  330 */     setOnanimationiterationImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnanimationstart() {
/*  335 */     return EventListenerImpl.getImpl(getOnanimationstartImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnanimationstart(EventListener paramEventListener) {
/*  340 */     setOnanimationstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOntransitionend() {
/*  345 */     return EventListenerImpl.getImpl(getOntransitionendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOntransitionend(EventListener paramEventListener) {
/*  350 */     setOntransitionendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwebkitanimationend() {
/*  355 */     return EventListenerImpl.getImpl(getOnwebkitanimationendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwebkitanimationend(EventListener paramEventListener) {
/*  360 */     setOnwebkitanimationendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwebkitanimationiteration() {
/*  365 */     return EventListenerImpl.getImpl(getOnwebkitanimationiterationImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwebkitanimationiteration(EventListener paramEventListener) {
/*  370 */     setOnwebkitanimationiterationImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwebkitanimationstart() {
/*  375 */     return EventListenerImpl.getImpl(getOnwebkitanimationstartImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwebkitanimationstart(EventListener paramEventListener) {
/*  380 */     setOnwebkitanimationstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwebkittransitionend() {
/*  385 */     return EventListenerImpl.getImpl(getOnwebkittransitionendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwebkittransitionend(EventListener paramEventListener) {
/*  390 */     setOnwebkittransitionendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnabort() {
/*  395 */     return EventListenerImpl.getImpl(getOnabortImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnabort(EventListener paramEventListener) {
/*  400 */     setOnabortImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnblur() {
/*  405 */     return EventListenerImpl.getImpl(getOnblurImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnblur(EventListener paramEventListener) {
/*  410 */     setOnblurImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOncanplay() {
/*  415 */     return EventListenerImpl.getImpl(getOncanplayImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOncanplay(EventListener paramEventListener) {
/*  420 */     setOncanplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOncanplaythrough() {
/*  425 */     return EventListenerImpl.getImpl(getOncanplaythroughImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOncanplaythrough(EventListener paramEventListener) {
/*  430 */     setOncanplaythroughImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnchange() {
/*  435 */     return EventListenerImpl.getImpl(getOnchangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnchange(EventListener paramEventListener) {
/*  440 */     setOnchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnclick() {
/*  445 */     return EventListenerImpl.getImpl(getOnclickImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnclick(EventListener paramEventListener) {
/*  450 */     setOnclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOncontextmenu() {
/*  455 */     return EventListenerImpl.getImpl(getOncontextmenuImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOncontextmenu(EventListener paramEventListener) {
/*  460 */     setOncontextmenuImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndblclick() {
/*  465 */     return EventListenerImpl.getImpl(getOndblclickImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndblclick(EventListener paramEventListener) {
/*  470 */     setOndblclickImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndrag() {
/*  475 */     return EventListenerImpl.getImpl(getOndragImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndrag(EventListener paramEventListener) {
/*  480 */     setOndragImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndragend() {
/*  485 */     return EventListenerImpl.getImpl(getOndragendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndragend(EventListener paramEventListener) {
/*  490 */     setOndragendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndragenter() {
/*  495 */     return EventListenerImpl.getImpl(getOndragenterImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndragenter(EventListener paramEventListener) {
/*  500 */     setOndragenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndragleave() {
/*  505 */     return EventListenerImpl.getImpl(getOndragleaveImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndragleave(EventListener paramEventListener) {
/*  510 */     setOndragleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndragover() {
/*  515 */     return EventListenerImpl.getImpl(getOndragoverImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndragover(EventListener paramEventListener) {
/*  520 */     setOndragoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndragstart() {
/*  525 */     return EventListenerImpl.getImpl(getOndragstartImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndragstart(EventListener paramEventListener) {
/*  530 */     setOndragstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndrop() {
/*  535 */     return EventListenerImpl.getImpl(getOndropImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndrop(EventListener paramEventListener) {
/*  540 */     setOndropImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOndurationchange() {
/*  545 */     return EventListenerImpl.getImpl(getOndurationchangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOndurationchange(EventListener paramEventListener) {
/*  550 */     setOndurationchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnemptied() {
/*  555 */     return EventListenerImpl.getImpl(getOnemptiedImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnemptied(EventListener paramEventListener) {
/*  560 */     setOnemptiedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnended() {
/*  565 */     return EventListenerImpl.getImpl(getOnendedImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnended(EventListener paramEventListener) {
/*  570 */     setOnendedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnerror() {
/*  575 */     return EventListenerImpl.getImpl(getOnerrorImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnerror(EventListener paramEventListener) {
/*  580 */     setOnerrorImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnfocus() {
/*  585 */     return EventListenerImpl.getImpl(getOnfocusImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnfocus(EventListener paramEventListener) {
/*  590 */     setOnfocusImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOninput() {
/*  595 */     return EventListenerImpl.getImpl(getOninputImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOninput(EventListener paramEventListener) {
/*  600 */     setOninputImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOninvalid() {
/*  605 */     return EventListenerImpl.getImpl(getOninvalidImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOninvalid(EventListener paramEventListener) {
/*  610 */     setOninvalidImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnkeydown() {
/*  615 */     return EventListenerImpl.getImpl(getOnkeydownImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnkeydown(EventListener paramEventListener) {
/*  620 */     setOnkeydownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnkeypress() {
/*  625 */     return EventListenerImpl.getImpl(getOnkeypressImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnkeypress(EventListener paramEventListener) {
/*  630 */     setOnkeypressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnkeyup() {
/*  635 */     return EventListenerImpl.getImpl(getOnkeyupImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnkeyup(EventListener paramEventListener) {
/*  640 */     setOnkeyupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnload() {
/*  645 */     return EventListenerImpl.getImpl(getOnloadImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnload(EventListener paramEventListener) {
/*  650 */     setOnloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnloadeddata() {
/*  655 */     return EventListenerImpl.getImpl(getOnloadeddataImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnloadeddata(EventListener paramEventListener) {
/*  660 */     setOnloadeddataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnloadedmetadata() {
/*  665 */     return EventListenerImpl.getImpl(getOnloadedmetadataImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnloadedmetadata(EventListener paramEventListener) {
/*  670 */     setOnloadedmetadataImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnloadstart() {
/*  675 */     return EventListenerImpl.getImpl(getOnloadstartImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnloadstart(EventListener paramEventListener) {
/*  680 */     setOnloadstartImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmousedown() {
/*  685 */     return EventListenerImpl.getImpl(getOnmousedownImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmousedown(EventListener paramEventListener) {
/*  690 */     setOnmousedownImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmouseenter() {
/*  695 */     return EventListenerImpl.getImpl(getOnmouseenterImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmouseenter(EventListener paramEventListener) {
/*  700 */     setOnmouseenterImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmouseleave() {
/*  705 */     return EventListenerImpl.getImpl(getOnmouseleaveImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmouseleave(EventListener paramEventListener) {
/*  710 */     setOnmouseleaveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmousemove() {
/*  715 */     return EventListenerImpl.getImpl(getOnmousemoveImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmousemove(EventListener paramEventListener) {
/*  720 */     setOnmousemoveImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmouseout() {
/*  725 */     return EventListenerImpl.getImpl(getOnmouseoutImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmouseout(EventListener paramEventListener) {
/*  730 */     setOnmouseoutImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmouseover() {
/*  735 */     return EventListenerImpl.getImpl(getOnmouseoverImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmouseover(EventListener paramEventListener) {
/*  740 */     setOnmouseoverImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmouseup() {
/*  745 */     return EventListenerImpl.getImpl(getOnmouseupImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmouseup(EventListener paramEventListener) {
/*  750 */     setOnmouseupImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmousewheel() {
/*  755 */     return EventListenerImpl.getImpl(getOnmousewheelImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmousewheel(EventListener paramEventListener) {
/*  760 */     setOnmousewheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnpause() {
/*  765 */     return EventListenerImpl.getImpl(getOnpauseImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnpause(EventListener paramEventListener) {
/*  770 */     setOnpauseImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnplay() {
/*  775 */     return EventListenerImpl.getImpl(getOnplayImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnplay(EventListener paramEventListener) {
/*  780 */     setOnplayImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnplaying() {
/*  785 */     return EventListenerImpl.getImpl(getOnplayingImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnplaying(EventListener paramEventListener) {
/*  790 */     setOnplayingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnprogress() {
/*  795 */     return EventListenerImpl.getImpl(getOnprogressImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnprogress(EventListener paramEventListener) {
/*  800 */     setOnprogressImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnratechange() {
/*  805 */     return EventListenerImpl.getImpl(getOnratechangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnratechange(EventListener paramEventListener) {
/*  810 */     setOnratechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnreset() {
/*  815 */     return EventListenerImpl.getImpl(getOnresetImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnreset(EventListener paramEventListener) {
/*  820 */     setOnresetImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnresize() {
/*  825 */     return EventListenerImpl.getImpl(getOnresizeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnresize(EventListener paramEventListener) {
/*  830 */     setOnresizeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnscroll() {
/*  835 */     return EventListenerImpl.getImpl(getOnscrollImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnscroll(EventListener paramEventListener) {
/*  840 */     setOnscrollImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnseeked() {
/*  845 */     return EventListenerImpl.getImpl(getOnseekedImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnseeked(EventListener paramEventListener) {
/*  850 */     setOnseekedImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnseeking() {
/*  855 */     return EventListenerImpl.getImpl(getOnseekingImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnseeking(EventListener paramEventListener) {
/*  860 */     setOnseekingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnselect() {
/*  865 */     return EventListenerImpl.getImpl(getOnselectImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnselect(EventListener paramEventListener) {
/*  870 */     setOnselectImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnstalled() {
/*  875 */     return EventListenerImpl.getImpl(getOnstalledImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnstalled(EventListener paramEventListener) {
/*  880 */     setOnstalledImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnsubmit() {
/*  885 */     return EventListenerImpl.getImpl(getOnsubmitImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnsubmit(EventListener paramEventListener) {
/*  890 */     setOnsubmitImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnsuspend() {
/*  895 */     return EventListenerImpl.getImpl(getOnsuspendImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnsuspend(EventListener paramEventListener) {
/*  900 */     setOnsuspendImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOntimeupdate() {
/*  905 */     return EventListenerImpl.getImpl(getOntimeupdateImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOntimeupdate(EventListener paramEventListener) {
/*  910 */     setOntimeupdateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnvolumechange() {
/*  915 */     return EventListenerImpl.getImpl(getOnvolumechangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnvolumechange(EventListener paramEventListener) {
/*  920 */     setOnvolumechangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwaiting() {
/*  925 */     return EventListenerImpl.getImpl(getOnwaitingImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwaiting(EventListener paramEventListener) {
/*  930 */     setOnwaitingImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnsearch() {
/*  935 */     return EventListenerImpl.getImpl(getOnsearchImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnsearch(EventListener paramEventListener) {
/*  940 */     setOnsearchImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnwheel() {
/*  945 */     return EventListenerImpl.getImpl(getOnwheelImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnwheel(EventListener paramEventListener) {
/*  950 */     setOnwheelImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnbeforeunload() {
/*  955 */     return EventListenerImpl.getImpl(getOnbeforeunloadImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnbeforeunload(EventListener paramEventListener) {
/*  960 */     setOnbeforeunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnhashchange() {
/*  965 */     return EventListenerImpl.getImpl(getOnhashchangeImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnhashchange(EventListener paramEventListener) {
/*  970 */     setOnhashchangeImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnmessage() {
/*  975 */     return EventListenerImpl.getImpl(getOnmessageImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnmessage(EventListener paramEventListener) {
/*  980 */     setOnmessageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnoffline() {
/*  985 */     return EventListenerImpl.getImpl(getOnofflineImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnoffline(EventListener paramEventListener) {
/*  990 */     setOnofflineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnonline() {
/*  995 */     return EventListenerImpl.getImpl(getOnonlineImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnonline(EventListener paramEventListener) {
/* 1000 */     setOnonlineImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnpagehide() {
/* 1005 */     return EventListenerImpl.getImpl(getOnpagehideImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnpagehide(EventListener paramEventListener) {
/* 1010 */     setOnpagehideImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnpageshow() {
/* 1015 */     return EventListenerImpl.getImpl(getOnpageshowImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnpageshow(EventListener paramEventListener) {
/* 1020 */     setOnpageshowImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnpopstate() {
/* 1025 */     return EventListenerImpl.getImpl(getOnpopstateImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnpopstate(EventListener paramEventListener) {
/* 1030 */     setOnpopstateImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnstorage() {
/* 1035 */     return EventListenerImpl.getImpl(getOnstorageImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnstorage(EventListener paramEventListener) {
/* 1040 */     setOnstorageImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */   
/*      */   public EventListener getOnunload() {
/* 1045 */     return EventListenerImpl.getImpl(getOnunloadImpl(getPeer()));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOnunload(EventListener paramEventListener) {
/* 1050 */     setOnunloadImpl(getPeer(), EventListenerImpl.getPeer(paramEventListener));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DOMSelectionImpl getSelection() {
/* 1058 */     return DOMSelectionImpl.getImpl(getSelectionImpl(getPeer()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void focus() {
/* 1065 */     focusImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void blur() {
/* 1072 */     blurImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/* 1079 */     closeImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void print() {
/* 1086 */     printImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/* 1093 */     stopImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void alert(String paramString) {
/* 1100 */     alertImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean confirm(String paramString) {
/* 1109 */     return confirmImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String prompt(String paramString1, String paramString2) {
/* 1119 */     return promptImpl(getPeer(), paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean find(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6) {
/* 1136 */     return findImpl(getPeer(), paramString, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, paramBoolean6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scrollBy(int paramInt1, int paramInt2) {
/* 1158 */     scrollByImpl(getPeer(), paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scrollTo(int paramInt1, int paramInt2) {
/* 1170 */     scrollToImpl(getPeer(), paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scroll(int paramInt1, int paramInt2) {
/* 1182 */     scrollImpl(getPeer(), paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveBy(float paramFloat1, float paramFloat2) {
/* 1194 */     moveByImpl(getPeer(), paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveTo(float paramFloat1, float paramFloat2) {
/* 1206 */     moveToImpl(getPeer(), paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resizeBy(float paramFloat1, float paramFloat2) {
/* 1218 */     resizeByImpl(getPeer(), paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resizeTo(float paramFloat1, float paramFloat2) {
/* 1230 */     resizeToImpl(getPeer(), paramFloat1, paramFloat2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CSSStyleDeclaration getComputedStyle(Element paramElement, String paramString) {
/* 1242 */     return CSSStyleDeclarationImpl.getImpl(getComputedStyleImpl(getPeer(), 
/* 1243 */           ElementImpl.getPeer(paramElement), paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void captureEvents() {
/* 1253 */     captureEventsImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseEvents() {
/* 1260 */     releaseEventsImpl(getPeer());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/* 1269 */     addEventListenerImpl(getPeer(), paramString, 
/*      */         
/* 1271 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeEventListener(String paramString, EventListener paramEventListener, boolean paramBoolean) {
/* 1284 */     removeEventListenerImpl(getPeer(), paramString, 
/*      */         
/* 1286 */         EventListenerImpl.getPeer(paramEventListener), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean dispatchEvent(Event paramEvent) throws DOMException {
/* 1297 */     return dispatchEventImpl(getPeer(), 
/* 1298 */         EventImpl.getPeer(paramEvent));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String atob(String paramString) throws DOMException {
/* 1306 */     return atobImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String btoa(String paramString) throws DOMException {
/* 1315 */     return btoaImpl(getPeer(), paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearTimeout(int paramInt) {
/* 1324 */     clearTimeoutImpl(getPeer(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearInterval(int paramInt) {
/* 1333 */     clearIntervalImpl(getPeer(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DocumentView getDocument() {
/* 1343 */     throw new UnsupportedOperationException("Not supported yet.");
/*      */   }
/*      */   
/*      */   private static native void dispose(long paramLong);
/*      */   
/*      */   static native long getFrameElementImpl(long paramLong);
/*      */   
/*      */   static native boolean getOffscreenBufferingImpl(long paramLong);
/*      */   
/*      */   static native int getOuterHeightImpl(long paramLong);
/*      */   
/*      */   static native int getOuterWidthImpl(long paramLong);
/*      */   
/*      */   static native int getInnerHeightImpl(long paramLong);
/*      */   
/*      */   static native int getInnerWidthImpl(long paramLong);
/*      */   
/*      */   static native int getScreenXImpl(long paramLong);
/*      */   
/*      */   static native int getScreenYImpl(long paramLong);
/*      */   
/*      */   static native int getScreenLeftImpl(long paramLong);
/*      */   
/*      */   static native int getScreenTopImpl(long paramLong);
/*      */   
/*      */   static native int getScrollXImpl(long paramLong);
/*      */   
/*      */   static native int getScrollYImpl(long paramLong);
/*      */   
/*      */   static native int getPageXOffsetImpl(long paramLong);
/*      */   
/*      */   static native int getPageYOffsetImpl(long paramLong);
/*      */   
/*      */   static native boolean getClosedImpl(long paramLong);
/*      */   
/*      */   static native int getLengthImpl(long paramLong);
/*      */   
/*      */   static native String getNameImpl(long paramLong);
/*      */   
/*      */   static native void setNameImpl(long paramLong, String paramString);
/*      */   
/*      */   static native String getStatusImpl(long paramLong);
/*      */   
/*      */   static native void setStatusImpl(long paramLong, String paramString);
/*      */   
/*      */   static native String getDefaultStatusImpl(long paramLong);
/*      */   
/*      */   static native void setDefaultStatusImpl(long paramLong, String paramString);
/*      */   
/*      */   static native long getSelfImpl(long paramLong);
/*      */   
/*      */   static native long getWindowImpl(long paramLong);
/*      */   
/*      */   static native long getFramesImpl(long paramLong);
/*      */   
/*      */   static native long getOpenerImpl(long paramLong);
/*      */   
/*      */   static native long getParentImpl(long paramLong);
/*      */   
/*      */   static native long getTopImpl(long paramLong);
/*      */   
/*      */   static native long getDocumentExImpl(long paramLong);
/*      */   
/*      */   static native double getDevicePixelRatioImpl(long paramLong);
/*      */   
/*      */   static native long getOnanimationendImpl(long paramLong);
/*      */   
/*      */   static native void setOnanimationendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnanimationiterationImpl(long paramLong);
/*      */   
/*      */   static native void setOnanimationiterationImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnanimationstartImpl(long paramLong);
/*      */   
/*      */   static native void setOnanimationstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOntransitionendImpl(long paramLong);
/*      */   
/*      */   static native void setOntransitionendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwebkitanimationendImpl(long paramLong);
/*      */   
/*      */   static native void setOnwebkitanimationendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwebkitanimationiterationImpl(long paramLong);
/*      */   
/*      */   static native void setOnwebkitanimationiterationImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwebkitanimationstartImpl(long paramLong);
/*      */   
/*      */   static native void setOnwebkitanimationstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwebkittransitionendImpl(long paramLong);
/*      */   
/*      */   static native void setOnwebkittransitionendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnabortImpl(long paramLong);
/*      */   
/*      */   static native void setOnabortImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnblurImpl(long paramLong);
/*      */   
/*      */   static native void setOnblurImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOncanplayImpl(long paramLong);
/*      */   
/*      */   static native void setOncanplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOncanplaythroughImpl(long paramLong);
/*      */   
/*      */   static native void setOncanplaythroughImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnchangeImpl(long paramLong);
/*      */   
/*      */   static native void setOnchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnclickImpl(long paramLong);
/*      */   
/*      */   static native void setOnclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOncontextmenuImpl(long paramLong);
/*      */   
/*      */   static native void setOncontextmenuImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndblclickImpl(long paramLong);
/*      */   
/*      */   static native void setOndblclickImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragImpl(long paramLong);
/*      */   
/*      */   static native void setOndragImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragendImpl(long paramLong);
/*      */   
/*      */   static native void setOndragendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragenterImpl(long paramLong);
/*      */   
/*      */   static native void setOndragenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragleaveImpl(long paramLong);
/*      */   
/*      */   static native void setOndragleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragoverImpl(long paramLong);
/*      */   
/*      */   static native void setOndragoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndragstartImpl(long paramLong);
/*      */   
/*      */   static native void setOndragstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndropImpl(long paramLong);
/*      */   
/*      */   static native void setOndropImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOndurationchangeImpl(long paramLong);
/*      */   
/*      */   static native void setOndurationchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnemptiedImpl(long paramLong);
/*      */   
/*      */   static native void setOnemptiedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnendedImpl(long paramLong);
/*      */   
/*      */   static native void setOnendedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnerrorImpl(long paramLong);
/*      */   
/*      */   static native void setOnerrorImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnfocusImpl(long paramLong);
/*      */   
/*      */   static native void setOnfocusImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOninputImpl(long paramLong);
/*      */   
/*      */   static native void setOninputImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOninvalidImpl(long paramLong);
/*      */   
/*      */   static native void setOninvalidImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnkeydownImpl(long paramLong);
/*      */   
/*      */   static native void setOnkeydownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnkeypressImpl(long paramLong);
/*      */   
/*      */   static native void setOnkeypressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnkeyupImpl(long paramLong);
/*      */   
/*      */   static native void setOnkeyupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnloadImpl(long paramLong);
/*      */   
/*      */   static native void setOnloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnloadeddataImpl(long paramLong);
/*      */   
/*      */   static native void setOnloadeddataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnloadedmetadataImpl(long paramLong);
/*      */   
/*      */   static native void setOnloadedmetadataImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnloadstartImpl(long paramLong);
/*      */   
/*      */   static native void setOnloadstartImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmousedownImpl(long paramLong);
/*      */   
/*      */   static native void setOnmousedownImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmouseenterImpl(long paramLong);
/*      */   
/*      */   static native void setOnmouseenterImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmouseleaveImpl(long paramLong);
/*      */   
/*      */   static native void setOnmouseleaveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmousemoveImpl(long paramLong);
/*      */   
/*      */   static native void setOnmousemoveImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmouseoutImpl(long paramLong);
/*      */   
/*      */   static native void setOnmouseoutImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmouseoverImpl(long paramLong);
/*      */   
/*      */   static native void setOnmouseoverImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmouseupImpl(long paramLong);
/*      */   
/*      */   static native void setOnmouseupImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmousewheelImpl(long paramLong);
/*      */   
/*      */   static native void setOnmousewheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnpauseImpl(long paramLong);
/*      */   
/*      */   static native void setOnpauseImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnplayImpl(long paramLong);
/*      */   
/*      */   static native void setOnplayImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnplayingImpl(long paramLong);
/*      */   
/*      */   static native void setOnplayingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnprogressImpl(long paramLong);
/*      */   
/*      */   static native void setOnprogressImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnratechangeImpl(long paramLong);
/*      */   
/*      */   static native void setOnratechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnresetImpl(long paramLong);
/*      */   
/*      */   static native void setOnresetImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnresizeImpl(long paramLong);
/*      */   
/*      */   static native void setOnresizeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnscrollImpl(long paramLong);
/*      */   
/*      */   static native void setOnscrollImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnseekedImpl(long paramLong);
/*      */   
/*      */   static native void setOnseekedImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnseekingImpl(long paramLong);
/*      */   
/*      */   static native void setOnseekingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnselectImpl(long paramLong);
/*      */   
/*      */   static native void setOnselectImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnstalledImpl(long paramLong);
/*      */   
/*      */   static native void setOnstalledImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnsubmitImpl(long paramLong);
/*      */   
/*      */   static native void setOnsubmitImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnsuspendImpl(long paramLong);
/*      */   
/*      */   static native void setOnsuspendImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOntimeupdateImpl(long paramLong);
/*      */   
/*      */   static native void setOntimeupdateImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnvolumechangeImpl(long paramLong);
/*      */   
/*      */   static native void setOnvolumechangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwaitingImpl(long paramLong);
/*      */   
/*      */   static native void setOnwaitingImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnsearchImpl(long paramLong);
/*      */   
/*      */   static native void setOnsearchImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnwheelImpl(long paramLong);
/*      */   
/*      */   static native void setOnwheelImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnbeforeunloadImpl(long paramLong);
/*      */   
/*      */   static native void setOnbeforeunloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnhashchangeImpl(long paramLong);
/*      */   
/*      */   static native void setOnhashchangeImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnmessageImpl(long paramLong);
/*      */   
/*      */   static native void setOnmessageImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnofflineImpl(long paramLong);
/*      */   
/*      */   static native void setOnofflineImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnonlineImpl(long paramLong);
/*      */   
/*      */   static native void setOnonlineImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnpagehideImpl(long paramLong);
/*      */   
/*      */   static native void setOnpagehideImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnpageshowImpl(long paramLong);
/*      */   
/*      */   static native void setOnpageshowImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnpopstateImpl(long paramLong);
/*      */   
/*      */   static native void setOnpopstateImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnstorageImpl(long paramLong);
/*      */   
/*      */   static native void setOnstorageImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getOnunloadImpl(long paramLong);
/*      */   
/*      */   static native void setOnunloadImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native long getSelectionImpl(long paramLong);
/*      */   
/*      */   static native void focusImpl(long paramLong);
/*      */   
/*      */   static native void blurImpl(long paramLong);
/*      */   
/*      */   static native void closeImpl(long paramLong);
/*      */   
/*      */   static native void printImpl(long paramLong);
/*      */   
/*      */   static native void stopImpl(long paramLong);
/*      */   
/*      */   static native void alertImpl(long paramLong, String paramString);
/*      */   
/*      */   static native boolean confirmImpl(long paramLong, String paramString);
/*      */   
/*      */   static native String promptImpl(long paramLong, String paramString1, String paramString2);
/*      */   
/*      */   static native boolean findImpl(long paramLong, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6);
/*      */   
/*      */   static native void scrollByImpl(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   static native void scrollToImpl(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   static native void scrollImpl(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   static native void moveByImpl(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   static native void moveToImpl(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   static native void resizeByImpl(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   static native void resizeToImpl(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */   static native long getComputedStyleImpl(long paramLong1, long paramLong2, String paramString);
/*      */   
/*      */   static native void captureEventsImpl(long paramLong);
/*      */   
/*      */   static native void releaseEventsImpl(long paramLong);
/*      */   
/*      */   static native void addEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   static native void removeEventListenerImpl(long paramLong1, String paramString, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   static native boolean dispatchEventImpl(long paramLong1, long paramLong2);
/*      */   
/*      */   static native String atobImpl(long paramLong, String paramString);
/*      */   
/*      */   static native String btoaImpl(long paramLong, String paramString);
/*      */   
/*      */   static native void clearTimeoutImpl(long paramLong, int paramInt);
/*      */   
/*      */   static native void clearIntervalImpl(long paramLong, int paramInt);
/*      */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\DOMWindowImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */