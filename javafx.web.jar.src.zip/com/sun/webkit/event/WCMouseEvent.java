/*    */ package com.sun.webkit.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WCMouseEvent
/*    */ {
/*    */   public static final int MOUSE_PRESSED = 0;
/*    */   public static final int MOUSE_RELEASED = 1;
/*    */   public static final int MOUSE_MOVED = 2;
/*    */   public static final int MOUSE_DRAGGED = 3;
/*    */   public static final int MOUSE_WHEEL = 4;
/*    */   public static final int NOBUTTON = 0;
/*    */   public static final int BUTTON1 = 1;
/*    */   public static final int BUTTON2 = 2;
/*    */   public static final int BUTTON3 = 4;
/*    */   private final int id;
/*    */   private final long when;
/*    */   private final int button;
/*    */   private final int clickCount;
/*    */   private final int x;
/*    */   private final int y;
/*    */   private final int screenX;
/*    */   private final int screenY;
/*    */   private final boolean shift;
/*    */   private final boolean control;
/*    */   private final boolean alt;
/*    */   private final boolean meta;
/*    */   private final boolean popupTrigger;
/*    */   
/*    */   public WCMouseEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) {
/* 66 */     this.id = paramInt1;
/* 67 */     this.button = paramInt2;
/* 68 */     this.clickCount = paramInt3;
/* 69 */     this.x = paramInt4;
/* 70 */     this.y = paramInt5;
/* 71 */     this.screenX = paramInt6;
/* 72 */     this.screenY = paramInt7;
/* 73 */     this.when = paramLong;
/* 74 */     this.shift = paramBoolean1;
/* 75 */     this.control = paramBoolean2;
/* 76 */     this.alt = paramBoolean3;
/* 77 */     this.meta = paramBoolean4;
/* 78 */     this.popupTrigger = paramBoolean5;
/*    */   }
/*    */   
/* 81 */   public int getID() { return this.id; } public long getWhen() {
/* 82 */     return this.when;
/*    */   }
/* 84 */   public int getButton() { return this.button; } public int getClickCount() {
/* 85 */     return this.clickCount;
/*    */   }
/* 87 */   public int getX() { return this.x; }
/* 88 */   public int getY() { return this.y; }
/* 89 */   public int getScreenX() { return this.screenX; } public int getScreenY() {
/* 90 */     return this.screenY;
/*    */   }
/* 92 */   public boolean isShiftDown() { return this.shift; }
/* 93 */   public boolean isControlDown() { return this.control; }
/* 94 */   public boolean isAltDown() { return this.alt; } public boolean isMetaDown() {
/* 95 */     return this.meta;
/*    */   } public boolean isPopupTrigger() {
/* 97 */     return this.popupTrigger;
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\event\WCMouseEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */