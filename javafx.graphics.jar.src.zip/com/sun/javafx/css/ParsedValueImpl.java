/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import javafx.css.ParsedValue;
/*     */ import javafx.css.Size;
/*     */ import javafx.css.SizeUnits;
/*     */ import javafx.css.StyleConverter;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.text.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParsedValueImpl<V, T>
/*     */   extends ParsedValue<V, T>
/*     */ {
/*     */   private final boolean lookup;
/*     */   private final boolean containsLookups;
/*     */   
/*     */   public final boolean isLookup() {
/*  52 */     return this.lookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isContainsLookups() {
/*  61 */     return this.containsLookups;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean getContainsLookupsFlag(Object paramObject) {
/*  66 */     boolean bool = false;
/*     */     
/*  68 */     if (paramObject instanceof Size) {
/*  69 */       bool = false;
/*     */     
/*     */     }
/*  72 */     else if (paramObject instanceof ParsedValueImpl) {
/*  73 */       ParsedValueImpl parsedValueImpl = (ParsedValueImpl)paramObject;
/*  74 */       bool = (parsedValueImpl.lookup || parsedValueImpl.containsLookups) ? true : false;
/*     */     
/*     */     }
/*  77 */     else if (paramObject instanceof ParsedValueImpl[]) {
/*  78 */       ParsedValueImpl[] arrayOfParsedValueImpl = (ParsedValueImpl[])paramObject;
/*  79 */       byte b = 0;
/*     */ 
/*     */       
/*  82 */       for (; b < arrayOfParsedValueImpl.length && !bool; 
/*  83 */         b++)
/*     */       {
/*  85 */         if (arrayOfParsedValueImpl[b] != null) {
/*  86 */           bool = (bool || (arrayOfParsedValueImpl[b]).lookup || (arrayOfParsedValueImpl[b]).containsLookups) ? true : false;
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  93 */     else if (paramObject instanceof ParsedValueImpl[][]) {
/*  94 */       ParsedValueImpl[][] arrayOfParsedValueImpl = (ParsedValueImpl[][])paramObject;
/*  95 */       byte b = 0;
/*  96 */       for (; b < arrayOfParsedValueImpl.length && !bool; 
/*  97 */         b++) {
/*     */         
/*  99 */         if (arrayOfParsedValueImpl[b] != null) {
/* 100 */           byte b1 = 0;
/* 101 */           for (; b1 < (arrayOfParsedValueImpl[b]).length && !bool; 
/* 102 */             b1++) {
/*     */             
/* 104 */             if (arrayOfParsedValueImpl[b][b1] != null) {
/* 105 */               bool = (bool || (arrayOfParsedValueImpl[b][b1]).lookup || (arrayOfParsedValueImpl[b][b1]).containsLookups) ? true : false;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containsFontRelativeSize(ParsedValue paramParsedValue, boolean paramBoolean) {
/* 121 */     boolean bool = false;
/*     */     
/* 123 */     Object object = paramParsedValue.getValue();
/*     */     
/* 125 */     if (object instanceof Size) {
/* 126 */       Size size = (Size)object;
/*     */ 
/*     */ 
/*     */       
/* 130 */       bool = (size.getUnits() == SizeUnits.PERCENT) ? paramBoolean : (!size.isAbsolute());
/*     */     
/*     */     }
/* 133 */     else if (object instanceof ParsedValue) {
/* 134 */       ParsedValueImpl parsedValueImpl = (ParsedValueImpl)object;
/* 135 */       bool = containsFontRelativeSize(parsedValueImpl, paramBoolean);
/*     */     
/*     */     }
/* 138 */     else if (object instanceof ParsedValue[]) {
/* 139 */       ParsedValue[] arrayOfParsedValue = (ParsedValue[])object;
/* 140 */       byte b = 0;
/* 141 */       for (; b < arrayOfParsedValue.length && !bool; 
/* 142 */         b++) {
/*     */         
/* 144 */         if (arrayOfParsedValue[b] != null) {
/* 145 */           bool = containsFontRelativeSize(arrayOfParsedValue[b], paramBoolean);
/*     */         }
/*     */       } 
/* 148 */     } else if (object instanceof ParsedValueImpl[][]) {
/* 149 */       ParsedValueImpl[][] arrayOfParsedValueImpl = (ParsedValueImpl[][])object;
/* 150 */       byte b = 0;
/* 151 */       for (; b < arrayOfParsedValueImpl.length && !bool; 
/* 152 */         b++) {
/*     */         
/* 154 */         if (arrayOfParsedValueImpl[b] != null) {
/* 155 */           byte b1 = 0;
/* 156 */           for (; b1 < (arrayOfParsedValueImpl[b]).length && !bool; 
/* 157 */             b1++) {
/*     */             
/* 159 */             if (arrayOfParsedValueImpl[b][b1] != null)
/* 160 */               bool = containsFontRelativeSize(arrayOfParsedValueImpl[b][b1], paramBoolean); 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 165 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParsedValueImpl(V paramV, StyleConverter<V, T> paramStyleConverter, boolean paramBoolean) {
/* 176 */     super(paramV, paramStyleConverter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     this.hash = Integer.MIN_VALUE; this.lookup = paramBoolean; this.containsLookups = (paramBoolean || getContainsLookupsFlag(paramV));
/*     */   } public ParsedValueImpl(V paramV, StyleConverter<V, T> paramStyleConverter) { this(paramV, paramStyleConverter, false); } public T convert(Font paramFont) { return (this.converter != null) ? this.converter.convert(this, paramFont) : (T)this.value; } private static int indent = 0; private int hash; private static final byte NULL_VALUE = 0; private static final byte VALUE = 1; private static final byte VALUE_ARRAY = 2; private static final byte ARRAY_OF_VALUE_ARRAY = 3; private static final byte STRING = 4; private static final byte COLOR = 5;
/* 390 */   public int hashCode() { if (this.hash == Integer.MIN_VALUE) {
/* 391 */       this.hash = 17;
/* 392 */       if (this.value instanceof ParsedValueImpl[][])
/* 393 */       { ParsedValueImpl[][] arrayOfParsedValueImpl = (ParsedValueImpl[][])this.value;
/* 394 */         for (byte b = 0; b < arrayOfParsedValueImpl.length; b++) {
/* 395 */           for (byte b1 = 0; b1 < (arrayOfParsedValueImpl[b]).length; b1++) {
/* 396 */             ParsedValueImpl parsedValueImpl = arrayOfParsedValueImpl[b][b1];
/* 397 */             this.hash = 37 * this.hash + ((parsedValueImpl != null && parsedValueImpl.value != null) ? parsedValueImpl.value.hashCode() : 0);
/*     */           } 
/*     */         }  }
/* 400 */       else if (this.value instanceof ParsedValueImpl[])
/* 401 */       { ParsedValueImpl[] arrayOfParsedValueImpl = (ParsedValueImpl[])this.value;
/* 402 */         for (byte b = 0; b < arrayOfParsedValueImpl.length; b++) {
/* 403 */           if (arrayOfParsedValueImpl[b] != null && (arrayOfParsedValueImpl[b]).value != null) {
/* 404 */             ParsedValueImpl parsedValueImpl = arrayOfParsedValueImpl[b];
/* 405 */             this.hash = 37 * this.hash + ((parsedValueImpl != null && parsedValueImpl.value != null) ? parsedValueImpl.value.hashCode() : 0);
/*     */           } 
/*     */         }  }
/* 408 */       else { this.hash = 37 * this.hash + ((this.value != null) ? this.value.hashCode() : 0); }
/*     */     
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 416 */     return this.hash; }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte ENUM = 6;
/*     */   
/*     */   private static final byte BOOLEAN = 7;
/*     */   
/*     */   private static final byte URL = 8;
/*     */   
/*     */   private static final byte SIZE = 9;
/*     */ 
/*     */   
/*     */   private static String spaces() {
/*     */     return (new String(new char[indent])).replace(false, ' ');
/*     */   }
/*     */ 
/*     */   
/*     */   public final void writeBinary(DataOutputStream paramDataOutputStream, StyleConverter.StringStore paramStringStore) throws IOException {
/* 435 */     paramDataOutputStream.writeBoolean(this.lookup);
/*     */     
/* 437 */     if (this.converter != null) {
/* 438 */       paramDataOutputStream.writeBoolean(true);
/* 439 */       this.converter.writeBinary(paramDataOutputStream, paramStringStore);
/*     */     } else {
/* 441 */       paramDataOutputStream.writeBoolean(false);
/*     */     } 
/*     */     
/* 444 */     if (this.value instanceof ParsedValue)
/* 445 */     { paramDataOutputStream.writeByte(1);
/* 446 */       ParsedValue<V, T> parsedValue = (ParsedValue)this.value;
/* 447 */       if (parsedValue instanceof ParsedValueImpl) {
/* 448 */         ((ParsedValueImpl)parsedValue).writeBinary(paramDataOutputStream, paramStringStore);
/*     */       } else {
/* 450 */         ParsedValueImpl parsedValueImpl = new ParsedValueImpl((V)parsedValue.getValue(), parsedValue.getConverter());
/* 451 */         parsedValueImpl.writeBinary(paramDataOutputStream, paramStringStore);
/*     */       }
/*     */        }
/* 454 */     else if (this.value instanceof ParsedValue[])
/* 455 */     { paramDataOutputStream.writeByte(2);
/* 456 */       ParsedValue[] arrayOfParsedValue = (ParsedValue[])this.value;
/* 457 */       if (arrayOfParsedValue != null) {
/* 458 */         paramDataOutputStream.writeByte(1);
/*     */       } else {
/* 460 */         paramDataOutputStream.writeByte(0);
/*     */       } 
/* 462 */       byte b1 = (arrayOfParsedValue != null) ? arrayOfParsedValue.length : 0;
/* 463 */       paramDataOutputStream.writeInt(b1);
/* 464 */       for (byte b2 = 0; b2 < b1; b2++) {
/* 465 */         if (arrayOfParsedValue[b2] != null) {
/* 466 */           paramDataOutputStream.writeByte(1);
/* 467 */           ParsedValue<V, T> parsedValue = arrayOfParsedValue[b2];
/* 468 */           if (parsedValue instanceof ParsedValueImpl) {
/* 469 */             ((ParsedValueImpl)parsedValue).writeBinary(paramDataOutputStream, paramStringStore);
/*     */           } else {
/* 471 */             ParsedValueImpl parsedValueImpl = new ParsedValueImpl((V)parsedValue.getValue(), parsedValue.getConverter());
/* 472 */             parsedValueImpl.writeBinary(paramDataOutputStream, paramStringStore);
/*     */           } 
/*     */         } else {
/* 475 */           paramDataOutputStream.writeByte(0);
/*     */         }
/*     */       
/*     */       }  }
/* 479 */     else if (this.value instanceof ParsedValue[][])
/* 480 */     { paramDataOutputStream.writeByte(3);
/* 481 */       ParsedValue[][] arrayOfParsedValue = (ParsedValue[][])this.value;
/* 482 */       if (arrayOfParsedValue != null) {
/* 483 */         paramDataOutputStream.writeByte(1);
/*     */       } else {
/* 485 */         paramDataOutputStream.writeByte(0);
/*     */       } 
/* 487 */       byte b1 = (arrayOfParsedValue != null) ? arrayOfParsedValue.length : 0;
/* 488 */       paramDataOutputStream.writeInt(b1);
/* 489 */       for (byte b2 = 0; b2 < b1; b2++) {
/* 490 */         ParsedValue[] arrayOfParsedValue1 = arrayOfParsedValue[b2];
/* 491 */         if (arrayOfParsedValue1 != null) {
/* 492 */           paramDataOutputStream.writeByte(1);
/*     */         } else {
/* 494 */           paramDataOutputStream.writeByte(0);
/*     */         } 
/* 496 */         byte b3 = (arrayOfParsedValue1 != null) ? arrayOfParsedValue1.length : 0;
/* 497 */         paramDataOutputStream.writeInt(b3);
/* 498 */         for (byte b4 = 0; b4 < b3; b4++) {
/* 499 */           if (arrayOfParsedValue1[b4] != null) {
/* 500 */             paramDataOutputStream.writeByte(1);
/* 501 */             ParsedValue<V, T> parsedValue = arrayOfParsedValue1[b4];
/* 502 */             if (parsedValue instanceof ParsedValueImpl) {
/* 503 */               ((ParsedValueImpl)parsedValue).writeBinary(paramDataOutputStream, paramStringStore);
/*     */             } else {
/* 505 */               ParsedValueImpl parsedValueImpl = new ParsedValueImpl((V)parsedValue.getValue(), parsedValue.getConverter());
/* 506 */               parsedValueImpl.writeBinary(paramDataOutputStream, paramStringStore);
/*     */             } 
/*     */           } else {
/* 509 */             paramDataOutputStream.writeByte(0);
/*     */           }
/*     */         
/*     */         } 
/*     */       }  }
/* 514 */     else if (this.value instanceof Color)
/* 515 */     { Color color = (Color)this.value;
/* 516 */       paramDataOutputStream.writeByte(5);
/* 517 */       paramDataOutputStream.writeLong(Double.doubleToLongBits(color.getRed()));
/* 518 */       paramDataOutputStream.writeLong(Double.doubleToLongBits(color.getGreen()));
/* 519 */       paramDataOutputStream.writeLong(Double.doubleToLongBits(color.getBlue()));
/* 520 */       paramDataOutputStream.writeLong(Double.doubleToLongBits(color.getOpacity())); }
/*     */     
/* 522 */     else if (this.value instanceof Enum)
/* 523 */     { Enum enum_ = (Enum)this.value;
/* 524 */       int i = paramStringStore.addString(enum_.name());
/* 525 */       paramDataOutputStream.writeByte(6);
/* 526 */       paramDataOutputStream.writeShort(i); }
/*     */     
/* 528 */     else if (this.value instanceof Boolean)
/* 529 */     { Boolean bool = (Boolean)this.value;
/* 530 */       paramDataOutputStream.writeByte(7);
/* 531 */       paramDataOutputStream.writeBoolean(bool.booleanValue()); }
/*     */     
/* 533 */     else if (this.value instanceof Size)
/* 534 */     { Size size = (Size)this.value;
/* 535 */       paramDataOutputStream.writeByte(9);
/*     */       
/* 537 */       double d = size.getValue();
/* 538 */       long l = Double.doubleToLongBits(d);
/* 539 */       paramDataOutputStream.writeLong(l);
/*     */       
/* 541 */       int i = paramStringStore.addString(size.getUnits().name());
/* 542 */       paramDataOutputStream.writeShort(i); }
/*     */     
/* 544 */     else if (this.value instanceof String)
/* 545 */     { paramDataOutputStream.writeByte(4);
/* 546 */       int i = paramStringStore.addString((String)this.value);
/* 547 */       paramDataOutputStream.writeShort(i); }
/*     */     
/* 549 */     else if (this.value instanceof URL)
/* 550 */     { paramDataOutputStream.writeByte(8);
/* 551 */       int i = paramStringStore.addString(this.value.toString());
/* 552 */       paramDataOutputStream.writeShort(i); }
/*     */     
/* 554 */     else if (this.value == null)
/* 555 */     { paramDataOutputStream.writeByte(0); }
/*     */     else
/*     */     
/* 558 */     { throw new InternalError("cannot writeBinary " + this); } 
/*     */   }
/*     */   private static void indent() { indent += 2; }
/*     */   private static void outdent() { indent = Math.max(0, indent - 2); }
/*     */   public String toString() { String str = System.lineSeparator(); StringBuilder stringBuilder = new StringBuilder(); stringBuilder.append(spaces()).append(this.lookup ? "<Value lookup=\"true\">" : "<Value>").append(str); indent(); if (this.value != null) { appendValue(stringBuilder, this.value, "value"); } else { appendValue(stringBuilder, "null", "value"); }  stringBuilder.append(spaces()).append("<converter>").append(this.converter).append("</converter>").append(str); outdent(); stringBuilder.append(spaces()).append("</Value>"); return stringBuilder.toString(); }
/*     */   private void appendValue(StringBuilder paramStringBuilder, Object paramObject, String paramString) { String str = System.lineSeparator(); if (paramObject instanceof ParsedValueImpl[][]) { ParsedValueImpl[][] arrayOfParsedValueImpl = (ParsedValueImpl[][])paramObject; paramStringBuilder.append(spaces()).append('<').append(paramString).append(" layers=\"").append(arrayOfParsedValueImpl.length).append("\">").append(str); indent(); for (ParsedValueImpl[] arrayOfParsedValueImpl1 : arrayOfParsedValueImpl) { paramStringBuilder.append(spaces()).append("<layer>").append(str); indent(); if (arrayOfParsedValueImpl1 == null) { paramStringBuilder.append(spaces()).append("null").append(str); } else { for (ParsedValueImpl parsedValueImpl : arrayOfParsedValueImpl1) { if (parsedValueImpl == null) { paramStringBuilder.append(spaces()).append("null").append(str); } else { paramStringBuilder.append(parsedValueImpl); }  }  outdent(); paramStringBuilder.append(spaces()).append("</layer>").append(str); }  }  outdent(); paramStringBuilder.append(spaces()).append("</").append(paramString).append('>').append(str); } else if (paramObject instanceof ParsedValueImpl[]) { ParsedValueImpl[] arrayOfParsedValueImpl = (ParsedValueImpl[])paramObject; paramStringBuilder.append(spaces()).append('<').append(paramString).append(" values=\"").append(arrayOfParsedValueImpl.length).append("\">").append(str); indent(); for (ParsedValueImpl parsedValueImpl : arrayOfParsedValueImpl) { if (parsedValueImpl == null) { paramStringBuilder.append(spaces()).append("null").append(str); } else { paramStringBuilder.append(parsedValueImpl); }  }  outdent(); paramStringBuilder.append(spaces()).append("</").append(paramString).append('>').append(str); } else if (paramObject instanceof ParsedValueImpl) { paramStringBuilder.append(spaces()).append('<').append(paramString).append('>').append(str); indent(); paramStringBuilder.append(paramObject); outdent(); paramStringBuilder.append(spaces()).append("</").append(paramString).append('>').append(str); } else { paramStringBuilder.append(spaces()).append('<').append(paramString).append('>'); paramStringBuilder.append(paramObject); paramStringBuilder.append("</").append(paramString).append('>').append(str); }  } public boolean equals(Object paramObject) { if (paramObject == this) return true;  if (paramObject == null || paramObject.getClass() != getClass()) return false;  ParsedValueImpl parsedValueImpl = (ParsedValueImpl)paramObject; if (this.hash != parsedValueImpl.hash) return false;  if (this.value instanceof ParsedValueImpl[][]) { if (!(parsedValueImpl.value instanceof ParsedValueImpl[][])) return false;  ParsedValueImpl[][] arrayOfParsedValueImpl1 = (ParsedValueImpl[][])this.value; ParsedValueImpl[][] arrayOfParsedValueImpl2 = (ParsedValueImpl[][])parsedValueImpl.value; if (arrayOfParsedValueImpl1.length != arrayOfParsedValueImpl2.length) return false;  for (byte b = 0; b < arrayOfParsedValueImpl1.length; b++) { if (arrayOfParsedValueImpl1[b] != null || arrayOfParsedValueImpl2[b] != null) { if (arrayOfParsedValueImpl1[b] == null || arrayOfParsedValueImpl2[b] == null) return false;  if ((arrayOfParsedValueImpl1[b]).length != (arrayOfParsedValueImpl2[b]).length) return false;  for (byte b1 = 0; b1 < (arrayOfParsedValueImpl1[b]).length; b1++) { ParsedValueImpl parsedValueImpl1 = arrayOfParsedValueImpl1[b][b1]; ParsedValueImpl parsedValueImpl2 = arrayOfParsedValueImpl2[b][b1]; if ((parsedValueImpl1 != null) ? !parsedValueImpl1.equals(parsedValueImpl2) : (parsedValueImpl2 != null)) return false;  }  }  }  return true; }  if (this.value instanceof ParsedValueImpl[]) { if (!(parsedValueImpl.value instanceof ParsedValueImpl[])) return false;  ParsedValueImpl[] arrayOfParsedValueImpl1 = (ParsedValueImpl[])this.value; ParsedValueImpl[] arrayOfParsedValueImpl2 = (ParsedValueImpl[])parsedValueImpl.value; if (arrayOfParsedValueImpl1.length != arrayOfParsedValueImpl2.length) return false;  for (byte b = 0; b < arrayOfParsedValueImpl1.length; b++) { ParsedValueImpl parsedValueImpl1 = arrayOfParsedValueImpl1[b]; ParsedValueImpl parsedValueImpl2 = arrayOfParsedValueImpl2[b]; if ((parsedValueImpl1 != null) ? !parsedValueImpl1.equals(parsedValueImpl2) : (parsedValueImpl2 != null))
/*     */           return false;  }  return true; }  if (this.value instanceof String && parsedValueImpl.value instanceof String)
/* 565 */       return this.value.toString().equalsIgnoreCase(parsedValueImpl.value.toString());  return (this.value != null) ? this.value.equals(parsedValueImpl.value) : ((parsedValueImpl.value == null)); } public static ParsedValueImpl readBinary(int paramInt, DataInputStream paramDataInputStream, String[] paramArrayOfString) throws IOException { boolean bool1 = paramDataInputStream.readBoolean();
/* 566 */     boolean bool2 = paramDataInputStream.readBoolean();
/*     */     
/* 568 */     StyleConverter<ParsedValueImpl, ?> styleConverter = bool2 ? StyleConverter.readBinary(paramDataInputStream, paramArrayOfString) : null;
/*     */     
/* 570 */     byte b = paramDataInputStream.readByte();
/*     */     
/* 572 */     if (b == 1) {
/* 573 */       ParsedValueImpl parsedValueImpl = readBinary(paramInt, paramDataInputStream, paramArrayOfString);
/* 574 */       return new ParsedValueImpl<>(parsedValueImpl, styleConverter, bool1);
/*     */     } 
/* 576 */     if (b == 2) {
/* 577 */       if (paramInt >= 4)
/*     */       {
/*     */         
/* 580 */         paramDataInputStream.readByte();
/*     */       }
/* 582 */       int i = paramDataInputStream.readInt();
/*     */ 
/*     */       
/* 585 */       ParsedValueImpl[] arrayOfParsedValueImpl = (i > 0) ? new ParsedValueImpl[i] : null;
/* 586 */       for (byte b1 = 0; b1 < i; b1++) {
/* 587 */         byte b2 = paramDataInputStream.readByte();
/* 588 */         if (b2 == 1) {
/* 589 */           arrayOfParsedValueImpl[b1] = readBinary(paramInt, paramDataInputStream, paramArrayOfString);
/*     */         } else {
/* 591 */           arrayOfParsedValueImpl[b1] = null;
/*     */         } 
/*     */       } 
/* 594 */       return new ParsedValueImpl<>(arrayOfParsedValueImpl, styleConverter, bool1);
/*     */     } 
/* 596 */     if (b == 3) {
/* 597 */       if (paramInt >= 4)
/*     */       {
/*     */         
/* 600 */         paramDataInputStream.readByte();
/*     */       }
/*     */       
/* 603 */       int i = paramDataInputStream.readInt();
/* 604 */       ParsedValueImpl[][] arrayOfParsedValueImpl = (i > 0) ? new ParsedValueImpl[i][0] : null;
/*     */       
/* 606 */       for (byte b1 = 0; b1 < i; b1++) {
/* 607 */         if (paramInt >= 4)
/*     */         {
/*     */           
/* 610 */           paramDataInputStream.readByte();
/*     */         }
/* 612 */         int j = paramDataInputStream.readInt();
/*     */         
/* 614 */         arrayOfParsedValueImpl[b1] = (j > 0) ? new ParsedValueImpl[j] : null;
/*     */         
/* 616 */         for (byte b2 = 0; b2 < j; b2++) {
/* 617 */           byte b3 = paramDataInputStream.readByte();
/* 618 */           if (b3 == 1) {
/* 619 */             arrayOfParsedValueImpl[b1][b2] = readBinary(paramInt, paramDataInputStream, paramArrayOfString);
/*     */           } else {
/* 621 */             arrayOfParsedValueImpl[b1][b2] = null;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 627 */       return new ParsedValueImpl<>(arrayOfParsedValueImpl, styleConverter, bool1);
/*     */     } 
/* 629 */     if (b == 5) {
/* 630 */       double d1 = Double.longBitsToDouble(paramDataInputStream.readLong());
/* 631 */       double d2 = Double.longBitsToDouble(paramDataInputStream.readLong());
/* 632 */       double d3 = Double.longBitsToDouble(paramDataInputStream.readLong());
/* 633 */       double d4 = Double.longBitsToDouble(paramDataInputStream.readLong());
/* 634 */       return new ParsedValueImpl<>(Color.color(d1, d2, d3, d4), styleConverter, bool1);
/*     */     } 
/* 636 */     if (b == 6) {
/* 637 */       short s = paramDataInputStream.readShort();
/* 638 */       String str = paramArrayOfString[s];
/*     */ 
/*     */       
/* 641 */       if (paramInt == 2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 654 */         short s1 = paramDataInputStream.readShort();
/* 655 */         if (s1 >= paramArrayOfString.length) throw new IllegalArgumentException("bad version " + paramInt);
/*     */       
/*     */       } 
/* 658 */       return new ParsedValueImpl<>(str, styleConverter, bool1);
/*     */     } 
/*     */     
/* 661 */     if (b == 7) {
/* 662 */       Boolean bool = Boolean.valueOf(paramDataInputStream.readBoolean());
/* 663 */       return new ParsedValueImpl<>(bool, styleConverter, bool1);
/*     */     } 
/* 665 */     if (b == 9) {
/* 666 */       double d = Double.longBitsToDouble(paramDataInputStream.readLong());
/* 667 */       SizeUnits sizeUnits = SizeUnits.PX;
/* 668 */       String str = paramArrayOfString[paramDataInputStream.readShort()];
/*     */       try {
/* 670 */         sizeUnits = Enum.<SizeUnits>valueOf(SizeUnits.class, str);
/* 671 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 672 */         System.err.println(illegalArgumentException.toString());
/* 673 */       } catch (NullPointerException nullPointerException) {
/* 674 */         System.err.println(nullPointerException.toString());
/*     */       } 
/* 676 */       return new ParsedValueImpl<>(new Size(d, sizeUnits), styleConverter, bool1);
/*     */     } 
/* 678 */     if (b == 4) {
/* 679 */       String str = paramArrayOfString[paramDataInputStream.readShort()];
/* 680 */       return new ParsedValueImpl<>(str, styleConverter, bool1);
/*     */     } 
/* 682 */     if (b == 8) {
/* 683 */       String str = paramArrayOfString[paramDataInputStream.readShort()];
/*     */       try {
/* 685 */         URL uRL = new URL(str);
/* 686 */         return new ParsedValueImpl<>(uRL, styleConverter, bool1);
/* 687 */       } catch (MalformedURLException malformedURLException) {
/* 688 */         throw new InternalError("Exception in Value.readBinary: " + malformedURLException);
/*     */       } 
/*     */     } 
/* 691 */     if (b == 0) {
/* 692 */       return new ParsedValueImpl<>(null, styleConverter, bool1);
/*     */     }
/*     */     
/* 695 */     throw new InternalError("unknown type: " + b); }
/*     */ 
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\css\ParsedValueImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */