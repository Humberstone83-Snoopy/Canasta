/*     */ package com.sun.glass.ui.mac;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MacFileNSURL
/*     */   extends File
/*     */ {
/*     */   private long ptr;
/*     */   
/*     */   static {
/*  43 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MacFileNSURL(String paramString, long paramLong) {
/*  52 */     super(paramString);
/*  53 */     this.ptr = paramLong;
/*  54 */     Application.checkEventThread();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkNotDisposed() {
/*  61 */     if (this.ptr == 0L) {
/*  62 */       throw new RuntimeException("The NSURL object has been diposed already");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  74 */     Application.checkEventThread();
/*  75 */     checkNotDisposed();
/*  76 */     _dispose(this.ptr);
/*  77 */     this.ptr = 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean startAccessingSecurityScopedResource() {
/*  90 */     Application.checkEventThread();
/*  91 */     checkNotDisposed();
/*  92 */     return _startAccessingSecurityScopedResource(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stopAccessingSecurityScopedResource() {
/* 100 */     Application.checkEventThread();
/* 101 */     checkNotDisposed();
/* 102 */     _stopAccessingSecurityScopedResource(this.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBookmark() {
/* 117 */     Application.checkEventThread();
/* 118 */     checkNotDisposed();
/* 119 */     return _getBookmark(this.ptr, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MacFileNSURL createFromBookmark(byte[] paramArrayOfbyte) {
/* 133 */     Application.checkEventThread();
/* 134 */     if (paramArrayOfbyte == null) {
/* 135 */       throw new NullPointerException("data must not be null");
/*     */     }
/* 137 */     if (!MacCommonDialogs.isFileNSURLEnabled()) {
/* 138 */       throw new RuntimeException("The system property glass.macosx.enableFileNSURL is not 'true'");
/*     */     }
/* 140 */     return _createFromBookmark(paramArrayOfbyte, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getDocumentScopedBookmark(MacFileNSURL paramMacFileNSURL) {
/* 153 */     Application.checkEventThread();
/* 154 */     checkNotDisposed();
/* 155 */     return _getBookmark(this.ptr, paramMacFileNSURL.ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MacFileNSURL createFromDocumentScopedBookmark(byte[] paramArrayOfbyte, MacFileNSURL paramMacFileNSURL) {
/* 170 */     Application.checkEventThread();
/* 171 */     if (paramArrayOfbyte == null) {
/* 172 */       throw new NullPointerException("data must not be null");
/*     */     }
/* 174 */     if (!MacCommonDialogs.isFileNSURLEnabled()) {
/* 175 */       throw new RuntimeException("The system property glass.macosx.enableFileNSURL is not 'true'");
/*     */     }
/* 177 */     return _createFromBookmark(paramArrayOfbyte, paramMacFileNSURL.ptr);
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native void _dispose(long paramLong);
/*     */   
/*     */   private native boolean _startAccessingSecurityScopedResource(long paramLong);
/*     */   
/*     */   private native void _stopAccessingSecurityScopedResource(long paramLong);
/*     */   
/*     */   private native byte[] _getBookmark(long paramLong1, long paramLong2);
/*     */   
/*     */   private static native MacFileNSURL _createFromBookmark(byte[] paramArrayOfbyte, long paramLong);
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\mac\MacFileNSURL.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */