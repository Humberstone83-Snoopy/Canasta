package com.sun.javafx.image;

import java.nio.IntBuffer;

public interface IntToIntPixelConverter extends PixelConverter<IntBuffer, IntBuffer> {
  void convert(int[] paramArrayOfint1, int paramInt1, int paramInt2, int[] paramArrayOfint2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(IntBuffer paramIntBuffer, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void convert(int[] paramArrayOfint, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\IntToIntPixelConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */