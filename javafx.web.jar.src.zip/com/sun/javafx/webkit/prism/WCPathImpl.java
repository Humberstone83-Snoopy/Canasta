/*     */ package com.sun.javafx.webkit.prism;
/*     */ 
/*     */ import com.sun.javafx.geom.Arc2D;
/*     */ import com.sun.javafx.geom.Ellipse2D;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.PathIterator;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.RoundRectangle2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.logging.PlatformLogger;
/*     */ import com.sun.webkit.graphics.WCPath;
/*     */ import com.sun.webkit.graphics.WCPathIterator;
/*     */ import com.sun.webkit.graphics.WCRectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WCPathImpl
/*     */   extends WCPath<Path2D>
/*     */ {
/*     */   private final Path2D path;
/*     */   private boolean hasCP = false;
/*  47 */   private static final PlatformLogger log = PlatformLogger.getLogger(WCPathImpl.class.getName());
/*     */   
/*     */   WCPathImpl() {
/*  50 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  51 */       log.fine("Create empty WCPathImpl({0})", new Object[] { Integer.valueOf(getID()) });
/*     */     }
/*  53 */     this.path = new Path2D();
/*     */   }
/*     */   
/*     */   WCPathImpl(WCPathImpl paramWCPathImpl) {
/*  57 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  58 */       log.fine("Create WCPathImpl({0}) from WCPathImpl({1})", new Object[] {
/*  59 */             Integer.valueOf(getID()), Integer.valueOf(paramWCPathImpl.getID())
/*     */           }); 
/*  61 */     this.path = new Path2D(paramWCPathImpl.path);
/*  62 */     this.hasCP = paramWCPathImpl.hasCP;
/*     */   }
/*     */   
/*     */   public void addRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  66 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  67 */       log.fine("WCPathImpl({0}).addRect({1},{2},{3},{4})", new Object[] {
/*  68 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4)
/*     */           }); 
/*  70 */     this.hasCP = true;
/*  71 */     this.path.append(new RoundRectangle2D((float)paramDouble1, (float)paramDouble2, (float)paramDouble3, (int)paramDouble4, 0.0F, 0.0F), false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEllipse(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  77 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/*  78 */       log.fine("WCPathImpl({0}).addEllipse({1},{2},{3},{4})", new Object[] {
/*  79 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4)
/*     */           }); 
/*  81 */     this.hasCP = true;
/*  82 */     this.path.append(new Ellipse2D((float)paramDouble1, (float)paramDouble2, (float)paramDouble3, (float)paramDouble4), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addArcTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
/*  87 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/*  88 */       log.fine("WCPathImpl({0}).addArcTo({1},{2},{3},{4})", new Object[] {
/*  89 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4)
/*     */           });
/*     */     }
/*  92 */     Arc2D arc2D = new Arc2D();
/*  93 */     arc2D.setArcByTangent(this.path
/*  94 */         .getCurrentPoint(), new Point2D((float)paramDouble1, (float)paramDouble2), new Point2D((float)paramDouble3, (float)paramDouble4), (float)paramDouble5);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.hasCP = true;
/* 100 */     this.path.append(arc2D, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, boolean paramBoolean) {
/* 108 */     float f1 = (float)paramDouble4;
/* 109 */     float f2 = (float)paramDouble5;
/*     */     
/* 111 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 112 */       log.fine("WCPathImpl({0}).addArc(x={1},y={2},r={3},sa=|{4}|,ea=|{5}|,aclock={6})", new Object[] {
/* 113 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Float.valueOf(f1), Float.valueOf(f2), Boolean.valueOf(paramBoolean)
/*     */           });
/*     */     }
/* 116 */     this.hasCP = true;
/*     */     
/* 118 */     float f3 = f2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     if (!paramBoolean && f1 > f2) {
/* 148 */       f3 = f1 + 6.2831855F - (f1 - f2) % 6.2831855F;
/* 149 */     } else if (paramBoolean && f1 < f2) {
/* 150 */       f3 = f1 - 6.2831855F - (f2 - f1) % 6.2831855F;
/*     */     } 
/*     */     
/* 153 */     this.path.append(new Arc2D((float)(paramDouble1 - paramDouble3), (float)(paramDouble2 - paramDouble3), (float)(2.0D * paramDouble3), (float)(2.0D * paramDouble3), 
/*     */           
/* 155 */           (float)Math.toDegrees(-f1), 
/* 156 */           (float)Math.toDegrees((f1 - f3)), 0), true);
/*     */   }
/*     */   
/*     */   public boolean contains(int paramInt, double paramDouble1, double paramDouble2) {
/* 160 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 161 */       log.fine("WCPathImpl({0}).contains({1},{2},{3})", new Object[] {
/* 162 */             Integer.valueOf(getID()), Integer.valueOf(paramInt), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2)
/*     */           }); 
/* 164 */     int i = this.path.getWindingRule();
/* 165 */     this.path.setWindingRule(paramInt);
/* 166 */     boolean bool = this.path.contains((float)paramDouble1, (float)paramDouble2);
/* 167 */     this.path.setWindingRule(i);
/*     */     
/* 169 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public WCRectangle getBounds() {
/* 174 */     RectBounds rectBounds = this.path.getBounds();
/* 175 */     return new WCRectangle(rectBounds.getMinX(), rectBounds.getMinY(), rectBounds.getWidth(), rectBounds.getHeight());
/*     */   }
/*     */   
/*     */   public void clear() {
/* 179 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 180 */       log.fine("WCPathImpl({0}).clear()", new Object[] { Integer.valueOf(getID()) });
/*     */     }
/* 182 */     this.hasCP = false;
/* 183 */     this.path.reset();
/*     */   }
/*     */   
/*     */   public void moveTo(double paramDouble1, double paramDouble2) {
/* 187 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 188 */       log.fine("WCPathImpl({0}).moveTo({1},{2})", new Object[] {
/* 189 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2)
/*     */           }); 
/* 191 */     this.hasCP = true;
/* 192 */     this.path.moveTo((float)paramDouble1, (float)paramDouble2);
/*     */   }
/*     */   
/*     */   public void addLineTo(double paramDouble1, double paramDouble2) {
/* 196 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 197 */       log.fine("WCPathImpl({0}).addLineTo({1},{2})", new Object[] {
/* 198 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2)
/*     */           }); 
/* 200 */     this.hasCP = true;
/* 201 */     this.path.lineTo((float)paramDouble1, (float)paramDouble2);
/*     */   }
/*     */   
/*     */   public void addQuadCurveTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 205 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 206 */       log.fine("WCPathImpl({0}).addQuadCurveTo({1},{2},{3},{4})", new Object[] {
/* 207 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4)
/*     */           }); 
/* 209 */     this.hasCP = true;
/* 210 */     this.path.quadTo((float)paramDouble1, (float)paramDouble2, (float)paramDouble3, (float)paramDouble4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBezierCurveTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 215 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 216 */       log.fine("WCPathImpl({0}).addBezierCurveTo({1},{2},{3},{4},{5},{6})", new Object[] {
/* 217 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4), Double.valueOf(paramDouble5), Double.valueOf(paramDouble6)
/*     */           }); 
/* 219 */     this.hasCP = true;
/* 220 */     this.path.curveTo((float)paramDouble1, (float)paramDouble2, (float)paramDouble3, (float)paramDouble4, (float)paramDouble5, (float)paramDouble6);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addPath(WCPath paramWCPath) {
/* 225 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 226 */       log.fine("WCPathImpl({0}).addPath({1})", new Object[] {
/* 227 */             Integer.valueOf(getID()), Integer.valueOf(paramWCPath.getID())
/*     */           }); 
/* 229 */     this.hasCP = (this.hasCP || ((WCPathImpl)paramWCPath).hasCP);
/* 230 */     this.path.append(((WCPathImpl)paramWCPath).path, false);
/*     */   }
/*     */   
/*     */   public void closeSubpath() {
/* 234 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 235 */       log.fine("WCPathImpl({0}).closeSubpath()", new Object[] { Integer.valueOf(getID()) });
/*     */     }
/* 237 */     this.path.closePath();
/*     */   }
/*     */   
/*     */   public boolean hasCurrentPoint() {
/* 241 */     return this.hasCP;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 245 */     PathIterator pathIterator = this.path.getPathIterator(null);
/* 246 */     float[] arrayOfFloat = new float[6];
/* 247 */     while (!pathIterator.isDone()) {
/* 248 */       switch (pathIterator.currentSegment(arrayOfFloat)) {
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/* 252 */           return false;
/*     */       } 
/* 254 */       pathIterator.next();
/*     */     } 
/* 256 */     return true;
/*     */   }
/*     */   
/*     */   public int getWindingRule() {
/* 260 */     return 1 - this.path.getWindingRule();
/*     */   }
/*     */   
/*     */   public void setWindingRule(int paramInt) {
/* 264 */     this.path.setWindingRule(1 - paramInt);
/*     */   }
/*     */   
/*     */   public Path2D getPlatformPath() {
/* 268 */     if (log.isLoggable(PlatformLogger.Level.FINE)) {
/* 269 */       log.fine("WCPathImpl({0}).getPath() BEGIN=====", new Object[] { Integer.valueOf(getID()) });
/* 270 */       PathIterator pathIterator = this.path.getPathIterator(null);
/* 271 */       float[] arrayOfFloat = new float[6];
/* 272 */       while (!pathIterator.isDone()) {
/* 273 */         switch (pathIterator.currentSegment(arrayOfFloat)) {
/*     */           case 0:
/* 275 */             log.fine("SEG_MOVETO ({0},{1})", new Object[] {
/* 276 */                   Float.valueOf(arrayOfFloat[0]), Float.valueOf(arrayOfFloat[1]) });
/*     */             break;
/*     */           case 1:
/* 279 */             log.fine("SEG_LINETO ({0},{1})", new Object[] {
/* 280 */                   Float.valueOf(arrayOfFloat[0]), Float.valueOf(arrayOfFloat[1]) });
/*     */             break;
/*     */           case 2:
/* 283 */             log.fine("SEG_QUADTO ({0},{1},{2},{3})", new Object[] {
/* 284 */                   Float.valueOf(arrayOfFloat[0]), Float.valueOf(arrayOfFloat[1]), Float.valueOf(arrayOfFloat[2]), Float.valueOf(arrayOfFloat[3]) });
/*     */             break;
/*     */           case 3:
/* 287 */             log.fine("SEG_CUBICTO ({0},{1},{2},{3},{4},{5})", new Object[] {
/* 288 */                   Float.valueOf(arrayOfFloat[0]), Float.valueOf(arrayOfFloat[1]), Float.valueOf(arrayOfFloat[2]), Float.valueOf(arrayOfFloat[3]), 
/* 289 */                   Float.valueOf(arrayOfFloat[4]), Float.valueOf(arrayOfFloat[5]) });
/*     */             break;
/*     */           case 4:
/* 292 */             log.fine("SEG_CLOSE");
/*     */             break;
/*     */         } 
/* 295 */         pathIterator.next();
/*     */       } 
/* 297 */       log.fine("========getPath() END=====");
/*     */     } 
/* 299 */     return this.path;
/*     */   }
/*     */   
/*     */   public WCPathIterator getPathIterator() {
/* 303 */     final PathIterator pi = this.path.getPathIterator(null);
/* 304 */     return new WCPathIterator() {
/*     */         public int getWindingRule() {
/* 306 */           return pi.getWindingRule();
/*     */         }
/*     */         
/*     */         public boolean isDone() {
/* 310 */           return pi.isDone();
/*     */         }
/*     */         
/*     */         public void next() {
/* 314 */           pi.next();
/*     */         }
/*     */         
/*     */         public int currentSegment(double[] param1ArrayOfdouble) {
/* 318 */           float[] arrayOfFloat = new float[6];
/* 319 */           int i = pi.currentSegment(arrayOfFloat);
/* 320 */           for (byte b = 0; b < param1ArrayOfdouble.length; b++) {
/* 321 */             param1ArrayOfdouble[b] = arrayOfFloat[b];
/*     */           }
/* 323 */           return i;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public void translate(double paramDouble1, double paramDouble2) {
/* 330 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 331 */       log.fine("WCPathImpl({0}).translate({1}, {2})", new Object[] {
/* 332 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2)
/*     */           }); 
/* 334 */     this.path.transform(BaseTransform.getTranslateInstance(paramDouble1, paramDouble2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void transform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 341 */     if (log.isLoggable(PlatformLogger.Level.FINE))
/* 342 */       log.fine("WCPathImpl({0}).transform({1},{2},{3},{4},{5},{6})", new Object[] {
/* 343 */             Integer.valueOf(getID()), Double.valueOf(paramDouble1), Double.valueOf(paramDouble2), Double.valueOf(paramDouble3), Double.valueOf(paramDouble4), Double.valueOf(paramDouble5), Double.valueOf(paramDouble6)
/*     */           }); 
/* 345 */     this.path.transform(BaseTransform.getInstance(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6));
/*     */   }
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\javafx\webkit\prism\WCPathImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */