/*    */ package com.sun.webkit.dom;
/*    */ 
/*    */ import org.w3c.dom.html.HTMLOptGroupElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTMLOptGroupElementImpl
/*    */   extends HTMLElementImpl
/*    */   implements HTMLOptGroupElement
/*    */ {
/*    */   HTMLOptGroupElementImpl(long paramLong) {
/* 32 */     super(paramLong);
/*    */   }
/*    */   
/*    */   static HTMLOptGroupElement getImpl(long paramLong) {
/* 36 */     return (HTMLOptGroupElement)create(paramLong);
/*    */   }
/*    */   
/*    */   static native boolean getDisabledImpl(long paramLong);
/*    */   
/*    */   public boolean getDisabled() {
/* 42 */     return getDisabledImpl(getPeer());
/*    */   }
/*    */   static native void setDisabledImpl(long paramLong, boolean paramBoolean);
/*    */   
/*    */   public void setDisabled(boolean paramBoolean) {
/* 47 */     setDisabledImpl(getPeer(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLabel() {
/* 52 */     return getLabelImpl(getPeer());
/*    */   }
/*    */   static native String getLabelImpl(long paramLong);
/*    */   
/*    */   public void setLabel(String paramString) {
/* 57 */     setLabelImpl(getPeer(), paramString);
/*    */   }
/*    */   
/*    */   static native void setLabelImpl(long paramLong, String paramString);
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\dom\HTMLOptGroupElementImpl.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */