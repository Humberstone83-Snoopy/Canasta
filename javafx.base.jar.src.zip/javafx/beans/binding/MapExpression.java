/*     */ package javafx.beans.binding;
/*     */ 
/*     */ import com.sun.javafx.binding.StringFormatter;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*     */ import javafx.beans.property.ReadOnlyIntegerProperty;
/*     */ import javafx.beans.value.ObservableMapValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MapExpression<K, V>
/*     */   implements ObservableMapValue<K, V>
/*     */ {
/*  59 */   private static final ObservableMap EMPTY_MAP = new EmptyObservableMap<>();
/*     */   
/*     */   private static class EmptyObservableMap<K, V> extends AbstractMap<K, V> implements ObservableMap<K, V> {
/*     */     private EmptyObservableMap() {}
/*     */     
/*     */     public Set<Map.Entry<K, V>> entrySet() {
/*  65 */       return Collections.emptySet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addListener(InvalidationListener param1InvalidationListener) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void removeListener(InvalidationListener param1InvalidationListener) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableMap<K, V> getValue() {
/*  91 */     return get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> MapExpression<K, V> mapExpression(final ObservableMapValue<K, V> value) {
/* 112 */     if (value == null) {
/* 113 */       throw new NullPointerException("Map must be specified.");
/*     */     }
/* 115 */     return (value instanceof MapExpression) ? (MapExpression<K, V>)value : 
/* 116 */       new MapBinding<K, V>()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void dispose()
/*     */         {
/* 123 */           unbind(new Observable[] { this.val$value });
/*     */         }
/*     */ 
/*     */         
/*     */         protected ObservableMap<K, V> computeValue() {
/* 128 */           return value.get();
/*     */         }
/*     */ 
/*     */         
/*     */         public ObservableList<?> getDependencies() {
/* 133 */           return FXCollections.singletonObservableList(value);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 143 */     return size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectBinding<V> valueAt(K paramK) {
/* 165 */     return Bindings.valueAt(this, paramK);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectBinding<V> valueAt(ObservableValue<K> paramObservableValue) {
/* 176 */     return Bindings.valueAt(this, paramObservableValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isEqualTo(ObservableMap<?, ?> paramObservableMap) {
/* 190 */     return Bindings.equal(this, paramObservableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotEqualTo(ObservableMap<?, ?> paramObservableMap) {
/* 204 */     return Bindings.notEqual(this, paramObservableMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNull() {
/* 213 */     return Bindings.isNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanBinding isNotNull() {
/* 222 */     return Bindings.isNotNull(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBinding asString() {
/* 234 */     return (StringBinding)StringFormatter.convert(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 239 */     ObservableMap<K, V> observableMap = get();
/* 240 */     return (observableMap == null) ? EMPTY_MAP.size() : observableMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 245 */     ObservableMap<K, V> observableMap = get();
/* 246 */     return (observableMap == null) ? EMPTY_MAP.isEmpty() : observableMap.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object paramObject) {
/* 251 */     ObservableMap<K, V> observableMap = get();
/* 252 */     return (observableMap == null) ? EMPTY_MAP.containsKey(paramObject) : observableMap.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object paramObject) {
/* 257 */     ObservableMap<K, V> observableMap = get();
/* 258 */     return (observableMap == null) ? EMPTY_MAP.containsValue(paramObject) : observableMap.containsValue(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public V put(K paramK, V paramV) {
/* 263 */     ObservableMap<K, V> observableMap = get();
/* 264 */     return (observableMap == null) ? EMPTY_MAP.put(paramK, paramV) : observableMap.put(paramK, paramV);
/*     */   }
/*     */ 
/*     */   
/*     */   public V remove(Object paramObject) {
/* 269 */     ObservableMap<K, V> observableMap = get();
/* 270 */     return (observableMap == null) ? (V)EMPTY_MAP.remove(paramObject) : observableMap.remove(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> paramMap) {
/* 275 */     ObservableMap<K, V> observableMap = get();
/* 276 */     if (observableMap == null) {
/* 277 */       EMPTY_MAP.putAll(paramMap);
/*     */     } else {
/* 279 */       observableMap.putAll(paramMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 285 */     ObservableMap<K, V> observableMap = get();
/* 286 */     if (observableMap == null) {
/* 287 */       EMPTY_MAP.clear();
/*     */     } else {
/* 289 */       observableMap.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 295 */     ObservableMap<K, V> observableMap = get();
/* 296 */     return (observableMap == null) ? EMPTY_MAP.keySet() : observableMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 301 */     ObservableMap<K, V> observableMap = get();
/* 302 */     return (observableMap == null) ? EMPTY_MAP.values() : observableMap.values();
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 307 */     ObservableMap<K, V> observableMap = get();
/* 308 */     return (observableMap == null) ? EMPTY_MAP.entrySet() : observableMap.entrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public V get(Object paramObject) {
/* 313 */     ObservableMap<K, V> observableMap = get();
/* 314 */     return (observableMap == null) ? (V)EMPTY_MAP.get(paramObject) : observableMap.get(paramObject);
/*     */   }
/*     */   
/*     */   public abstract ReadOnlyIntegerProperty sizeProperty();
/*     */   
/*     */   public abstract ReadOnlyBooleanProperty emptyProperty();
/*     */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.base.jar!\javafx\beans\binding\MapExpression.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */