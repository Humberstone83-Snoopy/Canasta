package com.sun.glass.events;

public class GestureEvent {
  public static final int GESTURE_STARTED = 1;
  
  public static final int GESTURE_PERFORMED = 2;
  
  public static final int GESTURE_FINISHED = 3;
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glass\events\GestureEvent.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */