/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Size
/*    */ {
/*    */   public int width;
/*    */   public int height;
/*    */   
/*    */   public Size(int paramInt1, int paramInt2) {
/* 35 */     this.width = paramInt1;
/* 36 */     this.height = paramInt2;
/*    */   }
/*    */   
/*    */   public Size() {
/* 40 */     this(0, 0);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 44 */     return "Size(" + this.width + ", " + this.height + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\glas\\ui\Size.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */