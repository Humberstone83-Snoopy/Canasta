/*    */ package com.sun.javafx.scene.layout.region;
/*    */ 
/*    */ import javafx.css.ParsedValue;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.scene.paint.Paint;
/*    */ import javafx.scene.text.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LayeredBorderPaintConverter
/*    */   extends StyleConverter<ParsedValue<ParsedValue<?, Paint>[], Paint[]>[], Paint[][]>
/*    */ {
/* 41 */   private static final LayeredBorderPaintConverter LAYERED_BORDER_PAINT_CONVERTER = new LayeredBorderPaintConverter();
/*    */ 
/*    */   
/*    */   public static LayeredBorderPaintConverter getInstance() {
/* 45 */     return LAYERED_BORDER_PAINT_CONVERTER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Paint[][] convert(ParsedValue<ParsedValue<ParsedValue<?, Paint>[], Paint[]>[], Paint[][]> paramParsedValue, Font paramFont) {
/* 54 */     ParsedValue[] arrayOfParsedValue = (ParsedValue[])paramParsedValue.getValue();
/* 55 */     Paint[][] arrayOfPaint = new Paint[arrayOfParsedValue.length][0];
/* 56 */     for (byte b = 0; b < arrayOfParsedValue.length; b++) {
/* 57 */       arrayOfPaint[b] = StrokeBorderPaintConverter.getInstance().convert(arrayOfParsedValue[b], paramFont);
/*    */     }
/* 59 */     return arrayOfPaint;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 64 */     return "LayeredBorderPaintConverter";
/*    */   }
/*    */ }


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\scene\layout\region\LayeredBorderPaintConverter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */