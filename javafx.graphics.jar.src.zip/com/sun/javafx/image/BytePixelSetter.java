package com.sun.javafx.image;

import java.nio.ByteBuffer;

public interface BytePixelSetter extends PixelSetter<ByteBuffer> {
  void setArgb(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  void setArgbPre(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.graphics.jar!\com\sun\javafx\image\BytePixelSetter.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */