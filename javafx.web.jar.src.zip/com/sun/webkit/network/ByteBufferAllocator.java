package com.sun.webkit.network;

import java.nio.ByteBuffer;

interface ByteBufferAllocator {
  ByteBuffer allocate() throws InterruptedException;
  
  void release(ByteBuffer paramByteBuffer);
}


/* Location:              C:\Users\jack.humberstone\Documents\Canasta2.0 Test1\CanastaV2.0.jar!\javafx.web.jar!\com\sun\webkit\network\ByteBufferAllocator.class
 * Java compiler version: 10 (54.0)
 * JD-Core Version:       1.1.3
 */